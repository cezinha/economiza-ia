# Interactive Home Dashboards

Make every metric card and chart on the home overviews open a right-side drawer (same pattern as `NuddDetailDrawer`) with the underlying data, and let rows inside drill through to the existing `My tasks` and `NUDDs` pages.

## Pattern (shared)

- New shared component `DashboardDetailDrawer` built on `Sheet` (right side, ~`max-w-[900px]`), matching NUDD drawer styling: header with eyebrow + title, scrollable body, semantic tokens only, `shadow-elev-*`, DDS typography.
- Each KpiCard gets a small `See details →` link in the bottom-right corner (button-style link, `text-button-2 text-primary`). The card stays clickable too — both open the same drawer. Wire via a new optional `KpiCard` prop `onSeeDetails?: () => void` rendered as a footer link.
- `CurrentPhaseDonut` and `PhaseStatusCard` get a header-row `See details →` link on the right.
- Drill-through navigation uses existing `TasksPage` query params: `/tasks?tab=platform&launch={id}` (and `&inner=tasks` / `&phase=` / `&gate=` already supported). Function-level drill-through additionally sets a function filter via `useFilters().setFilters({ function: ['GOE'|'NPI'|'SchM'] })` before navigating.

## Drawers (one per metric)

1. **Upcoming tasks** — `UpcomingTasksDrawer`
   - Lists active (non-`completed`, non-`not-started`) tasks across filtered launches.
   - Grouped by Platform → Current phase (use `currentPhaseName` per track, `tasksForLaunch`, `taskStatus`).
   - Each task row links to `/tasks?tab=platform&launch={launchId}&inner=tasks&phase={phase}&gate={gate}` (existing PlatformTasks supports `initialPhase`/`initialGate`).

2. **Achieved / on track** — `PlatformStatusListDrawer` (status="on-track")
   - Filtered launches where `platformStatus(l) === "on-track"`.
   - Grouped by LOB (`DT`, `NB`, `DnCP`). For each platform row: platform name + per-function chips (`GOE`, `NPI`, `SchM`) using `functionStatus`.
   - Click platform name → `/tasks?tab=platform&launch={id}`.
   - Click a function chip → set `filters.function=[track]` then navigate to same URL.

3. **At risk with mitigation** — same component, status `"at-risk-mitigated"`.
4. **At risk no mitigation** — same component, status `"at-risk"`.

5. **Unresolved NUDDs** — `UnresolvedNuddsDrawer`
   - Lists NUDDs where `status !== "Completed"` (Open + On hold), columns: ID, LOB, Platform, Risk score (`impact * probability`), Status, Last updated.
   - Row click navigates to `/risks?tab=table&nudd={id}`. RisksPage will read the `nudd` query param, find the row, and open `NuddDetailDrawer` automatically.

6. **Unresolved design issues** — `UnresolvedDesignIssuesDrawer`
   - Same column layout as the NUDD drawer but with a single empty state: "No design issue data available yet." (matches the existing `—` value).

7. **Current phase status (donut)** — `PhaseStatusByPlatformDrawer`
   - Same body as #2/3/4 but lists every filtered platform (all statuses), grouped by status section (on track → mitigated → at risk), each section grouped by LOB. Same drill-through behavior.

8. **Status distribution by current phase (per-track charts)** — `FunctionStatusDrawer`
   - Three sections (`GOE`, `NPI`, `SChM`). Within each, list every filtered platform with `functionStatus(l, track)` chip.
   - Click platform → `/tasks?tab=platform&launch={id}` with `filters.function=[track]` preset.
   - Each card's header gets its own `See details →` opening the drawer scrolled/anchored to that track's section (track passed as prop).

## Files

New
- `src/components/dashboard/drawers/DashboardDetailDrawer.tsx` (shared shell)
- `src/components/dashboard/drawers/UpcomingTasksDrawer.tsx`
- `src/components/dashboard/drawers/PlatformStatusListDrawer.tsx` (handles on-track / mitigated / at-risk + "all" mode)
- `src/components/dashboard/drawers/UnresolvedNuddsDrawer.tsx`
- `src/components/dashboard/drawers/UnresolvedDesignIssuesDrawer.tsx`
- `src/components/dashboard/drawers/FunctionStatusDrawer.tsx`

Edited
- `src/components/dashboard/KpiCard.tsx` — add `onSeeDetails` footer link.
- `src/components/dashboard/PortfolioMetrics.tsx` — own the open/close state for the six KPI drawers; wire `onSeeDetails` per card.
- `src/components/dashboard/CurrentPhaseDonut.tsx` — add header `See details →`, mount drawer.
- `src/components/dashboard/PhaseStatusCard.tsx` — add per-card header `See details →`, mount drawer with track prop.
- `src/pages/RisksPage.tsx` — read `?nudd=` query param to auto-open `NuddDetailDrawer`.
- (No changes needed to `TasksPage` — it already accepts `tab`, `launch`, `inner`, `phase`, `gate`.)

## Behavior notes

- All drawers honor the global `FilterContext` (use `useFilteredLaunches` / `useFilteredNudds`) so changing top filters changes drawer contents.
- Function drill-through uses `setFilters({ function: [track] })` so the `My tasks › By platform` view is automatically scoped — the existing function filter already drives `PlatformTasks`/`PortfolioMetrics`.
- Empty states: each drawer shows a friendly `text-body-3 text-muted-foreground` line when no rows match.
- No backend / mock changes needed; design issues drawer is intentionally an empty state.
- Dell DDS: only semantic tokens (`text-foreground`, `bg-surface`, `border-border`, status tokens, `shadow-elev-*`), DDS typography classes, no raw colors.
