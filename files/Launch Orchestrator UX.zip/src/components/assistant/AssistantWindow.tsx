import { useEffect, useRef, useState, KeyboardEvent } from "react";
import { Bot, MessageCircle, SendHorizontal, Trash2, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { cn } from "@/lib/utils";
import { AssistantMessage, type AssistantMessageData } from "./AssistantMessage";

interface AssistantWindowProps {
  open: boolean;
  onClose: () => void;
  messages: AssistantMessageData[];
  pending: boolean;
  onSubmit: (text: string) => void;
  onClear: () => void;
  userFirstName: string;
}

const HEADER_GRADIENT = "bg-[linear-gradient(135deg,hsl(225_70%_38%),hsl(285_45%_30%),hsl(330_65%_45%))]";

export function AssistantWindow({
  open,
  onClose,
  messages,
  pending,
  onSubmit,
  onClear,
  userFirstName,
}: AssistantWindowProps) {
  const [draft, setDraft] = useState("");
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, pending, open]);

  const submit = () => {
    const text = draft.trim();
    if (!text || pending) return;
    onSubmit(text);
    setDraft("");
  };

  const onKeyDown = (e: KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      submit();
    }
  };

  if (!open) return null;

  return (
    <div
      role="dialog"
      aria-label="OLP Assistant"
      className={cn(
        "fixed z-50 flex flex-col overflow-hidden rounded-lg border border-border bg-surface shadow-elev-4",
        // Desktop: anchored bottom-right above launcher.
        "m:bottom-24 m:right-6 m:h-[560px] m:w-[380px]",
        // Mobile: full-screen sheet.
        "inset-x-2 bottom-2 top-2",
      )}
    >
      {/* Header */}
      <div className={cn("flex items-center gap-3 px-4 py-3 text-primary-foreground", HEADER_GRADIENT)}>
        <Bot className="h-5 w-5 shrink-0" strokeWidth={1.75} />
        <span className="text-body-2 flex-1 truncate">OLP Assistant</span>
        <button
          type="button"
          onClick={onClear}
          aria-label="Clear conversation"
          className="rounded-sm p-1 hover:bg-white/10 transition-colors"
        >
          <Trash2 className="h-4 w-4" strokeWidth={1.75} />
        </button>
        <button
          type="button"
          onClick={onClose}
          aria-label="Close assistant"
          className="rounded-sm p-1 hover:bg-white/10 transition-colors"
        >
          <X className="h-4 w-4" strokeWidth={1.75} />
        </button>
      </div>

      {/* Body */}
      <div ref={scrollRef} className="flex-1 overflow-y-auto px-4 py-4">
        {messages.length === 0 ? (
          <div className="flex h-full flex-col items-center justify-center text-center">
            <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/10 text-primary">
              <MessageCircle className="h-6 w-6" strokeWidth={1.75} />
            </div>
            <p className="mt-4 text-body-2 text-foreground">
              How can I help you?
            </p>
            <p className="mt-2 max-w-xs text-caption text-muted-foreground">
              Ask about NUDDs, program documents, milestones, or any indexed content.
            </p>
          </div>
        ) : (
          <div className="flex flex-col gap-3">
            {messages.map((m) => (
              <AssistantMessage key={m.id} message={m} />
            ))}
            {pending && (
              <div className="flex w-full justify-start">
                <div className="flex items-center gap-1 rounded-lg bg-muted px-3 py-2">
                  <span className="h-2 w-2 animate-pulse rounded-full bg-muted-foreground" />
                  <span className="h-2 w-2 animate-pulse rounded-full bg-muted-foreground [animation-delay:150ms]" />
                  <span className="h-2 w-2 animate-pulse rounded-full bg-muted-foreground [animation-delay:300ms]" />
                </div>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Composer */}
      <div className="border-t border-border bg-surface px-4 py-3">
        <div className="flex items-end gap-2">
          <Textarea
            value={draft}
            onChange={(e) => setDraft(e.target.value)}
            onKeyDown={onKeyDown}
            placeholder="Type your question…"
            rows={2}
            className="min-h-12 resize-none border-primary/40 focus-visible:ring-primary"
          />
          <Button
            type="button"
            size="icon"
            variant="outline"
            onClick={submit}
            disabled={!draft.trim() || pending}
            aria-label="Send message"
          >
            <SendHorizontal className="h-4 w-4" />
          </Button>
        </div>
        <p className="mt-2 text-caption text-muted-foreground">
          Press Enter to send, Shift+Enter for new line
        </p>
      </div>
    </div>
  );
}
