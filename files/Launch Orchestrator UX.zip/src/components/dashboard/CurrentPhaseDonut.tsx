import { useState } from "react";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { useFilteredLaunches } from "@/lib/applyFilters";
import { platformStatus } from "@/lib/launchTasks";
import { Cell, Pie, PieChart, ResponsiveContainer, Tooltip } from "recharts";
import { ArrowRight } from "lucide-react";
import { PlatformStatusListDrawer } from "@/components/dashboard/drawers/PlatformStatusListDrawer";

const SEGMENTS = [
  { key: "on-track", label: "Achieved / on track", color: "hsl(var(--status-on-track))" },
  { key: "at-risk-mitigated", label: "Risk with mitigation", color: "hsl(var(--status-at-risk-mitigated))" },
  { key: "at-risk", label: "Missed / no mitigation plan", color: "hsl(var(--status-at-risk))" },
] as const;

export function CurrentPhaseDonut() {
  const launches = useFilteredLaunches();
  const [open, setOpen] = useState(false);
  const data = SEGMENTS.map((s) => ({
    name: s.label,
    color: s.color,
    value: launches.filter((l) => platformStatus(l) === s.key).length,
  }));
  const total = launches.length;

  return (
    <Card className="border-border bg-surface shadow-elev-1 h-full">
      <CardHeader className="space-y-1">
        <div className="flex items-start justify-between gap-3">
          <div className="space-y-1">
            <CardTitle className="text-h5 text-foreground">Current phase status</CardTitle>
            <p className="text-body-3 text-muted-foreground">Total count across active platforms</p>
          </div>
          <button
            type="button"
            onClick={() => setOpen(true)}
            className="inline-flex items-center gap-1 text-button-2 text-primary hover:underline focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring rounded-sm shrink-0"
          >
            See details
            <ArrowRight className="h-3 w-3" aria-hidden />
          </button>
        </div>
      </CardHeader>
      <CardContent>
        <div className="relative h-[320px] w-full">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Tooltip
                content={({ active, payload }) => {
                  if (!active || !payload?.length) return null;
                  const p = payload[0];
                  return (
                    <div className="rounded-sm border border-border bg-surface px-3 py-2 shadow-elev-2">
                      <div className="flex items-center gap-2 text-caption text-foreground">
                        <span
                          className="inline-block h-2 w-2 rounded-sm"
                          style={{ background: (p.payload as { color: string }).color }}
                        />
                        <span>
                          {p.name} : {p.value}
                        </span>
                      </div>
                    </div>
                  );
                }}
              />
              <Pie
                data={data}
                dataKey="value"
                nameKey="name"
                innerRadius="65%"
                outerRadius="90%"
                stroke="hsl(var(--surface))"
                strokeWidth={2}
                paddingAngle={2}
              >
                {data.map((d) => (
                  <Cell key={d.name} fill={d.color} />
                ))}
              </Pie>
            </PieChart>
          </ResponsiveContainer>
          <div className="pointer-events-none absolute inset-0 flex flex-col items-center justify-center">
            <div className="text-h2 text-foreground tabular-nums">{total}</div>
            <div className="text-caption text-muted-foreground">Active platforms</div>
          </div>
        </div>
        <div className="mt-4 flex flex-wrap items-center justify-center gap-4">
          {SEGMENTS.map((s) => (
            <div key={s.key} className="flex items-center gap-2 text-caption text-foreground">
              <span className="inline-block h-2 w-2 rounded-sm" style={{ background: s.color }} />
              <span>{s.label}</span>
            </div>
          ))}
        </div>
      </CardContent>
      <PlatformStatusListDrawer
        open={open}
        onOpenChange={setOpen}
        status="all"
        eyebrow="Current phase status"
        title="Platforms by current phase status"
      />
    </Card>
  );
}
