import { ReactNode } from "react";
import { cn } from "@/lib/utils";
import { DdsGrid, DdsCol } from "@/components/layout/DdsGrid";

/**
 * Two-column home workspace: a sticky left "summary rail" and a wider right
 * "feed" that scrolls. Both columns collapse to full-width below the L
 * breakpoint (1024px), with the rail stacked above the feed.
 *
 * Layout is composed of DDS primitives only (DdsGrid + DdsCol) — never
 * bespoke `grid-cols-*`. The vertical rhythm inside each column uses the
 * standard `gap-gutter` token so columns share the dashboard's gutter.
 */

export function HomeWorkspace({ children, className }: { children: ReactNode; className?: string }) {
  return <DdsGrid className={cn(className)}>{children}</DdsGrid>;
}

export function HomeRail({ children, className }: { children: ReactNode; className?: string }) {
  return (
    <DdsCol span={4} spanM={6} spanS={6} spanXs={2} className="l:self-start">
      <div className={cn("flex flex-col gap-gutter l:sticky l:top-16", className)}>
        {children}
      </div>
    </DdsCol>
  );
}

export function HomeFeed({ children, className }: { children: ReactNode; className?: string }) {
  return (
    <DdsCol span={8} spanM={6} spanS={6} spanXs={2}>
      <div className={cn("flex flex-col gap-gutter", className)}>{children}</div>
    </DdsCol>
  );
}

/** Single full-width column that stacks all home sections vertically. */
export function HomeStack({ children, className }: { children: ReactNode; className?: string }) {
  return (
    <DdsCol span={12} spanM={6} spanS={6} spanXs={2}>
      <div className={cn("flex flex-col gap-gutter", className)}>{children}</div>
    </DdsCol>
  );
}

/** Bottom row: Action queue (LHS) + Activity (RHS). One child = full width. */
export function HomeBottomRow({ children }: { children: ReactNode }) {
  const items = Array.isArray(children) ? children.filter(Boolean) : [children];
  if (items.length === 1) {
    return <DdsGrid><DdsCol span={12} spanM={6} spanS={6} spanXs={2}>{items[0]}</DdsCol></DdsGrid>;
  }
  return (
    <DdsGrid>
      {items.map((child, i) => (
        <DdsCol key={i} span={6} spanM={3} spanS={6} spanXs={2}>
          {child}
        </DdsCol>
      ))}
    </DdsGrid>
  );
}
