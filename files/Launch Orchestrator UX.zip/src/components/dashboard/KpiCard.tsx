import { Card, CardContent } from "@/components/ui/card";
import { cn } from "@/lib/utils";
import { LucideIcon, TrendingUp, TrendingDown, ArrowRight } from "lucide-react";

interface KpiCardProps {
  label: string;
  value: string | number;
  delta?: { value: string; direction: "up" | "down"; positive?: boolean };
  icon?: LucideIcon;
  tone?: "default" | "success" | "warning" | "danger";
  onClick?: () => void;
  selected?: boolean;
  onSeeDetails?: () => void;
}

const toneRing: Record<NonNullable<KpiCardProps["tone"]>, string> = {
  default: "before:bg-primary",
  success: "before:bg-success",
  warning: "before:bg-warning",
  danger: "before:bg-danger",
};

export function KpiCard({ label, value, delta, icon: Icon, tone = "default", onClick, selected, onSeeDetails }: KpiCardProps) {
  const interactive = typeof onClick === "function";
  const inner = (
    <CardContent className="p-4 m:p-6">
      <div className="flex items-start justify-between gap-4">
        <div>
          <p className="text-caption font-medium uppercase tracking-wide text-muted-foreground">{label}</p>
          <p className="mt-2 text-h2 tabular-nums text-foreground">{value}</p>
          {delta && (
            <div className={cn(
              "mt-2 inline-flex items-center gap-1 text-caption font-medium",
              delta.positive ? "text-success" : "text-danger",
            )}>
              {delta.direction === "up" ? <TrendingUp className="h-3 w-3" /> : <TrendingDown className="h-3 w-3" />}
              {delta.value}
            </div>
          )}
        </div>
        {Icon && (
          <div className="flex h-8 w-8 items-center justify-center rounded-sm bg-muted text-muted-foreground shrink-0">
            <Icon className="h-4 w-4" />
          </div>
        )}
      </div>
      {onSeeDetails && (
        <div className="mt-4 flex justify-end">
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              onSeeDetails();
            }}
            className="inline-flex items-center gap-1 text-button-2 text-primary hover:underline focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring rounded-sm"
          >
            See details
            <ArrowRight className="h-3 w-3" aria-hidden />
          </button>
        </div>
      )}
    </CardContent>
  );

  const cardClass = cn(
    "relative overflow-hidden border-border bg-surface shadow-elev-1 transition-shadow h-full",
    interactive && "cursor-pointer hover:shadow-elev-2 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring",
    !interactive && "hover:shadow-elev-2",
    selected && "ring-2 ring-primary shadow-elev-2",
  );

  if (interactive) {
    return (
      <Card
        role="button"
        tabIndex={0}
        aria-pressed={!!selected}
        onClick={onClick}
        onKeyDown={(e) => {
          if (e.key === "Enter" || e.key === " ") {
            e.preventDefault();
            onClick?.();
          }
        }}
        className={cardClass}
      >
        {inner}
      </Card>
    );
  }

  return <Card className={cardClass}>{inner}</Card>;
}
