import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Progress } from "@/components/ui/progress";
import { Button } from "@/components/ui/button";
import { useFilteredLaunches } from "@/lib/applyFilters";
import { RagBadge } from "./RagBadge";
import { ArrowUpRight } from "lucide-react";

export function LaunchTable() {
  const launches = useFilteredLaunches();
  return (
    <Card className="border-border bg-surface shadow-elev-1">
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-4">
        <div>
          <CardTitle className="text-h6 text-foreground">Active launches</CardTitle>
          <p className="text-caption text-muted-foreground mt-1">Portfolio-wide product launches in flight</p>
        </div>
        <Button variant="ghost" size="sm" className="text-primary hover:text-primary-hover">
          View all <ArrowUpRight className="ml-2 h-4 w-4" />
        </Button>
      </CardHeader>
      <CardContent className="p-0">
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow className="hover:bg-transparent">
                <TableHead className="text-caption uppercase tracking-wide text-muted-foreground">Launch</TableHead>
                <TableHead className="text-caption uppercase tracking-wide text-muted-foreground">LOB</TableHead>
                <TableHead className="text-caption uppercase tracking-wide text-muted-foreground">Phase</TableHead>
                <TableHead className="text-caption uppercase tracking-wide text-muted-foreground">Owner</TableHead>
                <TableHead className="text-caption uppercase tracking-wide text-muted-foreground w-[180px]">Progress</TableHead>
                <TableHead className="text-caption uppercase tracking-wide text-muted-foreground">Next milestone</TableHead>
                <TableHead className="text-caption uppercase tracking-wide text-muted-foreground">Status</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {launches.map((l) => (
                <TableRow key={l.id} className="cursor-pointer">
                  <TableCell>
                    <div className="font-medium text-foreground">{l.name}</div>
                    <div className="text-caption text-muted-foreground">{l.id} · {l.region}</div>
                  </TableCell>
                  <TableCell className="text-body-3 text-foreground">{l.lob}</TableCell>
                  <TableCell className="text-body-3 text-foreground">{l.phase}</TableCell>
                  <TableCell className="text-body-3 text-foreground">{l.owner}</TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <Progress value={l.progress} className="h-2" />
                      <span className="text-caption text-muted-foreground tabular-nums w-8 text-right">{l.progress}%</span>
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="text-body-3 text-foreground">{l.nextMilestone}</div>
                    <div className="text-caption text-muted-foreground">{l.nextMilestoneDate}</div>
                  </TableCell>
                  <TableCell><RagBadge rag={l.rag} /></TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  );
}
