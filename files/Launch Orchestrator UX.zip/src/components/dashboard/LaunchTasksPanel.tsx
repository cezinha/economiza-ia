import { useEffect, useState } from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ChevronRight, ChevronDown, ChevronUp } from "lucide-react";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { TaskDetailDrawer } from "@/components/dashboard/TaskDetailDrawer";
import type { Launch } from "@/mocks/launches";
import {
  tasksForLaunch,
  groupTasksByPhaseAndGate,
  taskStatus,
  isAutoTask,
  worstActive,
  type TaskFunction,
  type TaskStatus,
  type LaunchTask,
} from "@/lib/launchTasks";
import { cn } from "@/lib/utils";
import { PhaseExitTracker } from "@/components/dashboard/PhaseExitTracker";
import { NuddDetailDrawer } from "@/components/dashboard/NuddDetailDrawer";
import { NUDDS, type NuddRow } from "@/mocks/nudds";
import { Badge as RiskBadge } from "@/components/ui/badge";
import { useViewFilter } from "@/contexts/ViewFilterContext";

type TaskFilter = "all" | TaskFunction;

const trackLabel = (t: TaskFunction): string => (t === "SchM" ? "SChM" : t);

const FILTERS: { value: TaskFilter; label: string }[] = [
  { value: "all", label: "All" },
  { value: "GOE", label: "GOE" },
  { value: "NPI", label: "NPI" },
  { value: "SchM", label: trackLabel("SchM") },
];

const TRACKS: TaskFunction[] = ["GOE", "NPI", "SchM"];

const PHASE_CANONICAL_TEAMS: Record<string, TaskFunction[]> = {
  Concept: ["GOE", "NPI", "SchM"],
  Define: ["GOE", "NPI", "SchM"],
  Plan: ["GOE", "NPI", "SchM"],
  Develop: ["SchM"],
  Qual: ["GOE", "NPI"],
  Pilot: ["GOE", "NPI"],
  Launch: ["SchM"],
  Ramp: ["GOE", "NPI"],
};

const STATUS_CLASS: Record<TaskStatus, string> = {
  completed: "bg-status-completed",
  "on-track": "bg-status-on-track",
  "at-risk-mitigated": "bg-status-at-risk-mitigated",
  "at-risk": "bg-status-at-risk",
  "not-started": "bg-status-not-started",
};

function StatusDot({ status, className }: { status: TaskStatus; className?: string }) {
  return (
    <span
      className={cn("inline-block h-2 w-2 rounded-full shrink-0", STATUS_CLASS[status], className)}
      aria-hidden
    />
  );
}

interface LaunchTasksPanelProps {
  launch: Launch;
  initialTab?: "tasks" | "exit" | "nudds";
  initialPhase?: string;
  initialGate?: string;
}

export function LaunchTasksPanel({ launch, initialTab, initialPhase, initialGate }: LaunchTasksPanelProps) {
  const { lockedFunction } = useViewFilter();
  const [filter, setFilter] = useState<TaskFilter>(lockedFunction ?? "all");
  useEffect(() => {
    if (lockedFunction) setFilter(lockedFunction);
  }, [lockedFunction]);
  const [selectedTask, setSelectedTask] = useState<LaunchTask | null>(null);
  const [hintDismissed, setHintDismissed] = useState(false);
  const [selectedNudd, setSelectedNudd] = useState<NuddRow | null>(null);
  const [nuddOpen, setNuddOpen] = useState(false);
  const [showCompleted, setShowCompleted] = useState(false);
  const [tab, setTab] = useState<"tasks" | "exit" | "nudds">(initialTab ?? "tasks");
  const [openPhases, setOpenPhases] = useState<string[]>(
    initialPhase ? [`phase-${initialPhase}`] : [],
  );
  const [openGates, setOpenGates] = useState<string[]>(
    initialPhase && initialGate ? [`gate-${initialPhase}-${initialGate}`] : [],
  );

  useEffect(() => {
    if (initialTab) setTab(initialTab);
  }, [initialTab]);

  useEffect(() => {
    if (initialPhase) {
      const v = `phase-${initialPhase}`;
      setOpenPhases((prev) => (prev.includes(v) ? prev : [...prev, v]));
    }
  }, [initialPhase]);

  useEffect(() => {
    if (initialPhase && initialGate) {
      const v = `gate-${initialPhase}-${initialGate}`;
      setOpenGates((prev) => (prev.includes(v) ? prev : [...prev, v]));
    }
  }, [initialPhase, initialGate]);

  const allLaunchTasks = tasksForLaunch(launch);
  const launchTasks =
    filter === "all" ? allLaunchTasks : allLaunchTasks.filter((t) => t.teams.includes(filter));
  const grouped = groupTasksByPhaseAndGate(launchTasks);

  if (filter !== "SchM" && !grouped.some((p) => p.phase === "Ramp")) {
    const launchIdx = grouped.findIndex((p) => p.phase === "Launch");
    const entry = { phase: "Ramp", totalTasks: 0, gates: [] };
    if (launchIdx >= 0) grouped.splice(launchIdx, 0, entry);
    else grouped.push(entry);
  }

  const phaseRolledMap = new Map<string, TaskStatus>();
  grouped.forEach((p) => {
    const all = p.gates.flatMap((g) =>
      g.tasks.flatMap((t) => t.teams.map((tm) => taskStatus(launch, t, tm))),
    );
    let rolled: TaskStatus;
    if (all.length === 0) rolled = "not-started";
    else if (all.every((s) => s === "completed")) rolled = "completed";
    else if (all.every((s) => s === "not-started")) rolled = "not-started";
    else {
      const active = all.filter((s) => s !== "completed" && s !== "not-started");
      rolled = active.length > 0 ? worstActive(active) : "on-track";
    }
    phaseRolledMap.set(p.phase, rolled);
  });
  const completedPhaseCount = grouped.filter(
    (p) => phaseRolledMap.get(p.phase) === "completed",
  ).length;
  const visibleGrouped = showCompleted
    ? grouped
    : grouped.filter((p) => phaseRolledMap.get(p.phase) !== "completed");

  return (
    <>
      <Tabs value={tab} onValueChange={(v) => setTab(v as "tasks" | "exit" | "nudds")} className="w-full">
        <TabsList>
          <TabsTrigger value="tasks">
            Task list
            <span className="ml-2 text-caption font-normal text-muted-foreground">
              {launchTasks.length} of {allLaunchTasks.length}
            </span>
          </TabsTrigger>
          <TabsTrigger value="exit">Phase exit tracker</TabsTrigger>
          <TabsTrigger value="nudds">Relevant NUDDs</TabsTrigger>
        </TabsList>

        <TabsContent value="tasks" className="pt-4">
          <div className="flex items-center justify-start gap-4 mb-4 flex-wrap">
            {!lockedFunction && (
              <div className="inline-flex items-center rounded-full bg-surface border border-border p-1 gap-1">
                {FILTERS.map((f) => (
                  <button
                    key={f.value}
                    type="button"
                    onClick={() => setFilter(f.value)}
                    className={cn(
                      "px-4 py-2 text-button-2 rounded-full transition-colors whitespace-nowrap",
                      filter === f.value
                        ? "bg-primary text-primary-foreground shadow-elev-1"
                        : "text-muted-foreground hover:text-foreground",
                    )}
                  >
                    {f.label}
                  </button>
                ))}
              </div>
            )}
            {completedPhaseCount > 0 && (
              <Button
                type="button"
                variant="ghost"
                size="sm"
                onClick={() => setShowCompleted((v) => !v)}
                className="text-button-2 text-muted-foreground hover:text-foreground"
              >
                {showCompleted ? (
                  <>
                    <ChevronUp className="h-3 w-3 mr-1" />
                    Hide completed phases
                  </>
                ) : (
                  <>
                    <ChevronDown className="h-3 w-3 mr-1" />
                    Show {completedPhaseCount} completed phase{completedPhaseCount === 1 ? "" : "s"}
                  </>
                )}
              </Button>
            )}
          </div>
          {launchTasks.length === 0 ? (
            <p className="text-caption text-muted-foreground italic">No tasks match this filter.</p>
          ) : visibleGrouped.length === 0 ? (
            <p className="text-caption text-muted-foreground italic">All phases completed.</p>
          ) : (
            <Accordion type="multiple" value={openPhases} onValueChange={setOpenPhases} className="w-full">
              {visibleGrouped.map((p) => {
                const phaseGateStatuses = p.gates.map((g) =>
                  worstActive(
                    g.tasks.flatMap((t) => t.teams.map((tm) => taskStatus(launch, t, tm))),
                  ),
                );
                const phaseRolled = phaseRolledMap.get(p.phase) ?? ("not-started" as TaskStatus);
                const derived = TRACKS.filter((tr) =>
                  p.gates.some((g) => g.tasks.some((t) => t.teams.includes(tr))),
                );
                const canonical = (PHASE_CANONICAL_TEAMS[p.phase] ?? []).filter(
                  (tr) => filter === "all" || filter === tr,
                );
                const phaseTeams = derived.length > 0 ? derived : canonical;

                return (
                  <AccordionItem
                    key={p.phase}
                    value={`phase-${p.phase}`}
                    className="border-border"
                  >
                    <AccordionTrigger className="py-2 hover:no-underline">
                      <span className="flex items-center gap-2 text-body-3 font-medium text-foreground">
                        <StatusDot status={phaseRolled} />
                        {p.phase}
                        <span className="text-caption font-normal text-muted-foreground">
                          {p.totalTasks}
                        </span>
                        <span className="flex items-center gap-1 ml-2">
                          {phaseTeams.map((tm) => (
                            <Badge
                              key={tm}
                              variant="outline"
                              className="text-caption font-medium px-2 py-0"
                            >
                              {trackLabel(tm)}
                            </Badge>
                          ))}
                        </span>
                      </span>
                    </AccordionTrigger>
                    <AccordionContent className="pb-2">
                      <Accordion type="multiple" value={openGates} onValueChange={setOpenGates} className="w-full pl-4">
                        {p.gates.map((g, gi) => (
                          <AccordionItem
                            key={g.gate}
                            value={`gate-${p.phase}-${g.gate}`}
                            className="border-border"
                          >
                            <AccordionTrigger className="py-2 hover:no-underline">
                              <span className="flex items-center gap-2 text-caption text-foreground text-left">
                                <StatusDot status={phaseGateStatuses[gi]} />
                                {g.gate}
                                <span className="text-caption font-normal text-muted-foreground">
                                  {g.tasks.length}
                                </span>
                              </span>
                            </AccordionTrigger>
                            <AccordionContent className="pb-2">
                              <ul className="space-y-2 pl-4">
                                {!hintDismissed && g.tasks.length > 0 && (
                                  <li className="text-caption text-muted-foreground italic pb-1">
                                    Tip: click a row to view task details.
                                  </li>
                                )}
                                {g.tasks.map((t) => {
                                  const tStatus = worstActive(
                                    t.teams.map((tm) => taskStatus(launch, t, tm)),
                                  );
                                  return (
                                    <li key={t.id}>
                                      <div
                                        role="button"
                                        tabIndex={0}
                                        onClick={() => {
                                          setHintDismissed(true);
                                          setSelectedTask(t);
                                        }}
                                        onKeyDown={(e) => {
                                          if (e.key === "Enter" || e.key === " ") {
                                            e.preventDefault();
                                            setHintDismissed(true);
                                            setSelectedTask(t);
                                          }
                                        }}
                                        className="group flex items-start gap-3 text-caption w-full text-left rounded-md px-2 py-1 -mx-2 border-l-2 border-transparent hover:bg-muted/40 hover:border-primary transition-colors cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                                      >
                                        <StatusDot status={tStatus} className="mt-2" />
                                        <div className="flex flex-col gap-1 shrink-0 w-16">
                                          {t.teams.map((tm) => (
                                            <Badge
                                              key={tm}
                                              variant="outline"
                                              className="font-medium justify-center"
                                            >
                                              {trackLabel(tm)}
                                            </Badge>
                                          ))}
                                        </div>
                                        <div className="min-w-0 flex-1">
                                          <p className="text-body-3 text-foreground">
                                            {t.task}
                                            {isAutoTask(t) && (
                                              <Badge
                                                variant="secondary"
                                                className="ml-2 align-middle text-caption"
                                              >
                                                Auto
                                              </Badge>
                                            )}
                                          </p>
                                          {t.taskEnd && (
                                            <p className="text-caption text-muted-foreground mt-1">
                                              {t.taskEnd}
                                            </p>
                                          )}
                                        </div>
                                        <span className="self-center flex items-center gap-1 text-caption font-medium text-primary opacity-0 group-hover:opacity-100 group-focus-visible:opacity-100 transition-opacity shrink-0">
                                          View
                                          <ChevronRight className="h-3 w-3" />
                                        </span>
                                      </div>
                                    </li>
                                  );
                                })}
                              </ul>
                            </AccordionContent>
                          </AccordionItem>
                        ))}
                      </Accordion>
                    </AccordionContent>
                  </AccordionItem>
                );
              })}
            </Accordion>
          )}
        </TabsContent>

        <TabsContent value="exit" className="pt-4">
          <PhaseExitTracker launch={launch} />
        </TabsContent>
        <TabsContent value="nudds" className="pt-4">
          {(() => {
            const relevant = NUDDS.filter((n) => n.platform === launch.name);
            if (relevant.length === 0) {
              return (
                <p className="text-caption text-muted-foreground italic">
                  No NUDDs recorded for this platform.
                </p>
              );
            }
            const bandOf = (n: number): "Low" | "Medium" | "High" =>
              n <= 2 ? "Low" : n <= 5 ? "Medium" : "High";
            const bandClass = (b: "Low" | "Medium" | "High") =>
              b === "High"
                ? "bg-risk-high text-risk-high-foreground hover:bg-risk-high"
                : b === "Medium"
                ? "bg-risk-medium text-risk-medium-foreground hover:bg-risk-medium"
                : "bg-risk-low text-risk-low-foreground hover:bg-risk-low";
            return (
              <ul className="divide-y divide-border">
                {relevant.map((row) => {
                  const risk = row.impact * row.probability;
                  const b = bandOf(risk);
                  return (
                    <li key={row.id} className="flex items-start justify-between gap-4 py-3">
                      <div className="min-w-0">
                        <div className="flex items-center gap-2">
                          <span className="text-body-3 font-medium text-foreground tabular-nums">{row.id}</span>
                          <span className="text-body-3 text-foreground truncate">{row.title}</span>
                        </div>
                        <div className="mt-1 flex flex-wrap items-center gap-2 text-caption text-muted-foreground">
                          <span>{row.lob}</span>
                          <span aria-hidden>·</span>
                          <span>{row.status}</span>
                          <span aria-hidden>·</span>
                          <span className="tabular-nums">Risk {risk}</span>
                          <RiskBadge className={`rounded-full font-medium border-transparent ${bandClass(b)}`}>{b}</RiskBadge>
                        </div>
                      </div>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => {
                          setSelectedNudd(row);
                          setNuddOpen(true);
                        }}
                      >
                        View details
                      </Button>
                    </li>
                  );
                })}
              </ul>
            );
          })()}
        </TabsContent>
      </Tabs>

      <TaskDetailDrawer
        task={selectedTask}
        launch={launch}
        initialStatus={
          selectedTask
            ? worstActive(selectedTask.teams.map((tm) => taskStatus(launch, selectedTask, tm)))
            : "not-started"
        }
        onOpenChange={(o) => !o && setSelectedTask(null)}
      />
      <NuddDetailDrawer row={selectedNudd} open={nuddOpen} onOpenChange={setNuddOpen} />
    </>
  );
}
