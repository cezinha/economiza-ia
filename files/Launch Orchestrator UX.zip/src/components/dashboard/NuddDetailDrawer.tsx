import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetDescription,
} from "@/components/ui/sheet";
import { Badge } from "@/components/ui/badge";
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible";
import { ChevronDown } from "lucide-react";
import { cn } from "@/lib/utils";
import type { NuddRow } from "@/mocks/nudds";

type Props = {
  row: NuddRow | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
};

function Row({ label, value }: { label: string; value: React.ReactNode }) {
  return (
    <div className="grid grid-cols-[160px_1fr] gap-4 py-2">
      <dt className="text-body-3 text-muted-foreground">{label}</dt>
      <dd className="text-body-3 text-foreground min-w-0 break-words">
        {value ?? <span className="text-muted-foreground">—</span>}
      </dd>
    </div>
  );
}

function Section({
  title,
  children,
  defaultOpen = true,
}: {
  title: string;
  children: React.ReactNode;
  defaultOpen?: boolean;
}) {
  return (
    <Collapsible defaultOpen={defaultOpen} className="border-b border-border last:border-0">
      <CollapsibleTrigger className="group flex w-full items-center gap-2 py-4 text-left">
        <ChevronDown
          className="h-4 w-4 text-muted-foreground transition-transform group-data-[state=closed]:-rotate-90"
          aria-hidden
        />
        <span className="text-subtitle-2 text-foreground">{title}</span>
      </CollapsibleTrigger>
      <CollapsibleContent>
        <dl className="pb-4">{children}</dl>
      </CollapsibleContent>
    </Collapsible>
  );
}

function riskBand(n: number): "Low" | "Medium" | "High" {
  if (n <= 2) return "Low";
  if (n <= 5) return "Medium";
  return "High";
}

function scoreLabel(n: number) {
  return n === 1 ? "Low" : n === 2 ? "Medium" : "High";
}

export function NuddDetailDrawer({ row, open, onOpenChange }: Props) {
  if (!row) return null;
  const risk = row.impact * row.probability;
  const band = riskBand(risk);

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent
        side="right"
        className={cn(
          "w-full sm:max-w-[1200px] sm:w-[92vw] overflow-y-auto p-0 bg-surface",
        )}
      >
        <SheetHeader className="px-6 pt-6 pb-4 border-b border-border space-y-2">
          <div className="flex items-center gap-2 text-caption text-muted-foreground tabular-nums">
            <span>NUDDs</span>
            <span aria-hidden>/</span>
            <span className="text-foreground font-medium">{row.id}</span>
          </div>
          <SheetTitle className="text-h5 text-foreground">{row.title}</SheetTitle>
          <SheetDescription className="sr-only">
            Detailed information about {row.id}
          </SheetDescription>
          <div className="flex flex-wrap items-center gap-2 pt-1">
            <Badge variant="outline" className="rounded-full font-medium">
              {row.status}
            </Badge>
            <Badge className={`rounded-full font-medium tabular-nums border-transparent ${band === "High" ? "bg-risk-high text-risk-high-foreground hover:bg-risk-high" : band === "Medium" ? "bg-risk-medium text-risk-medium-foreground hover:bg-risk-medium" : "bg-risk-low text-risk-low-foreground hover:bg-risk-low"}`}>
              Risk {risk} · {band}
            </Badge>
            <Badge variant="outline" className="rounded-full font-medium">
              {row.type}
            </Badge>
          </div>
        </SheetHeader>

        <div className="px-6">
          <Section title="Details">
            <Row label="Type" value={row.type} />
            <Row label="Resolution" value={row.resolution} />
            <Row
              label="Labels"
              value={
                row.labels.length === 0 ? (
                  "None"
                ) : (
                  <div className="flex flex-wrap gap-1">
                    {row.labels.map((l) => (
                      <Badge key={l} variant="outline" className="rounded-full font-medium">
                        {l}
                      </Badge>
                    ))}
                  </div>
                )
              }
            />
            <Row label="Program name" value={row.programName} />
            <Row label="Program state" value={row.programState} />
            <Row label="Domain / Business" value={row.domainBusiness} />
            <Row label="Program category" value={row.programCategory} />
            <Row label="Platform model ID" value={row.platformModelId} />
            <Row label="Predecessor" value={row.predecessor} />
            <Row label="Form factor" value={row.formFactor} />
            <Row label="Program class" value={row.programClass} />
            <Row label="Program phase" value={row.programPhase} />
            <Row label="Tier" value={row.tier} />
            <Row label="CPU architecture" value={row.cpuArchitecture} />
            <Row label="ODM / Supplier" value={row.odmSupplier} />
            <Row
              label="RTS calendar"
              value={`${row.rtsCalendar.year} · ${row.rtsCalendar.quarter} · ${row.rtsCalendar.month}`}
            />
            <Row
              label="RTO calendar"
              value={`${row.rtoCalendar.year} · ${row.rtoCalendar.quarter} · ${row.rtoCalendar.month}`}
            />
          </Section>

          <Section title="People">
            <Row label="Assignee" value={row.people.assignee} />
            <Row label="Reporter" value={row.people.reporter} />
            <Row label="Program manager" value={row.people.programManager} />
            <Row label="Project manager" value={row.people.projectManager} />
            <Row label="Engineers" value={row.people.engineers.join(", ")} />
            <Row label="Quality engineer" value={row.people.qualityEngineer} />
            <Row label="Procurement" value={row.people.procurement} />
            <Row label="Services" value={row.people.services.join(", ")} />
            <Row label="GOE" value={row.people.goe} />
            <Row label="EDG" value={row.people.edg} />
          </Section>

          <Section title="Dates">
            <Row label="Created" value={row.dates.created} />
            <Row label="Updated" value={row.dates.updated} />
            <Row label="Concept Entry Target" value={row.dates.conceptEntryTarget} />
            <Row label="Concept Exit Target" value={row.dates.conceptExitTarget} />
            <Row label="Define Exit Target" value={row.dates.defineExitTarget} />
            <Row label="BA Target" value={row.dates.baTarget} />
            <Row label="DDS Target" value={row.dates.ddsTarget} />
            <Row label="Plan Exit Target" value={row.dates.planExitTarget} />
            <Row label="RFD Target" value={row.dates.rfdTarget} />
            <Row label="Develop Exit Target" value={row.dates.developExitTarget} />
            <Row label="RTS Target" value={row.dates.rtsTarget} />
            <Row label="RTO Target" value={row.dates.rtoTarget} />
          </Section>

          <Section title="Risk scoring">
            <Row label="Impact score" value={`${row.impact} · ${scoreLabel(row.impact)}`} />
            <Row
              label="Probability score"
              value={`${row.probability} · ${scoreLabel(row.probability)}`}
            />
            <Row label="Risk score" value={`${risk} · ${band}`} />
          </Section>
        </div>
      </SheetContent>
    </Sheet>
  );
}
