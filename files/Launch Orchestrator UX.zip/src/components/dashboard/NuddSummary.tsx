import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { DdsGrid, DdsCol } from "@/components/layout/DdsGrid";
import { KpiCard } from "@/components/dashboard/KpiCard";
import { type NuddRow, type NuddStatus } from "@/mocks/nudds";
import { launches as ALL_LAUNCHES } from "@/mocks/launches";
import { useFilteredNudds } from "@/lib/applyFilters";
import { AlertCircle, ArrowRight, Layers, X } from "lucide-react";
import { Bar, BarChart, CartesianGrid, Cell, Legend, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";

type KpiMode = "unresolved" | "platforms" | null;

type Band = "Low" | "Medium" | "High";

function band(score: number): Band {
  if (score <= 2) return "Low";
  if (score <= 5) return "Medium";
  return "High";
}

function bandClass(b: Band) {
  return b === "High"
    ? "bg-risk-high text-risk-high-foreground hover:bg-risk-high"
    : b === "Medium"
    ? "bg-risk-medium text-risk-medium-foreground hover:bg-risk-medium"
    : "bg-risk-low text-risk-low-foreground hover:bg-risk-low";
}

const STATUSES: NuddStatus[] = ["Open", "On hold", "Completed"];
const BANDS: Band[] = ["Low", "Medium", "High"];

type Props = {
  onOpenRow: (row: NuddRow) => void;
};

export function NuddSummary({ onOpenRow }: Props) {
  const NUDDS = useFilteredNudds();
  const launches = ALL_LAUNCHES;
  const navigate = useNavigate();
  const [selected, setSelected] = useState<{ status: NuddStatus; band: Band } | null>(null);
  const [kpiMode, setKpiMode] = useState<KpiMode>(null);

  const selectKpi = (mode: NonNullable<KpiMode>) => {
    setKpiMode((cur) => (cur === mode ? null : mode));
    setSelected(null);
  };
  const selectSegment = (status: NuddStatus, b: Band) => {
    setSelected((cur) => (cur && cur.status === status && cur.band === b ? null : { status, band: b }));
    setKpiMode(null);
  };

  const rows = NUDDS.map((n) => ({ ...n, risk: n.impact * n.probability }));

  const data = STATUSES.map((status) => {
    const subset = rows.filter((r) => r.status === status);
    return {
      status,
      Low: subset.filter((r) => band(r.risk) === "Low").length,
      Medium: subset.filter((r) => band(r.risk) === "Medium").length,
      High: subset.filter((r) => band(r.risk) === "High").length,
    };
  });

  const unresolved = rows.filter((r) => r.status === "Open" || r.status === "On hold");
  const unresolvedCount = unresolved.length;
  const impactedPlatformsCount = new Set(unresolved.map((r) => r.platform)).size;

  const matching = selected
    ? rows.filter((r) => r.status === selected.status && band(r.risk) === selected.band)
    : [];

  const platformGroups = (() => {
    const map = new Map<string, typeof unresolved>();
    unresolved.forEach((r) => {
      const arr = map.get(r.platform) ?? [];
      arr.push(r);
      map.set(r.platform, arr);
    });
    return Array.from(map.entries())
      .map(([platform, items]) => {
        const launch = launches.find((l) => l.name === platform);
        return { platform, count: items.length, launchId: launch?.id };
      })
      .sort((a, b) => b.count - a.count);
  })();

  const handleBarClick = (b: Band) => (payload: { status?: NuddStatus } | undefined) => {
    if (payload?.status) selectSegment(payload.status, b);
  };

  const isDimmed = (status: NuddStatus, b: Band) =>
    selected !== null && !(selected.status === status && selected.band === b);

  return (
    <DdsGrid>
      <DdsCol span={6} spanM={3} spanS={3} spanXs={2}>
        <KpiCard
          label="Unresolved NUDDs"
          value={unresolvedCount}
          icon={AlertCircle}
          tone="warning"
          onClick={() => selectKpi("unresolved")}
          selected={kpiMode === "unresolved"}
        />
      </DdsCol>
      <DdsCol span={6} spanM={3} spanS={3} spanXs={2}>
        <KpiCard
          label="Impacted platforms"
          value={impactedPlatformsCount}
          icon={Layers}
          tone="default"
          onClick={() => selectKpi("platforms")}
          selected={kpiMode === "platforms"}
        />
      </DdsCol>
      <DdsCol span={12}>
        <Card className="border-border bg-surface shadow-elev-1">
            <CardHeader>
              <CardTitle className="text-h5 text-foreground">Status overview</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-[320px] w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={data} margin={{ top: 8, right: 16, bottom: 8, left: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
                    <XAxis
                      dataKey="status"
                      stroke="hsl(var(--muted-foreground))"
                      tick={{ fontSize: 12 }}
                      tickLine={false}
                      axisLine={{ stroke: "hsl(var(--border))" }}
                    />
                    <YAxis
                      allowDecimals={false}
                      stroke="hsl(var(--muted-foreground))"
                      tick={{ fontSize: 12 }}
                      tickLine={false}
                      axisLine={{ stroke: "hsl(var(--border))" }}
                    />
                    <Tooltip
                      cursor={{ fill: "hsl(var(--muted))" }}
                      content={({ active, payload, label }) => {
                        if (!active || !payload?.length) return null;
                        return (
                          <div className="rounded-sm border border-border bg-surface px-3 py-2 shadow-elev-2">
                            <div className="text-body-3 font-medium text-foreground">{label}</div>
                            <div className="mt-1 flex flex-col gap-1">
                              {payload.map((p) => (
                                <div key={String(p.dataKey)} className="flex items-center gap-2 text-caption text-foreground">
                                  <span
                                    className="inline-block h-2 w-2 rounded-sm"
                                    style={{ background: p.color }}
                                  />
                                  <span>{p.name} : {p.value}</span>
                                </div>
                              ))}
                            </div>
                            <div className="mt-2 text-caption text-muted-foreground">Click a segment to drill down</div>
                          </div>
                        );
                      }}
                    />
                    <Legend
                      content={({ payload }) => (
                        <div className="mt-2 flex flex-wrap items-center justify-center gap-4">
                          {payload?.map((entry) => (
                            <div key={String(entry.value)} className="flex items-center gap-2 text-caption text-foreground">
                              <span
                                className="inline-block h-2 w-2 rounded-sm"
                                style={{ background: entry.color }}
                              />
                              <span>{entry.value}</span>
                            </div>
                          ))}
                        </div>
                      )}
                    />
                    {BANDS.map((b, i) => (
                      <Bar
                        key={b}
                        dataKey={b}
                        stackId="risk"
                        fill={`hsl(var(--risk-${b.toLowerCase()}))`}
                        radius={i === BANDS.length - 1 ? [4, 4, 0, 0] : [0, 0, 0, 0]}
                        cursor="pointer"
                        onClick={handleBarClick(b)}
                      >
                        {data.map((d) => (
                          <Cell
                            key={d.status}
                            fillOpacity={isDimmed(d.status, b) ? 0.3 : 1}
                          />
                        ))}
                      </Bar>
                    ))}
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
      </DdsCol>

      {selected && (
        <DdsCol span={12}>
          <Card className="border-border bg-surface shadow-elev-1">
            <CardHeader className="flex flex-row items-center justify-between gap-4 space-y-0">
              <div className="flex flex-wrap items-center gap-2">
                <CardTitle className="text-h6 text-foreground">{selected.status}</CardTitle>
                <Badge className={`rounded-full font-medium border-transparent ${bandClass(selected.band)}`}>
                  {selected.band} risk
                </Badge>
                <span className="text-body-3 text-muted-foreground">
                  {matching.length} {matching.length === 1 ? "NUDD" : "NUDDs"}
                </span>
              </div>
              <Button variant="ghost" size="sm" onClick={() => setSelected(null)} className="gap-1">
                <X className="h-4 w-4" /> Clear
              </Button>
            </CardHeader>
            <CardContent>
              {matching.length === 0 ? (
                <p className="text-body-3 text-muted-foreground">No NUDDs in this segment.</p>
              ) : (
                <ul className="divide-y divide-border">
                  {matching.map((row) => {
                    const risk = row.impact * row.probability;
                    return (
                      <li key={row.id} className="flex items-start justify-between gap-4 py-3">
                        <div className="min-w-0">
                          <div className="flex items-center gap-2">
                            <span className="text-body-3 font-medium text-foreground tabular-nums">{row.id}</span>
                            <span className="text-body-3 text-foreground truncate">{row.title}</span>
                          </div>
                          <div className="mt-1 flex flex-wrap items-center gap-2 text-caption text-muted-foreground">
                            <span>{row.platform}</span>
                            <span aria-hidden>·</span>
                            <span>{row.lob}</span>
                            <span aria-hidden>·</span>
                            <span className="tabular-nums">Risk {risk}</span>
                          </div>
                        </div>
                        <Button variant="outline" size="sm" onClick={() => onOpenRow(row)}>
                          View details
                        </Button>
                      </li>
                    );
                  })}
                </ul>
              )}
            </CardContent>
          </Card>
        </DdsCol>
      )}

      {kpiMode === "unresolved" && (
        <DdsCol span={12}>
          <Card className="border-border bg-surface shadow-elev-1">
            <CardHeader className="flex flex-row items-center justify-between gap-4 space-y-0">
              <div className="flex flex-wrap items-center gap-2">
                <CardTitle className="text-h6 text-foreground">Unresolved NUDDs</CardTitle>
                <span className="text-body-3 text-muted-foreground">
                  {unresolvedCount} {unresolvedCount === 1 ? "NUDD" : "NUDDs"}
                </span>
              </div>
              <Button variant="ghost" size="sm" onClick={() => setKpiMode(null)} className="gap-1">
                <X className="h-4 w-4" /> Clear
              </Button>
            </CardHeader>
            <CardContent>
              <ul className="divide-y divide-border">
                {unresolved.map((row) => {
                  const risk = row.impact * row.probability;
                  const b = band(risk);
                  return (
                    <li key={row.id} className="flex items-start justify-between gap-4 py-3">
                      <div className="min-w-0">
                        <div className="flex items-center gap-2">
                          <span className="text-body-3 font-medium text-foreground tabular-nums">{row.id}</span>
                          <span className="text-body-3 text-foreground truncate">{row.title}</span>
                        </div>
                        <div className="mt-1 flex flex-wrap items-center gap-2 text-caption text-muted-foreground">
                          <span>{row.platform}</span>
                          <span aria-hidden>·</span>
                          <span>{row.lob}</span>
                          <span aria-hidden>·</span>
                          <span className="tabular-nums">Risk {risk}</span>
                          <Badge className={`rounded-full font-medium border-transparent ${bandClass(b)}`}>{b}</Badge>
                        </div>
                      </div>
                      <Button variant="outline" size="sm" onClick={() => onOpenRow(row)}>
                        View details
                      </Button>
                    </li>
                  );
                })}
              </ul>
            </CardContent>
          </Card>
        </DdsCol>
      )}

      {kpiMode === "platforms" && (
        <DdsCol span={12}>
          <Card className="border-border bg-surface shadow-elev-1">
            <CardHeader className="flex flex-row items-center justify-between gap-4 space-y-0">
              <div className="flex flex-wrap items-center gap-2">
                <CardTitle className="text-h6 text-foreground">Impacted platforms</CardTitle>
                <span className="text-body-3 text-muted-foreground">
                  {platformGroups.length} {platformGroups.length === 1 ? "platform" : "platforms"}
                </span>
              </div>
              <Button variant="ghost" size="sm" onClick={() => setKpiMode(null)} className="gap-1">
                <X className="h-4 w-4" /> Clear
              </Button>
            </CardHeader>
            <CardContent>
              <ul className="divide-y divide-border">
                {platformGroups.map((g) => (
                  <li key={g.platform} className="flex items-start justify-between gap-4 py-3">
                    <div className="min-w-0">
                      <div className="text-body-3 font-medium text-foreground truncate">{g.platform}</div>
                      <div className="mt-1 text-caption text-muted-foreground">
                        {g.count} unresolved {g.count === 1 ? "NUDD" : "NUDDs"}
                      </div>
                    </div>
                    <Button
                      variant="outline"
                      size="sm"
                      disabled={!g.launchId}
                      title={g.launchId ? undefined : "Not tracked as a launch"}
                      onClick={() =>
                        g.launchId &&
                        navigate(`/tasks?tab=platform&launch=${g.launchId}&inner=nudds`)
                      }
                      className="gap-1"
                    >
                      View in My tasks <ArrowRight className="h-4 w-4" />
                    </Button>
                  </li>
                ))}
              </ul>
            </CardContent>
          </Card>
        </DdsCol>
      )}
    </DdsGrid>
  );
}
