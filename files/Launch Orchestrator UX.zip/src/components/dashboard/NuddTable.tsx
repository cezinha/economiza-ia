import { Card, CardContent } from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import { type NuddRow, type Score } from "@/mocks/nudds";
import { useFilteredNudds } from "@/lib/applyFilters";

const stickyId = "sticky left-0 z-10 bg-surface border-r border-border";
const stickyIdHeader = cn(stickyId, "z-20");

function scoreLabel(n: Score) {
  return n === 1 ? "Low" : n === 2 ? "Medium" : "High";
}

function riskBand(n: number): "Low" | "Medium" | "High" {
  if (n <= 2) return "Low";
  if (n <= 5) return "Medium";
  return "High";
}

type Props = {
  onOpenRow: (row: NuddRow) => void;
};

export function NuddTable({ onOpenRow }: Props) {
  const NUDDS = useFilteredNudds();
  return (
    <>
      <Card className="border-border bg-surface shadow-elev-1 overflow-hidden">
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className={cn(stickyIdHeader, "min-w-[160px]")}>ID</TableHead>
                  <TableHead>Impacted LOB</TableHead>
                  <TableHead>Impacted platform</TableHead>
                  <TableHead>Impact score</TableHead>
                  <TableHead>Probability score</TableHead>
                  <TableHead>Risk score</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Date created</TableHead>
                  <TableHead>Last updated</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {NUDDS.map((row) => {
                  const risk = row.impact * row.probability;
                  const band = riskBand(risk);
                  return (
                    <TableRow key={row.id}>
                      <TableCell className={cn(stickyId, "align-top")}>
                        <div className="flex flex-col">
                          <span className="font-medium tabular-nums text-foreground">{row.id}</span>
                          <button
                            type="button"
                            onClick={() => onOpenRow(row)}
                            className="text-caption text-primary hover:underline text-left mt-1 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring rounded-sm"
                          >
                            View details
                          </button>
                        </div>
                      </TableCell>
                      <TableCell>{row.lob}</TableCell>
                      <TableCell>{row.platform}</TableCell>
                      <TableCell className="tabular-nums">
                        {row.impact} · {scoreLabel(row.impact)}
                      </TableCell>
                      <TableCell className="tabular-nums">
                        {row.probability} · {scoreLabel(row.probability)}
                      </TableCell>
                      <TableCell>
                        <Badge className={`rounded-full font-medium tabular-nums border-transparent ${band === "High" ? "bg-risk-high text-risk-high-foreground hover:bg-risk-high" : band === "Medium" ? "bg-risk-medium text-risk-medium-foreground hover:bg-risk-medium" : "bg-risk-low text-risk-low-foreground hover:bg-risk-low"}`}>
                          {risk} · {band}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline" className="rounded-full font-medium">
                          {row.status}
                        </Badge>
                      </TableCell>
                      <TableCell className="tabular-nums text-muted-foreground">{row.created}</TableCell>
                      <TableCell className="tabular-nums text-muted-foreground">{row.updated}</TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </>
  );
}
