import { useMemo } from "react";
import { Link } from "react-router-dom";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ArrowUpRight } from "lucide-react";
import type { Launch } from "@/mocks/launches";
import { phasesForLaunch, pctBetween, type ScheduleTrack } from "@/lib/schedule";
import {
  functionStatus,
  phaseCompletionPct,
  tasksForLaunch,
  groupTasksByPhaseAndGate,
  taskStatus,
  worstActive,
  type TaskStatus,
} from "@/lib/launchTasks";
import { KEY_MILESTONES, milestoneDate } from "@/lib/keyMilestones";
import { cn } from "@/lib/utils";

interface PhaseExitTrackerProps {
  launch: Launch;
}

const TRACKS: ScheduleTrack[] = ["SchM", "GOE", "NPI"];

const STATUS_CLASS: Record<TaskStatus, string> = {
  completed: "bg-status-completed",
  "on-track": "bg-status-on-track",
  "at-risk-mitigated": "bg-status-at-risk-mitigated",
  "at-risk": "bg-status-at-risk",
  "not-started": "bg-status-not-started",
};

const STATUS_LABEL: Record<TaskStatus, string> = {
  completed: "Completed",
  "on-track": "On track",
  "at-risk-mitigated": "At risk · mitigation plan",
  "at-risk": "At risk · no mitigation",
  "not-started": "Not started",
};

// R > Y > G > Not started > Completed
const STATUS_SORT_RANK: Record<TaskStatus, number> = {
  "at-risk": 0,
  "at-risk-mitigated": 1,
  "on-track": 2,
  "not-started": 3,
  completed: 4,
};

function rollupGateStatus(launch: Launch, tasks: ReturnType<typeof tasksForLaunch>): TaskStatus {
  const all = tasks.flatMap((t) => t.teams.map((tm) => taskStatus(launch, t, tm)));
  if (all.length === 0) return "not-started";
  if (all.every((s) => s === "completed")) return "completed";
  if (all.every((s) => s === "not-started")) return "not-started";
  const active = all.filter((s) => s !== "completed" && s !== "not-started");
  return active.length > 0 ? worstActive(active) : "on-track";
}

function fmtDate(d: Date): string {
  return d.toLocaleDateString(undefined, { month: "short", day: "numeric", year: "numeric" });
}
function daysBetween(a: Date, b: Date): number {
  return Math.round((b.getTime() - a.getTime()) / (1000 * 60 * 60 * 24));
}

export function PhaseExitTracker({ launch }: PhaseExitTrackerProps) {
  const today = new Date();

  const { phaseSpan, track } = useMemo(() => {
    for (const tr of TRACKS) {
      const spans = phasesForLaunch(launch, tr);
      const span = spans.find((p) => p.name === launch.phase);
      if (span) return { phaseSpan: span, track: tr };
    }
    const spans = phasesForLaunch(launch, "SchM");
    return { phaseSpan: spans[0], track: "SchM" as ScheduleTrack };
  }, [launch]);

  if (!phaseSpan) return null;

  const totalDays = daysBetween(phaseSpan.start, phaseSpan.end);
  const todayPct = pctBetween(today, phaseSpan.start, phaseSpan.end);
  const todayWithin = today >= phaseSpan.start && today <= phaseSpan.end;

  const fnStatus = functionStatus(launch, track);
  const pct = phaseCompletionPct(launch, track, phaseSpan.name, today);

  // Real key milestones inside this phase span — sorted most-future → most-past.
  const phaseMilestones = KEY_MILESTONES
    .map((m) => ({ ...m, date: milestoneDate(launch.launchDate, m.offsetDays) }))
    .filter((m) => m.date >= phaseSpan.start && m.date <= phaseSpan.end)
    .sort((a, b) => b.date.getTime() - a.date.getTime());

  // Real exit criteria pulled from the task list — gates within the current phase.
  const launchTasks = tasksForLaunch(launch);
  const grouped = groupTasksByPhaseAndGate(launchTasks);
  const phaseGroup = grouped.find((p) => p.phase === phaseSpan.name);
  const criteria = (phaseGroup?.gates ?? [])
    .map((g) => ({
      gate: g.gate,
      count: g.tasks.length,
      status: rollupGateStatus(launch, g.tasks),
    }))
    .sort((a, b) => STATUS_SORT_RANK[a.status] - STATUS_SORT_RANK[b.status]);

  return (
    <section className="space-y-6">
      <div className="flex items-baseline justify-between gap-4 flex-wrap">
        <h2 className="text-h4 text-foreground">Phase exit tracker</h2>
        <span className="text-caption text-muted-foreground">
          {launch.name} · Current phase:{" "}
          <span className="font-medium text-foreground">{phaseSpan.name}</span> ·{" "}
          {track} track
        </span>
      </div>

      {/* Gantt zoom of current phase — matches OLP schedule visual language */}
      <Card className="border-border bg-surface shadow-elev-1">
        <CardHeader className="pb-3">
          <CardTitle className="text-h6 text-foreground">
            {phaseSpan.name} phase timeline
          </CardTitle>
          <p className="text-caption text-muted-foreground tabular-nums">
            {fmtDate(phaseSpan.start)} → {fmtDate(phaseSpan.end)} · {totalDays} days
          </p>
        </CardHeader>
        <CardContent>
          <div className="relative pt-10 pb-12">
            {phaseMilestones.map((m) => {
              const pctLeft = pctBetween(m.date, phaseSpan.start, phaseSpan.end);
              const iso = m.date.toISOString().slice(0, 10);
              return (
                <div
                  key={m.key}
                  className="absolute top-0 -translate-x-1/2 flex flex-col items-center gap-1"
                  style={{ left: `${pctLeft}%` }}
                  title={`${m.fullName} · ${iso}`}
                >
                  <span className="text-caption text-muted-foreground tabular-nums whitespace-nowrap leading-tight">
                    {m.label}
                  </span>
                  <span
                    className={cn(
                      "inline-block h-2 w-2 rotate-45",
                      m.isPhaseExit ? "bg-milestone-phase-exit" : "bg-milestone-key",
                    )}
                    aria-hidden
                  />
                </div>
              );
            })}

            <div className="relative h-5 rounded-sm bg-muted overflow-hidden">
              <div
                className={cn(
                  "absolute inset-0 flex items-center justify-center px-2",
                  STATUS_CLASS[fnStatus],
                )}
                title={`${track} · ${phaseSpan.name}: ${phaseSpan.start
                  .toISOString()
                  .slice(0, 10)} → ${phaseSpan.end.toISOString().slice(0, 10)}`}
              >
                <span className="text-caption font-medium text-primary-foreground truncate">
                  {phaseSpan.name} · {pct}%
                </span>
              </div>
            </div>

            {todayWithin && (
              <>
                <div
                  className="absolute top-8 bottom-6 w-0 border-l-2 border-dashed border-primary pointer-events-none"
                  style={{ left: `${todayPct}%` }}
                  aria-hidden
                />
                <div
                  className="absolute -translate-x-1/2 rounded-full bg-primary px-2 py-1 text-caption font-medium text-primary-foreground tabular-nums whitespace-nowrap shadow-elev-1"
                  style={{ left: `${todayPct}%`, bottom: 0 }}
                  aria-label="Today"
                >
                  Today · {today.toLocaleString("en", { month: "short", day: "numeric" })}
                </div>
              </>
            )}
          </div>
        </CardContent>
      </Card>

      <div className="grid gap-6 m:grid-cols-2">
        <Card className="border-border bg-surface shadow-elev-1">
          <CardHeader>
            <CardTitle className="text-h6 text-foreground">
              Key milestones for current phase
            </CardTitle>
          </CardHeader>
          <CardContent>
            {phaseMilestones.length === 0 ? (
              <p className="text-caption text-muted-foreground italic">
                No key milestones fall inside this phase.
              </p>
            ) : (
              <ul className="space-y-3">
                {phaseMilestones.map((m) => {
                  const delta = daysBetween(today, m.date);
                  const past = delta < 0;
                  const label =
                    delta === 0
                      ? "Today"
                      : past
                        ? `${Math.abs(delta)}d ago`
                        : `in ${delta}d`;
                  return (
                    <li
                      key={m.key}
                      className="flex items-center justify-between gap-3 border-b border-border last:border-0 pb-3 last:pb-0"
                    >
                      <div className="flex items-center gap-3 min-w-0">
                        <span
                          className={cn(
                            "inline-block h-2 w-2 rotate-45 shrink-0",
                            m.isPhaseExit ? "bg-milestone-phase-exit" : "bg-milestone-key",
                          )}
                          aria-hidden
                        />
                        <div className="min-w-0">
                          <p className="text-body-3 text-foreground truncate">
                            {m.fullName}{" "}
                            <span className="text-caption text-muted-foreground">({m.label})</span>
                          </p>
                          <p className="text-caption text-muted-foreground tabular-nums">
                            {fmtDate(m.date)}
                          </p>
                        </div>
                      </div>
                      <span className="text-caption text-muted-foreground tabular-nums shrink-0">
                        {label}
                      </span>
                    </li>
                  );
                })}
              </ul>
            )}
          </CardContent>
        </Card>

        <Card className="border-border bg-surface shadow-elev-1">
          <CardHeader>
            <CardTitle className="text-h6 text-foreground">
              Phase gate exit criteria
            </CardTitle>
            <p className="text-caption text-muted-foreground">
              Required to exit the {phaseSpan.name} phase
            </p>
          </CardHeader>
          <CardContent>
            {criteria.length === 0 ? (
              <p className="text-caption text-muted-foreground italic">
                No exit criteria defined for this phase.
              </p>
            ) : (
              <ul className="space-y-3">
                {criteria.map((c) => {
                  const href =
                    `/tasks?tab=platform&launch=${launch.id}&inner=tasks` +
                    `&phase=${encodeURIComponent(phaseSpan.name)}` +
                    `&gate=${encodeURIComponent(c.gate)}`;
                  return (
                    <li
                      key={c.gate}
                      className="flex items-start justify-between gap-3 border-b border-border last:border-0 pb-3 last:pb-0"
                    >
                      <Link
                        to={href}
                        className="group flex items-center gap-3 min-w-0 flex-1 rounded-sm hover:bg-muted/40 -mx-1 px-1 py-1 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                        aria-label={`Open ${phaseSpan.name} tasks for: ${c.gate}`}
                      >
                        <span
                          className={cn(
                            "inline-block h-2 w-2 rounded-full shrink-0",
                            STATUS_CLASS[c.status],
                          )}
                          aria-hidden
                        />
                        <p className="text-body-3 text-foreground group-hover:underline min-w-0">
                          {c.gate}
                          <span className="ml-2 text-caption font-normal text-muted-foreground tabular-nums">
                            {c.count}
                          </span>
                        </p>
                        <ArrowUpRight
                          className="h-4 w-4 shrink-0 text-muted-foreground opacity-0 group-hover:opacity-100 group-focus-visible:opacity-100 transition-opacity"
                          aria-hidden
                        />
                      </Link>
                      <Badge
                        variant="outline"
                        className="rounded-full font-medium shrink-0"
                      >
                        {STATUS_LABEL[c.status]}
                      </Badge>
                    </li>
                  );
                })}
              </ul>
            )}
          </CardContent>
        </Card>
      </div>
    </section>
  );
}
