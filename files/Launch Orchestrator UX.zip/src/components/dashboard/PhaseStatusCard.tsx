import { useState } from "react";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { DdsGrid, DdsCol } from "@/components/layout/DdsGrid";
import { launches as ALL_LAUNCHES, type Launch } from "@/mocks/launches";
import { useFilteredLaunches } from "@/lib/applyFilters";
import { useFilters } from "@/contexts/FilterContext";
import { currentPhaseName, functionStatus } from "@/lib/launchTasks";
import { phasesForLaunch, type ScheduleTrack } from "@/lib/schedule";
import { ArrowRight } from "lucide-react";
import { FunctionStatusDrawer } from "@/components/dashboard/drawers/FunctionStatusDrawer";
import {
  Bar,
  BarChart,
  CartesianGrid,
  LabelList,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";

const SERIES = [
  { key: "onTrack", label: "Achieved / on track", color: "hsl(var(--status-on-track))" },
  { key: "atRiskMit", label: "Risk with mitigation", color: "hsl(var(--status-at-risk-mitigated))" },
  { key: "atRisk", label: "Missed / no mitigation plan", color: "hsl(var(--status-at-risk))" },
] as const;

const TRACKS: ScheduleTrack[] = ["GOE", "NPI", "SchM"];
type Selection = "All" | ScheduleTrack;

function buildData(track: ScheduleTrack, launches: Launch[]) {
  const phases = phasesForLaunch(ALL_LAUNCHES[0], track).map((p) => p.name);
  return phases.map((phase) => {
    const row = { phase, onTrack: 0, atRiskMit: 0, atRisk: 0, total: 0 };
    for (const l of launches) {
      if (currentPhaseName(l, track) !== phase) continue;
      const s = functionStatus(l, track);
      if (s === "on-track") row.onTrack += 1;
      else if (s === "at-risk-mitigated") row.atRiskMit += 1;
      else if (s === "at-risk") row.atRisk += 1;
      row.total += 1;
    }
    return row;
  });
}

function TrackChart({ track, launches }: { track: ScheduleTrack; launches: Launch[] }) {
  const data = buildData(track, launches);
  return (
    <div className="h-[280px] w-full">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={data} margin={{ top: 24, right: 16, bottom: 24, left: 0 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
          <XAxis
            dataKey="phase"
            stroke="hsl(var(--muted-foreground))"
            tick={{ fontSize: 12 }}
            tickLine={false}
            axisLine={{ stroke: "hsl(var(--border))" }}
            label={{
              value: "Phase",
              position: "insideBottom",
              offset: -12,
              style: { fill: "hsl(var(--muted-foreground))", fontSize: 12 },
            }}
          />
          <YAxis
            allowDecimals={false}
            stroke="hsl(var(--muted-foreground))"
            tick={{ fontSize: 12 }}
            tickLine={false}
            axisLine={{ stroke: "hsl(var(--border))" }}
            label={{
              value: "Platform count",
              angle: -90,
              position: "insideLeft",
              style: { fill: "hsl(var(--muted-foreground))", fontSize: 12, textAnchor: "middle" },
            }}
          />
          <Tooltip
            cursor={{ fill: "hsl(var(--muted))" }}
            content={({ active, payload, label }) => {
              if (!active || !payload?.length) return null;
              return (
                <div className="rounded-sm border border-border bg-surface px-3 py-2 shadow-elev-2">
                  <div className="text-body-3 font-medium text-foreground">{label}</div>
                  <div className="mt-1 flex flex-col gap-1">
                    {payload.map((p) => (
                      <div
                        key={String(p.dataKey)}
                        className="flex items-center gap-2 text-caption text-foreground"
                      >
                        <span
                          className="inline-block h-2 w-2 rounded-sm"
                          style={{ background: p.color }}
                        />
                        <span>
                          {p.name} : {p.value}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              );
            }}
          />
          {SERIES.map((s, i) => (
            <Bar
              key={s.key}
              dataKey={s.key}
              name={s.label}
              stackId="s"
              fill={s.color}
              radius={i === SERIES.length - 1 ? [4, 4, 0, 0] : [0, 0, 0, 0]}
            >
              {i === SERIES.length - 1 && (
                <LabelList
                  dataKey="total"
                  position="top"
                  style={{ fill: "hsl(var(--foreground))", fontSize: 12 }}
                />
              )}
            </Bar>
          ))}
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}

export function PhaseStatusCard() {
  const { filters } = useFilters();
  const fnFilter = Array.isArray(filters.function) ? (filters.function as string[]) : [];
  const filteredLaunches = useFilteredLaunches();
  const tracksToShow = TRACKS.filter(
    (t) => fnFilter.length === 0 || fnFilter.includes(t),
  );
  const [openTrack, setOpenTrack] = useState<ScheduleTrack | null>(null);

  return (
    <section className="space-y-4">
      <div className="space-y-1">
        <h2 className="text-h5 text-foreground">Status distribution by current phase</h2>
        <p className="text-body-3 text-muted-foreground">
          Total count across active platforms
        </p>
      </div>
      <DdsGrid>
        {tracksToShow.map((t) => (
          <DdsCol key={t} span={4} spanM={2} spanS={6} spanXs={2}>
            <Card className="border-border bg-surface shadow-elev-1 h-full">
              <CardHeader className="pb-2">
                <div className="flex items-center justify-between gap-2">
                  <CardTitle className="text-h6 text-foreground">
                    {t === "SchM" ? "SChM" : t}
                  </CardTitle>
                  <button
                    type="button"
                    onClick={() => setOpenTrack(t)}
                    className="inline-flex items-center gap-1 text-button-2 text-primary hover:underline focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring rounded-sm"
                  >
                    See details
                    <ArrowRight className="h-3 w-3" aria-hidden />
                  </button>
                </div>
              </CardHeader>
              <CardContent>
                <TrackChart track={t} launches={filteredLaunches} />
              </CardContent>
            </Card>
          </DdsCol>
        ))}
      </DdsGrid>
      <div className="flex flex-wrap items-center justify-center gap-4">
        {SERIES.map((s) => (
          <div key={s.key} className="flex items-center gap-2 text-caption text-foreground">
            <span className="inline-block h-2 w-2 rounded-sm" style={{ background: s.color }} />
            <span>{s.label}</span>
          </div>
        ))}
      </div>
      <FunctionStatusDrawer
        open={openTrack !== null}
        onOpenChange={(o) => !o && setOpenTrack(null)}
        track={openTrack ?? undefined}
      />
    </section>
  );
}
