import { useMemo, useState } from "react";
import { Check, ChevronsUpDown } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
} from "@/components/ui/command";
import { useFilteredLaunches } from "@/lib/applyFilters";
import { platformStatus, type TaskStatus } from "@/lib/launchTasks";
import { LaunchTasksPanel } from "@/components/dashboard/LaunchTasksPanel";
import { cn } from "@/lib/utils";

const STATUS_CLASS: Record<TaskStatus, string> = {
  completed: "bg-status-completed",
  "on-track": "bg-status-on-track",
  "at-risk-mitigated": "bg-status-at-risk-mitigated",
  "at-risk": "bg-status-at-risk",
  "not-started": "bg-status-not-started",
};

interface PlatformTasksProps {
  launchId?: string;
  onChange: (launchId: string) => void;
  initialInnerTab?: "tasks" | "exit" | "nudds";
  initialPhase?: string;
  initialGate?: string;
}

export function PlatformTasks({ launchId, onChange, initialInnerTab, initialPhase, initialGate }: PlatformTasksProps) {
  const [open, setOpen] = useState(false);
  const launches = useFilteredLaunches();

  const sorted = useMemo(
    () =>
      [...launches].sort((a, b) => {
        const rank = (s: TaskStatus) =>
          s === "at-risk" ? 0 : s === "at-risk-mitigated" ? 1 : 2;
        const r = rank(platformStatus(a)) - rank(platformStatus(b));
        if (r !== 0) return r;
        return a.launchDate.localeCompare(b.launchDate);
      }),
    [launches],
  );

  const selected = sorted.find((l) => l.id === launchId) ?? sorted[0];

  if (!selected) {
    return (
      <p className="text-caption text-muted-foreground italic">
        No platforms available.
      </p>
    );
  }

  const renderRow = (l: typeof selected) => (
    <span className="flex items-center gap-2 min-w-0">
      <span
        className={cn(
          "inline-block h-2 w-2 rounded-full shrink-0",
          STATUS_CLASS[platformStatus(l)],
        )}
        aria-hidden
      />
      <span className="truncate">{l.name}</span>
      <span className="text-caption text-muted-foreground truncate">
        · {l.lob} · RTS {l.launchDate}
      </span>
    </span>
  );

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3 flex-wrap">
        <span className="text-caption text-muted-foreground">Platform</span>
        <Popover open={open} onOpenChange={setOpen}>
          <PopoverTrigger asChild>
            <Button
              variant="outline"
              role="combobox"
              aria-expanded={open}
              className="w-[360px] max-w-full justify-between font-normal"
            >
              {renderRow(selected)}
              <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
            </Button>
          </PopoverTrigger>
          <PopoverContent
            className="p-0 shadow-elev-2"
            style={{ width: "var(--radix-popover-trigger-width)" }}
            align="start"
            side="bottom"
            sideOffset={4}
            avoidCollisions={false}
          >
            <Command>
              <CommandInput placeholder="Search platforms…" />
              <CommandList>
                <CommandEmpty>No platforms match.</CommandEmpty>
                <CommandGroup>
                  {sorted.map((l) => (
                    <CommandItem
                      key={l.id}
                      value={l.name}
                      onSelect={() => {
                        onChange(l.id);
                        setOpen(false);
                      }}
                    >
                      <Check
                        className={cn(
                          "mr-2 h-4 w-4 shrink-0",
                          l.id === selected.id ? "opacity-100" : "opacity-0",
                        )}
                      />
                      {renderRow(l)}
                    </CommandItem>
                  ))}
                </CommandGroup>
              </CommandList>
            </Command>
          </PopoverContent>
        </Popover>
      </div>
      <LaunchTasksPanel launch={selected} initialTab={initialInnerTab} initialPhase={initialPhase} initialGate={initialGate} />
    </div>
  );
}
