import { useState } from "react";
import { KpiCard } from "@/components/dashboard/KpiCard";
import { DdsGrid, DdsCol } from "@/components/layout/DdsGrid";
import { useFilteredLaunches, useFilteredNudds } from "@/lib/applyFilters";
import { useFilters } from "@/contexts/FilterContext";
import {
  platformStatus,
  taskStatus,
  tasksForLaunch,
  isAutoTask,
  type TaskStatus,
} from "@/lib/launchTasks";
import type { ScheduleTrack } from "@/lib/schedule";
import {
  ListTodo,
  CheckCircle2,
  AlertTriangle,
  OctagonAlert,
  ShieldAlert,
  PenLine,
} from "lucide-react";
import { UpcomingTasksDrawer } from "@/components/dashboard/drawers/UpcomingTasksDrawer";
import { PlatformStatusListDrawer } from "@/components/dashboard/drawers/PlatformStatusListDrawer";
import { UnresolvedNuddsDrawer } from "@/components/dashboard/drawers/UnresolvedNuddsDrawer";
import { UnresolvedDesignIssuesDrawer } from "@/components/dashboard/drawers/UnresolvedDesignIssuesDrawer";

const TRACKS: ScheduleTrack[] = ["GOE", "NPI", "SchM"];

function pct(n: number, total: number) {
  if (total === 0) return "0%";
  return `${Math.round((n / total) * 100)}%`;
}

type DrawerKey =
  | "upcoming"
  | "on-track"
  | "at-risk-mitigated"
  | "at-risk"
  | "nudds"
  | "design"
  | null;

export function PortfolioMetrics({ layout = "grid" }: { layout?: "grid" | "rail" } = {}) {
  const launches = useFilteredLaunches();
  const NUDDS = useFilteredNudds();
  const { filters } = useFilters();
  const [drawer, setDrawer] = useState<DrawerKey>(null);
  const fnFilter = Array.isArray(filters.function) ? (filters.function as string[]) : [];
  const activeTracks: ScheduleTrack[] = TRACKS.filter(
    (t) => fnFilter.length === 0 || fnFilter.includes(t),
  );

  // Tasks: count active tasks across all launches/tracks; flag at-risk count
  let totalTasks = 0;
  let atRiskTasks = 0;
  for (const l of launches) {
    const lt = tasksForLaunch(l);
    for (const t of lt) {
      if (isAutoTask(t)) continue;
      for (const track of activeTracks) {
        if (!t.teams.includes(track)) continue;
        const s: TaskStatus = taskStatus(l, t, track);
        if (s === "completed" || s === "not-started") continue;
        totalTasks += 1;
        if (s === "at-risk" || s === "at-risk-mitigated") atRiskTasks += 1;
      }
    }
  }

  const total = launches.length;
  const onTrack = launches.filter((l) => platformStatus(l) === "on-track").length;
  const mit = launches.filter((l) => platformStatus(l) === "at-risk-mitigated").length;
  const risk = launches.filter((l) => platformStatus(l) === "at-risk").length;

  const totalNudds = NUDDS.length;
  const unresolvedNudds = NUDDS.filter((n) => n.status !== "Completed").length;

  const span = layout === "rail" ? 12 : 4;
  const spanM = layout === "rail" ? 3 : 2;
  const spanS = layout === "rail" ? 3 : 3;

  return (
    <>
      <DdsGrid>
        <DdsCol span={span} spanM={spanM} spanS={spanS} spanXs={2}>
          <KpiCard
            label="Upcoming tasks"
            value={`${totalTasks} (${atRiskTasks} at risk)`}
            icon={ListTodo}
            onSeeDetails={() => setDrawer("upcoming")}
          />
        </DdsCol>
        <DdsCol span={span} spanM={spanM} spanS={spanS} spanXs={2}>
          <KpiCard
            label="Achieved / on track"
            value={`${onTrack} (${pct(onTrack, total)})`}
            icon={CheckCircle2}
            tone="success"
            onSeeDetails={() => setDrawer("on-track")}
          />
        </DdsCol>
        <DdsCol span={span} spanM={spanM} spanS={spanS} spanXs={2}>
          <KpiCard
            label="At risk with mitigation"
            value={`${mit} (${pct(mit, total)})`}
            icon={AlertTriangle}
            tone="warning"
            onSeeDetails={() => setDrawer("at-risk-mitigated")}
          />
        </DdsCol>
        <DdsCol span={span} spanM={spanM} spanS={spanS} spanXs={2}>
          <KpiCard
            label="At risk no mitigation"
            value={`${risk} (${pct(risk, total)})`}
            icon={OctagonAlert}
            tone="danger"
            onSeeDetails={() => setDrawer("at-risk")}
          />
        </DdsCol>
        <DdsCol span={span} spanM={spanM} spanS={spanS} spanXs={2}>
          <KpiCard
            label="Unresolved NUDDs"
            value={`${unresolvedNudds} (${pct(unresolvedNudds, totalNudds)})`}
            icon={ShieldAlert}
            tone="warning"
            onSeeDetails={() => setDrawer("nudds")}
          />
        </DdsCol>
        <DdsCol span={span} spanM={spanM} spanS={spanS} spanXs={2}>
          <KpiCard
            label="Unresolved design issues"
            value="—"
            icon={PenLine}
            onSeeDetails={() => setDrawer("design")}
          />
        </DdsCol>
      </DdsGrid>

      <UpcomingTasksDrawer
        open={drawer === "upcoming"}
        onOpenChange={(o) => setDrawer(o ? "upcoming" : null)}
      />
      <PlatformStatusListDrawer
        open={drawer === "on-track"}
        onOpenChange={(o) => setDrawer(o ? "on-track" : null)}
        status="on-track"
        eyebrow="Achieved / on track"
        title="Platforms on track"
      />
      <PlatformStatusListDrawer
        open={drawer === "at-risk-mitigated"}
        onOpenChange={(o) => setDrawer(o ? "at-risk-mitigated" : null)}
        status="at-risk-mitigated"
        eyebrow="At risk · with mitigation"
        title="Platforms at risk with mitigation"
      />
      <PlatformStatusListDrawer
        open={drawer === "at-risk"}
        onOpenChange={(o) => setDrawer(o ? "at-risk" : null)}
        status="at-risk"
        eyebrow="At risk · no mitigation"
        title="Platforms at risk with no mitigation"
      />
      <UnresolvedNuddsDrawer
        open={drawer === "nudds"}
        onOpenChange={(o) => setDrawer(o ? "nudds" : null)}
      />
      <UnresolvedDesignIssuesDrawer
        open={drawer === "design"}
        onOpenChange={(o) => setDrawer(o ? "design" : null)}
      />
    </>
  );
}
