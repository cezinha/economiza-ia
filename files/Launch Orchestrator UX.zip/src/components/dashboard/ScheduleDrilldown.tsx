import { Fragment, useLayoutEffect, useMemo, useRef, useState } from "react";
import { Link } from "react-router-dom";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ChevronRight, Crosshair } from "lucide-react";
import { useFilteredLaunches } from "@/lib/applyFilters";
import { useFilters } from "@/contexts/FilterContext";
import { phasesForLaunch, pctBetween, type ScheduleTrack } from "@/lib/schedule";
import { functionStatus, platformStatus, phaseCompletionPct, type TaskFunction, type TaskStatus } from "@/lib/launchTasks";
import { KEY_MILESTONES, milestoneDate } from "@/lib/keyMilestones";
import { cn } from "@/lib/utils";

type TaskFilter = "all" | TaskFunction;
/** Display label for a function/track. Internal id stays "SchM" (mocks). */
const trackLabel = (t: TaskFunction | ScheduleTrack): string =>
  t === "SchM" ? "SChM" : t;
const FILTERS: { value: TaskFilter; label: string }[] = [
  { value: "all", label: "All" },
  { value: "GOE", label: "GOE" },
  { value: "NPI", label: "NPI" },
  { value: "SchM", label: trackLabel("SchM") },
];

const TRACKS: ScheduleTrack[] = ["GOE", "NPI", "SchM"];
const PX_PER_MONTH = 96;
const PLATFORM_COL_WIDTH = 200;



// Determine the current phase per track from today's date (each track has its own
// timeline, so the "current" phase can differ between GOE/NPI and SchM).
function currentPhaseIndexFromDate(
  phases: { start: Date; end: Date }[],
  today: Date,
): number {
  const t = today.getTime();
  for (let i = 0; i < phases.length; i++) {
    if (t >= phases[i].start.getTime() && t < phases[i].end.getTime()) return i;
  }
  // Before first phase → first; after last phase → last.
  if (phases.length === 0) return 0;
  if (t < phases[0].start.getTime()) return 0;
  return phases.length - 1;
}

const STATUS_CLASS: Record<TaskStatus, string> = {
  completed: "bg-status-completed",
  "on-track": "bg-status-on-track",
  "at-risk-mitigated": "bg-status-at-risk-mitigated",
  "at-risk": "bg-status-at-risk",
  "not-started": "bg-status-not-started",
};

function StatusDot({ status, className }: { status: TaskStatus; className?: string }) {
  return (
    <span
      className={cn("inline-block h-2 w-2 rounded-full shrink-0", STATUS_CLASS[status], className)}
      aria-hidden
    />
  );
}

function phaseStatusClass(idx: number, currentIdx: number, currentStatus: TaskStatus): string {
  if (idx < currentIdx) return STATUS_CLASS.completed;
  if (idx === currentIdx) return STATUS_CLASS[currentStatus];
  return STATUS_CLASS["not-started"];
}

function startOfMonth(d: Date) {
  return new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), 1));
}
function addMonths(d: Date, n: number) {
  return new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth() + n, 1));
}

export function ScheduleDrilldown() {
  const launches = useFilteredLaunches();
  const { filters } = useFilters();
  const fnFilter = Array.isArray(filters.function) ? (filters.function as string[]) : [];
  const activeTracks: ScheduleTrack[] = TRACKS.filter(
    (t) => fnFilter.length === 0 || fnFilter.includes(t),
  );
  // Full extent across every platform & track
  const { start, end, ticks, totalWidth } = useMemo(() => {
    let min = Infinity;
    let max = -Infinity;
    for (const l of launches) {
      for (const track of activeTracks) {
        for (const p of phasesForLaunch(l, track)) {
          if (p.start.getTime() < min) min = p.start.getTime();
          if (p.end.getTime() > max) max = p.end.getTime();
        }
      }
    }
    if (launches.length === 0) {
      const now = new Date();
      const s = startOfMonth(now);
      return { start: s, end: addMonths(s, 1), ticks: [s, addMonths(s, 1)], totalWidth: PX_PER_MONTH };
    }
    const start = startOfMonth(new Date(min));
    const end = startOfMonth(addMonths(new Date(max), 1));
    const ticks: Date[] = [];
    const cur = new Date(start.getTime());
    while (cur <= end) {
      ticks.push(new Date(cur.getTime()));
      cur.setUTCMonth(cur.getUTCMonth() + 1);
    }
    const totalWidth = (ticks.length - 1) * PX_PER_MONTH;
    return { start, end, ticks, totalWidth };
  }, [launches, activeTracks]);

  const today = new Date();
  const todayPct = pctBetween(today, start, end);

  // Pin platform column via inner scroll
  const scrollerRef = useRef<HTMLDivElement>(null);
  const [scrollReady, setScrollReady] = useState(false);

  const centeredScrollLeft = (el: HTMLDivElement) => {
    const todayPx = (todayPct / 100) * totalWidth;
    return Math.max(0, Math.min(totalWidth - el.clientWidth, todayPx - el.clientWidth / 2));
  };

  const scrollToToday = () => {
    const el = scrollerRef.current;
    if (!el) return;
    el.scrollTo({ left: centeredScrollLeft(el), behavior: "smooth" });
  };

  // Track viewport width of the gantt scroller (kept for future use)
  const [, setViewportW] = useState(0);
  useLayoutEffect(() => {
    const el = scrollerRef.current;
    if (!el) return;
    el.scrollLeft = centeredScrollLeft(el);
    setScrollReady(true);
    const update = () => setViewportW(el.clientWidth);
    update();
    const ro = new ResizeObserver(update);
    ro.observe(el);
    return () => ro.disconnect();
  }, [todayPct, totalWidth]);

  return (
    <Card className="border-border bg-surface shadow-elev-1">
      <div className="sticky top-16 z-30 bg-surface border-b border-border">
        <CardHeader className="px-4 pb-4 space-y-0">
          <CardTitle className="text-h4 text-foreground">Cross-platform timeline view</CardTitle>
        </CardHeader>
        <div className="px-4 pb-4 flex flex-wrap items-center justify-between gap-x-4 gap-y-2">
          <div className="flex flex-wrap items-center gap-x-4 gap-y-2">
            {[
              { cls: "bg-status-completed", label: "Completed" },
              { cls: "bg-status-on-track", label: "On track" },
              { cls: "bg-status-at-risk-mitigated", label: "At risk · mitigation plan" },
              { cls: "bg-status-at-risk", label: "At risk · no mitigation" },
              { cls: "bg-status-not-started", label: "Not started" },
            ].map((s) => (
              <span key={s.label} className="inline-flex items-center gap-2 text-caption text-muted-foreground">
                <span className={cn("h-2 w-2 rounded-full", s.cls)} aria-hidden />
                {s.label}
              </span>
            ))}
            <span className="inline-flex items-center gap-2 text-caption text-muted-foreground">
              <span className="h-2 w-2 rotate-45 bg-milestone-phase-exit" aria-hidden />
              Phase exit
            </span>
            <span className="inline-flex items-center gap-2 text-caption text-muted-foreground">
              <span className="h-2 w-2 rotate-45 bg-milestone-key" aria-hidden />
              Other key milestone
            </span>
          </div>
          <Button variant="secondary-dds" size="sm" onClick={scrollToToday} className="shrink-0">
            <Crosshair className="h-4 w-4" aria-hidden /> Today
          </Button>
        </div>
      </div>
      <CardContent className="p-0">
        <div
          ref={scrollerRef}
          className={cn("overflow-x-auto", !scrollReady && "invisible")}
        >
          <div
            className="relative"
            style={{ minWidth: PLATFORM_COL_WIDTH + totalWidth }}
          >
            {/* Header */}
            <div className="grid border-b border-border" style={{ gridTemplateColumns: `${PLATFORM_COL_WIDTH}px 1fr` }}>
              <div className="sticky left-0 z-20 bg-surface px-4 pt-8 pb-3 border-r border-border text-caption text-muted-foreground flex items-end">
                Platform
              </div>
              <div className="relative h-16" style={{ width: totalWidth }}>
                {/* Top row: Today pill (24px tall, with breathing room) */}
                <div className="absolute left-0 right-0 top-2 h-6">
                  <div
                    className="absolute -translate-x-1/2 z-20 rounded-full bg-primary px-2 py-1 text-caption font-medium text-primary-foreground tabular-nums whitespace-nowrap shadow-elev-1 pointer-events-none"
                    style={{ left: `${todayPct}%` }}
                    aria-label="Today"
                  >
                    Today · {today.toLocaleString("en", { month: "short", day: "numeric" })}
                  </div>
                </div>
                {/* Bottom row: month ticks */}
                <div className="absolute left-0 right-0 bottom-0 h-6">
                  {ticks.map((t, i) => {
                    const left = i * PX_PER_MONTH;
                    const monthLabel = t.toLocaleString("en", { month: "short", timeZone: "UTC" });
                    const yearShort = String(t.getUTCFullYear()).slice(-2);
                    return (
                      <div key={i} className="absolute top-0 bottom-0 flex flex-col justify-end pb-1" style={{ left }}>
                        <span className="text-caption text-muted-foreground tabular-nums whitespace-nowrap">
                          {monthLabel} '{yearShort}
                        </span>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>

            {/* Body — sorted R > Y > G, then by RTS date asc */}
            <div>
              {[...launches]
                .sort((a, b) => {
                  const sa = platformStatus(a);
                  const sb = platformStatus(b);
                  const rank = (s: TaskStatus) =>
                    s === "at-risk" ? 0 : s === "at-risk-mitigated" ? 1 : 2;
                  const r = rank(sa) - rank(sb);
                  if (r !== 0) return r;
                  return a.launchDate.localeCompare(b.launchDate);
                })
                .map((launch) => {
                return (
                <div key={launch.id} className="border-b border-border last:border-0">
                  {/* Gantt portion — grid + gridlines + today overlay only span this block */}
                  <div
                    className="relative grid"
                    style={{
                      gridTemplateColumns: `${PLATFORM_COL_WIDTH}px ${totalWidth}px`,
                    }}
                  >
                    {/* Row 1 — platform info (left, link to detail page), filler (right) */}
                    <div
                      className="sticky left-0 z-20 bg-surface px-4 pt-4 pb-2 border-r border-border min-w-0"
                      style={{ gridColumn: 1, gridRow: 1 }}
                    >
                      <div className="min-w-0">
                        <Link
                          to={`/tasks?tab=platform&launch=${launch.id}`}
                          className="group flex items-center gap-2 text-body-3 font-medium text-foreground rounded-sm hover:bg-muted/40 -mx-1 px-1 py-1 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                          aria-label={`View ${launch.name} tasks`}
                        >
                          <StatusDot status={platformStatus(launch)} />
                          <span className="truncate group-hover:underline min-w-0 flex-1" title={launch.name}>
                            {launch.name}
                          </span>
                          <ChevronRight className="h-4 w-4 shrink-0 text-muted-foreground opacity-0 group-hover:opacity-100 group-focus-visible:opacity-100 transition-opacity" />
                        </Link>
                        <span className="block text-caption text-muted-foreground tabular-nums mt-1">
                          {launch.lob} · RTS {launch.launchDate}
                        </span>
                        <Link
                          to={`/tasks?tab=platform&launch=${launch.id}`}
                          className="inline-block text-caption text-primary hover:underline mt-1 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring rounded-sm"
                        >
                          View tasks
                        </Link>
                      </div>
                    </div>
                    <div style={{ gridColumn: 2, gridRow: 1 }} className="pt-4 pb-2" />

                    {/* Milestone strip — union of GOE/NPI/SChM key gates, anchored to RTS */}
                    <div
                      className="sticky left-0 z-20 bg-surface px-4 py-1 border-r border-border flex items-center"
                      style={{ gridColumn: 1, gridRow: 2 }}
                    >
<span className="text-caption text-muted-foreground">
                        Milestones
                      </span>
                    </div>
                    <div
                      className="px-2 py-1 relative z-10"
                      style={{ gridColumn: 2, gridRow: 2 }}
                    >
                      <div className="relative h-7">
                        {KEY_MILESTONES.map((m) => {
                          const date = milestoneDate(launch.launchDate, m.offsetDays);
                          if (date < start || date > end) return null;
                          const left = pctBetween(date, start, end);
                          const iso = date.toISOString().slice(0, 10);
                          return (
                            <div
                              key={m.key}
                              className="absolute top-0 bottom-0 flex flex-col items-center"
                              style={{ left: `${left}%`, transform: "translateX(-50%)" }}
                              title={`${m.fullName} · ${iso}`}
                            >
                              <span className="text-caption leading-tight text-muted-foreground tabular-nums whitespace-nowrap">
                                {m.label}
                              </span>
                              <span
                                className={cn(
                                  "mt-1 inline-block h-2 w-2 rotate-45",
                                  m.isPhaseExit ? "bg-milestone-phase-exit" : "bg-milestone-key",
                                )}
                                aria-hidden
                              />
                            </div>
                          );
                        })}
                      </div>
                    </div>

                    {/* Track rows — labels in pinned col, bars in timeline */}
                    {activeTracks.map((track, ti) => {
                      const phases = phasesForLaunch(launch, track);
                      const currentIdx = currentPhaseIndexFromDate(phases, today);
                      const fnStatus = functionStatus(launch, track);
                      const isLast = ti === activeTracks.length - 1;
                      return (
                        <Fragment key={track}>
                          <div
                            className={cn(
                              "sticky left-0 z-20 bg-surface px-4 border-r border-border flex items-center gap-2",
                              isLast ? "pb-4 pt-1" : "py-1"
                            )}
                            style={{ gridColumn: 1, gridRow: ti + 3 }}
                          >
                            <StatusDot status={fnStatus} />
                            <span className="text-caption text-muted-foreground">
                              {trackLabel(track)}
                            </span>
                          </div>
                          <div
                            className={cn("px-2 relative z-10", isLast ? "pb-4 pt-1" : "py-1")}
                            style={{ gridColumn: 2, gridRow: ti + 3 }}
                          >
                            <div className="relative h-5 rounded-sm bg-muted overflow-hidden">
                              {phases.map((p, i) => {
                                const left = pctBetween(p.start, start, end);
                                const right = pctBetween(p.end, start, end);
                                const width = Math.max(0, right - left);
                                if (width <= 0) return null;
                                return (
                                  <div
                                    key={p.name}
                                    className={cn(
                                      "absolute top-0 bottom-0 flex items-center justify-center px-2 border-r border-surface last:border-r-0",
                                      phaseStatusClass(i, currentIdx, fnStatus)
                                    )}
                                    style={{ left: `${left}%`, width: `${width}%` }}
                                    title={`${track} · ${p.name}: ${p.start.toISOString().slice(0, 10)} → ${p.end.toISOString().slice(0, 10)}`}
                                  >
                                    {width > 3 && (
                                      <span className="text-caption font-medium text-primary-foreground truncate">
                                        {p.name}
                                        {i === currentIdx && ` · ${phaseCompletionPct(launch, track, p.name, today)}%`}
                                      </span>
                                    )}
                                  </div>
                                );
                              })}
                            </div>
                          </div>
                        </Fragment>
                      );
                    })}
                    {/* Gridlines + today marker — overlay scoped to this gantt block only */}
                    <div
                      className="absolute top-0 bottom-0 pointer-events-none z-0"
                      style={{ left: PLATFORM_COL_WIDTH, width: totalWidth }}
                    >
                      {ticks.map((_, i) => (
                        <div
                          key={i}
                          className="absolute top-0 bottom-0 w-px bg-border/60"
                          style={{ left: i * PX_PER_MONTH }}
                        />
                      ))}
                      <div
                        className="absolute top-0 bottom-0 w-0 border-l-2 border-dashed border-primary z-10"
                        style={{ left: `${todayPct}%` }}
                        aria-label="Today"
                      />
                    </div>
                  </div>

                </div>
                );
              })}
            </div>
          </div>
        </div>

      </CardContent>
    </Card>
  );
}

