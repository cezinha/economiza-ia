import { useEffect, useMemo, useRef, useState } from "react";
import { ChevronLeft, File as FileIcon, Flag, Paperclip, X } from "lucide-react";
import { toast } from "sonner";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetDescription,
  SheetClose,
  SheetFooter,
} from "@/components/ui/sheet";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { cn } from "@/lib/utils";
import type { LaunchTask, TaskStatus } from "@/lib/launchTasks";
import { useIsReadOnly } from "@/lib/permissions";
import type { Launch } from "@/mocks/launches";
import {
  getTaskDetails,
  resolveDueDate,
  OWNERS,
  type TaskComment,
  type TaskOwner,
} from "@/mocks/taskDetails";

type Attachment = { id: string; name: string; size: number; type: string; addedAt: string };

const formatBytes = (n: number) => {
  if (n < 1024) return `${n} B`;
  if (n < 1024 * 1024) return `${(n / 1024).toFixed(1)} KB`;
  return `${(n / (1024 * 1024)).toFixed(1)} MB`;
};

const tokenize = (name: string) => name.replace(/\s+/g, "");

const STATUS_LABEL: Record<TaskStatus, string> = {
  completed: "Completed",
  "on-track": "On track",
  "at-risk-mitigated": "At risk (mitigated)",
  "at-risk": "At risk",
  "not-started": "Not started",
};

const STATUS_DOT: Record<TaskStatus, string> = {
  completed: "bg-status-completed",
  "on-track": "bg-status-on-track",
  "at-risk-mitigated": "bg-status-at-risk-mitigated",
  "at-risk": "bg-status-at-risk",
  "not-started": "bg-status-not-started",
};

const STATUS_OPTIONS: TaskStatus[] = [
  "on-track",
  "at-risk-mitigated",
  "at-risk",
];

interface TaskDetailDrawerProps {
  task: LaunchTask | null;
  launch: Launch;
  initialStatus: TaskStatus;
  onOpenChange: (open: boolean) => void;
}

export function TaskDetailDrawer({
  task,
  launch,
  initialStatus,
  onOpenChange,
}: TaskDetailDrawerProps) {
  const readOnly = useIsReadOnly();
  const [status, setStatus] = useState<TaskStatus>(initialStatus);
  const [primary, setPrimary] = useState<TaskOwner | null>(null);
  const [backup, setBackup] = useState<TaskOwner | null>(null);
  const [comments, setComments] = useState<TaskComment[]>([]);
  const [draft, setDraft] = useState("");
  const [flag, setFlag] = useState(false);
  const [reassignOpen, setReassignOpen] = useState(false);
  const [mentions, setMentions] = useState<TaskOwner[]>([]);
  const [mentionQuery, setMentionQuery] = useState<string | null>(null);
  const [mentionIdx, setMentionIdx] = useState(0);
  const [attachments, setAttachments] = useState<Attachment[]>([]);
  const [pendingStatus, setPendingStatus] = useState<TaskStatus | null>(null);
  const [statusForm, setStatusForm] = useState({
    issue: "",
    impact: "",
    mitigation: "",
    owner: "",
  });
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const details = useMemo(
    () => (task ? getTaskDetails(task, launch) : null),
    [task, launch],
  );

  const taskFunctionLabel = useMemo(() => {
    if (!task) return "";
    return task.teams.map((t) => (t === "SchM" ? "SChM" : t)).join(" · ");
  }, [task]);

  useEffect(() => {
    if (!task || !details) return;
    setStatus(initialStatus);
    setPrimary(details.primaryOwner);
    setBackup(details.backupOwner);
    setComments(details.comments);
    setDraft("");
    setFlag(false);
    setMentions([]);
    setMentionQuery(null);
    setAttachments([]);
  }, [task, details, initialStatus]);

  if (!task || !details) return null;

  const dueCalendar = resolveDueDate(launch, task.taskEnd);
  const deltaLabel =
    details.deltaDays === 0
      ? "On time"
      : details.deltaDays > 0
        ? `+${details.deltaDays}d`
        : `${details.deltaDays}d`;
  const deltaTone =
    details.deltaDays === 0
      ? "text-status-on-track"
      : details.deltaDays > 0
        ? "text-status-at-risk"
        : "text-status-completed";

  const filteredMentionOptions = mentionQuery === null
    ? []
    : OWNERS.filter((o) =>
        o.name.toLowerCase().replace(/\s+/g, "").includes(mentionQuery.toLowerCase()),
      ).slice(0, 6);

  const updateDraft = (next: string, caretPos: number) => {
    setDraft(next);
    // Detect active @token immediately before caret
    const before = next.slice(0, caretPos);
    const m = before.match(/(?:^|\s)@([A-Za-z]*)$/);
    if (m) {
      setMentionQuery(m[1]);
      setMentionIdx(0);
    } else {
      setMentionQuery(null);
    }
    // Drop any mentions whose token is no longer in the text
    setMentions((prev) => prev.filter((o) => next.includes(`@${tokenize(o.name)}`)));
  };

  const insertMention = (owner: TaskOwner) => {
    const ta = textareaRef.current;
    const caret = ta?.selectionStart ?? draft.length;
    const before = draft.slice(0, caret);
    const after = draft.slice(caret);
    const replaced = before.replace(/@([A-Za-z]*)$/, `@${tokenize(owner.name)} `);
    const next = replaced + after;
    setDraft(next);
    setMentions((prev) =>
      prev.some((o) => o.name === owner.name) ? prev : [...prev, owner],
    );
    setMentionQuery(null);
    requestAnimationFrame(() => {
      const pos = replaced.length;
      ta?.focus();
      ta?.setSelectionRange(pos, pos);
    });
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (mentionQuery === null || filteredMentionOptions.length === 0) return;
    if (e.key === "ArrowDown") {
      e.preventDefault();
      setMentionIdx((i) => (i + 1) % filteredMentionOptions.length);
    } else if (e.key === "ArrowUp") {
      e.preventDefault();
      setMentionIdx((i) => (i - 1 + filteredMentionOptions.length) % filteredMentionOptions.length);
    } else if (e.key === "Enter" || e.key === "Tab") {
      e.preventDefault();
      insertMention(filteredMentionOptions[mentionIdx]);
    } else if (e.key === "Escape") {
      e.preventDefault();
      setMentionQuery(null);
    }
  };

  const postComment = () => {
    const body = draft.trim();
    if (!body) return;
    const activeMentions = mentions.filter((o) => body.includes(`@${tokenize(o.name)}`));
    setComments((c) => [
      {
        id: `local-${Date.now()}`,
        author: "You",
        initials: "YO",
        timestamp: "Just now",
        body,
        isRiskFlag: flag,
        mentions: activeMentions.map((o) => ({ name: o.name, initials: o.initials })),
      },
      ...c,
    ]);
    if (activeMentions.length > 0) {
      const names = activeMentions.map((o) => `@${o.name}`).join(", ");
      toast.success(
        `Notified ${activeMentions.length} ${activeMentions.length === 1 ? "person" : "people"}: ${names}`,
      );
    }
    setDraft("");
    setFlag(false);
    setMentions([]);
    setMentionQuery(null);
  };

  const renderCommentBody = (c: TaskComment) => {
    if (!c.mentions || c.mentions.length === 0) return c.body;
    const tokens = c.mentions.map((m) => ({ token: tokenize(m.name), name: m.name }));
    const re = new RegExp(`@(${tokens.map((t) => t.token).join("|")})\\b`, "g");
    const parts: React.ReactNode[] = [];
    let last = 0;
    let match: RegExpExecArray | null;
    let key = 0;
    while ((match = re.exec(c.body)) !== null) {
      if (match.index > last) parts.push(c.body.slice(last, match.index));
      const found = tokens.find((t) => t.token === match![1]);
      parts.push(
        <span
          key={key++}
          className="text-primary font-medium bg-primary/10 px-1 rounded"
        >
          @{found?.name ?? match[1]}
        </span>,
      );
      last = match.index + match[0].length;
    }
    if (last < c.body.length) parts.push(c.body.slice(last));
    return parts;
  };

  return (
    <Sheet open={!!task} onOpenChange={onOpenChange}>
      <SheetContent
        side="right"
        aria-label={`Task details: ${task.task}`}
        className="w-[1200px] sm:max-w-[90vw] p-0 flex flex-col gap-0 [&>button]:hidden"
      >
        <div className="px-8 pt-6 pb-4 border-b border-border">
          <SheetClose asChild>
            <button
              type="button"
              className="inline-flex items-center gap-1 text-body-3 text-primary hover:underline focus:outline-none focus-visible:ring-2 focus-visible:ring-ring rounded-sm"
            >
              <ChevronLeft className="h-4 w-4" />
              Back
            </button>
          </SheetClose>
          <SheetHeader className="mt-4 text-left sm:text-left">
            <SheetDescription className="text-caption uppercase tracking-wide">
              {task.phase}
              <span aria-hidden> › </span>
              {task.gate}
            </SheetDescription>
            <SheetTitle className="text-h3 text-foreground flex items-start gap-3">
              <span className="flex-1">{task.task}</span>
              {details?.isAuto && (
                <Badge variant="secondary" className="shrink-0 mt-1">
                  Auto
                </Badge>
              )}
            </SheetTitle>
            <SheetDescription>{launch.name}</SheetDescription>
          </SheetHeader>
        </div>

        <div className="flex-1 overflow-y-auto px-8 py-6 space-y-8">
          {/* At-a-glance */}
          <section className="grid grid-cols-2 l:grid-cols-4 gap-4">
            <Tile label="Status">
              <span className="inline-flex items-center gap-2">
                <span
                  className={cn("inline-block h-2 w-2 rounded-full", STATUS_DOT[status])}
                  aria-hidden
                />
                <span className="text-body-3 text-foreground">{STATUS_LABEL[status]}</span>
              </span>
            </Tile>
            <Tile label="Due date">
              <Badge variant="outline" className="text-caption font-medium">
                {task.taskEnd}
              </Badge>
              <p className="mt-2 text-body-3 text-foreground tabular-nums">{dueCalendar}</p>
            </Tile>
            <Tile label="Suggested min. duration">
              <p className="text-body-3 text-muted-foreground">N/A</p>
            </Tile>
            <Tile label={`Required documents and data sources (${details.requiredDocs.length})`}>
              <ul className="space-y-1">
                {details.requiredDocs.map((d) => (
                  <li
                    key={d}
                    className="flex items-start gap-2 text-body-3 text-foreground"
                  >
                    <Paperclip className="h-3 w-3 mt-1 text-muted-foreground" />
                    <span>{d}</span>
                  </li>
                ))}
              </ul>
            </Tile>
          </section>

          {/* POR vs actual */}
          <section className="space-y-3">
            <h3 className="text-subtitle-2 text-foreground">POR vs actual date</h3>
            <div className="rounded-md border border-border overflow-hidden">
              <div className="grid grid-cols-3 px-4 py-2 border-b border-border bg-muted/30 text-caption text-muted-foreground">
                <span>Series</span>
                <span>Date</span>
                <span>Delta</span>
              </div>
              <div className="grid grid-cols-3 px-4 py-3 border-b border-border text-body-3 text-foreground">
                <span>Plan of record</span>
                <span className="tabular-nums">{details.porDate}</span>
                <span className="text-muted-foreground">—</span>
              </div>
              <div className="grid grid-cols-3 px-4 py-3 text-body-3 text-foreground">
                <span>Actual / forecast</span>
                <span className="tabular-nums">{details.actualDate}</span>
                <span className={cn("tabular-nums", deltaTone)}>{deltaLabel}</span>
              </div>
            </div>
          </section>

          {/* Owners */}
          <section className="space-y-3">
            <h3 className="text-subtitle-2 text-foreground">Owners</h3>
            {details.isAuto ? (
              <p className="text-body-3 text-muted-foreground">
                Automated task — completes automatically at phase start. No owner required.
              </p>
            ) : (
              <>
                <div className="grid grid-cols-1 m:grid-cols-2 gap-4">
                  <OwnerCard label="Primary owner" owner={primary} taskFunction={taskFunctionLabel} />
                  <OwnerCard label="Backup owner" owner={backup} taskFunction={taskFunctionLabel} />
                </div>
                <div className="flex flex-col gap-3">
                  {!readOnly && (
                  <Popover open={reassignOpen} onOpenChange={setReassignOpen}>
                    <PopoverTrigger asChild>
                      <Button variant="outline" size="sm">
                        Reassign owner
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent align="start" className="w-80 p-0">
                      <div className="p-3 border-b border-border">
                        <p className="text-caption text-muted-foreground">
                          Select a new primary owner
                        </p>
                      </div>
                      <ul className="max-h-64 overflow-y-auto py-1">
                        {details.candidateOwners.map((o) => (
                          <li key={o.name}>
                            <button
                              type="button"
                              onClick={() => {
                                if (primary) setBackup(primary);
                                setPrimary(o);
                                setReassignOpen(false);
                              }}
                              className="w-full flex items-center gap-3 px-3 py-2 text-left hover:bg-muted/40 transition-colors"
                            >
                              <Avatar className="h-7 w-7">
                                <AvatarFallback className="text-caption">
                                  {o.initials}
                                </AvatarFallback>
                              </Avatar>
                              <span className="min-w-0">
                                <span className="block text-body-3 text-foreground truncate">
                                  {o.name}
                                </span>
                                <span className="block text-caption text-muted-foreground truncate">
                                  {o.role}
                                </span>
                              </span>
                            </button>
                          </li>
                        ))}
                      </ul>
                    </PopoverContent>
                  </Popover>
                  )}
                  <Accordion type="single" collapsible>
                    <AccordionItem value="history" className="border-border">
                      <AccordionTrigger className="text-body-3 text-muted-foreground hover:no-underline py-2">
                        Assignment history
                      </AccordionTrigger>
                      <AccordionContent>
                        <ul className="space-y-2 pt-2">
                          {details.history.map((h) => (
                            <li
                              key={h.id}
                              className="flex items-start justify-between gap-4 text-body-3"
                            >
                              <span className="text-foreground">
                                Reassigned from <span className="font-medium">{h.from}</span> to{" "}
                                <span className="font-medium">{h.to}</span> by {h.by}
                              </span>
                              <span className="text-caption text-muted-foreground tabular-nums shrink-0">
                                {h.timestamp}
                              </span>
                            </li>
                          ))}
                        </ul>
                      </AccordionContent>
                    </AccordionItem>
                  </Accordion>
                </div>
              </>
            )}
          </section>

          {/* Submission notes (only when completed) */}
          {status === "completed" && (
            <section className="space-y-2">
              <h3 className="text-subtitle-2 text-foreground">Submission notes</h3>
              <p className="text-body-3 text-muted-foreground">{details.submissionNotes}</p>
            </section>
          )}

          {/* Comments & risk flags */}
          <section className="space-y-3">
            <h3 className="text-subtitle-2 text-foreground">Comments & risk flags</h3>
            <ul className="space-y-3">
              {comments.length === 0 && (
                <li className="text-caption text-muted-foreground italic">
                  No comments yet.
                </li>
              )}
              {comments.map((c) => (
                <li
                  key={c.id}
                  className="flex gap-3 p-3 rounded-md border border-border"
                >
                  <Avatar className="h-8 w-8 shrink-0">
                    <AvatarFallback className="text-caption">{c.initials}</AvatarFallback>
                  </Avatar>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="text-body-3 font-medium text-foreground">
                        {c.author}
                      </span>
                      <span className="text-caption text-muted-foreground">
                        {c.timestamp}
                      </span>
                      {c.isRiskFlag && (
                        <Badge
                          variant="outline"
                          className="text-caption gap-1 border-status-at-risk text-status-at-risk"
                        >
                          <Flag className="h-3 w-3" />
                          Risk flag
                        </Badge>
                      )}
                    </div>
                    <p className="mt-1 text-body-3 text-foreground whitespace-pre-wrap">
                      {renderCommentBody(c)}
                    </p>
                    {c.mentions && c.mentions.length > 0 && (
                      <p className="mt-1 text-caption text-muted-foreground">
                        Notified: {c.mentions.map((m) => `@${m.name}`).join(", ")}
                      </p>
                    )}
                  </div>
                </li>
              ))}
            </ul>
            {!readOnly && (
            <div className="space-y-2">
              <div className="relative">
                <Textarea
                  ref={textareaRef}
                  value={draft}
                  onChange={(e) => updateDraft(e.target.value, e.target.selectionStart ?? e.target.value.length)}
                  onKeyDown={handleKeyDown}
                  placeholder="Add a comment… type @ to mention"
                  rows={3}
                />
                {mentionQuery !== null && filteredMentionOptions.length > 0 && (
                  <div className="absolute left-0 right-0 top-full mt-1 z-10 rounded-md border border-border bg-popover shadow-elev-2 max-h-60 overflow-y-auto">
                    <ul>
                      {filteredMentionOptions.map((o, i) => (
                        <li key={o.name}>
                          <button
                            type="button"
                            onMouseDown={(e) => {
                              e.preventDefault();
                              insertMention(o);
                            }}
                            onMouseEnter={() => setMentionIdx(i)}
                            className={cn(
                              "w-full flex items-center gap-3 px-3 py-2 text-left transition-colors",
                              i === mentionIdx ? "bg-muted/60" : "hover:bg-muted/40",
                            )}
                          >
                            <Avatar className="h-7 w-7">
                              <AvatarFallback className="text-caption">{o.initials}</AvatarFallback>
                            </Avatar>
                            <span className="min-w-0">
                              <span className="block text-body-3 text-foreground truncate">{o.name}</span>
                              <span className="block text-caption text-muted-foreground truncate">{o.role}</span>
                            </span>
                          </button>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
              {mentions.length > 0 && (
                <p className="text-caption text-muted-foreground">
                  Will notify: {mentions.map((m) => `@${m.name}`).join(", ")}
                </p>
              )}
              <div className="flex items-center justify-between">
                <label className="inline-flex items-center gap-2 text-caption text-foreground cursor-pointer">
                  <Checkbox
                    checked={flag}
                    onCheckedChange={(v) => setFlag(v === true)}
                  />
                  Flag as risk
                </label>
                <Button size="sm" onClick={postComment} disabled={!draft.trim()}>
                  Post
                </Button>
              </div>
            </div>
            )}
          </section>

          {/* Attachments */}
          <section className="space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-subtitle-2 text-foreground">Attachments</h3>
              {!readOnly && (
                <>
                  <input
                    ref={fileInputRef}
                    type="file"
                    multiple
                    className="hidden"
                    onChange={(e) => {
                      const files = Array.from(e.target.files ?? []);
                      if (files.length === 0) return;
                      const added: Attachment[] = files.map((f) => ({
                        id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
                        name: f.name,
                        size: f.size,
                        type: f.type || "file",
                        addedAt: "Just now",
                      }));
                      setAttachments((a) => [...a, ...added]);
                      toast.success(`Attached ${added.length} file${added.length === 1 ? "" : "s"}`);
                      if (fileInputRef.current) fileInputRef.current.value = "";
                    }}
                  />
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => fileInputRef.current?.click()}
                    className="gap-2"
                  >
                    <Paperclip className="h-4 w-4" />
                    Add file
                  </Button>
                </>
              )}
            </div>
            <ul className="space-y-2">
              {attachments.length === 0 && (
                <li className="text-caption text-muted-foreground italic">
                  No attachments yet.
                </li>
              )}
              {attachments.map((a) => (
                <li
                  key={a.id}
                  className="flex items-center gap-3 p-3 rounded-md border border-border"
                >
                  <FileIcon className="h-5 w-5 shrink-0 text-muted-foreground" />
                  <div className="min-w-0 flex-1">
                    <p className="text-body-3 text-foreground truncate">{a.name}</p>
                    <p className="text-caption text-muted-foreground truncate">
                      {formatBytes(a.size)} · {a.type} · {a.addedAt}
                    </p>
                  </div>
                  {!readOnly && (
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => {
                      setAttachments((list) => list.filter((x) => x.id !== a.id));
                      toast("Attachment removed");
                    }}
                    className="gap-1 shrink-0"
                  >
                    <X className="h-4 w-4" />
                    Remove
                  </Button>
                  )}
                </li>
              ))}
            </ul>
          </section>
        </div>

        {!readOnly && (
        <SheetFooter className="px-8 py-4 border-t border-border flex-row justify-start sm:justify-start gap-2 sm:space-x-0">
          {details?.isAuto ? (
            <p className="text-body-3 text-muted-foreground">
              This task is automated and will complete at phase start.
            </p>
          ) : (
            <>
              <Button
                variant="default"
                onClick={() => setStatus("completed")}
                disabled={status === "completed"}
              >
                {status === "completed" ? "Completed" : "Mark as complete"}
              </Button>
              <Popover>
                <PopoverTrigger asChild>
                  <Button variant="outline">Change status</Button>
                </PopoverTrigger>
                <PopoverContent align="start" className="w-56 p-1">
                  <ul>
                    {STATUS_OPTIONS.map((s) => (
                      <li key={s}>
                        <button
                          type="button"
                          onClick={() => {
                            setStatusForm({
                              issue: "",
                              impact: "",
                              mitigation: "",
                              owner: primary?.name ?? "",
                            });
                            setPendingStatus(s);
                          }}
                          className={cn(
                            "w-full flex items-center gap-2 px-2 py-2 rounded-sm text-left text-body-3 hover:bg-muted/40 transition-colors",
                            status === s && "bg-muted/60",
                          )}
                        >
                          <span
                            className={cn(
                              "inline-block h-2 w-2 rounded-full",
                              STATUS_DOT[s],
                            )}
                            aria-hidden
                          />
                          <span className="text-foreground">{STATUS_LABEL[s]}</span>
                        </button>
                      </li>
                    ))}
                  </ul>
                </PopoverContent>
              </Popover>
            </>
          )}
        </SheetFooter>
        )}
      </SheetContent>
      <Dialog
        open={pendingStatus !== null}
        onOpenChange={(o) => !o && setPendingStatus(null)}
      >
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle className="text-h5 text-foreground">
              Change status
              {pendingStatus && (
                <>
                  {" "}
                  to{" "}
                  <span className="text-primary">
                    {STATUS_LABEL[pendingStatus]}
                  </span>
                </>
              )}
            </DialogTitle>
            <DialogDescription className="text-body-3 text-muted-foreground">
              Provide context so reviewers can act on this status change.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <div className="space-y-2">
              <Label htmlFor="status-issue" className="text-body-3 text-foreground">
                Issue description
              </Label>
              <Textarea
                id="status-issue"
                value={statusForm.issue}
                onChange={(e) =>
                  setStatusForm((f) => ({ ...f, issue: e.target.value }))
                }
                placeholder="What is the issue?"
                rows={2}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="status-impact" className="text-body-3 text-foreground">
                Business impact
              </Label>
              <Textarea
                id="status-impact"
                value={statusForm.impact}
                onChange={(e) =>
                  setStatusForm((f) => ({ ...f, impact: e.target.value }))
                }
                placeholder="What is the impact on the launch?"
                rows={2}
              />
            </div>
            <div className="space-y-2">
              <Label
                htmlFor="status-mitigation"
                className="text-body-3 text-foreground"
              >
                Mitigation plan
              </Label>
              <Textarea
                id="status-mitigation"
                value={statusForm.mitigation}
                onChange={(e) =>
                  setStatusForm((f) => ({ ...f, mitigation: e.target.value }))
                }
                placeholder="How will this be addressed?"
                rows={2}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="status-owner" className="text-body-3 text-foreground">
                Owner
              </Label>
              <Select
                value={statusForm.owner}
                onValueChange={(v) =>
                  setStatusForm((f) => ({ ...f, owner: v }))
                }
              >
                <SelectTrigger id="status-owner">
                  <SelectValue placeholder="Select an owner" />
                </SelectTrigger>
                <SelectContent>
                  {OWNERS.map((o) => (
                    <SelectItem key={o.name} value={o.name}>
                      {o.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setPendingStatus(null)}>
              Cancel
            </Button>
            <Button
              onClick={() => {
                if (pendingStatus) {
                  setStatus(pendingStatus);
                  toast.success(
                    `Status updated to ${STATUS_LABEL[pendingStatus]}`,
                  );
                }
                setPendingStatus(null);
              }}
              disabled={
                !statusForm.issue.trim() ||
                !statusForm.impact.trim() ||
                !statusForm.mitigation.trim() ||
                !statusForm.owner
              }
            >
              Submit
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </Sheet>
  );
}

function Tile({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="rounded-md border border-border p-4 bg-surface">
      <p className="text-caption text-muted-foreground">{label}</p>
      <div className="mt-2">{children}</div>
    </div>
  );
}

function ownerEmail(name: string): string {
  return (
    name
      .toLowerCase()
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .replace(/[^a-z\s.-]/g, "")
      .trim()
      .split(/\s+/)
      .join(".") + "@dell.com"
  );
}

function OwnerCard({
  label,
  owner,
  taskFunction,
}: {
  label: string;
  owner: TaskOwner | null;
  taskFunction?: string;
}) {
  if (!owner) return null;
  return (
    <div className="flex items-start gap-3 rounded-md border border-border p-4">
      <Avatar className="h-10 w-10">
        <AvatarFallback>{owner.initials}</AvatarFallback>
      </Avatar>
      <div className="min-w-0 flex-1">
        <p className="text-caption text-muted-foreground">{label}</p>
        <p className="text-body-3 font-medium text-foreground truncate">{owner.name}</p>
        
        <a
          href={`mailto:${ownerEmail(owner.name)}`}
          className="block text-caption text-primary hover:underline truncate"
        >
          {ownerEmail(owner.name)}
        </a>
        {taskFunction && (
          <p className="text-caption text-muted-foreground truncate">
            Function: <span className="text-foreground">{taskFunction}</span>
          </p>
        )}
      </div>
    </div>
  );
}
