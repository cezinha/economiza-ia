import { useMemo, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { CheckCircle2, Eye } from "lucide-react";
import { useFilteredLaunches } from "@/lib/applyFilters";
import { useFilters } from "@/contexts/FilterContext";
import {
  tasksForLaunch,
  taskStatus,
  worstActive,
  isAutoTask,
  type LaunchTask,
  type TaskStatus,
} from "@/lib/launchTasks";
import { Badge } from "@/components/ui/badge";
import { dueDateFor } from "@/lib/tasks";
import { TaskDetailDrawer } from "@/components/dashboard/TaskDetailDrawer";
import { useIsReadOnly } from "@/lib/permissions";
import type { Launch } from "@/mocks/launches";

const STATUS_RANK: Record<TaskStatus, number> = {
  "at-risk": 0,
  "at-risk-mitigated": 1,
  "on-track": 2,
  "not-started": 3,
  completed: 99,
};

const STATUS_DOT: Record<TaskStatus, string> = {
  completed: "bg-status-completed",
  "on-track": "bg-status-on-track",
  "at-risk-mitigated": "bg-status-at-risk-mitigated",
  "at-risk": "bg-status-at-risk",
  "not-started": "bg-status-not-started",
};

const STATUS_LABEL: Record<TaskStatus, string> = {
  completed: "Completed",
  "on-track": "On track",
  "at-risk-mitigated": "At risk (mitigated)",
  "at-risk": "At risk",
  "not-started": "Not started",
};

interface QueueItem {
  task: LaunchTask;
  launch: Launch;
  status: TaskStatus;
  due: string;
  completedAt?: Date;
}

function hash(s: string): number {
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

function mockCompletedAt(taskId: string): Date {
  const daysAgo = hash(taskId) % 180;
  const d = new Date();
  d.setDate(d.getDate() - daysAgo);
  return d;
}

function formatRelative(d: Date): string {
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const target = new Date(d);
  target.setHours(0, 0, 0, 0);
  const diff = Math.round((today.getTime() - target.getTime()) / 86400000);
  if (diff <= 0) return "Today";
  if (diff === 1) return "Yesterday";
  if (diff < 30) return `${diff} days ago`;
  return d.toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" });
}

export function TaskQueue() {
  const [selected, setSelected] = useState<QueueItem | null>(null);
  const readOnly = useIsReadOnly();
  const launches = useFilteredLaunches();
  const { filters } = useFilters();
  const fnFilter = Array.isArray(filters.function) ? (filters.function as string[]) : [];
  const phaseFilter = Array.isArray(filters.phase) ? (filters.phase as string[]) : [];
  const taskFilter = Array.isArray(filters.task) ? (filters.task as string[]) : [];
  const statusFilter = Array.isArray(filters.status) ? (filters.status as string[]) : [];

  const statusBucket = (s: TaskStatus): "achieved" | "risk-mitigated" | "missed" | null => {
    if (s === "completed" || s === "on-track") return "achieved";
    if (s === "at-risk-mitigated") return "risk-mitigated";
    if (s === "at-risk") return "missed";
    return null;
  };

  const { todoItems, notStartedItems, completedItems } = useMemo(() => {
    const todo: QueueItem[] = [];
    const notStarted: QueueItem[] = [];
    const done: QueueItem[] = [];
    for (const launch of launches) {
      for (const task of tasksForLaunch(launch)) {
        if (fnFilter.length && !task.teams.some((t) => fnFilter.includes(t))) continue;
        if (phaseFilter.length && !phaseFilter.includes(task.phase)) continue;
        if (taskFilter.length && !taskFilter.includes(task.task)) continue;
        const status = worstActive(task.teams.map((tm) => taskStatus(launch, task, tm)));
        if (statusFilter.length) {
          const b = statusBucket(status);
          if (!b || !statusFilter.includes(b)) continue;
        }
        const due = dueDateFor(launch, task.taskEnd);
        if (status === "completed") {
          done.push({ task, launch, status, due, completedAt: mockCompletedAt(task.id) });
        } else if (status === "not-started") {
          notStarted.push({ task, launch, status, due });
        } else {
          todo.push({ task, launch, status, due });
        }
      }
    }
    todo.sort((a, b) => {
      const r = STATUS_RANK[a.status] - STATUS_RANK[b.status];
      if (r !== 0) return r;
      return a.due.localeCompare(b.due);
    });
    notStarted.sort((a, b) => a.due.localeCompare(b.due));
    done.sort((a, b) => (b.completedAt!.getTime() - a.completedAt!.getTime()));
    return { todoItems: todo, notStartedItems: notStarted, completedItems: done };
  }, [launches, fnFilter, phaseFilter, taskFilter, statusFilter]);

  const renderRow = (it: QueueItem, mode: "todo" | "not-started" | "completed") => (
    <li
      key={it.task.id}
      className="flex items-start gap-3 px-4 py-3 hover:bg-muted/40 transition-colors"
    >
      <span
        className={cn(
          "inline-block h-2 w-2 rounded-full mt-2 shrink-0",
          STATUS_DOT[it.status],
        )}
        aria-label={STATUS_LABEL[it.status]}
      />
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2 flex-wrap">
          <span className="text-caption text-muted-foreground">{STATUS_LABEL[it.status]}</span>
          <span className="text-caption text-muted-foreground">· {it.task.phase}</span>
          {mode === "completed" ? (
            <span className="text-caption text-muted-foreground">
              · Completed {formatRelative(it.completedAt!)}
            </span>
          ) : (
            <span className="text-caption text-muted-foreground tabular-nums">
              · Due {it.due}
            </span>
          )}
        </div>
        <p className="text-body-3 font-medium text-foreground mt-1 truncate">
          {it.task.task}
          {isAutoTask(it.task) && (
            <Badge variant="secondary" className="ml-2 align-middle text-caption">
              Auto
            </Badge>
          )}
        </p>
        <p className="text-caption text-muted-foreground truncate">
          <span className="font-medium text-foreground/80">{it.launch.lob}</span> · {it.launch.name}
        </p>
      </div>
      <Button
        size="sm"
        variant="outline"
        className="shrink-0"
        onClick={() => setSelected(it)}
      >
        {mode === "todo" && !readOnly ? (
          <>
            <CheckCircle2 className="h-4 w-4 mr-2" /> Complete task
          </>
        ) : (
          <>
            <Eye className="h-4 w-4 mr-2" /> View task
          </>
        )}
      </Button>
    </li>
  );

  return (
    <>
      <Card className="border-border bg-surface shadow-elev-1">
        <CardHeader className="pb-4">
          <CardTitle className="text-h6 text-foreground">Your action queue</CardTitle>
          <p className="text-caption text-muted-foreground">Tasks across platforms</p>
        </CardHeader>
        <CardContent className="p-0">
          <Tabs defaultValue="todo" className="w-full">
            <div className="px-4 pt-2">
              <TabsList>
                <TabsTrigger value="todo">To-do</TabsTrigger>
                <TabsTrigger value="not-started">Not started</TabsTrigger>
                <TabsTrigger value="completed">Completed</TabsTrigger>
              </TabsList>
            </div>
            <TabsContent value="todo" className="mt-2">
              {todoItems.length === 0 ? (
                <p className="px-4 py-6 text-caption text-muted-foreground italic">
                  No open tasks.
                </p>
              ) : (
                <ul className="divide-y divide-border max-h-[640px] overflow-y-auto">
                  {todoItems.map((it) => renderRow(it, "todo"))}
                </ul>
              )}
            </TabsContent>
            <TabsContent value="not-started" className="mt-2">
              {notStartedItems.length === 0 ? (
                <p className="px-4 py-6 text-caption text-muted-foreground italic">
                  No tasks waiting on a future phase.
                </p>
              ) : (
                <ul className="divide-y divide-border max-h-[640px] overflow-y-auto">
                  {notStartedItems.map((it) => renderRow(it, "not-started"))}
                </ul>
              )}
            </TabsContent>
            <TabsContent value="completed" className="mt-2">
              {completedItems.length === 0 ? (
                <p className="px-4 py-6 text-caption text-muted-foreground italic">
                  No completed tasks yet.
                </p>
              ) : (
                <ul className="divide-y divide-border max-h-[640px] overflow-y-auto">
                  {completedItems.map((it) => renderRow(it, "completed"))}
                </ul>
              )}
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>

      <TaskDetailDrawer
        task={selected?.task ?? null}
        launch={selected?.launch ?? launches[0]}
        initialStatus={selected?.status ?? "not-started"}
        onOpenChange={(o) => !o && setSelected(null)}
      />
    </>
  );
}
