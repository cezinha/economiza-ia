import { useNavigate } from "react-router-dom";
import { DashboardDetailDrawer, DrawerEmpty } from "./DashboardDetailDrawer";
import { useFilteredLaunches } from "@/lib/applyFilters";
import { useFilters } from "@/contexts/FilterContext";
import { currentPhaseName, functionStatus, type TaskStatus } from "@/lib/launchTasks";
import type { ScheduleTrack } from "@/lib/schedule";
import type { Launch } from "@/mocks/launches";

const TRACKS: ScheduleTrack[] = ["GOE", "NPI", "SchM"];

const STATUS_DOT: Record<TaskStatus, string> = {
  completed: "bg-status-completed",
  "on-track": "bg-status-on-track",
  "at-risk-mitigated": "bg-status-at-risk-mitigated",
  "at-risk": "bg-status-at-risk",
  "not-started": "bg-status-not-started",
};

const STATUS_LABEL: Record<TaskStatus, string> = {
  completed: "Completed",
  "on-track": "On track",
  "at-risk-mitigated": "Mitigated",
  "at-risk": "At risk",
  "not-started": "Not started",
};

function trackLabel(t: ScheduleTrack) {
  return t === "SchM" ? "SChM" : t;
}

type Props = {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  /** Optional: scope drawer to a single track (per-card). Defaults to all three. */
  track?: ScheduleTrack;
};

export function FunctionStatusDrawer({ open, onOpenChange, track }: Props) {
  const navigate = useNavigate();
  const { setFilter } = useFilters();
  const launches = useFilteredLaunches();
  const tracks = track ? [track] : TRACKS;

  const go = (l: Launch, t: ScheduleTrack) => {
    setFilter("function", [t]);
    onOpenChange(false);
    navigate(`/tasks?tab=platform&launch=${encodeURIComponent(l.id)}`);
  };

  return (
    <DashboardDetailDrawer
      open={open}
      onOpenChange={onOpenChange}
      eyebrow="Status distribution by current phase"
      title={track ? `Function · ${trackLabel(track)}` : "Function-level status"}
      description="Per-function status across platforms. Click a row to open My tasks scoped to that function."
    >
      {launches.length === 0 ? (
        <DrawerEmpty>No platforms match the current filters.</DrawerEmpty>
      ) : (
        <div className="space-y-8">
          {tracks.map((t) => (
            <section key={t} className="space-y-3">
              <h3 className="text-subtitle-2 text-foreground">{trackLabel(t)}</h3>
              <ul className="rounded-sm border border-border bg-surface divide-y divide-border">
                {launches.map((l) => {
                  const s = functionStatus(l, t);
                  const phase = currentPhaseName(l, t);
                  return (
                    <li key={l.id} className="px-4 py-3 flex items-center gap-3">
                      <button
                        type="button"
                        onClick={() => go(l, t)}
                        className="text-body-3 text-foreground hover:text-primary hover:underline text-left flex-1 min-w-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring rounded-sm"
                      >
                        <div className="truncate">{l.name}</div>
                        <div className="text-caption text-muted-foreground truncate">
                          {l.lob} · {phase ?? "—"}
                        </div>
                      </button>
                      <span className="inline-flex items-center gap-2 rounded-sm border border-border px-2 py-1 text-caption text-foreground">
                        <span className={`inline-block h-2 w-2 rounded-full ${STATUS_DOT[s]}`} aria-hidden />
                        {STATUS_LABEL[s]}
                      </span>
                    </li>
                  );
                })}
              </ul>
            </section>
          ))}
        </div>
      )}
    </DashboardDetailDrawer>
  );
}
