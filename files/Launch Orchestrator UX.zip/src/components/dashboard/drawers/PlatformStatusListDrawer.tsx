import { useNavigate } from "react-router-dom";
import { DashboardDetailDrawer, DrawerEmpty, StatusChip } from "./DashboardDetailDrawer";
import { useFilteredLaunches } from "@/lib/applyFilters";
import { useFilters } from "@/contexts/FilterContext";
import { functionStatus, platformStatus, type TaskStatus } from "@/lib/launchTasks";
import type { ScheduleTrack } from "@/lib/schedule";
import type { Launch } from "@/mocks/launches";

type Status = "on-track" | "at-risk-mitigated" | "at-risk";

type Props = {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  /** Filter to a single status, or "all" to show every platform grouped by status. */
  status: Status | "all";
  title: string;
  eyebrow: string;
};

const TRACKS: ScheduleTrack[] = ["GOE", "NPI", "SchM"];

const STATUS_GROUPS: { key: Status; label: string }[] = [
  { key: "on-track", label: "Achieved / on track" },
  { key: "at-risk-mitigated", label: "At risk · with mitigation" },
  { key: "at-risk", label: "At risk · no mitigation" },
];

const LOB_LABELS: Record<string, string> = {
  DT: "Desktops",
  NB: "Notebooks",
  DnCP: "Displays & Client Peripherals",
};

function trackLabel(t: ScheduleTrack) {
  return t === "SchM" ? "SChM" : t;
}

export function PlatformStatusListDrawer({ open, onOpenChange, status, title, eyebrow }: Props) {
  const navigate = useNavigate();
  const { setFilter } = useFilters();
  const launches = useFilteredLaunches();

  const goPlatform = (l: Launch) => {
    onOpenChange(false);
    navigate(`/tasks?tab=platform&launch=${encodeURIComponent(l.id)}`);
  };

  const goPlatformWithFunction = (l: Launch, track: ScheduleTrack) => {
    setFilter("function", [track]);
    onOpenChange(false);
    navigate(`/tasks?tab=platform&launch=${encodeURIComponent(l.id)}`);
  };

  const groups = status === "all"
    ? STATUS_GROUPS.map((g) => ({ ...g, items: launches.filter((l) => platformStatus(l) === g.key) }))
    : STATUS_GROUPS
        .filter((g) => g.key === status)
        .map((g) => ({ ...g, items: launches.filter((l) => platformStatus(l) === g.key) }));

  const total = groups.reduce((n, g) => n + g.items.length, 0);

  return (
    <DashboardDetailDrawer
      open={open}
      onOpenChange={onOpenChange}
      eyebrow={eyebrow}
      title={title}
      description={`${total} platform${total === 1 ? "" : "s"} · click a platform to open My tasks. Click a function chip to scope to that function.`}
    >
      {total === 0 ? (
        <DrawerEmpty>No platforms match the current filters.</DrawerEmpty>
      ) : (
        <div className="space-y-8">
          {groups.map((g) => {
            const byLob = new Map<string, Launch[]>();
            for (const l of g.items) {
              if (!byLob.has(l.lob)) byLob.set(l.lob, []);
              byLob.get(l.lob)!.push(l);
            }
            return (
              <section key={g.key} className="space-y-4">
                {status === "all" && (
                  <h3 className="text-subtitle-2 text-foreground flex items-center gap-2">
                    <StatusChip status={g.key as TaskStatus} />
                    <span className="text-muted-foreground">· {g.items.length}</span>
                  </h3>
                )}
                {g.items.length === 0 ? (
                  <p className="text-body-3 text-muted-foreground italic">None.</p>
                ) : (
                  Array.from(byLob.entries()).map(([lob, list]) => (
                    <div key={lob} className="space-y-2">
                      <div className="text-caption uppercase tracking-wide text-muted-foreground">
                        {LOB_LABELS[lob] ?? lob} ({list.length})
                      </div>
                      <ul className="rounded-sm border border-border bg-surface divide-y divide-border">
                        {list.map((l) => (
                          <li key={l.id} className="px-4 py-3 flex flex-wrap items-center gap-3">
                            <button
                              type="button"
                              onClick={() => goPlatform(l)}
                              className="text-body-2 text-foreground hover:text-primary hover:underline focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring rounded-sm text-left"
                            >
                              {l.name}
                            </button>
                            <span className="text-caption text-muted-foreground">
                              · {l.lob} · RTS {l.launchDate}
                            </span>
                            <div className="ml-auto flex flex-wrap items-center gap-2">
                              {TRACKS.map((t) => (
                                <button
                                  key={t}
                                  type="button"
                                  onClick={() => goPlatformWithFunction(l, t)}
                                  className="focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring rounded-sm"
                                  title={`Open ${trackLabel(t)} for ${l.name}`}
                                >
                                  <span className="inline-flex items-center gap-2 rounded-sm border border-border px-2 py-1 text-caption text-foreground hover:bg-muted transition-colors">
                                    <span className="text-muted-foreground">{trackLabel(t)}</span>
                                    <StatusDot status={functionStatus(l, t)} />
                                  </span>
                                </button>
                              ))}
                            </div>
                          </li>
                        ))}
                      </ul>
                    </div>
                  ))
                )}
              </section>
            );
          })}
        </div>
      )}
    </DashboardDetailDrawer>
  );
}

function StatusDot({ status }: { status: TaskStatus }) {
  const cls =
    status === "on-track"
      ? "bg-status-on-track"
      : status === "at-risk-mitigated"
      ? "bg-status-at-risk-mitigated"
      : status === "at-risk"
      ? "bg-status-at-risk"
      : status === "completed"
      ? "bg-status-completed"
      : "bg-status-not-started";
  return <span className={`inline-block h-2 w-2 rounded-full ${cls}`} aria-hidden />;
}
