import { ReactNode } from "react";
import { Outlet } from "react-router-dom";
import { SidebarProvider } from "@/components/ui/sidebar";
import { AppSidebar } from "./AppSidebar";
import { TopBar } from "./TopBar";
import { FilterProvider } from "@/contexts/FilterContext";
import { ViewFilterProvider } from "@/contexts/ViewFilterContext";
import { FiltersDrawer } from "./FiltersDrawer";
import { RoleViewModal } from "./RoleViewModal";

import { AssistantLauncher } from "@/components/assistant/AssistantLauncher";

export function AppShell({ children }: { children?: ReactNode }) {
  return (
    <FilterProvider>
      <ViewFilterProvider>
        <SidebarProvider>
          {/* Masthead spans the full width above the sidebar (DDS dashboard pattern). */}
          <div className="flex min-h-screen w-full flex-col bg-background">
            <TopBar />
            <div className="flex flex-1 min-h-0">
              <AppSidebar />
              <main className="flex-1 px-page py-6 l:py-8 animate-fade-in min-w-0 space-y-4">
                {children ?? <Outlet />}
              </main>
            </div>
          </div>
          <FiltersDrawer />
          <RoleViewModal />
          <AssistantLauncher />
        </SidebarProvider>
      </ViewFilterProvider>
    </FilterProvider>
  );
}

