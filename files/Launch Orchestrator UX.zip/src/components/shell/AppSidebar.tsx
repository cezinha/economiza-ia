import { NavLink, useLocation } from "react-router-dom";
import {
  Archive,
  Sliders,
  Hammer,
  AlertTriangle,
  ChevronLeft,
  ChevronRight,
} from "lucide-react";
import { UploadedIcon } from "./UploadedIcon";
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  useSidebar,
} from "@/components/ui/sidebar";
import { cn } from "@/lib/utils";

/**
 * DDS Side Navigation (locked).
 * - Width: 280px expanded / 60px collapsed (token-driven, see ui/sidebar.tsx)
 * - Item rhythm: 16px top/bottom padding, 16px icon, 4px left active marker
 * - Colors: Gray 800 inactive · Gray 900 active · Blue 100 hover · Gray 100 active bg · Blue 700 marker
 * - Sentence case labels, succinct (<20 chars where possible)
 * - Auto-collapse <768px (handled by mobile Sheet)
 * - Chevron toggle anchored to bottom of the panel
 */

const primary = [
  { title: "Home", url: "/", iconName: "home" as const },
  { title: "OLP schedule", url: "/launches", iconName: "schedule" as const },
  { title: "My tasks", url: "/tasks", iconName: "task" as const },
  { title: "Doc and data curator", url: "/curator", iconName: "files" as const },
  { title: "NUDDs", url: "/risks", iconName: "risk" as const },
  { title: "Design issues", url: "/design-issues", icon: AlertTriangle },
  { title: "Golden configs", url: "/golden-configs", icon: Sliders },
  { title: "Build execution", url: "/build-execution", icon: Hammer },
  { title: "Archive", url: "/activity", icon: Archive },
];

// DDS item: 16px vertical padding, 4px transparent left border that turns
// Blue 700 on active. Hover = Blue 100 bg + Gray 900 text. Active = Gray 100
// bg + Gray 900 text + Blue 700 marker. Resting = Gray 800 text/icon.
const itemClass = cn(
  "relative flex items-center gap-4 w-full",
  // 4px left marker reserved on every item (transparent at rest)
  "border-l-4 border-transparent",
  // 16px top/bottom padding, 12px right; left padding 12px so icon sits at 16px
  "!h-12 !py-4 !pl-3 !pr-3",
  "rounded-none",
  "text-body-3 text-sidebar-foreground",
  "transition-colors",
  // Hover: Blue 100 + Gray 900 text
  "hover:!bg-sidebar-accent hover:!text-sidebar-accent-foreground",
  // Active: Gray 100 bg, Gray 900 text, Blue 700 marker
  "data-[active=true]:!bg-sidebar-active",
  "data-[active=true]:!text-sidebar-active-foreground",
  "data-[active=true]:!border-sidebar-primary",
  "data-[active=true]:font-medium",
  // Collapsed (60px rail): center the icon, hide text
  "group-data-[collapsible=icon]:!h-12 group-data-[collapsible=icon]:!w-12",
  "group-data-[collapsible=icon]:!px-0 group-data-[collapsible=icon]:justify-center",
);

export function AppSidebar() {
  const { state, toggleSidebar } = useSidebar();
  const collapsed = state === "collapsed";
  const { pathname } = useLocation();
  const isActive = (path: string) => (path === "/" ? pathname === "/" : pathname.startsWith(path));

  return (
    <Sidebar collapsible="icon" className="border-r border-sidebar-border">

      <SidebarContent>
        <SidebarGroup className="p-0">
          <SidebarGroupContent>
            <SidebarMenu className="gap-0">
              {primary.map((item) => (
                <SidebarMenuItem key={item.title}>
                  <SidebarMenuButton
                    asChild
                    isActive={isActive(item.url)}
                    tooltip={item.title}
                    className={itemClass}
                  >
                    <NavLink to={item.url} aria-label={item.title}>
                      {"iconName" in item ? (
                        <UploadedIcon name={item.iconName} className="h-4 w-4 shrink-0" aria-hidden="true" />
                      ) : (
                        <item.icon className="h-4 w-4 shrink-0" aria-hidden="true" />
                      )}
                      {!collapsed && <span className="truncate">{item.title}</span>}
                    </NavLink>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>

      {/* DDS chevron toggle, anchored to bottom of the panel. */}
      <SidebarFooter className="p-0 border-t border-sidebar-border">
        <button
          type="button"
          onClick={toggleSidebar}
          aria-label={collapsed ? "Expand side navigation" : "Collapse side navigation"}
          className={cn(
            "flex h-12 w-full items-center justify-end px-4",
            "text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground",
            "transition-colors",
            "group-data-[collapsible=icon]:justify-center group-data-[collapsible=icon]:px-0",
          )}
        >
          {collapsed ? <ChevronRight className="h-4 w-4" /> : <ChevronLeft className="h-4 w-4" />}
        </button>
      </SidebarFooter>
    </Sidebar>
  );
}
