import { AlertTriangle } from "lucide-react";

export function ComingSoon() {
  return (
    <div className="flex flex-col items-center justify-center py-24 text-center">
      <AlertTriangle className="h-8 w-8 text-muted-foreground" aria-hidden="true" />
      <p className="mt-4 text-body-2 text-foreground">Coming soon</p>
      <p className="mt-2 text-body-3 text-muted-foreground">To be implemented in V2.0</p>
    </div>
  );
}
