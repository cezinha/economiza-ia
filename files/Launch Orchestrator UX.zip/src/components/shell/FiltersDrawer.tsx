import { useMemo } from "react";
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetFooter,
  SheetHeader,
  SheetTitle,
} from "@/components/ui/sheet";
import { Button } from "@/components/ui/button";
import { useFilters } from "@/contexts/FilterContext";
import {
  MultiSelectCombobox,
  type ComboOption,
} from "@/components/shell/MultiSelectCombobox";
import {
  lockedValues,
  scopedLobOptions,
  scopedOwnerOptions,
  scopedPhaseOptions,
  scopedPlatformOptions,
  scopedTaskOptions,
} from "@/lib/filterCascade";

const ORGANIZATION: ComboOption[] = [
  { value: "CSG", label: "CSG" },
  { value: "ISG", label: "ISG" },
];

const FUNCTION: ComboOption[] = [
  { value: "GOE", label: "GOE" },
  { value: "NPI", label: "NPI" },
  { value: "SchM", label: "SChM" },
];


const STATUS: ComboOption[] = [
  { value: "achieved", label: "Achieved / on track" },
  { value: "risk-mitigated", label: "Risk with mitigation" },
  { value: "missed", label: "Missed / no mitigation plan" },
];



interface FieldProps {
  label: string;
  children: React.ReactNode;
}

function Field({ label, children }: FieldProps) {
  return (
    <div className="space-y-2">
      <label className="text-body-3 font-medium text-foreground block">
        {label}
      </label>
      {children}
    </div>
  );
}

export function FiltersDrawer() {
  const { filters, setFilter, isOpen, setOpen, resetFilters, close, activeCount } =
    useFilters();

  const toCombo = (vs: string[]): ComboOption[] =>
    vs.map((v) => ({ value: v, label: v }));

  const platformOptions = useMemo<ComboOption[]>(
    () => toCombo(scopedPlatformOptions(filters)),
    [filters],
  );
  const ownerOptions = useMemo<ComboOption[]>(
    () => toCombo(scopedOwnerOptions(filters)),
    [filters],
  );
  const taskOptions = useMemo<ComboOption[]>(
    () => toCombo(scopedTaskOptions(filters)),
    [filters],
  );
  const lobOptionsScoped = useMemo<ComboOption[]>(
    () => toCombo(scopedLobOptions(filters)),
    [filters],
  );
  const phaseOptionsScoped = useMemo<ComboOption[]>(
    () => toCombo(scopedPhaseOptions(filters)),
    [filters],
  );

  const get = (k: string): string[] => {
    const v = filters[k];
    return Array.isArray(v) ? (v as string[]) : [];
  };

  return (
    <Sheet open={isOpen} onOpenChange={setOpen}>
      <SheetContent side="right" className="w-full s:max-w-md flex flex-col p-0">
        <SheetHeader className="px-6 py-4 border-b border-border">
          <SheetTitle className="text-h5">Filters</SheetTitle>
          <SheetDescription className="text-body-3 text-muted-foreground">
            Refine the data shown across the dashboard.
            {activeCount > 0 && ` ${activeCount} active.`}
          </SheetDescription>
        </SheetHeader>

        <div className="flex-1 overflow-y-auto px-6 py-4 space-y-4">
          <Field label="Business Unit">
            <MultiSelectCombobox
              options={ORGANIZATION}
              values={get("organization")}
              onChange={(v) => setFilter("organization", v)}
              placeholder="All business units"
              searchPlaceholder="Search business units..."
              lockedValues={lockedValues(filters, "organization")}
              lockedTooltip="Required by selected LOB or Platform"
            />
          </Field>

          <Field label="Function">
            <MultiSelectCombobox
              options={FUNCTION}
              values={get("function")}
              onChange={(v) => setFilter("function", v)}
              placeholder="All functions"
              searchPlaceholder="Search functions..."
            />
          </Field>

          <Field label="LOB">
            <MultiSelectCombobox
              options={lobOptionsScoped}
              values={get("lob")}
              onChange={(v) => setFilter("lob", v)}
              placeholder="All LOBs"
              searchPlaceholder="Search LOBs..."
              lockedValues={lockedValues(filters, "lob")}
              lockedTooltip="Required by selected Platform or Owner"
            />
          </Field>

          <Field label="Platform">
            <MultiSelectCombobox
              options={platformOptions}
              values={get("platform")}
              onChange={(v) => setFilter("platform", v)}
              placeholder="All platforms"
              searchPlaceholder="Search platforms..."
              lockedValues={lockedValues(filters, "platform")}
              lockedTooltip="Required by selected Owner"
            />
          </Field>

          <Field label="Phase">
            <MultiSelectCombobox
              options={phaseOptionsScoped}
              values={get("phase")}
              onChange={(v) => setFilter("phase", v)}
              placeholder="All phases"
              searchPlaceholder="Search phases..."
            />
          </Field>

          <Field label="Status">
            <MultiSelectCombobox
              options={STATUS}
              values={get("status")}
              onChange={(v) => setFilter("status", v)}
              placeholder="All statuses"
              searchPlaceholder="Search statuses..."
            />
          </Field>

          <Field label="Owner">
            <MultiSelectCombobox
              options={ownerOptions}
              values={get("owner")}
              onChange={(v) => setFilter("owner", v)}
              placeholder="All owners"
              searchPlaceholder="Search owners..."
            />
          </Field>

          <Field label="Task">
            <MultiSelectCombobox
              options={taskOptions}
              values={get("task")}
              onChange={(v) => setFilter("task", v)}
              placeholder="All tasks"
              searchPlaceholder="Search tasks..."
            />
          </Field>
        </div>

        <SheetFooter className="px-6 py-4 border-t border-border flex-row justify-between gap-2">
          <Button variant="ghost" onClick={resetFilters}>
            Reset
          </Button>
          <Button onClick={close}>Apply</Button>
        </SheetFooter>
      </SheetContent>
    </Sheet>
  );
}
