import { Pencil } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useViewFilter } from "@/contexts/ViewFilterContext";
import { useRole } from "@/contexts/RoleContext";
import { launches as ALL_LAUNCHES } from "@/mocks/launches";
import { useMemo } from "react";

export function LockedFilterBar() {
  const { role } = useRole();
  const { lockedFunction, lockedPlatformIds, open, isLocked } = useViewFilter();

  const platformLabel = useMemo(() => {
    if (!lockedPlatformIds || lockedPlatformIds.length === 0) return "—";
    if (lockedPlatformIds.length === 1) {
      const l = ALL_LAUNCHES.find((x) => x.id === lockedPlatformIds[0]);
      return l?.name ?? "1 platform";
    }
    return `${lockedPlatformIds.length} platforms`;
  }, [lockedPlatformIds]);

  if (!isLocked || !lockedFunction) return null;
  if (role !== "admin" && role !== "user") return null;

  return (
    <div className="flex items-center gap-3 flex-wrap rounded-md border border-border bg-surface px-4 py-2 shadow-elev-1">
      <span className="text-caption text-muted-foreground">View locked to</span>
      <Badge variant="secondary" className="text-body-3">
        Function · {lockedFunction === "SchM" ? "SChM" : lockedFunction}
      </Badge>
      <Badge variant="secondary" className="text-body-3">
        Platforms · {platformLabel}
      </Badge>
      <Button
        variant="ghost"
        size="sm"
        className="ml-auto gap-2"
        onClick={open}
      >
        <Pencil className="h-4 w-4" />
        Edit
      </Button>
    </div>
  );
}
