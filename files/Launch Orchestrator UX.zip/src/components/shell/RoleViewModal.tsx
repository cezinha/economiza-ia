import { useEffect, useMemo, useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { useViewFilter } from "@/contexts/ViewFilterContext";
import { useRole, ROLES } from "@/contexts/RoleContext";
import { launches as ALL_LAUNCHES } from "@/mocks/launches";
import type { TaskFunction } from "@/lib/launchTasks";
import { Search } from "lucide-react";
import { cn } from "@/lib/utils";

const FUNCTIONS: { value: TaskFunction; label: string }[] = [
  { value: "GOE", label: "GOE" },
  { value: "NPI", label: "NPI" },
  { value: "SchM", label: "SChM" },
];

export function RoleViewModal() {
  const { isOpen, apply, cancel, lockedFunction, lockedPlatformIds } = useViewFilter();
  const { role } = useRole();
  const roleLabel = ROLES.find((r) => r.value === role)?.label ?? role;

  const [fn, setFn] = useState<TaskFunction | null>(lockedFunction);
  const [platformIds, setPlatformIds] = useState<string[]>(lockedPlatformIds ?? []);
  const [search, setSearch] = useState("");

  useEffect(() => {
    if (isOpen) {
      setFn(lockedFunction);
      setPlatformIds(lockedPlatformIds ?? []);
      setSearch("");
    }
  }, [isOpen, lockedFunction, lockedPlatformIds]);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    if (!q) return ALL_LAUNCHES;
    return ALL_LAUNCHES.filter(
      (l) =>
        l.name.toLowerCase().includes(q) ||
        l.lob.toLowerCase().includes(q) ||
        l.region.toLowerCase().includes(q),
    );
  }, [search]);

  const allSelected = filtered.every((l) => platformIds.includes(l.id));

  const toggle = (id: string) => {
    setPlatformIds((prev) =>
      prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id],
    );
  };

  const toggleAllVisible = () => {
    const ids = filtered.map((l) => l.id);
    if (allSelected) {
      setPlatformIds((prev) => prev.filter((id) => !ids.includes(id)));
    } else {
      setPlatformIds((prev) => Array.from(new Set([...prev, ...ids])));
    }
  };

  const canApply = fn !== null && platformIds.length > 0;

  return (
    <Dialog
      open={isOpen}
      onOpenChange={(next) => {
        if (!next) cancel();
      }}
    >
      <DialogContent className="max-w-xl">
        <DialogHeader>
          <DialogTitle>Set your view</DialogTitle>
          <DialogDescription>
            {roleLabel} dashboards are scoped to one function and the platforms you own.
            You can change this later.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6">
          <div className="space-y-2">
            <Label className="text-body-3 text-foreground">Function</Label>
            <RadioGroup
              value={fn ?? ""}
              onValueChange={(v) => setFn(v as TaskFunction)}
              className="flex gap-4"
            >
              {FUNCTIONS.map((f) => (
                <label
                  key={f.value}
                  className={cn(
                    "flex items-center gap-2 rounded-md border border-border px-3 py-2 cursor-pointer",
                    fn === f.value && "border-primary bg-primary/5",
                  )}
                >
                  <RadioGroupItem value={f.value} id={`fn-${f.value}`} />
                  <span className="text-body-3 text-foreground">{f.label}</span>
                </label>
              ))}
            </RadioGroup>
          </div>

          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <Label className="text-body-3 text-foreground">
                Platforms{" "}
                <span className="text-caption text-muted-foreground">
                  ({platformIds.length} selected)
                </span>
              </Label>
              <button
                type="button"
                onClick={toggleAllVisible}
                className="text-caption text-primary hover:underline"
              >
                {allSelected ? "Clear visible" : "Select all visible"}
              </button>
            </div>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search platforms…"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="pl-10"
              />
            </div>
            <div className="max-h-64 overflow-y-auto rounded-md border border-border">
              {filtered.length === 0 ? (
                <p className="px-3 py-4 text-caption italic text-muted-foreground">
                  No platforms match.
                </p>
              ) : (
                <ul>
                  {filtered.map((l) => {
                    const checked = platformIds.includes(l.id);
                    return (
                      <li key={l.id}>
                        <label className="flex items-center gap-3 px-3 py-2 cursor-pointer hover:bg-muted/40">
                          <Checkbox
                            checked={checked}
                            onCheckedChange={() => toggle(l.id)}
                          />
                          <span className="flex-1 min-w-0">
                            <span className="block text-body-3 text-foreground truncate">
                              {l.name}
                            </span>
                            <span className="block text-caption text-muted-foreground truncate">
                              {l.lob}
                            </span>
                          </span>
                        </label>
                      </li>
                    );
                  })}
                </ul>
              )}
            </div>
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={cancel}>
            Cancel
          </Button>
          <Button
            disabled={!canApply}
            onClick={() => fn && apply(fn, platformIds)}
          >
            Apply
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
