import { Bell, Search, ChevronDown, Filter, User } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useRole, ROLES, Role } from "@/contexts/RoleContext";
import { useFilters } from "@/contexts/FilterContext";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuLabel,
  DropdownMenuRadioGroup,
  DropdownMenuRadioItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { useEffect, useState } from "react";
import dellLogo from "@/assets/dell-technologies-logo.png";

type Density = "compact" | "default" | "comfy";

type NotificationItem = { title: string; subtitle: string };
type NotificationCategory = { label: string; emptyLabel: string; items: NotificationItem[] };

const NOTIFICATION_CATEGORIES: NotificationCategory[] = [
  {
    label: "Overdue tasks",
    emptyLabel: "No overdue tasks.",
    items: [
      { title: "Upload PG documentation", subtitle: "Siple Low INT NVL S1 · 3d overdue" },
      { title: "Confirm GOE sign-off", subtitle: "Naples HE Plus · 1d overdue" },
    ],
  },
  {
    label: "Upcoming tasks",
    emptyLabel: "No upcoming tasks.",
    items: [
      { title: "Submit MRC checklist", subtitle: "Naples HE Plus · due in 2d" },
      { title: "Schedule NPI readiness review", subtitle: "Verona Pro · due in 5d" },
    ],
  },
  {
    label: "Upcoming NUDDs",
    emptyLabel: "No upcoming NUDDs.",
    items: [
      { title: "NUDD-0142 review", subtitle: "Siple Low INT NVL S1 · due in 4d" },
    ],
  },
  {
    label: "Upcoming design issues",
    emptyLabel: "No upcoming design issues.",
    items: [],
  },
  {
    label: "Mentions",
    emptyLabel: "No new mentions.",
    items: [
      {
        title: "Aisha Khan mentioned you",
        subtitle: "on 'Upload PG documentation' · 1d ago",
      },
    ],
  },
];

export function TopBar() {
  const { role, setRole } = useRole();
  const { open: openFilters, activeCount } = useFilters();
  const [density, setDensity] = useState<Density>("default");

  useEffect(() => {
    document.documentElement.dataset.density = density;
  }, [density]);

  const currentRoleLabel = ROLES.find((r) => r.value === role)?.label ?? role;

  return (
    <header className="sticky top-0 z-30 flex h-16 items-center gap-6 border-b border-border bg-surface px-4 m:px-6">
      {/* Brand / masthead */}
      <div className="flex items-center gap-3 shrink-0">
        <img src={dellLogo} alt="Dell Technologies" className="h-6 w-auto" />
        
        <span className="text-body-2 text-foreground ml-2">OLP Launch Orchestrator</span>
      </div>

      {/* Search */}
      <div className="hidden m:flex items-center gap-2 flex-1 max-w-2xl">
        <div className="relative w-full">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input placeholder="Search" className="pl-10 h-10 bg-background" />
        </div>
      </div>

      <div className="ml-auto flex items-center gap-2">
        {/* Filters */}
        <Button
          variant="outline"
          className="h-10 gap-2 px-3"
          onClick={openFilters}
          aria-label="Filters"
        >
          <Filter className="h-4 w-4" />
          <span className="text-body-3">Filters</span>
          {activeCount > 0 && (
            <span className="inline-flex h-5 min-w-5 items-center justify-center rounded-full bg-primary px-1 text-caption font-medium text-primary-foreground">
              {activeCount}
            </span>
          )}
        </Button>

        {/* Notifications */}
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" className="h-10 gap-2 px-3" aria-label="Notifications">
              <span className="relative inline-flex">
                <Bell className="h-5 w-5" strokeWidth={1.5} />
                <span className="absolute -top-2 -right-2 inline-flex h-4 min-w-4 items-center justify-center rounded-full bg-primary px-1 text-caption font-medium text-primary-foreground">
                  {NOTIFICATION_CATEGORIES.reduce((n, c) => n + c.items.length, 0)}
                </span>
              </span>
              <span className="text-body-3">Notification</span>
              <ChevronDown className="h-4 w-4 text-muted-foreground" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-96 max-h-[480px] overflow-y-auto">
            <DropdownMenuLabel>Notifications</DropdownMenuLabel>
            <DropdownMenuSeparator />
            {NOTIFICATION_CATEGORIES.map((cat, i) => (
              <div key={cat.label}>
                {i > 0 && <DropdownMenuSeparator />}
                <DropdownMenuLabel className="flex items-center justify-between">
                  <span>{cat.label}</span>
                  <span className="text-caption text-muted-foreground">{cat.items.length}</span>
                </DropdownMenuLabel>
                {cat.items.length === 0 ? (
                  <div className="px-2 py-2 text-caption italic text-muted-foreground">
                    {cat.emptyLabel}
                  </div>
                ) : (
                  <ul className="px-1 pb-1">
                    {cat.items.map((it, idx) => (
                      <li
                        key={idx}
                        className="px-2 py-2 rounded-md cursor-pointer hover:bg-muted/40"
                      >
                        <p className="text-body-3 text-foreground">{it.title}</p>
                        <p className="text-caption text-muted-foreground">{it.subtitle}</p>
                      </li>
                    ))}
                  </ul>
                )}
              </div>
            ))}
          </DropdownMenuContent>
        </DropdownMenu>

        {/* Profile (with Density + View as inside) */}
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" className="h-10 gap-2 px-3">
              <User className="h-5 w-5" strokeWidth={1.5} />
              <span className="text-body-3">Profile</span>
              <ChevronDown className="h-4 w-4 text-muted-foreground" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-56">
            <DropdownMenuLabel>Density</DropdownMenuLabel>
            <DropdownMenuRadioGroup value={density} onValueChange={(v) => setDensity(v as Density)}>
              <DropdownMenuRadioItem value="compact">Compact</DropdownMenuRadioItem>
              <DropdownMenuRadioItem value="default">Default</DropdownMenuRadioItem>
              <DropdownMenuRadioItem value="comfy">Comfortable</DropdownMenuRadioItem>
            </DropdownMenuRadioGroup>
            <DropdownMenuSeparator />
            <DropdownMenuLabel>View as · {currentRoleLabel}</DropdownMenuLabel>
            <DropdownMenuRadioGroup value={role} onValueChange={(v) => setRole(v as Role)}>
              {ROLES.map((r) => (
                <DropdownMenuRadioItem key={r.value} value={r.value}>
                  {r.label}
                </DropdownMenuRadioItem>
              ))}
            </DropdownMenuRadioGroup>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </header>
  );
}
