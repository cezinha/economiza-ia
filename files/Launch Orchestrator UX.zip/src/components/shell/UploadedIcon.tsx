import { cn } from "@/lib/utils";

type UploadedIconName = "home" | "schedule" | "task" | "files" | "risk";

interface UploadedIconProps {
  name: UploadedIconName;
  className?: string;
  "aria-hidden"?: boolean | "true" | "false";
}

const maskClassByName: Record<UploadedIconName, string> = {
  home: "dds-icon-home",
  schedule: "dds-icon-schedule",
  task: "dds-icon-task",
  files: "dds-icon-files",
  risk: "dds-icon-risk",
};

export function UploadedIcon({ name, className, ...props }: UploadedIconProps) {
  return <span className={cn("dds-icon-mask", maskClassByName[name], className)} {...props} />;
}