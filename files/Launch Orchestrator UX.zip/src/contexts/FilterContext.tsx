import { createContext, ReactNode, useCallback, useContext, useMemo, useState } from "react";

export type FilterValues = Record<string, unknown>;

type FilterContextValue = {
  filters: FilterValues;
  setFilter: (key: string, value: unknown) => void;
  resetFilters: () => void;
  isOpen: boolean;
  open: () => void;
  close: () => void;
  setOpen: (open: boolean) => void;
  activeCount: number;
};

const FilterContext = createContext<FilterContextValue | undefined>(undefined);

function isActive(value: unknown): boolean {
  if (value === undefined || value === null || value === "") return false;
  if (Array.isArray(value)) return value.length > 0;
  if (typeof value === "object") return Object.keys(value as object).length > 0;
  return true;
}

export function FilterProvider({ children }: { children: ReactNode }) {
  const [filters, setFilters] = useState<FilterValues>({});
  const [isOpen, setIsOpen] = useState(false);

  const setFilter = useCallback((key: string, value: unknown) => {
    setFilters((prev) => ({ ...prev, [key]: value }));
  }, []);

  const resetFilters = useCallback(() => setFilters({}), []);
  const open = useCallback(() => setIsOpen(true), []);
  const close = useCallback(() => setIsOpen(false), []);

  const activeCount = useMemo(
    () => Object.values(filters).filter(isActive).length,
    [filters],
  );

  const value = useMemo(
    () => ({ filters, setFilter, resetFilters, isOpen, open, close, setOpen: setIsOpen, activeCount }),
    [filters, setFilter, resetFilters, isOpen, open, close, activeCount],
  );

  return <FilterContext.Provider value={value}>{children}</FilterContext.Provider>;
}

export function useFilters() {
  const ctx = useContext(FilterContext);
  if (!ctx) throw new Error("useFilters must be used within a FilterProvider");
  return ctx;
}
