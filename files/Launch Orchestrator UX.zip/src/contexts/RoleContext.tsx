import { createContext, useContext, useMemo, useState, ReactNode } from "react";

export type Role = "superadmin" | "admin" | "executive" | "user";

export const ROLES: { value: Role; label: string; description: string }[] = [
  { value: "superadmin", label: "Superadmin", description: "Full portfolio control" },
  { value: "executive", label: "Executive", description: "Portfolio health & KPIs" },
  { value: "admin", label: "Admin", description: "Workspace configuration" },
  { value: "user", label: "User", description: "My tasks & launches" },
];

interface RoleContextValue {
  role: Role;
  setRole: (r: Role) => void;
}

const RoleContext = createContext<RoleContextValue | undefined>(undefined);

export function RoleProvider({ children }: { children: ReactNode }) {
  const [role, setRole] = useState<Role>("superadmin");
  const value = useMemo(() => ({ role, setRole }), [role]);
  return <RoleContext.Provider value={value}>{children}</RoleContext.Provider>;
}

export function useRole() {
  const ctx = useContext(RoleContext);
  if (!ctx) throw new Error("useRole must be used within RoleProvider");
  return ctx;
}
