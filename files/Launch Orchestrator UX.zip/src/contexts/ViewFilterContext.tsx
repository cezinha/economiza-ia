import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState, ReactNode } from "react";
import type { TaskFunction } from "@/lib/launchTasks";
import { useRole, type Role } from "@/contexts/RoleContext";

const STORAGE_KEY = "viewFilter:v1";

interface StoredState {
  role: Role;
  fn: TaskFunction;
  platformIds: string[];
}

interface ViewFilterValue {
  /** Locked function (only meaningful for admin/user). */
  lockedFunction: TaskFunction | null;
  /** Locked launch ids (only meaningful for admin/user). null = no scope. */
  lockedPlatformIds: string[] | null;
  /** True when the role requires setup but no selection has been made. */
  isLocked: boolean;
  /** Modal open state. */
  isOpen: boolean;
  open: () => void;
  apply: (fn: TaskFunction, platformIds: string[]) => void;
  cancel: () => void;
}

const ViewFilterContext = createContext<ViewFilterValue | undefined>(undefined);

function readStored(): Record<string, StoredState> {
  try {
    const raw = sessionStorage.getItem(STORAGE_KEY);
    if (!raw) return {};
    return JSON.parse(raw) as Record<string, StoredState>;
  } catch {
    return {};
  }
}

function writeStored(map: Record<string, StoredState>) {
  try {
    sessionStorage.setItem(STORAGE_KEY, JSON.stringify(map));
  } catch {
    /* ignore */
  }
}

export function ViewFilterProvider({ children }: { children: ReactNode }) {
  const { role, setRole } = useRole();
  const [stored, setStored] = useState<Record<string, StoredState>>(() => readStored());
  const [isOpen, setIsOpen] = useState(false);
  const previousRoleRef = useRef<Role>(role);

  const requiresScoping = role === "admin" || role === "user";
  const current = requiresScoping ? stored[role] : undefined;

  // Auto-open the modal when a role that requires scoping has no saved selection.
  useEffect(() => {
    if (requiresScoping && !current) {
      setIsOpen(true);
    } else {
      setIsOpen(false);
    }
    if (!requiresScoping) {
      previousRoleRef.current = role;
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [role, current]);

  const apply = useCallback(
    (fn: TaskFunction, platformIds: string[]) => {
      if (!requiresScoping) return;
      const next = { ...stored, [role]: { role, fn, platformIds } };
      setStored(next);
      writeStored(next);
      setIsOpen(false);
      previousRoleRef.current = role;
    },
    [role, stored, requiresScoping],
  );

  const cancel = useCallback(() => {
    setIsOpen(false);
    if (requiresScoping && !current) {
      // No prior selection — bounce back to previous role.
      const prev = previousRoleRef.current && previousRoleRef.current !== role
        ? previousRoleRef.current
        : "superadmin";
      setRole(prev);
    }
  }, [requiresScoping, current, role, setRole]);

  const open = useCallback(() => setIsOpen(true), []);

  const value = useMemo<ViewFilterValue>(
    () => ({
      lockedFunction: current?.fn ?? null,
      lockedPlatformIds: current?.platformIds ?? null,
      isLocked: requiresScoping,
      isOpen,
      open,
      apply,
      cancel,
    }),
    [current, requiresScoping, isOpen, open, apply, cancel],
  );

  return <ViewFilterContext.Provider value={value}>{children}</ViewFilterContext.Provider>;
}

export function useViewFilter(): ViewFilterValue {
  const ctx = useContext(ViewFilterContext);
  if (!ctx) throw new Error("useViewFilter must be used within ViewFilterProvider");
  return ctx;
}
