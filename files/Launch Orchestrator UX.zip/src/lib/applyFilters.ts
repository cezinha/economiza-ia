import { useMemo } from "react";
import { useFilters } from "@/contexts/FilterContext";
import { useViewFilter } from "@/contexts/ViewFilterContext";
import {
  launches as ALL_LAUNCHES,
  risks as ALL_RISKS,
  tasks as ALL_TASK_QUEUE,
  milestones as ALL_MILESTONES,
  activity as ALL_ACTIVITY,
  type Launch,
  type Risk,
  type TaskItem,
  type Milestone,
  type Activity,
  type RAG,
} from "@/mocks/launches";
import { NUDDS, type NuddRow } from "@/mocks/nudds";
import { phasesForLaunch, type ScheduleTrack } from "@/lib/schedule";
import { mergeImplied } from "@/lib/filterCascade";

const ALL_TRACKS: ScheduleTrack[] = ["GOE", "NPI", "SchM"];

/** Names of the per-track current phase for a launch as of `today`. */
function currentPhaseNames(l: Launch, today: Date): string[] {
  const out: string[] = [];
  for (const track of ALL_TRACKS) {
    const phases = phasesForLaunch(l, track);
    const t = today.getTime();
    let idx = -1;
    for (let i = 0; i < phases.length; i++) {
      if (t >= phases[i].start.getTime() && t < phases[i].end.getTime()) { idx = i; break; }
    }
    if (idx === -1) {
      if (phases.length === 0) continue;
      idx = t < phases[0].start.getTime() ? 0 : phases.length - 1;
    }
    out.push(phases[idx].name);
  }
  return out;
}

export type StatusBucket = "achieved" | "risk-mitigated" | "missed";

const arr = (v: unknown): string[] => (Array.isArray(v) ? (v as string[]) : []);

/** All current data is treated as CSG. ISG-only filter collapses to empty. */
export function passesOrganization(orgFilter: string[]): boolean {
  if (orgFilter.length === 0) return true;
  return orgFilter.includes("CSG");
}

export function ragToStatus(rag: RAG): StatusBucket {
  if (rag === "green") return "achieved";
  if (rag === "amber") return "risk-mitigated";
  return "missed";
}

export function severityToStatus(
  s: Risk["severity"],
): StatusBucket {
  if (s === "low") return "achieved";
  if (s === "critical") return "missed";
  return "risk-mitigated";
}

export function milestoneToStatus(s: Milestone["status"]): StatusBucket {
  if (s === "at_risk") return "risk-mitigated";
  return "achieved";
}

export function nuddToStatus(n: NuddRow): StatusBucket {
  const r = n.impact * n.probability;
  if (r <= 2) return "achieved";
  if (r <= 5) return "risk-mitigated";
  return "missed";
}

/** Apply launch-relevant filters. Phase = per-track current phase (any track match). */
function launchPasses(l: Launch, f: ReturnType<typeof useFilters>["filters"], today: Date): boolean {
  const lob = arr(f.lob);
  const platform = arr(f.platform);
  const phase = arr(f.phase);
  const owner = arr(f.owner);
  const status = arr(f.status);
  if (lob.length && !lob.includes(l.lob)) return false;
  if (platform.length && !platform.includes(l.name)) return false;
  if (phase.length) {
    const cur = currentPhaseNames(l, today);
    if (!cur.some((p) => phase.includes(p))) return false;
  }
  if (owner.length && !owner.includes(l.owner)) return false;
  if (status.length && !status.includes(ragToStatus(l.rag))) return false;
  return true;
}

export function useFilteredLaunches(): Launch[] {
  const { filters: raw } = useFilters();
  const { lockedPlatformIds } = useViewFilter();
  return useMemo(() => {
    const filters = mergeImplied(raw);
    if (!passesOrganization(arr(filters.organization))) return [];
    const today = new Date();
    let result = ALL_LAUNCHES.filter((l) => launchPasses(l, filters, today));
    if (lockedPlatformIds) {
      const allowed = new Set(lockedPlatformIds);
      result = result.filter((l) => allowed.has(l.id));
    }
    return result;
  }, [raw, lockedPlatformIds]);
}

function useLockedNames(): Set<string> | null {
  const { lockedPlatformIds } = useViewFilter();
  return useMemo(() => {
    if (!lockedPlatformIds) return null;
    const ids = new Set(lockedPlatformIds);
    return new Set(ALL_LAUNCHES.filter((l) => ids.has(l.id)).map((l) => l.name));
  }, [lockedPlatformIds]);
}

export function useFilteredRisks(): Risk[] {
  const { filters: raw } = useFilters();
  const lockedNames = useLockedNames();
  return useMemo(() => {
    const filters = mergeImplied(raw);
    if (!passesOrganization(arr(filters.organization))) return [];
    const platform = arr(filters.platform);
    const owner = arr(filters.owner);
    const status = arr(filters.status);
    const lob = arr(filters.lob);
    const phase = arr(filters.phase);
    const launchByName = new Map(ALL_LAUNCHES.map((l) => [l.name, l]));
    return ALL_RISKS.filter((r) => {
      if (lockedNames && !lockedNames.has(r.launch)) return false;
      if (platform.length && !platform.includes(r.launch)) return false;
      if (owner.length && !owner.includes(r.owner)) return false;
      if (status.length && !status.includes(severityToStatus(r.severity)))
        return false;
      const l = launchByName.get(r.launch);
      if (lob.length && (!l || !lob.includes(l.lob))) return false;
      if (phase.length && (!l || !phase.includes(l.phase))) return false;
      return true;
    });
  }, [raw, lockedNames]);
}

export function useFilteredNudds(): NuddRow[] {
  const { filters: raw } = useFilters();
  const lockedNames = useLockedNames();
  return useMemo(() => {
    const filters = mergeImplied(raw);
    if (!passesOrganization(arr(filters.organization))) return [];
    const lob = arr(filters.lob);
    const platform = arr(filters.platform);
    const owner = arr(filters.owner);
    const status = arr(filters.status);
    return NUDDS.filter((n) => {
      if (lockedNames && !lockedNames.has(n.platform)) return false;
      if (lob.length && !lob.includes(n.lob)) return false;
      if (platform.length && !platform.includes(n.platform)) return false;
      if (owner.length && !owner.includes(n.people.assignee)) return false;
      if (status.length && !status.includes(nuddToStatus(n))) return false;
      return true;
    });
  }, [raw, lockedNames]);
}

export function useFilteredMilestones(): Milestone[] {
  const { filters: raw } = useFilters();
  const launches = useFilteredLaunches();
  return useMemo(() => {
    const ids = new Set(launches.map((l) => l.id));
    const status = arr(raw.status);
    return ALL_MILESTONES.filter((m) => {
      if (!ids.has(m.launchId)) return false;
      if (status.length && !status.includes(milestoneToStatus(m.status)))
        return false;
      return true;
    });
  }, [launches, raw]);
}

export function useFilteredTaskQueue(): TaskItem[] {
  const { filters: raw } = useFilters();
  const lockedNames = useLockedNames();
  return useMemo(() => {
    const filters = mergeImplied(raw);
    if (!passesOrganization(arr(filters.organization))) return [];
    const platform = arr(filters.platform);
    const owner = arr(filters.owner);
    const task = arr(filters.task);
    const lob = arr(filters.lob);
    const phase = arr(filters.phase);
    const launchByName = new Map(ALL_LAUNCHES.map((l) => [l.name, l]));
    return ALL_TASK_QUEUE.filter((t) => {
      if (lockedNames && !lockedNames.has(t.launch)) return false;
      if (platform.length && !platform.includes(t.launch)) return false;
      if (owner.length && !owner.includes(t.assignee)) return false;
      if (task.length && !task.includes(t.title)) return false;
      const l = launchByName.get(t.launch);
      if (lob.length && (!l || !lob.includes(l.lob))) return false;
      if (phase.length && (!l || !phase.includes(l.phase))) return false;
      return true;
    });
  }, [raw, lockedNames]);
}

export function useFilteredActivity(): Activity[] {
  const { filters: raw } = useFilters();
  const launches = useFilteredLaunches();
  return useMemo(() => {
    const ids = new Set(launches.map((l) => l.id));
    const owner = arr(raw.owner);
    return ALL_ACTIVITY.filter((a) => {
      if (!ids.has(a.launchId)) return false;
      if (owner.length && !owner.includes(a.actor)) return false;
      return true;
    });
  }, [launches, raw]);
}
