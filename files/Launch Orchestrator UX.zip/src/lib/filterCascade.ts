import { launches } from "@/mocks/launches";
import rawTasks from "@/mocks/olpTasks.json";

export const LOB_TO_ORG: Record<string, "CSG" | "ISG"> = {
  DT: "CSG",
  NB: "CSG",
  DnCP: "CSG",
  Server: "ISG",
  Storage: "ISG",
  "S&S": "ISG",
  "Network Eq": "ISG",
};

export const ALL_LOBS = ["DT", "NB", "DnCP", "Server", "Storage", "S&S", "Network Eq"];
export const PHASE_ORDER = [
  "Concept",
  "Define",
  "Plan",
  "Develop",
  "Qual",
  "Pilot",
  "Ramp",
  "Launch",
];

type Filters = Record<string, unknown>;
const arr = (v: unknown): string[] => (Array.isArray(v) ? (v as string[]) : []);
const uniq = <T,>(xs: T[]): T[] => Array.from(new Set(xs));

type TaskDef = { task: string; lobs: string[] };
const TASKS = rawTasks as TaskDef[];

/** Parents implied by current child selections. */
export function impliedParents(f: Filters): {
  organization: string[];
  lob: string[];
  platform: string[];
} {
  const platform = arr(f.platform);
  const lob = arr(f.lob);
  const owner = arr(f.owner);

  const platformsFromOwner = owner.length
    ? launches.filter((l) => owner.includes(l.owner)).map((l) => l.name)
    : [];
  const allPlatforms = new Set([...platform, ...platformsFromOwner]);

  const lobsFromPlatform = launches
    .filter((l) => allPlatforms.has(l.name))
    .map((l) => l.lob as string);
  const allLobs = new Set<string>([...lob, ...lobsFromPlatform]);

  const orgsFromLob = Array.from(allLobs)
    .map((l) => LOB_TO_ORG[l])
    .filter(Boolean);

  return {
    organization: uniq(orgsFromLob),
    lob: uniq(lobsFromPlatform),
    platform: uniq(platformsFromOwner),
  };
}

/** Filters with parent values unioned with implied values (used at read time). */
export function mergeImplied(f: Filters): Filters {
  const imp = impliedParents(f);
  return {
    ...f,
    organization: uniq([...arr(f.organization), ...imp.organization]),
    lob: uniq([...arr(f.lob), ...imp.lob]),
    platform: uniq([...arr(f.platform), ...imp.platform]),
  };
}

export function lockedValues(
  f: Filters,
  kind: "organization" | "lob" | "platform",
): string[] {
  return impliedParents(f)[kind];
}

function passesOrg(lobOfLaunch: string, org: string[]): boolean {
  if (!org.length) return true;
  return org.includes(LOB_TO_ORG[lobOfLaunch]);
}

export function scopedPlatformOptions(f: Filters): string[] {
  const merged = mergeImplied(f);
  const org = arr(merged.organization);
  const lob = arr(merged.lob);
  const phase = arr(f.phase);
  const owner = arr(f.owner);
  const task = arr(f.task);

  let taskLobs: Set<string> | null = null;
  if (task.length) {
    taskLobs = new Set();
    for (const t of TASKS) if (task.includes(t.task)) for (const lo of t.lobs) taskLobs.add(lo);
  }

  return uniq(
    launches
      .filter((l) => {
        if (!passesOrg(l.lob, org)) return false;
        if (lob.length && !lob.includes(l.lob)) return false;
        if (phase.length && !phase.includes(l.phase)) return false;
        if (owner.length && !owner.includes(l.owner)) return false;
        if (taskLobs && !taskLobs.has(l.lob)) return false;
        return true;
      })
      .map((l) => l.name),
  ).sort();
}

export function scopedLobOptions(f: Filters): string[] {
  const org = arr(mergeImplied(f).organization);
  if (!org.length) return ALL_LOBS;
  return ALL_LOBS.filter((l) => org.includes(LOB_TO_ORG[l]));
}

export function scopedOwnerOptions(f: Filters): string[] {
  const merged = mergeImplied(f);
  const org = arr(merged.organization);
  const lob = arr(merged.lob);
  const platform = arr(merged.platform);
  const phase = arr(f.phase);
  return uniq(
    launches
      .filter((l) => {
        if (!passesOrg(l.lob, org)) return false;
        if (lob.length && !lob.includes(l.lob)) return false;
        if (platform.length && !platform.includes(l.name)) return false;
        if (phase.length && !phase.includes(l.phase)) return false;
        return true;
      })
      .map((l) => l.owner),
  ).sort();
}

export function scopedPhaseOptions(f: Filters): string[] {
  const merged = mergeImplied(f);
  const org = arr(merged.organization);
  const lob = arr(merged.lob);
  const platform = arr(merged.platform);
  const owner = arr(f.owner);
  const seen = new Set(
    launches
      .filter((l) => {
        if (!passesOrg(l.lob, org)) return false;
        if (lob.length && !lob.includes(l.lob)) return false;
        if (platform.length && !platform.includes(l.name)) return false;
        if (owner.length && !owner.includes(l.owner)) return false;
        return true;
      })
      .map((l) => l.phase as string),
  );
  return PHASE_ORDER.filter((p) => seen.has(p));
}

export function scopedTaskOptions(f: Filters): string[] {
  const lob = arr(mergeImplied(f).lob);
  const filtered = lob.length
    ? TASKS.filter((t) => t.lobs.some((l) => lob.includes(l)))
    : TASKS;
  return uniq(filtered.map((t) => t.task)).sort();
}
