import { useRole } from "@/contexts/RoleContext";

/** True when the active role has view-only access (no mutations). */
export function useIsReadOnly() {
  return useRole().role === "executive";
}
