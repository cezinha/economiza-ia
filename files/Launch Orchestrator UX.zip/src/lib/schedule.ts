import { Launch } from "@/mocks/launches";

export type ScheduleTrack = "GOE" | "NPI" | "SchM";

export interface PhaseSpan {
  name: string;
  start: Date;
  end: Date;
}

// Day offsets relative to launchDate. Each entry: [phaseName, startDayOffset, endDayOffset].
const GOE_NPI: ReadonlyArray<readonly [string, number, number]> = [
  ["Concept", -330, -270],
  ["Define",  -270, -210],
  ["Plan",    -210, -150],
  ["Qual",    -150, -90],
  ["Pilot",    -90, -30],
  ["Ramp",     -30,  30],
];

const SCHM: ReadonlyArray<readonly [string, number, number]> = [
  ["Concept", -330, -270],
  ["Define",  -270, -210],
  ["Plan",    -210, -150],
  ["Develop", -150,  -90],
  ["Launch",   -90,  30],
];

function addDays(base: Date, days: number): Date {
  const d = new Date(base.getTime());
  d.setUTCDate(d.getUTCDate() + days);
  return d;
}

export function phasesForLaunch(launch: Launch, track: ScheduleTrack): PhaseSpan[] {
  const launchDate = new Date(launch.launchDate + "T00:00:00Z");
  const def = track === "SchM" ? SCHM : GOE_NPI;
  return def.map(([name, s, e]) => ({
    name,
    start: addDays(launchDate, s),
    end: addDays(launchDate, e),
  }));
}

export function rollingWindow(monthsForward = 11, monthsBack = 1): { start: Date; end: Date } {
  const now = new Date();
  const start = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth() - monthsBack, 1));
  const end = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth() + monthsForward + 1, 1));
  return { start, end };
}

export function pctBetween(date: Date, start: Date, end: Date): number {
  const total = end.getTime() - start.getTime();
  const at = date.getTime() - start.getTime();
  return Math.max(0, Math.min(100, (at / total) * 100));
}

export function monthTicks(start: Date, end: Date): Date[] {
  const ticks: Date[] = [];
  const cur = new Date(Date.UTC(start.getUTCFullYear(), start.getUTCMonth(), 1));
  while (cur <= end) {
    ticks.push(new Date(cur.getTime()));
    cur.setUTCMonth(cur.getUTCMonth() + 1);
  }
  return ticks;
}
