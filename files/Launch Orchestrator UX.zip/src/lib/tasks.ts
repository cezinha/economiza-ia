import { taskCatalog, PHASE_ORDER, type CatalogTask, type OlpPhase } from "@/mocks/taskCatalog";
import { launches, type Launch, type LOB } from "@/mocks/launches";

export type TaskStatus = "todo" | "in_progress" | "done" | "blocked";
export type TaskType = "approval" | "review" | "input" | "decision";
export type TaskPriority = "high" | "medium" | "low";

export interface PlatformTask {
  id: string;
  launchId: string;
  launchName: string;
  lob: LOB;
  catalog: CatalogTask;
  status: TaskStatus;
  due: string; // ISO yyyy-mm-dd
  assignee: string;
  type: TaskType;
  priority: TaskPriority;
}

// ---- helpers ---------------------------------------------------------------

function hash(str: string): number {
  let h = 2166136261;
  for (let i = 0; i < str.length; i++) {
    h ^= str.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

function phaseIndex(p: OlpPhase | string): number {
  const i = PHASE_ORDER.indexOf(p as OlpPhase);
  return i === -1 ? 0 : i;
}

// Days from launchDate back to the start of each phase gate.
// Negative offsets relative to launchDate; e.g. CPE = 270 days before launch.
const GATE_OFFSET_DAYS: Record<string, number> = {
  CPE: -270, // Concept Phase Exit
  DPE: -210, // Define Phase Exit
  PPE: -150, // Plan Phase Exit
  FRC: -90,  // Final Release Candidate (Develop/Qual)
  "Pilot Start": -45,
  Launch: 0,
};

// Parse "CPE - 7 Days" / "PPE + 14 Days" / "FRC" / "Pilot Start -7 days"
function parseTaskEnd(taskEnd: string): { gate: string; deltaDays: number } | null {
  if (!taskEnd) return null;
  const t = taskEnd.trim();
  // try gates ordered by length desc so "Pilot Start" wins over "P..."
  const gates = Object.keys(GATE_OFFSET_DAYS).sort((a, b) => b.length - a.length);
  for (const g of gates) {
    if (t.toLowerCase().startsWith(g.toLowerCase())) {
      const rest = t.slice(g.length).trim();
      const m = rest.match(/^([+-]?)\s*(\d+)\s*days?$/i);
      if (!rest) return { gate: g, deltaDays: 0 };
      if (m) {
        const sign = m[1] === "-" ? -1 : 1;
        return { gate: g, deltaDays: sign * parseInt(m[2], 10) };
      }
      return { gate: g, deltaDays: 0 };
    }
  }
  return null;
}

function addDays(iso: string, days: number): string {
  const d = new Date(iso + "T00:00:00Z");
  d.setUTCDate(d.getUTCDate() + days);
  return d.toISOString().slice(0, 10);
}

export function dueDateFor(launch: Launch, taskEnd: string): string {
  const parsed = parseTaskEnd(taskEnd);
  if (!parsed) return launch.launchDate;
  const gateOffset = GATE_OFFSET_DAYS[parsed.gate] ?? 0;
  return addDays(launch.launchDate, gateOffset + parsed.deltaDays);
}

function deriveStatus(launch: Launch, taskPhase: OlpPhase, key: string): TaskStatus {
  const lp = phaseIndex(launch.phase);
  const tp = phaseIndex(taskPhase);
  if (tp < lp) return "done";
  if (tp === lp) {
    // ~15% blocked for variety
    return hash(key) % 100 < 15 ? "blocked" : "in_progress";
  }
  return "todo";
}

function deriveType(c: CatalogTask): TaskType {
  const t = c.task.toLowerCase();
  if (t.startsWith("approve") || t.includes("approval")) return "approval";
  if (t.startsWith("review")) return "review";
  if (t.startsWith("decision") || t.includes("decision")) return "decision";
  return "input";
}

// ---- public API ------------------------------------------------------------

export function tasksForLaunch(launch: Launch): PlatformTask[] {
  return taskCatalog
    .filter((c) => c.appliesTo[launch.lob])
    .map<PlatformTask>((c) => {
      const id = `${launch.id}::${c.l3Id}`;
      return {
        id,
        launchId: launch.id,
        launchName: launch.name,
        lob: launch.lob,
        catalog: c,
        status: deriveStatus(launch, c.l1Phase, id),
        due: dueDateFor(launch, c.taskEnd),
        assignee: launch.owner,
        type: deriveType(c),
        priority: c.required ? "high" : "medium",
      };
    });
}

export function allPlatformTasks(): PlatformTask[] {
  return launches.flatMap(tasksForLaunch);
}

/**
 * Tasks "due soon" for the action queue:
 * - status in_progress or blocked first, then todo
 * - sort by due date asc
 */
export function dueSoon(limit = 8): PlatformTask[] {
  const all = allPlatformTasks().filter((t) => t.status !== "done");
  const rank = (s: TaskStatus) =>
    s === "blocked" ? 0 : s === "in_progress" ? 1 : 2;
  return all
    .sort((a, b) => {
      const r = rank(a.status) - rank(b.status);
      if (r !== 0) return r;
      return a.due.localeCompare(b.due);
    })
    .slice(0, limit);
}
