export type RAG = "green" | "amber" | "red";
export type Phase = "Concept" | "Define" | "Plan" | "Develop" | "Qual" | "Pilot" | "Launch";
export type LOB = "DT" | "NB" | "DnCP";

export interface Launch {
  id: string;
  name: string;
  product: string;
  lob: LOB;
  region: "NA" | "EMEA" | "APJ" | "LATAM";
  owner: string;
  phase: Phase;
  rag: RAG;
  progress: number; // 0-100
  nextMilestone: string;
  nextMilestoneDate: string;
  launchDate: string;
}

export interface Milestone {
  id: string;
  launchId: string;
  name: string;
  date: string;
  status: "complete" | "in_progress" | "upcoming" | "at_risk";
}

export interface TaskItem {
  id: string;
  title: string;
  launch: string;
  type: "approval" | "review" | "input" | "decision";
  priority: "high" | "medium" | "low";
  due: string;
  assignee: string;
}

export interface Risk {
  id: string;
  launch: string;
  title: string;
  severity: "critical" | "high" | "medium" | "low";
  owner: string;
  raisedDate: string;
}

export type ActivityKind =
  | "phase_change"
  | "risk_raised"
  | "decision_request"
  | "approval_submitted"
  | "milestone_done"
  | "launch_kickoff";

export interface Activity {
  id: string;
  actor: string;
  kind: ActivityKind;
  launchId: string;
  refId?: string;
  timestamp: string;
}

export const launches: Launch[] = [
  // DT — Desktops
  { id: "L-2001", name: "Hyperion RPL-S",            product: "Hyperion RPL-S",            lob: "DT",   region: "NA",    owner: "Priya Shah",      phase: "Launch",  rag: "green", progress: 88, nextMilestone: "Channel enablement",      nextMilestoneDate: "2026-05-22", launchDate: "2026-06-18" },
  { id: "L-2002", name: "Citadel NVL",               product: "Citadel NVL",               lob: "DT",   region: "EMEA",  owner: "Marcus Lee",      phase: "Qual", rag: "amber", progress: 66, nextMilestone: "Reg compliance sign-off", nextMilestoneDate: "2026-05-19", launchDate: "2026-07-10" },
  { id: "L-2003", name: "Siple Low INT NVL S1",      product: "Siple Low INT NVL S1",      lob: "DT",   region: "APJ",   owner: "Hiroshi Tanaka",  phase: "Develop", rag: "red",   progress: 36, nextMilestone: "Firmware freeze",         nextMilestoneDate: "2026-05-14", launchDate: "2026-09-04" },
  { id: "L-2004", name: "Makalu-W INT NVL M2",       product: "Makalu-W INT NVL M2",       lob: "DT",   region: "NA",    owner: "Sara Okafor",     phase: "Plan",    rag: "green", progress: 24, nextMilestone: "BOM lock",                nextMilestoneDate: "2026-06-02", launchDate: "2026-10-21" },
  { id: "L-2005", name: "Vesta-P INT WCLR 24 AIO",   product: "Vesta-P INT WCLR 24 AIO",   lob: "DT",   region: "EMEA",  owner: "Lena Vogel",      phase: "Pilot",  rag: "green", progress: 78, nextMilestone: "Pilot exit review",        nextMilestoneDate: "2026-05-30", launchDate: "2026-08-14" },

  // NB — Notebooks
  { id: "L-2006", name: "Prowler NVL CS 16",         product: "Prowler NVL CS 16",         lob: "NB",   region: "NA",    owner: "Daniel Reyes",    phase: "Launch",  rag: "amber", progress: 81, nextMilestone: "Pricing approval",        nextMilestoneDate: "2026-05-16", launchDate: "2026-06-28" },
  { id: "L-2007", name: "Formula Rossa NVL CS 1",    product: "Formula Rossa NVL CS 1",    lob: "NB",   region: "EMEA",  owner: "Camila Souza",    phase: "Qual", rag: "green", progress: 72, nextMilestone: "Thermal validation",      nextMilestoneDate: "2026-05-25", launchDate: "2026-07-18" },
  { id: "L-2008", name: "Rapterra AMD CS 16",        product: "Rapterra AMD CS 16",        lob: "NB",   region: "APJ",   owner: "Aisha Khan",      phase: "Develop", rag: "amber", progress: 47, nextMilestone: "Beta customer kickoff",   nextMilestoneDate: "2026-05-28", launchDate: "2026-09-25" },
  { id: "L-2009", name: "Battlestar CS 18",          product: "Battlestar CS 18",          lob: "NB",   region: "NA",    owner: "Noah Bennett",    phase: "Concept", rag: "green", progress: 12, nextMilestone: "Concept gate review",     nextMilestoneDate: "2026-06-09", launchDate: "2027-01-15" },
  { id: "L-2010", name: "Volta NVL CS 14",           product: "Volta NVL CS 14",           lob: "NB",   region: "LATAM", owner: "Mateo Alvarez",   phase: "Plan",    rag: "green", progress: 28, nextMilestone: "Supplier RFQ close",      nextMilestoneDate: "2026-06-05", launchDate: "2026-11-04" },

  // DnCP — Displays & Client Peripherals
  { id: "L-2011", name: "U2726DER",                  product: "U2726DER",                  lob: "DnCP", region: "EMEA",  owner: "Elena Marchetti", phase: "Qual", rag: "green", progress: 74, nextMilestone: "Color calibration QA",    nextMilestoneDate: "2026-05-26", launchDate: "2026-07-20" },
  { id: "L-2012", name: "U40 Conference",            product: "U40 Conference",            lob: "DnCP", region: "NA",    owner: "Jordan Nguyen",   phase: "Launch",  rag: "green", progress: 91, nextMilestone: "Retail listing live",     nextMilestoneDate: "2026-05-21", launchDate: "2026-06-12" },
  { id: "L-2013", name: "AQ2426HL",                  product: "AQ2426HL",                  lob: "DnCP", region: "APJ",   owner: "Yuki Sato",       phase: "Develop", rag: "amber", progress: 52, nextMilestone: "Panel sourcing lock",     nextMilestoneDate: "2026-05-29", launchDate: "2026-09-15" },
  { id: "L-2014", name: "S2426HS",                   product: "S2426HS",                   lob: "DnCP", region: "NA",    owner: "Olivia Park",     phase: "Plan",    rag: "green", progress: 30, nextMilestone: "BOM lock",                nextMilestoneDate: "2026-06-04", launchDate: "2026-10-30" },
  { id: "L-2015", name: "P2226H",                    product: "P2226H",                    lob: "DnCP", region: "EMEA",  owner: "Felix Bauer",     phase: "Qual",   rag: "amber", progress: 64, nextMilestone: "Reg compliance sign-off", nextMilestoneDate: "2026-05-27", launchDate: "2026-08-08" },
];

export const milestones: Milestone[] = [
  { id: "M1", launchId: "L-2001", name: "Channel enablement",      date: "2026-05-22", status: "in_progress" },
  { id: "M2", launchId: "L-2002", name: "Reg compliance sign-off", date: "2026-05-19", status: "at_risk" },
  { id: "M3", launchId: "L-2003", name: "Firmware freeze",         date: "2026-05-14", status: "at_risk" },
  { id: "M4", launchId: "L-2006", name: "Pricing approval",        date: "2026-05-16", status: "in_progress" },
  { id: "M5", launchId: "L-2011", name: "Color calibration QA",    date: "2026-05-26", status: "upcoming" },
  { id: "M6", launchId: "L-2008", name: "Beta customer kickoff",   date: "2026-05-28", status: "upcoming" },
  { id: "M7", launchId: "L-2011", name: "Panel sourcing",          date: "2026-05-13", status: "complete" },
];

export const tasks: TaskItem[] = [
  { id: "T-201", title: "Approve Hyperion RPL-S launch comms",     launch: "Hyperion RPL-S",         type: "approval", priority: "high",   due: "2026-05-13", assignee: "You" },
  { id: "T-202", title: "Review Citadel NVL risk register",        launch: "Citadel NVL",            type: "review",   priority: "high",   due: "2026-05-14", assignee: "You" },
  { id: "T-203", title: "Decision: Siple firmware slip",           launch: "Siple Low INT NVL S1",   type: "decision", priority: "high",   due: "2026-05-12", assignee: "You" },
  { id: "T-204", title: "Pricing approval — Prowler NVL CS 16",    launch: "Prowler NVL CS 16",      type: "approval", priority: "medium", due: "2026-05-16", assignee: "You" },
  { id: "T-205", title: "Input needed: Makalu-W BOM",              launch: "Makalu-W INT NVL M2",    type: "input",    priority: "medium", due: "2026-05-20", assignee: "You" },
  { id: "T-206", title: "Review U40 Conference retail assets",     launch: "U40 Conference",         type: "review",   priority: "low",    due: "2026-05-23", assignee: "You" },
];

export const risks: Risk[] = [
  { id: "R-301", launch: "Siple Low INT NVL S1",   title: "Firmware regression on NVMe path",     severity: "critical", owner: "Hiroshi Tanaka",  raisedDate: "2026-05-08" },
  { id: "R-302", launch: "Citadel NVL",            title: "EU cybersecurity certification delay", severity: "high",     owner: "Marcus Lee",      raisedDate: "2026-05-09" },
  { id: "R-303", launch: "Prowler NVL CS 16",      title: "Margin below threshold in EMEA",       severity: "high",     owner: "Daniel Reyes",    raisedDate: "2026-05-10" },
  { id: "R-304", launch: "Rapterra AMD CS 16",     title: "Beta customer slot unconfirmed",       severity: "medium",   owner: "Aisha Khan",      raisedDate: "2026-05-11" },
  { id: "R-305", launch: "P2226H",                 title: "EOL inventory overhang in EMEA",       severity: "high",     owner: "Felix Bauer",     raisedDate: "2026-05-07" },
];

export const activity: Activity[] = [
  { id: "A1", actor: "Priya Shah",      kind: "phase_change",       launchId: "L-2001",                   timestamp: "2h ago" },
  { id: "A2", actor: "Marcus Lee",      kind: "risk_raised",        launchId: "L-2002", refId: "R-302",   timestamp: "4h ago" },
  { id: "A3", actor: "Hiroshi Tanaka",  kind: "decision_request",   launchId: "L-2003", refId: "T-203",   timestamp: "6h ago" },
  { id: "A4", actor: "Daniel Reyes",    kind: "approval_submitted", launchId: "L-2006", refId: "T-204",   timestamp: "Yesterday" },
  { id: "A5", actor: "Elena Marchetti", kind: "milestone_done",     launchId: "L-2011", refId: "M7",      timestamp: "Yesterday" },
  { id: "A6", actor: "Sara Okafor",     kind: "launch_kickoff",     launchId: "L-2004",                   timestamp: "2d ago" },
];

export const kpis = {
  inFlight: launches.length,
  onTrackPct: Math.round((launches.filter(l => l.rag === "green").length / launches.length) * 100),
  blockers: risks.filter(r => r.severity === "critical" || r.severity === "high").length,
  upcomingGates: milestones.filter(m => m.status === "in_progress" || m.status === "upcoming" || m.status === "at_risk").length,
};
