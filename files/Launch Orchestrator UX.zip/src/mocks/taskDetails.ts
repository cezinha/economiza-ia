import { isAutoTask, type LaunchTask } from "@/lib/launchTasks";
import type { Launch } from "@/mocks/launches";

export interface TaskOwner {
  name: string;
  role: string;
  initials: string;
}

export interface TaskComment {
  id: string;
  author: string;
  initials: string;
  timestamp: string;
  body: string;
  isRiskFlag?: boolean;
  mentions?: { name: string; initials: string }[];
}

export interface AssignmentEvent {
  id: string;
  timestamp: string;
  from: string;
  to: string;
  by: string;
}

export interface TaskDetails {
  primaryOwner: TaskOwner | null;
  backupOwner: TaskOwner | null;
  comments: TaskComment[];
  history: AssignmentEvent[];
  porDate: string;
  actualDate: string;
  deltaDays: number;
  submissionNotes: string;
  requiredDocs: string[];
  candidateOwners: TaskOwner[];
  isAuto: boolean;
}

export const OWNERS: TaskOwner[] = [
  { name: "Priya Shah", role: "GOE Program Lead", initials: "PS" },
  { name: "Marcus Lee", role: "NPI Engineering", initials: "ML" },
  { name: "Hiroshi Tanaka", role: "Schedule Manager", initials: "HT" },
  { name: "Sara Okafor", role: "GOE Program Lead", initials: "SO" },
  { name: "Daniel Reyes", role: "NPI Engineering", initials: "DR" },
  { name: "Aisha Khan", role: "Schedule Manager", initials: "AK" },
  { name: "Lena Vogel", role: "GOE Program Lead", initials: "LV" },
  { name: "Camila Souza", role: "NPI Engineering", initials: "CS" },
  { name: "Yuki Sato", role: "Schedule Manager", initials: "YS" },
  { name: "Felix Bauer", role: "GOE Program Lead", initials: "FB" },
];

const COMMENT_BODIES = [
  "Initial scoping looks fine — confirmed alignment with the GOE charter.",
  "Need GSM input on supplier capacity before we can move forward.",
  "Engineering flagged a thermal margin concern; tracking via JIRA.",
  "Aligned with the extended team in today's review; no blockers.",
  "Pulling forward by 2 days to de-risk the downstream gate.",
];

function hash(str: string): number {
  let h = 0;
  for (let i = 0; i < str.length; i++) h = (h * 31 + str.charCodeAt(i)) >>> 0;
  return h;
}

function pick<T>(arr: T[], seed: number, offset = 0): T {
  return arr[(seed + offset) % arr.length];
}

function parseOffsetDays(taskEnd: string): number {
  const m = taskEnd.match(/([+\-])\s*(\d+)\s*day/i);
  if (!m) return 0;
  return (m[1] === "-" ? -1 : 1) * parseInt(m[2], 10);
}

function addDays(iso: string, days: number): string {
  const d = new Date(iso);
  d.setDate(d.getDate() + days);
  return d.toISOString().slice(0, 10);
}

function formatDate(iso: string): string {
  return new Date(iso).toLocaleDateString("en-US", {
    month: "short",
    day: "numeric",
    year: "numeric",
  });
}

export function resolveDueDate(launch: Launch, taskEnd: string): string {
  const offset = parseOffsetDays(taskEnd);
  // Anchor T-minus to launch date minus 60d (rough phase-exit proxy)
  return formatDate(addDays(launch.launchDate, offset - 60));
}

export function getTaskDetails(task: LaunchTask, launch: Launch): TaskDetails {
  const seed = hash(task.id);
  const auto = isAutoTask(task);
  const primaryOwner = auto ? null : pick(OWNERS, seed);
  const backupOwner = auto ? null : pick(OWNERS, seed, 3);
  const candidateOwners = auto
    ? []
    : OWNERS.filter(
        (o) =>
          o.name !== primaryOwner!.name && o.name !== backupOwner!.name,
      );

  const commentCount = (seed % 3) + 1;
  const comments: TaskComment[] = Array.from({ length: commentCount }).map((_, i) => {
    const author = pick(OWNERS, seed, i + 1);
    const daysAgo = (i + 1) * ((seed % 4) + 1);
    return {
      id: `${task.id}-c${i}`,
      author: author.name,
      initials: author.initials,
      timestamp: `${daysAgo}d ago`,
      body: pick(COMMENT_BODIES, seed, i),
      isRiskFlag: i === 0 && seed % 5 === 0,
    };
  });

  const offset = parseOffsetDays(task.taskEnd);
  const porIso = addDays(launch.launchDate, offset - 60);
  const drift = (seed % 7) - 3; // -3 .. +3
  const actualIso = addDays(porIso, drift);

  const history: AssignmentEvent[] = auto
    ? []
    : [
        {
          id: `${task.id}-h1`,
          timestamp: formatDate(addDays(porIso, -45)),
          from: "Unassigned",
          to: pick(OWNERS, seed, 5).name,
          by: "System",
        },
        {
          id: `${task.id}-h2`,
          timestamp: formatDate(addDays(porIso, -20)),
          from: pick(OWNERS, seed, 5).name,
          to: primaryOwner!.name,
          by: pick(OWNERS, seed, 7).name,
        },
      ];

  // Required docs from task name heuristics
  const requiredDocs: string[] = [];
  const t = task.task.toLowerCase();
  if (t.includes("upload")) {
    const m = task.task.match(/Upload (?:the )?(.+?)(?:\s*[\-,]|$)/i);
    if (m) requiredDocs.push(m[1].trim());
  }
  if (t.includes("review")) requiredDocs.push("Review findings memo");
  if (t.includes("schedule")) requiredDocs.push("Schedule worksheet");
  if (t.includes("nudd")) requiredDocs.push("NUDD register entry");
  if (requiredDocs.length === 0) requiredDocs.push("Completion attestation");

  const submissionNotes = auto
    ? "Completed automatically by the system at phase start."
    : "Submitted with full sign-off from the extended team. Supporting artifacts uploaded to the program drive; downstream gate notified.";

  return {
    primaryOwner,
    backupOwner,
    candidateOwners,
    comments,
    history,
    porDate: formatDate(porIso),
    actualDate: formatDate(actualIso),
    deltaDays: drift,
    submissionNotes,
    requiredDocs,
    isAuto: auto,
  };
}
