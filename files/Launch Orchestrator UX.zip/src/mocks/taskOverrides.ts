import type { ScheduleTrack } from "@/lib/schedule";

export type OverrideStatus = "at-risk" | "at-risk-mitigated";

export interface LaunchStatusOverride {
  /** Which function track this override applies to. */
  track: ScheduleTrack;
  /** Status to apply to the first current-phase task on that track. */
  status: OverrideStatus;
}

/**
 * Per-platform tuned mock — each entry flips the first current-phase task on
 * the given track to R/Y so the rollup (task → gate → phase → function →
 * platform) produces a deliberate story aligned with each launch's `rag`
 * value in `src/mocks/launches.ts`. Edit here to retell the story.
 */
export const launchOverrides: Record<string, LaunchStatusOverride[]> = {
  // RED launches
  "L-2003": [{ track: "GOE", status: "at-risk" }],          // Siple Low INT NVL S1

  // AMBER launches
  "L-2002": [{ track: "NPI", status: "at-risk-mitigated" }], // Citadel NVL
  "L-2006": [{ track: "SchM", status: "at-risk-mitigated" }],// Prowler NVL CS 16
  "L-2008": [{ track: "GOE", status: "at-risk-mitigated" }], // Rapterra AMD CS 16
  "L-2013": [{ track: "NPI", status: "at-risk-mitigated" }], // AQ2426HL
  "L-2015": [{ track: "SchM", status: "at-risk-mitigated" }],// P2226H

  // GREEN launches → no overrides
};
