import { useState } from "react";
import { Eye, Pencil, Trash2, Users, Folder, Filter, Bell, Plus, UserPlus, Search, Mail } from "lucide-react";
import { PageHeader } from "@/components/shell/PageHeader";
import { DebugTab } from "@/components/curator/DebugTab";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { cn } from "@/lib/utils";
import { useIsReadOnly } from "@/lib/permissions";

/* ------------------------------- Programs ------------------------------- */

type ProgramRow = {
  organization: "CSG" | "ISG";
  lob: string;
  platform: string;
  status: "Active" | "Pending configuration";
  totalDocuments: number;
};

const programRows: ProgramRow[] = [
  { organization: "CSG", lob: "NB", platform: "Latitude 7000", status: "Active", totalDocuments: 1284 },
  { organization: "CSG", lob: "NB", platform: "Latitude 5000", status: "Active", totalDocuments: 942 },
  { organization: "CSG", lob: "NB", platform: "XPS 13", status: "Active", totalDocuments: 1103 },
  { organization: "CSG", lob: "NB", platform: "XPS 15", status: "Pending configuration", totalDocuments: 0 },
  { organization: "CSG", lob: "NB", platform: "Inspiron 14", status: "Active", totalDocuments: 612 },
  { organization: "CSG", lob: "NB", platform: "Inspiron 16", status: "Active", totalDocuments: 488 },
  { organization: "CSG", lob: "NB", platform: "Vostro 3000", status: "Pending configuration", totalDocuments: 24 },
  { organization: "CSG", lob: "NB", platform: "Alienware m18", status: "Active", totalDocuments: 731 },
  { organization: "CSG", lob: "NB", platform: "Alienware x16", status: "Active", totalDocuments: 658 },
  { organization: "CSG", lob: "NB", platform: "Dell Pro 14", status: "Pending configuration", totalDocuments: 0 },
  { organization: "CSG", lob: "DT", platform: "OptiPlex 7000", status: "Active", totalDocuments: 1421 },
  { organization: "CSG", lob: "DT", platform: "OptiPlex 5000", status: "Active", totalDocuments: 1056 },
  { organization: "CSG", lob: "DT", platform: "Precision 5000", status: "Active", totalDocuments: 873 },
  { organization: "CSG", lob: "DT", platform: "Precision 7000", status: "Active", totalDocuments: 1192 },
  { organization: "CSG", lob: "DT", platform: "Dell Pro Max 16", status: "Pending configuration", totalDocuments: 12 },
  { organization: "ISG", lob: "Server", platform: "—", status: "Pending configuration", totalDocuments: 0 },
  { organization: "ISG", lob: "Storage", platform: "—", status: "Pending configuration", totalDocuments: 0 },
  { organization: "ISG", lob: "S&S", platform: "—", status: "Pending configuration", totalDocuments: 0 },
  { organization: "ISG", lob: "Network Eq.", platform: "—", status: "Pending configuration", totalDocuments: 0 },
];

function StatusBadge({ status }: { status: ProgramRow["status"] }) {
  if (status === "Active") {
    return <Badge className="bg-success/15 text-success hover:bg-success/15 border-0">Active</Badge>;
  }
  return <Badge variant="outline" className="text-muted-foreground">Pending configuration</Badge>;
}

function ProgramsTab() {
  return (
    <div className="rounded-lg border border-border bg-card shadow-elev-1">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead className="text-subtitle-2">Business Unit</TableHead>
            <TableHead className="text-subtitle-2">LOB</TableHead>
            <TableHead className="text-subtitle-2">Platform</TableHead>
            <TableHead className="text-subtitle-2">Status</TableHead>
            <TableHead className="text-subtitle-2 text-right">Total documents</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {programRows.map((row, i) => (
            <TableRow key={`${row.organization}-${row.lob}-${row.platform}-${i}`}>
              <TableCell className="text-body-3 font-medium">{row.organization}</TableCell>
              <TableCell className="text-body-3">{row.lob}</TableCell>
              <TableCell className="text-body-3">{row.platform}</TableCell>
              <TableCell><StatusBadge status={row.status} /></TableCell>
              <TableCell className="text-body-3 text-right tabular-nums">
                {row.totalDocuments.toLocaleString()}
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
}

/* ------------------------------- Settings ------------------------------- */

type SettingsSection = "users" | "doctypes" | "rules" | "notifications";

const settingsNav: { id: SettingsSection; label: string; icon: typeof Users }[] = [
  { id: "users", label: "User Management", icon: Users },
  { id: "doctypes", label: "Document Types", icon: Folder },
  { id: "rules", label: "Classification Rules", icon: Filter },
  { id: "notifications", label: "Notifications", icon: Bell },
];

/* User Management */

type UserRole = "Super Admin" | "Admin" | "User";
type UserRow = {
  initials: string;
  name: string;
  email: string;
  role: UserRole;
  enabled: boolean;
  programs: string;
  dateAdded: string;
};

const userRows: UserRow[] = [
  { initials: "CA", name: "Chandwani, Akash", email: "akash.chandwani@dell.com", role: "Super Admin", enabled: true, programs: "All", dateAdded: "1/15/2025" },
  { initials: "SJ", name: "Sidana, Jaskaran", email: "jaskaran.sidana@dell.com", role: "Admin", enabled: true, programs: "12", dateAdded: "1/22/2025" },
  { initials: "DK", name: "Durairajan, Krishnan", email: "krishnan.durairajan@dell.com", role: "Admin", enabled: true, programs: "8", dateAdded: "2/3/2025" },
  { initials: "SV", name: "Singh, Vivek", email: "vivek.singh@dell.com", role: "User", enabled: true, programs: "3", dateAdded: "2/14/2025" },
  { initials: "JD", name: "Doe, John", email: "john.doe@dell.com", role: "User", enabled: true, programs: "5", dateAdded: "2/28/2025" },
  { initials: "AP", name: "Patel, Ashly", email: "ashly.patel@dell.com", role: "User", enabled: false, programs: "2", dateAdded: "3/4/2026" },
  { initials: "KR", name: "Kumar, Rohit", email: "rohit.kumar@dell.com", role: "Admin", enabled: true, programs: "6", dateAdded: "3/12/2026" },
  { initials: "CL", name: "Lee, Christine", email: "christine.lee@dell.com", role: "Super Admin", enabled: true, programs: "All", dateAdded: "3/20/2026" },
];

function RoleBadge({ role }: { role: UserRole }) {
  const styles =
    role === "Super Admin"
      ? "bg-destructive/10 text-destructive"
      : role === "Admin"
        ? "bg-primary/10 text-primary"
        : "bg-muted text-muted-foreground";
  return <Badge className={cn("border-0 hover:bg-transparent", styles)}>{role}</Badge>;
}

function UserManagementSection() {
  const readOnly = useIsReadOnly();
  return (
    <div className="rounded-lg border border-border bg-card p-6 shadow-elev-1 space-y-6">
      <div className="flex items-start justify-between gap-4">
        <div>
          <h2 className="text-h5">User Management</h2>
          <p className="text-body-3 text-muted-foreground mt-1">Manage users, roles, and program access</p>
        </div>
        {!readOnly && (
        <div className="flex items-center gap-3">
          <Button variant="outline" className="gap-2">
            <UserPlus className="h-4 w-4" /> Add Bulk Users
          </Button>
          <Button className="gap-2">
            <Plus className="h-4 w-4" /> Add User
          </Button>
        </div>
        )}
      </div>

      <div className="relative max-w-md">
        <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
        <Input placeholder="Search users..." className="pl-9" />
      </div>

      <Table>
        <TableHeader>
          <TableRow>
            <TableHead className="text-subtitle-2">Name</TableHead>
            <TableHead className="text-subtitle-2">Email</TableHead>
            <TableHead className="text-subtitle-2">Role</TableHead>
            <TableHead className="text-subtitle-2">Dashboard Access</TableHead>
            <TableHead className="text-subtitle-2">Programs</TableHead>
            <TableHead className="text-subtitle-2">Date Added</TableHead>
            <TableHead className="text-subtitle-2 text-right">Actions</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {userRows.map((u) => (
            <TableRow key={u.email}>
              <TableCell>
                <div className="flex items-center gap-3">
                  <div className="flex h-8 w-8 items-center justify-center rounded-full bg-muted text-caption font-medium">
                    {u.initials}
                  </div>
                  <span className="text-body-3 font-medium">{u.name}</span>
                </div>
              </TableCell>
              <TableCell className="text-body-3 text-primary">{u.email}</TableCell>
              <TableCell><RoleBadge role={u.role} /></TableCell>
              <TableCell>
                {u.enabled ? (
                  <Badge className="border-0 bg-success/15 text-success hover:bg-success/15">Enabled</Badge>
                ) : (
                  <Badge variant="outline" className="text-muted-foreground">Disabled</Badge>
                )}
              </TableCell>
              <TableCell className="text-body-3">{u.programs}</TableCell>
              <TableCell className="text-body-3">{u.dateAdded}</TableCell>
              <TableCell>
                <div className="flex items-center justify-end gap-2">
                  {!readOnly && <Button variant="ghost" size="icon" className="h-8 w-8"><Pencil className="h-4 w-4" /></Button>}
                  {!readOnly && <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive"><Trash2 className="h-4 w-4" /></Button>}
                </div>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
}

/* Document Types */

type SchemaState = "Defined" | "None";
type DocTypeRow = {
  name: string;
  displayName: string;
  lob: string;
  description: string;
  schema: SchemaState;
  rules: number;
  active: boolean;
};

const docTypeRows: DocTypeRow[] = [
  { name: "ARD", displayName: "Architecture Requirements Document", lob: "Notebook", description: "ARD outlines the key architectural requiremen...", schema: "Defined", rules: 0, active: true },
  { name: "ARD", displayName: "Architecture Requirements Document", lob: "—", description: "ARD outlines the key architectural requiremen...", schema: "Defined", rules: 4, active: false },
  { name: "Build Plan", displayName: "Build Plan", lob: "Notebook", description: "Factory build plan for product ramp.", schema: "Defined", rules: 0, active: true },
  { name: "Build Plan", displayName: "Build Plan", lob: "—", description: "Factory build plan for product ramp.", schema: "None", rules: 2, active: true },
  { name: "Cable Plan/Cable List", displayName: "—", lob: "—", description: "—", schema: "None", rules: 0, active: true },
  { name: "CIT", displayName: "Chassis Integration Test", lob: "Server", description: "—", schema: "None", rules: 0, active: true },
  { name: "Complexity Matrix", displayName: "Complexity Matrix", lob: "Notebook", description: "Complexity matrix provided by PMO.", schema: "Defined", rules: 0, active: true },
  { name: "Complexity Matrix", displayName: "Complexity Matrix", lob: "—", description: "Complexity matrix provided by PMO.", schema: "None", rules: 2, active: true },
  { name: "CSTL", displayName: "CSTL", lob: "Desktop", description: "Platform certification for shipping.", schema: "Defined", rules: 0, active: true },
  { name: "CSTL", displayName: "CSTL", lob: "—", description: "Platform certification for shipping.", schema: "None", rules: 2, active: true },
  { name: "CSTL", displayName: "CSTL", lob: "Notebook", description: "Platform certification for shipping.", schema: "Defined", rules: 0, active: true },
  { name: "CTCR", displayName: "CTCR", lob: "—", description: "—", schema: "None", rules: 0, active: true },
  { name: "Engg. NUDD", displayName: "Engineering NUDD", lob: "—", description: "JIRA NUDD issue from engineering.", schema: "None", rules: 0, active: true },
  { name: "Memory Matrix", displayName: "Memory Matrix", lob: "—", description: "Provides guidance on DIMM (Dual In-line Me...", schema: "None", rules: 3, active: true },
  { name: "Ops NUDD", displayName: "Ops NUDD", lob: "—", description: "JIRA NUDD issue from operations.", schema: "None", rules: 0, active: true },
  { name: "PRD", displayName: "Product Requirements Document", lob: "—", description: "PRD is Program Requirements Document.", schema: "Defined", rules: 3, active: true },
  { name: "PRD", displayName: "Product Requirements Document", lob: "Notebook", description: "PRD is Program Requirements Document.", schema: "Defined", rules: 0, active: true },
  { name: "Program Schedule", displayName: "Program Schedule", lob: "Desktop", description: "Program major Milestones (Phase Exits).", schema: "Defined", rules: 0, active: true },
  { name: "Slot Priority Matrix", displayName: "Slot Priority Matrix", lob: "—", description: "SPM is database for slot information.", schema: "None", rules: 3, active: true },
  { name: "Storage Matrix", displayName: "Storage Matrix", lob: "—", description: "A storage supportability matrix.", schema: "None", rules: 3, active: true },
];

function DocumentTypesSection() {
  const readOnly = useIsReadOnly();
  return (
    <div className="rounded-lg border border-border bg-card p-6 shadow-elev-1 space-y-6">
      <div className="flex items-start justify-between gap-4">
        <div>
          <h2 className="text-h5">Document Types</h2>
          <p className="text-body-3 text-muted-foreground mt-1">Define and manage your document type classifications</p>
        </div>
        {!readOnly && (
        <Button className="gap-2">
          <Plus className="h-4 w-4" /> Add Type
        </Button>
        )}
      </div>

      <Table>
        <TableHeader>
          <TableRow>
            <TableHead className="text-subtitle-2">Name</TableHead>
            <TableHead className="text-subtitle-2">Display Name</TableHead>
            <TableHead className="text-subtitle-2">LOB</TableHead>
            <TableHead className="text-subtitle-2">Description</TableHead>
            <TableHead className="text-subtitle-2">Schema</TableHead>
            <TableHead className="text-subtitle-2 text-right">Rules</TableHead>
            <TableHead className="text-subtitle-2">Status</TableHead>
            <TableHead className="text-subtitle-2 text-right">Actions</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {docTypeRows.map((row, i) => (
            <TableRow key={`${row.name}-${row.lob}-${i}`}>
              <TableCell>
                <Badge variant="outline" className="font-mono text-caption">{row.name}</Badge>
              </TableCell>
              <TableCell className="text-body-3">{row.displayName}</TableCell>
              <TableCell className="text-body-3 text-primary">{row.lob}</TableCell>
              <TableCell className="text-body-3 text-muted-foreground max-w-xs truncate">{row.description}</TableCell>
              <TableCell>
                {row.schema === "Defined" ? (
                  <Badge className="border-0 bg-success/15 text-success hover:bg-success/15">Defined</Badge>
                ) : (
                  <Badge variant="outline" className="text-muted-foreground">None</Badge>
                )}
              </TableCell>
              <TableCell className="text-body-3 text-right tabular-nums">{row.rules}</TableCell>
              <TableCell>
                {row.active ? (
                  <Badge className="border-0 bg-success/15 text-success hover:bg-success/15">Active</Badge>
                ) : (
                  <Badge variant="outline" className="text-muted-foreground">Inactive</Badge>
                )}
              </TableCell>
              <TableCell>
                <div className="flex items-center justify-end gap-1">
                  <Button variant="ghost" size="icon" className="h-8 w-8"><Eye className="h-4 w-4" /></Button>
                  {!readOnly && <Button variant="ghost" size="icon" className="h-8 w-8"><Pencil className="h-4 w-4" /></Button>}
                  {!readOnly && <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive"><Trash2 className="h-4 w-4" /></Button>}
                </div>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
}

/* Classification Rules */

type RuleType = "FILENAME" | "FOLDER";
type RuleRow = {
  documentType: string;
  type: RuleType;
  pattern: string;
  priority: number;
  confidence: number;
};

const ruleRows: RuleRow[] = [
  { documentType: "ARD", type: "FILENAME", pattern: "(?<!C)\\bARD\\b", priority: 1, confidence: 0.9 },
  { documentType: "CSTL", type: "FILENAME", pattern: "\\bCSTL\\b", priority: 1, confidence: 0.9 },
  { documentType: "Functional Plan", type: "FILENAME", pattern: "\\bFUNCTIONAL[_\\s]?PLAN\\b", priority: 1, confidence: 0.9 },
  { documentType: "Program Schedule", type: "FILENAME", pattern: "\\b(SCHEDULE|TIMELINE)\\b", priority: 1, confidence: 0.9 },
  { documentType: "Build Plan", type: "FILENAME", pattern: "\\bBUILD[_\\s]?PLAN\\b", priority: 1, confidence: 0.9 },
  { documentType: "FM-Feature Matrix", type: "FILENAME", pattern: "\\bFEATURE[_\\s]?MATRIX\\b", priority: 1, confidence: 0.9 },
  { documentType: "PRD", type: "FILENAME", pattern: "\\bPRD\\b", priority: 1, confidence: 0.9 },
  { documentType: "ID Book", type: "FILENAME", pattern: "\\bID[_\\s-]?BOOK\\b", priority: 1, confidence: 0.9 },
  { documentType: "Engineering Restrictions", type: "FILENAME", pattern: "ENGINEERING[_\\s]+RESTRICTION", priority: 1, confidence: 0.9 },
  { documentType: "GCD", type: "FILENAME", pattern: "\\bGCD\\b", priority: 1, confidence: 0.9 },
  { documentType: "Complexity Matrix", type: "FILENAME", pattern: "\\bCOMPLEXITY\\b", priority: 1, confidence: 0.9 },
  { documentType: "Ecosystem Matrix", type: "FILENAME", pattern: "\\bECOSYSTEM\\b", priority: 1, confidence: 0.9 },
  { documentType: "ARD", type: "FOLDER", pattern: "ARD", priority: 1, confidence: 0.7 },
  { documentType: "CSTL", type: "FOLDER", pattern: "CSTL", priority: 1, confidence: 0.7 },
  { documentType: "Functional Plan", type: "FOLDER", pattern: "FUNCTIONAL[_\\s]?PLAN", priority: 1, confidence: 0.7 },
  { documentType: "Program Schedule", type: "FOLDER", pattern: "(SCHEDULE|TIMELINE)", priority: 1, confidence: 0.7 },
  { documentType: "Build Plan", type: "FOLDER", pattern: "BUILD[_\\s]?PLAN", priority: 1, confidence: 0.7 },
  { documentType: "FM-Feature Matrix", type: "FOLDER", pattern: "FEATURE[_\\s]?MATRIX", priority: 1, confidence: 0.7 },
  { documentType: "PRD", type: "FOLDER", pattern: "PRD", priority: 1, confidence: 0.7 },
  { documentType: "ID Book", type: "FOLDER", pattern: "ID[_\\s-]?BOOK", priority: 1, confidence: 0.7 },
  { documentType: "Engineering Restrictions", type: "FOLDER", pattern: "ENGINEERING[_\\s]+RESTRICTION", priority: 1, confidence: 0.7 },
  { documentType: "GCD", type: "FOLDER", pattern: "GCD", priority: 1, confidence: 0.7 },
  { documentType: "Complexity Matrix", type: "FOLDER", pattern: "COMPLEXITY", priority: 1, confidence: 0.65 },
  { documentType: "Ecosystem Matrix", type: "FOLDER", pattern: "ECOSYSTEM", priority: 1, confidence: 0.65 },
];

function ClassificationRulesSection() {
  const readOnly = useIsReadOnly();
  return (
    <div className="rounded-lg border border-border bg-card p-6 shadow-elev-1 space-y-6">
      <div className="flex items-start justify-between gap-4">
        <div>
          <h2 className="text-h5">Classification Rules</h2>
          <p className="text-body-3 text-muted-foreground mt-1">Configure pattern-based rules for automatic document classification</p>
        </div>
        <div className="flex items-center gap-3">
          <Button variant="outline">All Document Types</Button>
          {!readOnly && (
          <Button className="gap-2">
            <Plus className="h-4 w-4" /> Add Rule
          </Button>
          )}
        </div>
      </div>

      <Table>
        <TableHeader>
          <TableRow>
            <TableHead className="text-subtitle-2">Document Type</TableHead>
            <TableHead className="text-subtitle-2">Type</TableHead>
            <TableHead className="text-subtitle-2">Pattern</TableHead>
            <TableHead className="text-subtitle-2 text-right">Priority</TableHead>
            <TableHead className="text-subtitle-2 text-right">Confidence</TableHead>
            <TableHead className="text-subtitle-2">Status</TableHead>
            <TableHead className="text-subtitle-2 text-right">Actions</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {ruleRows.map((r, i) => (
            <TableRow key={`${r.documentType}-${r.type}-${i}`}>
              <TableCell>
                <Badge variant="outline" className="font-mono text-caption">{r.documentType}</Badge>
              </TableCell>
              <TableCell>
                <Badge className="border-0 bg-accent text-accent-foreground hover:bg-accent">{r.type}</Badge>
              </TableCell>
              <TableCell className="font-mono text-caption text-primary">{r.pattern}</TableCell>
              <TableCell className="text-body-3 text-right tabular-nums">{r.priority}</TableCell>
              <TableCell className="text-body-3 text-right tabular-nums">{r.confidence}</TableCell>
              <TableCell>
                <Badge className="border-0 bg-success/15 text-success hover:bg-success/15">Active</Badge>
              </TableCell>
              <TableCell>
                <div className="flex items-center justify-end gap-1">
                  <Button variant="ghost" size="icon" className="h-8 w-8"><Eye className="h-4 w-4" /></Button>
                  {!readOnly && <Button variant="ghost" size="icon" className="h-8 w-8"><Pencil className="h-4 w-4" /></Button>}
                  {!readOnly && <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive"><Trash2 className="h-4 w-4" /></Button>}
                </div>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
}

/* Notifications */

function NotificationsSection() {
  const readOnly = useIsReadOnly();
  const [unit, setUnit] = useState<"hours" | "days">("days");
  const [value, setValue] = useState(3);
  const totalHours = unit === "days" ? value * 24 : value;

  return (
    <div className="rounded-lg border border-border bg-card p-6 shadow-elev-1 space-y-6">
      <div>
        <h2 className="text-h5">Notifications</h2>
        <p className="text-body-3 text-muted-foreground mt-1">
          Trigger email notifications for change-detection results within a time window
        </p>
      </div>

      <div className="space-y-3">
        <div>
          <h3 className="text-subtitle-2">Lookback Window</h3>
          <p className="text-body-3 text-muted-foreground">
            Select how far back to look for change-detection runs when sending notifications.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <Input
            type="number"
            min={1}
            value={value}
            onChange={(e) => setValue(Math.max(1, Number(e.target.value) || 1))}
            className="w-20"
            disabled={readOnly}
          />
          <div className="inline-flex rounded-md border border-border overflow-hidden">
            <button
              type="button"
              disabled={readOnly}
              onClick={() => setUnit("hours")}
              className={cn(
                "px-4 py-2 text-button-2 disabled:opacity-60 disabled:cursor-not-allowed",
                unit === "hours" ? "bg-primary text-primary-foreground" : "bg-card text-foreground",
              )}
            >
              Hours
            </button>
            <button
              type="button"
              disabled={readOnly}
              onClick={() => setUnit("days")}
              className={cn(
                "px-4 py-2 text-button-2 border-l border-border disabled:opacity-60 disabled:cursor-not-allowed",
                unit === "days" ? "bg-primary text-primary-foreground" : "bg-card text-foreground",
              )}
            >
              Days
            </button>
          </div>
        </div>

        <p className="text-body-3 text-muted-foreground">
          Notifications will cover the last <span className="font-medium text-foreground">{value} {unit}</span>
          {unit === "days" && <> ({totalHours} hours)</>}
        </p>
      </div>

      {!readOnly && (
      <Button className="gap-2">
        <Mail className="h-4 w-4" /> Send Notifications
      </Button>
      )}
    </div>
  );
}

/* Settings tab shell */

function SettingsTab() {
  const [section, setSection] = useState<SettingsSection>("users");

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-h4">Settings</h2>
        <p className="text-body-3 text-muted-foreground mt-1">
          Manage document types, classification rules, and user access
        </p>
      </div>

      <div className="flex gap-6">
        <nav className="w-64 shrink-0 space-y-1">
          {settingsNav.map((item) => {
            const Icon = item.icon;
            const active = section === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => setSection(item.id)}
                className={cn(
                  "flex w-full items-center gap-3 rounded-md px-3 py-2 text-body-3 transition-colors",
                  active
                    ? "bg-primary/10 text-primary font-medium"
                    : "text-foreground hover:bg-muted",
                )}
              >
                <Icon className="h-4 w-4" />
                {item.label}
              </button>
            );
          })}
        </nav>

        <div className="flex-1 min-w-0">
          {section === "users" && <UserManagementSection />}
          {section === "doctypes" && <DocumentTypesSection />}
          {section === "rules" && <ClassificationRulesSection />}
          {section === "notifications" && <NotificationsSection />}
        </div>
      </div>
    </div>
  );
}

/* ----------------------------------------------------------------------- */

export default function CuratorPage() {
  return (
    <div className="space-y-8">
      <PageHeader
        eyebrow="Knowledge"
        title="Doc and data curator"
        breadcrumbs={[{ label: "Doc and data curator" }]}
      />

      <Tabs defaultValue="programs" className="w-full">
        <TabsList>
          <TabsTrigger value="programs">Programs</TabsTrigger>
          <TabsTrigger value="settings">Settings</TabsTrigger>
          <TabsTrigger value="debug">Debug</TabsTrigger>
        </TabsList>

        <TabsContent value="programs" className="mt-6">
          <ProgramsTab />
        </TabsContent>
        <TabsContent value="settings" className="mt-6">
          <SettingsTab />
        </TabsContent>
        <TabsContent value="debug" className="mt-6">
          <DebugTab />
        </TabsContent>
      </Tabs>
    </div>
  );
}
