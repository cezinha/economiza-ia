import { useRole } from "@/contexts/RoleContext";
import { SuperadminOverview } from "./overviews/SuperadminOverview";
import { ExecutiveOverview } from "./overviews/ExecutiveOverview";
import { AdminOverview } from "./overviews/AdminOverview";
import { UserOverview } from "./overviews/UserOverview";

export default function Index() {
  const { role } = useRole();
  switch (role) {
    case "superadmin": return <SuperadminOverview />;
    case "executive": return <ExecutiveOverview />;
    case "admin": return <AdminOverview />;
    case "user": return <UserOverview />;
  }
}
