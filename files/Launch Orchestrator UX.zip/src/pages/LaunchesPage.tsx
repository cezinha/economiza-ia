import { PageHeader } from "@/components/shell/PageHeader";
import { ScheduleDrilldown } from "@/components/dashboard/ScheduleDrilldown";
import { DdsGrid, DdsCol } from "@/components/layout/DdsGrid";

export default function LaunchesPage() {
  return (
    <div className="space-y-8">
      <PageHeader
        eyebrow="Portfolio"
        title="OLP schedule"
        breadcrumbs={[{ label: "OLP schedule" }]}
      />
      <DdsGrid>
        <DdsCol span={12} spanM={6} spanS={6} spanXs={2}><ScheduleDrilldown /></DdsCol>
      </DdsGrid>
    </div>
  );
}
