import { useEffect, useState } from "react";
import { useSearchParams } from "react-router-dom";
import { PageHeader } from "@/components/shell/PageHeader";
import { NuddTable } from "@/components/dashboard/NuddTable";
import { NuddSummary } from "@/components/dashboard/NuddSummary";
import { NuddDetailDrawer } from "@/components/dashboard/NuddDetailDrawer";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { NUDDS, type NuddRow } from "@/mocks/nudds";

export default function RisksPage() {
  const [searchParams, setSearchParams] = useSearchParams();
  const [selected, setSelected] = useState<NuddRow | null>(null);
  const [open, setOpen] = useState(false);
  const tab = searchParams.get("tab") === "table" ? "table" : "summary";
  const nuddParam = searchParams.get("nudd");

  useEffect(() => {
    if (!nuddParam) return;
    const row = NUDDS.find((n) => n.id === nuddParam);
    if (row) {
      setSelected(row);
      setOpen(true);
    }
  }, [nuddParam]);

  const openRow = (row: NuddRow) => {
    setSelected(row);
    setOpen(true);
  };

  const handleOpenChange = (next: boolean) => {
    setOpen(next);
    if (!next && nuddParam) {
      const np = new URLSearchParams(searchParams);
      np.delete("nudd");
      setSearchParams(np, { replace: true });
    }
  };

  const setTab = (value: string) => {
    const next = new URLSearchParams(searchParams);
    if (value === "summary") next.delete("tab");
    else next.set("tab", value);
    setSearchParams(next, { replace: true });
  };

  return (
    <div className="space-y-8">
      <PageHeader eyebrow="Risk register" title="NUDDs" breadcrumbs={[{ label: "NUDDs" }]} />
      <Tabs value={tab} onValueChange={setTab} className="space-y-6">
        <TabsList>
          <TabsTrigger value="summary">Summary dashboard</TabsTrigger>
          <TabsTrigger value="table">Table view</TabsTrigger>
        </TabsList>
        <TabsContent value="summary">
          <NuddSummary onOpenRow={openRow} />
        </TabsContent>
        <TabsContent value="table">
          <NuddTable onOpenRow={openRow} />
        </TabsContent>
      </Tabs>
      <NuddDetailDrawer row={selected} open={open} onOpenChange={handleOpenChange} />
    </div>
  );
}
