import { useSearchParams } from "react-router-dom";
import { PageHeader } from "@/components/shell/PageHeader";
import { TaskQueue } from "@/components/dashboard/TaskQueue";
import { PlatformTasks } from "@/components/dashboard/PlatformTasks";
import { DdsGrid, DdsCol } from "@/components/layout/DdsGrid";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { useRole } from "@/contexts/RoleContext";

export default function TasksPage() {
  const { role } = useRole();
  const isExecutive = role === "executive";
  const [searchParams, setSearchParams] = useSearchParams();
  const tab = isExecutive
    ? "platform"
    : searchParams.get("tab") === "platform"
    ? "platform"
    : "queue";
  const launchParam = searchParams.get("launch") ?? undefined;
  const innerParam = searchParams.get("inner");
  const initialInnerTab =
    innerParam === "nudds" || innerParam === "exit" || innerParam === "tasks" ? innerParam : undefined;
  const initialPhase = searchParams.get("phase") ?? undefined;
  const initialGate = searchParams.get("gate") ?? undefined;

  const setTab = (value: string) => {
    const next = new URLSearchParams(searchParams);
    if (value === "queue") {
      next.delete("tab");
      next.delete("launch");
    } else {
      next.set("tab", "platform");
    }
    setSearchParams(next, { replace: true });
  };

  const setLaunch = (id: string) => {
    const next = new URLSearchParams(searchParams);
    next.set("tab", "platform");
    next.set("launch", id);
    setSearchParams(next, { replace: true });
  };

  return (
    <div className="space-y-8">
      <PageHeader
        eyebrow="Workflow"
        title="My tasks"
        breadcrumbs={[{ label: "My tasks" }]}
      />
      <DdsGrid>
        <DdsCol span={12} spanM={6} spanS={6} spanXs={2}>
          {isExecutive ? (
            <PlatformTasks
              launchId={launchParam}
              onChange={setLaunch}
              initialInnerTab={initialInnerTab}
              initialPhase={initialPhase}
              initialGate={initialGate}
            />
          ) : (
            <Tabs value={tab} onValueChange={setTab} className="w-full">
              <TabsList>
                <TabsTrigger value="queue">Action queue</TabsTrigger>
                <TabsTrigger value="platform">By platform</TabsTrigger>
              </TabsList>
              <TabsContent value="queue" className="pt-4">
                <TaskQueue />
              </TabsContent>
              <TabsContent value="platform" className="pt-4">
                <PlatformTasks launchId={launchParam} onChange={setLaunch} initialInnerTab={initialInnerTab} initialPhase={initialPhase} initialGate={initialGate} />
              </TabsContent>
            </Tabs>
          )}
        </DdsCol>
      </DdsGrid>
    </div>
  );
}
