import { PageHeader } from "@/components/shell/PageHeader";
import { UserPlus, ClipboardCheck, Plug } from "lucide-react";
import { DdsGrid, DdsCol } from "@/components/layout/DdsGrid";
import { KpiCard } from "@/components/dashboard/KpiCard";
import { CurrentPhaseDonut } from "@/components/dashboard/CurrentPhaseDonut";
import { PhaseStatusCard } from "@/components/dashboard/PhaseStatusCard";
import { TaskQueue } from "@/components/dashboard/TaskQueue";
import { ActivityFeed } from "@/components/dashboard/ActivityFeed";
import { HomeWorkspace, HomeStack, HomeBottomRow } from "@/components/dashboard/HomeWorkspace";

export function AdminOverview() {
  return (
    <div className="space-y-8">
      <PageHeader
        eyebrow="Admin"
        title="Home"
      />
      <HomeWorkspace>
        <HomeStack>
          <DdsGrid>
            <DdsCol span={4} spanM={2} spanS={3} spanXs={2}>
              <KpiCard label="Active users" value={48} icon={UserPlus} />
            </DdsCol>
            <DdsCol span={4} spanM={2} spanS={3} spanXs={2}>
              <KpiCard label="Pending approvals" value={6} icon={ClipboardCheck} tone="warning" />
            </DdsCol>
            <DdsCol span={4} spanM={2} spanS={3} spanXs={2}>
              <KpiCard label="Connected integrations" value={3} icon={Plug} tone="success" />
            </DdsCol>
          </DdsGrid>
          <CurrentPhaseDonut />
          <PhaseStatusCard />
          <HomeBottomRow>
            <TaskQueue />
            <ActivityFeed />
          </HomeBottomRow>
        </HomeStack>
      </HomeWorkspace>
    </div>
  );
}

