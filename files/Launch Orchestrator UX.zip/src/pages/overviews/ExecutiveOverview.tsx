import { PageHeader } from "@/components/shell/PageHeader";
import { PortfolioMetrics } from "@/components/dashboard/PortfolioMetrics";
import { CurrentPhaseDonut } from "@/components/dashboard/CurrentPhaseDonut";
import { PhaseStatusCard } from "@/components/dashboard/PhaseStatusCard";
import { ActivityFeed } from "@/components/dashboard/ActivityFeed";
import { HomeWorkspace, HomeStack, HomeBottomRow } from "@/components/dashboard/HomeWorkspace";

export function ExecutiveOverview() {
  return (
    <div className="space-y-8">
      <PageHeader
        eyebrow="Executive view"
        title="Home"
      />
      <HomeWorkspace>
        <HomeStack>
          <PortfolioMetrics />
          <CurrentPhaseDonut />
          <PhaseStatusCard />
          <HomeBottomRow>
            <ActivityFeed />
          </HomeBottomRow>
        </HomeStack>
      </HomeWorkspace>
    </div>
  );
}
