import { PageHeader } from "@/components/shell/PageHeader";
import { HomeWorkspace, HomeStack, HomeBottomRow } from "@/components/dashboard/HomeWorkspace";
import { PortfolioMetrics } from "@/components/dashboard/PortfolioMetrics";
import { CurrentPhaseDonut } from "@/components/dashboard/CurrentPhaseDonut";
import { PhaseStatusCard } from "@/components/dashboard/PhaseStatusCard";
import { TaskQueue } from "@/components/dashboard/TaskQueue";
import { ActivityFeed } from "@/components/dashboard/ActivityFeed";

export function SuperadminOverview() {
  return (
    <div className="space-y-8">
      <PageHeader
        eyebrow="Superadmin · Single pane of glass"
        title="Home"
      />
      <HomeWorkspace>
        <HomeStack>
          <PortfolioMetrics />
          <CurrentPhaseDonut />
          <PhaseStatusCard />
          <HomeBottomRow>
            <TaskQueue />
            <ActivityFeed />
          </HomeBottomRow>
        </HomeStack>
      </HomeWorkspace>
    </div>
  );
}
