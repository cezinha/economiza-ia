import { PageHeader } from "@/components/shell/PageHeader";
import { TaskQueue } from "@/components/dashboard/TaskQueue";
import { ActivityFeed } from "@/components/dashboard/ActivityFeed";
import { KpiCard } from "@/components/dashboard/KpiCard";
import { CheckSquare, Clock, Rocket } from "lucide-react";
import { DdsGrid, DdsCol } from "@/components/layout/DdsGrid";
import { CurrentPhaseDonut } from "@/components/dashboard/CurrentPhaseDonut";
import { PhaseStatusCard } from "@/components/dashboard/PhaseStatusCard";
import { HomeWorkspace, HomeStack, HomeBottomRow } from "@/components/dashboard/HomeWorkspace";

export function UserOverview() {
  return (
    <div className="space-y-8">
      <PageHeader
        eyebrow="My work"
        title="Home"
      />
      <HomeWorkspace>
        <HomeStack>
          <DdsGrid>
            <DdsCol span={4} spanM={2} spanS={3} spanXs={2}>
              <KpiCard label="Open tasks" value={5} icon={CheckSquare} />
            </DdsCol>
            <DdsCol span={4} spanM={2} spanS={3} spanXs={2}>
              <KpiCard label="Due this week" value={3} icon={Clock} tone="warning" />
            </DdsCol>
            <DdsCol span={4} spanM={2} spanS={3} spanXs={2}>
              <KpiCard label="Launches I'm on" value={4} icon={Rocket} />
            </DdsCol>
          </DdsGrid>
          <CurrentPhaseDonut />
          <PhaseStatusCard />
          <HomeBottomRow>
            <TaskQueue />
            <ActivityFeed />
          </HomeBottomRow>
        </HomeStack>
      </HomeWorkspace>
    </div>
  );
}
