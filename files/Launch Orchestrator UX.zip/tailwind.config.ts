import type { Config } from "tailwindcss";

/**
 * DDS-aligned Tailwind config.
 *
 * Spacing scale below is restricted to multiples of 4px (Dell baseline grid).
 * The shadcn defaults still resolve via Tailwind's built-ins where present;
 * authors should avoid non-4px utilities (0.5, 1.5, 2.5, 3.5) inside the
 * dashboard surface — this is enforced by src/test/dds-grid.test.ts.
 *
 * Breakpoints below match the DDS responsive table verbatim.
 */
export default {
  darkMode: ["class"],
  content: ["./pages/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}", "./app/**/*.{ts,tsx}", "./src/**/*.{ts,tsx}"],
  prefix: "",
  theme: {
    /* Replace default screens with DDS breakpoints (verbatim from spec) */
    screens: {
      xs: "320px",   // XS: 320–479
      s:  "480px",   // S:  480–767
      m:  "768px",   // M:  768–1023
      l:  "1024px",  // L:  1024–1365
      xl: "1366px",  // XL: 1366–1583
      "2xl": "1584px", // 2XL: 1584–1919
      "3xl": "1920px", // 3XL: 1920–2559
      "4xl": "2560px", // 4XL: 2560–3839
      "5xl": "3840px", // 5XL: 3840+
      // Legacy aliases used by stock shadcn components — kept to avoid breakage.
      sm: "480px",
      md: "768px",
      lg: "1024px",
    },
    container: {
      center: true,
      padding: "var(--dds-margin)",
      screens: { "2xl": "1584px" },
    },
    extend: {
      colors: {
        border: "hsl(var(--border))",
        input: "hsl(var(--input))",
        ring: "hsl(var(--ring))",
        background: "hsl(var(--background))",
        foreground: "hsl(var(--foreground))",
        surface: {
          DEFAULT: "hsl(var(--surface))",
          raised: "hsl(var(--surface-raised))",
        },
        primary: {
          DEFAULT: "hsl(var(--primary))",
          hover: "hsl(var(--primary-hover))",
          foreground: "hsl(var(--primary-foreground))",
        },
        navy: {
          DEFAULT: "hsl(var(--navy))",
          foreground: "hsl(var(--navy-foreground))",
        },
        secondary: {
          DEFAULT: "hsl(var(--secondary))",
          foreground: "hsl(var(--secondary-foreground))",
        },
        destructive: {
          DEFAULT: "hsl(var(--destructive))",
          foreground: "hsl(var(--destructive-foreground))",
        },
        muted: {
          DEFAULT: "hsl(var(--muted))",
          foreground: "hsl(var(--muted-foreground))",
        },
        accent: {
          DEFAULT: "hsl(var(--accent))",
          foreground: "hsl(var(--accent-foreground))",
        },
        success: {
          DEFAULT: "hsl(var(--success))",
          foreground: "hsl(var(--success-foreground))",
        },
        warning: {
          DEFAULT: "hsl(var(--warning))",
          foreground: "hsl(var(--warning-foreground))",
        },
        danger: {
          DEFAULT: "hsl(var(--danger))",
          foreground: "hsl(var(--danger-foreground))",
        },
        info: {
          DEFAULT: "hsl(var(--info))",
          foreground: "hsl(var(--info-foreground))",
        },
        risk: {
          low: "hsl(var(--risk-low))",
          "low-foreground": "hsl(var(--risk-low-foreground))",
          medium: "hsl(var(--risk-medium))",
          "medium-foreground": "hsl(var(--risk-medium-foreground))",
          high: "hsl(var(--risk-high))",
          "high-foreground": "hsl(var(--risk-high-foreground))",
        },
        breadcrumb: {
          "hover-bg": "hsl(var(--breadcrumb-hover-bg))",
          "link-hover": "hsl(var(--breadcrumb-link-hover))",
          "icon-hover": "hsl(var(--breadcrumb-icon-hover))",
          "focus-ring": "hsl(var(--breadcrumb-focus-ring))",
        },
        status: {
          completed: "hsl(var(--status-completed))",
          "on-track": "hsl(var(--status-on-track))",
          "at-risk-mitigated": "hsl(var(--status-at-risk-mitigated))",
          "at-risk": "hsl(var(--status-at-risk))",
          "not-started": "hsl(var(--status-not-started))",
        },
        milestone: {
          "phase-exit": "hsl(var(--milestone-phase-exit))",
          key: "hsl(var(--milestone-key))",
        },
        popover: {
          DEFAULT: "hsl(var(--popover))",
          foreground: "hsl(var(--popover-foreground))",
        },
        card: {
          DEFAULT: "hsl(var(--card))",
          foreground: "hsl(var(--card-foreground))",
        },
        sidebar: {
          DEFAULT: "hsl(var(--sidebar-background))",
          foreground: "hsl(var(--sidebar-foreground))",
          primary: "hsl(var(--sidebar-primary))",
          "primary-foreground": "hsl(var(--sidebar-primary-foreground))",
          accent: "hsl(var(--sidebar-accent))",
          "accent-foreground": "hsl(var(--sidebar-accent-foreground))",
          active: "hsl(var(--sidebar-active))",
          "active-foreground": "hsl(var(--sidebar-active-foreground))",
          border: "hsl(var(--sidebar-border))",
          ring: "hsl(var(--sidebar-ring))",
        },
      },
      /* DDS-derived spacing tokens — every value is a multiple of 4px */
      spacing: {
        gutter: "var(--dds-gutter)",
        page: "var(--dds-margin)",
        section: "32px",
        18: "72px",
      },
      gap: {
        gutter: "var(--dds-gutter)",
      },
      gridTemplateColumns: {
        dds: "repeat(var(--dds-cols), minmax(0, 1fr))",
        "dds-12": "repeat(12, minmax(0, 1fr))",
        "dds-6": "repeat(6, minmax(0, 1fr))",
        "dds-2": "repeat(2, minmax(0, 1fr))",
      },
      borderRadius: {
        lg: "var(--radius)",
        md: "calc(var(--radius) - 2px)",
        sm: "calc(var(--radius) - 4px)",
      },
      /* DDS elevation tokens — 4 levels × 3 light directions, plus inset.
         Use ONE direction per screen (default = bottom). */
      boxShadow: {
        "elev-1": "var(--elevation-1)",
        "elev-2": "var(--elevation-2)",
        "elev-3": "var(--elevation-3)",
        "elev-4": "var(--elevation-4)",
        "elev-left-1": "var(--elevation-left-1)",
        "elev-left-2": "var(--elevation-left-2)",
        "elev-left-3": "var(--elevation-left-3)",
        "elev-left-4": "var(--elevation-left-4)",
        "elev-right-1": "var(--elevation-right-1)",
        "elev-right-2": "var(--elevation-right-2)",
        "elev-right-3": "var(--elevation-right-3)",
        "elev-right-4": "var(--elevation-right-4)",
        "elev-inset": "var(--elevation-inset)",
      },
      /* DDS Typography ramp — base = <1024px (responsive ramp).
         Sizes ≥1024px (default ramp) are upgraded via media-query
         utilities in src/index.css. */
      fontFamily: {
        sans: [
          "Roboto",
          '"Helvetica Neue"',
          "Arial",
          '"Microsoft YaHei"',
          '"Hiragino Kaku Gothic"',
          '"Malgun Gothic"',
          '"Noto Sans"',
          "sans-serif",
        ],
      },
      fontSize: {
        "display-1":  ["3.5rem",  { lineHeight: "68px", fontWeight: "300" }],
        "display-2":  ["3rem",    { lineHeight: "56px", fontWeight: "300" }],
        "display-3":  ["2.5rem",  { lineHeight: "48px", fontWeight: "300" }],
        h1:           ["2.5rem",  { lineHeight: "48px", fontWeight: "300" }],
        h2:           ["2rem",    { lineHeight: "40px", fontWeight: "300" }],
        h3:           ["1.5rem",  { lineHeight: "32px", fontWeight: "400" }],
        h4:           ["1.25rem", { lineHeight: "28px", fontWeight: "400" }],
        h5:           ["1.25rem", { lineHeight: "28px", fontWeight: "400" }],
        h6:           ["1rem",    { lineHeight: "24px", fontWeight: "500" }],
        "subtitle-1": ["1.5rem",  { lineHeight: "36px", fontWeight: "400" }],
        "subtitle-2": ["1rem",    { lineHeight: "24px", fontWeight: "500" }],
        "body-1":     ["1.5rem",  { lineHeight: "36px", fontWeight: "300" }],
        "body-2":     ["1rem",    { lineHeight: "24px", fontWeight: "400" }],
        "body-3":     ["0.875rem",{ lineHeight: "20px", fontWeight: "400" }],
        "button-1":   ["1rem",    { lineHeight: "24px", fontWeight: "500" }],
        "button-2":   ["0.875rem",{ lineHeight: "24px", fontWeight: "500" }],
        caption:      ["0.75rem", { lineHeight: "20px", fontWeight: "400" }],
      },
      keyframes: {
        "accordion-down": { from: { height: "0" }, to: { height: "var(--radix-accordion-content-height)" } },
        "accordion-up": { from: { height: "var(--radix-accordion-content-height)" }, to: { height: "0" } },
        "fade-in": { from: { opacity: "0", transform: "translateY(4px)" }, to: { opacity: "1", transform: "translateY(0)" } },
      },
      animation: {
        "accordion-down": "accordion-down 0.2s ease-out",
        "accordion-up": "accordion-up 0.2s ease-out",
        "fade-in": "fade-in 0.25s ease-out",
      },
    },
  },
  plugins: [require("tailwindcss-animate")],
} satisfies Config;
