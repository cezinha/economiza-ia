"""Service status endpoint (no database; mirrors SharePoint connector `/status` shape partially)."""

from datetime import datetime, timezone
from typing import Literal

from fastapi import APIRouter
from pydantic import BaseModel

router = APIRouter(prefix="/status", tags=["status"])


class StatusResponse(BaseModel):
    """Lightweight status payload for orchestration and dashboards."""

    service: str
    timestamp: datetime
    environment: str
    backend: Literal["http", "memory"]
    regrello_base_url: str
    regrello_workspace_id: str
    workflow_template_id: int


@router.get("", response_model=StatusResponse)
async def get_status() -> StatusResponse:
    """Return non-secret connector configuration and identity."""

    from app.config import settings

    return StatusResponse(
        service="regrello-connector",
        timestamp=datetime.now(timezone.utc),
        environment=settings.environment,
        backend=settings.regrello_connector_backend,
        regrello_base_url=settings.regrello_base_url,
        regrello_workspace_id=settings.regrello_workspace_id,
        workflow_template_id=settings.regrello_workflow_template_id,
    )
