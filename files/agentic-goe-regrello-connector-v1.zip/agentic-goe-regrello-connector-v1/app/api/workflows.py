"""Workflow endpoints backed by a pluggable ``WorkflowBackend`` (HTTP or memory fixtures)."""

from __future__ import annotations

import base64
import logging
from typing import Annotated, Any

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel, Field

from app.workflows.deps import get_workflow_backend
from app.workflows.port import WorkflowBackend

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/workflows", tags=["workflows"])


class DocumentPayload(BaseModel):
    """Binary document passed as base64 for JSON APIs."""

    filename: str
    content_base64: str = Field(
        ...,
        description="File contents, base64-encoded",
    )


class CreateWorkflowRequest(BaseModel):
    """Request body aligned with the workflow backend ``create_workflow``."""

    field_instances: list[dict[str, Any]]
    documents: list[DocumentPayload] | None = None
    workflow_template_id: int | None = None
    start_condition: str = "START_IMMEDIATELY"
    tag_ids: list[str] | None = None


class CreateWorkflowResponse(BaseModel):
    workflow_id: str
    document_ids: list[str]


WorkflowBackendDep = Annotated[WorkflowBackend, Depends(get_workflow_backend)]


def _decode_documents(docs: list[DocumentPayload] | None) -> list[tuple[str, bytes]] | None:
    if not docs:
        return None
    out: list[tuple[str, bytes]] = []
    for d in docs:
        try:
            raw = base64.b64decode(d.content_base64, validate=True)
        except (ValueError, TypeError) as e:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Invalid base64 for document {d.filename!r}: {e}",
            ) from e
        out.append((d.filename, raw))
    return out


@router.post("", response_model=CreateWorkflowResponse)
async def create_workflow_route(
    backend: WorkflowBackendDep,
    body: CreateWorkflowRequest,
) -> CreateWorkflowResponse:
    """Create a workflow from a template using GraphQL (`createWorkflowFromTemplate`)."""

    documents = _decode_documents(body.documents)
    try:
        result = await backend.create_workflow(
            field_instances=body.field_instances,
            documents=documents,
            workflow_template_id=body.workflow_template_id,
            start_condition=body.start_condition,
            tag_ids=body.tag_ids,
        )
    except (RuntimeError, ValueError) as e:
        logger.exception("Workflow creation failed")
        raise HTTPException(status_code=status.HTTP_502_BAD_GATEWAY, detail=str(e)) from e

    return CreateWorkflowResponse(
        workflow_id=str(result["workflow_id"]),
        document_ids=[str(x) for x in result.get("document_ids", [])],
    )


@router.get("/template/fields")
async def workflow_template_fields_route(
    backend: WorkflowBackendDep,
    workflow_template_id: int | None = None,
) -> list[dict[str, Any]]:
    """Return normalized template fields (`WorkflowTemplateFields` query)."""

    try:
        return await backend.get_workflow_template_fields(
            workflow_template_id=workflow_template_id,
        )
    except (RuntimeError, ValueError) as e:
        logger.exception("Workflow template fields failed")
        raise HTTPException(
            status_code=status.HTTP_502_BAD_GATEWAY,
            detail=str(e),
        ) from e


@router.get("/template/field-metadata")
async def workflow_template_field_metadata_route(
    backend: WorkflowBackendDep,
    workflow_template_id: int | None = None,
) -> list[dict[str, Any]]:
    """Return human-readable field metadata for a workflow template."""

    try:
        return await backend.get_workflow_template_field_metadata(
            workflow_template_id=workflow_template_id,
        )
    except (RuntimeError, ValueError) as e:
        logger.exception("Workflow template field metadata failed")
        raise HTTPException(
            status_code=status.HTTP_502_BAD_GATEWAY,
            detail=str(e),
        ) from e


@router.get("/{workflow_id}/status")
async def workflow_status_route(
    backend: WorkflowBackendDep,
    workflow_id: str,
    workflow_template_id: int | None = None,
) -> dict[str, Any]:
    """Return workflow status via GraphQL (`WorkflowStatus` query)."""

    try:
        return await backend.get_workflow_status(
            workflow_id,
            workflow_template_id=workflow_template_id,
        )
    except (RuntimeError, ValueError) as e:
        logger.exception("Workflow status failed")
        raise HTTPException(
            status_code=status.HTTP_502_BAD_GATEWAY,
            detail=str(e),
        ) from e
