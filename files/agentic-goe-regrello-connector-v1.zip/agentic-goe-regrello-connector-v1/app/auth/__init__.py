"""Authentication helpers.

OAuth2 client credentials for Regrello are handled inside `regrello.RegrelloClient`
(see `app/graphql/client.py`). This package is reserved for parity with other connectors.
"""
