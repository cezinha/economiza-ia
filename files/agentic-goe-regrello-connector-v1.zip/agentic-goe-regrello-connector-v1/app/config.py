"""Configuration for the Regrello connector service."""

from __future__ import annotations

import os
from pathlib import Path
from typing import Literal, Self

from pydantic import Field, model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

# Package layout: app/config.py -> connector root is parent of `app/` (next to pyproject.toml).
_CONNECTOR_ROOT = Path(__file__).resolve().parent.parent


def _settings_env_file() -> tuple[str, ...] | None:
    """`.env` paths for runtime; disabled when tests set REGRELLO_CONNECTOR_DISABLE_DOTENV."""
    if os.environ.get("REGRELLO_CONNECTOR_DISABLE_DOTENV", "").lower() in ("1", "true", "yes"):
        return None
    return (
        str(Path.cwd() / ".env"),
        str(_CONNECTOR_ROOT / ".env"),
    )


class Settings(BaseSettings):
    """Application settings loaded from environment variables."""

    model_config = SettingsConfigDict(
        case_sensitive=False,
        extra="allow",
        # cwd first, connector root second: pydantic merges env files with update(), so connector
        # root wins for duplicate keys. OS env still overrides dotenv (default source order).
        env_file=_settings_env_file(),
        env_file_encoding="utf-8",
    )

    environment: str = Field(default="local", validation_alias="REGRELLO_CONNECTOR_ENVIRONMENT")
    service_host: str = Field(default="0.0.0.0", validation_alias="REGRELLO_CONNECTOR_SERVICE_HOST")
    service_port: int = Field(default=8005, validation_alias="REGRELLO_CONNECTOR_SERVICE_PORT")
    log_level: str = Field(default="INFO", validation_alias="REGRELLO_CONNECTOR_LOG_LEVEL")

    regrello_connector_backend: Literal["http", "memory"] = Field(
        default="http",
        validation_alias="REGRELLO_CONNECTOR_BACKEND",
    )
    regrello_connector_memory_fixtures_path: Path | None = Field(
        default=None,
        validation_alias="REGRELLO_CONNECTOR_MEMORY_FIXTURES_PATH",
    )

    regrello_base_url: str = Field(default="", validation_alias="REGRELLO_BASE_URL")
    regrello_workspace_id: str = Field(default="", validation_alias="REGRELLO_WORKSPACE_ID")
    regrello_client_id: str = Field(default="", validation_alias="REGRELLO_CLIENT_ID")
    regrello_client_secret: str = Field(default="", validation_alias="REGRELLO_CLIENT_SECRET")
    regrello_workflow_template_id: int = Field(
        default=253,
        validation_alias="REGRELLO_WORKFLOW_TEMPLATE_ID",
    )
    regrello_verify_ssl: bool = Field(default=True, validation_alias="REGRELLO_VERIFY_SSL")

    @model_validator(mode="after")
    def validate_backend_requirements(self) -> Self:
        if self.regrello_connector_backend == "http":
            missing: list[str] = []
            if not self.regrello_base_url.strip():
                missing.append("REGRELLO_BASE_URL")
            if not self.regrello_workspace_id.strip():
                missing.append("REGRELLO_WORKSPACE_ID")
            if not self.regrello_client_id.strip():
                missing.append("REGRELLO_CLIENT_ID")
            if not self.regrello_client_secret.strip():
                missing.append("REGRELLO_CLIENT_SECRET")
            if missing:
                raise ValueError(
                    "When REGRELLO_CONNECTOR_BACKEND=http, the following environment variables "
                    f"must be set to non-empty values: {', '.join(missing)}"
                )
            return self

        # memory
        p = self.regrello_connector_memory_fixtures_path
        if p is None:
            raise ValueError(
                "REGRELLO_CONNECTOR_MEMORY_FIXTURES_PATH is required when "
                "REGRELLO_CONNECTOR_BACKEND=memory"
            )
        if not p.is_file():
            raise ValueError(
                f"REGRELLO_CONNECTOR_MEMORY_FIXTURES_PATH must be an existing file; got {p!r}"
            )
        return self


settings = Settings()
