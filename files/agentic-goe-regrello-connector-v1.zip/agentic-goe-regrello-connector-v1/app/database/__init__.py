"""Database access.

The Regrello connector does not persist state in v1; this package mirrors the SharePoint
connector layout for future use.
"""
