"""GraphQL access layer for Regrello (parallel to `app/graph` in the SharePoint connector)."""
