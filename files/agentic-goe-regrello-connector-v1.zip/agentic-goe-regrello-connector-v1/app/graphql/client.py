"""Build `regrello` library settings and clients from connector configuration."""

from __future__ import annotations

from regrello import RegrelloClient
from regrello.config import Settings as RegrelloLibrarySettings

from app.config import Settings, settings


def regrello_library_settings_from_connector(app_settings: Settings | None = None) -> RegrelloLibrarySettings:
    """Map connector env-backed settings to the `regrello` package `Settings` model."""
    s = app_settings or settings
    return RegrelloLibrarySettings(
        regrello_base_url=s.regrello_base_url,
        regrello_workspace_id=s.regrello_workspace_id,
        regrello_client_id=s.regrello_client_id,
        regrello_client_secret=s.regrello_client_secret,
        regrello_workflow_template_id=s.regrello_workflow_template_id,
        regrello_verify_ssl=s.regrello_verify_ssl,
    )


def create_regrello_client(app_settings: Settings | None = None) -> RegrelloClient:
    """Construct an unauthenticated `RegrelloClient` using connector configuration."""
    return RegrelloClient(settings=regrello_library_settings_from_connector(app_settings))
