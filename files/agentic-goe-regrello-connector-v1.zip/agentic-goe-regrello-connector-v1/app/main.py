"""FastAPI entry point for the Regrello connector service."""

import logging
from datetime import datetime, timezone

from fastapi import FastAPI
from pydantic import BaseModel
from prometheus_fastapi_instrumentator import Instrumentator

from app.api import status, workflows
from app.config import settings

logging.basicConfig(
    level=getattr(logging, settings.log_level.upper(), logging.INFO),
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
)

app = FastAPI(
    title="Regrello Connector",
    version="0.1.0",
)
Instrumentator().instrument(app).expose(app, include_in_schema=False)

app.include_router(status.router)
app.include_router(workflows.router)


class HealthResponse(BaseModel):
    """Health check response model."""

    status: str
    service: str
    timestamp: datetime


@app.get("/health", response_model=HealthResponse)
async def health() -> HealthResponse:
    """Liveness/readiness probe endpoint."""

    return HealthResponse(
        status="ok",
        service="regrello-connector",
        timestamp=datetime.now(timezone.utc),
    )
