"""Object storage integration.

Not used by the Regrello connector v1; reserved for layout parity with other connectors.
"""
