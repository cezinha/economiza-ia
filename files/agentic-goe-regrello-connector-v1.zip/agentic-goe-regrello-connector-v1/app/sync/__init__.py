"""Synchronization workflows.

Regrello operations are exposed under `/workflows` instead of SharePoint-style `/sync`.
"""
