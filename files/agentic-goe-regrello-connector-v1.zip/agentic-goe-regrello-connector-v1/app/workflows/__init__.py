"""Workflow backends: HTTP (Regrello) and in-memory JSON fixtures."""

from app.workflows.deps import get_workflow_backend
from app.workflows.port import WorkflowBackend
from app.workflows.regrello_http_backend import RegrelloHttpBackend
from app.workflows.regrello_memory_backend import RegrelloMemoryBackend

__all__ = [
    "WorkflowBackend",
    "RegrelloHttpBackend",
    "RegrelloMemoryBackend",
    "get_workflow_backend",
]
