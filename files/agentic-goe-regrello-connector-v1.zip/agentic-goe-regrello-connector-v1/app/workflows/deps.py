"""FastAPI dependency wiring for ``WorkflowBackend``."""

from __future__ import annotations

from collections.abc import AsyncIterator

from app.config import settings
from app.workflows.port import WorkflowBackend
from app.workflows.regrello_http_backend import RegrelloHttpBackend
from app.workflows.regrello_memory_backend import RegrelloMemoryBackend


async def get_workflow_backend() -> AsyncIterator[WorkflowBackend]:
    """Yield the configured backend and always ``aclose`` after the request."""
    if settings.regrello_connector_backend == "http":
        backend: WorkflowBackend = RegrelloHttpBackend(settings)
    elif settings.regrello_connector_backend == "memory":
        path = settings.regrello_connector_memory_fixtures_path
        assert path is not None  # enforced by Settings validator
        backend = RegrelloMemoryBackend.from_path(
            path,
            default_workflow_template_id=settings.regrello_workflow_template_id,
        )
    else:
        raise RuntimeError(
            f"Unsupported regrello_connector_backend: {settings.regrello_connector_backend!r}"
        )

    try:
        yield backend
    finally:
        await backend.aclose()
