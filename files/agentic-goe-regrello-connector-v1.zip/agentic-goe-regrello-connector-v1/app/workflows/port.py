"""Workflow backend protocol: HTTP (Regrello) or in-memory fixtures."""

from __future__ import annotations

from typing import Any, Protocol, runtime_checkable


@runtime_checkable
class WorkflowBackend(Protocol):
    """Async façade over Regrello workflow operations used by HTTP routes."""

    async def create_workflow(
        self,
        field_instances: list[dict[str, Any]],
        documents: list[tuple[str, bytes]] | None,
        workflow_template_id: int | None,
        start_condition: str,
        tag_ids: list[str] | None,
    ) -> dict[str, Any]:
        """Return a dict with at least ``workflow_id`` and ``document_ids``."""

    async def get_workflow_template_fields(
        self,
        workflow_template_id: int | None,
    ) -> list[dict[str, Any]]:
        """Normalized template field definitions."""

    async def get_workflow_template_field_metadata(
        self,
        workflow_template_id: int | None,
    ) -> list[dict[str, Any]]:
        """Human-readable field metadata for a template."""

    async def get_workflow_status(
        self,
        workflow_id: str,
        workflow_template_id: int | None,
    ) -> dict[str, Any]:
        """Workflow status payload (GraphQL-shaped dict)."""

    async def aclose(self) -> None:
        """Release HTTP resources; memory backends may no-op."""
