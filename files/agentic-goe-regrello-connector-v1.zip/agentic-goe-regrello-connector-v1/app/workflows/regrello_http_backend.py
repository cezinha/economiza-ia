"""Workflow backend delegating to the vendored async ``RegrelloClient``."""

from __future__ import annotations

from typing import Any

from regrello import RegrelloClient

from app.config import Settings
from app.graphql.client import create_regrello_client


class RegrelloHttpBackend:
    """Authenticate-once-per-instance HTTP adapter over ``RegrelloClient``."""

    def __init__(self, app_settings: Settings) -> None:
        self._client: RegrelloClient = create_regrello_client(app_settings)
        self._authenticated = False

    async def _ensure_authenticated(self) -> None:
        if not self._authenticated:
            await self._client.authenticate()
            self._authenticated = True

    async def create_workflow(
        self,
        field_instances: list[dict[str, Any]],
        documents: list[tuple[str, bytes]] | None,
        workflow_template_id: int | None,
        start_condition: str,
        tag_ids: list[str] | None,
    ) -> dict[str, Any]:
        await self._ensure_authenticated()
        return await self._client.create_workflow(
            field_instances=field_instances,
            documents=documents,
            workflow_template_id=workflow_template_id,
            start_condition=start_condition,
            tag_ids=tag_ids,
        )

    async def get_workflow_template_fields(
        self,
        workflow_template_id: int | None,
    ) -> list[dict[str, Any]]:
        await self._ensure_authenticated()
        return await self._client.get_workflow_template_fields(
            workflow_template_id=workflow_template_id,
        )

    async def get_workflow_template_field_metadata(
        self,
        workflow_template_id: int | None,
    ) -> list[dict[str, Any]]:
        await self._ensure_authenticated()
        return await self._client.get_workflow_template_field_metadata(
            workflow_template_id=workflow_template_id,
        )

    async def get_workflow_status(
        self,
        workflow_id: str,
        workflow_template_id: int | None,
    ) -> dict[str, Any]:
        await self._ensure_authenticated()
        return await self._client.get_workflow_status(
            workflow_id,
            workflow_template_id=workflow_template_id,
        )

    async def aclose(self) -> None:
        await self._client.aclose()
