# Scripts

Operational scripts can be added here following the SharePoint connector (`agentic-goe-sharepoint-connector/scripts/`).

Regrello-specific examples that call the Python client directly remain in `agentic-goe-regrello/examples/`.
