"""Integration tests (optional; marked `integration` in pytest)."""
