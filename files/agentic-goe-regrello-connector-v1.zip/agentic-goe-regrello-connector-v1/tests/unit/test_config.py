"""Settings validation for HTTP vs memory backends."""

from __future__ import annotations

from pathlib import Path

import pytest
from pydantic import ValidationError

from app.config import Settings


def test_settings_http_rejects_empty_base_url(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("REGRELLO_CONNECTOR_BACKEND", "http")
    monkeypatch.setenv("REGRELLO_BASE_URL", "")
    monkeypatch.setenv("REGRELLO_WORKSPACE_ID", "w")
    monkeypatch.setenv("REGRELLO_CLIENT_ID", "c")
    monkeypatch.setenv("REGRELLO_CLIENT_SECRET", "s")
    with pytest.raises(ValidationError, match="REGRELLO_BASE_URL"):
        Settings()


def test_settings_http_rejects_empty_workspace_id(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("REGRELLO_CONNECTOR_BACKEND", "http")
    monkeypatch.setenv("REGRELLO_BASE_URL", "https://example")
    monkeypatch.setenv("REGRELLO_WORKSPACE_ID", "")
    monkeypatch.setenv("REGRELLO_CLIENT_ID", "c")
    monkeypatch.setenv("REGRELLO_CLIENT_SECRET", "s")
    with pytest.raises(ValidationError, match="REGRELLO_WORKSPACE_ID"):
        Settings()


def test_settings_http_rejects_empty_client_id(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("REGRELLO_CONNECTOR_BACKEND", "http")
    monkeypatch.setenv("REGRELLO_BASE_URL", "https://example")
    monkeypatch.setenv("REGRELLO_WORKSPACE_ID", "w")
    monkeypatch.setenv("REGRELLO_CLIENT_ID", "")
    monkeypatch.setenv("REGRELLO_CLIENT_SECRET", "s")
    with pytest.raises(ValidationError, match="REGRELLO_CLIENT_ID"):
        Settings()


def test_settings_http_rejects_empty_client_secret(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("REGRELLO_CONNECTOR_BACKEND", "http")
    monkeypatch.setenv("REGRELLO_BASE_URL", "https://example")
    monkeypatch.setenv("REGRELLO_WORKSPACE_ID", "w")
    monkeypatch.setenv("REGRELLO_CLIENT_ID", "c")
    monkeypatch.setenv("REGRELLO_CLIENT_SECRET", "")
    with pytest.raises(ValidationError, match="REGRELLO_CLIENT_SECRET"):
        Settings()


def test_settings_memory_requires_existing_file(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    missing = tmp_path / "missing.json"
    monkeypatch.setenv("REGRELLO_CONNECTOR_BACKEND", "memory")
    monkeypatch.setenv("REGRELLO_CONNECTOR_MEMORY_FIXTURES_PATH", str(missing))
    with pytest.raises(ValidationError, match="existing file"):
        Settings()


def test_settings_memory_requires_path_when_memory(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.delenv("REGRELLO_CONNECTOR_MEMORY_FIXTURES_PATH", raising=False)
    monkeypatch.setenv("REGRELLO_CONNECTOR_BACKEND", "memory")
    with pytest.raises(ValidationError, match="REGRELLO_CONNECTOR_MEMORY_FIXTURES_PATH"):
        Settings()


def test_settings_memory_accepts_fixture_file(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    p = tmp_path / "fx.json"
    p.write_text("{}", encoding="utf-8")
    monkeypatch.setenv("REGRELLO_CONNECTOR_BACKEND", "memory")
    monkeypatch.setenv("REGRELLO_CONNECTOR_MEMORY_FIXTURES_PATH", str(p))
    s = Settings()
    assert s.regrello_connector_backend == "memory"
    assert s.regrello_connector_memory_fixtures_path == p
