"""Tests for application bootstrap and health endpoints."""

from fastapi.testclient import TestClient

from app.main import app

client = TestClient(app)


def test_health_endpoint() -> None:
    """`/health` returns ok payload."""

    response = client.get("/health")
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "ok"
    assert data["service"] == "regrello-connector"
    assert "timestamp" in data


def test_status_endpoint() -> None:
    """`/status` surfaces non-secret configuration."""

    response = client.get("/status")
    assert response.status_code == 200
    body = response.json()
    assert body["service"] == "regrello-connector"
    assert body["backend"] == "http"
    assert body["regrello_base_url"] == "https://regrello.example"
    assert body["regrello_workspace_id"] == "workspace-test"
