"""``get_workflow_backend`` lifecycle and ``RegrelloHttpBackend`` delegation."""

from __future__ import annotations

from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from app.config import settings as live_settings
from app.workflows.deps import get_workflow_backend
from app.workflows.regrello_http_backend import RegrelloHttpBackend
from app.workflows.regrello_memory_backend import RegrelloMemoryBackend


@pytest.mark.asyncio
async def test_get_workflow_backend_memory_aclose(tmp_path: Path) -> None:
    p = tmp_path / "fx.json"
    p.write_text(
        '{"create_workflow_response":{"workflow_id":"x","document_ids":[]},"workflow_status":{}}',
        encoding="utf-8",
    )
    fake = MagicMock()
    fake.regrello_connector_backend = "memory"
    fake.regrello_connector_memory_fixtures_path = p
    fake.regrello_workflow_template_id = 253

    with patch("app.workflows.deps.settings", fake):
        gen = get_workflow_backend()
        backend = await gen.__anext__()
        assert isinstance(backend, RegrelloMemoryBackend)
        await gen.aclose()


@pytest.mark.asyncio
async def test_get_workflow_backend_http_aclose() -> None:
    gen = get_workflow_backend()
    backend = await gen.__anext__()
    assert isinstance(backend, RegrelloHttpBackend)
    await gen.aclose()


@pytest.mark.asyncio
async def test_regrello_http_backend_authenticates_once_and_delegates() -> None:
    mock_client = MagicMock()
    mock_client.authenticate = AsyncMock()
    mock_client.create_workflow = AsyncMock(
        return_value={"workflow_id": "w", "document_ids": ["d"]},
    )
    mock_client.get_workflow_template_fields = AsyncMock(return_value=[{"fieldId": 1}])
    mock_client.get_workflow_template_field_metadata = AsyncMock(return_value=[{"m": 1}])
    mock_client.get_workflow_status = AsyncMock(return_value={"id": "w"})
    mock_client.aclose = AsyncMock()

    with patch(
        "app.workflows.regrello_http_backend.create_regrello_client",
        return_value=mock_client,
    ):
        b = RegrelloHttpBackend(live_settings)
        await b.create_workflow([], None, 1, "START_IMMEDIATELY", None)
        await b.get_workflow_template_fields(1)
        await b.get_workflow_template_field_metadata(1)
        await b.get_workflow_status("w", 1)
        await b.aclose()

    mock_client.authenticate.assert_awaited_once()
    mock_client.create_workflow.assert_awaited_once()
    mock_client.get_workflow_template_fields.assert_awaited_once()
    mock_client.get_workflow_template_field_metadata.assert_awaited_once()
    mock_client.get_workflow_status.assert_awaited_once()
    mock_client.aclose.assert_awaited_once()


@pytest.mark.asyncio
async def test_get_workflow_backend_rejects_unknown_mode() -> None:
    fake = MagicMock()
    fake.regrello_connector_backend = "bogus"  # type: ignore[assignment]
    with patch("app.workflows.deps.settings", fake):
        gen = get_workflow_backend()
        with pytest.raises(RuntimeError, match="Unsupported"):
            await gen.__anext__()
