"""Workflow route tests with mocked workflow backend."""

from pathlib import Path
from unittest.mock import AsyncMock, MagicMock

import pytest
from fastapi.testclient import TestClient

from app.api import workflows
from app.main import app
from app.workflows.deps import get_workflow_backend
from app.workflows.regrello_memory_backend import RegrelloMemoryBackend


@pytest.fixture
def mock_backend() -> MagicMock:
    backend = MagicMock()
    backend.create_workflow = AsyncMock(
        return_value={"workflow_id": "wf-1", "document_ids": ["d1"]},
    )
    backend.get_workflow_status = AsyncMock(return_value={"id": "wf-1", "name": "Test"})
    backend.get_workflow_template_fields = AsyncMock(return_value=[{"fieldId": 1}])
    backend.get_workflow_template_field_metadata = AsyncMock(return_value=[{"fieldId": 1}])
    backend.aclose = AsyncMock()
    return backend


@pytest.fixture
def client_with_mock(mock_backend: MagicMock) -> TestClient:
    async def _override():
        yield mock_backend

    app.dependency_overrides[get_workflow_backend] = _override
    yield TestClient(app)
    app.dependency_overrides.clear()


def test_create_workflow(client_with_mock: TestClient, mock_backend: MagicMock) -> None:
    """POST `/workflows` delegates to the workflow backend ``create_workflow``."""

    response = client_with_mock.post(
        "/workflows",
        json={
            "field_instances": [
                {"fieldId": 1, "stringValue": "x", "inputType": "REQUESTED", "displayOrder": 1},
            ],
        },
    )
    assert response.status_code == 200
    assert response.json() == {"workflow_id": "wf-1", "document_ids": ["d1"]}
    mock_backend.create_workflow.assert_awaited()


def test_workflow_status(client_with_mock: TestClient, mock_backend: MagicMock) -> None:
    """GET `/workflows/{id}/status` returns backend payload."""

    response = client_with_mock.get("/workflows/wf-1/status")
    assert response.status_code == 200
    assert response.json()["id"] == "wf-1"
    mock_backend.get_workflow_status.assert_awaited()


def test_template_fields(client_with_mock: TestClient, mock_backend: MagicMock) -> None:
    """GET `/workflows/template/fields` maps template fields."""

    response = client_with_mock.get("/workflows/template/fields")
    assert response.status_code == 200
    assert response.json() == [{"fieldId": 1}]
    mock_backend.get_workflow_template_fields.assert_awaited()


def test_template_field_metadata(client_with_mock: TestClient, mock_backend: MagicMock) -> None:
    """GET `/workflows/template/field-metadata` returns metadata."""

    response = client_with_mock.get("/workflows/template/field-metadata")
    assert response.status_code == 200
    assert response.json() == [{"fieldId": 1}]
    mock_backend.get_workflow_template_field_metadata.assert_awaited()


def test_invalid_document_base64(client_with_mock: TestClient) -> None:
    """Malformed document payloads return HTTP 400."""

    response = client_with_mock.post(
        "/workflows",
        json={
            "field_instances": [],
            "documents": [{"filename": "a.bin", "content_base64": "not-valid-base64!!!"}],
        },
    )
    assert response.status_code == 400


def test_create_workflow_502_on_backend_value_error(
    client_with_mock: TestClient,
    mock_backend: MagicMock,
) -> None:
    mock_backend.create_workflow = AsyncMock(side_effect=ValueError("simulated failure"))
    response = client_with_mock.post("/workflows", json={"field_instances": []})
    assert response.status_code == 502


def test_template_fields_502_on_backend_error(
    client_with_mock: TestClient,
    mock_backend: MagicMock,
) -> None:
    mock_backend.get_workflow_template_fields = AsyncMock(side_effect=ValueError("bad"))
    response = client_with_mock.get("/workflows/template/fields")
    assert response.status_code == 502


def test_template_field_metadata_502_on_backend_error(
    client_with_mock: TestClient,
    mock_backend: MagicMock,
) -> None:
    mock_backend.get_workflow_template_field_metadata = AsyncMock(side_effect=ValueError("bad"))
    response = client_with_mock.get("/workflows/template/field-metadata")
    assert response.status_code == 502


def test_workflow_status_502_on_backend_error(
    client_with_mock: TestClient,
    mock_backend: MagicMock,
) -> None:
    mock_backend.get_workflow_status = AsyncMock(side_effect=ValueError("bad"))
    response = client_with_mock.get("/workflows/wf-1/status")
    assert response.status_code == 502


@pytest.mark.asyncio
async def test_regrello_memory_backend_fixture_resolution() -> None:
    """``RegrelloMemoryBackend`` resolves per-template data and falls back to default template id."""
    path = Path(__file__).resolve().parent.parent / "fixtures" / "regrello_memory_minimal.json"
    backend = RegrelloMemoryBackend.from_path(path, default_workflow_template_id=253)

    fields_other = await backend.get_workflow_template_fields(100)
    assert fields_other == [{"fieldId": 1}]

    fields_fallback = await backend.get_workflow_template_fields(999)
    assert fields_fallback == [{"fieldId": 99, "inputType": "REQUESTED", "displayOrder": 1}]

    meta = await backend.get_workflow_template_field_metadata(None)
    assert meta == [{"fieldId": 99, "name": "Fixture Field"}]

    created = await backend.create_workflow([], None, None, "START_IMMEDIATELY", None)
    assert created["workflow_id"] == "mem-wf-1"
    assert created["document_ids"] == ["mem-doc-1"]

    status_ok = await backend.get_workflow_status("wf-known", None)
    assert status_ok["id"] == "wf-known"

    with pytest.raises(ValueError, match="Unknown workflow_id"):
        await backend.get_workflow_status("missing-wf", None)

    await backend.aclose()


@pytest.mark.asyncio
async def test_memory_backend_list_template_fields_and_invalid_payloads(tmp_path: Path) -> None:
    """Support list-shaped ``template_fields`` and validation errors for bad fixture shapes."""
    p = tmp_path / "list_fields.json"
    p.write_text(
        '{"template_fields": [{"fieldId": 7}], "workflow_status": {}, '
        '"create_workflow_response": {"workflow_id": "1", "document_ids": []}}',
        encoding="utf-8",
    )
    b = RegrelloMemoryBackend.from_path(p, default_workflow_template_id=253)
    assert await b.get_workflow_template_fields(999) == [{"fieldId": 7}]
    await b.aclose()

    bad_root = tmp_path / "array.json"
    bad_root.write_text("[]", encoding="utf-8")
    with pytest.raises(ValueError, match="object"):
        RegrelloMemoryBackend.from_path(bad_root, default_workflow_template_id=253)

    bad_create = tmp_path / "bad_create.json"
    bad_create.write_text(
        '{"create_workflow_response": "nope", "workflow_status": {}}',
        encoding="utf-8",
    )
    b2 = RegrelloMemoryBackend.from_path(bad_create, default_workflow_template_id=253)
    with pytest.raises(ValueError, match="create_workflow_response"):
        await b2.create_workflow([], None, None, "START_IMMEDIATELY", None)

    bad_ws = tmp_path / "bad_ws.json"
    bad_ws.write_text(
        '{"workflow_status": [], "create_workflow_response": {"workflow_id":"1","document_ids":[]}}',
        encoding="utf-8",
    )
    b3 = RegrelloMemoryBackend.from_path(bad_ws, default_workflow_template_id=253)
    with pytest.raises(ValueError, match="workflow_status"):
        await b3.get_workflow_status("any", None)

    bad_entry = tmp_path / "bad_entry.json"
    bad_entry.write_text(
        '{"workflow_status": {"w": "not-object"}, '
        '"create_workflow_response": {"workflow_id":"1","document_ids":[]}}',
        encoding="utf-8",
    )
    b4 = RegrelloMemoryBackend.from_path(bad_entry, default_workflow_template_id=253)
    with pytest.raises(ValueError, match="must be a JSON object"):
        await b4.get_workflow_status("w", None)

    no_branch = tmp_path / "no_branch.json"
    no_branch.write_text(
        '{"create_workflow_response": {"workflow_id":"1","document_ids":[]}, "workflow_status": {}}',
        encoding="utf-8",
    )
    b5 = RegrelloMemoryBackend.from_path(no_branch, default_workflow_template_id=253)
    assert await b5.get_workflow_template_fields(1) == []

    bad_shape = tmp_path / "bad_shape.json"
    bad_shape.write_text(
        '{"template_fields": "not-list-or-dict", '
        '"create_workflow_response": {"workflow_id":"1","document_ids":[]}, "workflow_status": {}}',
        encoding="utf-8",
    )
    b6 = RegrelloMemoryBackend.from_path(bad_shape, default_workflow_template_id=253)
    assert await b6.get_workflow_template_fields(1) == []

    orphan_templates = tmp_path / "orphan_templates.json"
    orphan_templates.write_text(
        '{"template_fields": {"1": []}, '
        '"create_workflow_response": {"workflow_id":"1","document_ids":[]}, "workflow_status": {}}',
        encoding="utf-8",
    )
    b7 = RegrelloMemoryBackend.from_path(orphan_templates, default_workflow_template_id=253)
    assert await b7.get_workflow_template_fields(999) == []
