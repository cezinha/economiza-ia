# Regrello Connector Service

HTTP façade over the Regrello GraphQL API, built from the same layout as `agentic-goe-sharepoint-connector`.

The async Regrello client (`RegrelloClient`, `Settings`) is vendored in this repo under [`regrello/`](regrello/) (same source as `agentic-goe-regrello/src/regrello`). Optional runnable demos still live in the sibling package [`agentic-goe-regrello`](../agentic-goe-regrello) under `examples/` (`create_workflow_demo.py`, `check_workflow_status_demo.py`, `get_workflow_template_fields_demo.py`, etc.).

## Setup

```bash
cd agentic-goe-regrello-connector
uv sync --all-groups
```

### Virtual environment

`uv sync` / `uv sync --all-groups` manage an isolated environment implicitly; some teams still use an explicit venv:

```bash
python3 -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install --upgrade pip
pip install -e .
```

Dev tools are listed under `[dependency-groups]` in `pyproject.toml` (uv), not setuptools extras: with **uv**, use `uv sync --all-groups`; with **pip** only, install tests with `pip install pytest pytest-asyncio pytest-cov pytest-mock` (add `mypy` if you run type checks). Run the suite with `pytest` or `.venv/bin/pytest` (see [Tests](#tests)).

## Configuration

### Environment file

Start from the canonical template: [`.env.example`](.env.example).

```bash
cp .env.example .env
```

All variable names, placeholders, and per-parameter descriptions are `#` comments in that file (including the optional **Memory backend** block).

Settings are defined in [`app/config.py`](app/config.py) with **Pydantic Settings** (`BaseSettings`). On import, `Settings` loads `.env` automatically via `model_config.env_file`: it reads `Path.cwd() / ".env"` and `.env` next to `pyproject.toml` (connector root, derived from `app/config.py`) when each file exists. If both files define the same key, the connector-root `.env` wins (pydantic merges multiple `env_file` paths with later paths overriding earlier ones). Variables already set in the **process environment** still take precedence over values from `.env` files (standard pydantic-settings behavior). You do not need to call `load_dotenv()` for `Settings` itself.

Optional alternatives if you want variables in the shell or duplicated loading: `set -a && source .env && set +a`, **`uvicorn[standard]`**’s `uvicorn ... --env-file .env`, the `dotenv` CLI, IDE run configurations, Docker `--env-file`, or Kubernetes secrets.

### Parameter reference (grouping only)

| Area | What to configure |
|------|-------------------|
| Connector process | Service bind address/port, environment label, log level. |
| Backend mode | `http` (live Regrello) vs `memory` (JSON fixture file path). |
| Regrello API | OAuth and workspace settings when using `http`; not required for `memory` (see comments in [`.env.example`](.env.example)). |

### Memory backend

1. Set backend and fixture path as described in the **Memory backend** section of [`.env.example`](.env.example). The documented default is [`regrello_memory_minimal.json`](regrello_memory_minimal.json) at the project root (next to `pyproject.toml`). Pytest still loads the same JSON from [`tests/fixtures/regrello_memory_minimal.json`](tests/fixtures/regrello_memory_minimal.json).
2. Optionally adjust template id so fixture keys match (see comments in [`.env.example`](.env.example)).

Run from the connector directory:

```bash
cd agentic-goe-regrello-connector
export REGRELLO_CONNECTOR_BACKEND=memory
export REGRELLO_CONNECTOR_MEMORY_FIXTURES_PATH="$(pwd)/regrello_memory_minimal.json"
uvicorn app.main:app --host 0.0.0.0 --port 8005 --reload
```

Verify:

- `GET /status` — response includes `"backend": "memory"`.
- `GET /workflows/wf-known/status` — with the minimal fixture below, returns the canned workflow; an unknown id returns HTTP 502.
- `POST /workflows` — returns the `create_workflow_response` from the fixture (shape `workflow_id` + `document_ids`).
- `POST /regrello/graphql` — returns entries from `graphql_responses` keyed by `operationName`, or `default`.

#### Fixture JSON schema

- **`template_fields`** (optional): either a JSON array of field objects, or an object whose keys are template ids (`"253"` or `253`) mapping to arrays. If the requested template id is missing, the backend falls back to `REGRELLO_WORKFLOW_TEMPLATE_ID`.
- **`template_field_metadata`** (optional): same shape as `template_fields`.
- **`workflow_status`** (object): maps `workflow_id` strings to status objects. Unknown ids raise `ValueError` (HTTP 502 from the API).
- **`create_workflow_response`** (object): default body for `POST /workflows`; must include `workflow_id` and `document_ids` (array).
- **`graphql_responses`** (object, optional): maps `operationName` strings (or `"default"`) to full GraphQL JSON bodies for `POST /regrello/graphql`.

#### Example fixture file (same JSON shape as [`regrello_memory_minimal.json`](regrello_memory_minimal.json) at the repo root and as used by pytest under `tests/fixtures/`)

```json
{
  "template_fields": {
    "253": [{ "fieldId": 99, "inputType": "REQUESTED", "displayOrder": 1 }],
    "100": [{ "fieldId": 1 }]
  },
  "template_field_metadata": {
    "253": [{ "fieldId": 99, "name": "Fixture Field" }]
  },
  "workflow_status": {
    "wf-known": { "id": "wf-known", "name": "Memory fixture workflow" }
  },
  "create_workflow_response": {
    "workflow_id": "mem-wf-1",
    "document_ids": ["mem-doc-1"]
  },
  "graphql_responses": {
    "default": { "data": { "workflows": { "workflows": [] } } },
    "WorkflowStatus": {
      "data": {
        "workflows": {
          "workflows": [{ "id": "wf-known", "name": "Memory fixture workflow" }]
        }
      }
    }
  }
}
```

## Run locally (HTTP / default)

With `REGRELLO_CONNECTOR_BACKEND=http` (default), set the variables for `http` mode as documented in [`.env.example`](.env.example), then:

```bash
uvicorn app.main:app --host 0.0.0.0 --port 8005 --reload
```

For memory mode, use the steps in [Memory backend](#memory-backend) instead.

## Container image

Build from the **repository root** so `agentic-goe-regrello-connector/` and its `regrello/` package are on the build context:

```bash
docker build -f agentic-goe-regrello-connector/Dockerfile .
```

## Documentation

Regrello GraphQL reference for workflows, tasks, lifecycle, and cURL examples lives under [`docs/`](docs/README.md):

- [Overview, transport, lifecycle](docs/README.md)
- [Workflows, templates, documents](docs/workflows.md)
- [ActionItems / Tasks (comments, documents, assignees)](docs/tasks.md)

## API overview

- `GET /health` — probes
- `GET /status` — non-secret connector identity (includes `backend`: `http` or `memory`)
- `POST /workflows` — create workflow (`createWorkflowFromTemplate`); optional `documents[].content_base64`
- `GET /workflows/template/fields` — normalized template fields
- `GET /workflows/template/field-metadata` — field metadata for forms
- `GET /workflows/{workflow_id}/status` — workflow status query
- `POST /regrello/graphql` — proxy any Regrello GraphQL call (`query`, `variables`, `operationName`); returns full JSON (`data`, `errors`)

## Tests

From the connector directory (with the dev environment installed, for example `uv sync --all-groups`):

```bash
pytest
```

`tests/conftest.py` sets `REGRELLO_CONNECTOR_DISABLE_DOTENV=1` before application imports so a developer `.env` (for example `REGRELLO_CONNECTOR_BACKEND=memory`) does not change unit test expectations.

If `pytest` is not on your `PATH`, use `uv run pytest` or the virtualenv’s `pytest`.
