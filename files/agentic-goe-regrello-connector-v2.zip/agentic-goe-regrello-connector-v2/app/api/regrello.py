"""Regrello GraphQL proxy and other tenant-wide Regrello HTTP operations."""

from __future__ import annotations

import logging
from typing import Annotated, Any

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel, ConfigDict, Field

from app.workflows.deps import get_workflow_backend
from app.workflows.port import WorkflowBackend

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/regrello", tags=["regrello"])


class GraphQLRequest(BaseModel):
    """Regrello GraphQL envelope (query, variables, operationName)."""

    query: str
    variables: dict[str, Any] | None = None
    operation_name: str | None = Field(None, alias="operationName")

    model_config = ConfigDict(populate_by_name=True)


WorkflowBackendDep = Annotated[WorkflowBackend, Depends(get_workflow_backend)]


@router.post("/graphql")
async def regrello_graphql_route(
    backend: WorkflowBackendDep,
    body: GraphQLRequest,
) -> dict[str, Any]:
    """Proxy a Regrello GraphQL request; returns full JSON (data and optional errors)."""

    try:
        return await backend.execute_graphql(
            query=body.query,
            variables=body.variables,
            operation_name=body.operation_name,
        )
    except (RuntimeError, ValueError) as e:
        logger.exception("GraphQL proxy failed")
        raise HTTPException(
            status_code=status.HTTP_502_BAD_GATEWAY,
            detail=str(e),
        ) from e
