"""In-memory workflow backend driven by a JSON fixture file."""

from __future__ import annotations

import json
from copy import deepcopy
from pathlib import Path
from typing import Any


def _template_keys(template_id: int) -> tuple[str, int]:
    """JSON object keys may be strings or ints."""
    return (str(template_id), template_id)


class RegrelloMemoryBackend:
    """Serve canned responses from a JSON file (local / CI without Regrello)."""

    def __init__(self, data: dict[str, Any], default_workflow_template_id: int) -> None:
        self._data = data
        self._default_workflow_template_id = default_workflow_template_id

    @classmethod
    def from_path(cls, path: Path, *, default_workflow_template_id: int) -> RegrelloMemoryBackend:
        raw = json.loads(path.read_text(encoding="utf-8"))
        if not isinstance(raw, dict):
            raise ValueError(f"Memory fixtures JSON must be an object, got {type(raw).__name__}")
        return cls(raw, default_workflow_template_id)

    def _effective_template_id(self, workflow_template_id: int | None) -> int:
        return (
            workflow_template_id
            if workflow_template_id is not None
            else self._default_workflow_template_id
        )

    def _resolve_template_branch(
        self,
        key: str,
        workflow_template_id: int | None,
    ) -> list[dict[str, Any]]:
        """Resolve ``template_fields`` / ``template_field_metadata`` per template with fallback."""
        branch = self._data.get(key)
        if branch is None:
            return []
        requested = self._effective_template_id(workflow_template_id)
        default_tid = self._default_workflow_template_id

        if isinstance(branch, list):
            return [dict(x) for x in branch if isinstance(x, dict)]

        if not isinstance(branch, dict):
            return []

        def pick(tid: int) -> list[dict[str, Any]] | None:
            for k in _template_keys(tid):
                if k in branch:
                    val = branch[k]
                    if isinstance(val, list):
                        return [dict(x) for x in val if isinstance(x, dict)]
            return None

        chosen = pick(requested)
        if chosen is not None:
            return chosen
        if requested != default_tid:
            chosen = pick(default_tid)
            if chosen is not None:
                return chosen
        return []

    async def create_workflow(
        self,
        field_instances: list[dict[str, Any]],
        documents: list[tuple[str, bytes]] | None,
        workflow_template_id: int | None,
        start_condition: str,
        tag_ids: list[str] | None,
    ) -> dict[str, Any]:
        _ = (field_instances, documents, workflow_template_id, start_condition, tag_ids)
        raw = self._data.get("create_workflow_response", {})
        if not isinstance(raw, dict):
            raise ValueError("create_workflow_response must be a JSON object")
        return deepcopy(raw)

    async def get_workflow_template_fields(
        self,
        workflow_template_id: int | None,
    ) -> list[dict[str, Any]]:
        return self._resolve_template_branch("template_fields", workflow_template_id)

    async def get_workflow_template_field_metadata(
        self,
        workflow_template_id: int | None,
    ) -> list[dict[str, Any]]:
        return self._resolve_template_branch("template_field_metadata", workflow_template_id)

    async def get_workflow_status(
        self,
        workflow_id: str,
        workflow_template_id: int | None,
    ) -> dict[str, Any]:
        _ = workflow_template_id
        statuses = self._data.get("workflow_status")
        if not isinstance(statuses, dict):
            raise ValueError("workflow_status must be a JSON object keyed by workflow id")
        payload = statuses.get(workflow_id)
        if payload is None:
            raise ValueError(
                f"Unknown workflow_id {workflow_id!r} for memory backend: "
                f"not defined under workflow_status in fixtures"
            )
        if not isinstance(payload, dict):
            raise ValueError(f"workflow_status[{workflow_id!r}] must be a JSON object")
        return deepcopy(payload)

    def _resolve_graphql_response(self, operation_name: str | None) -> dict[str, Any]:
        branch = self._data.get("graphql_responses")
        if not isinstance(branch, dict):
            raise ValueError(
                "graphql_responses must be a JSON object keyed by operationName "
                "(or 'default') for memory backend execute_graphql"
            )

        if operation_name is not None and operation_name in branch:
            payload = branch[operation_name]
        elif "default" in branch:
            payload = branch["default"]
        else:
            raise ValueError(
                f"Unknown operationName {operation_name!r} for memory backend: "
                f"not defined under graphql_responses and no 'default' entry"
            )

        if not isinstance(payload, dict):
            key = operation_name if operation_name is not None else "default"
            raise ValueError(f"graphql_responses[{key!r}] must be a JSON object")
        return deepcopy(payload)

    async def execute_graphql(
        self,
        query: str,
        variables: dict[str, Any] | None = None,
        operation_name: str | None = None,
    ) -> dict[str, Any]:
        _ = (query, variables)
        return self._resolve_graphql_response(operation_name)

    async def aclose(self) -> None:
        """No HTTP resources."""
