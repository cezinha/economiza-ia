# Regrello GraphQL API reference

This folder documents how to call the Regrello API used by the connector’s vendored client ([`regrello/client.py`](../regrello/client.py)). Use it to implement clients, test with cURL/Postman, or align the connector HTTP API with Regrello.

## Contents

| Document | Description |
|----------|-------------|
| [workflows.md](workflows.md) | Workflow, Blueprint (template), Stage, **ActionItem**, Document, and workflow GraphQL operations |
| [tasks.md](tasks.md) | **ActionItem** (UI: Task)—assignees, documents, comments—and task GraphQL operations |
| [workflow-req-res.md](workflow-req-res.md) | **Reference (do not edit):** `workflows` query + response |
| [task-req-res.md](task-req-res.md) | **Reference (do not edit):** `actionItem` query + response |

## Confidence legend

Labels appear on fields and operations throughout these docs:

| Label | Meaning |
|-------|---------|
| **Implemented** | Used in [`regrello/client.py`](../regrello/client.py) today |
| **Official API** | Documented in Regrello’s workflow API guide (`workflow via API.pdf`) but not yet implemented in the client |
| **Confirmed (tenant)** | Observed in [`workflow-req-res.md`](workflow-req-res.md) / [`task-req-res.md`](task-req-res.md) on Dell Regrello |
| **Product / inferred** | Derived from Regrello How To or guessed GraphQL names not yet seen in tenant samples |

## Environment variables

Set these for cURL examples (see [`.env.example`](../.env.example)):

| Variable | Purpose |
|----------|---------|
| `REGRELLO_BASE_URL` | Tenant base URL (no trailing slash), e.g. `https://your-tenant.regrello.com` |
| `REGRELLO_WORKSPACE_ID` | Workspace id in OAuth and GraphQL paths |
| `REGRELLO_CLIENT_ID` | OAuth client id |
| `REGRELLO_CLIENT_SECRET` | OAuth client secret |
| `REGRELLO_WORKFLOW_TEMPLATE_ID` | Default blueprint/template id (e.g. `253`) |
| `REGRELLO_VERIFY_SSL` | `true` (default) or `false` for dev only |

Shell setup:

```bash
export REGRELLO_BASE_URL="https://your-tenant.regrello.com"
export REGRELLO_WORKSPACE_ID="your-workspace-id"
export REGRELLO_CLIENT_ID="your-client-id"
export REGRELLO_CLIENT_SECRET="your-client-secret"
export ACCESS_TOKEN=""   # set after OAuth step below
export GRAPHQL_URL="${REGRELLO_BASE_URL}/customer/workspace/${REGRELLO_WORKSPACE_ID}/query"
```

## Endpoints

| Step | Method | URL |
|------|--------|-----|
| OAuth token | `POST` | `{REGRELLO_BASE_URL}/oauth/{REGRELLO_WORKSPACE_ID}/token` |
| GraphQL | `POST` | `{REGRELLO_BASE_URL}/customer/workspace/{REGRELLO_WORKSPACE_ID}/query` |
| Document upload | `PUT` | Pre-signed URL from `createDocument.signedUrl` (not Regrello GraphQL host) |

## GraphQL call structure

Every GraphQL operation uses the same HTTP envelope:

**Headers**

```http
Content-Type: application/json
Authorization: Bearer {access_token}
```

**Body (JSON)**

```json
{
  "query": "<GraphQL document string>",
  "variables": { },
  "operationName": "<optional operation name>"
}
```

**Successful response shape**

```json
{
  "data": {
    "<rootField>": { }
  }
}
```

**GraphQL-level errors** (HTTP may still be `200`):

```json
{
  "errors": [
    { "message": "...", "locations": [], "path": [] }
  ],
  "data": null
}
```

**Mutation business errors** (HTTP `200`, no top-level `errors`): many Regrello mutations return an `error` field on the payload, e.g. `createWorkflowFromTemplate.error`.

The client treats any top-level `errors` array as failure and raises `RuntimeError` (typed helper methods). The connector also exposes **`POST /regrello/graphql`**, which forwards the same JSON envelope and returns the **full** Regrello response (`data` and optional `errors`) without converting GraphQL errors into HTTP failures.

## Connector HTTP API

| Endpoint | Purpose |
|----------|---------|
| `POST /regrello/graphql` | Generic GraphQL proxy (`query`, `variables`, `operationName`) |
| `POST /workflows` | Create workflow from template |
| `GET /workflows/template/fields` | Normalized template fields |
| `GET /workflows/template/field-metadata` | Template field metadata |
| `GET /workflows/{workflow_id}/status` | Workflow status query |

## Lifecycle

Regrello models work as **Blueprint (template) → Workflow (instance) → Stages → ActionItems** (called **Tasks** in the UI). GraphQL in this repo focuses on **starting workflows** and **reading workflow status**; **action items** are queried via `openActionItems` on a workflow and `actionItem(input: { uuid })` for detail—see [tasks.md](tasks.md) and the tenant samples.

```mermaid
stateDiagram-v2
    direction TB

    [*] --> Authenticate: POST oauth token
    Authenticate --> DiscoverTemplate: WorkflowTemplateFields
    DiscoverTemplate --> UploadDocs: CreateDocument plus PUT
    UploadDocs --> CreateWorkflow: createWorkflowFromTemplate
    CreateWorkflow --> Started: START_IMMEDIATELY
    CreateWorkflow --> Draft: omit startCondition
    Draft --> Started: startWorkflow mutation
    Started --> Stage1ActionItems: emails to assignees
    Stage1ActionItems --> ActionItemOpen: standard approval split
    ActionItemOpen --> ActionItemComplete: UI email webform or mutation
    ActionItemOpen --> AutoActionItem: integration automated step
    AutoActionItem --> Callback: HTTP POST to GOE connector
    ActionItemComplete --> NextStage: dependencies
    NextStage --> Stage1ActionItems: more stages
    Started --> Paused: pause workflow
    Paused --> Started: resume
    Started --> Ended: end workflow
    Ended --> [*]
```

**Typical Dell / GOE integration path**

1. Obtain OAuth token.
2. (Optional) Load template fields via `WorkflowTemplateFields`.
3. Upload documents with `CreateDocumentMutation` + `PUT` to `signedUrl`.
4. Call `createWorkflowFromTemplate` with `fieldInstances` and `startCondition: "START_IMMEDIATELY"` so Stage 1 tasks start and assignees are notified.
5. Poll workflow status with `WorkflowStatus` (`workflows` query).
6. When an **automated task** in the blueprint finishes, Regrello calls your **HTTP callback** (not GraphQL); the GOE API persists results under `/api/regrello/callback`.

**Product rules (How To)**

- A workflow needs at least **one Stage and one Task** before it can start.
- **Start** fields (yellow in UI) map to `fieldInstances` on create (and/or before `startWorkflow`).
- While a workflow is **Paused**, assignees can view/comment but **cannot complete** tasks.
- When a workflow is **Ended**, no further task actions are allowed.

See [workflows.md](workflows.md) for workflow operations and [tasks.md](tasks.md) for task entities and inferred task operations.

## Related code

| Component | Path |
|-----------|------|
| Regrello client | [`regrello/client.py`](../regrello/client.py) |
| Connector GraphQL proxy | [`app/api/regrello.py`](../app/api/regrello.py) |
| Connector workflow routes | [`app/api/workflows.py`](../app/api/workflows.py) |
| GOE Regrello callback | `agentic-goe/services/api/app/regrello/` (sibling repo) |
