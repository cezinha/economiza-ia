# GraphQL Task

## Task Request - GraphQL Query

```graphql
{
  actionItem(input: { uuid: "HwkdOzdKTbE" }) {
    id
    name
    description
    dueOn
    dueOnClass
    status
    templateId
    comments {
      id
      text
      createdBy {
        id
      }
      createdAt
      documents {
        id
        name
        documentType {
          id
          name
        }
        comment {
          id
          text
          createdBy {
            id
          }
          createdAt
        }
      }
    }
    hasDocuments
    fieldInstances {
      field {
        fieldType
      }
      inputType
      updatedAt
      isCopy
    }
    documents {
      id
      name
      documentType {
        id
        name
      }
      comment {
        id
        text
        createdBy {
          id
        }
        createdAt
      }
    }
    assignees {
      id
    }
    requiresAck
    requiresReview
    workflowReference {
      stageId
      workflowId
    }
  }
}
```


## Task Response

```json
{
  "data": {
    "actionItem": {
      "id": 3555,
      "name": "Upload feature matrix and roadmap​",
      "description": "<p>Platform: All​</p><p>PG SharePoint: <a target=\"_blank\" rel=\"noopener noreferrer nofollow\" href=\"https://dell.sharepoint.com/sites/CSGPC-Functions/PMO/Forms/AllItems.aspx\">https://dell.sharepoint.com/sites/CSGPC-Functions/PMO/Forms/AllItems.aspx</a></p><p></p>",
      "dueOn": "2026-05-12T04:59:59.999Z",
      "dueOnClass": "OVERDUE",
      "status": "COMPLETED",
      "templateId": 11844,
      "comments": [],
      "hasDocuments": true,
      "fieldInstances": [
        {
          "field": {
            "fieldType": "DEFAULT"
          },
          "inputType": "REQUESTED",
          "updatedAt": "2026-05-15T03:30:52.045521Z",
          "isCopy": true
        }
      ],
      "documents": [],
      "assignees": [
        {
          "id": 350
        }
      ],
      "requiresAck": false,
      "requiresReview": false,
      "workflowReference": {
        "stageId": 4540,
        "workflowId": 2078
      }
    }
  }
}
```
