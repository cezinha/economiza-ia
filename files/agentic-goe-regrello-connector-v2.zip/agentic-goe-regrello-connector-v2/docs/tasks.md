# ActionItems (Tasks) — entities and GraphQL operations

In Regrello’s **GraphQL API**, work items are **`ActionItem`** objects. The product UI calls them **Tasks**.

- List open items on a workflow: root field **`workflows`** → `openActionItems` — [workflows.md](workflows.md#workflows) and [workflow-req-res.md](workflow-req-res.md).
- Load one item in full: root field **`actionItem(input: { uuid })`** — [task-req-res.md](task-req-res.md) and [actionItem](#actionitem) below.

Action items are **not created directly via GraphQL**; they are defined on blueprints and appear when a workflow **starts** (`START_IMMEDIATELY` or `startWorkflow`). See [lifecycle](README.md#lifecycle).

Back to [workflows](workflows.md) for workflow and document operations.

---

## Entity: ActionItem (UI: Task)

A unit of work inside a **Stage**, with assignees, form fields, documents, and **comments** (activity/message history).

| Field | Type | Confidence | Description |
|-------|------|------------|-------------|
| `id` | `Int` | Confirmed (tenant) | Numeric id (e.g. `3555`) |
| `uuid` | `String` | Confirmed (tenant) | Lookup key for `actionItem(input: { uuid })` (e.g. `"HwkdOzdKTbE"`) |
| `name` | `String` | Confirmed (tenant) | Title |
| `description` | `String` | Confirmed (tenant) | HTML description |
| `status` | Enum | Confirmed (tenant) | e.g. `PENDING_SUBMISSION`, `COMPLETED` |
| `dueOn` | `DateTime` | Confirmed (tenant) | Due timestamp |
| `dueOnClass` | Enum | Confirmed (tenant) | e.g. `OVERDUE` |
| `templateId` | `Int` | Confirmed (tenant) | Blueprint task template id |
| `hasDocuments` | `Boolean` | Confirmed (tenant) | Whether documents exist on the item |
| `requiresAck` | `Boolean` | Confirmed (tenant) | Requires acknowledgment |
| `requiresReview` | `Boolean` | Confirmed (tenant) | Requires review |
| `assignees` | `[Assignee]` | Confirmed (tenant) | Assignees (`id`; expand `user` on workflow list query) |
| `workflowReference` | Object | Confirmed (tenant) | `workflowId`, `stageId` |
| `fieldInstances` | `[FieldInstance]` | Confirmed (tenant) | `field.fieldType`, `inputType`, `updatedAt`, `isCopy` |
| `documents` | `[Document]` | Confirmed (tenant) | `id`, `name`, `documentType`, linked `comment` |
| `comments` | `[Comment]` | Confirmed (tenant) | Activity / messages (see below) |
| `assignedBy` | `Party` | Product (UI) | Shown as **Assigned by** in UI (not in tenant GraphQL sample; query if needed) |
| `ccParties` | `[Party]` | Product / inferred | Cc recipients (How To) |
| `approvers` | `[Party]` | Product / inferred | Approval tasks (How To) |

Tenant sample: [task-req-res.md](task-req-res.md).

---

## Entity: Assignee

| Field | Type | Confidence | Description |
|-------|------|------------|-------------|
| `id` | `Int` | Confirmed (tenant) | Assignee party id (e.g. `350`) |
| `user.name` | `String` | Confirmed (tenant) | User name / email (on `openActionItems`) |
| `user.email` | `String` | Product / inferred | Email when selected on query |

---

## Entity: Document (on ActionItem)

| Field | Type | Confidence | Description |
|-------|------|------------|-------------|
| `id` | `ID` | Confirmed (tenant) | Document id |
| `name` | `String` | Confirmed (tenant) | **File name** |
| `documentType.id` | `ID` | Confirmed (tenant) | Document type id |
| `documentType.name` | `String` | Confirmed (tenant) | Document type label |
| `comment` | `Comment` | Confirmed (tenant) | Comment that attached the document |

Documents may also appear nested under `comments.documents`.

---

## Entity: Comment (activity / message history)

Regrello exposes task activity as **`comments`**, not a separate `activity` root field. Map to your activity model as follows:

| GraphQL (`comments`) | Activity concept |
|----------------------|------------------|
| `createdAt` | Date/time of activity |
| `createdBy.id` | Actor (resolve to name via user query if needed) |
| `text` | Message body |
| (derive) `activityType` | Infer from context (reply, system event) or extend query if Regrello adds it |

| Field | Type | Confidence | Description |
|-------|------|------------|-------------|
| `id` | `ID` | Confirmed (tenant) | Comment id |
| `text` | `String` | Confirmed (tenant) | Message text |
| `createdAt` | `DateTime` | Confirmed (tenant) | When posted |
| `createdBy.id` | `ID` | Confirmed (tenant) | Author party/user id |
| `documents` | `[Document]` | Confirmed (tenant) | Attachments on this comment |

How To notification types (completed, approved, rejected, problem raised, etc.) align with **product behavior**; exact GraphQL enums for activity type were not present in the tenant sample.

---

## Entity: FieldInstance (on ActionItem)

| Field | Type | Confidence | Description |
|-------|------|------------|-------------|
| `field.fieldType` | `String` | Confirmed (tenant) | e.g. `DEFAULT` |
| `inputType` | `String` | Confirmed (tenant) | e.g. `REQUESTED` |
| `updatedAt` | `DateTime` | Confirmed (tenant) | Last update |
| `isCopy` | `Boolean` | Confirmed (tenant) | Copied from upstream |

Value fields (`stringValue`, `documentMultiValue`, etc.) may be available on expanded queries.

---

## ActionItem types (product)

| UI type | GraphQL hints | Typical integration |
|---------|---------------|---------------------|
| **Standard** | `PENDING_SUBMISSION` → `COMPLETED` | UI, email, webform, or completion mutation (inferred) |
| **Approval** | `requiresReview` | Approve/reject (inferred mutations) |
| **Automated / Integration** | Integration in blueprint | **HTTP callback** to GOE (Dell), not necessarily GraphQL |

---

## Operations

Open action items on a workflow use the same **`workflows`** query — see [workflows.md — workflows](workflows.md#workflows) and [workflow-req-res.md](workflow-req-res.md).

---

### actionItem

- **Type:** query
- **Confidence:** Confirmed (tenant)
- **Root field:** `actionItem` — response key `data.actionItem` (object)

Load one action item (UI: Task) by **`uuid`**. Numeric **`id`** is returned in the response (e.g. `3555`) but lookup uses `uuid`. Tenant capture: [task-req-res.md](task-req-res.md) (reference only; do not edit).

**GraphQL** (same shape as tenant sample)

```graphql
query {
  actionItem(input: { uuid: "HwkdOzdKTbE" }) {
    id
    name
    description
    dueOn
    dueOnClass
    status
    templateId
    comments {
      id
      text
      createdBy {
        id
      }
      createdAt
      documents {
        id
        name
        documentType {
          id
          name
        }
        comment {
          id
          text
          createdBy {
            id
          }
          createdAt
        }
      }
    }
    hasDocuments
    fieldInstances {
      field {
        fieldType
      }
      inputType
      updatedAt
      isCopy
    }
    documents {
      id
      name
      documentType {
        id
        name
      }
      comment {
        id
        text
        createdBy {
          id
        }
        createdAt
      }
    }
    assignees {
      id
    }
    requiresAck
    requiresReview
    workflowReference {
      stageId
      workflowId
    }
  }
}
```

**Variables (HTTP POST)**

```json
{
  "variables": { "uuid": "HwkdOzdKTbE" },
  "query": "query($uuid: String!) { actionItem(input: { uuid: $uuid }) { id name description dueOn dueOnClass status templateId hasDocuments requiresAck requiresReview workflowReference { stageId workflowId } assignees { id } fieldInstances { field { fieldType } inputType updatedAt isCopy } documents { id name documentType { id name } } comments { id text createdAt createdBy { id } documents { id name } } } }"
}
```

**Example response**

Full JSON is in [task-req-res.md](task-req-res.md#task-response). Root:

```json
{
  "data": {
    "actionItem": {
      "id": 3555,
      "name": "Upload feature matrix and roadmap​",
      "status": "COMPLETED",
      "dueOn": "2026-05-12T04:59:59.999Z",
      "dueOnClass": "OVERDUE",
      "workflowReference": { "stageId": 4540, "workflowId": 2078 },
      "documents": [],
      "comments": [],
      "assignees": [{ "id": 350 }]
    }
  }
}
```

**cURL**

```bash
curl -sS -X POST "${GRAPHQL_URL}" \
  -H "Authorization: Bearer ${ACCESS_TOKEN}" \
  -H "Content-Type: application/json" \
  -d '{
    "query": "query($uuid: String!) { actionItem(input: { uuid: $uuid }) { id name status dueOn dueOnClass workflowReference { stageId workflowId } assignees { id } documents { id name } comments { id text createdAt createdBy { id } } } }",
    "variables": { "uuid": "HwkdOzdKTbE" }
  }' | jq '.data.actionItem'
```

**Note:** `uuid` is not returned on `openActionItems` in the captured `workflows` query; obtain it from the Regrello UI or another API field.

### Activity / comments mapping (tenant)

| UI / doc concept | GraphQL in `actionItem` sample |
|------------------|--------------------------------|
| Document **name** | `documents[].name` |
| Activity feed | `comments[]` with `text`, `createdAt`, `createdBy.id` |
| **Assigned by** | Not in tenant sample; UI-only unless you add fields to the query |

---

### AssignedTasks (inferred)

- **Type:** query
- **Confidence:** Product / inferred

Equivalent to the **Assigned tasks** home view; exact root field name not in tenant samples (may be `assignedActionItems`, `assignedTasks`, etc.).

```graphql
query AssignedActionItems($limit: Int) {
  assignedActionItems(limit: $limit) {
    id
    name
    status
    dueOn
    workflowReference {
      workflowId
    }
  }
}
```

Confirm via introspection on your tenant.

---

### CompleteTask / Approve / Reject / Reopen (inferred)

Mutations such as `completeTask`, `approveTask`, `rejectTask`, and `reopenTask` are **not** in the Dell tenant samples. Many users complete items via **email** or **webform**. Dell automated flows use **integration action items** and **HTTP callbacks** to `/api/regrello/callback`.

If you discover mutation names on your tenant, document them next to [Regrello API Guides](https://regrello.notion.site/API-Guides-and-Documentation-4aeb8b52964840b98736e3883b848b84?pvs=24).

**Introspection filter**

```bash
curl -sS -X POST "${GRAPHQL_URL}" \
  -H "Authorization: Bearer ${ACCESS_TOKEN}" \
  -H "Content-Type: application/json" \
  -d '{"query":"{ __schema { mutationType { fields { name } } } }"}' \
  | jq '[.data.__schema.mutationType.fields[].name | select(test("(?i)action|task|complete|approve"))]'
```

---

## Workflow state effects (product)

| Workflow state | Action item behavior |
|----------------|----------------------|
| **Running** | Items can be completed per permissions |
| **Paused** | View/comment only; **cannot complete** |
| **Ended** | No further actions |

---

## UI vs GraphQL naming

| UI (How To) | GraphQL API |
|-------------|-------------|
| Task | `actionItem` |
| Open tasks on workflow | `workflows` → `openActionItems` |
| Task activity / messages | `comments` |
| Assigned by | UI field; not in tenant `actionItem` sample |
| Document name | `documents.name` |

Lifecycle: [README.md](README.md#lifecycle).
