# GraphQL Workflow

## Workflow Request - GraphQL Query

```graphql
{
  workflows(id: 2078) {
    scheduleStatus,
    hasException,
    daysDelayed
    endDate
    percentComplete
    numOpenActionItems
    plannedDueOn
    adjustedDueOn
    owner {
      user {
        name
        email
      }
    }
    openActionItems {
      id
      name
      status
      assignees {
        id
        user {
          name
        }
      }
    }
    topOpenActionItem {
      id
      name
      workflowReference{
        stageId
      }
    }
    stages{
      id
      name
    }
  }
}
```

## Workflow Response

```json
{
  "data": {
    "workflows": [
      {
        "scheduleStatus": "STARTED",
        "hasException": false,
        "daysDelayed": 0,
        "endDate": "2027-04-09T04:59:59.999Z",
        "percentComplete": 0.14,
        "numOpenActionItems": 5,
        "plannedDueOn": "2027-04-09T04:59:59.999Z",
        "adjustedDueOn": "2027-04-09T04:59:59.999Z",
        "owner": {
          "user": {
            "name": "tyler.roth@dellteam.com",
            "email": "tyler.roth@dellteam.com"
          }
        },
        "openActionItems": [
          {
            "id": 3566,
            "name": "Initiate extended team formation​",
            "status": "PENDING_SUBMISSION",
            "assignees": [
              {
                "id": 350,
                "user": {
                  "name": "tyler.roth@dellteam.com"
                }
              }
            ]
          },
          {
            "id": 3568,
            "name": "Conduct ODM supplier assessment before BA​",
            "status": "PENDING_SUBMISSION",
            "assignees": [
              {
                "id": 350,
                "user": {
                  "name": "tyler.roth@dellteam.com"
                }
              }
            ]
          },
          {
            "id": 3565,
            "name": "Identify initial NUDDs​",
            "status": "PENDING_SUBMISSION",
            "assignees": [
              {
                "id": 350,
                "user": {
                  "name": "tyler.roth@dellteam.com"
                }
              }
            ]
          },
          {
            "id": 3567,
            "name": "Conduct DFx assessment and engineering engagement",
            "status": "PENDING_SUBMISSION",
            "assignees": [
              {
                "id": 350,
                "user": {
                  "name": "tyler.roth@dellteam.com"
                }
              }
            ]
          },
          {
            "id": 3569,
            "name": "Close 1. Concept Phase",
            "status": "PENDING_SUBMISSION",
            "assignees": [
              {
                "id": 350,
                "user": {
                  "name": "tyler.roth@dellteam.com"
                }
              }
            ]
          }
        ],
        "topOpenActionItem": {
          "id": 3566,
          "name": "Initiate extended team formation​",
          "workflowReference": {
            "stageId": 4541
          }
        },
        "stages": [
          {
            "id": 4539,
            "name": "1. Concept Phase Launch"
          },
          {
            "id": 4540,
            "name": "Upload Concept Documentation"
          },
          {
            "id": 4541,
            "name": "Initial extended team formed"
          },
          {
            "id": 4542,
            "name": "Early end 2 end supply chain NUDD identified"
          },
          {
            "id": 4543,
            "name": "Early DFx NUDDs Identified"
          },
          {
            "id": 4544,
            "name": "Early SMA audit completed "
          },
          {
            "id": 4545,
            "name": "ODM improvement Plan formulated"
          },
          {
            "id": 4546,
            "name": "1. Concept Phase Close"
          },
          {
            "id": 4547,
            "name": "2. Define Phase Launch"
          },
          {
            "id": 4548,
            "name": "Upload Define phase documentation"
          },
          {
            "id": 4549,
            "name": "Extended team expanded & finalized"
          },
          {
            "id": 4550,
            "name": "OE requirement locked"
          },
          {
            "id": 4551,
            "name": "Mitigation Plans formulated for early identified NUDDs"
          },
          {
            "id": 4552,
            "name": "Additional NUDDs identified"
          },
          {
            "id": 4553,
            "name": "New test requirements identified"
          },
          {
            "id": 4554,
            "name": "Relevant dependencies mapped (if applicable to critical transitions)"
          },
          {
            "id": 4555,
            "name": "Relevant dependencies mapped (if applicable to critical transitions)"
          },
          {
            "id": 4556,
            "name": "2. Define Phase Close"
          },
          {
            "id": 4557,
            "name": "3. Plan Phase Launch"
          },
          {
            "id": 4558,
            "name": "Development builds, phase gates, OLP schedule locked"
          },
          {
            "id": 4559,
            "name": "WW fulfillment plan confirmed"
          },
          {
            "id": 4560,
            "name": "Relevant dependencies mapped (if applicable to critical transitions)"
          },
          {
            "id": 4561,
            "name": "Upload Plan phase documentation"
          },
          {
            "id": 4562,
            "name": "NUDDs mitigation plans locked"
          },
          {
            "id": 4563,
            "name": "WW FRC & RTO volume ramp plan locked"
          },
          {
            "id": 4564,
            "name": "Manufacturing plan confirmed"
          },
          {
            "id": 4565,
            "name": "ODM BA score"
          },
          {
            "id": 4566,
            "name": "KPI aligned (yield, quality, FIR & IFIR goals)"
          },
          {
            "id": 4567,
            "name": "SQE MEDF Phase Gate #2 exited"
          },
          {
            "id": 4568,
            "name": "Test coverage analysis completed and ITM tests planned"
          },
          {
            "id": 4569,
            "name": "DFx design plan locked"
          }
        ]
      }
    ]
  }
}
```

