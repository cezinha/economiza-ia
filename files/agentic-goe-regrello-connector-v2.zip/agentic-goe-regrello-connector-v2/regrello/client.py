"""Regrello API client for workflow and document management.

Provides async methods for:
- OAuth2 authentication (client credentials flow)
- Document creation and upload
- Workflow creation from templates
"""

from __future__ import annotations

import logging
import mimetypes
from typing import Any

import httpx

from regrello.config import Settings


class RegrelloClient:
    """Async client for Regrello workflow management API.

    - Manages OAuth2 authentication with automatic token refresh
    - Provides methods for document and workflow operations
    - Uses GraphQL for API interactions
    - Uses default `httpx` SSL verification behavior

    Example:
        ```python
        async with RegrelloClient() as client:
            # Authenticate
            await client.authenticate()

            # Create and upload document
            doc_id = await client.create_and_upload_document("file.pdf", b"content")

            # Create workflow
            workflow_id = await client.create_workflow(
                name="My Workflow",
                document_ids=[doc_id],
                field_instances=[...]
            )
        ```
    """

    def __init__(
        self,
        settings: Settings | None = None,
        client: httpx.AsyncClient | None = None,
        timeout: float | None = 30.0,
    ) -> None:
        """Initialize Regrello client.

        Args:
            settings: Configuration settings (loads from env if not provided)
            client: Optional httpx.AsyncClient for testing
            timeout: Request timeout in seconds
        """
        self._settings = settings or Settings()
        self._access_token: str | None = None
        self._verify_ssl: bool = self._settings.regrello_verify_ssl

        # Build URLs
        base_url = self._settings.regrello_base_url.rstrip("/")
        self._token_url = f"{base_url}/oauth/{self._settings.regrello_workspace_id}/token"
        self._graphql_url = (
            f"{base_url}/customer/workspace/{self._settings.regrello_workspace_id}/query"
        )

        # SSL verification setup
        # - `verify=True`: use default httpx/OpenSSL trust behavior
        # - `verify=False`: disable SSL verification (dev/test only)
        if not self._verify_ssl:
            logging.warning(
                "REGRELLO_VERIFY_SSL is false; SSL certificate verification is disabled"
            )

        self._client = client or httpx.AsyncClient(timeout=timeout, verify=self._verify_ssl)

    async def aclose(self) -> None:
        """Close the HTTP client."""
        await self._client.aclose()

    async def __aenter__(self) -> RegrelloClient:
        return self

    async def __aexit__(self, *exc: Any) -> None:  # type: ignore[override]
        await self.aclose()

    async def authenticate(self) -> str:
        """Obtain OAuth2 access token using client credentials flow.

        Returns:
            Access token string

        Raises:
            RuntimeError: If authentication fails
        """
        headers = {"Content-Type": "application/x-www-form-urlencoded"}
        data = {
            "grant_type": "client_credentials",
            "client_id": self._settings.regrello_client_id,
            "client_secret": self._settings.regrello_client_secret,
        }
        try:
            response = await self._client.post(self._token_url, headers=headers, data=data)
            response.raise_for_status()
        except httpx.HTTPError as e:
            logging.error(f"Authentication failed: {e}")
            raise RuntimeError(f"Authentication failed: {e}") from e

        token_data = response.json()
        self._access_token = token_data.get("access_token")

        if not self._access_token:
            raise RuntimeError("No access token in response")

        return self._access_token

    def _get_auth_headers(self) -> dict[str, str]:
        """Get headers with authorization token.

        Returns:
            Headers dict with Authorization and Content-Type

        Raises:
            RuntimeError: If not authenticated
        """
        if not self._access_token:
            raise RuntimeError("Not authenticated. Call authenticate() first.")

        return {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {self._access_token}",
        }

    def _build_graphql_payload(
        self,
        query: str,
        variables: dict[str, Any] | None = None,
        operation_name: str | None = None,
    ) -> dict[str, Any]:
        payload: dict[str, Any] = {"query": query}
        if variables:
            payload["variables"] = variables
        if operation_name:
            payload["operationName"] = operation_name
        return payload

    async def _post_graphql_payload(self, payload: dict[str, Any]) -> dict[str, Any]:
        """POST a GraphQL envelope and return the full JSON body."""
        headers = self._get_auth_headers()
        data: dict[str, Any] = {}
        try:
            response = await self._client.post(
                self._graphql_url,
                headers=headers,
                json=payload,
            )
            data = response.json()
            logging.debug(f"GraphQL response data: {data}")
            response.raise_for_status()
        except httpx.HTTPError as e:
            logging.error(f"GraphQL request failed: {e} \n error \n {data}")
            raise RuntimeError(f"GraphQL request failed: {e} \n error \n {data}") from e
        return data

    async def execute_graphql(
        self,
        query: str,
        variables: dict[str, Any] | None = None,
        operation_name: str | None = None,
    ) -> dict[str, Any]:
        """Execute a GraphQL request and return the full Regrello JSON response.

        Unlike ``_graphql_request``, top-level ``errors`` are returned as-is
        (no ``RuntimeError``) so callers can handle GraphQL-level failures.
        """
        payload = self._build_graphql_payload(query, variables, operation_name)
        return await self._post_graphql_payload(payload)

    async def _graphql_request(
        self,
        query: str,
        variables: dict[str, Any] | None = None,
        operation_name: str | None = None,
    ) -> dict[str, Any]:
        """Execute a GraphQL request.

        Args:
            query: GraphQL query or mutation string
            variables: Query variables
            operation_name: Optional operation name

        Returns:
            Response data dict

        Raises:
            RuntimeError: If request fails or returns errors
        """
        payload = self._build_graphql_payload(query, variables, operation_name)
        data = await self._post_graphql_payload(payload)

        if "errors" in data:
            error_messages = [err.get("message", str(err)) for err in data["errors"]]
            raise RuntimeError(f"GraphQL errors: {', '.join(error_messages)}")

        return data.get("data", {})

    async def create_document(self, filename: str) -> tuple[str, str]:
        """Create a document and get a signed upload URL.

        Args:
            filename: Name of the document to create

        Returns:
            Tuple of (signed_url, document_id)

        Raises:
            RuntimeError: If document creation fails
        """
        query = """
        mutation CreateDocumentMutation($filename: String!) {
          createDocument(input: {name: $filename}) {
            error
            document { id name __typename }
            signedUrl
            __typename
          }
        }
        """

        data = await self._graphql_request(
            query=query,
            variables={"filename": filename},
            operation_name="CreateDocumentMutation",
        )

        create_result = data.get("createDocument", {})

        if create_result.get("error"):
            raise RuntimeError(f"Document creation error: {create_result['error']}")

        signed_url = create_result.get("signedUrl")
        document = create_result.get("document", {})
        document_id = document.get("id")

        if not signed_url or not document_id:
            raise RuntimeError("Missing signed URL or document ID in response")

        return signed_url, document_id

    async def upload_file_to_url(self, signed_url: str, file_content: bytes, filename: str) -> None:
        """Upload file content to a signed URL.

        Args:
            signed_url: Pre-signed upload URL from create_document
            file_content: File content as bytes
            filename: Original filename (used to determine MIME type)

        Raises:
            RuntimeError: If upload fails
        """
        mime_type, _ = mimetypes.guess_type(filename)
        mime_type = mime_type or "application/octet-stream"

        headers = {"Content-Type": mime_type}

        try:
            response = await self._client.put(signed_url, content=file_content, headers=headers)
            response.raise_for_status()
        except httpx.HTTPError as e:
            raise RuntimeError(f"File upload failed: {e}") from e

    async def create_and_upload_document(self, filename: str, file_content: bytes) -> str:
        """Create a document and upload its content in one operation.

        Args:
            filename: Name of the document
            file_content: File content as bytes

        Returns:
            Document ID

        Raises:
            RuntimeError: If creation or upload fails
        """
        signed_url, document_id = await self.create_document(filename)
        await self.upload_file_to_url(signed_url, file_content, filename)
        return document_id

    async def create_workflow(
        self,
        field_instances: list[dict[str, Any]],
        documents: list[tuple[str, bytes]] | None = None,
        workflow_template_id: int | None = None,
        start_condition: str = "START_IMMEDIATELY",
        tag_ids: list[str] | None = None,
    ) -> dict[str, Any]:
        """Create a workflow from a template with automatic document handling.

        This method automatically detects if documents need to be uploaded based on:
        1. The `documents` parameter being provided
        2. Document placeholders ($doc_N) in field_instances

        If documents are provided, they are uploaded first and placeholders are resolved.

        Args:
            name: Workflow name
            field_instances: List of field instance configurations, each containing:
                - fieldId: Field identifier
                - inputType: "REQUESTED" or "OPTIONAL"
                - displayOrder: Display order number
                - Value fields (one of):
                    - stringValue: Single string value
                    - stringMultiValue: List of strings
                    - documentMultiValue: List of document IDs or "$doc_N" placeholders
            documents: Optional list of (filename, content) tuples to upload.
                Use "$doc_N" in documentMultiValue to reference the Nth document (0-indexed)
            workflow_template_id: Template ID (uses setting default if not provided)
            start_condition: When to start ("START_IMMEDIATELY", etc.)
            tag_ids: Optional list of tag IDs

        Returns:
            Dict containing:
                - workflow_id: Created workflow ID
                - document_ids: List of uploaded document IDs (empty if no documents)

        Raises:
            RuntimeError: If workflow creation fails
            ValueError: If invalid document reference is used

        Examples:
            Without documents:
            ```python
            result = await client.create_workflow(
                name="Simple Workflow",
                field_instances=[
                    {
                        "fieldId": 1037,
                        "stringValue": "My Value",
                        "inputType": "REQUESTED",
                        "displayOrder": 1
                    }
                ]
            )
            # Returns: {"workflow_id": "...", "document_ids": []}
            ```

            With documents (using placeholders):
            ```python
            result = await client.create_workflow(
                name="Document Workflow",
                documents=[
                    ("baseline.pdf", baseline_content),
                    ("current.pdf", current_content),
                ],
                field_instances=[
                    {
                        "fieldId": 1037,
                        "stringValue": "Product",
                        "inputType": "REQUESTED",
                        "displayOrder": 1
                    },
                    {
                        "fieldId": 1042,
                        "documentMultiValue": ["$doc_0"],  # First document
                        "inputType": "OPTIONAL",
                        "displayOrder": 2
                    },
                    {
                        "fieldId": 1043,
                        "documentMultiValue": ["$doc_1"],  # Second document
                        "inputType": "REQUESTED",
                        "displayOrder": 3
                    }
                ]
            )
            # Returns: {"workflow_id": "...", "document_ids": ["doc1_id", "doc2_id"]}
            ```

            With pre-uploaded documents (using actual IDs):
            ```python
            doc_id = await client.create_and_upload_document("file.pdf", content)
            result = await client.create_workflow(
                name="Workflow with ID",
                field_instances=[
                    {
                        "fieldId": 1042,
                        "documentMultiValue": [doc_id],  # Direct document ID
                        "inputType": "OPTIONAL",
                        "displayOrder": 1
                    }
                ]
            )
            ```
        """
        document_ids = await self._upload_documents(documents)
        resolved_field_instances = self._resolve_field_instances(field_instances, document_ids)

        variables = self._build_workflow_variables(
            field_instances=resolved_field_instances,
            workflow_template_id=workflow_template_id,
            start_condition=start_condition,
            tag_ids=tag_ids,
        )

        workflow_id = await self._execute_workflow_creation(variables)

        return {
            "workflow_id": workflow_id,
            "document_ids": document_ids,
        }

    async def get_workflow_status(
        self,
        workflow_id: str,
        workflow_template_id: int | None = None,
    ) -> dict[str, Any]:
        """Retrieve the current status of a workflow by ID.

        Args:
            workflow_id: Workflow identifier to look up.
            workflow_template_id: Optional template ID override. Falls back to
                `REGRELLO_WORKFLOW_TEMPLATE_ID` if not provided.
        """
        template_id = workflow_template_id or self._settings.regrello_workflow_template_id

        if template_id is None:
            raise ValueError(
                "workflow_template_id is required. Pass it to get_workflow_status() or"
                " set REGRELLO_WORKFLOW_TEMPLATE_ID in your environment."
            )

        query = """
        query WorkflowStatus($id: ID!) {
            workflows(id: $id) {
                # Basic Info
                id
                name
                description
                referenceNumber
                referenceNumberPrefix
                status: scheduleStatus  # Mapped from scheduleStatus enum
                # Timing & Status
                createdAt
                startedAt
                completedAt
                endedAt
                updatedAt
                percentComplete
                daysDelayed
                isLocked
                hasException

                # Blueprint/Template Info
                blueprint {
                    id
                    name
                }

                # Progress Info
                stages {
                    id
                    name
                    status
                }
                # Tracking
                tags {
                    id
                    name
                }
                __typename
            }
        }
        """

        data = await self._graphql_request(
            query=query,
            variables={
                "id": workflow_id,
            },
            operation_name="WorkflowStatus",
        )

        workflow = data.get("workflow")

        if not workflow:
            raise RuntimeError(f"Workflow {workflow_id} not found")

        return workflow

    async def get_workflow_template_fields(
        self,
        workflow_template_id: int | None = None,
        document_field_ids: list[int] | None = None,
    ) -> list[dict[str, Any]]:
        """Return normalized field definitions ready for `create_workflow`.

        Args:
            workflow_template_id: Template ID override (uses env default otherwise).
            document_field_ids: Optional explicit list of field IDs that should be
                treated as document uploads (overrides heuristic detection).

        Returns:
            Sorted list of field-instance configs (unique by fieldId).
        """
        template_id = workflow_template_id or self._settings.regrello_workflow_template_id

        if template_id is None:
            raise ValueError(
                "workflow_template_id is required. Pass it to"
                " get_workflow_template_fields() or set REGRELLO_WORKFLOW_TEMPLATE_ID"
                " in your environment."
            )

        field_instances = await self._fetch_workflow_template_field_instances(template_id)
        return self._process_workflow_template_fields(
            field_instances,
            document_field_ids=document_field_ids,
        )

    async def get_workflow_template_field_metadata(
        self,
        workflow_template_id: int | None = None,
    ) -> list[dict[str, Any]]:
        """Return metadata for REQUESTED/OPTIONAL fields on a workflow template."""

        template_id = workflow_template_id or self._settings.regrello_workflow_template_id

        if template_id is None:
            raise ValueError(
                "workflow_template_id is required. Pass it to"
                " get_workflow_template_field_metadata() or set"
                " REGRELLO_WORKFLOW_TEMPLATE_ID in your environment."
            )

        field_instances = await self._fetch_workflow_template_field_instances(template_id)
        return self._build_field_metadata(field_instances)

    async def _fetch_workflow_template_field_instances(
        self, template_id: int
    ) -> list[dict[str, Any]]:
        query = """
        query WorkflowTemplateFields($id: ID!) {
            workflowTemplates(id: $id) {
                id
                name
                description
                fieldInstances {
                    id
                    inputType
                    displayOrder
                    originalInputType
                    spectrumFieldVersion {
                        name
                        description
                        validationType {
                            validationType
                        }
                    }
                    field {
                        id
                        name
                        description
                        isMultiValued
                        fieldType
                        fieldUnit { name }
                        scimAttributeName
                        spectrumField {
                            id
                            uuid
                        }
                    }
                }
            }
        }
        """

        data = await self._graphql_request(
            query=query,
            variables={"id": template_id},
            operation_name="WorkflowTemplateFields",
        )

        templates = data.get("workflowTemplates") or []
        if not templates:
            raise RuntimeError(f"Workflow template {template_id} not found")

        return templates[0].get("fieldInstances", [])

    def _process_workflow_template_fields(
        self,
        field_instances: list[dict[str, Any]],
        document_field_ids: list[int] | None = None,
    ) -> list[dict[str, Any]]:
        """Build field-instance templates ready to plug into create_workflow()."""
        allowed_input_types = {"REQUESTED", "OPTIONAL"}
        document_id_set = {str(fid) for fid in document_field_ids or []}
        fields_by_id: dict[str, dict[str, Any]] = {}

        for instance in field_instances:
            input_type = instance.get("inputType")
            if input_type not in allowed_input_types:
                continue

            field_info = instance.get("field") or {}
            field_id = field_info.get("id")
            if not field_id:
                continue

            display_order = instance.get("displayOrder")
            is_multi = bool(field_info.get("isMultiValued"))
            is_document = self._is_document_field(field_info, document_id_set)
            value_key = self._determine_value_key(is_multi=is_multi, is_document=is_document)
            value_placeholder: Any = [] if value_key.endswith("MultiValue") else ""

            normalized = {
                "fieldId": field_id,
                "inputType": input_type,
                "displayOrder": display_order,
                value_key: value_placeholder,
            }

            existing = fields_by_id.get(field_id)
            if existing is None or (
                display_order is not None
                and (
                    existing.get("displayOrder") is None
                    or display_order < existing.get("displayOrder")
                )
            ):
                fields_by_id[field_id] = normalized

        def sort_key(item: dict[str, Any]) -> tuple[bool, Any]:
            order = item.get("displayOrder")
            return (order is None, order)

        return sorted(fields_by_id.values(), key=sort_key)

    def _build_field_metadata(self, field_instances: list[dict[str, Any]]) -> list[dict[str, Any]]:
        allowed_input_types = {"REQUESTED", "OPTIONAL"}
        metadata_by_field: dict[int, dict[str, Any]] = {}

        for instance in field_instances:
            input_type = instance.get("inputType")
            if input_type not in allowed_input_types:
                continue

            field_info = instance.get("field") or {}
            field_id = field_info.get("id")
            if field_id is None:
                continue

            display_order = instance.get("displayOrder")
            validation_type = (
                (instance.get("spectrumFieldVersion") or {}).get("validationType") or {}
            ).get("validationType")

            candidate = {
                "fieldId": field_id,
                "fieldName": field_info.get("name"),
                "inputType": input_type,
                "displayOrder": display_order,
                "isMultiValued": bool(field_info.get("isMultiValued")),
                "dataType": validation_type,
            }

            existing = metadata_by_field.get(field_id)
            if existing is None or (
                display_order is not None
                and (
                    existing.get("displayOrder") is None
                    or display_order < existing.get("displayOrder")
                )
            ):
                metadata_by_field[field_id] = candidate

        def sort_key(item: dict[str, Any]) -> tuple[bool, Any]:
            order = item.get("displayOrder")
            return (order is None, order)

        return sorted(metadata_by_field.values(), key=sort_key)

    @staticmethod
    def _determine_value_key(*, is_multi: bool, is_document: bool) -> str:
        """Map document/string detection and multiplicity to payload keys."""
        if is_document:
            return "documentMultiValue" if is_multi else "documentValue"
        return "stringMultiValue" if is_multi else "stringValue"

    @staticmethod
    def _is_document_field(field_info: dict[str, Any], document_id_set: set[str] | None) -> bool:
        field_id = str(field_info.get("id", ""))
        if field_id and document_id_set and field_id in document_id_set:
            return True

        name = (field_info.get("name") or "").lower()
        unit_name = ((field_info.get("fieldUnit") or {}).get("name") or "").lower()
        doc_keywords = ("document", "attachment", "file", "upload")

        if any(keyword in name for keyword in doc_keywords):
            return True

        return unit_name in {"document", "file"}

    async def _upload_documents(self, documents: list[tuple[str, bytes]] | None) -> list[str]:
        """Upload provided documents and return their IDs."""
        if not documents:
            return []

        document_ids = []
        for filename, content in documents:
            doc_id = await self.create_and_upload_document(filename, content)
            document_ids.append(doc_id)
        return document_ids

    def _resolve_field_instances(
        self,
        field_instances: list[dict[str, Any]],
        document_ids: list[str],
    ) -> list[dict[str, Any]]:
        """Replace document placeholders with uploaded document IDs when needed."""
        if not document_ids:
            return field_instances

        resolved_field_instances: list[dict[str, Any]] = []
        for config in field_instances:
            config_copy = config.copy()

            if "documentMultiValue" in config_copy:
                config_copy["documentMultiValue"] = [
                    self._resolve_document_reference(doc_ref, document_ids)
                    for doc_ref in config_copy["documentMultiValue"]
                ]

            resolved_field_instances.append(config_copy)

        return resolved_field_instances

    def _resolve_document_reference(self, doc_ref: Any, document_ids: list[str]) -> Any:
        """Resolve document placeholder references (e.g., $doc_0)."""
        if isinstance(doc_ref, str) and doc_ref.startswith("$doc_"):
            try:
                idx = int(doc_ref.split("_")[1])
            except (IndexError, ValueError) as exc:
                raise ValueError(f"Invalid document placeholder: {doc_ref}") from exc

            if idx >= len(document_ids):
                raise ValueError(
                    f"Invalid document reference: {doc_ref}. "
                    f"Only {len(document_ids)} documents provided."
                )

            return document_ids[idx]

        return doc_ref

    def _build_workflow_variables(
        self,
        *,
        field_instances: list[dict[str, Any]],
        workflow_template_id: int | None,
        start_condition: str,
        tag_ids: list[str] | None,
    ) -> dict[str, Any]:
        """Construct GraphQL variables payload for workflow creation."""
        template_id = workflow_template_id or self._settings.regrello_workflow_template_id

        if template_id is None:
            raise ValueError(
                "workflow_template_id is required. Pass it to create_workflow() or set"
                " REGRELLO_WORKFLOW_TEMPLATE_ID in your environment."
            )

        return {
            "input": {
                "fieldInstances": field_instances,
                "startCondition": start_condition,
                "tagIds": tag_ids or [],
                "workflowTemplateId": template_id,
            }
        }

    async def _execute_workflow_creation(self, variables: dict[str, Any]) -> str:
        """Execute the workflow creation GraphQL mutation and return the workflow ID."""
        query = """
        mutation CreateWorkflowFromTemplateMutation($input: CreateWorkflowFromTemplateInputs!) {
            createWorkflowFromTemplate(input: $input) {
                workflow { id }
                error
            }
        }
        """
        data = await self._graphql_request(
            query=query,
            variables=variables,
            operation_name="CreateWorkflowFromTemplateMutation",
        )

        logging.debug(f"Workflow creation response data: {data}")

        create_result = data.get("createWorkflowFromTemplate", {})

        if create_result.get("error"):
            raise RuntimeError(f"Workflow creation error: {create_result['error']}")

        workflow = create_result.get("workflow", {})
        workflow_id = workflow.get("id")

        if not workflow_id:
            raise RuntimeError("Missing workflow ID in response")

        return workflow_id
