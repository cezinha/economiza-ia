"""Regrello API route tests with mocked workflow backend."""

from unittest.mock import AsyncMock, MagicMock

import pytest
from fastapi.testclient import TestClient

from app.main import app
from app.workflows.deps import get_workflow_backend


@pytest.fixture
def mock_backend() -> MagicMock:
    backend = MagicMock()
    backend.execute_graphql = AsyncMock(
        return_value={"data": {"workflows": {"workflows": []}}, "errors": None},
    )
    backend.aclose = AsyncMock()
    return backend


@pytest.fixture
def client_with_mock(mock_backend: MagicMock) -> TestClient:
    async def _override():
        yield mock_backend

    app.dependency_overrides[get_workflow_backend] = _override
    yield TestClient(app)
    app.dependency_overrides.clear()


def test_execute_graphql(client_with_mock: TestClient, mock_backend: MagicMock) -> None:
    """POST `/regrello/graphql` delegates to the workflow backend ``execute_graphql``."""

    response = client_with_mock.post(
        "/regrello/graphql",
        json={
            "operationName": "WorkflowStatus",
            "query": "query WorkflowStatus { __typename }",
            "variables": {},
        },
    )
    assert response.status_code == 200
    assert response.json() == {
        "data": {"workflows": {"workflows": []}},
        "errors": None,
    }
    mock_backend.execute_graphql.assert_awaited_once_with(
        query="query WorkflowStatus { __typename }",
        variables={},
        operation_name="WorkflowStatus",
    )


def test_execute_graphql_502_on_backend_error(
    client_with_mock: TestClient,
    mock_backend: MagicMock,
) -> None:
    mock_backend.execute_graphql = AsyncMock(side_effect=ValueError("bad graphql"))
    response = client_with_mock.post(
        "/regrello/graphql",
        json={"query": "query Q { __typename }"},
    )
    assert response.status_code == 502


def test_workflows_graphql_route_removed(client_with_mock: TestClient) -> None:
    """Legacy ``POST /workflows/graphql`` is no longer registered."""

    response = client_with_mock.post(
        "/workflows/graphql",
        json={"query": "query Q { __typename }"},
    )
    assert response.status_code == 404
