"""Unit tests for ``RegrelloClient.execute_graphql`` passthrough behavior."""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock

import httpx
import pytest

from regrello.client import RegrelloClient
from regrello.config import Settings


@pytest.mark.asyncio
async def test_execute_graphql_returns_full_body_with_errors() -> None:
    mock_http = MagicMock()
    mock_response = MagicMock()
    mock_response.json.return_value = {
        "data": None,
        "errors": [{"message": "field not found"}],
    }
    mock_response.raise_for_status = MagicMock()
    mock_http.post = AsyncMock(return_value=mock_response)

    settings = Settings(
        regrello_base_url="https://tenant.regrello.com",
        regrello_workspace_id="ws",
        regrello_client_id="id",
        regrello_client_secret="secret",
    )
    client = RegrelloClient(settings=settings, client=mock_http)
    client._access_token = "token"

    result = await client.execute_graphql(
        query="query Q { missing }",
        variables={"id": "1"},
        operation_name="Q",
    )

    assert result == {
        "data": None,
        "errors": [{"message": "field not found"}],
    }
    mock_http.post.assert_awaited_once()
    call_kwargs = mock_http.post.await_args.kwargs
    assert call_kwargs["json"] == {
        "query": "query Q { missing }",
        "variables": {"id": "1"},
        "operationName": "Q",
    }


@pytest.mark.asyncio
async def test_graphql_request_raises_on_errors() -> None:
    mock_http = MagicMock()
    mock_response = MagicMock()
    mock_response.json.return_value = {
        "data": None,
        "errors": [{"message": "boom"}],
    }
    mock_response.raise_for_status = MagicMock()
    mock_http.post = AsyncMock(return_value=mock_response)

    settings = Settings(
        regrello_base_url="https://tenant.regrello.com",
        regrello_workspace_id="ws",
        regrello_client_id="id",
        regrello_client_secret="secret",
    )
    client = RegrelloClient(settings=settings, client=mock_http)
    client._access_token = "token"

    with pytest.raises(RuntimeError, match="GraphQL errors"):
        await client._graphql_request(query="query Q { x }")
