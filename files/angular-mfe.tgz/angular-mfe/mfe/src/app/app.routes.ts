import { Routes } from '@angular/router';
import { MFE_ROUTES } from './mfe.routes';

export const routes: Routes = [
  ...MFE_ROUTES,
];
