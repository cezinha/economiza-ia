import { Component } from '@angular/core';
import { RouterLink, RouterOutlet } from '@angular/router';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet, RouterLink],
  template: `
    <nav>
      <a routerLink="/settings">Settings</a> |
      <a routerLink="/reports">Reports</a>
    </nav>
    <router-outlet />
  `,
})
export class App {}
