import { Routes } from '@angular/router';
import { SettingsComponent } from './settings/settings';
import { ReportsComponent } from './reports/reports';

export const MFE_ROUTES: Routes = [
  { path: 'settings', component: SettingsComponent },
  { path: 'reports', component: ReportsComponent },
  { path: '', redirectTo: 'settings', pathMatch: 'full' },
];
