import { Component } from '@angular/core';

@Component({
  selector: 'app-settings',
  template: `
    <h2>Settings</h2>
    <p>MFE Settings page</p>
  `,
})
export class SettingsComponent {}
