import { Routes } from '@angular/router';
import { loadRemoteModule } from '@angular-architects/native-federation';

export const routes: Routes = [
  {
    path: 'mfe',
    loadChildren: () =>
      loadRemoteModule('mfe', './routes').then((m) => m.MFE_ROUTES),
  },
  { path: '', redirectTo: 'mfe', pathMatch: 'full' },
];
