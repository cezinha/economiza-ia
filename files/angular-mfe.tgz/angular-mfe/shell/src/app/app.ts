import { Component } from '@angular/core';
import { RouterLink, RouterOutlet } from '@angular/router';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet, RouterLink],
  template: `
    <h1>Shell</h1>
    <nav>
      <a routerLink="/mfe/settings">MFE Settings</a> |
      <a routerLink="/mfe/reports">MFE Reports</a>
    </nav>
    <router-outlet />
  `,
})
export class App {}
