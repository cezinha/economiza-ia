import {
  BrnSelect
} from "./chunk-DGNG5AUF.js";
import "./chunk-2FT3RPXR.js";
import "./chunk-7B5RDSRQ.js";
import "./chunk-SJN2AHIS.js";
import "./chunk-X766NLSK.js";
import "./chunk-Q5UOOUVD.js";
import "./chunk-J4GGTL6S.js";
import "./chunk-X3574FFZ.js";
import "./chunk-TOVIQ4AT.js";
import "./chunk-IFMDODVZ.js";
import "./chunk-XNZ3Q47O.js";
import {
  injectDateAdapter
} from "./chunk-KH75PGHH.js";
import "./chunk-TKOMAHN7.js";
import "./chunk-HWBMUYTH.js";
import "./chunk-A5BOFX7I.js";
import "./chunk-T5HKIHIO.js";
import "./chunk-GZX5U5ZF.js";
import "./chunk-4SZ4RQJX.js";
import "./chunk-ILAJV3NO.js";
import {
  ChangeDetectorRef,
  ContentChild,
  ContentChildren,
  Directive,
  ElementRef,
  Injectable,
  Input,
  Output,
  TemplateRef,
  ViewContainerRef,
  afterNextRender,
  booleanAttribute,
  contentChild,
  contentChildren,
  input,
  model,
  numberAttribute,
  setClassMetadata,
  ɵɵProvidersFeature,
  ɵɵattribute,
  ɵɵcontentQuerySignal,
  ɵɵdefineDirective,
  ɵɵdomProperty,
  ɵɵlistener,
  ɵɵqueryAdvance
} from "./chunk-4U2MKPNG.js";
import {
  InjectionToken,
  Injector,
  computed,
  effect,
  forwardRef,
  inject,
  linkedSignal,
  signal,
  untracked,
  ɵɵdefineInjectable
} from "./chunk-J672K7WJ.js";
import "./chunk-RSS3ODKE.js";
import {
  __spreadProps,
  __spreadValues
} from "./chunk-S5KMCARS.js";

// node_modules/@spartan-ng/brain/fesm2022/spartan-ng-brain-calendar.mjs
var BrnCalendarToken = new InjectionToken("BrnCalendarToken");
function provideBrnCalendar(instance) {
  return {
    provide: BrnCalendarToken,
    useExisting: instance
  };
}
function injectBrnCalendar() {
  return inject(BrnCalendarToken);
}
var BrnCalendarCellButton = class _BrnCalendarCellButton {
  /** Access the date adapter */
  _dateAdapter = injectDateAdapter();
  /** Access the calendar component */
  _calendar = injectBrnCalendar();
  /** Access the element ref */
  _elementRef = inject(ElementRef);
  /** The date this cell represents */
  date = input.required(...ngDevMode ? [{
    debugName: "date"
  }] : []);
  /** Whether this date is currently selected */
  selected = computed(() => this._calendar.isSelected(this.date()), ...ngDevMode ? [{
    debugName: "selected"
  }] : []);
  start = computed(() => this._calendar.isStartOfRange(this.date()), ...ngDevMode ? [{
    debugName: "start"
  }] : []);
  end = computed(() => this._calendar.isEndOfRange(this.date()), ...ngDevMode ? [{
    debugName: "end"
  }] : []);
  betweenRange = computed(() => this._calendar.isBetweenRange(this.date()), ...ngDevMode ? [{
    debugName: "betweenRange"
  }] : []);
  /** Whether this date is focusable */
  focusable = computed(() => this._dateAdapter.isSameDay(this._calendar.focusedDate(), this.date()), ...ngDevMode ? [{
    debugName: "focusable"
  }] : []);
  outside = computed(() => {
    const focusedDate = this._calendar.focusedDate();
    return !this._dateAdapter.isSameMonth(this.date(), focusedDate);
  }, ...ngDevMode ? [{
    debugName: "outside"
  }] : []);
  /** Whether this date is today */
  today = computed(() => this._dateAdapter.isSameDay(this.date(), this._dateAdapter.now()), ...ngDevMode ? [{
    debugName: "today"
  }] : []);
  /** Whether this date is disabled */
  disabled = computed(() => this._calendar.isDateDisabled(this.date()) || this._calendar.disabled(), ...ngDevMode ? [{
    debugName: "disabled"
  }] : []);
  /**
   * Focus the previous cell.
   */
  focusPrevious(event) {
    event.preventDefault();
    event.stopPropagation();
    const targetDate = this._dateAdapter.add(this._calendar.focusedDate(), {
      days: this.getDirection() === "rtl" ? 1 : -1
    });
    this._calendar.setFocusedDate(targetDate);
  }
  /**
   * Focus the next cell.
   */
  focusNext(event) {
    event.preventDefault();
    event.stopPropagation();
    const targetDate = this._dateAdapter.add(this._calendar.focusedDate(), {
      days: this.getDirection() === "rtl" ? -1 : 1
    });
    this._calendar.setFocusedDate(targetDate);
  }
  /**
   * Focus the above cell.
   */
  focusAbove(event) {
    event.preventDefault();
    event.stopPropagation();
    this._calendar.setFocusedDate(this._dateAdapter.subtract(this._calendar.focusedDate(), {
      days: 7
    }));
  }
  /**
   * Focus the below cell.
   */
  focusBelow(event) {
    event.preventDefault();
    event.stopPropagation();
    this._calendar.setFocusedDate(this._dateAdapter.add(this._calendar.focusedDate(), {
      days: 7
    }));
  }
  /**
   * Focus the first date of the month.
   */
  focusFirst(event) {
    event.preventDefault();
    event.stopPropagation();
    this._calendar.setFocusedDate(this._dateAdapter.startOfMonth(this._calendar.focusedDate()));
  }
  /**
   * Focus the last date of the month.
   */
  focusLast(event) {
    event.preventDefault();
    event.stopPropagation();
    this._calendar.setFocusedDate(this._dateAdapter.endOfMonth(this._calendar.focusedDate()));
  }
  /**
   * Focus the same date in the previous month.
   */
  focusPreviousMonth(event) {
    event.preventDefault();
    event.stopPropagation();
    const date = this._dateAdapter.getDate(this._calendar.focusedDate());
    let previousMonthTarget = this._dateAdapter.startOfMonth(this._calendar.focusedDate());
    previousMonthTarget = this._dateAdapter.subtract(previousMonthTarget, {
      months: 1
    });
    const lastDay = this._dateAdapter.endOfMonth(previousMonthTarget);
    if (date > this._dateAdapter.getDate(lastDay)) {
      this._calendar.setFocusedDate(lastDay);
    } else {
      this._calendar.setFocusedDate(this._dateAdapter.set(previousMonthTarget, {
        day: date
      }));
    }
  }
  /**
   * Focus the same date in the next month.
   */
  focusNextMonth(event) {
    event.preventDefault();
    event.stopPropagation();
    const date = this._dateAdapter.getDate(this._calendar.focusedDate());
    let nextMonthTarget = this._dateAdapter.startOfMonth(this._calendar.focusedDate());
    nextMonthTarget = this._dateAdapter.add(nextMonthTarget, {
      months: 1
    });
    const lastDay = this._dateAdapter.endOfMonth(nextMonthTarget);
    if (date > this._dateAdapter.getDate(lastDay)) {
      this._calendar.setFocusedDate(lastDay);
    } else {
      this._calendar.setFocusedDate(this._dateAdapter.set(nextMonthTarget, {
        day: date
      }));
    }
  }
  /**
   * Get the direction of the element.
   */
  getDirection() {
    return getComputedStyle(this._elementRef.nativeElement).direction === "rtl" ? "rtl" : "ltr";
  }
  focus() {
    this._elementRef.nativeElement.focus();
  }
  /** @nocollapse */
  static ɵfac = function BrnCalendarCellButton_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _BrnCalendarCellButton)();
  };
  /** @nocollapse */
  static ɵdir = ɵɵdefineDirective({
    type: _BrnCalendarCellButton,
    selectors: [["button", "brnCalendarCellButton", ""]],
    hostAttrs: ["role", "gridcell", "type", "button"],
    hostVars: 11,
    hostBindings: function BrnCalendarCellButton_HostBindings(rf, ctx) {
      if (rf & 1) {
        ɵɵlistener("click", function BrnCalendarCellButton_click_HostBindingHandler() {
          return ctx._calendar.selectDate(ctx.date());
        })("keydown.arrowLeft", function BrnCalendarCellButton_keydown_arrowLeft_HostBindingHandler($event) {
          return ctx.focusPrevious($event);
        })("keydown.arrowRight", function BrnCalendarCellButton_keydown_arrowRight_HostBindingHandler($event) {
          return ctx.focusNext($event);
        })("keydown.arrowUp", function BrnCalendarCellButton_keydown_arrowUp_HostBindingHandler($event) {
          return ctx.focusAbove($event);
        })("keydown.arrowDown", function BrnCalendarCellButton_keydown_arrowDown_HostBindingHandler($event) {
          return ctx.focusBelow($event);
        })("keydown.home", function BrnCalendarCellButton_keydown_home_HostBindingHandler($event) {
          return ctx.focusFirst($event);
        })("keydown.end", function BrnCalendarCellButton_keydown_end_HostBindingHandler($event) {
          return ctx.focusLast($event);
        })("keydown.pageUp", function BrnCalendarCellButton_keydown_pageUp_HostBindingHandler($event) {
          return ctx.focusPreviousMonth($event);
        })("keydown.pageDown", function BrnCalendarCellButton_keydown_pageDown_HostBindingHandler($event) {
          return ctx.focusNextMonth($event);
        });
      }
      if (rf & 2) {
        ɵɵdomProperty("tabIndex", ctx.focusable() ? 0 : -1)("disabled", ctx.disabled());
        ɵɵattribute("data-outside", !ctx.selected() && ctx.outside() && !ctx.end() && !ctx.start() ? "" : null)("data-today", ctx.today() && !ctx.selected() ? "" : null)("data-selected", ctx.selected() ? "" : null)("data-disabled", ctx.disabled() ? "" : null)("aria-selected", ctx.selected() ? "true" : null)("aria-disabled", ctx.disabled() ? "true" : null)("data-range-start", ctx.start() ? "" : null)("data-range-end", ctx.end() ? "" : null)("data-range-between", ctx.betweenRange() ? "" : null);
      }
    },
    inputs: {
      date: [1, "date"]
    }
  });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(BrnCalendarCellButton, [{
    type: Directive,
    args: [{
      selector: "button[brnCalendarCellButton]",
      host: {
        role: "gridcell",
        "[tabindex]": "focusable() ? 0 : -1",
        type: "button",
        "[attr.data-outside]": "!selected() && outside() && (!end() && !start())? '' : null",
        "[attr.data-today]": "today() && !selected() ? '' : null",
        "[attr.data-selected]": "selected() ? '' : null",
        "[attr.data-disabled]": "disabled() ? '' : null",
        "[attr.aria-selected]": "selected() ? 'true' : null",
        "[attr.aria-disabled]": "disabled() ? 'true' : null",
        "[attr.data-range-start]": 'start() ? "" : null',
        "[attr.data-range-end]": 'end() ? "" : null',
        "[attr.data-range-between]": 'betweenRange() ? "" : null',
        "[disabled]": "disabled()",
        "(click)": "_calendar.selectDate(date())",
        "(keydown.arrowLeft)": "focusPrevious($event)",
        "(keydown.arrowRight)": "focusNext($event)",
        "(keydown.arrowUp)": "focusAbove($event)",
        "(keydown.arrowDown)": "focusBelow($event)",
        "(keydown.home)": "focusFirst($event)",
        "(keydown.end)": "focusLast($event)",
        "(keydown.pageUp)": "focusPreviousMonth($event)",
        "(keydown.pageDown)": "focusNextMonth($event)"
      }
    }]
  }], null, {
    date: [{
      type: Input,
      args: [{
        isSignal: true,
        alias: "date",
        required: true
      }]
    }]
  });
})();
var uniqueId = 0;
var BrnCalendarHeader = class _BrnCalendarHeader {
  /** The unique id for the header */
  id = input(`brn-calendar-header-${++uniqueId}`, ...ngDevMode ? [{
    debugName: "id"
  }] : []);
  /** @nocollapse */
  static ɵfac = function BrnCalendarHeader_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _BrnCalendarHeader)();
  };
  /** @nocollapse */
  static ɵdir = ɵɵdefineDirective({
    type: _BrnCalendarHeader,
    selectors: [["", "brnCalendarHeader", ""]],
    hostAttrs: ["aria-live", "polite", "role", "presentation"],
    hostVars: 1,
    hostBindings: function BrnCalendarHeader_HostBindings(rf, ctx) {
      if (rf & 2) {
        ɵɵdomProperty("id", ctx.id());
      }
    },
    inputs: {
      id: [1, "id"]
    }
  });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(BrnCalendarHeader, [{
    type: Directive,
    args: [{
      selector: "[brnCalendarHeader]",
      host: {
        "[id]": "id()",
        "aria-live": "polite",
        role: "presentation"
      }
    }]
  }], null, {
    id: [{
      type: Input,
      args: [{
        isSignal: true,
        alias: "id",
        required: false
      }]
    }]
  });
})();
var BrnCalendarI18nToken = new InjectionToken("BrnCalendarI18nToken");
function provideBrnCalendarI18n(configuration) {
  return {
    provide: BrnCalendarI18nToken,
    useFactory: () => {
      const service = new BrnCalendarI18nService();
      service.use(configuration ?? defaultCalendarI18n);
      return service;
    }
  };
}
var defaultCalendarI18n = {
  formatWeekdayName: (index) => {
    const weekdays = ["Su", "Mo", "Tu", "We", "Th", "Fr", "Sa"];
    return weekdays[index];
  },
  months: () => ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],
  years: (startYear = 1925, endYear = (/* @__PURE__ */ new Date()).getFullYear() + 1) => Array.from({
    length: endYear - startYear + 1
  }, (_, i) => startYear + i),
  formatHeader: (month, year) => {
    return new Date(year, month).toLocaleDateString(void 0, {
      month: "long",
      year: "numeric"
    });
  },
  formatMonth: (month) => {
    return new Date(2e3, month).toLocaleDateString(void 0, {
      month: "short"
    });
  },
  formatYear: (year) => {
    return new Date(year, 0).toLocaleDateString(void 0, {
      year: "numeric"
    });
  },
  labelPrevious: () => "Go to the previous month",
  labelNext: () => "Go to the next month",
  labelWeekday: (index) => {
    const weekdays = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
    return weekdays[index];
  },
  firstDayOfWeek: () => 0
};
function injectBrnCalendarI18n() {
  return inject(BrnCalendarI18nToken, {
    optional: true
  }) ?? inject(BrnCalendarI18nService);
}
var BrnCalendarI18nService = class _BrnCalendarI18nService {
  _config = signal(defaultCalendarI18n, ...ngDevMode ? [{
    debugName: "_config"
  }] : []);
  config = this._config.asReadonly();
  use(config) {
    this._config.set(__spreadValues(__spreadValues({}, this.config()), config));
  }
  /** @nocollapse */
  static ɵfac = function BrnCalendarI18nService_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _BrnCalendarI18nService)();
  };
  /** @nocollapse */
  static ɵprov = ɵɵdefineInjectable({
    token: _BrnCalendarI18nService,
    factory: _BrnCalendarI18nService.ɵfac,
    providedIn: "root"
  });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(BrnCalendarI18nService, [{
    type: Injectable,
    args: [{
      providedIn: "root"
    }]
  }], null, null);
})();
var BrnCalendar = class _BrnCalendar {
  _i18n = injectBrnCalendarI18n();
  /** Access the date adapter */
  _dateAdapter = injectDateAdapter();
  /** Access the change detector */
  _changeDetector = inject(ChangeDetectorRef);
  /** Access the injector */
  _injector = inject(Injector);
  /** The minimum date that can be selected.*/
  min = input(...ngDevMode ? [void 0, {
    debugName: "min"
  }] : []);
  /** The maximum date that can be selected. */
  max = input(...ngDevMode ? [void 0, {
    debugName: "max"
  }] : []);
  /** Determine if the date picker is disabled. */
  disabled = input(false, ...ngDevMode ? [{
    debugName: "disabled",
    transform: booleanAttribute
  }] : [{
    transform: booleanAttribute
  }]);
  /** The selected value. */
  date = model(...ngDevMode ? [void 0, {
    debugName: "date"
  }] : []);
  /** Whether a specific date is disabled. */
  dateDisabled = input(() => false, ...ngDevMode ? [{
    debugName: "dateDisabled"
  }] : []);
  /** The day the week starts on */
  weekStartsOn = input(void 0, ...ngDevMode ? [{
    debugName: "weekStartsOn",
    transform: (v) => v === void 0 || v === null ? void 0 : numberAttribute(v)
  }] : [{
    transform: (v) => v === void 0 || v === null ? void 0 : numberAttribute(v)
  }]);
  _weekStartsOn = computed(() => this.weekStartsOn() ?? this._i18n.config().firstDayOfWeek(), ...ngDevMode ? [{
    debugName: "_weekStartsOn"
  }] : []);
  /** The default focused date. */
  defaultFocusedDate = input(...ngDevMode ? [void 0, {
    debugName: "defaultFocusedDate"
  }] : []);
  /** @internal Access the header */
  header = contentChild(BrnCalendarHeader, ...ngDevMode ? [{
    debugName: "header"
  }] : []);
  /** Store the cells */
  _cells = contentChildren(BrnCalendarCellButton, ...ngDevMode ? [{
    debugName: "_cells",
    descendants: true
  }] : [{
    descendants: true
  }]);
  /**
   * The focused date.
   */
  focusedDate = linkedSignal(() => this.constrainDate(this.defaultFocusedDate() ?? this.date() ?? this._dateAdapter.now()), ...ngDevMode ? [{
    debugName: "focusedDate"
  }] : []);
  /**
   * Get all the days to display, this is the days of the current month
   * and the days of the previous and next month to fill the grid.
   */
  days = computed(() => {
    const weekStartsOn = this._weekStartsOn();
    const month = this.focusedDate();
    const days = [];
    let firstDay = this._dateAdapter.startOfMonth(month);
    let lastDay = this._dateAdapter.endOfMonth(month);
    while (this._dateAdapter.getDay(firstDay) !== weekStartsOn) {
      firstDay = this._dateAdapter.subtract(firstDay, {
        days: 1
      });
    }
    const weekEndsOn = (weekStartsOn + 6) % 7;
    while (this._dateAdapter.getDay(lastDay) !== weekEndsOn) {
      lastDay = this._dateAdapter.add(lastDay, {
        days: 1
      });
    }
    while (firstDay <= lastDay) {
      days.push(firstDay);
      firstDay = this._dateAdapter.add(firstDay, {
        days: 1
      });
    }
    return days;
  }, ...ngDevMode ? [{
    debugName: "days"
  }] : []);
  /** @internal Constrain a date to the min and max boundaries */
  constrainDate(date) {
    const min = this.min();
    const max = this.max();
    if (!min && !max) {
      return date;
    }
    if (min && this._dateAdapter.isBefore(date, this._dateAdapter.startOfDay(min))) {
      return min;
    }
    if (max && this._dateAdapter.isAfter(date, this._dateAdapter.endOfDay(max))) {
      return max;
    }
    return date;
  }
  /** @internal Determine if a date is disabled */
  isDateDisabled(date) {
    if (this.disabled()) {
      return true;
    }
    const min = this.min();
    const max = this.max();
    if (min && this._dateAdapter.isBefore(date, this._dateAdapter.startOfDay(min))) {
      return true;
    }
    if (max && this._dateAdapter.isAfter(date, this._dateAdapter.endOfDay(max))) {
      return true;
    }
    const disabledFn = this.dateDisabled();
    if (disabledFn(date)) {
      return true;
    }
    return false;
  }
  isSelected(date) {
    const selected = this.date();
    return selected !== void 0 && this._dateAdapter.isSameDay(date, selected);
  }
  selectDate(date) {
    if (this.isSelected(date)) {
      this.date.set(void 0);
    } else {
      this.date.set(date);
    }
    this.focusedDate.set(date);
  }
  /** @internal Set the focused date */
  setFocusedDate(date) {
    if (this.isDateDisabled(date)) {
      return;
    }
    this.focusedDate.set(date);
    afterNextRender({
      write: () => {
        const cell = this._cells().find((c) => this._dateAdapter.isSameDay(c.date(), date));
        if (cell) {
          cell.focus();
        }
      }
    }, {
      injector: this._injector
    });
    this._changeDetector.detectChanges();
  }
  /**
   * Determine if a date is the start of a range. In a date picker, this is always false.
   * @param date The date to check.
   * @returns Always false.
   * @internal
   */
  isStartOfRange(_) {
    return false;
  }
  /**
   * Determine if a date is the end of a range. In a date picker, this is always false.
   * @param date The date to check.
   * @returns Always false.
   * @internal
   */
  isEndOfRange(_) {
    return false;
  }
  /**
   * Determine if a date is between the start and end dates. In a date picker, this is always false.
   * @param date The date to check.
   * @returns True if the date is between the start and end dates, false otherwise.
   * @internal
   */
  isBetweenRange(_) {
    return false;
  }
  /** @nocollapse */
  static ɵfac = function BrnCalendar_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _BrnCalendar)();
  };
  /** @nocollapse */
  static ɵdir = ɵɵdefineDirective({
    type: _BrnCalendar,
    selectors: [["", "brnCalendar", ""]],
    contentQueries: function BrnCalendar_ContentQueries(rf, ctx, dirIndex) {
      if (rf & 1) {
        ɵɵcontentQuerySignal(dirIndex, ctx.header, BrnCalendarHeader, 5)(dirIndex, ctx._cells, BrnCalendarCellButton, 5);
      }
      if (rf & 2) {
        ɵɵqueryAdvance(2);
      }
    },
    inputs: {
      min: [1, "min"],
      max: [1, "max"],
      disabled: [1, "disabled"],
      date: [1, "date"],
      dateDisabled: [1, "dateDisabled"],
      weekStartsOn: [1, "weekStartsOn"],
      defaultFocusedDate: [1, "defaultFocusedDate"]
    },
    outputs: {
      date: "dateChange"
    },
    features: [ɵɵProvidersFeature([provideBrnCalendar(_BrnCalendar)])]
  });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(BrnCalendar, [{
    type: Directive,
    args: [{
      selector: "[brnCalendar]",
      providers: [provideBrnCalendar(BrnCalendar)]
    }]
  }], null, {
    min: [{
      type: Input,
      args: [{
        isSignal: true,
        alias: "min",
        required: false
      }]
    }],
    max: [{
      type: Input,
      args: [{
        isSignal: true,
        alias: "max",
        required: false
      }]
    }],
    disabled: [{
      type: Input,
      args: [{
        isSignal: true,
        alias: "disabled",
        required: false
      }]
    }],
    date: [{
      type: Input,
      args: [{
        isSignal: true,
        alias: "date",
        required: false
      }]
    }, {
      type: Output,
      args: ["dateChange"]
    }],
    dateDisabled: [{
      type: Input,
      args: [{
        isSignal: true,
        alias: "dateDisabled",
        required: false
      }]
    }],
    weekStartsOn: [{
      type: Input,
      args: [{
        isSignal: true,
        alias: "weekStartsOn",
        required: false
      }]
    }],
    defaultFocusedDate: [{
      type: Input,
      args: [{
        isSignal: true,
        alias: "defaultFocusedDate",
        required: false
      }]
    }],
    header: [{
      type: ContentChild,
      args: [forwardRef(() => BrnCalendarHeader), {
        isSignal: true
      }]
    }],
    _cells: [{
      type: ContentChildren,
      args: [forwardRef(() => BrnCalendarCellButton), __spreadProps(__spreadValues({}, {
        descendants: true
      }), {
        isSignal: true
      })]
    }]
  });
})();
var BrnCalendarCell = class _BrnCalendarCell {
  /** @nocollapse */
  static ɵfac = function BrnCalendarCell_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _BrnCalendarCell)();
  };
  /** @nocollapse */
  static ɵdir = ɵɵdefineDirective({
    type: _BrnCalendarCell,
    selectors: [["", "brnCalendarCell", ""]],
    hostAttrs: ["role", "presentation"]
  });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(BrnCalendarCell, [{
    type: Directive,
    args: [{
      selector: "[brnCalendarCell]",
      host: {
        role: "presentation"
      }
    }]
  }], null, null);
})();
var BrnCalendarGrid = class _BrnCalendarGrid {
  /** Access the calendar component */
  _calendar = injectBrnCalendar();
  /** @nocollapse */
  static ɵfac = function BrnCalendarGrid_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _BrnCalendarGrid)();
  };
  /** @nocollapse */
  static ɵdir = ɵɵdefineDirective({
    type: _BrnCalendarGrid,
    selectors: [["", "brnCalendarGrid", ""]],
    hostAttrs: ["role", "grid"],
    hostVars: 1,
    hostBindings: function BrnCalendarGrid_HostBindings(rf, ctx) {
      if (rf & 2) {
        let tmp_0_0;
        ɵɵattribute("aria-labelledby", (tmp_0_0 = ctx._calendar.header()) == null ? null : tmp_0_0.id());
      }
    }
  });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(BrnCalendarGrid, [{
    type: Directive,
    args: [{
      selector: "[brnCalendarGrid]",
      host: {
        role: "grid",
        "[attr.aria-labelledby]": "_calendar.header()?.id()"
      }
    }]
  }], null, null);
})();
var BrnCalendarMonthSelect = class _BrnCalendarMonthSelect {
  /** Access the select */
  _select = inject(BrnSelect);
  /** Access the calendar */
  _calendar = injectBrnCalendar();
  /** Access the date adapter */
  _dateAdapter = injectDateAdapter();
  /** Access the calendar i18n */
  _i18n = injectBrnCalendarI18n();
  _selectedMonth = computed(() => {
    return this._i18n.config().months()[this._dateAdapter.getMonth(this._calendar.focusedDate())];
  }, ...ngDevMode ? [{
    debugName: "_selectedMonth"
  }] : []);
  constructor() {
    effect(() => {
      this._select.writeValue(this._selectedMonth());
    });
  }
  /** Focus selected month */
  monthSelected(selectedMonth) {
    const month = this._i18n.config().months().findIndex((month2) => month2 === selectedMonth);
    const targetDate = this._dateAdapter.set(this._calendar.focusedDate(), {
      month
    });
    this._calendar.focusedDate.set(targetDate);
  }
  /** @nocollapse */
  static ɵfac = function BrnCalendarMonthSelect_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _BrnCalendarMonthSelect)();
  };
  /** @nocollapse */
  static ɵdir = ɵɵdefineDirective({
    type: _BrnCalendarMonthSelect,
    selectors: [["brnSelect", "brnCalendarMonthSelect", ""], ["hlm-select", "brnCalendarMonthSelect", ""]],
    hostBindings: function BrnCalendarMonthSelect_HostBindings(rf, ctx) {
      if (rf & 1) {
        ɵɵlistener("valueChange", function BrnCalendarMonthSelect_valueChange_HostBindingHandler($event) {
          return ctx.monthSelected($event);
        });
      }
    }
  });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(BrnCalendarMonthSelect, [{
    type: Directive,
    args: [{
      selector: "brnSelect[brnCalendarMonthSelect],hlm-select[brnCalendarMonthSelect]",
      host: {
        "(valueChange)": "monthSelected($event)"
      }
    }]
  }], () => [], null);
})();
var BrnCalendarNextButton = class _BrnCalendarNextButton {
  /** Access the calendar */
  _calendar = injectBrnCalendar();
  /** Access the date adapter */
  _dateAdapter = injectDateAdapter();
  /** Access the calendar i18n */
  _i18n = injectBrnCalendarI18n();
  /** Focus the next month */
  focusNextMonth() {
    const focusedDate = this._calendar.focusedDate();
    const date = this._dateAdapter.getDate(focusedDate);
    let nextMonthTarget = this._dateAdapter.startOfMonth(focusedDate);
    nextMonthTarget = this._dateAdapter.add(nextMonthTarget, {
      months: 1
    });
    const lastDay = this._dateAdapter.endOfMonth(nextMonthTarget);
    let targetDate;
    if (date > this._dateAdapter.getDate(lastDay)) {
      targetDate = lastDay;
    } else {
      targetDate = this._dateAdapter.set(nextMonthTarget, {
        day: date
      });
    }
    const possibleDate = this._calendar.constrainDate(targetDate);
    if (this._dateAdapter.isSameMonth(possibleDate, targetDate)) {
      this._calendar.focusedDate.set(possibleDate);
      return;
    }
    this._calendar.focusedDate.set(targetDate);
  }
  /** @nocollapse */
  static ɵfac = function BrnCalendarNextButton_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _BrnCalendarNextButton)();
  };
  /** @nocollapse */
  static ɵdir = ɵɵdefineDirective({
    type: _BrnCalendarNextButton,
    selectors: [["", "brnCalendarNextButton", ""]],
    hostAttrs: ["type", "button"],
    hostVars: 1,
    hostBindings: function BrnCalendarNextButton_HostBindings(rf, ctx) {
      if (rf & 1) {
        ɵɵlistener("click", function BrnCalendarNextButton_click_HostBindingHandler() {
          return ctx.focusNextMonth();
        });
      }
      if (rf & 2) {
        ɵɵattribute("aria-label", ctx._i18n.config().labelNext());
      }
    }
  });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(BrnCalendarNextButton, [{
    type: Directive,
    args: [{
      selector: "[brnCalendarNextButton]",
      host: {
        type: "button",
        "[attr.aria-label]": "_i18n.config().labelNext()",
        "(click)": "focusNextMonth()"
      }
    }]
  }], null, null);
})();
var BrnCalendarPreviousButton = class _BrnCalendarPreviousButton {
  /** Access the calendar */
  _calendar = injectBrnCalendar();
  /** Access the date adapter */
  _dateAdapter = injectDateAdapter();
  /** Access the calendar i18n */
  _i18n = injectBrnCalendarI18n();
  /** Focus the previous month */
  focusPreviousMonth() {
    const focusedDate = this._calendar.focusedDate();
    const date = this._dateAdapter.getDate(focusedDate);
    let previousMonthTarget = this._dateAdapter.startOfMonth(focusedDate);
    previousMonthTarget = this._dateAdapter.subtract(previousMonthTarget, {
      months: 1
    });
    const lastDay = this._dateAdapter.endOfMonth(previousMonthTarget);
    let targetDate;
    if (date > this._dateAdapter.getDate(lastDay)) {
      targetDate = lastDay;
    } else {
      targetDate = this._dateAdapter.set(previousMonthTarget, {
        day: date
      });
    }
    const possibleDate = this._calendar.constrainDate(targetDate);
    if (this._dateAdapter.isSameMonth(possibleDate, targetDate)) {
      this._calendar.focusedDate.set(possibleDate);
      return;
    }
    this._calendar.focusedDate.set(targetDate);
  }
  /** @nocollapse */
  static ɵfac = function BrnCalendarPreviousButton_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _BrnCalendarPreviousButton)();
  };
  /** @nocollapse */
  static ɵdir = ɵɵdefineDirective({
    type: _BrnCalendarPreviousButton,
    selectors: [["", "brnCalendarPreviousButton", ""]],
    hostAttrs: ["type", "button"],
    hostVars: 1,
    hostBindings: function BrnCalendarPreviousButton_HostBindings(rf, ctx) {
      if (rf & 1) {
        ɵɵlistener("click", function BrnCalendarPreviousButton_click_HostBindingHandler() {
          return ctx.focusPreviousMonth();
        });
      }
      if (rf & 2) {
        ɵɵattribute("aria-label", ctx._i18n.config().labelPrevious());
      }
    }
  });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(BrnCalendarPreviousButton, [{
    type: Directive,
    args: [{
      selector: "[brnCalendarPreviousButton]",
      host: {
        type: "button",
        "[attr.aria-label]": "_i18n.config().labelPrevious()",
        "(click)": "focusPreviousMonth()"
      }
    }]
  }], null, null);
})();
var BrnCalendarWeek = class _BrnCalendarWeek {
  /** Access the calendar */
  _calendar = injectBrnCalendar();
  /** Access the view container ref */
  _viewContainerRef = inject(ViewContainerRef);
  /** Access the change detector */
  _changeDetector = inject(ChangeDetectorRef);
  /** Access the template ref */
  _templateRef = inject(TemplateRef);
  // get the weeks to display.
  _weeks = computed(() => {
    const days = this._calendar.days();
    const weeks = [];
    for (let i = 0; i < days.length; i += 7) {
      weeks.push(days.slice(i, i + 7));
    }
    return weeks;
  }, ...ngDevMode ? [{
    debugName: "_weeks"
  }] : []);
  /** Store the view refs */
  _viewRefs = [];
  // Make sure the template checker knows the type of the context with which the
  // template of this directive will be rendered
  static ngTemplateContextGuard(_, ctx) {
    return true;
  }
  constructor() {
    effect(() => {
      const weeks = this._weeks();
      untracked(() => this._renderWeeks(weeks));
    });
  }
  _renderWeeks(weeks) {
    for (const viewRef of this._viewRefs) {
      viewRef.destroy();
    }
    this._viewRefs = [];
    for (const week of weeks) {
      const viewRef = this._viewContainerRef.createEmbeddedView(this._templateRef, {
        $implicit: week
      });
      this._viewRefs.push(viewRef);
    }
    this._changeDetector.detectChanges();
  }
  ngOnDestroy() {
    for (const viewRef of this._viewRefs) {
      viewRef.destroy();
    }
  }
  /** @nocollapse */
  static ɵfac = function BrnCalendarWeek_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _BrnCalendarWeek)();
  };
  /** @nocollapse */
  static ɵdir = ɵɵdefineDirective({
    type: _BrnCalendarWeek,
    selectors: [["", "brnCalendarWeek", ""]]
  });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(BrnCalendarWeek, [{
    type: Directive,
    args: [{
      selector: "[brnCalendarWeek]"
    }]
  }], () => [], null);
})();
var BrnCalendarWeekday = class _BrnCalendarWeekday {
  /** Access the calendar */
  _calendar = injectBrnCalendar();
  /** Access the date time adapter */
  _dateAdapter = injectDateAdapter();
  /** Access the view container ref */
  _viewContainerRef = inject(ViewContainerRef);
  /** Access the change detector */
  _changeDetector = inject(ChangeDetectorRef);
  /** Access the template ref */
  _templateRef = inject(TemplateRef);
  /** Get the days of the week to display in the header. */
  _weekdays = computed(() => this._calendar.days().slice(0, 7), ...ngDevMode ? [{
    debugName: "_weekdays"
  }] : []);
  /** Store the view refs */
  _viewRefs = [];
  // Make sure the template checker knows the type of the context with which the
  // template of this directive will be rendered
  static ngTemplateContextGuard(_, ctx) {
    return true;
  }
  constructor() {
    effect(() => {
      const weekdays = this._weekdays();
      untracked(() => this._renderWeekdays(weekdays));
    });
  }
  _renderWeekdays(weekdays) {
    for (const viewRef of this._viewRefs) {
      viewRef.destroy();
    }
    this._viewRefs = [];
    for (const day of weekdays) {
      const viewRef = this._viewContainerRef.createEmbeddedView(this._templateRef, {
        $implicit: this._dateAdapter.getDay(day)
      });
      this._viewRefs.push(viewRef);
    }
    this._changeDetector.detectChanges();
  }
  ngOnDestroy() {
    for (const viewRef of this._viewRefs) {
      viewRef.destroy();
    }
  }
  /** @nocollapse */
  static ɵfac = function BrnCalendarWeekday_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _BrnCalendarWeekday)();
  };
  /** @nocollapse */
  static ɵdir = ɵɵdefineDirective({
    type: _BrnCalendarWeekday,
    selectors: [["", "brnCalendarWeekday", ""]]
  });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(BrnCalendarWeekday, [{
    type: Directive,
    args: [{
      selector: "[brnCalendarWeekday]"
    }]
  }], () => [], null);
})();
var BrnCalendarYearSelect = class _BrnCalendarYearSelect {
  /** Access the select */
  _select = inject(BrnSelect);
  /** Access the calendar */
  _calendar = injectBrnCalendar();
  /** Access the date adapter */
  _dateAdapter = injectDateAdapter();
  /** Access the calendar i18n */
  _i18n = injectBrnCalendarI18n();
  constructor() {
    effect(() => {
      this._select.writeValue(this._dateAdapter.getYear(this._calendar.focusedDate()));
    });
  }
  /** Focus selected year */
  yearSelected(year) {
    const targetDate = this._dateAdapter.set(this._calendar.focusedDate(), {
      year
    });
    this._calendar.focusedDate.set(targetDate);
  }
  /** @nocollapse */
  static ɵfac = function BrnCalendarYearSelect_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _BrnCalendarYearSelect)();
  };
  /** @nocollapse */
  static ɵdir = ɵɵdefineDirective({
    type: _BrnCalendarYearSelect,
    selectors: [["brnSelect", "brnCalendarYearSelect", ""], ["hlm-select", "brnCalendarYearSelect", ""]],
    hostBindings: function BrnCalendarYearSelect_HostBindings(rf, ctx) {
      if (rf & 1) {
        ɵɵlistener("valueChange", function BrnCalendarYearSelect_valueChange_HostBindingHandler($event) {
          return ctx.yearSelected($event);
        });
      }
    }
  });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(BrnCalendarYearSelect, [{
    type: Directive,
    args: [{
      selector: "brnSelect[brnCalendarYearSelect],hlm-select[brnCalendarYearSelect]",
      host: {
        "(valueChange)": "yearSelected($event)"
      }
    }]
  }], () => [], null);
})();
var BrnCalendarMulti = class _BrnCalendarMulti {
  _i18n = injectBrnCalendarI18n();
  /**
   * Determine if a date is the start of a range. In a date picker, this is always false.
   * @param date The date to check.
   * @returns Always false.
   * @internal
   */
  isStartOfRange(_) {
    return false;
  }
  /**
   * Determine if a date is the end of a range. In a date picker, this is always false.
   * @param date The date to check.
   * @returns Always false.
   * @internal
   */
  isEndOfRange(_) {
    return false;
  }
  /**
   * Determine if a date is between the start and end dates. In a date picker, this is always false.
   * @param date The date to check.
   * @returns True if the date is between the start and end dates, false otherwise.
   * @internal
   */
  isBetweenRange(_) {
    return false;
  }
  // /** Access the date adapter */
  _dateAdapter = injectDateAdapter();
  /** Access the change detector */
  _changeDetector = inject(ChangeDetectorRef);
  /** Access the injector */
  _injector = inject(Injector);
  /** The minimum date that can be selected.*/
  min = input(...ngDevMode ? [void 0, {
    debugName: "min"
  }] : []);
  /** The maximum date that can be selected. */
  max = input(...ngDevMode ? [void 0, {
    debugName: "max"
  }] : []);
  /** The minimum selectable dates.  */
  minSelection = input(void 0, ...ngDevMode ? [{
    debugName: "minSelection",
    transform: numberAttribute
  }] : [{
    transform: numberAttribute
  }]);
  /** The maximum selectable dates.  */
  maxSelection = input(void 0, ...ngDevMode ? [{
    debugName: "maxSelection",
    transform: numberAttribute
  }] : [{
    transform: numberAttribute
  }]);
  /** Determine if the date picker is disabled. */
  disabled = input(false, ...ngDevMode ? [{
    debugName: "disabled",
    transform: booleanAttribute
  }] : [{
    transform: booleanAttribute
  }]);
  /** The selected value. */
  date = model(...ngDevMode ? [void 0, {
    debugName: "date"
  }] : []);
  /** Whether a specific date is disabled. */
  dateDisabled = input(() => false, ...ngDevMode ? [{
    debugName: "dateDisabled"
  }] : []);
  /** The day the week starts on */
  weekStartsOn = input(void 0, ...ngDevMode ? [{
    debugName: "weekStartsOn",
    transform: (v) => v === void 0 || v === null ? void 0 : numberAttribute(v)
  }] : [{
    transform: (v) => v === void 0 || v === null ? void 0 : numberAttribute(v)
  }]);
  _weekStartsOn = computed(() => this.weekStartsOn() ?? this._i18n.config().firstDayOfWeek(), ...ngDevMode ? [{
    debugName: "_weekStartsOn"
  }] : []);
  /** The default focused date. */
  defaultFocusedDate = input(...ngDevMode ? [void 0, {
    debugName: "defaultFocusedDate"
  }] : []);
  /** @internal Access the header */
  header = contentChild(BrnCalendarHeader, ...ngDevMode ? [{
    debugName: "header"
  }] : []);
  /** Store the cells */
  _cells = contentChildren(BrnCalendarCellButton, ...ngDevMode ? [{
    debugName: "_cells",
    descendants: true
  }] : [{
    descendants: true
  }]);
  /**
   * The focused date.
   */
  focusedDate = linkedSignal(() => this.constrainDate(this.defaultFocusedDate() ?? this._dateAdapter.now()), ...ngDevMode ? [{
    debugName: "focusedDate"
  }] : []);
  /**
   * Get all the days to display, this is the days of the current month
   * and the days of the previous and next month to fill the grid.
   */
  days = computed(() => {
    const weekStartsOn = this._weekStartsOn();
    const month = this.focusedDate();
    const days = [];
    let firstDay = this._dateAdapter.startOfMonth(month);
    let lastDay = this._dateAdapter.endOfMonth(month);
    while (this._dateAdapter.getDay(firstDay) !== weekStartsOn) {
      firstDay = this._dateAdapter.subtract(firstDay, {
        days: 1
      });
    }
    const weekEndsOn = (weekStartsOn + 6) % 7;
    while (this._dateAdapter.getDay(lastDay) !== weekEndsOn) {
      lastDay = this._dateAdapter.add(lastDay, {
        days: 1
      });
    }
    while (firstDay <= lastDay) {
      days.push(firstDay);
      firstDay = this._dateAdapter.add(firstDay, {
        days: 1
      });
    }
    return days;
  }, ...ngDevMode ? [{
    debugName: "days"
  }] : []);
  isSelected(date) {
    return this.date()?.some((d) => this._dateAdapter.isSameDay(d, date)) ?? false;
  }
  selectDate(date) {
    const selected = this.date();
    if (this.isSelected(date)) {
      const minSelection = this.minSelection();
      if (selected?.length === minSelection) {
        return;
      }
      this.date.set(selected?.filter((d) => !this._dateAdapter.isSameDay(d, date)));
    } else {
      const maxSelection = this.maxSelection();
      if (selected?.length === maxSelection) {
        this.date.set([date]);
      } else {
        this.date.set([...selected ?? [], date]);
      }
    }
  }
  // same as in brn-calendar.directive.ts
  /** @internal Constrain a date to the min and max boundaries */
  constrainDate(date) {
    const min = this.min();
    const max = this.max();
    if (!min && !max) {
      return date;
    }
    if (min && this._dateAdapter.isBefore(date, this._dateAdapter.startOfDay(min))) {
      return min;
    }
    if (max && this._dateAdapter.isAfter(date, this._dateAdapter.endOfDay(max))) {
      return max;
    }
    return date;
  }
  /** @internal Determine if a date is disabled */
  isDateDisabled(date) {
    if (this.disabled()) {
      return true;
    }
    const min = this.min();
    const max = this.max();
    if (min && this._dateAdapter.isBefore(date, this._dateAdapter.startOfDay(min))) {
      return true;
    }
    if (max && this._dateAdapter.isAfter(date, this._dateAdapter.endOfDay(max))) {
      return true;
    }
    const disabledFn = this.dateDisabled();
    if (disabledFn(date)) {
      return true;
    }
    return false;
  }
  /** @internal Set the focused date */
  setFocusedDate(date) {
    if (this.isDateDisabled(date)) {
      return;
    }
    this.focusedDate.set(date);
    afterNextRender({
      write: () => {
        const cell = this._cells().find((c) => this._dateAdapter.isSameDay(c.date(), date));
        if (cell) {
          cell.focus();
        }
      }
    }, {
      injector: this._injector
    });
    this._changeDetector.detectChanges();
  }
  /** @nocollapse */
  static ɵfac = function BrnCalendarMulti_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _BrnCalendarMulti)();
  };
  /** @nocollapse */
  static ɵdir = ɵɵdefineDirective({
    type: _BrnCalendarMulti,
    selectors: [["", "brnCalendarMulti", ""]],
    contentQueries: function BrnCalendarMulti_ContentQueries(rf, ctx, dirIndex) {
      if (rf & 1) {
        ɵɵcontentQuerySignal(dirIndex, ctx.header, BrnCalendarHeader, 5)(dirIndex, ctx._cells, BrnCalendarCellButton, 5);
      }
      if (rf & 2) {
        ɵɵqueryAdvance(2);
      }
    },
    inputs: {
      min: [1, "min"],
      max: [1, "max"],
      minSelection: [1, "minSelection"],
      maxSelection: [1, "maxSelection"],
      disabled: [1, "disabled"],
      date: [1, "date"],
      dateDisabled: [1, "dateDisabled"],
      weekStartsOn: [1, "weekStartsOn"],
      defaultFocusedDate: [1, "defaultFocusedDate"]
    },
    outputs: {
      date: "dateChange"
    },
    features: [ɵɵProvidersFeature([provideBrnCalendar(_BrnCalendarMulti)])]
  });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(BrnCalendarMulti, [{
    type: Directive,
    args: [{
      selector: "[brnCalendarMulti]",
      providers: [provideBrnCalendar(BrnCalendarMulti)]
    }]
  }], null, {
    min: [{
      type: Input,
      args: [{
        isSignal: true,
        alias: "min",
        required: false
      }]
    }],
    max: [{
      type: Input,
      args: [{
        isSignal: true,
        alias: "max",
        required: false
      }]
    }],
    minSelection: [{
      type: Input,
      args: [{
        isSignal: true,
        alias: "minSelection",
        required: false
      }]
    }],
    maxSelection: [{
      type: Input,
      args: [{
        isSignal: true,
        alias: "maxSelection",
        required: false
      }]
    }],
    disabled: [{
      type: Input,
      args: [{
        isSignal: true,
        alias: "disabled",
        required: false
      }]
    }],
    date: [{
      type: Input,
      args: [{
        isSignal: true,
        alias: "date",
        required: false
      }]
    }, {
      type: Output,
      args: ["dateChange"]
    }],
    dateDisabled: [{
      type: Input,
      args: [{
        isSignal: true,
        alias: "dateDisabled",
        required: false
      }]
    }],
    weekStartsOn: [{
      type: Input,
      args: [{
        isSignal: true,
        alias: "weekStartsOn",
        required: false
      }]
    }],
    defaultFocusedDate: [{
      type: Input,
      args: [{
        isSignal: true,
        alias: "defaultFocusedDate",
        required: false
      }]
    }],
    header: [{
      type: ContentChild,
      args: [forwardRef(() => BrnCalendarHeader), {
        isSignal: true
      }]
    }],
    _cells: [{
      type: ContentChildren,
      args: [forwardRef(() => BrnCalendarCellButton), __spreadProps(__spreadValues({}, {
        descendants: true
      }), {
        isSignal: true
      })]
    }]
  });
})();
var BrnCalendarRange = class _BrnCalendarRange {
  _i18n = injectBrnCalendarI18n();
  // /** Access the date adapter */
  _dateAdapter = injectDateAdapter();
  /** Access the change detector */
  _changeDetector = inject(ChangeDetectorRef);
  /** Access the injector */
  _injector = inject(Injector);
  /** The minimum date that can be selected.*/
  min = input(...ngDevMode ? [void 0, {
    debugName: "min"
  }] : []);
  /** The maximum date that can be selected. */
  max = input(...ngDevMode ? [void 0, {
    debugName: "max"
  }] : []);
  /** Determine if the date picker is disabled. */
  disabled = input(false, ...ngDevMode ? [{
    debugName: "disabled",
    transform: booleanAttribute
  }] : [{
    transform: booleanAttribute
  }]);
  /** Whether a specific date is disabled. */
  dateDisabled = input(() => false, ...ngDevMode ? [{
    debugName: "dateDisabled"
  }] : []);
  /** The day the week starts on */
  weekStartsOn = input(void 0, ...ngDevMode ? [{
    debugName: "weekStartsOn",
    transform: (v) => v === void 0 || v === null ? void 0 : numberAttribute(v)
  }] : [{
    transform: (v) => v === void 0 || v === null ? void 0 : numberAttribute(v)
  }]);
  _weekStartsOn = computed(() => this.weekStartsOn() ?? this._i18n.config().firstDayOfWeek(), ...ngDevMode ? [{
    debugName: "_weekStartsOn"
  }] : []);
  /** The default focused date. */
  defaultFocusedDate = input(...ngDevMode ? [void 0, {
    debugName: "defaultFocusedDate"
  }] : []);
  /** @internal Access the header */
  header = contentChild(BrnCalendarHeader, ...ngDevMode ? [{
    debugName: "header"
  }] : []);
  /** Store the cells */
  _cells = contentChildren(BrnCalendarCellButton, ...ngDevMode ? [{
    debugName: "_cells",
    descendants: true
  }] : [{
    descendants: true
  }]);
  /**
   * The focused date.
   */
  focusedDate = linkedSignal(() => this.constrainDate(this.defaultFocusedDate() ?? this.startDate() ?? this._dateAdapter.now()), ...ngDevMode ? [{
    debugName: "focusedDate"
  }] : []);
  /**
   * The selected start date
   */
  startDate = model(...ngDevMode ? [void 0, {
    debugName: "startDate"
  }] : []);
  /**
   * The selected end date
   */
  endDate = model(...ngDevMode ? [void 0, {
    debugName: "endDate"
  }] : []);
  /**
   * Get all the days to display, this is the days of the current month
   * and the days of the previous and next month to fill the grid.
   */
  days = computed(() => {
    const weekStartsOn = this._weekStartsOn();
    const month = this.focusedDate();
    const days = [];
    let firstDay = this._dateAdapter.startOfMonth(month);
    let lastDay = this._dateAdapter.endOfMonth(month);
    while (this._dateAdapter.getDay(firstDay) !== weekStartsOn) {
      firstDay = this._dateAdapter.subtract(firstDay, {
        days: 1
      });
    }
    const weekEndsOn = (weekStartsOn + 6) % 7;
    while (this._dateAdapter.getDay(lastDay) !== weekEndsOn) {
      lastDay = this._dateAdapter.add(lastDay, {
        days: 1
      });
    }
    while (firstDay <= lastDay) {
      days.push(firstDay);
      firstDay = this._dateAdapter.add(firstDay, {
        days: 1
      });
    }
    return days;
  }, ...ngDevMode ? [{
    debugName: "days"
  }] : []);
  isSelected(date) {
    const start = this.startDate();
    const end = this.endDate();
    if (!start && !end) {
      return false;
    }
    const isStartSelected = start ? this._dateAdapter.isSameDay(date, start) : false;
    const isEndSelected = end ? this._dateAdapter.isSameDay(date, end) : false;
    return isStartSelected || isEndSelected;
  }
  selectDate(date) {
    const start = this.startDate();
    const end = this.endDate();
    if (!start && !end) {
      this.startDate.set(date);
      return;
    }
    if (start && !end) {
      if (this._dateAdapter.isAfter(date, start)) {
        this.endDate.set(date);
      } else if (this._dateAdapter.isBefore(date, start)) {
        this.startDate.set(date);
        this.endDate.set(start);
      } else if (this._dateAdapter.isSameDay(date, start)) {
        this.endDate.set(date);
      }
      return;
    }
    this.startDate.set(date);
    this.endDate.set(void 0);
  }
  // same as in brn-calendar.directive.ts
  /** @internal Constrain a date to the min and max boundaries */
  constrainDate(date) {
    const min = this.min();
    const max = this.max();
    if (!min && !max) {
      return date;
    }
    if (min && this._dateAdapter.isBefore(date, this._dateAdapter.startOfDay(min))) {
      return min;
    }
    if (max && this._dateAdapter.isAfter(date, this._dateAdapter.endOfDay(max))) {
      return max;
    }
    return date;
  }
  /** @internal Determine if a date is disabled */
  isDateDisabled(date) {
    if (this.disabled()) {
      return true;
    }
    const min = this.min();
    const max = this.max();
    if (min && this._dateAdapter.isBefore(date, this._dateAdapter.startOfDay(min))) {
      return true;
    }
    if (max && this._dateAdapter.isAfter(date, this._dateAdapter.endOfDay(max))) {
      return true;
    }
    const disabledFn = this.dateDisabled();
    if (disabledFn(date)) {
      return true;
    }
    return false;
  }
  /** @internal Set the focused date */
  setFocusedDate(date) {
    if (this.isDateDisabled(date)) {
      return;
    }
    this.focusedDate.set(date);
    afterNextRender({
      write: () => {
        const cell = this._cells().find((c) => this._dateAdapter.isSameDay(c.date(), date));
        if (cell) {
          cell.focus();
        }
      }
    }, {
      injector: this._injector
    });
    this._changeDetector.detectChanges();
  }
  /**
   * Determine if a date is the start of a range.
   * @param date The date to check.
   * @returns Always false.
   * @internal
   */
  isStartOfRange(date) {
    const start = this.startDate();
    return start ? this._dateAdapter.isSameDay(date, start) : false;
  }
  /**
   * Determine if a date is the end of a range.
   * @param date The date to check.
   * @returns Always false.
   * @internal
   */
  isEndOfRange(date) {
    const end = this.endDate();
    return end ? this._dateAdapter.isSameDay(date, end) : false;
  }
  /**
   * Determine if a date is between the start and end dates.
   * @param date The date to check.
   * @returns True if the date is between the start and end dates, false otherwise.
   * @internal
   */
  isBetweenRange(date) {
    const start = this.startDate();
    const end = this.endDate();
    if (!start || !end) {
      return false;
    }
    return this._dateAdapter.isAfter(date, start) && this._dateAdapter.isBefore(date, end);
  }
  /** @nocollapse */
  static ɵfac = function BrnCalendarRange_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _BrnCalendarRange)();
  };
  /** @nocollapse */
  static ɵdir = ɵɵdefineDirective({
    type: _BrnCalendarRange,
    selectors: [["", "brnCalendarRange", ""]],
    contentQueries: function BrnCalendarRange_ContentQueries(rf, ctx, dirIndex) {
      if (rf & 1) {
        ɵɵcontentQuerySignal(dirIndex, ctx.header, BrnCalendarHeader, 5)(dirIndex, ctx._cells, BrnCalendarCellButton, 5);
      }
      if (rf & 2) {
        ɵɵqueryAdvance(2);
      }
    },
    inputs: {
      min: [1, "min"],
      max: [1, "max"],
      disabled: [1, "disabled"],
      dateDisabled: [1, "dateDisabled"],
      weekStartsOn: [1, "weekStartsOn"],
      defaultFocusedDate: [1, "defaultFocusedDate"],
      startDate: [1, "startDate"],
      endDate: [1, "endDate"]
    },
    outputs: {
      startDate: "startDateChange",
      endDate: "endDateChange"
    },
    features: [ɵɵProvidersFeature([provideBrnCalendar(_BrnCalendarRange)])]
  });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(BrnCalendarRange, [{
    type: Directive,
    args: [{
      selector: "[brnCalendarRange]",
      providers: [provideBrnCalendar(BrnCalendarRange)]
    }]
  }], null, {
    min: [{
      type: Input,
      args: [{
        isSignal: true,
        alias: "min",
        required: false
      }]
    }],
    max: [{
      type: Input,
      args: [{
        isSignal: true,
        alias: "max",
        required: false
      }]
    }],
    disabled: [{
      type: Input,
      args: [{
        isSignal: true,
        alias: "disabled",
        required: false
      }]
    }],
    dateDisabled: [{
      type: Input,
      args: [{
        isSignal: true,
        alias: "dateDisabled",
        required: false
      }]
    }],
    weekStartsOn: [{
      type: Input,
      args: [{
        isSignal: true,
        alias: "weekStartsOn",
        required: false
      }]
    }],
    defaultFocusedDate: [{
      type: Input,
      args: [{
        isSignal: true,
        alias: "defaultFocusedDate",
        required: false
      }]
    }],
    header: [{
      type: ContentChild,
      args: [forwardRef(() => BrnCalendarHeader), {
        isSignal: true
      }]
    }],
    _cells: [{
      type: ContentChildren,
      args: [forwardRef(() => BrnCalendarCellButton), __spreadProps(__spreadValues({}, {
        descendants: true
      }), {
        isSignal: true
      })]
    }],
    startDate: [{
      type: Input,
      args: [{
        isSignal: true,
        alias: "startDate",
        required: false
      }]
    }, {
      type: Output,
      args: ["startDateChange"]
    }],
    endDate: [{
      type: Input,
      args: [{
        isSignal: true,
        alias: "endDate",
        required: false
      }]
    }, {
      type: Output,
      args: ["endDateChange"]
    }]
  });
})();
var BrnCalendarImports = [BrnCalendarCellButton, BrnCalendarGrid, BrnCalendarHeader, BrnCalendarNextButton, BrnCalendarPreviousButton, BrnCalendarWeek, BrnCalendarWeekday, BrnCalendar, BrnCalendarCell, BrnCalendarMulti, BrnCalendarRange, BrnCalendarMonthSelect, BrnCalendarYearSelect];
export {
  BrnCalendar,
  BrnCalendarCell,
  BrnCalendarCellButton,
  BrnCalendarGrid,
  BrnCalendarHeader,
  BrnCalendarI18nService,
  BrnCalendarI18nToken,
  BrnCalendarImports,
  BrnCalendarMonthSelect,
  BrnCalendarMulti,
  BrnCalendarNextButton,
  BrnCalendarPreviousButton,
  BrnCalendarRange,
  BrnCalendarToken,
  BrnCalendarWeek,
  BrnCalendarWeekday,
  BrnCalendarYearSelect,
  injectBrnCalendar,
  injectBrnCalendarI18n,
  provideBrnCalendar,
  provideBrnCalendarI18n
};
//# sourceMappingURL=@spartan-ng_brain_calendar.js.map
