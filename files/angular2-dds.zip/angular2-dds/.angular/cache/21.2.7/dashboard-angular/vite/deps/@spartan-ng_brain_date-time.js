import {
  BrnDateAdapterToken,
  BrnNativeDateAdapter,
  BrnUtcDateAdapter,
  injectDateAdapter,
  provideDateAdapter,
  provideNativeDateAdapter,
  provideUtcDateAdapter
} from "./chunk-KH75PGHH.js";
import "./chunk-4U2MKPNG.js";
import "./chunk-J672K7WJ.js";
import "./chunk-RSS3ODKE.js";
import "./chunk-S5KMCARS.js";
export {
  BrnDateAdapterToken,
  BrnNativeDateAdapter,
  BrnUtcDateAdapter,
  injectDateAdapter,
  provideDateAdapter,
  provideNativeDateAdapter,
  provideUtcDateAdapter
};
