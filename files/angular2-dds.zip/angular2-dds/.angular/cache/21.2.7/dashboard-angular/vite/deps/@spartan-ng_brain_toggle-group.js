import {
  NG_VALUE_ACCESSOR
} from "./chunk-GZX5U5ZF.js";
import "./chunk-ILAJV3NO.js";
import {
  Directive,
  Input,
  Output,
  booleanAttribute,
  input,
  model,
  output,
  setClassMetadata,
  ɵɵProvidersFeature,
  ɵɵattribute,
  ɵɵdefineDirective,
  ɵɵdomProperty,
  ɵɵlistener
} from "./chunk-4U2MKPNG.js";
import {
  InjectionToken,
  computed,
  forwardRef,
  inject,
  linkedSignal
} from "./chunk-J672K7WJ.js";
import "./chunk-RSS3ODKE.js";
import "./chunk-S5KMCARS.js";

// node_modules/@spartan-ng/brain/fesm2022/spartan-ng-brain-toggle-group.mjs
var BrnToggleGroupToken = new InjectionToken("BrnToggleGroupToken");
function injectBrnToggleGroup() {
  return inject(BrnToggleGroupToken, {
    optional: true
  });
}
function provideBrnToggleGroup(value) {
  return {
    provide: BrnToggleGroupToken,
    useExisting: value
  };
}
var BRN_BUTTON_TOGGLE_GROUP_VALUE_ACCESSOR = {
  provide: NG_VALUE_ACCESSOR,
  useExisting: forwardRef(() => BrnToggleGroup),
  multi: true
};
var BrnButtonToggleChange = class {
  source;
  value;
  constructor(source, value) {
    this.source = source;
    this.value = value;
  }
};
var BrnToggleGroup = class _BrnToggleGroup {
  /** The type of the toggle group. */
  type = input("single", ...ngDevMode ? [{
    debugName: "type"
  }] : []);
  /** Whether the toggle group allows multiple selections. */
  _multiple = computed(() => this.type() === "multiple", ...ngDevMode ? [{
    debugName: "_multiple"
  }] : []);
  /** Value of the toggle group. */
  value = model(void 0, ...ngDevMode ? [{
    debugName: "value"
  }] : []);
  /** Emits when the value changes. */
  valueChange = output();
  /** Whether no button toggles need to be selected. */
  nullable = input(false, ...ngDevMode ? [{
    debugName: "nullable",
    transform: booleanAttribute
  }] : [{
    transform: booleanAttribute
  }]);
  /** Whether the button toggle group is disabled. */
  disabled = input(false, ...ngDevMode ? [{
    debugName: "disabled",
    transform: booleanAttribute
  }] : [{
    transform: booleanAttribute
  }]);
  /** The disabled state. */
  disabledState = linkedSignal(this.disabled, ...ngDevMode ? [{
    debugName: "disabledState"
  }] : []);
  /** Emit event when the group value changes. */
  change = output();
  /**
   * The method to be called in order to update ngModel.
   */
  // eslint-disable-next-line @typescript-eslint/no-empty-function
  _onChange = () => {
  };
  /** onTouch function registered via registerOnTouch (ControlValueAccessor). */
  // eslint-disable-next-line @typescript-eslint/no-empty-function
  onTouched = () => {
  };
  writeValue(value) {
    this.value.set(value);
  }
  registerOnChange(fn) {
    this._onChange = fn;
  }
  registerOnTouched(fn) {
    this.onTouched = fn;
  }
  setDisabledState(isDisabled) {
    this.disabledState.set(isDisabled);
  }
  /**
   * @internal
   * Determines whether a value can be set on the group.
   */
  canDeselect(value) {
    if (this.nullable()) return true;
    const currentValue = this.value();
    if (this._multiple() && Array.isArray(currentValue)) {
      return !(currentValue.length === 1 && currentValue[0] === value);
    }
    return currentValue !== value;
  }
  /**
   * @internal
   * Selects a value.
   */
  select(value, source) {
    if (this.disabledState() || this.isSelected(value)) {
      return;
    }
    const currentValue = this.value();
    if (this._multiple()) {
      this.emitSelectionChange([...currentValue ?? [], value], source);
    } else {
      this.emitSelectionChange(value, source);
    }
    this._onChange(this.value());
    this.change.emit(new BrnButtonToggleChange(source, this.value()));
  }
  /**
   * @internal
   * Deselects a value.
   */
  deselect(value, source) {
    if (this.disabledState() || !this.isSelected(value) || !this.canDeselect(value)) {
      return;
    }
    const currentValue = this.value();
    if (this._multiple()) {
      this.emitSelectionChange((currentValue ?? []).filter((v) => v !== value), source);
    } else if (currentValue === value) {
      this.emitSelectionChange(null, source);
    }
  }
  /**
   * @internal
   * Determines whether a value is selected.
   */
  isSelected(value) {
    const currentValue = this.value();
    if (currentValue == null || currentValue === void 0 || Array.isArray(currentValue) && currentValue.length === 0) {
      return false;
    }
    if (this._multiple()) {
      return currentValue?.includes(value);
    }
    return currentValue === value;
  }
  /** Update the value of the group */
  emitSelectionChange(value, source) {
    this.value.set(value);
    this.valueChange.emit(value);
    this._onChange(value);
    this.change.emit(new BrnButtonToggleChange(source, this.value()));
  }
  /** @nocollapse */
  static ɵfac = function BrnToggleGroup_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _BrnToggleGroup)();
  };
  /** @nocollapse */
  static ɵdir = ɵɵdefineDirective({
    type: _BrnToggleGroup,
    selectors: [["", "brnToggleGroup", ""], ["brn-toggle-group"]],
    hostAttrs: ["role", "group"],
    hostVars: 2,
    hostBindings: function BrnToggleGroup_HostBindings(rf, ctx) {
      if (rf & 1) {
        ɵɵlistener("focusout", function BrnToggleGroup_focusout_HostBindingHandler() {
          return ctx.onTouched();
        });
      }
      if (rf & 2) {
        ɵɵattribute("aria-disabled", ctx.disabledState())("data-disabled", ctx.disabledState());
      }
    },
    inputs: {
      type: [1, "type"],
      value: [1, "value"],
      nullable: [1, "nullable"],
      disabled: [1, "disabled"]
    },
    outputs: {
      value: "valueChange",
      valueChange: "valueChange",
      change: "change"
    },
    exportAs: ["brnToggleGroup"],
    features: [ɵɵProvidersFeature([provideBrnToggleGroup(_BrnToggleGroup), BRN_BUTTON_TOGGLE_GROUP_VALUE_ACCESSOR])]
  });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(BrnToggleGroup, [{
    type: Directive,
    args: [{
      selector: "[brnToggleGroup],brn-toggle-group",
      exportAs: "brnToggleGroup",
      providers: [provideBrnToggleGroup(BrnToggleGroup), BRN_BUTTON_TOGGLE_GROUP_VALUE_ACCESSOR],
      host: {
        role: "group",
        "[attr.aria-disabled]": "disabledState()",
        "[attr.data-disabled]": "disabledState()",
        "(focusout)": "onTouched()"
      }
    }]
  }], null, {
    type: [{
      type: Input,
      args: [{
        isSignal: true,
        alias: "type",
        required: false
      }]
    }],
    value: [{
      type: Input,
      args: [{
        isSignal: true,
        alias: "value",
        required: false
      }]
    }, {
      type: Output,
      args: ["valueChange"]
    }],
    valueChange: [{
      type: Output,
      args: ["valueChange"]
    }],
    nullable: [{
      type: Input,
      args: [{
        isSignal: true,
        alias: "nullable",
        required: false
      }]
    }],
    disabled: [{
      type: Input,
      args: [{
        isSignal: true,
        alias: "disabled",
        required: false
      }]
    }],
    change: [{
      type: Output,
      args: ["change"]
    }]
  });
})();
var BrnToggleGroupItem = class _BrnToggleGroupItem {
  static _uniqueId = 0;
  /** Access the toggle group if available. */
  _group = injectBrnToggleGroup();
  /** The id of the toggle. */
  id = input(`brn-toggle-group-item-${++_BrnToggleGroupItem._uniqueId}`, ...ngDevMode ? [{
    debugName: "id"
  }] : []);
  /** The value this toggle represents. */
  value = input(...ngDevMode ? [void 0, {
    debugName: "value"
  }] : []);
  /** Whether the toggle is disabled. */
  disabled = input(false, ...ngDevMode ? [{
    debugName: "disabled",
    transform: booleanAttribute
  }] : [{
    transform: booleanAttribute
  }]);
  /** Whether the toggle is disabled either from itself or from the group. */
  _disabled = computed(() => this.disabled() || this._group?.disabled(), ...ngDevMode ? [{
    debugName: "_disabled"
  }] : []);
  /** The current state of the toggle when not used in a group. */
  state = model("off", ...ngDevMode ? [{
    debugName: "state"
  }] : []);
  /** The type of the button. */
  type = input("button", ...ngDevMode ? [{
    debugName: "type"
  }] : []);
  /**
   * Accessibility label for screen readers.
   * Use when no visible label exists.
   */
  ariaLabel = input(null, ...ngDevMode ? [{
    debugName: "ariaLabel",
    alias: "aria-label"
  }] : [{
    alias: "aria-label"
  }]);
  /** Whether the toggle is in the on state. */
  _isOn = computed(() => this._state() === "on", ...ngDevMode ? [{
    debugName: "_isOn"
  }] : []);
  /** The current state that reflects the group state or the model state. */
  _state = computed(() => {
    if (this._group) {
      return this._group.isSelected(this.value()) ? "on" : "off";
    }
    return this.state();
  }, ...ngDevMode ? [{
    debugName: "_state"
  }] : []);
  toggle() {
    if (this._disabled()) return;
    if (this._group) {
      if (this._isOn()) {
        this._group.deselect(this.value(), this);
      } else {
        this._group.select(this.value(), this);
      }
    } else {
      this.state.set(this._isOn() ? "off" : "on");
    }
  }
  /** @nocollapse */
  static ɵfac = function BrnToggleGroupItem_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _BrnToggleGroupItem)();
  };
  /** @nocollapse */
  static ɵdir = ɵɵdefineDirective({
    type: _BrnToggleGroupItem,
    selectors: [["button", "brnToggleGroupItem", ""]],
    hostVars: 7,
    hostBindings: function BrnToggleGroupItem_HostBindings(rf, ctx) {
      if (rf & 1) {
        ɵɵlistener("click", function BrnToggleGroupItem_click_HostBindingHandler() {
          return ctx.toggle();
        });
      }
      if (rf & 2) {
        ɵɵdomProperty("id", ctx.id())("type", ctx.type());
        ɵɵattribute("disabled", ctx._disabled() ? true : null)("data-disabled", ctx._disabled() ? true : null)("data-state", ctx._state())("aria-pressed", ctx._isOn())("aria-label", ctx.ariaLabel() || null);
      }
    },
    inputs: {
      id: [1, "id"],
      value: [1, "value"],
      disabled: [1, "disabled"],
      state: [1, "state"],
      type: [1, "type"],
      ariaLabel: [1, "aria-label", "ariaLabel"]
    },
    outputs: {
      state: "stateChange"
    }
  });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(BrnToggleGroupItem, [{
    type: Directive,
    args: [{
      selector: "button[brnToggleGroupItem]",
      host: {
        "[id]": "id()",
        "[attr.disabled]": "_disabled() ? true : null",
        "[attr.data-disabled]": "_disabled() ? true : null",
        "[attr.data-state]": "_state()",
        "[attr.aria-pressed]": "_isOn()",
        "[attr.aria-label]": "ariaLabel() || null",
        "[type]": "type()",
        "(click)": "toggle()"
      }
    }]
  }], null, {
    id: [{
      type: Input,
      args: [{
        isSignal: true,
        alias: "id",
        required: false
      }]
    }],
    value: [{
      type: Input,
      args: [{
        isSignal: true,
        alias: "value",
        required: false
      }]
    }],
    disabled: [{
      type: Input,
      args: [{
        isSignal: true,
        alias: "disabled",
        required: false
      }]
    }],
    state: [{
      type: Input,
      args: [{
        isSignal: true,
        alias: "state",
        required: false
      }]
    }, {
      type: Output,
      args: ["stateChange"]
    }],
    type: [{
      type: Input,
      args: [{
        isSignal: true,
        alias: "type",
        required: false
      }]
    }],
    ariaLabel: [{
      type: Input,
      args: [{
        isSignal: true,
        alias: "aria-label",
        required: false
      }]
    }]
  });
})();
var BrnToggleGroupImports = [BrnToggleGroup, BrnToggleGroupItem];
export {
  BRN_BUTTON_TOGGLE_GROUP_VALUE_ACCESSOR,
  BrnButtonToggleChange,
  BrnToggleGroup,
  BrnToggleGroupImports,
  BrnToggleGroupItem,
  injectBrnToggleGroup,
  provideBrnToggleGroup
};
//# sourceMappingURL=@spartan-ng_brain_toggle-group.js.map
