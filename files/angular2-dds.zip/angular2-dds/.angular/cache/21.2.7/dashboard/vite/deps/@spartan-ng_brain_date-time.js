import {
  BrnDateAdapterToken,
  BrnNativeDateAdapter,
  BrnUtcDateAdapter,
  injectDateAdapter,
  provideDateAdapter,
  provideNativeDateAdapter,
  provideUtcDateAdapter
} from "./chunk-S4VLCQJN.js";
import "./chunk-LIMDZXLF.js";
import "./chunk-6YCBIAWP.js";
import "./chunk-RSS3ODKE.js";
import "./chunk-R2QGWZ7S.js";
export {
  BrnDateAdapterToken,
  BrnNativeDateAdapter,
  BrnUtcDateAdapter,
  injectDateAdapter,
  provideDateAdapter,
  provideNativeDateAdapter,
  provideUtcDateAdapter
};
