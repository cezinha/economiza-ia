# React2 -> Angular2-DDS Migration Plan

## Objetivo
Migrar o aplicativo React2 para Angular, mantendo contratos de rota, comportamentos e UX, seguindo o padrão já estabelecido em angular-dds.

## Estado Atual (27/04/2026 - Após Onda 1 & Onda 2 Início)
- Base criada: angular2-dds foi copiado de angular-dds.
- **Onda 1 CONCLUÍDA**: Todas as 9 rotas faltantes foram adicionadas como páginas transicionais.
- **Onda 2 - Features reais migradas (3 de 4)**:
  - ✅ /document-repository — Feature real com filtros e tabela de documentos
  - ✅ /archive — Feature real com lista expansível e edição de lições aprendidas
  - ✅ /my-tasks — Feature real com filtros por status e painel de detalhe
  - ⏳ /design-issues — Ainda como transitional (próxima prioridade)
- Rotas do React2 com cobertura de transitional (ainda faltam features reais):
  - /design-issues (transitional)
  - /dependencies (transitional)
  - /factory-constraints (transitional)
  - /compliance (transitional)
  - /supply-chain (transitional)
  - /audit-log (transitional)

## Estratégia de Migração
1. Garantir cobertura completa de rotas com páginas transitionais.
2. Migrar feature a feature (não arquivo a arquivo), priorizando maior impacto de negócio.
3. Reaproveitar estrutura existente (standalone components, lazy load, Signal Store, Transloco).
4. Validar build/lint e comportamento ao final de cada onda.

## Ondas de Execução

### Onda 1 - Cobertura de Rotas (rápida)
- Criar páginas transitionais para as 9 rotas faltantes em src/app/features/transitional.
- Registrar todas as novas rotas em src/app/app.routes.ts com loadComponent.
- Ajustar menu/navegação para não haver links quebrados.

Critério de aceite:
- 100% das rotas do React2 respondem no Angular (com página real ou transitional).

### Onda 2 - Migração de Features Prioritárias
Prioridade sugerida (por tamanho/complexidade em React2):
1. /document-repository
2. /design-issues
3. /archive
4. /my-tasks

Ações:
- Migrar dados/modelos para src/app/shared/data e/ou src/app/features/<feature>.
- Criar componentes na estrutura atômica já usada no projeto.
- Preservar estados de loading/empty/error e ações de usuário.

Critério de aceite:
- Features equivalentes às páginas React2 em fluxo principal.

### Onda 3 - Migração de Features Secundárias
Rotas:
- /dependencies
- /factory-constraints
- /compliance
- /supply-chain
- /audit-log

Ações:
- Implementar páginas e subcomponentes mantendo contratos visuais/funcionais.
- Centralizar regras em store/service (evitar lógica de negócio em atoms/molecules).

Critério de aceite:
- Sem dependência funcional do React2 para as rotas acima.

### Onda 4 - Consolidação e Hardening
- Revisar i18n (src/assets/i18n/en.json) para textos novos.
- Revisar consistência de estilos Tailwind e utilitários globais.
- Completar testes mínimos das novas páginas.
- Rodar lint e build finais.

Critério de aceite:
- build e lint sem erro nas áreas alteradas.

## Riscos e Mitigações
- Risco: regressão de UX em páginas densas (Nudds/ProgramDetails já migradas, mas outras densas faltam).
  - Mitigação: migração incremental por feature com validação visual por rota.
- Risco: quebra de layout por diferenças de host Angular em containers.
  - Mitigação: preferir flex flex-col gap-* quando filhos diretos são app-*.
- Risco: bundle crescer além do esperado.
  - Mitigação: manter páginas pesadas com loadComponent no app.routes.ts.
- Risco: ESLint não está configurado no projeto (tentativa de lint falha).
  - Mitigação: foco em build e testes manuais de TypeScript; ESLint pode ser adicionado em Onda 4.

## Checkpoint Operacional
Comandos no angular2-dds:
- npm install
- npm run build (✅ Build concluído com sucesso, warning de budget apenas)
- npm run test:ci
- npx ng lint (requer setup de angular-eslint)

## Status da Migração (27/04/2026 Tarde)
**Concluído:**
- ✅ Onda 1: 100% de cobertura de rotas (9 transicionais + 3 reais migradas)
- ✅ 3 features prioritárias migradas e integradas (Document Repository, Archive, My Tasks)
- ✅ Build sem erro
- ✅ Menu lateral atualizado
- ✅ I18n sincronizado

**Próximo passo recomendado:**
Continuar Onda 2 com /design-issues (próxima prioridade). Após Design Issues, avaliar se Onda 3 (features secundárias) deve ser executada completa ou se projeto entra em Onda 4 (consolidação).
