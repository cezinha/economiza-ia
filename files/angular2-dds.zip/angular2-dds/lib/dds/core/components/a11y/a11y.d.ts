/**
 * This is a shared internal "like component" which is intended to aid with naming, spelling, and
 * consistency when working with accessibility features.
 */
export declare const commonClasses: {
    srOnly: string;
};
export declare const commonAttributes: {
    ariaPolite: {
        "aria-live": string;
    };
    labelledBy: string;
    describedBy: string;
    label: string;
    current: string;
    description: string;
    disabled: string;
    expanded: string;
    invalid: string;
    selected: string;
    checked: string;
    hidden: string;
    posinset: string;
    setsize: string;
    controls: string;
    hasPopup: string;
    roledescription: string;
    atomic: string;
};
