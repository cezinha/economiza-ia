export declare const componentName = "AccordionItem";
export declare const componentClasses: {
    readonly wrapper: "dds__accordion__item";
    readonly focus: "dds__accordion__item--focus";
    readonly expanded: "dds__accordion__item--expanded";
    readonly inactive: "dds__accordion__item--inactive";
    readonly collapsing: "dds__accordion__item--collapsing";
    readonly expanding: "dds__accordion__item--expanding";
    readonly heading: "dds__accordion__heading";
    readonly button: "dds__accordion__button";
    readonly icon: "dds__accordion__icon";
    readonly content: "dds__accordion__content";
    readonly body: "dds__accordion__body";
};
