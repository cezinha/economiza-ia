export declare const componentName = "Accordion";
export declare const defaultLocalization: {
    readonly srExpandAll: "All items expanded";
    readonly srCollapseAll: "All items collapsed";
    readonly expandButtonLabel: "Expand all";
    readonly collapseButtonLabel: "Collapse all";
};
export declare const animations: {
    readonly none: "none";
    readonly normal: "normal";
};
export type Animation = keyof typeof animations;
export declare const componentClasses: {
    readonly accordion: "dds__accordion";
    readonly controls: "dds__accordion__control";
    readonly expandAll: "dds__accordion__control__expand";
    readonly collapseAll: "dds__accordion__control__collapse";
    readonly screenReader: "dds__accordion__sr";
};
export declare const defaultProps: {
    readonly animation: "normal";
    readonly independent: false;
    readonly withControls: false;
};
/**
 * Loops through accordionItems to focus first not inactive item.
 * @param {Array} accordionItems list of AccordionItem instances;
 * @return {void}
 */
export declare const setFocusFirstAvailableItemOnList: (accordionItems: any) => void;
/**
 * Creates a new list from **accordionItems** where the
 * first item will be **index** and the last item **index - 1**
 * @param {Number} index the current index you want to find the next
 * @param {Array} accordionItems;
 * @return {Array}
 */
export declare const forwardListFromIndex: <T = any>(index: number, accordionItems?: Array<T>) => T[];
/**
 * Creates a new list from **accordionItems** where the
 * first item will be **index** and the last item **index + 1**
 * @param {Number} index the current index you want to find the next
 * @param {Array} accordionItems;
 * @return {Array}
 */
export declare const backwardListFromIndex: <T = any>(index: any, accordionItems?: Array<T>) => T[];
/**
 * Find the accordion-item instance on accordionItems list
 * based on **index** which can be a number or an htmlElement
 * Returns -1 when index is not found on accordionItems
 * @param {*} index Number or HTML Element
 * @param {Array} accordionItems list of AccordionItem instances
 * @returns {Number}
 */
export declare const getIndexFromParam: (index: any, accordionItems: any) => any;
