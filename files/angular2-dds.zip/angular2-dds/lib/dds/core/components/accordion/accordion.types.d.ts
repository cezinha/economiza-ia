import { animations } from "./accordion";
export type Animation = keyof typeof animations;
export interface Props {
    /**
     * Defines the animation when expanding or collapsing. Possible values are `normal` (default) and `none`.
     */
    animation: Animation;
    /**
     * Defines whether an accordion item works independently (single) or not (multiples).
     */
    independent: boolean;
    /**
     * @deprecated Use localization.srCollapseAll instead
     */
    srCollapseAll?: string;
    /**
     * @deprecated Use localization.srExpandAll instead
     */
    srExpandAll?: string;
    localization?: Localization;
}
export interface Localization {
    /**
     * Defines the screen reader message that will be announced when it's finished
     * collapsing all items through the collapse-all button or public API call.
     */
    srCollapseAll?: string;
    /**
     * Defines the screen reader message that will be announced when it's finished
     * expanding all items through the expand-all button or public API call.
     */
    srExpandAll?: string;
    expandButtonLabel?: string;
    collapseButtonLabel?: string;
}
