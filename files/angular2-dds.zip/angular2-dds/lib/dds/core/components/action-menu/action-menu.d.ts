export declare const componentName = "ActionMenu";
/**
 * @deprecated - use componentClasses.wrapper
 */
export declare const base = "dds__action-menu";
export declare const componentClasses: {
    readonly wrapper: "dds__action-menu";
    readonly wrapperSm: "dds__action-menu--sm";
    readonly wrapperIsPressing: "dds__action-menu--is-pressing";
    readonly container: {
        readonly base: "dds__action-menu__container";
        readonly positioning: "dds__action-menu__container--positioning";
        readonly visible: "dds__action-menu__container--visible";
    };
    readonly menu: "dds__action-menu__menu";
    readonly separator: "dds__action-menu__separator";
    readonly item: "dds__action-menu__item";
    readonly itemDestructive: "dds__action-menu__item--destructive";
    readonly link: "dds__action-menu__link";
    readonly linkDestructive: "dds__action-menu__link--destructive";
    readonly option: "dds__action-menu__option";
    readonly check: "dds__action-menu__check";
    readonly groupTitle: "dds__action-menu__group__title";
    readonly icon: "dds__action-menu__icon";
};
export declare const sizes: {
    readonly lg: "lg";
    readonly sm: "sm";
};
export declare const types: {
    readonly link: "link";
    readonly option: "option";
    readonly action: "action";
};
/**
 * TODO we don't want the keys to be dashed and that's why we switched to using objects (see placement.js)
 * refactor this once the placement is refactored to TS
 */
export declare const placements: {
    readonly "bottom-start": "bottom-start";
    readonly "bottom-end": "bottom-end";
};
export declare const alignments: {
    readonly start: "start";
    readonly end: "end";
};
