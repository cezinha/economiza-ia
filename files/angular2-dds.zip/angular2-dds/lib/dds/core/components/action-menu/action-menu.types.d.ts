import { sizes, placements, alignments, types } from "./action-menu";
export interface Props {
    /**
     * @deprecated - in favor of using placement
     */
    alignment?: Alignment;
    placement?: Placement;
    closeOnItemClick?: boolean;
    closeOnScroll?: boolean;
    trigger?: string | HTMLElement;
    openOnArrowKeys?: boolean;
}
export type Size = typeof sizes[keyof typeof sizes];
export type Type = typeof types[keyof typeof types];
export type Placement = typeof placements[keyof typeof placements];
export type Alignment = typeof alignments[keyof typeof alignments];
