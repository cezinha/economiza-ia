export declare const componentName = "Badge";
export declare const colors: {
    readonly informative: "informative";
    readonly error: "error";
    readonly gray: "gray";
    readonly success: "success";
    readonly warning: "warning";
    readonly brand: "brand";
};
export declare const emphases: {
    readonly light: "light";
    readonly medium: "medium";
    readonly heavy: "heavy";
};
export declare const sizes: {
    readonly microdot: "microdot";
    readonly dot: "dot";
    readonly mini: "mini";
    readonly sm: "sm";
    readonly md: "md";
    readonly lg: "lg";
};
export declare const componentClasses: {
    readonly base: "dds__badge";
    readonly label: "dds__badge__label";
    readonly sizes: {
        readonly md: "dds__badge--md";
        readonly sm: "dds__badge--sm";
        readonly mini: "dds__badge--mini";
        readonly dot: "dds__badge--dot";
        readonly microdot: "dds__badge--microdot";
    };
    readonly colors: {
        readonly success: "dds__badge--success";
        readonly warning: "dds__badge--warning";
        readonly error: "dds__badge--error";
        readonly gray: "dds__badge--gray";
        readonly brand: "dds__badge--brand";
    };
    readonly emphases: {
        readonly heavy: "dds__badge--heavy";
        readonly medium: "dds__badge--medium";
        readonly light: "dds__badge--light";
    };
    readonly icon: "dds__badge__icon";
};
