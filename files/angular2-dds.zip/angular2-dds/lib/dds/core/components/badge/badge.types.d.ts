import { colors, emphases, sizes } from "./badge";
export type Color = typeof colors[keyof typeof colors];
export type Size = typeof sizes[keyof typeof sizes];
export type Emphasis = typeof emphases[keyof typeof emphases];
