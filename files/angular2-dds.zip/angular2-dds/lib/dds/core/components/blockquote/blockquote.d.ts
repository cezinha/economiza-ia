export declare const componentName = "Blockquote";
export declare const componentClasses: {
    readonly base: "dds__blockquote";
    readonly content: "dds__blockquote-content";
    readonly layout: {
        readonly start: "";
        readonly center: "dds__blockquote--center";
        readonly end: "dds__blockquote--end";
    };
};
export declare const layouts: {
    readonly start: "start";
    readonly center: "center";
    readonly end: "end";
};
