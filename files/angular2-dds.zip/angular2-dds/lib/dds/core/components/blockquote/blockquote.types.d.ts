import { layouts } from "./blockquote";
export type Layout = typeof layouts[keyof typeof layouts];
