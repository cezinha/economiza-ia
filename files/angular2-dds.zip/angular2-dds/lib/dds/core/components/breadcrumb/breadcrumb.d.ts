export declare const componentName = "Breadcrumb";
export declare const componentClasses: {
    readonly list: "dds__breadcrumb";
    readonly listItem: "dds__breadcrumb__item";
    readonly button: "dds__breadcrumb__button";
    readonly mobileIcon: "dds__breadcrumb__mobile-icon";
    readonly homeIcon: "dds__breadcrumb__home-icon";
};
export declare const localization: {
    readonly srExpandLabel: "expand {number} more levels";
    readonly srAriaLabel: "breadcrumb";
};
