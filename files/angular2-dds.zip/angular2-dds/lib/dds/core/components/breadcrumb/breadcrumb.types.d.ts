export interface Props {
    /**
     * @deprecated - use localization.srExpandLabel instead
     */
    buttonLabel?: string;
    localization?: Localization;
}
export interface Localization {
    srExpandLabel: string;
    srAriaLabel?: string;
}
