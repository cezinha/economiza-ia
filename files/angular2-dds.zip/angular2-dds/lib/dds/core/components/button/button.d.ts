export declare const componentName = "Button";
export declare const kinds: {
    readonly primary: "primary";
    readonly secondary: "secondary";
    readonly tertiary: "tertiary";
};
export declare const colors: {
    readonly ai: "ai";
    readonly default: "default";
    readonly destructive: "destructive";
    readonly transactional: "transactional";
    readonly editorial: "editorial";
    readonly editorialLight: "editorial-light";
};
export declare const sizes: {
    readonly mini: "mini";
    readonly sm: "sm";
    readonly md: "md";
    readonly lg: "lg";
};
export declare const iconPlacements: {
    readonly start: "start";
    readonly end: "end";
};
export declare const types: {
    readonly button: "button";
    readonly submit: "submit";
    readonly reset: "reset";
};
export declare const componentClasses: {
    readonly base: "dds__button";
    readonly block: "dds__button--block";
    readonly aiTextGradient: "dds__button__text--ai-gradient";
    readonly kinds: {
        readonly primary: "";
        readonly secondary: "dds__button--secondary";
        readonly tertiary: "dds__button--tertiary";
    };
    readonly colors: {
        readonly default: "";
        readonly destructive: "dds__button--destructive";
        readonly transactional: "dds__button--transactional";
        readonly editorial: "dds__button--editorial";
        readonly editorialLight: "dds__button--editorial-light";
        readonly ai: "dds__button--ai";
    };
    readonly sizes: {
        readonly mini: "dds__button--mini";
        readonly sm: "dds__button--sm";
        readonly md: "dds__button--md";
        readonly lg: "";
    };
    readonly withIcon: {
        readonly start: "dds__button__icon--start";
        readonly end: "dds__button__icon--end";
        readonly only: "dds__button__icon";
    };
};
