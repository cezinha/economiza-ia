import { colors, iconPlacements, kinds, sizes, types } from "./button";
/**
 * @deprecated import these from the button.ts file instead
 */
export { colors, iconPlacements, kinds, sizes };
export type Kind = typeof kinds[keyof typeof kinds];
export type Color = typeof colors[keyof typeof colors];
export type Size = typeof sizes[keyof typeof sizes];
export type IconPlacement = typeof iconPlacements[keyof typeof iconPlacements];
export type Type = typeof types[keyof typeof types];
