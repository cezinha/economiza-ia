export declare const componentName = "Card";
export declare const componentClasses: {
    readonly base: "dds__card";
    readonly actionContainer: "dds__card__footer";
    readonly actionItem: "dds__card__footer__item";
    readonly body: "dds__card__body";
    readonly header: "dds__card__header";
    readonly headerIcon: "dds__card__header__icon";
    readonly content: "dds__card__content";
    readonly title: "dds__card__header__title";
    readonly subtitle: "dds__card__header__subtitle";
    readonly media: "dds__card__media";
    readonly mediaItem: "dds__card__media__item";
    readonly icon: "dds__icon";
    readonly headTopIcon: "dds__card__header--top-icon";
    readonly headerText: "dds__card__header__text";
};
