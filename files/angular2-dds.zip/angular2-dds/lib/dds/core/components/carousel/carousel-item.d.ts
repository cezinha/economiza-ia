export declare const defaultLocalization: {
    readonly srAriaLabel: "Describe the carousel item";
};
