export interface Props {
    localization?: Localization;
}
export type Localization = {
    srAriaLabel?: string;
};
