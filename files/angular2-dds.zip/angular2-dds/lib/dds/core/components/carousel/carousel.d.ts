import type { DeepReadonly } from "../../types/deepreadonly";
import type { Props, Localization } from "./carousel.types";
export declare const componentName = "Carousel";
export declare const resizeMode: {
    container: string;
    window: string;
};
export declare const animation: {
    slide: string;
    none: string;
};
export declare const defaultLocalization: DeepReadonly<Localization>;
export declare const defaultProps: DeepReadonly<Props>;
export declare const componentClasses: {
    readonly container: "dds__carousel";
    readonly compact: "dds__carousel--compact-view";
    readonly noIndicators: "dds__carousel--no-indicators";
    readonly fullWidth: "dds__carousel--full-width";
    readonly multipleItemsPerPage: "dds__carousel--multiple-items-per-page";
    readonly noControls: "dds__carousel--no-controls";
    readonly slider: "dds__carousel__track";
    readonly slides: "dds__carousel__item";
    readonly controls: "dds__carousel__controls";
    readonly next: "dds__carousel__controls__next";
    readonly prev: "dds__carousel__controls__prev";
    readonly indicators: "dds__carousel__indicators";
    readonly indicator: "dds__carousel__indicator";
    readonly activeIndicator: "active";
    readonly indicatorIcon: "dds__carousel__indicator__icon";
    readonly itemsWrapper: "dds__carousel__items-wrapper";
    readonly rendered: "dds__carousel__rendered";
    readonly animations: {
        readonly default: "";
        readonly none: "dds__carousel--transition-none";
    };
    readonly visibleElement: "visible";
};
