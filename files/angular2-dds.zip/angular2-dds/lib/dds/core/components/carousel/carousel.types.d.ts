import { animation, resizeMode } from "./carousel";
export type ResizeMode = typeof resizeMode[keyof typeof resizeMode];
export type Animation = typeof animation[keyof typeof animation];
export interface Props {
    animation?: Animation;
    compactViewBreakpoint?: number;
    indicators?: boolean;
    itemsPerSlide?: number | Record<number, number>;
    localization?: Localization;
    loop?: boolean;
    resizeMode?: ResizeMode;
}
export type Localization = {
    compactPaginationText?: string;
    srIndicatorDescription?: string;
    srPaginationDescription?: string;
    srPaginationIndicatorLabel?: string;
    srAriaLabel?: string;
    srNextPage?: string;
    srPrevPage?: string;
};
