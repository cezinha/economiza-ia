export declare const componentName = "Checkbox";
export declare const componentClasses: {
    readonly base: "dds__checkbox";
    readonly label: "dds__checkbox__label";
    readonly input: "dds__checkbox__input";
    readonly span: "dds__checkbox__span";
    readonly size: {
        readonly lg: "";
        readonly sm: "dds__checkbox--sm";
    };
    readonly fieldsetInline: "dds__fieldset--inline";
    readonly isInvalid: "dds__is--invalid";
    readonly errorText: "dds__invalid-feedback";
    readonly errorIcon: "dds__checkbox__error-text";
    readonly fieldset: "dds__fieldset";
    readonly fieldsetSize: {
        readonly lg: "";
        readonly sm: "dds__fieldset--sm";
    };
    readonly group: "dds__checkbox-group";
    readonly visualIndicator: "dds__visual-indicator";
};
export declare const sizes: {
    readonly sm: "sm";
    readonly lg: "lg";
};
export declare const alignments: {
    readonly horizontal: "horizontal";
    readonly vertical: "vertical";
};
