import { sizes, alignments } from "./checkbox";
export type Size = typeof sizes[keyof typeof sizes];
export type Alignment = typeof alignments[keyof typeof alignments];
