import type { DeepReadonly } from "../../types/deepreadonly";
import type { CalendarLocalization } from "./calendar.types";
export declare const componentName = "Calendar";
export declare const defaultProps: {
    readonly endDate: Date;
    readonly format: "m/d/yyyy";
    readonly inactiveDates: readonly [];
    readonly locale: "en-US";
    readonly startDate: Date;
    readonly selectedDate: undefined;
    readonly displayTodayButton: true;
    readonly weekStart: "sun";
    readonly localization: CalendarLocalization;
    readonly onCancelClick: () => void;
    readonly onConfirmClick: () => void;
    readonly onSelectDate: () => void;
};
declare const _deprecatedProps: {
    cancelLabel: string;
    confirmLabel: string;
    monthSrLabel: string;
    nextSrLabel: string;
    prevSrLabel: string;
    todayLabel: string;
    yearSrLabel: string;
};
export declare const deprecatedProps: DeepReadonly<typeof _deprecatedProps>;
export declare const componentClasses: {
    calendar: {
        base: string;
        isPressing: string;
    };
    header: string;
    headerDisplay: string;
    headerPolite: string;
    monthSelect: string;
    yearSelect: string;
    prevButton: string;
    nextButton: string;
    body: string;
    grid: {
        head: string;
        body: string;
        row: string;
    };
    weekDay: string;
    day: {
        base: string;
        inactive: string;
        outMonth: string;
        today: string;
        selected: string;
        focusable: string;
    };
    footer: string;
    today: {
        base: string;
        inactive: string;
    };
    cancel: string;
    confirm: string;
};
export declare const slotNumber = 42;
export declare const weekStartDays: {
    readonly sun: "sun";
    readonly mon: "mon";
    readonly sat: "sat";
};
declare const _dayNames: {
    sun: number;
    mon: number;
    tue: number;
    wed: number;
    thu: number;
    fri: number;
    sat: number;
};
export declare const dayNames: DeepReadonly<typeof _dayNames>;
/**
 * Verify if a date meet all the requirements to be valid
 * @param {Date} date
 * @param {Date} startDate
 * @param {Date} endDate
 * @param {Array<Date>} inactiveDates
 * @returns {Boolean}
 */
export declare const isValidDate: (date: any, startDate: any, endDate: any, inactiveDates: any) => boolean;
/**
 * Get week day index based on dayNames and javascript Date
 * @param {String} weekStartDay - Week day name based on dayNames keys (From sun[0] to sat[6]).
 * @returns {Number} - From 0 (sun) to 6 (sat)
 */
export declare const getWeekStartDayIndex: (weekStartDay: any) => number;
/**
 * NOTE: Calendar Calendar is based on a 42 slots grid
 * Get the slot index of the first day of month based on the day that week starts
 * @param {Date} date - only month matters
 * @param {Number} weekStartIndex - Index of the starting day of the week (dayNames)
 * @returns {Number} - Slot index
 */
export declare const getFirstDayOfMonthSlotIndex: (date: any, weekStartIndex: any) => number;
/**
 * NOTE: Calendar Calendar is based on a 42 slots grid
 * Get the slot index of the last day of month based on the day that week starts
 * @param {Date} date - only month matters
 * @param {Number} weekStartIndex - Index of the starting day of the week (dayNames)
 * @returns {Number} - Slot index
 */
export declare const getLastDayOfMonthSlotIndex: (date: any, weekStartIndex: any) => number;
/**
 * NOTE: Calendar Calendar is based on a 42 slots grid
 * Get the first slot date based on the day that week starts
 * @param {Date} date - only month matters
 * @param {Number} weekStartIndex - Index of the starting day of the week (dayNames)
 * @returns {Date}
 */
export declare const getFirstSlotDate: (date: any, weekStartIndex: any) => Date;
/**
 * NOTE: Calendar Calendar is based on a 42 slots grid
 * Get the last slot date based on the day that week starts
 * @param {Date} date - only month matters
 * @param {Number} weekStartIndex - Index of the starting day of the week (dayNames)
 * @returns {Date}
 */
export declare const getLastSlotDate: (date: any, weekStartIndex: any) => Date;
/**
 * NOTE: Calendar Calendar is based on a 42 slots grid
 * Check if a date is outside of slots given a base date and the day that week starts to build the range of slots
 * @param {Date} date
 * @param {Date} slotsBaseDate - only month matters
 * @param {Number} weekStartIndex - Index of the starting day of the week (dayNames)
 * @returns {Boolean}
 */
export declare const isDateOutsideSlots: (date: any, slotsBaseDate: any, weekStartIndex: any) => boolean;
/**
 * Generating date hash for mapping date value
 * @param {String} date - Date object
 * @returns {String} date hash value
 */
export declare const getDateHash: (date: any) => string;
/**
 * Map inactive date for easier access to that data
 * @param {Array} inactiveDates - Array of date objects
 * @returns Inactive dates map
 */
export declare const getInactiveDatesMap: (inactiveDates: any) => Map<any, any>;
export {};
