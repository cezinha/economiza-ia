import { weekStartDays } from "./calendar";
/** Define calendar labels localization strings */
export type CalendarLocalization = {
    cancelLabel: string;
    confirmLabel: string;
    todayLabel: string;
    srCalendarLabel: string;
    srKeyboardControlInstructions: string;
    srMonthLabel: string;
    srNextLabel: string;
    srPrevLabel: string;
    srTodayCellLabel: string;
    srYearLabel: string;
    /** @deprecated use srMonthLabel instead */
    monthSrLabel: string;
    /** @deprecated use srNextLabel instead */
    nextSrLabel: string;
    /** @deprecated use srPrevLabel instead */
    prevSrLabel: string;
    /** @deprecated use srYearLabel instead */
    yearSrLabel: string;
};
/** Define the main calendar control props */
export type CalendarProps = {
    endDate: Date;
    format: string;
    inactiveDates: Date[];
    locale: string;
    startDate: Date;
    selectedDate?: Date;
    displayTodayButton: boolean;
    weekStart: string;
    localization: CalendarLocalization;
    onCancelClick: () => void;
    onConfirmClick: () => void;
    onSelectDate: (date: Date) => void;
};
export type WeekStart = typeof weekStartDays[keyof typeof weekStartDays];
