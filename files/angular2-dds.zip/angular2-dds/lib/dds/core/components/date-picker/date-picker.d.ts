import type { DatepickerProps } from "./date-picker.types";
export declare const componentName = "DatePicker";
export declare const base = "dds__date-picker";
export declare const defaultProps: Readonly<DatepickerProps>;
export declare const deprecatedProps: any;
export declare const componentClasses: {
    readonly base: "dds__date-picker";
    readonly invalid: "dds__date-picker--invalid";
    readonly size: {
        readonly lg: "";
        readonly sm: "dds__date-picker--sm";
    };
    readonly label: "dds__date-picker__label";
    readonly calendarButton: "dds__date-picker__calendar-button";
    readonly calendarButtonIcon: "dds__date-picker__calendar-button__icon";
    readonly wrapper: "dds__date-picker__wrapper";
    readonly control: "dds__date-picker__input";
    readonly validationIcon: "dds__date-picker__validation-icon";
    readonly invalidFeedback: "dds__date-picker__invalid-feedback";
    readonly helperText: "dds__date-picker__helper";
    readonly popup: {
        readonly base: "dds__date-picker__popup";
        readonly positioning: "dds__date-picker__popup--positioning";
        readonly visible: "dds__date-picker__popup--visible";
        readonly hidden: "dds__date-picker__popup--hidden";
    };
};
export declare const sizes: {
    readonly sm: "sm";
    readonly lg: "lg";
};
export declare const applyMask: (mask: any, maskChar: any, element: any) => any;
export declare const maskInitChars: {
    numberChar: string;
};
export declare const bindMask: (event: any, format: any, inputElement: any) => void;
