import { sizes } from "./date-picker";
import type { CalendarProps } from "./calendar.types";
/** Defines the datepicker localization structure */
export type Localization = {
    /** @deprecated use srCalendarButtonLabel instead */
    calendarButtonSrLabel: string;
    /** @deprecated use srDateParserLabel instead */
    dateParserSrLabel: string;
    /** @deprecated use unavailable instead */
    unavailableDateErrorMessage: string;
    /** @deprecated use invalid instead */
    invalidDateErrorMessage: string;
    invalid: string;
    unavailable: string;
    srCalendarButtonLabel: string;
    srDateParserLabel: string;
    dateParserLetterError: string;
    dateParserInvalidLengthErrorMessage: string;
    dateParserPredictiveParserErrorMessage: string;
    dateParserNoSeparatorErrorMessage: string;
    dateParserInvalidMonthErrorMessage: string;
    dateParserInvalidDayErrorMessage: string;
};
/** Component main properties which affects the <input> control in template */
export type DatepickerInputProps = {
    predictiveParser: boolean;
    closeOnScroll: boolean;
    inactive: boolean;
    localization: Localization;
};
/** Complete datepicker component props */
export type DatepickerProps = DatepickerInputProps & CalendarProps;
export type Size = typeof sizes[keyof typeof sizes];
