export declare const componentName = "Divider";
export declare const componentClasses: {
    readonly primary: "dds__divider";
    readonly secondary: "dds__divider--secondary";
    readonly vertical: "dds__divider--vertical";
    readonly positionEnd: "dds__divider--vertical--end";
};
export declare const kinds: {
    readonly primary: "primary";
    readonly secondary: "secondary";
};
export declare const layouts: {
    readonly start: "start";
    readonly end: "end";
};
