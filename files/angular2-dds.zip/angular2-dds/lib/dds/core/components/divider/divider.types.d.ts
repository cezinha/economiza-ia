import { kinds, layouts } from "./divider";
export type Kind = typeof kinds[keyof typeof kinds];
export type Layout = typeof layouts[keyof typeof layouts];
