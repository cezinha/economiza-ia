export declare const componentName = "Drawer";
/**
 * @deprecated use componentClasses.base instead
 */
export declare const base = "dds__drawer";
export declare const componentClasses: {
    readonly base: "dds__drawer";
    readonly container: "dds__drawer__container";
    readonly header: "dds__drawer__header";
    readonly body: "dds__drawer__body";
    readonly title: "dds__drawer__title";
    readonly footer: "dds__drawer__footer";
    readonly close: "dds__drawer__close";
    readonly closeIcon: "dds__drawer__close-icon";
    readonly overlay: {
        readonly base: "dds__drawer__overlay";
        readonly blurred: "dds__overlay--blur";
        readonly overflowHidden: "dds__drawer__overlay--overflow-hidden";
    };
    readonly sizes: {
        readonly lg: "";
        readonly md: "dds__drawer--md";
        readonly sm: "dds__drawer--sm";
        readonly xs: "dds__drawer--xs";
    };
};
export declare const sizes: {
    readonly lg: "lg";
    readonly md: "md";
    readonly sm: "sm";
    readonly xs: "xs";
};
export declare const defaultLocalization: {
    readonly srCloseLabel: "Close drawer";
    readonly backButtonLabel: "Back";
    readonly srDrawerLabel: "Drawer";
};
