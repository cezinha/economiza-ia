import { sizes } from "./drawer";
export interface Props {
    trigger?: string;
    visible?: boolean;
    width?: string;
    localization?: Localization;
}
export interface Localization {
    srCloseLabel?: string;
    backButtonLabel?: string;
    srDrawerLabel?: string;
}
export type Size = typeof sizes[keyof typeof sizes];
