export declare const componentName = "Dropdown";
export declare const defaultLocalization: {
    readonly noOptionsLabel: "No options found";
    readonly selectedLabel: "selected";
    readonly srClearLabel: "Clear selected options";
    readonly selectAllLabel: "Select all";
};
export declare const defaultProps: {
    readonly selection: "single";
    readonly selectAll: true;
    readonly required: false;
    readonly inactive: false;
    readonly closeOnScroll: true;
    readonly helperText: "Helper text";
    readonly errorText: "Error text";
    readonly size: "lg";
    readonly label: "Label";
    readonly placeholder: "";
    readonly localization: {
        readonly noOptionsLabel: "No options found";
        readonly selectedLabel: "selected";
        readonly srClearLabel: "Clear selected options";
        readonly selectAllLabel: "Select all";
    };
};
export declare const componentClasses: {
    readonly base: "dds__dropdown";
    readonly isMultiple: "dds__dropdown--is-multiple";
    readonly isPressing: "dds__dropdown--is-pressing";
    readonly sizes: {
        readonly sm: "dds__dropdown--sm";
        readonly lg: "";
    };
    readonly inputContainer: "dds__dropdown__input-container";
    readonly inputWrapper: "dds__dropdown__input-wrapper";
    readonly inputField: "dds__dropdown__input-field";
    readonly inputFieldHidden: "dds__dropdown__input-field-hidden";
    readonly invalid: "dds__is--invalid";
    readonly tag: "dds__dropdown__tag";
    readonly chevron: "dds__dropdown__chevron";
    readonly popup: {
        readonly base: "dds__dropdown__popup";
        readonly positioning: "dds__dropdown__popup--positioning";
        readonly visible: "dds__dropdown__popup--visible";
        readonly hidden: "dds__dropdown__popup--hidden";
    };
    readonly list: {
        readonly base: "dds__dropdown__list";
        readonly empty: "dds__dropdown__list--empty";
    };
    readonly group: "dds__dropdown__group";
    readonly groupTitle: "dds__dropdown__group-title";
    readonly item: "dds__dropdown__item";
    readonly itemOption: "dds__dropdown__item-option";
    readonly itemSelected: "dds__dropdown__item-selected";
    readonly itemLabel: "dds__dropdown__item-label";
    readonly notice: "dds__dropdown__notice";
    readonly selectAll: "dds__dropdown__select-all";
    readonly listItemSeparator: "dds__dropdown__list-separator";
    readonly helperText: "dds__input-text__helper";
    readonly errorText: "dds__invalid-feedback";
    readonly error: "dds__error";
    readonly errorIcon: "dds__dropdown__feedback__icon";
};
export declare const selections: {
    readonly single: "single";
    readonly multiple: "multiple";
};
export declare const sizes: {
    readonly sm: "sm";
    readonly lg: "lg";
};
