import { selections, sizes } from "./dropdown";
export interface Props {
    selection?: Selection;
    selectAll?: boolean;
    required?: boolean;
    inactive?: boolean;
    closeOnScroll?: boolean;
    localization?: Localization;
    popupId?: string;
    /** @deprecated use localization.noOptionsLabel instead */
    noOptionsLabel?: string;
    /** @deprecated use localization.selectedLabel instead */
    selectedLabel?: string;
    /** @deprecated use localization.srClearLabel instead */
    srClearLabel?: string;
    /** @deprecated use localization.selectAllLabel instead */
    selectAllLabel?: string;
}
export interface Localization {
    noOptionsLabel?: string;
    selectedLabel?: string;
    srClearLabel?: string;
    selectAllLabel?: string;
}
export type Selection = typeof selections[keyof typeof selections];
export type Size = typeof sizes[keyof typeof sizes];
