export declare const componentName = "EmptyState";
export declare const base = "dds__empty-state";
export declare const componentClasses: {
    readonly base: "dds__empty-state";
    readonly icon: "dds__empty-state__icon";
    readonly title: "dds__empty-state__title";
    readonly description: "dds__empty-state__description";
    readonly action: "dds__empty-state__action";
};
