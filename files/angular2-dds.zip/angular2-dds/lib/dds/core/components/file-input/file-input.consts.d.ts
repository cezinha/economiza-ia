export declare const sizes: {
    readonly lg: "lg";
    readonly sm: "sm";
};
export declare const statuses: {
    readonly rest: "rest";
    readonly uploading: "uploading";
    readonly success: "success";
    readonly error: "error";
};
