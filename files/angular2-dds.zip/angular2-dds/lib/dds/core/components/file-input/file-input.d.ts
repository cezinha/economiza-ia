import { Localization } from "./file-input.types";
export declare const componentName = "FileInput";
export declare const componentClasses: {
    readonly base: "dds__file-input";
    readonly size: {
        readonly lg: "";
        readonly sm: "dds__file-input--sm";
    };
    readonly button: "dds__file-input__button";
    readonly control: "dds__file-input__control";
    readonly wrapper: "dds__file-input__wrapper";
    readonly label: "dds__file-input__label";
    readonly helperText: "dds__file-input__helper-text";
    readonly errorText: "dds__error-text";
    readonly list: "dds__file-input__list";
    readonly srLabel: "dds__sr-only";
    readonly item: {
        readonly base: "dds__file-input__item";
        readonly text: "dds__file-input__item__text";
        readonly content: "dds__file-input__item__content";
        readonly name: "dds__file-input__item__name";
        readonly size: "dds__file-input__item__size";
        readonly uploading: "dds__file-input__item--uploading";
        readonly success: "dds__file-input__item--success";
        readonly error: "dds__file-input__item--error";
        readonly feedback: "dds__file-input__item__feedback";
        readonly feedbackIcon: "dds__file-input__item__feedback__icon";
        readonly close: "dds__file-input__item__close";
    };
};
export declare const defaultLocalization: Localization;
