import { sizes, statuses } from "./file-input.consts";
export type Localization = {
    uploadingMessage?: string;
    successMessage?: string;
    errorMessageMaxFileCount?: string;
    errorMessageMaxFileSize?: string;
    errorMessageFileType?: string;
    errorAcceptedFileTypes?: string;
    errorMessage?: string;
    errorMaxFileSize?: string;
    errorMaxFileCount?: string;
    srFileRemovedDescription?: string;
    srFileAddedDescription?: string;
    browseButtonLabel?: string;
    srRemoveFileButton?: string;
    srButtonUnavailableDescription?: string;
    removeFileAriaLabel?: string;
    srButtonAvailable?: string;
    srButtonUnavailable?: string;
};
export type Size = typeof sizes[keyof typeof sizes];
export type Status = typeof statuses[keyof typeof statuses];
export type FileItem = {
    file: File;
    status: Status;
    message: string;
};
