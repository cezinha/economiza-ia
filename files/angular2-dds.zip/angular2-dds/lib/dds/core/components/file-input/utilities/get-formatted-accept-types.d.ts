/**
 * Get formatted list for all accepting file types
 * @param {String} acceptTypes Rules list (string) for accepting file types, for example .png, image/gif, video/*
 */
declare const getFormattedAcceptTypes: (acceptTypes?: string) => Array<string>;
export { getFormattedAcceptTypes };
