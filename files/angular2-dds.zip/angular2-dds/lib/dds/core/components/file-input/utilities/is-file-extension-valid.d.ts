/**
 * Return True if the extension of file is valid, False otherwise
 * @param {Object} file File object
 * @param {Array} acceptTypes List of rules to consider a file extension valid
 */
declare const isFileExtensionValid: (file: Pick<File, "name">, acceptTypes: Array<string>) => boolean;
export { isFileExtensionValid };
