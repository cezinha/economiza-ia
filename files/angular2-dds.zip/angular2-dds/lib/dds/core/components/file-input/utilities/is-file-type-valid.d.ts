/**
 * Return True if the type of file is valid, False otherwise
 * @param {Object} file File object
 * @param {Array} acceptTypes List of rules to consider a file type valid
 * @returns Boolean
 */
declare const isFileTypeValid: (file: Pick<File, "type">, acceptTypes: Array<string>) => boolean;
export { isFileTypeValid };
