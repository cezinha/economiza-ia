export declare const componentName = "Footnote";
export declare const componentClasses: {
    readonly base: "dds__footnote";
    readonly styleSelected: "dds__footnote--selected";
    readonly styleTitle: "dds__footnote__title";
};
export declare const defaultLocalization: {
    readonly srLabel: "Footnotes";
};
