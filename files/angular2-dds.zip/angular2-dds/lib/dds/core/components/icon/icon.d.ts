export declare const componentName = "Icon";
export declare const componentClasses: {
    readonly base: "dds__icon";
};
