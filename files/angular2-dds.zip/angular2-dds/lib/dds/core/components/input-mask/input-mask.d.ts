export declare const componentName = "InputMask";
export declare const defaultProps: {
    readonly mask: null;
    readonly alphanumeric: false;
    readonly parseLength: false;
};
export declare const componentClasses: {
    readonly input: "dds__input-text";
    readonly validated: "dds__input-text--invalid";
    readonly errorIcon: "dds__input-text__icon--end";
};
export declare const maskInitChars: {
    readonly numberChar: "9";
    readonly letterChar: "A";
    readonly alphanumericChar: "*";
    readonly formattingChars: readonly ["(", ")", "-", " ", "+", "."];
};
export declare const applyMask: (mask: string[], element: HTMLInputElement) => string;
/**
 * @deprecated - should use applyMask instead but this was left for backwards compatibility.
 * This function only works for numeric masks and not alphanumeric.
 */
export declare const numericOnlyApplyMask: (mask: any, maskChar: any, element: any) => any;
export declare function isAMaskChar(char: string): boolean;
export declare function isNumeric(char: string): boolean;
export declare function isAlpha(char: string): boolean;
export declare function allowedByMaskChar(maskChar: string, char: string): boolean;
