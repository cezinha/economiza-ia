export type FormattingChars = "(" | ")" | "-" | " " | "+" | ".";
export type MaskChars = "*" | "9" | "A";
