import { Localization } from "./input-password.types";
export declare const componentName = "InputPassword";
export declare const componentClasses: {
    readonly action: "dds__input__action";
    readonly switchButton: "dds__input__action--switch";
    readonly validated: "dds__password-input--validated";
    readonly passwordInput: "dds__input-text";
    readonly errorIcon: "dds__input-text__icon--end";
};
export declare const defaultProps: Localization;
