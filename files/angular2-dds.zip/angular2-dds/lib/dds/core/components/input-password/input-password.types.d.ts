export interface Localization {
    showLabel?: string;
    hideLabel?: string;
    srShowTitle?: string;
    srHideTitle?: string;
}
