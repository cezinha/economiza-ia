export declare const componentName = "Label";
export declare const componentClasses: {
    readonly base: "dds__label";
    readonly sizes: {
        readonly sm: "dds__label--sm";
        readonly lg: "";
    };
    readonly required: "dds__label--required";
};
export declare const sizes: {
    readonly sm: "sm";
    readonly lg: "lg";
};
