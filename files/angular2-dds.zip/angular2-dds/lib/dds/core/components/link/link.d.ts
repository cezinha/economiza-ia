export declare const componentName = "Link";
export declare const componentClasses: {
    readonly basic: "dds__link";
    readonly standalone: "dds__link--standalone";
    readonly large: "dds__link--lg";
    readonly small: "dds__link--sm";
    readonly iconStart: "dds__link__icon--start";
    readonly iconEnd: "dds__link__icon--end";
};
export declare const iconPlacements: {
    readonly start: "start";
    readonly end: "end";
};
export declare const kinds: {
    readonly inline: "inline";
    readonly standalone: "standalone";
};
