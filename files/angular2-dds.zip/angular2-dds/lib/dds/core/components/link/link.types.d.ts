import { iconPlacements, kinds } from "./link";
export type IconPlacement = typeof iconPlacements[keyof typeof iconPlacements];
export type Kind = typeof kinds[keyof typeof kinds];
