export declare const componentName = "List";
export declare const componentClasses: {
    readonly base: "dds__list";
    readonly unstyled: "dds__list--unstyled";
};
export declare const kinds: {
    readonly ordered: "ordered";
    readonly unordered: "unordered";
    readonly unstyled: "unstyled";
};
