import { kinds } from "./list";
export type Kind = typeof kinds[keyof typeof kinds];
