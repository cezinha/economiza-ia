import type { Localization } from "./loading-indicator.types";
export declare const componentName = "LoadingIndicator";
export declare const defaultLabel: "Label";
export declare const sizeValues: {
    readonly sm: "sm";
    readonly md: "md";
    readonly lg: "lg";
    readonly xl: "xl";
};
export declare const placementValues: {
    readonly left: "left";
    readonly right: "right";
    readonly start: "start";
    readonly end: "end";
    readonly top: "top";
    readonly bottom: "bottom";
};
export declare const defaultTimeout = 500;
export declare const defaultLocalization: Localization;
export declare const defaultProps: {
    readonly srCompletedText: string | undefined;
    readonly localization: Localization;
};
export declare const componentClasses: {
    readonly main: {
        readonly base: "dds__loading-indicator";
        readonly sizes: {
            readonly sm: "dds__loading-indicator--sm";
            readonly md: "dds__loading-indicator--md";
            readonly lg: "dds__loading-indicator--lg";
        };
        readonly labelPlacement: {
            readonly top: "dds__loading-indicator__label--top";
            /** @deprecated use end instead */
            readonly right: "dds__loading-indicator__label--right";
            /** @deprecated use start instead */
            readonly left: "dds__loading-indicator__label--left";
            readonly end: "dds__loading-indicator__label--end";
            readonly start: "dds__loading-indicator__label--start";
        };
    };
    readonly overlay: {
        readonly base: "dds__loading-indicator__overlay";
        readonly overflowHidden: "dds__loading-indicator__overlay--overflow-hidden";
        readonly blur: "dds__loading-indicator__overlay--blur";
    };
    readonly spinner: "dds__loading-indicator__spinner";
    readonly label: "dds__loading-indicator__label";
    readonly wrapper: "dds__loading-indicator__wrapper";
    readonly container: "dds__loading-indicator__container";
};
