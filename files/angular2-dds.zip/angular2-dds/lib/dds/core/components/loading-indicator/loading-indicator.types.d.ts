import { placementValues, sizeValues } from "./loading-indicator";
export interface Localization {
    srCompletedText?: string;
}
export interface Props {
    srCompletedText?: string;
    localization?: Localization;
}
export type Size = typeof sizeValues[keyof typeof sizeValues];
export type Placement = typeof placementValues[keyof typeof placementValues];
