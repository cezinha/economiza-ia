import { Localization } from "./message-bar.types";
export declare const componentName = "MessageBar";
/**
 * @deprecated use componentClasses.base instead
 */
export declare const base = "dds__message-bar";
export declare const componentClasses: {
    readonly messageBar: {
        readonly base: "dds__message-bar";
        readonly alignment: "dds__message-bar__content--center";
        readonly content: "dds__message-bar__content";
        readonly icon: "dds__message-bar__icon";
        readonly global: "dds__message-bar--global";
        readonly globalContainer: "dds__message-bar--global__container";
        readonly success: "dds__message-bar--success";
        readonly warning: "dds__message-bar--warning";
        readonly error: "dds__message-bar--error";
        readonly hide: "dds__message-bar--hide";
        readonly actionBlock: "dds__action-block";
    };
    readonly activeTimer: "dds__message-bar--timer-active";
    readonly closeButton: "dds__message-bar__dismiss";
    readonly closeButtonIcon: "dds__message-bar__dismiss-icon";
    readonly hasTimer: "dds__message-bar--timer";
    readonly timerButton: "dds__message-bar__dismiss__timer";
    readonly dismissTimer: "dds__message-bar__timer";
    readonly dismissTimerCircle: "dds__message-bar__timer-circle";
    readonly styleShowing: "dds__showing";
    readonly styleHiding: "dds__hiding";
};
export declare const defaultLocalization: Localization;
export declare const colors: {
    readonly informative: "informative";
    readonly success: "success";
    readonly warning: "warning";
    readonly error: "error";
};
export declare const kinds: {
    readonly contextual: "contextual";
    readonly global: "global";
};
export declare const alignments: {
    readonly start: "start";
    readonly center: "center";
};
