import { colors, kinds, alignments } from "./message-bar";
export interface Props {
    dismissible?: boolean;
    startShow?: boolean;
    timer?: boolean;
    timerDuration?: number;
    localization?: Localization;
    /** @deprecated use localization.srCloseButton instead */
    srCloseLabel?: string;
}
export interface Localization {
    srCloseButton?: string;
}
export type Color = typeof colors[keyof typeof colors];
export type Kind = typeof kinds[keyof typeof kinds];
export type Alignment = typeof alignments[keyof typeof alignments];
