export declare const componentName = "Modal";
export declare const sizes: {
    readonly md: "md";
    readonly lg: "lg";
};
export declare const localization: {
    readonly srCloseLabel: "Close dialog";
};
export declare const defaultProps: {
    /**
     * @deprecated use localization.srCloseLabel instead
     */
    readonly srCloseLabel: undefined;
    readonly trigger: undefined;
    readonly preventBackgroundScroll: false;
    readonly localization: {
        readonly srCloseLabel: "Close dialog";
    };
};
export declare const componentClasses: {
    readonly basic: "dds__modal";
    readonly title: "dds__modal__title";
    readonly content: "dds__modal__content";
    readonly body: "dds__modal__body";
    readonly footer: "dds__modal__footer";
    readonly header: "dds__modal__header";
    readonly large: "dds__modal--lg";
    readonly show: "dds__modal--show";
    readonly closeButton: "dds__modal__button--close";
    readonly overflowVisible: "dds__modal--overflow-visible";
    readonly overlay: {
        readonly overflowHidden: "dds__modal__overlay--overflow-hidden";
    };
};
/**
 * @deprecated uses sizes instead
 */
export declare const SizeValues: readonly ["md", "lg"];
