import { sizes } from "./modal";
export type Size = typeof sizes[keyof typeof sizes];
export interface Localization {
    srCloseLabel: string;
}
export interface Props {
    /**
     * @deprecated use localization.srCloseLabel instead
     */
    srCloseLabel?: string;
    trigger?: string;
    preventBackgroundScroll?: boolean;
    localization?: Localization;
}
