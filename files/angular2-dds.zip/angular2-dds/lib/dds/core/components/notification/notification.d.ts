export declare const componentName = "Notification";
export declare const localization: {
    readonly srCloseLabel: "Dismiss notification";
    readonly srNotificationsLabel: "Notifications";
};
export declare const componentClasses: {
    readonly wrapper: "dds__notification__wrapper";
    readonly base: "dds__notification";
    readonly body: "dds__notification__body";
    readonly header: "dds__notification__header";
    readonly headerTitle: "dds__notification__header-title";
    readonly message: "dds__notification__message";
    readonly footer: "dds__notification__footer";
    readonly icon: "dds__notification__icon";
    readonly closeButton: "dds__notification__close-button";
    readonly closeButtonIcon: "dds__notification__close-button__icon";
    readonly timeStamp: "dds__notification__time-stamp";
    readonly show: "dds__show";
};
