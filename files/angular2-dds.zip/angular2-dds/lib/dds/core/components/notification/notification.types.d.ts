import type { Name as IconName, Type as IconType } from "../icon/icon.types";
export interface Props {
    closeIcon?: boolean;
    messageBody?: string;
    primaryAction?: () => void;
    primaryActionText?: string;
    secondaryAction?: () => void;
    secondaryActionText?: string;
    timeStamp?: string;
    title?: string;
    titleIcon?: IconName;
    titleIconType?: IconType;
    localization?: Localization;
}
export interface Localization {
    srCloseLabel?: string;
    srNotificationsLabel?: string;
}
