export declare const componentName = "Overlay";
export declare const overlays: {
    readonly transparent: "transparent";
    readonly blurred: "blurred";
};
export declare const componentClasses: {
    readonly default: "dds__overlay";
    readonly blur: "dds__overlay--blur";
    readonly absolute: "dds__overlay--absolute";
    readonly overflow: "dds__overlay--overflow-hidden";
};
