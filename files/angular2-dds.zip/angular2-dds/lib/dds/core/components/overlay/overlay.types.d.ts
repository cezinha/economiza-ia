import { overlays } from "./overlay";
export type Overlay = typeof overlays[keyof typeof overlays];
