export declare const componentName = "Pagination";
export declare const defaultProps: {
    readonly currentPage: 1;
    readonly totalItems: 0;
    readonly ariaCurrentPageDescription: "Navigate to page from 1 to {totalPages}";
};
export declare const defaultLocalization: Localization;
export interface Localization {
    nextPage?: string;
    prevPage?: string;
    items?: string;
    itemsPerPage?: string;
    label?: string;
    page?: string;
    preposition?: string;
    /** @deprecated see https://confluence.dell.com/display/DDSYS/%5BARD%5D+Pagination */
    srInputDescription?: string;
    srNextPage?: string;
    srPrevPage?: string;
    srLastPage?: string;
    srFirstPage?: string;
}
export declare const componentClasses: {
    readonly pagination: {
        readonly base: "dds__pagination";
        readonly width1024: "dds__pagination--width-1024";
        readonly width768: "dds__pagination--width-768";
        readonly width640: "dds__pagination--width-640";
        readonly width480: "dds__pagination--width-480";
        readonly width360: "dds__pagination--width-360";
    };
    readonly summary: "dds__pagination__summary";
    readonly perPageLabel: "dds__pagination__per-page-label";
    readonly perPageSelect: "dds__pagination__per-page-select";
    readonly range: "dds__pagination__range";
    readonly rangeStart: "dds__pagination__range-start";
    readonly rangeEnd: "dds__pagination__range-end";
    readonly rangeTotal: "dds__pagination__range-total";
    readonly rangeTotalLabel: "dds__pagination__range-total-label";
    readonly nav: "dds__pagination__nav";
    readonly firstPage: "dds__pagination__first-page";
    readonly prevPage: "dds__pagination__prev-page";
    readonly prevPageLabel: "dds__pagination__prev-page-label";
    readonly prevPageIcon: "dds__pagination__prev-page__icon";
    readonly pageRange: "dds__pagination__page-range";
    readonly pageRangeLabel: "dds__pagination__page-range-label";
    readonly pageRangeCurrentWrapper: "dds__pagination__page-range-current-wrapper";
    readonly pageRangeCurrent: {
        readonly base: "dds__pagination__page-range-current";
        readonly wide: "dds__pagination__page-range-current--wide";
        readonly wider: "dds__pagination__page-range-current--wider";
    };
    readonly pageRangeTotalLabel: "dds__pagination__page-range-total-label";
    readonly pageRangeTotal: "dds__pagination__page-range-total";
    readonly nextPage: "dds__pagination__next-page";
    readonly nextPageLabel: "dds__pagination__next-page-label";
    readonly nextPageIcon: "dds__pagination__next-page__icon";
    readonly lastPage: "dds__pagination__last-page";
};
