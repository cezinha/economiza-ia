export declare const componentName = "Popover";
export declare const defaultLocalization: {
    readonly srCloseLabel: "close popover";
};
export declare const sizes: {
    readonly sm: "sm";
    readonly md: "md";
    readonly lg: "lg";
};
export declare const breakpoints: {
    readonly sm: 288;
    readonly md: 488;
    readonly lg: 800;
};
export declare const defaultProps: {
    readonly closeOnScroll: false;
    readonly localization: {
        readonly srCloseLabel: "close popover";
    };
    readonly placement: string;
    readonly size: "sm";
    readonly srCloseLabel: undefined;
};
export declare const componentClasses: {
    readonly base: "dds__popover";
    readonly size: {
        readonly sm: "dds__popover--sm";
        readonly md: "dds__popover--md";
        readonly lg: "dds__popover--lg";
    };
    readonly open: "dds__popover--open";
    readonly content: "dds__popover__content";
    readonly body: "dds__popover__body";
    readonly header: "dds__popover__header";
    readonly headline: "dds__popover__headline";
    readonly animating: "dds__popover--animating";
    readonly close: "dds__popover__close";
    readonly pointer: "dds__popover__pointer";
};
