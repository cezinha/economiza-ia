import { placements } from "../../js/placement/placement";
import { sizes } from "./popover";
export interface Localization {
    srCloseLabel?: string;
}
export type Size = typeof sizes[keyof typeof sizes];
export type Placement = typeof placements[keyof typeof placements];
export interface Props {
    closeOnScroll?: boolean;
    localization?: Localization;
    placement?: string;
    size?: Size;
    srCloseLabel?: string | undefined;
    trigger?: string;
}
