export declare const sizes: {
    readonly sm: "sm";
    readonly md: "md";
    readonly lg: "lg";
};
export declare const placements: {
    default: string;
    inline: string;
};
export declare const formats: {
    default: string;
    usingSteps: string;
};
export declare const base = "dds__progress-bar";
export declare const componentClasses: {
    readonly base: "dds__progress-bar";
    readonly dynamicTransition: "dds__dynamic-progress-bar";
    readonly elements: {
        readonly label: "dds__progress-bar__label";
        readonly amount: {
            readonly container: "dds__progress-bar__value";
            readonly displayed: "dds__progress-bar__value__display";
        };
        readonly indicator: "dds__progress-bar__indicator";
        readonly helper: "dds__progress-bar__helper-text";
    };
    readonly indeterminate: "dds__progress-bar--indeterminate";
    readonly placement: "dds__progress-bar--start";
    readonly sizes: {
        readonly lg: "";
        readonly md: "dds__progress-bar--md";
        readonly sm: "dds__progress-bar--sm";
    };
};
export declare const componentName = "ProgressBar";
export declare const defaultProps: {
    readonly currentValue: 0;
    readonly maxValue: 100;
    readonly useSteps: false;
};
