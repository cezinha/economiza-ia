import { sizes, placements, formats } from "./progress-bar";
export type Size = keyof typeof sizes;
export type Placement = keyof typeof placements;
export type ValueFormat = keyof typeof formats | string;
export type Localization = {
    successMessage?: string;
    valueFormat?: ValueFormat;
};
