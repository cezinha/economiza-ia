export declare const componentName = "ProgressTracker";
export declare const status: {
    readonly inProgress: "in-progress";
    readonly complete: "complete";
    readonly active: "active";
    readonly inactive: "inactive";
};
export declare const size: {
    readonly sm: "sm";
    readonly lg: "lg";
};
export declare const direction: {
    readonly horizontal: "horizontal";
    readonly vertical: "vertical";
};
export declare const componentClasses: {
    readonly base: "dds__progress-tracker";
    readonly vertical: "dds__progress-tracker--vertical";
    readonly small: "dds__progress-tracker--sm";
    readonly item: {
        readonly base: "dds__progress-tracker__item";
        readonly inProgress: "dds__progress-tracker--in-progress";
        readonly complete: "dds__progress-tracker--complete";
        readonly active: "dds__progress-tracker--active";
        readonly circle: "dds__progress-tracker__circle";
        readonly icon: "dds__progress-tracker__icon";
        readonly content: "dds__progress-tracker__content";
        readonly stepName: "dds__progress-tracker__step-name";
    };
};
export declare const defaultLocalization: {
    readonly srCompleted: "Completed";
    readonly srNotStarted: "Not started";
};
