import { status, size, direction } from "./progress-tracker";
export type Status = typeof status[keyof typeof status];
export type Size = typeof size[keyof typeof size];
export type Direction = typeof direction[keyof typeof direction];
export interface Localization {
    srCompleted?: string;
    srNotStarted?: string;
}
