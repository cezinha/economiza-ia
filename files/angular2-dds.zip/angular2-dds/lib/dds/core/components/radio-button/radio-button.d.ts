export declare const componentName = "RadioButton";
export declare const sizes: {
    readonly sm: "sm";
    readonly lg: "lg";
};
export declare const alignments: {
    readonly horizontal: "horizontal";
    readonly vertical: "vertical";
};
export declare const componentClasses: {
    readonly base: "dds__radio-button";
    readonly errorText: "dds__invalid-feedback";
    readonly errorIcon: "dds__radio-button__error-text";
    readonly group: "dds__radio-button-group";
    readonly fieldset: {
        readonly base: "dds__fieldset";
        readonly alignment: {
            readonly horizontal: "dds__fieldset--inline";
        };
        readonly size: {
            readonly lg: "";
            readonly sm: "dds__fieldset--sm";
        };
    };
    readonly input: "dds__radio-button__input";
    readonly isInvalid: "dds__is--invalid";
    readonly label: "dds__radio-button__label";
    readonly size: {
        readonly lg: "";
        readonly sm: "dds__radio-button--sm";
    };
    readonly visualIndicator: "dds__visual-indicator";
};
