import { alignments, sizes } from "./radio-button";
export type Size = typeof sizes[keyof typeof sizes];
export type Alignment = typeof alignments[keyof typeof alignments];
