import type { Localization } from "./search.types";
export declare const defaultLocalization: Localization;
export declare const componentName = "Search";
export declare const componentClasses: {
    readonly base: "dds__search";
    readonly sizes: {
        readonly lg: "";
        readonly sm: "dds__search--sm";
    };
    readonly label: "dds__label";
    readonly wrapper: "dds__search__wrapper";
    readonly control: "dds__search__control";
    readonly actionGroup: "dds__search__action-group";
    readonly action: "dds__search__action";
    readonly actions: {
        readonly clear: "dds__search__action-clear";
        readonly submit: "dds__search__action-submit";
        readonly hide: "dds__search__action--hide";
    };
};
export declare const sizes: {
    readonly lg: "lg";
    readonly sm: "sm";
};
