import { sizes } from "./search";
export interface Props {
    localization?: Localization;
    /** @deprecated use localization.srClearButtonAvailable instead */
    srClearButtonAvailable?: string;
    /** @deprecated use localization.srClearButtonText instead */
    srClearButtonText?: string;
    /** @deprecated use localization.srSearchButtonText instead */
    srSearchButtonText?: string;
    /** @deprecated no longer needed */
    srClearButtonHidden?: string;
}
export interface Localization {
    srClearButtonText?: string;
    srSearchButtonText?: string;
    /** @deprecated no longer needed */
    srClearButtonHidden?: string;
    /** @deprecated no longer needed */
    srClearButtonAvailable?: string;
}
export type Size = typeof sizes[keyof typeof sizes];
