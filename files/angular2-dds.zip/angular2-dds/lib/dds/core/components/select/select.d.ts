export declare const sizes: {
    readonly sm: "sm";
    readonly lg: "lg";
};
export declare const componentName = "Select";
export declare const componentClasses: {
    readonly basic: "dds__select";
    readonly placeholder: "dds__select--placeholder";
    readonly wrapper: "dds__select__wrapper";
    readonly field: "dds__select__field";
    readonly optionPlaceholder: "dds__select__option--placeholder";
    readonly helperText: "dds__select__helper";
    readonly chevronIcon: "dds__select__chevron";
    readonly feedbackIcon: "dds__select__feedback__icon";
    readonly errorText: "dds__invalid-feedback";
    readonly isInvalid: "dds__is--invalid";
    readonly sizes: {
        readonly sm: "dds__select--sm";
        readonly lg: "";
    };
};
