export declare const componentName = "SideNavGroup";
export declare const componentClasses: {
    readonly base: "dds__side-nav__group";
    readonly selected: "dds__side-nav__group--selected";
    readonly collapse: "dds__collapse";
    readonly chevron: "dds__side-nav__group__chevron";
};
export declare const defaultProps: {
    readonly expand: false;
};
