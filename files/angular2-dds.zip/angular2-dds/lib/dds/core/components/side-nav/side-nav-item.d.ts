export declare const componentName = "SideNavItem";
export declare const componentClasses: {
    readonly base: "dds__side-nav__item";
    readonly selected: "dds__side-nav__item--selected";
};
export declare const defaultProps: {
    readonly index: undefined;
    readonly toggleStore: undefined;
    readonly selected: false;
};
