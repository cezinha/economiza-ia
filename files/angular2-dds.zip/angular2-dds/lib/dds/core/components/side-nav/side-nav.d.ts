export declare const componentName = "SideNav";
export declare const componentClasses: {
    readonly base: "dds__side-nav";
    readonly menu: "dds__side-nav__menu";
    readonly toggle: "dds__side-nav__toggle";
    readonly wrapper: "dds__side-nav__wrapper";
    readonly fixed: "dds__side-nav__wrapper--fixed";
    readonly toggleButton: "dds__side-nav__toggle > button";
    readonly icon: "dds__side-nav__icon";
};
export declare const defaultProps: {
    readonly expand: true;
    readonly fixed: false;
    /**
     * @deprecated - moved to localization.
     */
    readonly srToggleExpanded: "Navigation expanded";
    /**
     * @deprecated - moved to localization.
     */
    readonly srToggleCollapsed: "Navigation collapsed";
};
export declare const defaultLocalization: {
    readonly srExpandLabel: "Expand navigation";
    readonly srCollapseLabel: "Collapse navigation";
    /**
     * @deprecated - this aria-live text should be removed.
     * https://confluence.dell.com/display/DDSYS/DDS+Engineering%3A+Components+%3E+Requirements+%3E+DRAFT%3A+Side+navigation
     */
    readonly srToggleExpanded: "Navigation expanded";
    /**
     * @deprecated - this aria-live text should be removed.
     * https://confluence.dell.com/display/DDSYS/DDS+Engineering%3A+Components+%3E+Requirements+%3E+DRAFT%3A+Side+navigation
     */
    readonly srToggleCollapsed: "Navigation collapsed";
    /**
     * @deprecated - this label is not necessary if you're already using it with a <nav>
     */
    readonly srNavLabel: "Side Navigation";
};
