export interface Localization {
    srExpandLabel?: string;
    srCollapseLabel?: string;
    /**
     * @deprecated - this aria-live text should be removed.
     * https://confluence.dell.com/display/DDSYS/DDS+Engineering%3A+Components+%3E+Requirements+%3E+DRAFT%3A+Side+navigation
     */
    srToggleExpanded?: string;
    /**
     * @deprecated - this aria-live text should be removed.
     * https://confluence.dell.com/display/DDSYS/DDS+Engineering%3A+Components+%3E+Requirements+%3E+DRAFT%3A+Side+navigation
     */
    srToggleCollapsed?: string;
    /**
     * @deprecated - this label is not necessary if you're already using it with a <nav>
     */
    srNavLabel?: string;
}
export interface Props {
    expand?: boolean;
    fixed?: boolean;
    srToggleExpanded?: string;
    srToggleCollapsed?: string;
}
