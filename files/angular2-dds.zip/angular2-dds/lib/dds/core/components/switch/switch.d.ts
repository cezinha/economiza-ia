import { Localization } from "./switch.types";
export declare const componentName = "Switch";
export declare const sizes: {
    readonly sm: "sm";
    readonly lg: "lg";
};
export declare const horizontalAlignments: {
    readonly start: "start";
    readonly spaceBetween: "space-between";
};
export declare const defaultLocalization: Localization;
export declare const defaultProps: {
    readonly inactive: false;
    readonly checked: false;
};
export declare const componentClasses: {
    readonly base: "dds__switch";
    readonly sizes: {
        readonly lg: "";
        readonly sm: "dds__switch--sm";
    };
    readonly alignHorizontalStartBase: "dds__switch--horizontal-start";
    readonly label: "dds__switch__label";
    readonly area: "dds__switch__area";
    readonly track: "dds__switch__track";
    readonly handle: "dds__switch__handle";
    readonly controlLabel: "dds__switch__control-label";
    readonly controlLabelOn: "dds__switch__control-label__on";
    readonly controlLabelOff: "dds__switch__control-label__off";
};
