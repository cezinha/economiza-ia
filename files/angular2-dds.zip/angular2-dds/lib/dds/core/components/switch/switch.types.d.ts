import { sizes, horizontalAlignments } from "./switch";
export interface Props {
    /**
     * Set the inactivity state of the switch.
     */
    inactive?: boolean;
    /**
     * Set the checked state of the switch.
     */
    checked?: boolean;
}
export type Size = typeof sizes[keyof typeof sizes];
export type HorizontalAlignment = typeof horizontalAlignments[keyof typeof horizontalAlignments];
export interface Localization {
    onLabel: string;
    offLabel: string;
}
