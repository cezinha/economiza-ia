export declare const componentName = "TableBody";
export declare const componentClasses: {
    readonly base: "dds__tbody";
};
