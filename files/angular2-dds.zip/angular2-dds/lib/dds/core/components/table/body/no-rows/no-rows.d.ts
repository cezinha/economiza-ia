export declare const componentClasses: {
    readonly base: "dds__table__no-rows";
    readonly cell: "dds__table__no-rows__cell";
};
