export declare const componentName = "TableBodyCell";
export declare const componentClasses: {
    readonly base: "dds__td";
    readonly hidden: "dds__td--hidden";
    readonly expandableCell: "dds__td--expandable";
    readonly expandableButton: {
        readonly base: "dds__td--expandable__button";
        readonly screenReader: "dds__td--expandable__button__sr";
        readonly label: "dds__td--expandable__button__label";
        readonly opened: "dds__td--expandable__button--opened";
        readonly icon: "dds__td--expandable__button__icon";
    };
    readonly expandable: {
        readonly content: "dds__td--expandable-content";
        readonly empty: "dds__td--expandable--empty";
    };
    readonly selectableCell: "dds__td--selectable";
    readonly states: {
        readonly focus: "dds__td--focus";
    };
    readonly align: {
        readonly end: "dds__td--align-end";
    };
};
