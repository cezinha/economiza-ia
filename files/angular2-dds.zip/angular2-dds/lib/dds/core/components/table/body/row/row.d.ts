export declare const componentName = "TableBodyRow";
export declare const componentClasses: {
    readonly base: "dds__tr";
    readonly expandable: {
        readonly base: "dds__tr__expandable";
        readonly expanded: "dds__tr--expanded";
    };
    readonly selected: "dds__tr--selected";
};
