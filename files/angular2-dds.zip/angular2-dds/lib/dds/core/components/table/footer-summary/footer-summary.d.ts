export declare const componentName = "TableFooterSummary";
export declare const componentClasses: {
    readonly base: "dds__table__footer-summary";
};
