export declare const componentName = "TableHead";
export declare const componentClasses: {
    readonly base: "dds__thead";
};
