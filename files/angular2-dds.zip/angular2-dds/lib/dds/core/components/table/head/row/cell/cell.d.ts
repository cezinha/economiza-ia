import type { DeepReadonly } from "../../../../../types/deepreadonly";
export declare const componentName = "TableHeadCell";
declare const _componentClasses: {
    base: string;
    hidden: string;
    align: {
        end: string;
    };
    states: {
        focus: string;
    };
    withAction: string;
    buttonScreenReader: string;
    pinIcon: string;
    sortIcon: string;
    actionButton: {
        rest: string;
        label: string;
        icon: string;
    };
    expandableCell: string;
    selectableCell: string;
    columnFilter: {
        rest: string;
        control: string;
        icon: string;
        modifier: string;
    };
};
export declare const componentClasses: DeepReadonly<typeof _componentClasses>;
export declare const columnFilterDelay = 750;
export {};
