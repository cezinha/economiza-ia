export declare const componentName = "TableHeadRow";
export declare const componentClasses: {
    readonly base: "dds__tr";
};
