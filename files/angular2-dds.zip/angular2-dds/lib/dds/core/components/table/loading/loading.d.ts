export declare const base = "dds__table__loading";
export declare const baseWrapper = "dds__table__loading__wrapper";
export declare const baseLoadingIndicator = "dds__table__loading__loading-indicator";
export declare const componentClasses: {
    readonly base: "dds__table__loading";
    readonly container: {
        readonly base: "dds__table__loading";
        readonly centered: "dds__table__loading--centered";
    };
    readonly wrapper: {
        readonly base: "dds__table__loading__wrapper";
        readonly compact: "dds__table__loading__wrapper--compact";
        readonly sm: "dds__table__loading__wrapper--sm";
    };
    readonly loadingIndicator: {
        readonly base: "dds__table__loading__loading-indicator";
        readonly sm: "dds__table__loading__loading-indicator--sm";
    };
};
