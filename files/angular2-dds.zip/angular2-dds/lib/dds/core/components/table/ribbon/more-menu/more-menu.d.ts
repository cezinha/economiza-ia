export declare const componentClasses: {
    readonly trigger: {
        readonly textContent: {
            readonly className: "dds__table__bulk-action__more-menu__trigger__text-content";
            readonly hidden: "dds__sr-only";
        };
        readonly icon: {
            readonly iconEnd: "dds__button__icon--end";
        };
    };
};
