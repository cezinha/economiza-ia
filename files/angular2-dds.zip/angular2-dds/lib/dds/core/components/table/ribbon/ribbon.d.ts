export declare const componentName = "TableRibbon";
export declare const componentClasses: {
    readonly base: "dds__table__ribbon";
    readonly singleLine: "dds__table__ribbon--single-line";
    readonly actionBar: "dds__table__ribbon__action-bar";
    readonly bulkActionsBar: "dds__table__ribbon__bulk-actions-bar";
    readonly breakpoints: {
        readonly 480: "dds__table__ribbon--breakpoint-480";
        readonly 768: "dds__table__ribbon--breakpoint-768";
    };
};
export declare const componentBreakpoints: {
    480: number;
    768: number;
};
