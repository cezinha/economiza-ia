import type { DeepReadonly } from "../../../../types/deepreadonly";
export declare const componentName = "TableSearch";
export declare const base = "dds__table__search";
declare const _componentClasses: {
    base: string;
    control: string;
    icon: string;
};
export declare const componentClasses: DeepReadonly<typeof _componentClasses>;
export declare const searchDebounceDelay = 400;
export {};
