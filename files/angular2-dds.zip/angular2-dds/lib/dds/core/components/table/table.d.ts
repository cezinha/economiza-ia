import { DeepReadonly } from "../../types/deepreadonly";
import { Column, ColumnSortLabels, NoRows, Pin, PinParams, Props } from "./table.types";
export declare const componentName = "Table";
export declare const defaultLocalization: {
    readonly ariaLoading: "Loading table data";
    readonly ariaRows: "rows available";
    readonly bulkActionsMoreMenuLabel: "More";
    readonly changeSort: "Change Sort";
    readonly collapseRow: "Collapse the row";
    readonly columnFilterAriaLabel: "Filter {column} entries";
    readonly columnFilterClearAriaLabel: "Clear {column} filter";
    readonly columnFilterClearButtonAvailable: "Clear button available";
    readonly columnFilterClearButtonHidden: "Clear button hidden";
    readonly expandRow: "Expand the row";
    readonly searchPlaceholder: "Table search";
    readonly pinColumn: "Pin column";
    readonly unpinColumn: "Unpin column";
    readonly selectAllLabel: "Select all rows";
    readonly selectedRowsTagLabel: {
        readonly zero: undefined;
        readonly one: "{count} row selected";
        readonly two: undefined;
        readonly few: undefined;
        readonly many: undefined;
        readonly other: "{count} rows selected";
    };
    readonly selectedRowsTagDismissAriaLabel: "Clear selection";
    readonly selectableCheckboxLabelSelect: "Select row {rowIndex}";
    readonly featureNameColumnFilter: "column filter";
    readonly featureNamePin: "pin";
    readonly featureNameSearch: "search";
    readonly featureNameSort: "sort";
    readonly showHideColumnsShowingColumns: "Showing {x} of {y} columns.";
    readonly showHideColumnsRibbonButtonLabel: "Show or Hide Columns";
    readonly showHideColumnsDrawerTitle: "Show or Hide Columns";
    readonly showHideColumnsDrawerDescription: "Selected columns show on the table. Unselect a column to hide it. This may affect data displayed in the table.";
    readonly showHideColumnsDrawerInputPlaceholder: "Filter by column name.";
    readonly showHideColumnsDrawerNoColumnsFoundTitle: "No results found for \"{term}\".";
    readonly showHideColumnsDrawerNoColumnsFoundDescription: "Check spelling or search another term.";
    readonly showHideColumnsDrawerInfoMessage: "This column has {featureNames} applied to it.";
    readonly showHideColumnsDrawerInfoMessageConjunction: ", and";
    readonly showHideColumnsDrawerErrorNoColumnsSelected: "Select at least one column to continue.";
    readonly showHideColumnsDrawerApplyButtonLabel: "Apply changes";
    readonly showHideColumnsDrawerCancelButtonLabel: "Cancel";
    readonly srLoadingLabel: "Loading";
    /** Deprecated session */
    /** @deprecated now use just selectAllLabel instead */
    readonly deselectAllLabel: "Deselect all rows";
    /** @deprecated now use just selectableCheckboxLabelSelect instead */
    readonly selectableCheckboxLabelDeselect: "Deselect row {rowIndex}";
};
export declare const defaultNoRows: DeepReadonly<NoRows>;
export declare const defaultPin: DeepReadonly<Pin>;
export declare const defaultProps: DeepReadonly<Partial<Props>>;
export declare const defaultColumnSortLabels: DeepReadonly<ColumnSortLabels>;
export declare const defaultPinParams: DeepReadonly<PinParams>;
export declare const defaultColumnProps: DeepReadonly<Partial<Column>>;
export declare const componentClasses: {
    readonly base: "dds__table";
    readonly pin: {
        readonly base: "dds__table__col--pinned";
        readonly direction: {
            readonly start: {
                readonly anchor: "dds__table__col--pinned-start-anchor";
                readonly pinned: "dds__table__col--pinned-start";
            };
            readonly end: {
                readonly anchor: "dds__table__col--pinned-end-anchor";
                readonly pinned: "dds__table__col--pinned-end";
            };
        };
    };
    readonly cell: "dds__table__cell";
    readonly tableDynamicCol: "dds__dynamic-col";
    readonly kind: {
        readonly grid: "";
        readonly horizontal: "dds__table--horizontal";
        readonly "horizontal-alternating": "dds__table--horizontal-alternating";
        readonly "grid-alternating": "dds__table--grid-alternating";
        readonly freeform: "dds__table--freeform";
        readonly "freeform-alternating": "dds__table--freeform-alternating";
    };
    readonly density: {
        readonly comfy: "dds__table--comfy";
        readonly compact: "dds__table--compact";
        readonly subcompact: "dds__table--subcompact";
    };
    readonly stickyHeader: "dds__table--sticky-header";
};
