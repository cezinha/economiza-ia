import { DSFilter } from "../../js/data-source/filter";
import type { SortTypes } from "../../js/data-source/sort/sort.types";
import { PluralRules } from "../../js/utilities/plural-rules";
import type { DeepReadonly } from "../../types/deepreadonly";
export interface Props {
    columnFilter?: boolean;
    columns: Columns;
    data?: Data;
    dataSource?: DataSource;
    density?: Density;
    externalFilterParams?: ExternalFilterParams;
    pagination?: Pagination;
    pinnable?: boolean;
    pin?: Pin;
    search?: boolean;
    searchParams?: SearchParams;
    subscribe?: string[];
    noRows?: NoRows;
    expandableRows?: boolean;
    selectableRows?: boolean;
    autoCollapseSelectedRow?: boolean;
    locale?: string;
    role?: Role;
    localization?: Localization;
    loading?: boolean;
    bulkActions?: Array<BulkActionParams>;
    showHideColumns?: boolean;
    /** @deprecated use localization.ariaRows instead */
    ariaRows?: string;
}
export type Kind = "grid" | "horizontal" | "horizontal-alternating" | "grid-alternating" | "freeform" | "freeform-alternating";
export declare const kind: DeepReadonly<Record<Kind, Kind>>;
export type Density = "default" | "comfy" | "compact" | "subcompact";
export declare const density: DeepReadonly<Record<Density, Density>>;
export type Role = "grid" | "table";
export declare const role: DeepReadonly<Record<Role, Role>>;
/**
 * Data pattern for the table render the data. Should be the new schema (TableRow)
 * or an Array containing the old schema (Array<TableRowData>).
 */
export type Data = DataSchema | DataSchemaLegacy;
/**
 * The schema for row joining the old schema (Array<TableCell | TableCellValue>)
 * with the new schema (TableRow).
 */
export type DataSchema = Array<DataRow>;
export type DataSchemaLegacy = Array<DataRowLegacy>;
export type RowId = string | number;
/**
 * The new row schema for the table. If provided the old format,
 * internally the table will convert the schema to the new one below.
 */
export interface DataRow {
    id?: RowId;
    columns: Array<DataCell>;
    selectable?: boolean;
    expandable?: boolean;
    expandableContent?: string | HTMLElement | ((props: DataRowExpandableContent) => DataRowExpandableContentCallback);
}
export type DataRowLegacy = Array<DataCell | DataCellValue>;
export interface DataRowExpandableContent {
    element: HTMLElement;
    values: Array<DataCell>;
}
export type DataRowExpandableContentCallback = void | (() => void);
/**
 * Base interface for the cell value. Used on the scenario where
 * the user specify the schema with the value as the column data
 * for the current row.
 *
 * Example: const data: TableCell[] = [{ value: 1 }, { value: 'b' }];
 */
export interface DataCell {
    value: DataCellValue;
}
/**
 * This type is the input value the table cell supports.
 * Can be used like: const columns: TableCellValue[] = ['a', 2, true];
 */
export type DataCellValue = string | number | boolean | null | undefined;
export interface DataSource {
    fetchData: (state: any) => any;
}
export interface ExternalFilterParams {
    value: DSFilter;
}
export interface Pin {
    pinLabel?: string;
    unpinLabel?: string;
    startColumn?: number;
}
export interface Pagination {
    rowsPerPage: number;
    currentPage: number;
    topics?: any;
}
export interface NoRows {
    title: string;
    description: string;
    render?: (element: HTMLElement) => void;
}
export interface Localization {
    ariaLoading?: string;
    ariaRows?: string;
    bulkActionsMoreMenuLabel?: string;
    collapseRow?: string;
    columnFilterAriaLabel?: string;
    columnFilterClearAriaLabel?: string;
    expandRow?: string;
    searchPlaceholder?: string;
    pinColumn?: string;
    unpinColumn?: string;
    selectAllLabel?: string;
    selectedRowsTagLabel?: PluralRules;
    selectedRowsTagDismissAriaLabel?: string;
    selectableCheckboxLabelSelect?: string;
    featureNameColumnFilter?: string;
    featureNamePin?: string;
    featureNameSearch?: string;
    featureNameSort?: string;
    showHideColumnsShowingColumns?: string;
    showHideColumnsRibbonButtonLabel?: string;
    showHideColumnsDrawerTitle?: string;
    showHideColumnsDrawerDescription?: string;
    showHideColumnsDrawerInputPlaceholder?: string;
    showHideColumnsDrawerNoColumnsFoundTitle?: string;
    showHideColumnsDrawerNoColumnsFoundDescription?: string;
    showHideColumnsDrawerInfoMessage?: string;
    showHideColumnsDrawerInfoMessageConjunction?: string;
    showHideColumnsDrawerErrorNoColumnsSelected?: string;
    showHideColumnsDrawerApplyButtonLabel?: string;
    showHideColumnsDrawerCancelButtonLabel?: string;
    srLoadingLabel?: string;
    /** Deprecated session */
    /** @deprecated see https://confluence.dell.com/display/DDSYS/%5BARD%5D+Table+-+Sort */
    changeSort?: string;
    /** @deprecated see https://confluence.dell.com/display/DDSYS/%5BARD%5D+Table+-+column+filter */
    columnFilterClearButtonAvailable?: string;
    /** @deprecated see https://confluence.dell.com/display/DDSYS/%5BARD%5D+Table+-+column+filter */
    columnFilterClearButtonHidden?: string;
    /** @deprecated now use just selectAllLabel instead */
    deselectAllLabel?: string;
    /** @deprecated now use just selectableCheckboxLabelSelect instead */
    selectableCheckboxLabelDeselect?: string;
}
export interface SearchParams {
    value: string;
}
export type Columns = Array<Column>;
export interface Column {
    id?: number | string;
    filter?: boolean;
    filterParams?: ColumnFilterParams;
    value: string;
    visible?: boolean;
    align?: ColumnAlign;
    sortBy?: SortTypes | null;
    sortLabels?: ColumnSortLabels;
    minWidth?: number | null;
    width?: number | null;
    maxWidth?: number | null;
    fit?: boolean;
    pinParams?: PinParams;
    sortCallback?: ColumnSortCallback;
    render?: (element: HTMLElement, cellData: DataCell, columnData: Partial<Column>, rowData: DataRow) => (() => void) | void;
}
export type ColumnAlign = "start" | "end";
export declare const columnAlign: DeepReadonly<Record<ColumnAlign, ColumnAlign>>;
export type ColumnSortLabels = {
    unsorted: string;
    ascending: string;
    descending: string;
};
export type ColumnSortCallback = (index: number, sortType: SortTypes, collator: Intl.Collator) => (a: any, b: any) => number;
export interface ColumnFilterParams {
    value: string;
}
export type PinDirection = "start" | "end";
export declare const pinDirection: DeepReadonly<Record<PinDirection, PinDirection>>;
export interface PinParams {
    direction?: PinDirection;
}
export type BulkActionCallbackParams<TableInstance> = {
    selectedRows: Array<DataRow>;
    tableInstance: TableInstance;
};
export interface BulkActionParams<TableInstance = any> {
    id: string;
    content: string;
    inactive?: boolean;
    insideMoreMenu?: boolean;
    action: (params: BulkActionCallbackParams<TableInstance>) => void;
}
export interface PinState {
    start: undefined | string | number;
    end: undefined | string | number;
}
