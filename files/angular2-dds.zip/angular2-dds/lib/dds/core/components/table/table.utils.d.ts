import { DSFilter } from "../../js/data-source/filter";
import { Logger } from "../../js/logger/logger";
import { Columns, Data, DataSchema, PinParams, PinState } from "./table.types";
/**
 * Loop through data object to manage all different of data types
 * allowed to to TableProps.data and return a list of TableRow
 * which is the latest and preferred format to be used
 */
export declare const normalizeData: (data: Data) => DataSchema;
/**
 * Decorates the columns to always have a default value to be used
 * NOTE: Currently being used by angular to merge the defaultColumnProps on the user input columns
 * In vanilla this is done inside of the head cells where this information is needed column by column
 */
export declare const normalizeColumns: (columns: Columns) => Columns;
/**
 * Function that returns the index of the last pinable column at runtime (Only pin start can be changed at runtime), so we can add action menu only for those columns.
 * Note: Since pin end is only set programmatically, it has precedence over pin start.
 * Context: In our table we have a definition that at least 2 columns should not be pinned.
 *  - Example 1: If your table have 5 columns (index 0-4), the first 3 columns (index 0-2) will be pinnable to start in runtime.
 *  - Example 2: If your table have 5 columns (index 0-4), the last column is pinned end (index 4), only the first 2 columns (index 0-1) will be pinnable to start in runtime.
 */
export declare const getPinStartLimit: (columns: {
    id: string | number;
}[], pinState: PinState) => number | undefined;
/**
 * Function that returns the pin state from the columns object
 * NOTE: Angular logger works as a service, that means it doesn't use the same logger imported here, this is the reason we are accepting logger as a parameter
 */
export declare const getPinState: (columns: {
    id: string | number;
    pinParams?: PinParams;
}[], logger?: Logger) => PinState;
/**
 * Combines the external, column and search DSFilters into a single DSFilter instance, folllowing the order of precedence (external > column > search)
 * The search filter will always be added as the last item of the resulting DSFilter because it contains multiple OR conditions
 * @param externalFilter
 * @param columnFilter
 * @param searchFilter
 * @returns DSFilter | undefined
 */
export declare const combineFilters: ({ externalFilter, columnFilter, searchFilter, }: {
    externalFilter?: DSFilter | undefined;
    columnFilter?: DSFilter | undefined;
    searchFilter?: DSFilter | undefined;
}) => DSFilter | undefined;
