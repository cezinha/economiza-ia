export declare const componentName = "TabItem";
export declare const componentClasses: {
    readonly icon: "dds__tabs__tab__icon";
    readonly badge: "dds__tabs__tab__badge";
    readonly iconStart: "dds__tabs__tab__icon--start";
    readonly iconEnd: "dds__tabs__tab__icon--end";
    readonly image: "dds__tabs__tab__image";
    readonly label: "dds__tabs__tab__label";
    readonly mobileStackedChevron: "dds__tabs__tab__chevron";
};
