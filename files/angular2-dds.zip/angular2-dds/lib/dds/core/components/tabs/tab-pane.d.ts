export declare const componentName = "TabPane";
export declare const componentClasses: {
    readonly header: "dds__tabs__pane__header";
    readonly content: "dds__tabs__pane__content";
    readonly bodyOverflow: "dds__tabs__pane--body-overflow";
};
