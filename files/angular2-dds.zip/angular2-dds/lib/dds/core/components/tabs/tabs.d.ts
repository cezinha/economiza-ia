import { Localization } from "./tabs.types";
export declare const componentName = "Tabs";
export declare const base = "dds__tabs";
export declare const orientations: {
    readonly horizontal: "horizontal";
    readonly vertical: "vertical";
};
export declare const iconPlacements: {
    readonly end: "end";
    readonly start: "start";
};
export declare const kinds: {
    readonly global: "global";
    readonly contained: "contained";
};
export declare const mobiles: {
    readonly stacked: "stacked";
    readonly justified: "justified";
    readonly globalDefault: "";
};
export declare const defaultProps: {
    readonly moreLabel: "More";
    readonly backLabel: undefined;
    readonly closeOnMoreItemClick: true;
    readonly tabItemWidthBuffer: 0;
    readonly showMoreButton: undefined;
};
export declare const defaultLocalization: Localization;
export declare const componentClasses: {
    readonly wrapper: "dds__tabs";
    readonly wrapperSm: "dds__tabs--sm";
    readonly wrapperContained: "dds__tabs--contained";
    readonly wrapperMobileStacked: "dds__tabs--mobile-stacked";
    readonly wrapperIcons: "dds__tabs--with-icons";
    readonly wrapperBadges: "dds__tabs--with-badges";
    readonly wrapperMobileJustified: "dds__tabs--mobile-justified";
    readonly wrapperVertical: "dds__tabs--vertical";
    readonly wrapperIsPressing: "dds__tabs--is-pressing";
    readonly list: "dds__tabs__list";
    readonly listOverflow: "dds__tabs__list--overflow";
    readonly listContainer: "dds__tabs__list-container";
    readonly listContainerHiddenGradient: "dds__tabs__list-container--hidden-gradient";
    readonly badge: "dds__tabs__badge";
    readonly tab: "dds__tabs__tab";
    readonly tabLabel: "dds__tabs__tab__label";
    readonly tabIcon: "dds__tabs__tab__icon";
    readonly tabWithImage: "dds__tabs__tab--with-image";
    readonly tabHidden: "dds__tabs__tab--hidden";
    readonly tabsPane: "dds__tabs__tabs__pane";
    readonly tabsPaneHeader: "dds__tabs__tabs__pane__header";
    readonly icon: "dds__tabs__icon";
    readonly iconEnd: "dds__tabs__icon--end";
    readonly more: "dds__tabs__more";
    readonly moreIcon: "dds__tabs__more__icon";
    readonly moreWrapper: "dds__tabs__more-wrapper";
    readonly moreContainer: "dds__tabs__more-wrapper__container";
    readonly moreContainerPositioning: "dds__tabs__more-wrapper__container--positioning";
    readonly moreList: "dds__tabs__more-list";
    readonly moreListItem: "dds__tabs__more-list__item";
    readonly moreListItemHidden: "dds__tabs__more-list__item--hidden";
    readonly moreListItemIcon: "dds__tabs__more-list__item__icon";
    readonly pane: "dds__tabs__pane";
    readonly paneContainer: "dds__tabs__pane-container";
    readonly paneHeader: "dds__tabs__pane__header";
    readonly paneChevron: "dds__tabs__tab__chevron";
    readonly bodyOverflow: "dds__tabs--body-overflow";
};
