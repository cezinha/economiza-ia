import { iconPlacements, kinds, orientations, mobiles } from "./tabs";
export type IconPlacement = typeof iconPlacements[keyof typeof iconPlacements];
export type Kind = typeof kinds[keyof typeof kinds];
export type Orientation = typeof orientations[keyof typeof orientations];
export type Mobile = typeof mobiles[keyof typeof mobiles];
export interface Props {
    moreLabel?: string;
    /** @deprecated */
    backLabel?: string;
    closeOnMoreItemClick: boolean;
    tabItemWidthBuffer: number;
    localization?: Localization;
    /** @deprecated */
    showMoreButton?: boolean;
}
export interface Localization {
    moreLabel?: string;
    srBackLabel?: string;
}
