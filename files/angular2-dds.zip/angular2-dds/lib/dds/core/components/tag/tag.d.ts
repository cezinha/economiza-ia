import type { Props } from "./tag.types";
/**
 * @deprecated should be importing from the types file and not tag.ts directly.
 */
export type { Size, Color } from "./tag.types";
export declare const componentName = "Tag";
export declare const sizes: {
    readonly lg: "lg";
    readonly md: "md";
    readonly sm: "sm";
};
/**
 * @deprecated use sizes
 */
export declare const SizeValues: readonly ["lg", "md", "sm"];
export declare const colors: {
    readonly blue: "blue";
    readonly green: "green";
    readonly yellow: "yellow";
    readonly orange: "orange";
    readonly red: "red";
    readonly berry: "berry";
    readonly purple: "purple";
    readonly gray: "gray";
};
/**
 * @deprecated use colors
 */
export declare const ColorValues: readonly ["blue", "green", "yellow", "orange", "red", "berry", "purple", "gray"];
export declare const defaultProps: Props;
export declare const componentClasses: {
    readonly base: "dds__tag";
    readonly colors: {
        readonly blue: "";
        readonly green: "dds__tag--green";
        readonly yellow: "dds__tag--yellow";
        readonly orange: "dds__tag--orange";
        readonly red: "dds__tag--red";
        readonly berry: "dds__tag--berry";
        readonly purple: "dds__tag--purple";
        readonly gray: "dds__tag--gray";
    };
    readonly inactive: "dds__tag--inactive";
    readonly sizes: {
        readonly lg: "";
        readonly md: "dds__tag--md";
        readonly sm: "dds__tag--sm";
    };
    readonly icon: "dds__tag__icon";
    readonly closeButton: "dds__tag__close-button";
    readonly closeButtonIcon: "dds__tag__close-button__icon";
};
