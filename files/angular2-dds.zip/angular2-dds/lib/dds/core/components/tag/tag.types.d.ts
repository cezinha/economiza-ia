import { sizes, colors } from "./tag";
export interface Props {
    dismiss?: boolean;
    srDismiss?: string;
}
export type Size = typeof sizes[keyof typeof sizes];
export type Color = typeof colors[keyof typeof colors];
