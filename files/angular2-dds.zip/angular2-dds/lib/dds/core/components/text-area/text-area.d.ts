import { Localization } from "./text-area.types";
/**
 * Note: The maxlength property is now deprecated. It was passed in as a prop of a sub component
 * instead of being on the wrapper. It was also confusing because there is an html maxlength
 * property as well. These two were confusing customers so we've just deprecated maxlength as a dds
 * property for this component, the html version can be used no problem. Instead to set a max on the
 * counter, set it by using the counterMax.
 *
 * Note: the maxCounterLength property was not used externally, but internally. We are not clear if
 * this propagated through so we are deprecating it in favor of a standard "counterMax".
 *
 * Note: the localization property in Vanilla is defined internally, as Vanilla uses {remaining} instead of $remaining syntax.
 */
export declare const componentName = "TextArea";
export declare const sizes: {
    readonly sm: "sm";
    readonly lg: "lg";
};
export declare const defaultLocalization: Localization;
export declare const defaultProps: {
    readonly counter: true;
    readonly counterMax: 140;
    readonly localization: Localization;
    readonly srLabel: undefined;
    readonly maxlength: undefined;
    readonly maxCounterLength: undefined;
};
export declare const deprecatedProps: {
    readonly maxlength: "counterMax";
    readonly maxCounterLength: "counterMax";
    readonly srLabel: "localization.srRemaining";
};
export declare const componentClasses: {
    readonly basic: "dds__text-area";
    readonly wrapper: "dds__text-area__wrapper";
    readonly counter: "dds__text-area__counter";
    readonly counterCurrent: "dds__current-value";
    readonly validated: "dds__text-area--validated";
    readonly sr: "dds__text-area__sr";
    readonly errorText: "dds__invalid-feedback";
    readonly error: "dds__error";
    readonly errorIcon: "dds__input-text__icon--end";
    readonly header: "dds__text-area__header";
    readonly helper: "dds__input-text__helper";
    readonly isInvalid: "dds__is--invalid";
    readonly container: {
        readonly base: "dds__text-area__container";
        readonly sm: "dds__text-area__container--sm";
    };
};
