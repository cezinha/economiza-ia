import { sizes } from "./text-area";
export type Size = keyof typeof sizes;
export interface Localization {
    srExceeding?: string;
    srRemaining?: string;
}
