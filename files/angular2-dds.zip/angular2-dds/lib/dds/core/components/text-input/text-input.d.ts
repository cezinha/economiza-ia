export declare const componentName = "Text Input";
export declare const sizes: {
    readonly sm: "sm";
    readonly lg: "lg";
};
export declare const inputTypes: {
    readonly text: "text";
    readonly url: "url";
    readonly email: "email";
    readonly password: "password";
    readonly search: "search";
    readonly tel: "tel";
};
export declare const componentClasses: {
    readonly size: {
        readonly lg: "";
        readonly sm: "dds__input-text__container--sm";
    };
    readonly icon: {
        readonly start: "dds__input-text__icon--start";
        readonly end: "dds__input-text__icon--end";
    };
    readonly isInvalid: "dds__is--invalid";
    readonly errorIcon: "dds__field__icon--invalid";
    readonly container: "dds__input-text__container";
    readonly wrapper: "dds__input-text__wrapper";
    readonly control: "dds__input-text";
    readonly hasIcon: "dds__has__icon--start";
    readonly helperText: "dds__input-text__helper";
    readonly errorText: "dds__invalid-feedback";
    readonly withButton: "dds__input-text__wrapper--button";
};
