import { inputTypes, sizes } from "./text-input";
export type Size = keyof typeof sizes;
export type InputType = keyof typeof inputTypes;
