import type { DeepReadonly } from "../../types/deepreadonly";
import type { Props, Localization } from "./time-picker.types";
export declare const componentName = "TimePicker";
export declare const sizes: {
    readonly sm: "sm";
    readonly lg: "lg";
};
export declare const defaultLocalization: Localization;
export declare const defaultProps: DeepReadonly<Props>;
export declare const componentClasses: {
    readonly base: "dds__time-picker";
    readonly sizes: {
        readonly sm: "dds__time-picker--sm";
        readonly lg: "";
    };
    readonly invalid: "dds__time-picker--invalid";
    readonly invalidFeedback: "dds__time-picker__invalid-feedback";
    readonly input: {
        readonly container: "dds__time-picker__input-container";
        readonly wrapper: "dds__time-picker__input-wrapper";
        readonly field: "dds__time-picker__input";
    };
    readonly iconsWrapper: "dds__time-picker__icons-wrapper";
    readonly chevron: "dds__time-picker__chevron";
    readonly errorIcon: "dds__time-picker__error__icon";
    readonly popup: {
        readonly base: "dds__time-picker__popup";
        readonly hidden: "dds__time-picker__popup--hidden";
    };
    readonly list: "dds__time-picker__list";
    readonly listItem: "dds__time-picker__list-item";
    readonly listItemLabel: "dds__time-picker__list-item-label";
    readonly listItemHighlighted: "dds__time-picker__list-item--highlighted";
    readonly listItemSelected: "dds__time-picker__list-item--selected";
    readonly selectedIcon: "dds__time-picker__selected__icon";
};
