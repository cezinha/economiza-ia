import { sizes } from "./time-picker";
export type Size = keyof typeof sizes;
export type Meridiem = string;
export type Format = 12 | 24;
export type Interval = 15 | 30 | 45 | 60;
export type TimeString = string;
export interface TimeSchema {
    hour?: number;
    minute?: number;
    totalMilliseconds?: number;
    timeFormat: Format;
    meridiem?: Meridiem;
    time?: TimeString;
}
interface BaseTimeRange<T> {
    start: T;
    end: T;
}
export type TimeRange = BaseTimeRange<TimeString | TimeSchema>;
export interface Props {
    timeFormat?: Format;
    interval?: Interval;
    allowFreeTimeChoice?: boolean;
    required?: boolean;
    inactive?: boolean;
    closeOnScroll?: boolean;
    availableTimes?: Array<TimeRange | TimeString>;
    localization?: Localization;
    leadingZero?: boolean;
    appendTo?: HTMLElement;
}
export interface Localization {
    srUpdatedTimeText?: string;
    am?: string;
    pm?: string;
}
export {};
