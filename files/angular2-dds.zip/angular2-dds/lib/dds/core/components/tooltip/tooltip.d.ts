export declare const componentName = "Tooltip";
export declare const showTooltipDelay = 500;
export declare const maxContentWidth = 220;
export declare const placements: {
    readonly topStart: "top-start";
    readonly top: "top";
    readonly topEnd: "top-end";
    readonly rightStart: "right-start";
    readonly right: "right";
    readonly rightEnd: "right-end";
    readonly bottomStart: "bottom-start";
    readonly bottom: "bottom";
    readonly bottomEnd: "bottom-end";
    readonly leftStart: "left-start";
    readonly left: "left";
    readonly leftEnd: "left-end";
};
export declare const componentClasses: {
    readonly tooltip: "dds__tooltip";
    readonly tooltipMaxContent: "dds__tooltip--max-content";
    readonly show: "dds__tooltip--show";
    readonly body: "dds__tooltip__body";
    readonly bodyNoTitle: "dds__tooltip__body--no-title";
    readonly title: "dds__tooltip__title";
    readonly animating: "dds__tooltip--animating";
    readonly dismiss: "dds__tooltip__dismiss";
    readonly pointer: "dds__tooltip__pointer";
};
