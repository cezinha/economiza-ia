import type { Localization } from "./view-more-less.types";
export declare const componentName = "MoreLess";
export declare const kinds: {
    readonly inline: "inline";
    readonly block: "block";
};
export declare const defaultLocalization: Localization;
export declare const componentClasses: {
    readonly base: "dds__more-less";
    readonly kind: {
        readonly list: "dds__more-less--list";
        readonly inline: "dds__more-less--inline";
    };
    readonly target: "dds__more-less__target";
    readonly styleExpanded: "dds__more-less__target--show";
    readonly styleButton: "dds__more-less__button";
    readonly styleTarget: "dds__more-less__target";
    readonly icon: "dds__more-less__icon";
    readonly button: "dds__more-less__button";
    readonly buttonStandalone: "dds__more-less__button--standalone";
    readonly moreButton: "dds__more-less__button--more";
    readonly lessButton: "dds__more-less__button--less";
    readonly ellipsis: "dds__more-less__ellipsis";
    readonly noFocusOutline: "dds__more-less--hidden-focus-outline";
};
