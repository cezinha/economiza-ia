import { kinds } from "./view-more-less";
export type Kind = typeof kinds[keyof typeof kinds];
export interface Localization {
    viewMore: string;
    viewLess: string;
    srViewMore?: string;
    srViewLess?: string;
}
