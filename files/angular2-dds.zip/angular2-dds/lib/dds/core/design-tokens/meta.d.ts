export const ddsSpace: "dds";
export const ddsToken: "__";
export const fontVersion: "2.137.1";
export const iconVersion: "2.9.2";
export const prefix: "dds__";
export const iconPrefix: "dds__icon--";
export const userIsTabbing: "user-is-tabbing";
