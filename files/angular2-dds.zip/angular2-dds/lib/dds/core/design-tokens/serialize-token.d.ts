/**
 * Creates function for handling CSS or JS output
 *
 * @param value String default string
 * @param append String the value to append
 *
 * @return Function This
 *
 * @example
 * const red = token("red")
 * red(); // "red"
 * red(true) // "red !default;";
 * red(); // "red"
 * red(true, "!important;") // "red !important;";
 */
export default function serializeToken(value: any, append: any): any;
