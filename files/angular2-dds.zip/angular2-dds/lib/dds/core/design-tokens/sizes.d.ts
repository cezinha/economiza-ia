export const breakpoints: {
    "breakpoints-xs": any;
    "breakpoints-sm": any;
    "breakpoints-md": any;
    "breakpoints-lg": any;
    "breakpoints-xl": any;
    "breakpoints-2xl": any;
    "breakpoints-3xl": any;
    "breakpoints-4xl": any;
    "breakpoints-5xl": any;
};
export const gridColumns: {
    "grid-columns-xs": any;
    "grid-columns-sm": any;
    "grid-columns-md": any;
    "grid-columns-lg": any;
    "grid-columns-xl": any;
    "grid-columns-2xl": any;
    "grid-columns-3xl": any;
    "grid-columns-4xl": any;
    "grid-columns-5xl": any;
};
export const gridGutterCompact: {
    "grid-gutter-compact-xs": any;
    "grid-gutter-compact-sm": any;
    "grid-gutter-compact-md": any;
    "grid-gutter-compact-lg": any;
    "grid-gutter-compact-xl": any;
    "grid-gutter-compact-2xl": any;
    "grid-gutter-compact-3xl": any;
    "grid-gutter-compact-4xl": any;
    "grid-gutter-compact-5xl": any;
};
export const gridGutter: {
    "grid-gutter-default-xs": any;
    "grid-gutter-default-sm": any;
    "grid-gutter-default-md": any;
    "grid-gutter-default-lg": any;
    "grid-gutter-default-xl": any;
    "grid-gutter-default-2xl": any;
    "grid-gutter-default-3xl": any;
    "grid-gutter-default-4xl": any;
    "grid-gutter-default-5xl": any;
};
export const gridGutterComfy: {
    "grid-gutter-comfy-xs": any;
    "grid-gutter-comfy-sm": any;
    "grid-gutter-comfy-md": any;
    "grid-gutter-comfy-lg": any;
    "grid-gutter-comfy-xl": any;
    "grid-gutter-comfy-2xl": any;
    "grid-gutter-comfy-3xl": any;
    "grid-gutter-comfy-4xl": any;
    "grid-gutter-comfy-5xl": any;
};
export const gridMarginsCompact: {
    "grid-margins-compact-xs": any;
    "grid-margins-compact-sm": any;
    "grid-margins-compact-md": any;
    "grid-margins-compact-lg": any;
    "grid-margins-compact-xl": any;
    "grid-margins-compact-2xl": any;
    "grid-margins-compact-3xl": any;
    "grid-margins-compact-4xl": any;
    "grid-margins-compact-5xl": any;
};
export const gridMargins: {
    "grid-margins-default-xs": any;
    "grid-margins-default-sm": any;
    "grid-margins-default-md": any;
    "grid-margins-default-lg": any;
    "grid-margins-default-xl": any;
    "grid-margins-default-2xl": any;
    "grid-margins-default-3xl": any;
    "grid-margins-default-4xl": any;
    "grid-margins-default-5xl": any;
};
export const gridMarginsComfy: {
    "grid-margins-comfy-xs": any;
    "grid-margins-comfy-sm": any;
    "grid-margins-comfy-md": any;
    "grid-margins-comfy-lg": any;
    "grid-margins-comfy-xl": any;
    "grid-margins-comfy-2xl": any;
    "grid-margins-comfy-3xl": any;
    "grid-margins-comfy-4xl": any;
    "grid-margins-comfy-5xl": any;
};
