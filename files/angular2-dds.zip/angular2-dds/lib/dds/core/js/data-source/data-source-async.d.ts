import DataSource from "./data-source";
import { DataSourceAsyncProps, GetDataProps } from "./data-source.types";
/**
 * Create a DataSource
 * R stands for a generic row schema
 * C stands for a generic column schema
 * DataSource will have its own schema extending from the generic ones
 * this gives the implementer intelissend of both schemas
 * @param {DataSourceAsyncProps<R, C>} props
 * @returns {DataSourceAsync}
 */
export default class DataSourceAsync<R, C> extends DataSource<R, C> {
    protected _fetchData: DataSourceAsyncProps<R, C>["fetchData"];
    protected _currentPromise?: CancellablePromise;
    constructor(props: DataSourceAsyncProps<R, C>);
    get data(): never[];
    set data(data: never[]);
    getData: ({ currentPage, pageSize, fetchData, }: GetDataProps) => Promise<DataSourceAsyncProps<R, C>["data"]>;
}
type CancellablePromise = Promise<any> & {
    __completed: boolean;
    __cancelled: boolean;
    cancel: () => void;
};
export {};
