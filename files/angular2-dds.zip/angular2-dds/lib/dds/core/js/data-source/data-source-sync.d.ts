import DataSource from "./data-source";
import { DataSourceProps, DataSourceSyncProps, GetDataProps } from "./data-source.types";
/**
 * Create a DataSource
 * R stands for a generic row schema
 * C stands for a generic column schema
 * DataSource will have its own schema extending from the generic ones
 * this gives the implementer intelissend of both schemas
 * @param {DataSourceSyncProps<R, C>} props
 * @returns {DataSourceSync}
 */
export default class DataSourceSync<R, C> extends DataSource<R, C> {
    protected _computedData: DataSourceSyncProps<R, C>["data"];
    constructor(props: DataSourceSyncProps<R, C>);
    get data(): DataSourceSyncProps<R, C>["data"];
    set data(data: DataSourceSyncProps<R, C>["data"]);
    get filter(): DataSourceProps<R, C>["filter"];
    set filter(filter: DataSourceSyncProps<R, C>["filter"]);
    set sort(sort: DataSourceSyncProps<R, C>["sort"]);
    get computedData(): DataSourceSyncProps<R, C>["data"];
    private setComputedData;
    getData: ({ currentPage, pageSize, }: GetDataProps) => Promise<DataSourceSyncProps<R, C>["data"]>;
}
