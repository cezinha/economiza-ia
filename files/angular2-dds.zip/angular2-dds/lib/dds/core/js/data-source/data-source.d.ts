import { Column, DataSourceProps, GetDataProps } from "./data-source.types";
import { DSFilter } from "./filter/filter";
/**
 * Create a DataSource
 * R stands for a generic row schema
 * C stands for a generic column schema
 * DataSource will have its own schema extending from the generic ones
 * this gives the implementer intelissend of both schemas
 * @param {DataSourceProps<R, C>} props
 * @returns {DataSource}
 */
declare class DataSource<R, C> {
    protected _data: DataSourceProps<R, C>["data"];
    protected _totalItems: DataSourceProps<R, C>["totalItems"];
    protected _columns: DataSourceProps<R, C>["columns"];
    protected _sort: DataSourceProps<R, C>["sort"];
    protected _filter: DataSourceProps<R, C>["filter"];
    protected _filters: DataSourceProps<R, C>["filters"];
    protected _search: DataSourceProps<R, C>["search"];
    protected _collator: DataSourceProps<R, C>["collator"];
    constructor(props: DataSourceProps<R, C>);
    get data(): DataSourceProps<R, C>["data"];
    set data(data: DataSourceProps<R, C>["data"]);
    get totalItems(): number;
    set totalItems(totalItems: number);
    get columns(): DataSourceProps<R, C>["columns"];
    set columns(columns: DataSourceProps<R, C>["columns"]);
    get filter(): DataSourceProps<R, C>["filter"];
    set filter(filter: DataSourceProps<R, C>["filter"]);
    get filters(): DataSourceProps<R, C>["filters"];
    set filters(filters: DataSourceProps<R, C>["filters"]);
    get search(): DataSourceProps<R, C>["search"];
    set search(search: DataSourceProps<R, C>["search"]);
    get sort(): DataSourceProps<R, C>["sort"];
    set sort(sort: DataSourceProps<R, C>["sort"]);
    getData: (props: GetDataProps) => Promise<DataSourceProps<R, C>["data"]>;
    hasColumn: (id: Column["id"]) => (Column & C) | undefined;
    getColumn: (id: Column["id"]) => (Column & C) | undefined;
    getColumnIndex: (id: Column["id"]) => number;
    getRow: (key: string | symbol, value: any) => (import("./data-source.types").Row & R) | undefined;
    DSFilter: typeof DSFilter;
}
export default DataSource;
