import { DSFilter } from "./filter/filter";
import { SortTypes } from "./sort/sort.types";
/**
 * R stands for a generic row schema
 * C stands for a generic column schema
 * DataSource will have its own schema extending from the generic ones
 * this gives the implementer intelissend of both schemas
 */
export type DataSourceProps<R, C> = {
    collator?: Intl.Collator;
    columns: Columns<C>;
    data: Data<R>;
    filter?: DSFilter;
    filters?: ColumnFilter[];
    search?: string;
    sort?: Sort;
    totalItems: number;
};
export type DataSourceSyncProps<R, C> = DataSourceProps<R, C>;
export type Data<R> = Array<Row & R>;
export type Columns<C> = Array<Column & C>;
export interface Row {
    columns: Array<{
        value: any;
    }>;
}
export interface Column {
    id: string | number;
    value: any;
    sortCallback?: SortCallback;
}
export type GetDataProps = {
    currentPage: number;
    pageSize: number;
    fetchData?: (state: FetchDataState) => void;
};
export interface Sort {
    columnId: Column["id"];
    sortBy: SortTypes;
}
export interface ColumnFilter {
    columnId: Column["id"];
    value: string | number;
}
export type SortCallback = (columnIndex: number, sortBy: SortTypes, collator: Intl.Collator) => (a: any, b: any) => number;
export type DataSourceAsyncProps<R, C> = DataSourceProps<R, C> & {
    fetchData: (state: FetchDataState) => void;
};
export interface FetchDataState {
    currentPage: number;
    pageSize: number;
    sort?: Sort;
    filter?: DSFilter;
    filters?: ColumnFilter[];
    search?: string;
}
