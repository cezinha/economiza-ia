import { DeepReadonly } from "../../../types/deepreadonly";
import { Column, Columns, Data, Row } from "../data-source.types";
declare const _dsFilterMatchers: {
    includes: string;
};
export declare const dsFilterMatchers: DeepReadonly<typeof _dsFilterMatchers>;
export declare const dsFilterMatchersValues: any[];
export type DSFilterMatchers = typeof dsFilterMatchersValues[number];
declare const _dsFilterOperators: {
    and: string;
    or: string;
};
export declare const dsFilterOperators: DeepReadonly<typeof _dsFilterOperators>;
export declare const dsFilterOperatorsValues: any[];
export type DSFilterOperators = typeof dsFilterOperatorsValues[number];
declare const _dsFilterTypes: {
    match: string;
    operator: string;
};
export declare const dsFilterTypes: DeepReadonly<typeof _dsFilterTypes>;
export declare const dsFilterTypesValues: any[];
export type DSFilterTypes = typeof dsFilterTypesValues[number];
export interface DSFilterRuleSchema {
    columnId: Column["id"];
    matcher: DSFilterMatchers | ((value1: any, value2: any) => void);
    value?: any;
}
export interface DSFilterMatchSchema {
    type: DSFilterTypes;
    rule: DSFilterRuleSchema;
}
export interface DSFilterOperatorSchema {
    type: DSFilterTypes;
    operator: DSFilterOperators;
    rules: DSFilterSchema;
}
export type DSFilterSchema = Array<DSFilterMatchSchema | DSFilterOperatorSchema>;
export declare const className = "DSFilter";
export declare class DSFilter {
    _filterSchema: DSFilterSchema;
    _rule: DSFilterRuleSchema;
    constructor(columnId: DSFilterRuleSchema["columnId"], matcher: DSFilterRuleSchema["matcher"], value: DSFilterRuleSchema["value"]);
    get filterSchema(): DSFilterSchema;
    set filterSchema(filterSchema: DSFilterSchema);
    static match(columnId: DSFilterRuleSchema["columnId"], matcher: DSFilterRuleSchema["matcher"], value: DSFilterRuleSchema["value"]): DSFilter;
    static includes(columnId: DSFilterRuleSchema["columnId"], value: DSFilterRuleSchema["value"]): DSFilter;
    and: (filter: DSFilter) => this;
    or: (filter: DSFilter) => this;
    clone: () => DSFilter;
}
export declare const dsFilterResolve: <GenericRowSchema, GenericColumnSchema>(data: Data<GenericRowSchema>, columns: Columns<GenericColumnSchema>, filter: DSFilter) => Data<GenericRowSchema>;
export declare const dsFilterResolveRow: <GenericColumnSchema>(row: Row, columns: Columns<GenericColumnSchema>, filterSchema: DSFilterSchema) => any;
export declare const dsFilterResolveRule: <GenericColumnSchema>(row: Row, columns: Columns<GenericColumnSchema>, rule: DSFilterRuleSchema) => any;
export {};
