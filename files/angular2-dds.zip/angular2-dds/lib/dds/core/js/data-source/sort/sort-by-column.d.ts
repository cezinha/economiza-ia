/**
 * Designed to be used with Array.sort.
 * It makes asc/desc sorting over lists with objects
 */
export declare const sortByColumn: (index?: number, sortType?: import("./sort.types").SortTypes, collator?: Intl.Collator) => (listA: any, listB: any) => number;
export default sortByColumn;
