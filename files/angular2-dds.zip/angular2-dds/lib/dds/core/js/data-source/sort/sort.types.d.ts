export type SortTypes = "ascending" | "descending" | "unsorted";
export declare const sortTypes: Record<SortTypes, SortTypes>;
