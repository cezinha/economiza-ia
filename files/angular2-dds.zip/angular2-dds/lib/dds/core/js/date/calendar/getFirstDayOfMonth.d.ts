/**
 * Get Date object on the first day of month
 * @param {Date} date
 * @returns {Date}
 */
export declare const getFirstDayOfMonth: (date: any) => Date;
