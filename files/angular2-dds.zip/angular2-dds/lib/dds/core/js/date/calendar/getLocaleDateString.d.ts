/**
 * Error treatment to toLocaleDateString if a wrong locale is informed
 * @param {Date} date
 * @param {String} locale - locale string
 * @param {Object} config - toLocaleDateString config
 * @returns {String}
 */
export declare const getLocaleDateString: (date: any, locale: any, config: any) => string;
