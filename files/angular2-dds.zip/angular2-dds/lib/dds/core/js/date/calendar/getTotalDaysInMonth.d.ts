/**
 * Get total days or month last day
 * @param {Date} date
 * @returns {Number}
 */
export declare const getTotalDaysInMonth: (date: any) => number;
