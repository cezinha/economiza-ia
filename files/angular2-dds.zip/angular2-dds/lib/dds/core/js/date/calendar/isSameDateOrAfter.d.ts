/**
 * Check if date is same or after comparison depending on precision parameter
 * @param {Date} date
 * @param {Date} comparison
 * @param {String} precision - comparisonPrecision type
 * @returns {Boolean}
 */
export declare const isSameDateOrAfter: (date: any, comparison: any, precision?: string) => boolean;
