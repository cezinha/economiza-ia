/**
 * Check if date is same or before comparison depending on precision parameter
 * @param {Date} date
 * @param {Date} comparison
 * @param {String} precision - comparisonPrecision type
 * @returns {Boolean}
 */
export declare const isSameDateOrBefore: (date: any, comparison: any, precision?: string) => boolean;
