export declare const dateFormatChars: {
    YYYY: string;
    MM: string;
    DD: string;
};
export declare const dateFormatCharsRegex: {
    YYYY: RegExp;
    MM: RegExp;
    DD: RegExp;
};
export declare const datePrecision: {
    year: string;
    month: string;
    day: string;
};
export declare const dateParserSpecialCharsRegex: RegExp;
