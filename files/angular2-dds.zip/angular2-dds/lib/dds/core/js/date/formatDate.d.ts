/**
 * Format a date
 * @param {Date} date - Date object
 * @param {String} format - Date format using available dateFormatChars characters
 * @param {Locale} locale - Optional param with the locale, the default is en-US
 * @returns {String}
 */
export declare const formatDate: (date: Date | null, format: string, locale?: string) => string;
