/**
 * Get fullYear, month and day from a date
 * @param {Date} date
 * @returns {Array}
 */
export declare const getDateVariables: (date: any) => any[];
