/**
 * Check if date is after comparison depending on precision parameter
 * @param {Date} date
 * @param {Date} comparison
 * @param {String} precision - comparisonPrecision type
 * @returns {Boolean}
 */
export declare const isDateAfter: (date: any, comparison: any, precision?: string) => boolean;
