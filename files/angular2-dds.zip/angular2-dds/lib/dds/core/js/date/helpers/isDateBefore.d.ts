/**
 * Check if date is before comparison depending on precision parameter
 * @param {Date} date
 * @param {Date} comparison
 * @param {String} precision - comparisonPrecision type
 * @returns {Boolean}
 */
export declare const isDateBefore: (date: any, comparison: any, precision?: string) => boolean;
