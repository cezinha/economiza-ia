/**
 * Check if date and comparison are equals depending on precision parameter
 * @param {Date} date
 * @param {Date} comparison
 * @param {String} precision - comparisonPrecision type
 * @returns {Boolean}
 */
export declare const isSameDate: (date: any, comparison: any, precision?: string) => boolean;
