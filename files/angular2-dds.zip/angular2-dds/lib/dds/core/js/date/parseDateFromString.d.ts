export type dateParserErrors = null | "invalidDateErrorMessage" | "dateParserLetterError" | "dateParserNoSeparatorErrorMessage" | "dateParserPredictiveParserErrorMessage" | "dateParserInvalidLengthErrorMessage" | "dateParserInvalidMonthErrorMessage" | "dateParserInvalidDayErrorMessage";
export type dateParserReturn = {
    date: Date | null;
    error: dateParserErrors;
};
/**
 * This function is used to parse a date from a string, it will try to parse the date based on the format provided and the string contents, if it has letters it will try to parse the long date, if not it will try to parse the short date based on the provided format
 * @param {String} value  example: 01/01/2020, 1/1/2020, 01012020, 1-1-2020, 2020.1.1
 * @param {String} format example: "MM-DD-YYYY", "D/M/YYYY"
 * @returns { dateParserReturn }
 */
export declare const parseDateFromString: (value: string, format: string, predictiveParser?: boolean) => dateParserReturn;
