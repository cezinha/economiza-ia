export namespace focusTrapNodeTypes {
    let fallback: string;
    let start: string;
    let end: string;
}
export function createFocusTrapNode({ type }: HTMLElement): HTMLElement;
export function addFocusTrap({ element, fallbackElement, startElement, endElement }: HTMLElement): any;
export function buildFocusTrap(element: HTMLElement): any;
