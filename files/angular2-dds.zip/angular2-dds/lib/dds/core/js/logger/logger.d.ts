export declare const consolePrefix = "[DDS]";
type LogMessage = (logMessage: any, ...args: any) => void;
export interface Logger {
    error: LogMessage;
    info: LogMessage;
    warn: LogMessage;
    table: LogMessage;
    log: LogMessage;
}
export declare const logTypes: {
    readonly log: "log";
    readonly info: "info";
    readonly warn: "warn";
    readonly table: "table";
    readonly error: "error";
};
export declare const logTypesValues: ("log" | "info" | "warn" | "table" | "error")[];
export type LogTypes = typeof logTypesValues[number];
/**
 * Enables the custom logger
 * @param {boolean} enabled
 * @param {types} logTypes
 */
export declare const debug: (enabled: boolean, logTypes?: LogTypes[]) => void;
export declare const logger: Logger;
export {};
