export declare const maskDefinitions: Record<string, RegExp>;
export interface MaskProps {
    mask: string;
}
interface MaskCharBase {
    char: string;
}
interface MaskCharNonPermanent extends MaskCharBase {
    isPermanent: false;
    match: RegExp;
}
interface MaskCharPermanent extends MaskCharBase {
    isPermanent: true;
    match: undefined;
}
export type MaskChar = MaskCharNonPermanent | MaskCharPermanent;
export declare class Mask {
    mask: MaskChar[];
    totalCharsToFill: number;
    constructor({ mask }: MaskProps);
    setMask(mask: string): void;
    getPreviousNonPermanentIndex(caretPosition: number): number;
    getNextNonPermanentIndex(caretPosition: number): number;
    getMaskValue(value: string, lastKeyDown?: string | null, keyDownSelectionStart?: number, keyDownSelectionEnd?: number, onChangeselectionStart?: number): {
        maskedValue: string;
        newCaret: number;
    };
}
export {};
