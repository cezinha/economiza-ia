/**
 * Get the position left/top based on a placement that a target element will be positioned regards a trigger element
 *
 *  * @param {{
 *  trigger: HTMLElement // Trigger Element
 *  target: HTMLElement // Target Element
 *  placement: String // Array containing the order of placements to work as a fallback when flip is active
 *  placementFallback: Array //  Array containing the order of placements to work as a fallback when flip is active
 *  flip: Boolean // Defines when the flip feature is active
 *  adjustToEdge: Boolean // Define if after placement target and pointer will be adjusted to edges of screen if needed
 *  offsets: {x: Number, y: Number} // Define the distance between the trigger and the target in both axes
 *  gutters: {x: Number, y: Number} // Define the distance between the trigger and the target in both axes
 *  pointer: Number // Pointer size in pixels (if 0 the pointer will not be calculated)
 *  pointerOffset: {x: Number, y: Number} // Pointer offset on start/end positions
 *  _document?: Document, // Optional custom document object
 *  _window?: Window // Optional custom window object
 *
 * }} config
 * @returns
 */
export function getPlacement({ trigger, target, placement, placementFallback, flip, offsets, gutters, pointer, pointerOffset, adjustToEdge, _document, _window, }: {
    trigger: HTMLElement;
    target: HTMLElement;
    placement: string;
    placementFallback: any[];
    flip: boolean;
    adjustToEdge: boolean;
    offsets: {
        x: number;
        y: number;
    };
    gutters: {
        x: number;
        y: number;
    };
    pointer: number;
    pointerOffset: {
        x: number;
        y: number;
    };
    _document?: Document;
    _window?: Window;
}): {
    position: {
        left: number;
        top: number;
    };
    pointer: {
        left: number;
        top: number;
    };
    newPlacement: string;
};
export namespace alignments {
    let start: string;
    let end: string;
}
export namespace placements {
    let topStart: string;
    let top: string;
    let topEnd: string;
    let rightStart: string;
    let right: string;
    let rightEnd: string;
    let bottomStart: string;
    let bottom: string;
    let bottomEnd: string;
    let leftStart: string;
    let left: string;
    let leftEnd: string;
}
export const topPlacements: string[];
export const rightPlacements: string[];
export const bottomPlacements: string[];
export const leftPlacements: string[];
export function getPlacementFallback(p: Array<string> | string): Array<string>;
export function getElementOffsetParentContext(element: HTMLElement, context?: {
    inOffsetParent: boolean;
    inOffsetParentScrollable: boolean;
    offsetParent: null | HTMLElement;
    offsetParentList: any[];
    offsetParentScrollable: null | HTMLElement;
}): any;
