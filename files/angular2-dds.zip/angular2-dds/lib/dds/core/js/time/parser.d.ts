import * as TimepickerTypes from "../../components/time-picker/time-picker.types";
import { Time } from "./time";
export declare const timeRegex: RegExp;
/**
 * Formats a Date object into a string time.
 */
export declare function formatTime(time: Time, format: TimepickerTypes.Format, leadingZero?: boolean, localization?: TimepickerTypes.Localization): string;
/**
 * Parses a time string into a Time object.
 * Expects values like:
 * 1, 01, 01:1, 01:01, 0101, 10 am, 10 pm
 * @throws Error when invalid time string is provided
 */
export declare function parseTime(time: string, localization?: TimepickerTypes.Localization): Time;
/**
 * Given a time in string format, parses it into a Time object resolving the possible time shifts.
 */
export declare function resolveTime(time: string, localization?: TimepickerTypes.Localization): Time[];
