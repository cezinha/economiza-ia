/**
 * Create a new Time object based on Date. It is used to avoid date part operations
 */
export declare class Time extends Date {
    /**
     * Builds the time
     */
    constructor(hours?: number, minutes?: number, seconds?: number, milis?: number);
}
/**
 * Defines a time range based on a start and end limits
 */
export type TimeRange = {
    start: Time | string;
    end: Time | string;
};
/**
 * Type which holds an absolute Time or a range specification
 * Absolute time can be a Time object or a string in the format "HH:mm" or "HH:mm am/pm"
 */
export type TimeslotDef = TimeRange | Time | string;
/**
 * Defines the item type for the timeslot list in UI domain as text-value pair
 */
export type TimeslotItem = {
    text: string;
    value: Time;
};
