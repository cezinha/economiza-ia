import type { TimeslotDef, TimeRange } from "./time";
import { Time } from "./time";
/**
 * Parse a list of TimeslotDef into a TimeRange list
 */
export declare const getTimRangeFromTimeSlotDef: (list: TimeslotDef[]) => TimeRange[];
/**
 * Builds a list of timeslots from a list of timeslot definitions.
 * A timeslot is a "portion" of time in a discrete timeline
 * @param defs A list of timeslot definitions
 * @param interval The interval between each timeslot in minutes
 * @returns A list of timeslots
 * @example
 * buildTimeslot([{start: new Date(2020, 0, 1, 12, 0), end: new Date(2020, 0, 1, 13, 0)}], 30)
 * // => [new Date(2020, 0, 1, 12, 0), new Date(2020, 0, 1, 12, 30), new Date(2020, 0, 1, 13, 0)]
 * buildTimeslot([{start: new Date(2020, 0, 1, 12, 0), end: new Date(2020, 0, 1, 13, 0)}], 60)
 * // => [new Date(2020, 0, 1, 12, 0), new Date(2020, 0, 1, 13, 0)]
 * buildTimeslot([{start: new Date(2020, 0, 1, 12, 0), end: new Date(2020, 0, 1, 13, 0)}], 15)
 */
export declare function buildTimeslot(defs: Array<TimeslotDef>, interval: number): Time[];
