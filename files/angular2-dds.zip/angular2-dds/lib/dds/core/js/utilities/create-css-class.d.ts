export function createCSSClass(className: string, style: {
    [x: string]: string;
}): CSSStyleRule;
