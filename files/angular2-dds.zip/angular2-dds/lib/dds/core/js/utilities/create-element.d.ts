interface CreateElementProps {
    class?: any;
    html?: string;
    text?: string;
    children?: Array<any>;
    [prop: string]: any;
}
/**
 * Create DOM element node.
 *
 * @param  {String} nodeType type of node to create.
 * @param  {Object} props properties and attributes to apply to node.
 * @return {HTMLElement} newly created element.
 */
export declare const createElement: (nodeType: any, props?: CreateElementProps, ...children: Array<any>) => any;
export {};
