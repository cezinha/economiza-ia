/**
 * COPIED FROM underscore.js implementation of this function.
 *
 * @important DO NOT MODIFY
 *
 * Returns a function, that, as long as it continues to be invoked, will not be triggered. The
 * function will be called after it stops being called for N milliseconds. If `immediate` is passed,
 * trigger the function on the leading edge, instead of the trailing.
 * @param {function} func
 * @param {number} wait
 * @param {boolean} immediate
 * @returns
 */
export function debounce(func: Function, wait: number, immediate?: boolean): (...args: any[]) => void;
