/**
 * Takes two objects and merges them into 1.
 * Arguments behave like Object.assign()
 * @param {Object} target
 * @param {Object} source
 * @returns {Object}
 */
export declare const deepMerge: <T = any>(target: any, source: any) => T;
