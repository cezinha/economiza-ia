/**
 * Defer the execution of the specified callback after all the calls
 * has been made.
 */
export declare const defer: (callback: () => void) => void;
