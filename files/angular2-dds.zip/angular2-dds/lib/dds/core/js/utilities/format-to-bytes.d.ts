export function formatToBytes(bytes: number, decimals?: number): string;
