export function generateUniqueID(target: string): string;
