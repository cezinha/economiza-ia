export function getFocusableElements(element: any): any[];
