export function isScrollableElement(element: HTMLElement): boolean;
