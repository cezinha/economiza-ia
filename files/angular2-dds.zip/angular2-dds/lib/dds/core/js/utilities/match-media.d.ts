export function smallMediaQueryList(): boolean;
export function mobileMediaQueryList(): boolean;
export function tabletMediaQueryList(): boolean;
export function prefersReducedMotion(): boolean;
