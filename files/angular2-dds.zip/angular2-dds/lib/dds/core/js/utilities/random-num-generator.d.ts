/**
 * Create random number between two values.
 * The maximum is exclusive and the minimum is inclusive.
 * Defaults to 9 digits.
 * @return {Number}
 */
export function randomNumGenerator(min?: number, max?: number): number;
