export declare const replacePlaceholders: (templateString: string, placeholders: string[], replacements: string[]) => string;
