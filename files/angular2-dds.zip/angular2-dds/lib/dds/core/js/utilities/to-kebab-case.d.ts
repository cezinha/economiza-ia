export function toKebabCase(str: string): string;
