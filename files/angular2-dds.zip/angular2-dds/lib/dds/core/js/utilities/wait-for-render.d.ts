export function waitForRender(element: HTMLElement, prop: string, val: string, maxFrames?: number): Promise<any>;
