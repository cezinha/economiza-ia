export declare const matchers: {
    undefined: (value: any) => value is undefined;
    null: (value: any) => value is null;
    false: (value: any) => boolean;
    true: (value: any) => boolean;
    falsy: (value: any) => boolean;
    truthy: (value: any) => boolean;
    number: (value: any) => value is number;
    boolean: (value: any) => value is boolean;
    string: (value: any) => value is string;
    emptyString: (value: any) => boolean;
    function: (fn: any) => fn is Function;
    object: <T = Record<string, any>>(value: any) => value is T;
    date: (value: any) => boolean;
    array: <T_1 = any>(value: any) => value is T_1[];
    regexp: (value: any) => boolean;
    minChars: (value: any) => (value: any) => any;
    htmlElement: (element: any) => element is HTMLElement;
    /**
     * Return if target > expect
     * @param {Number} expect
     * @returns {Boolean}
     */
    gt: (expect: any) => (target: any) => boolean;
    /**
     * Return if target >= expect
     * @param {Number} expect
     * @returns {Boolean}
     */
    gte: (expect: any) => (target: any) => boolean;
    /**
     * Return if target < expect
     * @param {Number} expect
     * @returns {Boolean}
     */
    lt: (expect: any) => (target: any) => boolean;
    /**
     * Return if target <= expect
     * @param {Number} expect
     * @returns {Boolean}
     */
    lte: (expect: any) => (target: any) => boolean;
    /**
     * Test if target === expected
     * @param {*} expect
     * @returns {Boolean}
     */
    eq: (expect: any) => (target: any) => boolean;
    /**
     * Test if target !== expected
     * @param {*} expect
     * @returns {Boolean}
     */
    neq: (expect: any) => (target: any) => boolean;
    /**
     * Return if **value** is in btw startRange and endRange
     * @param {Number} startRange
     * @param {Number} endRange
     * @returns
     */
    inRange: (startRange: any, endRange: any) => (value: any) => boolean;
    /**
     * All arguments must be a function.
     * They will called with **value**
     * All functions must return true to pass.
     * @param  {...any} args list of functions
     * @returns {Boolean}
     */
    and: (...args: any[]) => (value: any) => any;
    /**
     * All arguments must be a function.
     * They will called with **value**
     * At least one of the call must return true to pass
     * @param  {...any} args list of functions
     * @returns {(value: any) => boolean}
     */
    or: (...args: any[]) => (value: any) => any;
    /**
     * The argument must be a function.
     * It will be called with **value**
     * Returns the opposite boolean value from the return value of the function passed in
     * @param {...any} pattern
     * @returns {Boolean}
     */
    not: (func: any) => (value: any) => boolean;
    /**
     * Test if value matches pattern
     * @param {String|RegExp} pattern
     * @returns {(value: any) => Boolean}
     */
    match: (pattern: any) => (value: any) => any;
    /**
     * Test if all values from **list** exists in **refs**
     * refs:[a,b,c] list:[a,b] => true
     * refs:[a,b,c] list: [a,c] =>  false
     * refs:[a,b,c] list: [c] =>  false
     * @param {Array} refs list with expected values
     * @returns Boolean
     */
    includesList: (refs: any) => (list: any) => boolean;
    /**
     * Test if **value** exists in refs (Uses Array includes)
     * @param {Array|String} refs
     * @returns {Function}
     */
    includes: (refs: any) => (value: any) => any;
    /**
     * Return if value is instanceof Instance
     * @param {*} Instance
     * @returns {Boolean}
     */
    instanceof: (Instance: any) => (value: any) => boolean;
};
