/**
 * Recursively type nested properties of an object as "readonly"
 */
export type DeepReadonly<T> = {
    readonly [P in keyof T]: DeepReadonly<T[P]>;
};
