import { AfterViewChecked, ElementRef, EventEmitter, OnChanges, OnDestroy, Renderer2, SimpleChanges } from "@angular/core";
import { AccordionExpandEvent } from "../accordion.types";
import { Service } from "../service/accordion.service";
import * as i0 from "@angular/core";
export declare class AccordionItemComponent implements AfterViewChecked, OnDestroy, OnChanges {
    private elRef;
    private service;
    private _renderer;
    contentElement: ElementRef;
    bodyElement: ElementRef;
    buttonElement: ElementRef;
    ddsAccordionExpandedEvent: EventEmitter<AccordionExpandEvent>;
    ddsAccordionCollapsedEvent: EventEmitter<AccordionExpandEvent>;
    inactive: boolean;
    title: string;
    heading: number;
    expanded: boolean;
    readonly itemId: string;
    readonly contentId: string;
    itemExpanded: boolean;
    iconExpanded: boolean;
    itemFocus: boolean;
    private itemExpanding;
    private itemCollapsing;
    private heightToExpand;
    private isAnimating;
    get itemClasses(): {
        dds__accordion__item: boolean;
        "dds__accordion__item--inactive": boolean;
        "dds__accordion__item--focus": boolean;
    };
    contentClasses: {
        dds__accordion__content: boolean;
    };
    headingClasses: {
        dds__accordion__heading: boolean;
    };
    buttonClasses: {
        dds__accordion__button: boolean;
    };
    bodyClasses: {
        dds__accordion__body: boolean;
    };
    chevronClasses: {
        dds__icon: boolean;
        dds__accordion__icon: boolean;
    };
    handleClick(event: any): void;
    handleFocus(event: any): void;
    private getContentHeight;
    startExpanding(): void;
    private endExpanding;
    startCollapsing(): void;
    private endCollapse;
    handleTransition(event: any): void;
    ngAfterViewChecked(): void;
    ngOnDestroy(): void;
    ngOnChanges(changes: SimpleChanges): void;
    constructor(elRef: ElementRef, service: Service, _renderer: Renderer2);
    static ɵfac: i0.ɵɵFactoryDeclaration<AccordionItemComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AccordionItemComponent, "dds-accordion-item", never, { "inactive": { "alias": "inactive"; "required": false; }; "title": { "alias": "title"; "required": false; }; "heading": { "alias": "heading"; "required": false; }; "expanded": { "alias": "expanded"; "required": false; }; }, { "ddsAccordionExpandedEvent": "dds-expand"; "ddsAccordionCollapsedEvent": "dds-collapse"; }, never, ["*"], false, never>;
}
