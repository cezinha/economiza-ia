import { AfterContentInit, EventEmitter, OnChanges, OnDestroy, QueryList, SimpleChanges } from "@angular/core";
import { Service } from "./service/accordion.service";
import { AccordionItemComponent } from "./accordion-item/accordion-item.component";
import { AccordionCollapseAllEvent, AccordionCollapseEvent, AccordionExpandAllEvent, AccordionExpandEvent, Localization } from "./accordion.types";
import * as i0 from "@angular/core";
export declare class AccordionComponent implements OnChanges, AfterContentInit, OnDestroy {
    service: Service;
    accordionItems: QueryList<AccordionItemComponent>;
    independent: boolean;
    controls: boolean;
    animation: string | boolean;
    localization: Localization;
    ddsAccordionExpandedAllEvent: EventEmitter<AccordionExpandAllEvent>;
    ddsAccordionCollapsedAllEvent: EventEmitter<AccordionCollapseAllEvent>;
    ddsAccordionExpandedEvent: EventEmitter<AccordionExpandEvent>;
    ddsAccordionCollapsedEvent: EventEmitter<AccordionCollapseEvent>;
    focusableItems: AccordionItemComponent[];
    expandDisabled: boolean;
    collapseDisabled: boolean;
    srOnlyValue: string;
    private expandSubscription;
    private collapseSubscription;
    handleKeyDown(event: KeyboardEvent): void;
    accordionId: string;
    accordionClasses: {
        dds__accordion: boolean;
    };
    controlClasses: {
        dds__accordion__control: boolean;
    };
    expandClass: {
        dds__accordion__control__expand: boolean;
    };
    collapseClass: {
        dds__accordion__control__collapse: boolean;
    };
    srOnlyClasses: {
        dds__accordion__sr: boolean;
    };
    expandItem: (index: any) => void;
    collapseItem: (index: any) => void;
    expandAll: () => void;
    collapseAll: () => void;
    ngAfterContentInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    constructor(service: Service);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AccordionComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AccordionComponent, "dds-accordion", never, { "independent": { "alias": "independent"; "required": false; }; "controls": { "alias": "controls"; "required": false; }; "animation": { "alias": "animation"; "required": false; }; "localization": { "alias": "localization"; "required": false; }; }, { "ddsAccordionExpandedAllEvent": "dds-expand-all"; "ddsAccordionCollapsedAllEvent": "dds-collapse-all"; "ddsAccordionExpandedEvent": "dds-expand"; "ddsAccordionCollapsedEvent": "dds-collapse"; }, ["accordionItems"], ["*"], false, never>;
}
