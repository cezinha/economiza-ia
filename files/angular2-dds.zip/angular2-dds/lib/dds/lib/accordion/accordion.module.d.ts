import * as i0 from "@angular/core";
import * as i1 from "./accordion.component";
import * as i2 from "./accordion-item/accordion-item.component";
import * as i3 from "@angular/common";
export declare class AccordionModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<AccordionModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<AccordionModule, [typeof i1.AccordionComponent, typeof i2.AccordionItemComponent], [typeof i3.CommonModule], [typeof i1.AccordionComponent, typeof i2.AccordionItemComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<AccordionModule>;
}
