import { AccordionComponent } from "./accordion.component";
import { GenericEvent } from "../abstracts/types/generic-event";
import { AccordionItemComponent } from "./public-api";
export type { Localization } from "../../core/components/accordion/accordion.types";
export type AccordionExpandEvent = GenericEvent<AccordionComponent | AccordionItemComponent>;
export type AccordionCollapseEvent = GenericEvent<AccordionComponent | AccordionItemComponent>;
export type AccordionCollapseAllEvent = GenericEvent<AccordionComponent>;
export type AccordionExpandAllEvent = GenericEvent<AccordionComponent>;
