import { BehaviorSubject } from "rxjs";
import * as i0 from "@angular/core";
export declare class Service {
    expand$: BehaviorSubject<string | undefined>;
    collapse$: BehaviorSubject<string | undefined>;
    animation$: BehaviorSubject<boolean | undefined>;
    currentItem$: BehaviorSubject<string | undefined>;
    expandedItem$: BehaviorSubject<string[]>;
    independent: boolean;
    constructor();
    static ɵfac: i0.ɵɵFactoryDeclaration<Service, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<Service>;
}
