import { AfterViewInit, ElementRef, SimpleChanges } from "@angular/core";
import { BehaviorSubject } from "rxjs";
import type { IconName, IconType } from "./action-menu.types";
import * as i0 from "@angular/core";
export declare class ActionMenuContentComponent implements AfterViewInit {
    svgIconName?: string;
    iconClasses: {
        dds__icon: boolean;
        "dds__action-menu__icon": boolean;
    };
    focused$: BehaviorSubject<boolean>;
    index: number;
    inactive: boolean;
    iconType: IconType;
    iconName?: IconName;
    ref: ElementRef;
    ngAfterViewInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ActionMenuContentComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ActionMenuContentComponent, "ng-component", never, { "inactive": { "alias": "inactive"; "required": false; }; "iconType": { "alias": "icon-type"; "required": false; }; "iconName": { "alias": "icon-name"; "required": false; }; }, {}, never, never, false, never>;
}
