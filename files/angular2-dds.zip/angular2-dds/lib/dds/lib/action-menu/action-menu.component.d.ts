import { AfterViewInit, ChangeDetectorRef, ElementRef, EventEmitter, OnChanges, OnDestroy, QueryList, SimpleChanges, Renderer2 } from "@angular/core";
import type { Size, Placement, ActionMenuEvent } from "./action-menu.types";
import type { WithNativeElement } from "../abstracts/types/with-native-element";
import { ActionMenuContentComponent } from "./action-menu-content.component";
import * as i0 from "@angular/core";
export declare class ActionMenuComponent implements OnChanges, AfterViewInit, OnDestroy {
    private document;
    private changeDetectorRef;
    private elementRef;
    private renderer;
    private platformId;
    private id;
    isVisible: boolean;
    private focusedIndex;
    private totalItems;
    containerPosition: {};
    private isUsingKeyboard;
    private triggerFullKeyboardNav;
    private triggerNoArrowsKeyboardNav;
    readonly wrapperClasses: {
        "dds__action-menu": boolean;
        "dds__action-menu--sm": boolean;
    };
    readonly menuClasses: {
        "dds__action-menu__menu": boolean;
    };
    readonly containerClasses: {
        "dds__action-menu__container": boolean;
        "dds__action-menu__container--visible": boolean;
    };
    /**
     * Controls whether the menu should be opened by the arrow keys or not
     * When actionmenu is inside dds-table with role=grid, arrow keys should nav through the cells
     * and not toggle the visibility of the action menu
     */
    openOnArrowKeys: boolean;
    private _trigger?;
    trigger?: HTMLElement | WithNativeElement;
    closeOnItemClick: boolean;
    closeOnScroll: boolean;
    size: Size;
    placement: Placement;
    usePortal: boolean;
    ddsClose: EventEmitter<ActionMenuEvent>;
    ddsOpen: EventEmitter<ActionMenuEvent>;
    containerRef: ElementRef;
    children?: QueryList<ActionMenuContentComponent>;
    private assignIndexesToChildren;
    handleEscape(): void;
    handleTab(): void;
    handleHome(event: Event): void;
    handleEnd(event: Event): void;
    focusNext(event: Event): void;
    focusPrev(event: Event): void;
    private getNextFocusableItem;
    private getPreviousFocusableItem;
    /**
     * It handles to close the action menu or not when clicking outside of it
     */
    private handleDocumentClick;
    /**
     * It handles to close the action menu or not when scrolling outside of it
     */
    private handleWindowScroll;
    /**
     * Everytime the focus change it loops through the children and updates
     * the focused state of each item.
     */
    private updateFocusedItem;
    /**
     * It handles to close the action menu from keyboard
     */
    private handleKeyboardTrigger;
    /**
     * It handles to close the action menu from mouse
     */
    private handleMouseTrigger;
    /**
     * Calculates the position of the container based on the trigger
     * and updates the containerPosition variable
     */
    private updatePosition;
    private removeGlobalListeners;
    /**
     * This function handles to close the action menu when this.closeOnClick is true
     * To prevent from closing when clicking on label, separator etc we check the nodeName
     * and only clicks on Button and Anchor will close the menu
     * @private
     */
    handleContentAction(event: Event): void;
    /**
     * Toggles the action menu visibility
     * @emits dds-close, dds-open
     */
    toggle: () => void;
    /**
     * Toggles the action menu visibility
     * @emits dds-open
     */
    open: () => void;
    /**
     * Toggles the action menu visibility
     * @emits dds-close
     */
    close: () => void;
    constructor(document: Document, changeDetectorRef: ChangeDetectorRef, elementRef: ElementRef, renderer: Renderer2, platformId: any);
    ngOnChanges(changes: SimpleChanges): void;
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ActionMenuComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ActionMenuComponent, "dds-action-menu", never, { "openOnArrowKeys": { "alias": "open-on-arrow-keys"; "required": false; }; "trigger": { "alias": "trigger"; "required": false; }; "closeOnItemClick": { "alias": "close-on-item-click"; "required": false; }; "closeOnScroll": { "alias": "close-on-scroll"; "required": false; }; "size": { "alias": "size"; "required": false; }; "placement": { "alias": "placement"; "required": false; }; "usePortal": { "alias": "use-portal"; "required": false; }; }, { "ddsClose": "dds-close"; "ddsOpen": "dds-open"; }, ["children"], ["dds-action-menu-group,dds-action-menu-item,dds-action-menu-link,dds-action-menu-option"], false, never>;
}
