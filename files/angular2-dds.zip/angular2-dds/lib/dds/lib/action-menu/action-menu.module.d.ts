import * as i0 from "@angular/core";
import * as i1 from "./action-menu.component";
import * as i2 from "./action-menu-content.component";
import * as i3 from "./menu-item/menu-item.component";
import * as i4 from "./menu-option/menu-option.component";
import * as i5 from "./menu-link/menu-link.component";
import * as i6 from "./menu-group/menu-group.component";
import * as i7 from "@angular/common";
export declare class ActionMenuModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ActionMenuModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ActionMenuModule, [typeof i1.ActionMenuComponent, typeof i2.ActionMenuContentComponent, typeof i3.ActionMenuItemComponent, typeof i4.ActionMenuOptionComponent, typeof i5.ActionMenuLinkComponent, typeof i6.ActionMenuGroupComponent], [typeof i7.CommonModule], [typeof i1.ActionMenuComponent, typeof i2.ActionMenuContentComponent, typeof i3.ActionMenuItemComponent, typeof i4.ActionMenuOptionComponent, typeof i5.ActionMenuLinkComponent, typeof i6.ActionMenuGroupComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ActionMenuModule>;
}
