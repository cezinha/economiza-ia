import { ActionMenuComponent } from "./action-menu.component";
export type { Name as IconName, Type as IconType } from "../icon/icon.types";
export type { Size, Placement } from "../../core/components/action-menu/action-menu.types";
export type ActionMenuEvent = {
    target: ActionMenuComponent;
};
export interface WithNativeElement {
    nativeElement: HTMLElement;
}
