import { AfterContentChecked, AfterViewInit, ElementRef, EventEmitter, QueryList } from "@angular/core";
import { ActionMenuOptionComponent } from "../menu-option/menu-option.component";
import * as i0 from "@angular/core";
export type ActionMenuGroupEvent = {
    target: ActionMenuGroupComponent;
};
export declare class ActionMenuGroupComponent implements AfterViewInit, AfterContentChecked {
    id: string;
    ariaLabelledBy?: string | undefined;
    checkedItems: string[];
    readonly separatorClasses: {
        "dds__action-menu__separator": boolean;
    };
    readonly titleClasses: {
        "dds__action-menu__group__title": boolean;
    };
    children?: QueryList<ActionMenuOptionComponent>;
    /**
     * Event emitted when the group is checked or unchecked.
     */
    ddsCheckedItems: EventEmitter<ActionMenuGroupEvent>;
    /**
     * The aria-label that will be added to describe the group.
     * It should be used when dds-label is not present.
     * @default null
     */
    label?: string;
    /**
     * Adds a separator in the end of the group
     * @default false
     */
    separator: boolean;
    groupTitle?: ElementRef;
    private toggleChecked;
    ngAfterContentChecked(): void;
    ngAfterViewInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ActionMenuGroupComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ActionMenuGroupComponent, "dds-action-menu-group", never, { "label": { "alias": "label"; "required": false; }; "separator": { "alias": "separator"; "required": false; }; }, { "ddsCheckedItems": "dds-checked-items"; }, ["children"], ["dds-label", "dds-action-menu-item,dds-action-menu-link,dds-action-menu-option"], false, never>;
}
