import { AfterViewInit, OnChanges, SimpleChanges } from "@angular/core";
import { ActionMenuContentComponent } from "../action-menu-content.component";
import { WithNativeElement } from "../action-menu.types";
import * as i0 from "@angular/core";
export declare class ActionMenuItemComponent extends ActionMenuContentComponent implements OnChanges, AfterViewInit, WithNativeElement {
    nativeElement: HTMLElement;
    readonly wrapperClasses: {
        "dds__action-menu__item": boolean;
    };
    destructive: boolean;
    ngOnChanges(changes: SimpleChanges): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ActionMenuItemComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ActionMenuItemComponent, "dds-action-menu-item", never, { "destructive": { "alias": "destructive"; "required": false; }; }, {}, never, ["*"], false, never>;
}
