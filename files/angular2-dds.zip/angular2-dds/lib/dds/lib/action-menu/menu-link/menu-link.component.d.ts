import { SimpleChanges } from "@angular/core";
import { ActionMenuContentComponent } from "../action-menu-content.component";
import * as i0 from "@angular/core";
export declare class ActionMenuLinkComponent extends ActionMenuContentComponent {
    readonly wrapperClasses: {
        "dds__action-menu__link": boolean;
    };
    href: string;
    download: string;
    target: string;
    rel: string;
    type: string;
    ping: string;
    hreflang: string;
    referrerpolicy: string;
    destructive: boolean;
    /**
     * @private
     * Handle click event on the link and prevent default if the link is inactive
     */
    handleClick(event: Event): void;
    ngOnChanges(changes: SimpleChanges): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ActionMenuLinkComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ActionMenuLinkComponent, "dds-action-menu-link", never, { "href": { "alias": "href"; "required": false; }; "download": { "alias": "download"; "required": false; }; "target": { "alias": "target"; "required": false; }; "rel": { "alias": "rel"; "required": false; }; "type": { "alias": "type"; "required": false; }; "ping": { "alias": "ping"; "required": false; }; "hreflang": { "alias": "href-lang"; "required": false; }; "referrerpolicy": { "alias": "referrer-policy"; "required": false; }; "destructive": { "alias": "destructive"; "required": false; }; }, {}, never, ["*"], false, never>;
}
