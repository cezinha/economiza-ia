import { AfterViewInit, ElementRef, EventEmitter } from "@angular/core";
import { ActionMenuContentComponent } from "../action-menu-content.component";
import * as i0 from "@angular/core";
export type ActionMenuOptionEvent = {
    target: ActionMenuOptionComponent;
};
export declare class ActionMenuOptionComponent extends ActionMenuContentComponent implements AfterViewInit {
    checked: boolean;
    /**
     * The value of this option. When empty, the text content will be used.
     */
    value: string;
    textRef: ElementRef;
    /**
     * Event emitted when the option is checked.
     */
    ddsCheck: EventEmitter<ActionMenuOptionEvent>;
    /**
     * Event emitted when the option is unchecked.
     */
    ddsUncheck: EventEmitter<ActionMenuOptionEvent>;
    readonly wrapperClasses: {
        "dds__action-menu__option": boolean;
    };
    readonly checkedIconClasses: {
        dds__icon: boolean;
        "dds__action-menu__check": boolean;
    };
    /**
     * Toggles the checked state of the option and dispatch the corresponding event.
     * @emit dds-checked, dds-unchecked
     */
    toggleChecked(): void;
    ngAfterViewInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ActionMenuOptionComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ActionMenuOptionComponent, "dds-action-menu-option", never, { "checked": { "alias": "checked"; "required": false; }; "value": { "alias": "value"; "required": false; }; }, { "ddsCheck": "dds-check"; "ddsUncheck": "dds-uncheck"; }, never, ["*"], false, never>;
}
