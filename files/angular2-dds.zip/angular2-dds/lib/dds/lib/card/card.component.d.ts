import * as i0 from "@angular/core";
export declare class CardComponent {
    readonly cardClass: {
        dds__card__content: boolean;
    };
    static ɵfac: i0.ɵɵFactoryDeclaration<CardComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CardComponent, "dds-card", never, {}, {}, never, ["dds-card-media", "dds-card-header", "dds-card-body", "dds-card-footer"], false, never>;
}
