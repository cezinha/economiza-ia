import * as i0 from "@angular/core";
import * as i1 from "./card.component";
import * as i2 from "./header/header.component";
import * as i3 from "./sub-title/sub-title.component";
import * as i4 from "./title/title.component";
import * as i5 from "./media/media.component";
import * as i6 from "./body/body.component";
import * as i7 from "./footer/footer.component";
import * as i8 from "@angular/common";
export declare class CardModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CardModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CardModule, [typeof i1.CardComponent, typeof i2.CardHeaderComponent, typeof i3.CardSubTitleComponent, typeof i4.CardTitleComponent, typeof i5.CardMediaComponent, typeof i6.CardBodyComponent, typeof i7.CardFooterComponent], [typeof i8.CommonModule], [typeof i1.CardComponent, typeof i2.CardHeaderComponent, typeof i3.CardSubTitleComponent, typeof i4.CardTitleComponent, typeof i5.CardMediaComponent, typeof i6.CardBodyComponent, typeof i7.CardFooterComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CardModule>;
}
