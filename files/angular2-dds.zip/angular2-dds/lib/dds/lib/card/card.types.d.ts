export type { Name as IconName, Type as IconType } from "../icon/icon.types";
export type IconPlacement = "start" | "top";
