import { SimpleChanges } from "@angular/core";
import type { IconPlacement, IconType, IconName } from "../card.types";
import * as i0 from "@angular/core";
export declare class CardHeaderComponent {
    iconPlacement: IconPlacement;
    iconName?: IconName;
    iconType: IconType;
    svgIconName: string;
    externalHeaderClasses: {
        dds__card__header: boolean;
    };
    readonly headerClasses: {
        dds__card__header__text: boolean;
    };
    readonly iconClasses: {
        dds__icon: boolean;
        dds__card__header__icon: boolean;
    };
    private getExternalHeaderClasses;
    ngOnChanges(changes: SimpleChanges): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CardHeaderComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CardHeaderComponent, "dds-card-header", never, { "iconPlacement": { "alias": "icon-placement"; "required": false; }; "iconName": { "alias": "icon-name"; "required": false; }; "iconType": { "alias": "icon-type"; "required": false; }; }, {}, never, ["dds-card-title", "dds-card-sub-title", "*"], false, never>;
}
