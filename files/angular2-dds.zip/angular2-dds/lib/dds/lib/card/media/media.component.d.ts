import * as i0 from "@angular/core";
export declare class CardMediaComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<CardMediaComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CardMediaComponent, "dds-card-media", never, {}, {}, never, ["*"], false, never>;
}
