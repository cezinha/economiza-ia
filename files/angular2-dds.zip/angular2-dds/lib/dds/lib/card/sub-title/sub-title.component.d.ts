import * as i0 from "@angular/core";
export declare class CardSubTitleComponent {
    readonly subTitleClass: {
        dds__card__header__subtitle: boolean;
    };
    static ɵfac: i0.ɵɵFactoryDeclaration<CardSubTitleComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CardSubTitleComponent, "dds-card-sub-title", never, {}, {}, never, ["*"], false, never>;
}
