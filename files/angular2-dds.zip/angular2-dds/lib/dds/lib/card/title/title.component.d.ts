import { SimpleChanges } from "@angular/core";
import * as i0 from "@angular/core";
export declare class CardTitleComponent {
    headingLevel: number;
    readonly titleClass: {
        dds__card__header__title: boolean;
    };
    ngOnChanges(changes: SimpleChanges): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CardTitleComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CardTitleComponent, "dds-card-title", never, { "headingLevel": { "alias": "heading-level"; "required": false; }; }, {}, never, ["*"], false, never>;
}
