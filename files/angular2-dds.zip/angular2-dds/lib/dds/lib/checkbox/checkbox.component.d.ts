import { AfterViewInit, OnChanges, SimpleChanges } from "@angular/core";
import { FormField } from "../abstracts/form-field/form-field.component";
import * as i0 from "@angular/core";
export declare class CheckboxComponent extends FormField<string> implements OnChanges, AfterViewInit {
    readonly componentClasses: {
        readonly base: "dds__checkbox";
        readonly label: "dds__checkbox__label";
        readonly input: "dds__checkbox__input";
        readonly span: "dds__checkbox__span";
        readonly size: {
            readonly lg: "";
            readonly sm: "dds__checkbox--sm";
        };
        readonly fieldsetInline: "dds__fieldset--inline";
        readonly isInvalid: "dds__is--invalid";
        readonly errorText: "dds__invalid-feedback";
        readonly errorIcon: "dds__checkbox__error-text";
        readonly fieldset: "dds__fieldset";
        readonly fieldsetSize: {
            readonly lg: "";
            readonly sm: "dds__fieldset--sm";
        };
        readonly group: "dds__checkbox-group";
        readonly visualIndicator: "dds__visual-indicator";
    };
    readonly containerClass: {
        dds__checkbox: boolean;
        "dds__is--invalid": boolean;
    };
    readonly externalFocus: {
        "dds__checkbox--focus-visible": boolean;
    };
    componentName: string;
    value: string;
    checked: boolean;
    indeterminate: boolean;
    /** Sets attr.aria-checked as mixed if indeterminate */
    ariaChecked: string;
    private handleAriaChecked;
    /** Update classes when checkbox has been clicked */
    handleChange(): void;
    handleFocus(event: Event): void;
    handleBlur($event: FocusEvent): void;
    showErrorControl: boolean;
    handleValidation(value: string | null): void;
    ngOnChanges(changes: SimpleChanges): void;
    /**
     * This method is called from FormField when formControl or ngModel is udpated from outside
     * It makes the html element be on sync with the external control
     * @private
     */
    updateViewFromExternalControl(newValue: boolean): void;
    /** Set indeterminate to the declared stat */
    ngAfterViewInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckboxComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CheckboxComponent, "dds-checkbox", never, { "value": { "alias": "value"; "required": false; }; "checked": { "alias": "checked"; "required": false; }; "indeterminate": { "alias": "indeterminate"; "required": false; }; }, {}, never, ["dds-label", "dds-error"], false, never>;
}
