import * as i0 from "@angular/core";
import * as i1 from "./checkbox.component";
import * as i2 from "@angular/common";
export declare class CheckboxModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckboxModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CheckboxModule, [typeof i1.CheckboxComponent], [typeof i2.CommonModule], [typeof i1.CheckboxComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CheckboxModule>;
}
