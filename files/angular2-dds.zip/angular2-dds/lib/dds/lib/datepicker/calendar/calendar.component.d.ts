import { ElementRef, EventEmitter, OnChanges, OnDestroy, OnInit } from "@angular/core";
import type { Localization } from "../datepicker.types";
import { DatePickerService } from "../services/datepicker.service";
import * as i0 from "@angular/core";
type WeekDayCell = {
    value: number;
    label: string;
    abbr: string;
};
type CalendarCell = {
    date: Date;
    inactive: boolean;
    classes: Record<string, boolean>;
    selected: boolean;
    focused: boolean;
};
type SelectOption = {
    value: number;
    label: number | string;
    selected: boolean;
};
export declare class CalendarComponent implements OnInit, OnDestroy, OnChanges {
    private _el;
    private datePickerService;
    readonly calendarClasses: {
        calendar: {
            base: string;
            isPressing: string;
        };
        header: string;
        headerDisplay: string;
        headerPolite: string;
        monthSelect: string;
        yearSelect: string;
        /** List of week days with proper localization and sequence based on @see weekStart */
        prevButton: string;
        nextButton: string;
        body: string; /** List of days computed for a specific month/year. Already chunked in lots of 7 (a week)*/
        grid: {
            head: string;
            body: string;
            row: string;
        };
        weekDay: string;
        day: {
            base: string;
            inactive: string;
            outMonth: string;
            today: string;
            selected: string;
            focusable: string;
        };
        footer: string;
        today: {
            base: string;
            inactive: string;
        };
        cancel: string;
        confirm: string;
    };
    readonly srClasses: {
        srOnly: string;
    };
    readonly buttonClasses: {
        readonly base: "dds__button";
        readonly block: "dds__button--block";
        readonly aiTextGradient: "dds__button__text--ai-gradient";
        readonly kinds: {
            readonly primary: "";
            readonly secondary: "dds__button--secondary";
            readonly tertiary: "dds__button--tertiary";
        };
        readonly colors: {
            readonly default: "";
            readonly destructive: "dds__button--destructive";
            readonly transactional: "dds__button--transactional";
            readonly editorial: "dds__button--editorial";
            readonly editorialLight: "dds__button--editorial-light";
            readonly ai: "dds__button--ai";
        };
        readonly sizes: {
            readonly mini: "dds__button--mini";
            readonly sm: "dds__button--sm";
            readonly md: "dds__button--md";
            readonly lg: "";
        };
        readonly withIcon: {
            readonly start: "dds__button__icon--start";
            readonly end: "dds__button__icon--end";
            readonly only: "dds__button__icon";
        };
    };
    /** Keep track of date in focus (navigation) */
    private focusedDate;
    private calendar$;
    /** Options for year select control */
    yearOptions: SelectOption[];
    /** Options for month select control */
    monthOptions: SelectOption[];
    /** List of week days with proper localization and sequence based on @see weekStart */
    weekDays: WeekDayCell[];
    /** List of days computed for a specific month/year. Already chunked in lots of 7 (a week)*/
    calendarDays: CalendarCell[][];
    /** Polite sr header message */
    srPoliteYearMonthText: string;
    private _startEl;
    private _firstEl;
    private _lastEl;
    startDate: Date;
    endDate: Date;
    inactiveDates: Date[];
    locale: string;
    weekStart: string;
    displayTodayButton: boolean;
    private _localization;
    /** Set the localization specific data */
    set localization(data: Partial<Localization>);
    get localization(): Partial<Localization>;
    private value;
    /** Cancel the selected date in calendar control */
    ddsCancel: EventEmitter<any>;
    handleKey($event: KeyboardEvent): boolean | undefined;
    /** Resolves the styles for next month button */
    readonly nextButtonClasses: string[];
    /** Resolves the styles for previous month button */
    readonly prevButtonClasses: string[];
    /** Resolves the styles for screen reader data */
    readonly srPoliteYearMonthClasses: string[];
    /** Resolves the styles for the set today button */
    todayButtonClasses: {
        [x: string]: boolean;
        dds__button: boolean;
        "dds__button--sm": boolean;
        "dds__button--tertiary": boolean;
    };
    /** Resolves the styles for cancellation button */
    readonly cancelButtonClasses: string[];
    /** Resolves the styles for confirmation button */
    readonly confirmButtonClasses: string[];
    /** Generate a polite text to be rendered to Screen readers
     * @param {Date} date Date to be parsed
     * @returns {string} the text to be read
     */
    private generateSRPoliteYearMonthText;
    /** Generate the list option of years for <select>
     * @param {number} startYear defines the starting year of the list (inclusive)
     * @param {number} endYear defines the ending year of the list (inclusive)
     */
    private generateYears;
    /** Generate the list option of months for <select>
     * The list of options may exclude some months if the month in list falls outside
     * the @see {start-date} and @see {end-date} parameters for this class
     *
     * @param {number} year defines the relative year of the list (inclusive)
     */
    private generateMonths;
    /** Find the nearest start of week given a base date and the starting weekday
     * @param {Date} base is an arbitrary date to compute the nearest starting/ending weekday
     * @param {string} weekStart indicates the beginning week day.
     * @param {string} precision look for dates before base date or after base date.
     * @returns {Date} the nearest date which represents the beginning or ending of a week
     */
    private nearestStartOfWeek;
    /** Generate the name of weekdays for the calendar body */
    private generateWeekDays;
    /** Generate the values for day to render the body of calendar
     * @param {number} year defines the year related to the calendar
     * @param {number} month defines the month related to the calendar
     */
    private generateCalendar;
    /** Generate the month list of days with classification for styling */
    private dayClasses;
    private isWithinStartAndEndDates;
    /**
     * Finds the closest date in the next or previous month relative to the provided date,
     * considering the component's start and end dates. If the next or previous month does not
     * have that day of the month, the closest valid date will be returned.
     * Given January 31st and direction "next", for example, it will return February 28th or February 29th
     *
     * @param {Date} date - The date to update.
     * @param {"next" | "previous"} direction - Indicates whether the new date's month should be the next or previous month
     * @return {Date} The updated date.
     */
    private findClosestDateInAdjacentMonth;
    private findFocusableDate;
    get isPreviousDisabled(): boolean;
    get isNextDisabled(): boolean;
    get isTodayAValidDate(): boolean;
    handleMonthChange($event: Event): void;
    handleYearChange($event: Event): void;
    handlePreviousClick($event: Event): void;
    handleNextClick($event: Event): void;
    handleDateClick($event: Event): void;
    handleSetToday(): void;
    handleCancel(): void;
    handleConfirm(): void;
    /**
     * Defines a custom focus behavior
     */
    setFocus(visible: boolean): void;
    constructor(_el: ElementRef<HTMLDivElement>, datePickerService: DatePickerService);
    ngOnChanges(): void;
    private buildCalendar;
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CalendarComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CalendarComponent, "dds-datepicker-calendar", never, { "startDate": { "alias": "start-date"; "required": false; }; "endDate": { "alias": "end-date"; "required": false; }; "inactiveDates": { "alias": "inactive-dates"; "required": false; }; "locale": { "alias": "locale"; "required": false; }; "weekStart": { "alias": "week-start"; "required": false; }; "displayTodayButton": { "alias": "display-today-button"; "required": false; }; "localization": { "alias": "localization"; "required": false; }; }, { "ddsCancel": "dds-cancel"; }, never, never, false, never>;
}
export {};
