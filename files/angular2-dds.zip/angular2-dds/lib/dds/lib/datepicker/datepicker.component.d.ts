import { ElementRef, EventEmitter, Injector, OnChanges, OnInit, SimpleChanges } from "@angular/core";
import type { Size, Localization, DatePickerChangeEvent } from "./datepicker.types";
import { componentClasses } from "../../core/components/date-picker/date-picker";
import { componentClasses as iconClasses } from "../../core/components/icon/icon";
import { FormField } from "../abstracts/form-field/form-field.component";
import type { DeepReadonly } from "../../core/types/deepreadonly";
import { DatePickerService } from "./services/datepicker.service";
import * as i0 from "@angular/core";
export declare class DatepickerComponent extends FormField<string | Date> implements OnChanges, OnInit {
    private service;
    readonly ref: ElementRef;
    readonly injector: Injector;
    readonly componentClasses: DeepReadonly<typeof componentClasses>;
    readonly iconClasses: DeepReadonly<typeof iconClasses>;
    readonly popupId: string;
    private openedSubscription?;
    private formSubmitSubscription?;
    private dateSelectionSubscription?;
    readonly ddsChange: EventEmitter<DatePickerChangeEvent>;
    maxLength?: number;
    placeholder?: string;
    inactive: boolean;
    size: Size;
    locale: string;
    format: string;
    weekStart: string;
    required: boolean;
    predictiveParser: boolean;
    displayTodayButton: boolean;
    inactiveDates: Date[];
    startDate: Date;
    endDate: Date;
    closeOnScroll: boolean;
    value?: string | Date;
    srParserLabel: string;
    localization: Localization;
    baseClasses: {
        "dds__date-picker": boolean;
        "dds__date-picker--sm": boolean;
    };
    validationIconClasses: {
        dds__icon: boolean;
        "dds__date-picker__validation-icon": boolean;
    };
    handleToggleCalendar(event: Event): void;
    private handleNewValue;
    handleChange($event: FocusEvent): void;
    private invalidMessage;
    handleValidation: (value: string, invalidReason?: string, isResetting?: boolean) => void;
    writeValue(value: string): void;
    constructor(service: DatePickerService, ref: ElementRef, injector: Injector);
    ngOnInit(): void;
    /**
     * Closes when scrolling the page or clicking in the document
     */
    private handleCloseOutsideAction;
    ngOnChanges(changes: SimpleChanges): void;
    private unbindDocumentEvents;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DatepickerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DatepickerComponent, "dds-datepicker", never, { "maxLength": { "alias": "max-length"; "required": false; }; "placeholder": { "alias": "placeholder"; "required": false; }; "inactive": { "alias": "inactive"; "required": false; }; "size": { "alias": "size"; "required": false; }; "locale": { "alias": "locale"; "required": false; }; "format": { "alias": "format"; "required": false; }; "weekStart": { "alias": "week-start"; "required": false; }; "required": { "alias": "required"; "required": false; }; "predictiveParser": { "alias": "predictive-parser"; "required": false; }; "displayTodayButton": { "alias": "display-today-button"; "required": false; }; "inactiveDates": { "alias": "inactive-dates"; "required": false; }; "startDate": { "alias": "start-date"; "required": false; }; "endDate": { "alias": "end-date"; "required": false; }; "closeOnScroll": { "alias": "close-on-scroll"; "required": false; }; "value": { "alias": "value"; "required": false; }; "localization": { "alias": "localization"; "required": false; }; }, { "ddsChange": "dds-change"; }, never, ["dds-label", "dds-error", "dds-helper"], false, never>;
}
