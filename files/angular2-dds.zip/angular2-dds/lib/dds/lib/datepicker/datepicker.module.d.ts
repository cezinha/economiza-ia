import * as i0 from "@angular/core";
import * as i1 from "./datepicker.component";
import * as i2 from "./calendar/calendar.component";
import * as i3 from "./popup/popup.component";
import * as i4 from "@angular/common";
export declare class DatepickerModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DatepickerModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DatepickerModule, [typeof i1.DatepickerComponent, typeof i2.CalendarComponent, typeof i3.PopupComponent], [typeof i4.CommonModule], [typeof i1.DatepickerComponent, typeof i2.CalendarComponent, typeof i3.PopupComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DatepickerModule>;
}
