import { ElementRef, OnInit, OnDestroy, ChangeDetectorRef } from "@angular/core";
import { DatePickerService } from "../services/datepicker.service";
import * as i0 from "@angular/core";
export declare class PopupComponent implements OnInit, OnDestroy {
    private popupElement;
    private service;
    private changeDetectorRef;
    id: string;
    hidden: boolean;
    placementRef: HTMLElement;
    containerRef: ElementRef;
    handleClick($event: Event): void;
    handleKeyUp(): void;
    readonly wrapperClasses: {
        "dds__date-picker__popup": boolean;
    };
    private _popupPosition;
    get popupPosition(): string | undefined;
    private updateCalendarPosition;
    constructor(popupElement: ElementRef, service: DatePickerService, changeDetectorRef: ChangeDetectorRef);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<PopupComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PopupComponent, "dds-datepicker-popup", never, { "id": { "alias": "id"; "required": false; }; "placementRef": { "alias": "placement-ref"; "required": false; }; }, {}, never, ["*"], false, never>;
}
