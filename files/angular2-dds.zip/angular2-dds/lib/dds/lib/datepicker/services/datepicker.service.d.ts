import { BehaviorSubject } from "rxjs";
import * as i0 from "@angular/core";
export declare class DatePickerService {
    selectedDate$: BehaviorSubject<Date | undefined>;
    opened$: BehaviorSubject<boolean>;
    spotFocus: boolean;
    openCalendar(spotFocus: boolean): void;
    closeCalendar(): void;
    toggleCalendar(spotFocus: boolean): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DatePickerService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<DatePickerService>;
}
