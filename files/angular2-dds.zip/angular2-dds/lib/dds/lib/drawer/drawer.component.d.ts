import { AfterViewInit, ElementRef, EventEmitter, OnChanges, OnDestroy, SimpleChanges } from "@angular/core";
import { Localization, Size, DrawerClosedEvent, DrawerOpenedEvent } from "./drawer.types";
import { WithNativeElement } from "../abstracts/types/with-native-element";
import { Overlay } from "../../core/components/overlay/overlay.types";
import * as i0 from "@angular/core";
export declare class DrawerComponent implements OnChanges, AfterViewInit, OnDestroy {
    private elRef;
    constructor(elRef: ElementRef);
    containerElement: ElementRef;
    buttonElement: ElementRef;
    handleKeyDown(): void;
    private focusTrap;
    private _trigger?;
    title: string;
    width: string;
    isVisible: boolean;
    size: Size;
    overlay: Overlay;
    trigger?: HTMLElement | WithNativeElement;
    headingLevel: number;
    localization: Localization;
    ddsDrawerOpenedEvent: EventEmitter<DrawerOpenedEvent>;
    ddsDrawerClosedEvent: EventEmitter<DrawerClosedEvent>;
    readonly baseClass: {
        dds__drawer: boolean;
    };
    readonly iconClasses: {
        dds__icon: boolean;
        "dds__drawer__close-icon": boolean;
    };
    readonly containerClass: {
        dds__drawer__container: boolean;
    };
    readonly headerClass: {
        dds__drawer__header: boolean;
    };
    readonly closeButtonClass: {
        dds__drawer__close: boolean;
    };
    readonly bodyClass: {
        dds__drawer__body: boolean;
    };
    readonly titleClass: {
        dds__drawer__title: boolean;
    };
    readonly overlayClass: {
        dds__drawer__overlay: boolean;
    };
    readonly drawerId: string;
    /**
     * Toggles the drawer visibility
     * @emits dds-close, dds-open
     */
    toggle: () => void;
    open: () => void;
    close: () => void;
    private updateDrawerWidth;
    private handleTriggerClick;
    handleTriggerKeydown: (e: KeyboardEvent) => void;
    private validateTrigger;
    private setTrigger;
    private unsetTrigger;
    ngOnChanges(changes: SimpleChanges): void;
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DrawerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DrawerComponent, "dds-drawer", never, { "title": { "alias": "title"; "required": false; }; "width": { "alias": "width"; "required": false; }; "isVisible": { "alias": "visible"; "required": false; }; "size": { "alias": "size"; "required": false; }; "overlay": { "alias": "overlay"; "required": false; }; "trigger": { "alias": "trigger"; "required": false; }; "headingLevel": { "alias": "headingLevel"; "required": false; }; "localization": { "alias": "localization"; "required": false; }; }, { "ddsDrawerOpenedEvent": "dds-opened"; "ddsDrawerClosedEvent": "dds-closed"; }, never, ["*", "dds-drawer-footer"], false, never>;
}
