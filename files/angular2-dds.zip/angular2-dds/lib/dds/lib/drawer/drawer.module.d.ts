import * as i0 from "@angular/core";
import * as i1 from "./drawer.component";
import * as i2 from "./footer/footer.component";
import * as i3 from "@angular/common";
import * as i4 from "../overlay/overlay.module";
export declare class DrawerModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DrawerModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DrawerModule, [typeof i1.DrawerComponent, typeof i2.DrawerFooterComponent], [typeof i3.CommonModule, typeof i4.OverlayModule], [typeof i1.DrawerComponent, typeof i2.DrawerFooterComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DrawerModule>;
}
