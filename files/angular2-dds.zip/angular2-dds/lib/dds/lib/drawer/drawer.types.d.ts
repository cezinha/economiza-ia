import { GenericEvent } from "../abstracts/types/generic-event";
import { DrawerComponent } from "./public-api";
export { defaultLocalization } from "../../core/components/drawer/drawer";
export { Localization, Size } from "../../core/components/drawer/drawer.types";
export type DrawerClosingEvent = GenericEvent<DrawerComponent>;
export type DrawerClosedEvent = GenericEvent<DrawerComponent>;
export type DrawerOpeningEvent = GenericEvent<DrawerComponent>;
export type DrawerOpenedEvent = GenericEvent<DrawerComponent>;
