import * as i0 from "@angular/core";
export declare class DrawerFooterComponent {
    constructor();
    readonly footerClass: {
        dds__drawer__footer: boolean;
    };
    static ɵfac: i0.ɵɵFactoryDeclaration<DrawerFooterComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DrawerFooterComponent, "dds-drawer-footer", never, {}, {}, never, ["*"], false, never>;
}
