import { SimpleChanges } from "@angular/core";
import { DropdownManagementService } from "../services/dropdown-management.service";
import type { DropdownGroupSchema } from "../dropdown.types";
import * as i0 from "@angular/core";
export declare class DropdownGroupComponent {
    private service;
    value: DropdownGroupSchema;
    dropdownGroupLabelId: string;
    hidden: boolean;
    readonly dropdownGroupLabelClass: {
        "dds__dropdown__group-title": boolean;
    };
    readonly dropdownGroupClass: {
        dds__dropdown__group: boolean;
    };
    constructor(service: DropdownManagementService);
    ngOnChanges(changes: SimpleChanges): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DropdownGroupComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DropdownGroupComponent, "dds-dropdown-group", never, { "value": { "alias": "value"; "required": false; }; }, {}, never, ["dds-dropdown-option"], false, never>;
}
