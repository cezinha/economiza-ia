import { ElementRef, EventEmitter, OnChanges, SimpleChanges } from "@angular/core";
import { DropdownManagementService } from "../services/dropdown-management.service";
import type { DropdownOptionClickEvent, DropdownOptionSchema } from "../dropdown.types";
import * as i0 from "@angular/core";
export declare class DropdownOptionComponent implements OnChanges {
    service: DropdownManagementService;
    readonly ref: ElementRef;
    group: string;
    value: DropdownOptionSchema;
    hidden: boolean;
    inactive: boolean;
    index: number;
    isFocused: boolean;
    isSelectAll: boolean;
    label: string;
    selected: boolean;
    selectedState: "true" | "false" | "mixed";
    setsize: number;
    posinset: number;
    private selectedSubscription?;
    private focusSubscription?;
    private filterSubscription?;
    private letSizeSubscription?;
    buttonRef: ElementRef;
    readonly ddsOptionClick: EventEmitter<DropdownOptionClickEvent>;
    readonly dropdownItemClass: {
        dds__dropdown__item: boolean;
        "dds__dropdown__select-all": boolean;
    };
    readonly dropdownItemOptionClass: {
        "dds__dropdown__item-option": boolean;
    };
    readonly dropdownItemLabelClass: {
        "dds__dropdown__item-label": boolean;
    };
    readonly dropdownItemIconClasses: {
        dds__icon: boolean;
        "dds__dropdown__item-selected": boolean;
    };
    readonly selectAllSeparatorClass: {
        "dds__dropdown__list-separator": boolean;
    };
    constructor(service: DropdownManagementService, ref: ElementRef);
    /**
     * Handles the click event for the dropdown option.
     * Updates the selected option label and sets the selected flag to true.
     */
    handleOptionClick(): void;
    ngOnInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DropdownOptionComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DropdownOptionComponent, "dds-dropdown-option", never, { "group": { "alias": "group"; "required": false; }; "value": { "alias": "value"; "required": false; }; }, { "ddsOptionClick": "dds-option-click"; }, never, never, false, never>;
}
