import { ElementRef, EventEmitter, Injector, OnInit, SimpleChanges } from "@angular/core";
import { FormField } from "../abstracts/form-field/form-field.component";
import { DropdownGroup, DropdownOption, Localization, Selection } from "./dropdown.types";
import type { DropdownCloseEvent, DropdownOpenEvent, DropdownOptionSelectEvent } from "./dropdown.types";
import { DropdownManagementService } from "./services/dropdown-management.service";
import * as i0 from "@angular/core";
export declare class DropdownComponent extends FormField<string | number> implements OnInit {
    readonly ref: ElementRef;
    readonly injector: Injector;
    value: string | number;
    options: (DropdownGroup | DropdownOption)[];
    localization: Localization;
    selection: Selection;
    placeholder?: string;
    closeOnScroll: boolean;
    selectAll: boolean;
    ddsOpen: EventEmitter<DropdownOpenEvent>;
    ddsClose: EventEmitter<DropdownCloseEvent>;
    ddsOptionSelect: EventEmitter<DropdownOptionSelectEvent>;
    isOpened: boolean;
    showTag: boolean;
    showPlaceholder: boolean;
    private selectAllOption;
    private filterSubscription?;
    private selectedSubscription?;
    private focusableSubscription?;
    readonly dropdownClasses: {
        dds__dropdown: boolean;
        "dds__dropdown--sm": boolean;
        "dds__dropdown--is-multiple": boolean;
    };
    readonly inputContainerClasses: {
        "dds__dropdown__input-container": boolean;
    };
    readonly inputWrapperClasses: {
        "dds__dropdown__input-wrapper": boolean;
    };
    readonly inputClassesField: {
        "dds__dropdown__input-field": boolean;
    };
    readonly inputIconClasses: {
        dds__dropdown__chevron: boolean;
    };
    readonly helperClasses: {
        "dds__input-text__helper": boolean;
    };
    readonly errorClasses: {
        "dds__invalid-feedback": boolean;
    };
    readonly dropdownPopupClasses: {
        dds__dropdown__popup: boolean;
        "dds__dropdown__popup--visible": boolean;
        "dds__dropdown__popup--hidden": boolean;
    };
    readonly dropdownPopupListClasses: {
        dds__dropdown__list: boolean;
    };
    readonly iconClass: {
        dds__icon: boolean;
    };
    readonly feedbackIconClass: {
        dds__icon: boolean;
        dds__dropdown__feedback__icon: boolean;
    };
    readonly noOptionsFoundClass: {
        dds__dropdown__notice: boolean;
    };
    readonly tagWrapperClasses: {
        "dds__dropdown__tag-wrapper": boolean;
    };
    readonly dropdownId: string;
    readonly dropdownPopupId: string;
    readonly dropdownPopupListId: string;
    private containerRef;
    tagRef?: ElementRef;
    tagEl?: ElementRef;
    /**
     * Checks if the given option is a DropdownGroup.
     * @param option - The option to check.
     * @returns True if the option is a DropdownGroup, false otherwise.
     */
    isDropdownGroup(option: DropdownGroup | DropdownOption): boolean;
    /**
     * On input keydown event, if the dropdown is not visible, it opens it.
     * Enable the filtering state.
     * @private
     */
    onInputChange(): void;
    /**
     * Handles the click event on the input element
     * If the dropdown is visible, it closes it. Otherwise, it opens it.
     * @private
     */
    handleInputClick(event: Event): void;
    /**
     * Handles the enter event on the input element (for single selection)
     * If the dropdown is visible, it closes it. Otherwise, it opens it.
     * @private
     */
    handleEnterEvent(): void;
    /**
     * Callback called from FormField
     * @private
     */
    handleValidation(value: string | null): void;
    /**
     * Identifies selected DropdownOptions from the provided options object
     * and updates the service's selectedOption observable
     */
    private findSelectedTrueOptions;
    /**
     * Clears the selection in the dropdown component.
     * @private
     */
    clearSelection: (event?: any) => void;
    /**
     * Public API
     * Selects an option by its value.
     * @param optionValue: string | string[] - The value of the option to select.
     */
    selectOption: (optionValue: string | number | (string | number)[]) => void;
    /**
     * Public API
     * Deselects an option by its value.
     */
    deselectOption: (values: (string | number) | (string | number)[]) => void;
    handleOptionClick(): void;
    handleReset(): void;
    updateViewFromExternalControl(newValue: string): void;
    /**
     * Closes the dropdown if it is currently visible.
     * Emits the `dds-close` event and resets the focused option index.
     * Also updates the dropdown popup classes and removes global listeners.
     */
    private close;
    /**
     * Opens the dropdown if it is currently not visible.
     * Emits the `dds-open` event and sets up global listeners.
     * Also updates the dropdown popup classes and updates the position of the container.
     */
    private open;
    private handleKeyboardEvents;
    /**
     * Closes when scrolling the page or clicking in the document
     */
    private handleCloseOutsideAction;
    writeValue(newValue: string | number | undefined | null): void;
    /**
     * Calculates the position of the container based on the trigger
     * and updates the containerPosition variable
     */
    private updatePosition;
    private unbindDocumentEvents;
    service: DropdownManagementService;
    private changeDetectorRef;
    constructor(ref: ElementRef, injector: Injector);
    ngOnChanges(changes: SimpleChanges): void;
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DropdownComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DropdownComponent, "dds-dropdown", never, { "value": { "alias": "value"; "required": false; }; "options": { "alias": "options"; "required": false; }; "localization": { "alias": "localization"; "required": false; }; "selection": { "alias": "selection"; "required": false; }; "placeholder": { "alias": "placeholder"; "required": false; }; "closeOnScroll": { "alias": "close-on-scroll"; "required": false; }; "selectAll": { "alias": "select-all"; "required": false; }; }, { "ddsOpen": "dds-open"; "ddsClose": "dds-close"; "ddsOptionSelect": "dds-option-select"; }, never, ["dds-label", "dds-helper", "dds-error"], false, never>;
}
