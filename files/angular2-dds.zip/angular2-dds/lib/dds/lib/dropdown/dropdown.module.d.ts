import * as i0 from "@angular/core";
import * as i1 from "./dropdown.component";
import * as i2 from "./dropdown-option/dropdown-option.component";
import * as i3 from "./dropdown-group/dropdown-group.component";
import * as i4 from "@angular/common";
import * as i5 from "../tag/tag.module";
export declare class DropdownModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DropdownModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DropdownModule, [typeof i1.DropdownComponent, typeof i2.DropdownOptionComponent, typeof i3.DropdownGroupComponent], [typeof i4.CommonModule, typeof i5.TagModule], [typeof i1.DropdownComponent, typeof i2.DropdownOptionComponent, typeof i3.DropdownGroupComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DropdownModule>;
}
