import { FormFieldValidationEvent } from "../abstracts/form-field/form-field.types";
import { GenericEvent } from "../abstracts/types/generic-event";
import type { DropdownComponent } from "./dropdown.component";
import { DropdownOptionComponent } from "./dropdown-option/dropdown-option.component";
export { Selection, Localization, Size } from "../../core/components/dropdown/dropdown.types";
export { FormFieldValidationEvent as DropdownValidationEvent };
export interface DropdownOption {
    label: string;
    value?: string | number;
    inactive?: boolean;
    selected?: boolean;
}
export interface DropdownGroup {
    label: string;
    options: DropdownOption[];
}
export interface DropdownOptionSchema {
    label: string;
    value: string | number;
    inactive: boolean;
    index: number;
    isSelectAll: boolean;
}
export interface DropdownGroupSchema {
    label: string;
    options: DropdownOptionSchema[];
}
export type DropdownOptionsSchema = (DropdownGroupSchema | DropdownOptionSchema)[];
export type DropdownOpenEvent = GenericEvent<DropdownComponent>;
export type DropdownCloseEvent = GenericEvent<DropdownComponent>;
export type DropdownOptionSelectEvent = GenericEvent<DropdownComponent>;
export type DropdownOptionClickEvent = GenericEvent<DropdownOptionComponent>;
