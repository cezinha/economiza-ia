import { OnDestroy } from "@angular/core";
import { BehaviorSubject } from "rxjs";
import { Selection } from "../../../core/components/dropdown/dropdown.types";
import { DropdownOptionSchema, DropdownOptionsSchema } from "../dropdown.types";
import { Subscription } from "rxjs";
import * as i0 from "@angular/core";
export declare class DropdownManagementService implements OnDestroy {
    private _options$;
    setOptions(options: DropdownOptionsSchema): void;
    private _filter$;
    setFilter(text: string): void;
    options$: BehaviorSubject<DropdownOptionsSchema>;
    isFiltering$: BehaviorSubject<boolean>;
    private optionsSubscription?;
    previousValue: any;
    currentValue: any;
    /**
     * Filters the given options based on the provided filter.
     *
     * @param {(DropdownGroupSchema | DropdownOptionSchema)[]} options - The options to filter.
     * @param {string} filter - The filter to apply.
     * @return {(DropdownGroupSchema | DropdownOptionSchema)[]} - The filtered options.
     */
    private _filterOptions;
    private _filterFocusableOptions;
    private _flattenOptions;
    private _flattenOptionsWithInactives;
    focusableOptions$: import("rxjs").Observable<DropdownOptionSchema[]>;
    focusableOptions: DropdownOptionSchema[];
    selectedOption$: BehaviorSubject<DropdownOptionSchema[] | undefined>;
    selectedValues$: Subscription;
    focusedOption$: BehaviorSubject<DropdownOptionSchema | undefined>;
    flattenedOptions: DropdownOptionSchema[];
    selectionType: Selection;
    isAllDataSelected: boolean;
    setSize$: BehaviorSubject<number>;
    selectOption: (optionValue: string | number | (string | number)[]) => void;
    private isOptionSelected;
    constructor();
    private getValidSelectableOptions;
    /**
     * Parses the given value to a string for tooltip accessibility for the tag.
     * @param value - The string of selected dropdown options to be parsed.
     */
    parseValue(value: any): any;
    /**
     * Parses the given options array and updates the dropdown options.
     * @param options - The array of dropdown options to be parsed.
     */
    parseOptions<T>(options: T[]): void;
    /**
     * Finds an option by its value.
     */
    findOptionByValue(value: string | number): DropdownOptionSchema | undefined;
    /**
     * Select/Deselects all options
     */
    toggleSelectAll(): void;
    focusNextOption(): void;
    focusPreviousOption(): void;
    focusFirstOption(): void;
    focusLastOption(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DropdownManagementService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<DropdownManagementService>;
}
