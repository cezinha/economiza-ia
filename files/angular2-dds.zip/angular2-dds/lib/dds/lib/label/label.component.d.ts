import { ElementRef, EventEmitter, SimpleChanges } from "@angular/core";
import { VisualIndicator } from "../abstracts/types/visual-indicator";
import * as i0 from "@angular/core";
export declare class LabelComponent {
    ref: ElementRef<HTMLDivElement>;
    visualIndicator: VisualIndicator;
    visualIndicatorChange: EventEmitter<VisualIndicator>;
    constructor(ref: ElementRef<HTMLDivElement>);
    ngOnChanges(changes: SimpleChanges): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<LabelComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<LabelComponent, "dds-label", never, { "visualIndicator": { "alias": "visual-indicator"; "required": false; }; }, { "visualIndicatorChange": "visualIndicatorChange"; }, never, ["*"], false, never>;
}
