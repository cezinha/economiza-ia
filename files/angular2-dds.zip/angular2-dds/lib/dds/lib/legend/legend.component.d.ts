import { SimpleChanges } from "@angular/core";
import { VisualIndicator } from "../abstracts/types/visual-indicator";
import * as i0 from "@angular/core";
export declare class LegendComponent {
    id: string;
    readonly legendClasses: {
        "dds__legend--required": boolean;
    };
    visualIndicator: VisualIndicator;
    ngOnChanges(change: SimpleChanges): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<LegendComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<LegendComponent, "dds-legend", never, { "visualIndicator": { "alias": "visual-indicator"; "required": false; }; }, {}, never, ["*"], false, never>;
}
