import * as i0 from "@angular/core";
import * as i1 from "./legend.component";
import * as i2 from "@angular/common";
export declare class LegendModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<LegendModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<LegendModule, [typeof i1.LegendComponent], [typeof i2.CommonModule], [typeof i1.LegendComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<LegendModule>;
}
