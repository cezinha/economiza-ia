import { EventEmitter, OnChanges, SimpleChanges } from "@angular/core";
import type { Placement, Size, Localization } from "./loading-indicator.types";
import * as i0 from "@angular/core";
export declare class LoadingIndicatorComponent implements OnChanges {
    size: Size;
    placement: Placement;
    completed: boolean;
    completedText: string;
    completedTimeout: number;
    localization: Localization;
    elevation: boolean;
    hidden: boolean;
    ddsComplete: EventEmitter<any>;
    readonly componentClasses: {
        readonly main: {
            readonly base: "dds__loading-indicator";
            readonly sizes: {
                readonly sm: "dds__loading-indicator--sm";
                readonly md: "dds__loading-indicator--md";
                readonly lg: "dds__loading-indicator--lg";
            };
            readonly labelPlacement: {
                readonly top: "dds__loading-indicator__label--top";
                readonly right: "dds__loading-indicator__label--right";
                readonly left: "dds__loading-indicator__label--left";
                readonly end: "dds__loading-indicator__label--end";
                readonly start: "dds__loading-indicator__label--start";
            };
        };
        readonly overlay: {
            readonly base: "dds__loading-indicator__overlay";
            readonly overflowHidden: "dds__loading-indicator__overlay--overflow-hidden";
            readonly blur: "dds__loading-indicator__overlay--blur";
        };
        readonly spinner: "dds__loading-indicator__spinner";
        readonly label: "dds__loading-indicator__label";
        readonly wrapper: "dds__loading-indicator__wrapper";
        readonly container: "dds__loading-indicator__container";
    };
    readonly mainClasses: {
        "dds__loading-indicator": boolean;
    };
    readonly wrapperClasses: {
        "dds__loading-indicator__wrapper": boolean;
    };
    readonly containerClasses: {
        "dds__loading-indicator__container": boolean;
    };
    readonly labelClasses: {
        "dds__loading-indicator__label": boolean;
    };
    readonly spinnerClass: {
        "dds__loading-indicator__spinner": boolean;
    };
    srCompletedText?: string | null;
    ngOnChanges(changes: SimpleChanges): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<LoadingIndicatorComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<LoadingIndicatorComponent, "dds-loading-indicator", never, { "size": { "alias": "size"; "required": false; }; "placement": { "alias": "placement"; "required": false; }; "completed": { "alias": "completed"; "required": false; }; "completedText": { "alias": "completed-text"; "required": false; }; "completedTimeout": { "alias": "completed-timeout"; "required": false; }; "localization": { "alias": "localization"; "required": false; }; "elevation": { "alias": "elevation"; "required": false; }; "hidden": { "alias": "hidden"; "required": false; }; }, { "ddsComplete": "dds-complete"; }, never, ["*"], false, never>;
}
