import * as i0 from "@angular/core";
import * as i1 from "./loading-indicator.component";
import * as i2 from "@angular/common";
export declare class LoadingIndicatorModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<LoadingIndicatorModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<LoadingIndicatorModule, [typeof i1.LoadingIndicatorComponent], [typeof i2.CommonModule], [typeof i1.LoadingIndicatorComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<LoadingIndicatorModule>;
}
