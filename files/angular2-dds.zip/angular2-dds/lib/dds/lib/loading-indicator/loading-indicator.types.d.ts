export type { Placement, Size, Localization, } from "../../core/components/loading-indicator/loading-indicator.types";
