import { NotificationManagementService } from "../service/notification-management.service";
import * as i0 from "@angular/core";
export declare class NotificationBodyComponent {
    notificationManagementService: NotificationManagementService;
    readonly notificationBodyMessage: {
        dds__notification__message: boolean;
    };
    readonly notificationTimeStampClass: {
        "dds__notification__time-stamp": boolean;
    };
    constructor(notificationManagementService: NotificationManagementService);
    static ɵfac: i0.ɵɵFactoryDeclaration<NotificationBodyComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<NotificationBodyComponent, "dds-notification-body", never, {}, {}, never, ["*"], false, never>;
}
