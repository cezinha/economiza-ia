import * as i0 from "@angular/core";
export declare class NotificationFooterComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<NotificationFooterComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<NotificationFooterComponent, "dds-notification-footer", never, {}, {}, never, ["*"], false, never>;
}
