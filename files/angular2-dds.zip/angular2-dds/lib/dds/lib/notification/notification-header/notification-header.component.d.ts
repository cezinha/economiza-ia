import * as i0 from "@angular/core";
export declare class NotificationHeaderComponent {
    readonly notificationHeaderTitleClass: {
        "dds__notification__header-title": boolean;
    };
    static ɵfac: i0.ɵɵFactoryDeclaration<NotificationHeaderComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<NotificationHeaderComponent, "dds-notification-header", never, {}, {}, never, ["*"], false, never>;
}
