import { EventEmitter, OnInit, SimpleChanges } from "@angular/core";
import { IconName, IconType, Localization, NotificationCloseEvent } from "./notification.types";
import { NotificationManagementService } from "./service/notification-management.service";
import * as i0 from "@angular/core";
export declare class NotificationComponent implements OnInit {
    notificationManagementService: NotificationManagementService;
    closeIcon: boolean;
    iconType: IconType;
    iconName?: IconName;
    timeStamp?: string;
    localization: Localization;
    readonly ddsClose: EventEmitter<NotificationCloseEvent>;
    svgIconName?: string;
    isHidden: boolean;
    readonly notificationClasses: {
        dds__notification: boolean;
    };
    readonly notificationBodyClasses: {
        dds__notification__body: boolean;
    };
    readonly iconClasses: {
        [x: string]: boolean;
        dds__icon: boolean;
        dds__notification__icon: boolean;
    };
    readonly notificationHeaderClass: {
        dds__notification__header: boolean;
    };
    readonly notificationHeaderCloseButtonClasses: {
        dds__button: boolean;
        "dds__button--tertiary": boolean;
        "dds__button--sm": boolean;
        "dds__notification__close-button": boolean;
    };
    readonly notificationHeaderCloseIconClasses: {
        "dds__notification__close-button__icon": boolean;
        dds__icon: boolean;
        "dds__icon--close-x": boolean;
    };
    onClose(): void;
    hide: () => void;
    handleEscape(): void;
    constructor(notificationManagementService: NotificationManagementService);
    ngOnInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<NotificationComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<NotificationComponent, "dds-notification", never, { "closeIcon": { "alias": "close-icon"; "required": false; }; "iconType": { "alias": "icon-type"; "required": false; }; "iconName": { "alias": "icon-name"; "required": false; }; "timeStamp": { "alias": "time-stamp"; "required": false; }; "localization": { "alias": "localization"; "required": false; }; }, { "ddsClose": "dds-close"; }, never, ["dds-notification-header", "dds-notification-body", "dds-notification-footer"], false, never>;
}
