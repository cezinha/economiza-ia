import * as i0 from "@angular/core";
import * as i1 from "./notification.component";
import * as i2 from "./notification-header/notification-header.component";
import * as i3 from "./notification-body/notification-body.component";
import * as i4 from "./notification-footer/notification-footer.component";
import * as i5 from "@angular/common";
export declare class NotificationModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<NotificationModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<NotificationModule, [typeof i1.NotificationComponent, typeof i2.NotificationHeaderComponent, typeof i3.NotificationBodyComponent, typeof i4.NotificationFooterComponent], [typeof i5.CommonModule], [typeof i1.NotificationComponent, typeof i2.NotificationHeaderComponent, typeof i3.NotificationBodyComponent, typeof i4.NotificationFooterComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<NotificationModule>;
}
