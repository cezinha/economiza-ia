import { GenericEvent } from "../abstracts/types/generic-event";
import { NotificationComponent } from "./notification.component";
export { Localization } from "../../core/components/notification/notification.types";
export { Type as IconType, Name as IconName } from "../icon/icon.types";
export type NotificationCloseEvent = GenericEvent<NotificationComponent>;
