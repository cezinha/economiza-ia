import { BehaviorSubject } from "rxjs";
import * as i0 from "@angular/core";
export declare class NotificationManagementService {
    timeStamp$: BehaviorSubject<string>;
    constructor();
    static ɵfac: i0.ɵɵFactoryDeclaration<NotificationManagementService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<NotificationManagementService>;
}
