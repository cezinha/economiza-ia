import { EventEmitter, ElementRef, OnChanges, ChangeDetectorRef, SimpleChanges, AfterViewInit, OnDestroy } from "@angular/core";
import { componentClasses } from "../../core/components/pagination/pagination";
import { DeepReadonly } from "../../core/types/deepreadonly";
import { componentClasses as iconClasses } from "../../core/components/icon/icon";
import { componentClasses as buttonClasses } from "../../core/components/button/button";
import { PaginationEvent, PageSizeOption, Localization } from "./pagination.types";
import * as i0 from "@angular/core";
export declare class PaginationComponent implements OnChanges, AfterViewInit, OnDestroy {
    private changeDetector;
    componentName: string;
    readonly componentClasses: DeepReadonly<typeof componentClasses>;
    readonly iconClasses: DeepReadonly<typeof iconClasses>;
    readonly buttonClasses: DeepReadonly<typeof buttonClasses>;
    readonly selectInputClasses: {
        readonly basic: "dds__select";
        readonly placeholder: "dds__select--placeholder";
        readonly wrapper: "dds__select__wrapper";
        readonly field: "dds__select__field";
        readonly optionPlaceholder: "dds__select__option--placeholder";
        readonly helperText: "dds__select__helper";
        readonly chevronIcon: "dds__select__chevron";
        readonly feedbackIcon: "dds__select__feedback__icon";
        readonly errorText: "dds__invalid-feedback";
        readonly isInvalid: "dds__is--invalid";
        readonly sizes: {
            readonly sm: "dds__select--sm";
            readonly lg: "";
        };
    };
    readonly paginationId: string;
    readonly paginationSelectId: string;
    readonly paginationInputId: string;
    readonly paginationSrId: string;
    private observer?;
    srInputDescription: string;
    readonly perPageSelectClass: {
        "dds__pagination__per-page-select": boolean;
        dds__select: boolean;
        "dds__select--sm": boolean;
    };
    readonly selectIconClasses: {
        dds__icon: boolean;
        dds__select__chevron: boolean;
    };
    readonly inputWrapperClasses: {
        "dds__input-text__container": boolean;
        "dds__input-text__container--sm": boolean;
    };
    readonly navButtonClasses: {
        dds__button: boolean;
        "dds__button--tertiary": boolean;
        "dds__button--sm": boolean;
    };
    readonly navNextClasses: {
        "dds__pagination__next-page": boolean;
        dds__button: boolean;
        "dds__button--tertiary": boolean;
        "dds__button--sm": boolean;
    };
    readonly navPrevClasses: {
        "dds__pagination__prev-page": boolean;
        dds__button: boolean;
        "dds__button--tertiary": boolean;
        "dds__button--sm": boolean;
    };
    readonly navFirstClasses: {
        "dds__pagination__first-page": boolean;
        dds__button__icon: boolean;
        dds__button: boolean;
        "dds__button--tertiary": boolean;
        "dds__button--sm": boolean;
    };
    readonly navLastClasses: {
        "dds__pagination__last-page": boolean;
        dds__button__icon: boolean;
        dds__button: boolean;
        "dds__button--tertiary": boolean;
        "dds__button--sm": boolean;
    };
    readonly pageRangeClasses: {
        "dds__input-text__wrapper": boolean;
        "dds__pagination__page-range-current-wrapper": boolean;
    };
    readonly currentPageClasses: {
        "dds__input-text": boolean;
        "dds__pagination__page-range-current": boolean;
    };
    readonly state: {
        totalPages: number;
        itemsRangeStart: number;
        itemsRangeEnd: number;
        isFirstPage: boolean;
        isLastPage: boolean;
        hasNextPage: boolean;
        hasPrevPage: boolean;
    };
    pageSize: number;
    pageSizeChange: EventEmitter<number>;
    isPageSizeOption(option: any): option is PageSizeOption;
    localization: Localization;
    pageSizeOptions: (PageSizeOption | number)[];
    _totalItems: number;
    set totalItems(value: number);
    get totalItems(): number;
    currentPage: number;
    currentPageChange: EventEmitter<number>;
    ddsNextPage: EventEmitter<PaginationEvent>;
    ddsPrevPage: EventEmitter<PaginationEvent>;
    ddsLastPage: EventEmitter<PaginationEvent>;
    ddsFirstPage: EventEmitter<PaginationEvent>;
    ddsPageChange: EventEmitter<PaginationEvent>;
    ddsPageSizeChange: EventEmitter<PaginationEvent>;
    pageSizeSelectEl: ElementRef;
    currentPageEl: ElementRef;
    wrapperEl: ElementRef;
    wrapperClasses: {
        dds__pagination: boolean;
    };
    private getTotalPages;
    private sanitizeCurrentPage;
    private updateState;
    handleUpdatePageSize($event: Event): void;
    handlePaginationResize: (changes: ResizeObserverEntry[]) => void;
    private debouncedResize;
    handleCurrentPageInput($event: Event | KeyboardEvent): void;
    nextPage(): void;
    previousPage(): void;
    lastPage(): void;
    firstPage(): void;
    constructor(changeDetector: ChangeDetectorRef);
    ngOnChanges(changes: SimpleChanges): void;
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<PaginationComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PaginationComponent, "dds-pagination", never, { "pageSize": { "alias": "page-size"; "required": false; }; "localization": { "alias": "localization"; "required": false; }; "pageSizeOptions": { "alias": "page-size-options"; "required": false; }; "totalItems": { "alias": "total-items"; "required": false; }; "currentPage": { "alias": "current-page"; "required": false; }; }, { "pageSizeChange": "page-sizeChange"; "currentPageChange": "current-pageChange"; "ddsNextPage": "dds-next-page"; "ddsPrevPage": "dds-prev-page"; "ddsLastPage": "dds-last-page"; "ddsFirstPage": "dds-first-page"; "ddsPageChange": "dds-page-change"; "ddsPageSizeChange": "dds-page-size-change"; }, never, never, false, never>;
}
