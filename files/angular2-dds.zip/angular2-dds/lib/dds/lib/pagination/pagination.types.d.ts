import { PaginationComponent } from "./pagination.component";
export { Localization } from "../../core/components/pagination/pagination";
export type PaginationEvent = {
    target: PaginationComponent;
    action: string;
};
export type PageSizeOption = {
    value: number;
    selected?: boolean;
};
