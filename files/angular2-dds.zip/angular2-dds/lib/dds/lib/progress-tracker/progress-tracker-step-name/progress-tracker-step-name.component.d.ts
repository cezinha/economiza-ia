import * as i0 from "@angular/core";
export declare class ProgressTrackerStepNameComponent {
    class: "dds__progress-tracker__step-name";
    static ɵfac: i0.ɵɵFactoryDeclaration<ProgressTrackerStepNameComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ProgressTrackerStepNameComponent, "dds-progress-tracker-step-name", never, {}, {}, never, ["*"], false, never>;
}
