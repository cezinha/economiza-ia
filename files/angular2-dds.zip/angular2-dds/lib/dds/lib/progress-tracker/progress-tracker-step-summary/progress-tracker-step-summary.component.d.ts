import * as i0 from "@angular/core";
export declare class ProgressTrackerStepSummaryComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<ProgressTrackerStepSummaryComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ProgressTrackerStepSummaryComponent, "dds-progress-tracker-step-summary", never, {}, {}, never, ["*"], false, never>;
}
