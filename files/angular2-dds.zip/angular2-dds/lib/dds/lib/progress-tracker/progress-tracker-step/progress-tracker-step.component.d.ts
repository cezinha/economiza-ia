import { OnChanges, SimpleChanges } from "@angular/core";
import { Status } from "../progress-tracker.types";
import { ProgressTrackerService } from "../service/progress-tracker.service";
import * as i0 from "@angular/core";
export declare class ProgressTrackerStepComponent implements OnChanges {
    readonly service: ProgressTrackerService;
    constructor(service: ProgressTrackerService);
    status: Status;
    readonly iconClasses: {
        "dds__progress-tracker__icon": boolean;
    };
    readonly circleClasses: {
        "dds__progress-tracker__circle": boolean;
    };
    readonly contentClasses: {
        "dds__progress-tracker__content": boolean;
    };
    readonly role = "listitem";
    current: boolean;
    get stepClasses(): {
        "dds__progress-tracker__item": boolean;
        "dds__progress-tracker--in-progress": boolean;
        "dds__progress-tracker--complete": boolean;
        "dds__progress-tracker--active": boolean;
    };
    get ariaLabel(): string | null | undefined;
    ngOnChanges(changes: SimpleChanges): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ProgressTrackerStepComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ProgressTrackerStepComponent, "dds-progress-tracker-step", never, { "status": { "alias": "status"; "required": false; }; }, {}, never, ["*"], false, never>;
}
