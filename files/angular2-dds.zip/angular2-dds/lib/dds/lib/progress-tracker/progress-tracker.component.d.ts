import { OnChanges, SimpleChanges } from "@angular/core";
import type { Alignment, Size, Localization } from "./progress-tracker.types";
import { ProgressTrackerService } from "./service/progress-tracker.service";
import * as i0 from "@angular/core";
export declare class ProgressTrackerComponent implements OnChanges {
    private readonly progressTrackerService;
    constructor(progressTrackerService: ProgressTrackerService);
    alignment: Alignment;
    size: Size;
    localization: Localization;
    readonly componentClasses: {
        readonly base: "dds__progress-tracker";
        readonly vertical: "dds__progress-tracker--vertical";
        readonly small: "dds__progress-tracker--sm";
        readonly item: {
            readonly base: "dds__progress-tracker__item";
            readonly inProgress: "dds__progress-tracker--in-progress";
            readonly complete: "dds__progress-tracker--complete";
            readonly active: "dds__progress-tracker--active";
            readonly circle: "dds__progress-tracker__circle";
            readonly icon: "dds__progress-tracker__icon";
            readonly content: "dds__progress-tracker__content";
            readonly stepName: "dds__progress-tracker__step-name";
        };
    };
    readonly wrapperClasses: {
        "dds__progress-tracker": boolean;
        "dds__progress-tracker--vertical": boolean;
        "dds__progress-tracker--sm": boolean;
    };
    ngOnChanges(changes: SimpleChanges): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ProgressTrackerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ProgressTrackerComponent, "dds-progress-tracker", never, { "alignment": { "alias": "alignment"; "required": false; }; "size": { "alias": "size"; "required": false; }; "localization": { "alias": "localization"; "required": false; }; }, {}, never, ["dds-progress-tracker-step"], false, never>;
}
