import * as i0 from "@angular/core";
import * as i1 from "./progress-tracker.component";
import * as i2 from "./progress-tracker-step/progress-tracker-step.component";
import * as i3 from "./progress-tracker-step-name/progress-tracker-step-name.component";
import * as i4 from "./progress-tracker-step-summary/progress-tracker-step-summary.component";
import * as i5 from "@angular/common";
export declare class ProgressTrackerModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ProgressTrackerModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ProgressTrackerModule, [typeof i1.ProgressTrackerComponent, typeof i2.ProgressTrackerStepComponent, typeof i3.ProgressTrackerStepNameComponent, typeof i4.ProgressTrackerStepSummaryComponent], [typeof i5.CommonModule], [typeof i1.ProgressTrackerComponent, typeof i2.ProgressTrackerStepComponent, typeof i3.ProgressTrackerStepNameComponent, typeof i4.ProgressTrackerStepSummaryComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ProgressTrackerModule>;
}
