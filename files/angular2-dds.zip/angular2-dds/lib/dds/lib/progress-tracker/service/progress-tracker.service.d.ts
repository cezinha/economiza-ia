import { BehaviorSubject } from "rxjs";
import { Localization } from "../progress-tracker.types";
import * as i0 from "@angular/core";
export declare class ProgressTrackerService {
    localization$: BehaviorSubject<Localization>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ProgressTrackerService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ProgressTrackerService>;
}
