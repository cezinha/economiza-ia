import { SimpleChanges, OnChanges } from "@angular/core";
import { FormField } from "../abstracts/form-field/form-field.component";
import * as i0 from "@angular/core";
export declare class RadioButtonComponent extends FormField<string> implements OnChanges {
    componentName: string;
    readonly componentClasses: {
        base: "dds__radio-button";
        errorText: "dds__invalid-feedback";
        errorIcon: "dds__radio-button__error-text";
        group: "dds__radio-button-group";
        fieldset: {
            readonly base: "dds__fieldset";
            readonly alignment: {
                readonly horizontal: "dds__fieldset--inline";
            };
            readonly size: {
                readonly lg: "";
                readonly sm: "dds__fieldset--sm";
            };
        };
        input: "dds__radio-button__input";
        isInvalid: "dds__is--invalid";
        label: "dds__radio-button__label";
        size: {
            readonly lg: "";
            readonly sm: "dds__radio-button--sm";
        };
        visualIndicator: "dds__visual-indicator";
    };
    checked: boolean;
    value: string;
    readonly containerClass: {
        "dds__radio-button": boolean;
        "dds__radio-button--sm": boolean;
    };
    readonly externalFocus: {
        "dds__radio-button--focus-visible": boolean;
    };
    /**
     * This method is called when the user clicks on the radio button
     * It's public because the template has to access it but it's not part of the API
     * @private
     */
    handleChange(): void;
    writeValue(value: string): void;
    ngOnChanges(changes: SimpleChanges): void;
    handleFocus(event: Event): void;
    handleBlur($event: FocusEvent): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<RadioButtonComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<RadioButtonComponent, "dds-radio-button", never, { "checked": { "alias": "checked"; "required": false; }; "value": { "alias": "value"; "required": false; }; }, {}, never, ["dds-label"], false, never>;
}
