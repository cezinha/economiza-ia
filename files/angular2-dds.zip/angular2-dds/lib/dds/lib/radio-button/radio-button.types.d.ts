export type { Size, Alignment } from "../../core/components/radio-button/radio-button.types";
export interface RadioButtonValidationEvent<T> {
    target: T;
}
