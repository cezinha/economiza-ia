import { BehaviorSubject } from "rxjs";
import * as i0 from "@angular/core";
export declare class SideNavService {
    readonly id: string;
    itemSelected$: BehaviorSubject<HTMLElement | undefined>;
    static ɵfac: i0.ɵɵFactoryDeclaration<SideNavService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<SideNavService>;
}
