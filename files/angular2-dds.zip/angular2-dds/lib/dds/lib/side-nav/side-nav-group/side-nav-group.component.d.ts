import { ElementRef, EventEmitter, OnChanges, OnDestroy, SimpleChanges } from "@angular/core";
import { IconType, IconName } from "./../side-nav.types";
import { SideNavService } from "../service/side-nav.service";
import { RouterLinkActive } from "@angular/router";
import * as i0 from "@angular/core";
export declare class SideNavGroupComponent implements OnChanges, OnDestroy {
    sideNavService: SideNavService;
    private routerLinkActive;
    isExpanded: boolean;
    private itemSubscription?;
    private routerLinkActiveSubscription?;
    label: string;
    iconName: IconName | undefined;
    iconType: IconType;
    expanded: boolean;
    groupClickedEvent: EventEmitter<boolean>;
    groupItem: ElementRef<HTMLElement>;
    private _selected;
    menuClasses: {
        "dds__side-nav__menu": boolean;
        dds__collapse: boolean;
    };
    groupClasses: {
        "dds__side-nav__group": boolean;
        "dds__side-nav__group--selected": boolean;
    };
    readonly componentClasses: {
        readonly base: "dds__side-nav";
        readonly menu: "dds__side-nav__menu";
        readonly toggle: "dds__side-nav__toggle";
        readonly wrapper: "dds__side-nav__wrapper";
        readonly fixed: "dds__side-nav__wrapper--fixed";
        readonly toggleButton: "dds__side-nav__toggle > button";
        readonly icon: "dds__side-nav__icon";
    };
    readonly iconClasses: {
        dds__icon: boolean;
        "dds__side-nav__group__chevron": boolean;
    };
    handleGroupClick(): void;
    ngOnChanges(changes: SimpleChanges): void;
    ngOnDestroy(): void;
    updateSelectedAndExpandedState(selected: boolean): void;
    constructor(sideNavService: SideNavService, routerLinkActive: RouterLinkActive);
    static ɵfac: i0.ɵɵFactoryDeclaration<SideNavGroupComponent, [null, { optional: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SideNavGroupComponent, "dds-side-nav-group", never, { "label": { "alias": "label"; "required": false; }; "iconName": { "alias": "icon-name"; "required": false; }; "iconType": { "alias": "icon-type"; "required": false; }; "expanded": { "alias": "expanded"; "required": false; }; }, { "groupClickedEvent": "groupClickedEvent"; }, never, ["*"], false, never>;
}
