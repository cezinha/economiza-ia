import { ElementRef, OnChanges, OnDestroy, OnInit, Renderer2, SimpleChanges } from "@angular/core";
import { SideNavService } from "../service/side-nav.service";
import { IconName } from "./../side-nav.types";
import { IsActiveMatchOptions, Router, RouterLinkActive } from "@angular/router";
import { Subscription } from "rxjs";
import * as i0 from "@angular/core";
export declare class SideNavItemComponent implements OnChanges, OnInit, OnDestroy {
    sideNavService: SideNavService;
    private ref;
    private renderer;
    private router;
    private routerLinkActive;
    routerSubscription?: Subscription;
    private routerLinkActiveSubscription?;
    private itemSubscription?;
    constructor(sideNavService: SideNavService, ref: ElementRef, renderer: Renderer2, router: Router, routerLinkActive: RouterLinkActive);
    ngOnInit(): void;
    itemId: string;
    componentClasses: {
        readonly base: "dds__side-nav";
        readonly menu: "dds__side-nav__menu";
        readonly toggle: "dds__side-nav__toggle";
        readonly wrapper: "dds__side-nav__wrapper";
        readonly fixed: "dds__side-nav__wrapper--fixed";
        readonly toggleButton: "dds__side-nav__toggle > button";
        readonly icon: "dds__side-nav__icon";
    };
    routeMatchOptions: IsActiveMatchOptions;
    iconName: IconName | undefined;
    iconType: "font-icon" | "svg";
    selected: boolean;
    menuitem: ElementRef<HTMLElement>;
    selectedClasses: {
        "dds__side-nav__item--selected": boolean;
        "dds__side-nav__item": boolean;
    };
    readonly iconClasses: {
        "dds__side-nav__icon": boolean;
    };
    updateSelectedState(selected: boolean): void;
    handleClick(): void;
    ngOnDestroy(): void;
    ngOnChanges(changes: SimpleChanges): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SideNavItemComponent, [null, null, null, { optional: true; }, { optional: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SideNavItemComponent, "dds-side-nav-item", never, { "routeMatchOptions": { "alias": "match-route"; "required": false; }; "iconName": { "alias": "icon-name"; "required": false; }; "iconType": { "alias": "icon-type"; "required": false; }; "selected": { "alias": "selected"; "required": false; }; }, {}, never, ["*"], false, never>;
}
