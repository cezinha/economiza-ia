import { EventEmitter, OnChanges, OnInit, QueryList, SimpleChanges } from "@angular/core";
import { Localization, SideNavEvent } from "./side-nav.types";
import { SideNavGroupComponent } from "./side-nav-group/side-nav-group.component";
import { SideNavService } from "./service/side-nav.service";
import * as i0 from "@angular/core";
export declare class SideNavComponent implements OnChanges, OnInit {
    private sideNavService;
    constructor(sideNavService: SideNavService);
    componentClasses: {
        readonly base: "dds__side-nav";
        readonly menu: "dds__side-nav__menu";
        readonly toggle: "dds__side-nav__toggle";
        readonly wrapper: "dds__side-nav__wrapper";
        readonly fixed: "dds__side-nav__wrapper--fixed";
        readonly toggleButton: "dds__side-nav__toggle > button";
        readonly icon: "dds__side-nav__icon";
    };
    readonly sideNavId: string;
    navExpanded: boolean;
    localization: Localization;
    fixed: boolean;
    expanded: boolean;
    ddsCollapsed: EventEmitter<SideNavEvent<SideNavComponent>>;
    ddsExpanded: EventEmitter<SideNavEvent<SideNavComponent>>;
    groups: QueryList<SideNavGroupComponent> | undefined;
    readonly wrapperClassess: {
        "dds__side-nav__wrapper": boolean;
        "dds__side-nav__wrapper--fixed": boolean;
    };
    readonly srClass: {
        "dds__sr-only": boolean;
    };
    readonly sideNavClassess: {
        "dds__side-nav": boolean;
    };
    readonly toggleClassess: {
        "dds__side-nav__toggle": boolean;
    };
    readonly expandClasses: {
        [x: string]: boolean;
        dds__icon: boolean;
        "dds__icon--chevron-right": boolean;
    };
    readonly collapseClasses: {
        [x: string]: boolean;
        dds__icon: boolean;
        "dds__icon--chevron-left": boolean;
    };
    navToggle(): void;
    navExpandedHandler(): void;
    collapseAllGroups(): void;
    private windowResizeHandler;
    ngOnInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SideNavComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SideNavComponent, "dds-side-nav", never, { "localization": { "alias": "localization"; "required": false; }; "fixed": { "alias": "fixed"; "required": false; }; "expanded": { "alias": "expanded"; "required": false; }; }, { "ddsCollapsed": "dds-collapsed"; "ddsExpanded": "dds-expanded"; }, ["groups"], ["*"], false, never>;
}
