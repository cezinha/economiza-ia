import * as i0 from "@angular/core";
import * as i1 from "./side-nav.component";
import * as i2 from "./side-nav-item/side-nav-item.component";
import * as i3 from "./side-nav-group/side-nav-group.component";
import * as i4 from "@angular/common";
import * as i5 from "../icon/icon.module";
export declare class SideNavModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<SideNavModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<SideNavModule, [typeof i1.SideNavComponent, typeof i2.SideNavItemComponent, typeof i3.SideNavGroupComponent], [typeof i4.CommonModule, typeof i5.IconModule], [typeof i1.SideNavComponent, typeof i2.SideNavItemComponent, typeof i3.SideNavGroupComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<SideNavModule>;
}
