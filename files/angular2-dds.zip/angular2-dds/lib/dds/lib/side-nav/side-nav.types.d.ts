export type { Name as IconName, Type as IconType } from "../icon/icon.types";
export { Localization } from "../../core/components/side-nav/side-nav.types";
export type SideNavEvent<T> = {
    target: T;
};
