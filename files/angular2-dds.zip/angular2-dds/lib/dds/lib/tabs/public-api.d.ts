export * from "./tabs.component";
export * from "./tabs.module";
export * from "./tabs-header/tabs-header.component";
export * from "./tab-label/tab-label.component";
export * from "./tabs-body/tabs-body.component";
export * from "./tab-panel/tab-panel.component";
