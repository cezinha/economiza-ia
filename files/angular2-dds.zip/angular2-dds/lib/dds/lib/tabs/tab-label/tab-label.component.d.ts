import { AfterViewInit, ElementRef, OnInit, SimpleChanges } from "@angular/core";
import { TabsManagementService } from "../services/tabs-management.service";
import { IconName, IconPlacement, IconType, BadgeColor } from "../tabs.types";
import * as i0 from "@angular/core";
export declare class TabLabelComponent implements OnInit, AfterViewInit {
    ref: ElementRef;
    tabsService: TabsManagementService;
    activeTabIndex: number;
    labelTotalNumber: number;
    labelId: string;
    panelId: string;
    isMobileStacked: boolean;
    index: number;
    selected: boolean;
    iconType: IconType;
    iconName?: IconName;
    iconPlacement: IconPlacement;
    badgeText?: string;
    badgeColor: BadgeColor;
    hasFontIconStart: boolean;
    hasSvgIconStart: boolean;
    hasFontIconEnd: boolean;
    hasSvgIconEnd: boolean;
    svgIconName: string;
    isHidden: boolean;
    label: string;
    tabButton: ElementRef;
    constructor(ref: ElementRef, tabsService: TabsManagementService);
    readonly tabButtonClasses: {
        dds__tabs__tab: boolean;
    };
    readonly tabButtonLabelClasses: {
        dds__tabs__tab__label: boolean;
    };
    iconClasses: Record<string, boolean>;
    ngOnInit(): void;
    ngAfterViewInit(): void;
    private updateIconClasses;
    ngOnChanges(changes: SimpleChanges): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<TabLabelComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<TabLabelComponent, "dds-tab-label", never, { "index": { "alias": "index"; "required": false; }; "selected": { "alias": "selected"; "required": false; }; "iconType": { "alias": "icon-type"; "required": false; }; "iconName": { "alias": "icon-name"; "required": false; }; "iconPlacement": { "alias": "icon-placement"; "required": false; }; "badgeText": { "alias": "badge-text"; "required": false; }; "badgeColor": { "alias": "badge-color"; "required": false; }; }, {}, never, ["*"], false, never>;
}
