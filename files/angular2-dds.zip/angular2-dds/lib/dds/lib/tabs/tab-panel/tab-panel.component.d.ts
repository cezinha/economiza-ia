import { ElementRef, OnInit, SimpleChanges } from "@angular/core";
import { TabsManagementService } from "../services/tabs-management.service";
import { BadgeColor } from "../tabs.types";
import * as i0 from "@angular/core";
export declare class TabPanelComponent implements OnInit {
    private ref;
    tabsService: TabsManagementService;
    panelId: string;
    labelId: string;
    isHidden: boolean;
    isMobileStacked: boolean;
    tabLabel: string;
    hasFontIconStart: boolean;
    hasSvgIconStart: boolean;
    hasFontIconEnd: boolean;
    hasSvgIconEnd: boolean;
    iconClasses: {};
    svgIconName: string;
    badgeText: string;
    badgeColor: BadgeColor;
    index: number;
    readonly panelClasses: {
        dds__tabs__pane: boolean;
    };
    readonly headerPanelClasses: {
        dds__tabs__pane__header: boolean;
    };
    readonly contentPanelClasses: {
        dds__tabs__pane__content: boolean;
    };
    panelWrapperEl: ElementRef;
    constructor(ref: ElementRef, tabsService: TabsManagementService);
    onClick(): void;
    ngOnInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<TabPanelComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<TabPanelComponent, "dds-tab-panel", never, { "index": { "alias": "index"; "required": false; }; }, {}, never, ["*"], false, never>;
}
