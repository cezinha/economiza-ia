import { QueryList } from "@angular/core";
import { TabPanelComponent } from "../public-api";
import * as i0 from "@angular/core";
export declare class TabsBodyComponent {
    readonly bodyClasses: {
        "dds__tabs__pane-container": boolean;
    };
    tabPanels: QueryList<TabPanelComponent>;
    static ɵfac: i0.ɵɵFactoryDeclaration<TabsBodyComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<TabsBodyComponent, "dds-tabs-body", never, {}, {}, ["tabPanels"], ["dds-tab-panel"], false, never>;
}
