import { AfterViewInit, ChangeDetectorRef, ElementRef, OnDestroy } from "@angular/core";
import { TabsManagementService } from "../services/tabs-management.service";
import { Orientation } from "../tabs.types";
import * as i0 from "@angular/core";
export type HiddenTab = {
    index: number;
    label: string;
};
export declare class TabsHeaderComponent implements AfterViewInit, OnDestroy {
    tabsService: TabsManagementService;
    ref: ElementRef;
    private changeDetector;
    tabsOrientation: Orientation;
    tabsOverflow: boolean;
    previousTabsOverflow: boolean;
    hiddenTabs: HiddenTab[];
    startIndex: number;
    overflowButtonFocused: boolean;
    closeOnMoreItemClick: any;
    readonly overflowId: string;
    private observer?;
    readonly headerClasses: {
        "dds__tabs__list-container": boolean;
    };
    readonly headerTabListClasses: {
        dds__tabs__list: boolean;
    };
    readonly overflowWrapperClass: {
        "dds__tabs__more-wrapper": boolean;
    };
    readonly overflowButtonClass: {
        dds__tabs__more: boolean;
    };
    readonly overflowButtonIconClasses: {
        dds__icon: boolean;
        dds__tabs__more__icon: boolean;
    };
    tabLabels: import("@angular/core").Signal<readonly any[]>;
    button: ElementRef;
    wrapperEl: ElementRef;
    prevTabLabelsLength: number;
    constructor(tabsService: TabsManagementService, ref: ElementRef, changeDetector: ChangeDetectorRef);
    overflowCalculation: () => void;
    getAriaSelected(): boolean;
    onLeftRightKeydown(event: KeyboardEvent): void;
    onUpDownKeydown(event: KeyboardEvent): void;
    handleEnter(): void;
    handleHome(event: Event): void;
    handleEnd(event: Event): void;
    onMouseDown(): void;
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<TabsHeaderComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<TabsHeaderComponent, "dds-tabs-header", never, {}, {}, ["tabLabels"], ["dds-tab-label"], false, never>;
}
