import { EventEmitter, OnChanges, SimpleChanges } from "@angular/core";
import { TabsManagementService } from "./services/tabs-management.service";
import { Kind, Orientation, Mobile, Localization } from "./tabs.types";
import * as i0 from "@angular/core";
export type TabsOpenEvent = {
    target: TabsComponent;
    activeTab: number;
};
export type TabsCloseEvent = {
    target: TabsComponent;
};
export declare class TabsComponent implements OnChanges {
    private tabsService;
    activeTab: number;
    kind: Kind;
    orientation: Orientation;
    mobile: Mobile;
    closeOnMoreItemClick: boolean;
    localization: Localization;
    isMobile(): boolean;
    isMobileStacked(): boolean;
    readonly ddsOpen: EventEmitter<TabsOpenEvent>;
    readonly ddsClose: EventEmitter<TabsCloseEvent>;
    readonly tabsClasses: {
        dds__tabs: boolean;
    };
    constructor(tabsService: TabsManagementService);
    ngOnInit(): void;
    onResize(): void;
    ngOnChanges(changes: SimpleChanges): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<TabsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<TabsComponent, "dds-tabs", never, { "activeTab": { "alias": "active-tab"; "required": false; }; "kind": { "alias": "kind"; "required": false; }; "orientation": { "alias": "orientation"; "required": false; }; "mobile": { "alias": "mobile"; "required": false; }; "closeOnMoreItemClick": { "alias": "close-on-more-item-click"; "required": false; }; "localization": { "alias": "localization"; "required": false; }; }, { "ddsOpen": "dds-open"; "ddsClose": "dds-close"; }, never, ["dds-tabs-header", "dds-tabs-body"], false, never>;
}
