import * as i0 from "@angular/core";
import * as i1 from "./tabs.component";
import * as i2 from "./tabs-header/tabs-header.component";
import * as i3 from "./tab-label/tab-label.component";
import * as i4 from "./tabs-body/tabs-body.component";
import * as i5 from "./tab-panel/tab-panel.component";
import * as i6 from "@angular/common";
import * as i7 from "../action-menu/action-menu.module";
import * as i8 from "../badge/badge.module";
export declare class TabsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<TabsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<TabsModule, [typeof i1.TabsComponent, typeof i2.TabsHeaderComponent, typeof i3.TabLabelComponent, typeof i4.TabsBodyComponent, typeof i5.TabPanelComponent], [typeof i6.CommonModule, typeof i7.ActionMenuModule, typeof i8.BadgeModule], [typeof i1.TabsComponent, typeof i2.TabsHeaderComponent, typeof i3.TabLabelComponent, typeof i4.TabsBodyComponent, typeof i5.TabPanelComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<TabsModule>;
}
