export { Kind, Orientation, Mobile, Localization } from "../../core/components/tabs/tabs.types";
export { Name as IconName, Type as IconType } from "../icon/icon.types";
export { IconPlacement } from "../button/button.types";
export { Color as BadgeColor } from "../badge/badge.types";
