export * from "./text-area-counter/public-api";
export * from "./text-area.component";
export * from "./text-area.module";
