export * from "./text-area-counter.component";
export * from "./text-area-counter.module";
