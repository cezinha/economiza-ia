import { componentClasses } from "../../../core/components/text-area/text-area";
import { DeepReadonly } from "../../../core/types/deepreadonly";
import { Localization } from "../../../core/components/text-area/text-area.types";
import * as i0 from "@angular/core";
export declare class TextAreaCounterComponent {
    readonly textareaClasses: DeepReadonly<typeof componentClasses>;
    separator: string;
    max: number;
    localization: Localization;
    remaining: number;
    excess: number;
    srMessage?: string | undefined;
    srAriaLive?: string | undefined;
    readonly externalWrapperClass: {
        "dds__text-area__counter": boolean;
        dds__error: boolean;
    };
    private _value;
    set value(value: number);
    get value(): number;
    static ɵfac: i0.ɵɵFactoryDeclaration<TextAreaCounterComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<TextAreaCounterComponent, "dds-textarea-counter", never, { "separator": { "alias": "separator"; "required": false; }; "max": { "alias": "max"; "required": false; }; "localization": { "alias": "localization"; "required": false; }; "value": { "alias": "value"; "required": false; }; }, {}, never, never, false, never>;
}
