import * as i0 from "@angular/core";
import * as i1 from "./text-area-counter.component";
import * as i2 from "@angular/common";
export declare class TextAreaCounterModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<TextAreaCounterModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<TextAreaCounterModule, [typeof i1.TextAreaCounterComponent], [typeof i2.CommonModule], [typeof i1.TextAreaCounterComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<TextAreaCounterModule>;
}
