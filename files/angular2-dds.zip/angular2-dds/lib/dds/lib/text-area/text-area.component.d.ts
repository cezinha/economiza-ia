import { AfterContentInit, OnChanges, SimpleChanges } from "@angular/core";
import { FormField } from "../abstracts/form-field/form-field.component";
import { TextAreaCounterComponent } from "./text-area-counter/text-area-counter.component";
import * as i0 from "@angular/core";
export declare class TextAreaComponent extends FormField<string> implements AfterContentInit, OnChanges {
    readonly componentClasses: {
        readonly basic: "dds__text-area";
        readonly wrapper: "dds__text-area__wrapper";
        readonly counter: "dds__text-area__counter";
        readonly counterCurrent: "dds__current-value";
        readonly validated: "dds__text-area--validated";
        readonly sr: "dds__text-area__sr";
        readonly errorText: "dds__invalid-feedback";
        readonly error: "dds__error";
        readonly errorIcon: "dds__input-text__icon--end";
        readonly header: "dds__text-area__header"; /**
         * @deprecated
         * @use minlength
         */
        readonly helper: "dds__input-text__helper";
        readonly isInvalid: "dds__is--invalid";
        readonly container: {
            readonly base: "dds__text-area__container";
            readonly sm: "dds__text-area__container--sm";
        };
    };
    private _softInvalid;
    get softInvalid(): boolean;
    /**
     * Used to bind the container classes.
     * It gets updated inside ngOnChanges and ngAfterViewInit
     */
    readonly containerClasses: {
        "dds__text-area__container": boolean;
        "dds__text-area__container--sm": boolean;
        "dds__text-area--validated": boolean;
    };
    value: string;
    minlength?: number;
    maxlength?: number;
    placeholder?: string;
    rows: number;
    cols?: number;
    pattern?: string;
    /**
     * @deprecated
     * @use minlength
     */
    set minLength(value: number);
    /**
     * @deprecated
     * @use maxlength
     */
    set maxLength(value: number);
    ddsCounter: TextAreaCounterComponent;
    /**
     * Updates the counter value and triggers validation
     * @param value
     * @private
     */
    private updateCounter;
    /**
     * It handles the value of describedBy attribute in the textarea by checking the
     * invalid state and the presence of dds-error and dds-helper components.
     */
    handleAriaDescribedBy(): void;
    /**
     * Handle changes in the textarea and run validation in the case
     * the component has already started it.
     * The function is public because the template needs to access it but it's
     * marked as private to avoid external calls.
     * @private
     */
    handleInput(): void;
    /**
     * Handle sync changes on control/model and the value attribute
     */
    updateViewFromExternalControl(newValue: string): void;
    /**
     * Handle validation and update the container classes.
     * It's invoked by from FormFieldComponent and the super method
     * should be called in order to run the default validation in adddition
     * to the custom one
     * @protected
     */
    handleValidation(status: string | null): void;
    /**
     * Reset the counter when form resets
     * It's invoked by from FormFieldComponent and the super method
     * @protected
     */
    handleReset(): void;
    ngAfterContentInit(): void;
    /**
     * Updates the size when input is provided
     */
    ngOnChanges(changes: SimpleChanges): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<TextAreaComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<TextAreaComponent, "dds-textarea", never, { "value": { "alias": "value"; "required": false; }; "minlength": { "alias": "minlength"; "required": false; }; "maxlength": { "alias": "maxlength"; "required": false; }; "placeholder": { "alias": "placeholder"; "required": false; }; "rows": { "alias": "rows"; "required": false; }; "cols": { "alias": "cols"; "required": false; }; "pattern": { "alias": "pattern"; "required": false; }; "minLength": { "alias": "min-length"; "required": false; }; "maxLength": { "alias": "max-length"; "required": false; }; }, {}, ["ddsCounter"], ["dds-label", "dds-helper", "dds-error", "dds-textarea-counter"], false, never>;
}
