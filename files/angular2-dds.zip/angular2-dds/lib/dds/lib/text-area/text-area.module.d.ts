import * as i0 from "@angular/core";
import * as i1 from "./text-area.component";
import * as i2 from "@angular/common";
import * as i3 from "@angular/forms";
import * as i4 from "../abstracts/form-field/form-field.component";
import * as i5 from "./text-area-counter/text-area-counter.module";
export declare class TextAreaModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<TextAreaModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<TextAreaModule, [typeof i1.TextAreaComponent], [typeof i2.CommonModule, typeof i3.FormsModule, typeof i3.ReactiveFormsModule, typeof i4.FormFieldModule], [typeof i1.TextAreaComponent, typeof i5.TextAreaCounterModule]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<TextAreaModule>;
}
