import { ChangeDetectorRef, ElementRef, OnDestroy } from "@angular/core";
import { Time } from "../../../core/js/time/time";
import { TimepickerService } from "../services/timepicker.service";
import * as i0 from "@angular/core";
export declare class DropdownListItemComponent implements OnDestroy {
    private ref;
    private service;
    private cd;
    readonly componentClasses: {
        base: "dds__time-picker";
        sizes: {
            readonly sm: "dds__time-picker--sm";
            readonly lg: "";
        };
        invalid: "dds__time-picker--invalid";
        invalidFeedback: "dds__time-picker__invalid-feedback";
        input: {
            readonly container: "dds__time-picker__input-container";
            readonly wrapper: "dds__time-picker__input-wrapper";
            readonly field: "dds__time-picker__input";
        };
        iconsWrapper: "dds__time-picker__icons-wrapper";
        chevron: "dds__time-picker__chevron";
        errorIcon: "dds__time-picker__error__icon";
        popup: {
            readonly base: "dds__time-picker__popup";
            readonly hidden: "dds__time-picker__popup--hidden";
        };
        list: "dds__time-picker__list";
        listItem: "dds__time-picker__list-item";
        listItemLabel: "dds__time-picker__list-item-label";
        listItemHighlighted: "dds__time-picker__list-item--highlighted";
        listItemSelected: "dds__time-picker__list-item--selected";
        selectedIcon: "dds__time-picker__selected__icon";
    };
    readonly itemClasses: {
        "dds__time-picker__list-item": boolean;
        "dds__time-picker__list-item--selected": boolean;
        "dds__time-picker__list-item--highlighted": boolean;
    };
    readonly itemIconClasses: {
        dds__icon: boolean;
        "dds__time-picker__selected__icon": boolean;
    };
    index: number;
    value: Time;
    private focusSubscription?;
    private selectedSubscription?;
    private highlightSubscription?;
    selected: boolean;
    constructor(ref: ElementRef<HTMLElement>, service: TimepickerService, cd: ChangeDetectorRef);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DropdownListItemComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DropdownListItemComponent, "dds-timepicker-dropdown-list-item", never, { "index": { "alias": "index"; "required": false; }; "value": { "alias": "value"; "required": false; }; }, {}, never, ["*"], false, never>;
}
