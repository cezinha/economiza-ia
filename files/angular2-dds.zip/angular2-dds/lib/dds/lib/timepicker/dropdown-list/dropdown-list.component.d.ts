import { ChangeDetectorRef, ElementRef, OnDestroy, OnInit, Renderer2 } from "@angular/core";
import { componentClasses } from "../../../core/components/time-picker/time-picker";
import { DeepReadonly } from "../../../core/types/deepreadonly";
import { TimepickerService } from "../services/timepicker.service";
import * as i0 from "@angular/core";
export declare class DropdownListComponent implements OnInit, OnDestroy {
    service: TimepickerService;
    private ref;
    private renderer;
    private cd;
    private visibilitySubscription?;
    readonly componentClasses: DeepReadonly<typeof componentClasses>;
    readonly wrapperClasses: {
        "dds__time-picker__popup": boolean;
        "dds__time-picker__popup--hidden": boolean;
    };
    id: string;
    placementRef: HTMLElement;
    dropdownElementRef: ElementRef;
    handleResize(): void;
    private updateTimeslotsPosition;
    constructor(service: TimepickerService, ref: ElementRef, renderer: Renderer2, cd: ChangeDetectorRef);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DropdownListComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DropdownListComponent, "dds-timepicker-dropdown-list", never, { "id": { "alias": "id"; "required": false; }; "placementRef": { "alias": "placement-ref"; "required": false; }; }, {}, never, never, false, never>;
}
