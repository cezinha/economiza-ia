import { BehaviorSubject } from "rxjs";
import { TimeslotItem, Time } from "../../../core/js/time/time";
import * as i0 from "@angular/core";
export declare class TimepickerService {
    selectedTime$: BehaviorSubject<Time | undefined>;
    options$: BehaviorSubject<TimeslotItem[]>;
    focusedItem$: BehaviorSubject<number>;
    highlightedItem$: BehaviorSubject<number>;
    isOpened: boolean;
    visibility$: BehaviorSubject<boolean>;
    open(): void;
    close(): void;
    getOptionByIndex(index: number): TimeslotItem;
    getOptionByText(value: string): TimeslotItem;
    /**
     * Finds the index of the option that best fits the text
     */
    getOptionIndexByText(text: string): number;
    getFocusedOption(): TimeslotItem;
    toggleOpen(readonly: boolean): void;
    focusNextOption(): void;
    focusPreviousOption(): void;
    highlightOptionByLabel(label: string): void;
    constructor();
    static ɵfac: i0.ɵɵFactoryDeclaration<TimepickerService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<TimepickerService>;
}
