import { ElementRef, EventEmitter, Injector, OnChanges, OnDestroy, OnInit, SimpleChanges } from "@angular/core";
import type { TimeslotDef } from "../../core/js/time/time";
import { FormField } from "../abstracts/form-field/form-field.component";
import { TimepickerService } from "./services/timepicker.service";
import type { Format, Interval, Localization, TimePickerChangeEvent, TimePickerInvalidKind } from "./timepicker.types";
import * as i0 from "@angular/core";
export declare class TimepickerComponent extends FormField<string> implements OnInit, OnDestroy, OnChanges {
    readonly ref: ElementRef;
    readonly injector: Injector;
    protected componentName: string;
    private selectedTimeSubscription?;
    private submitSubscription?;
    private softInvalid;
    private availableRanges;
    private cd;
    readonly popupId: string;
    readonly componentClasses: {
        base: "dds__time-picker";
        sizes: {
            readonly sm: "dds__time-picker--sm";
            readonly lg: "";
        };
        invalid: "dds__time-picker--invalid";
        invalidFeedback: "dds__time-picker__invalid-feedback";
        input: {
            readonly container: "dds__time-picker__input-container";
            readonly wrapper: "dds__time-picker__input-wrapper";
            readonly field: "dds__time-picker__input";
        };
        iconsWrapper: "dds__time-picker__icons-wrapper";
        chevron: "dds__time-picker__chevron";
        errorIcon: "dds__time-picker__error__icon";
        popup: {
            readonly base: "dds__time-picker__popup";
            readonly hidden: "dds__time-picker__popup--hidden";
        };
        list: "dds__time-picker__list";
        listItem: "dds__time-picker__list-item";
        listItemLabel: "dds__time-picker__list-item-label";
        listItemHighlighted: "dds__time-picker__list-item--highlighted";
        listItemSelected: "dds__time-picker__list-item--selected";
        selectedIcon: "dds__time-picker__selected__icon";
    };
    readonly inputClasses: {
        size: {
            readonly lg: "";
            readonly sm: "dds__input-text__container--sm";
        };
        icon: {
            readonly start: "dds__input-text__icon--start";
            readonly end: "dds__input-text__icon--end";
        };
        isInvalid: "dds__is--invalid";
        errorIcon: "dds__field__icon--invalid";
        container: "dds__input-text__container";
        wrapper: "dds__input-text__wrapper";
        control: "dds__input-text";
        hasIcon: "dds__has__icon--start";
        helperText: "dds__input-text__helper";
        errorText: "dds__invalid-feedback";
        withButton: "dds__input-text__wrapper--button";
    };
    readonly chevronWrapper: {
        [x: string]: boolean | undefined;
        "dds__time-picker__icons-wrapper": boolean;
    };
    readonly baseClasses: {
        "dds__time-picker": boolean;
        "dds__time-picker--sm": boolean;
    };
    readonly validationIconClasses: {
        dds__icon: boolean;
        "dds__time-picker__error__icon": boolean;
    };
    readonly chevronIconClasses: {
        dds__icon: boolean;
        "dds__time-picker__chevron": boolean;
    };
    service: TimepickerService;
    invalidKind?: TimePickerInvalidKind | undefined;
    placeholder: string;
    srUpdatedTimeText: string;
    value: string;
    localization: Localization;
    leadingZero: boolean;
    closeOnScroll: boolean;
    timeFormat: Format;
    interval: Interval;
    allowFreeTimeChoice: boolean;
    availableTimes: Array<TimeslotDef>;
    readonly ddsChange: EventEmitter<TimePickerChangeEvent>;
    handleScroll(): void;
    focusOut(event: FocusEvent): void;
    handleKeyDown(event: KeyboardEvent): void;
    private buildTimeslots;
    /**
     * Try to resolve to an existing option or a valid time (allow-free-time-choice)
     * based on the value of the input
     */
    private resolveOption;
    private close;
    private onsumbit;
    private lastStatus?;
    handleValidation(value: string): void;
    handleSelect(event: Event): void;
    handleInput(): void;
    ngOnChanges(changes: SimpleChanges): void;
    writeValue(value: string | undefined): void;
    constructor(ref: ElementRef, injector: Injector);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<TimepickerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<TimepickerComponent, "dds-timepicker", never, { "value": { "alias": "value"; "required": false; }; "localization": { "alias": "localization"; "required": false; }; "leadingZero": { "alias": "leading-zero"; "required": false; }; "closeOnScroll": { "alias": "close-on-scroll"; "required": false; }; "timeFormat": { "alias": "time-format"; "required": false; }; "interval": { "alias": "interval"; "required": false; }; "allowFreeTimeChoice": { "alias": "allow-free-time-choice"; "required": false; }; "availableTimes": { "alias": "available-times"; "required": false; }; }, { "ddsChange": "dds-change"; }, never, ["dds-label", "dds-error[kind=unavailable]", "dds-error[kind=invalid]", "dds-error", "dds-helper"], false, never>;
}
