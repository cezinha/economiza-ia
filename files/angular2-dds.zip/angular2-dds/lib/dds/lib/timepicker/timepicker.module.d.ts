import * as i0 from "@angular/core";
import * as i1 from "./timepicker.component";
import * as i2 from "./dropdown-list/dropdown-list.component";
import * as i3 from "./dropdown-list-item/dropdown-list-item.component";
import * as i4 from "@angular/common";
import * as i5 from "@angular/forms";
export declare class TimepickerModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<TimepickerModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<TimepickerModule, [typeof i1.TimepickerComponent, typeof i2.DropdownListComponent, typeof i3.DropdownListItemComponent], [typeof i4.CommonModule, typeof i5.FormsModule, typeof i5.ReactiveFormsModule], [typeof i1.TimepickerComponent, typeof i2.DropdownListComponent, typeof i3.DropdownListItemComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<TimepickerModule>;
}
