import { FormFieldValidationEvent } from "../abstracts/form-field/form-field.types";
import { TimepickerComponent } from "./timepicker.component";
/**
 * Define timepicker invalid kind values
 * @internal
 *
 */
export declare const TimePickerInvalidKindValues: {
    readonly invalid: "invalid";
    readonly unavailable: "unavailable";
};
/**
 * Defines the kind of invalidity
 * - `invalid`: The time is invalid
 * - `unavailable`: The time is not available
 */
export type TimePickerInvalidKind = keyof typeof TimePickerInvalidKindValues;
export type { FormFieldValidationEvent as TimepickerValidationEvent };
export type TimePickerChangeEvent = {
    target: TimepickerComponent;
};
export type { Localization, Interval, Format, Size, } from "../../core/components/time-picker/time-picker.types";
