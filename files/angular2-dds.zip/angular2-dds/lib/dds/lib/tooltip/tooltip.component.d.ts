import { ChangeDetectorRef, ElementRef, EventEmitter, OnChanges, OnDestroy, SimpleChanges } from "@angular/core";
import type { Placement, TooltipHideEvent, TooltipShowEvent } from "./tooltip.types";
import { WithNativeElement } from "../abstracts/types/with-native-element";
import * as i0 from "@angular/core";
export declare class TooltipComponent implements OnChanges, OnDestroy {
    private ref;
    private changeDetector;
    private _trigger;
    protected isVisible: boolean;
    private tooltipDynamicClass;
    private pointerDynamicClass;
    private isAnimating;
    private tooltipShowTimeout;
    private debounceResize;
    readonly ddsShow: EventEmitter<TooltipShowEvent>;
    readonly ddsHide: EventEmitter<TooltipHideEvent>;
    placement: Placement;
    title: string;
    set trigger(value: HTMLElement | WithNativeElement);
    srId: string;
    handleResize(): void;
    readonly componentClass: {
        tooltip: "dds__tooltip";
        tooltipMaxContent: "dds__tooltip--max-content";
        show: "dds__tooltip--show";
        body: "dds__tooltip__body";
        bodyNoTitle: "dds__tooltip__body--no-title";
        title: "dds__tooltip__title";
        animating: "dds__tooltip--animating";
        dismiss: "dds__tooltip__dismiss";
        pointer: "dds__tooltip__pointer";
    };
    readonly tooltipClasses: {
        dds__tooltip: boolean;
        "dds__tooltip--show": boolean;
        "dds__tooltip--animating": boolean;
    };
    readonly contentClasses: {
        dds__tooltip__body: boolean;
        "dds__tooltip__body--no-title": boolean;
    };
    readonly pointerClasses: {
        dds__tooltip__pointer: boolean;
    };
    readonly iconClasses = "dds__icon";
    private _isMobile;
    get isMobile(): boolean;
    private handleTriggerClick;
    private handleTriggerMouseLeave;
    private handleTriggerBlur;
    private handleTriggerKeydown;
    /**
     * Tooltips have a specific behavior when being open from a small (mobile) screen:
     * - Adding the close button
     * - As in mobile the tooltip has the close button if the title is not present his space
     * need to be preserver so there is available space for the close button
     * - If the tooltip width is bigger then the minimum required by design (maxContentWidth)
     * a class is added to ensure that tooltips will be 100vh - gutters
     */
    private updateTooltipPosition;
    hide: () => void;
    show: () => void;
    private setTrigger;
    private unsetTrigger;
    constructor(ref: ElementRef, changeDetector: ChangeDetectorRef);
    ngOnChanges(changes: SimpleChanges): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<TooltipComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<TooltipComponent, "dds-tooltip", never, { "placement": { "alias": "placement"; "required": false; }; "title": { "alias": "title"; "required": false; }; "trigger": { "alias": "trigger"; "required": false; }; "srId": { "alias": "sr-id"; "required": false; }; }, { "ddsShow": "dds-show"; "ddsHide": "dds-hide"; }, never, ["*"], false, never>;
}
