import { placements } from "../../core/components/tooltip/tooltip";
import { GenericEvent } from "../abstracts/types/generic-event";
import { TooltipComponent } from "./tooltip.component";
export type Placement = typeof placements[keyof typeof placements];
export type TooltipShowEvent = GenericEvent<TooltipComponent>;
export type TooltipHideEvent = GenericEvent<TooltipComponent>;
