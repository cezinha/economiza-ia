import * as i0 from "@angular/core";
export declare class ViewMoreLessEllipsisDirective {
    target: boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<ViewMoreLessEllipsisDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<ViewMoreLessEllipsisDirective, "[as-ellipsis]", never, {}, {}, never, never, false, never>;
}
