import { AfterViewInit, ElementRef, OnChanges, OnDestroy, Renderer2, SimpleChanges } from "@angular/core";
import { ViewMoreLessService } from "../services/view-more-less.service";
import * as i0 from "@angular/core";
export declare class ViewMoreLessTargetDirective implements OnChanges, OnDestroy, AfterViewInit {
    private elRef;
    private service;
    private renderer;
    target: boolean;
    hidden: boolean;
    region: string;
    id: string;
    private idSubscription?;
    private statusSubscription?;
    private nativeElement;
    private isMainTarget;
    private removeTabindex;
    constructor(elRef: ElementRef, service: ViewMoreLessService, renderer: Renderer2);
    ngOnChanges(changes: SimpleChanges): void;
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ViewMoreLessTargetDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<ViewMoreLessTargetDirective, "[as-target]", never, { "id": { "alias": "id"; "required": false; }; }, {}, never, never, false, never>;
}
