import { BehaviorSubject } from "rxjs";
import { Kind } from "../view-more-less.types";
import * as i0 from "@angular/core";
export declare class ViewMoreLessService {
    expanded: boolean;
    targetId$: BehaviorSubject<string>;
    status$: BehaviorSubject<boolean>;
    kind$: BehaviorSubject<Kind>;
    expand(): void;
    collapse(): void;
    toggle(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ViewMoreLessService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ViewMoreLessService>;
}
