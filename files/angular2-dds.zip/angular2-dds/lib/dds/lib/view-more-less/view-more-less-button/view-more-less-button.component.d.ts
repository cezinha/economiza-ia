import { ElementRef, OnChanges, OnDestroy, OnInit, SimpleChanges } from "@angular/core";
import { ViewMoreLessService } from "../services/view-more-less.service";
import { Localization } from "../view-more-less.types";
import * as i0 from "@angular/core";
export declare class ViewMoreLessButtonComponent implements OnChanges, OnDestroy, OnInit {
    readonly ref: ElementRef;
    readonly service: ViewMoreLessService;
    private kindSubscription?;
    private statusSubscription?;
    readonly buttonClasses: {
        "dds__more-less__button": boolean;
        "dds__more-less__button--standalone": boolean;
    };
    readonly srClasses: {
        "dds__sr-only": boolean;
    };
    localization: Localization;
    expanded: boolean;
    isStandAlone: boolean;
    label: string;
    screenReader: string | undefined;
    constructor(ref: ElementRef, service: ViewMoreLessService);
    ngOnChanges(changes: SimpleChanges): void;
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ViewMoreLessButtonComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ViewMoreLessButtonComponent, "dds-view-more-less-button", never, { "localization": { "alias": "localization"; "required": false; }; }, {}, never, never, false, never>;
}
