import { EventEmitter, OnChanges, OnDestroy, SimpleChanges } from "@angular/core";
import { ViewMoreLessService } from "./services/view-more-less.service";
import { Kind, ViewMoreLessCollapseEvent, ViewMoreLessExpandEvent } from "./view-more-less.types";
import { Subscription } from "rxjs";
import * as i0 from "@angular/core";
export declare class ViewMoreLessComponent implements OnChanges, OnDestroy {
    readonly service: ViewMoreLessService;
    kind: Kind;
    readonly ddsExpand: EventEmitter<ViewMoreLessExpandEvent>;
    readonly ddsCollapse: EventEmitter<ViewMoreLessCollapseEvent>;
    readonly wrapperClasses: {
        expanded: boolean;
        "dds__more-less--inline": boolean;
    };
    statusSubscription: Subscription;
    expand: () => void;
    collapse: () => void;
    toggle: () => void;
    constructor(service: ViewMoreLessService);
    ngOnChanges(changes: SimpleChanges): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ViewMoreLessComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ViewMoreLessComponent, "dds-view-more-less", never, { "kind": { "alias": "kind"; "required": false; }; }, { "ddsExpand": "dds-expand"; "ddsCollapse": "dds-collapse"; }, never, ["*"], false, never>;
}
