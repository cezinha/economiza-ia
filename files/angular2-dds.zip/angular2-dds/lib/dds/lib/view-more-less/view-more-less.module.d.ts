import * as i0 from "@angular/core";
import * as i1 from "./view-more-less.component";
import * as i2 from "./view-more-less-button/view-more-less-button.component";
import * as i3 from "./directives/as-target.directive";
import * as i4 from "./directives/as-ellipsis.directive";
import * as i5 from "@angular/common";
export declare class ViewMoreLessModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ViewMoreLessModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ViewMoreLessModule, [typeof i1.ViewMoreLessComponent, typeof i2.ViewMoreLessButtonComponent, typeof i3.ViewMoreLessTargetDirective, typeof i4.ViewMoreLessEllipsisDirective], [typeof i5.CommonModule], [typeof i1.ViewMoreLessComponent, typeof i2.ViewMoreLessButtonComponent, typeof i3.ViewMoreLessTargetDirective, typeof i4.ViewMoreLessEllipsisDirective]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ViewMoreLessModule>;
}
