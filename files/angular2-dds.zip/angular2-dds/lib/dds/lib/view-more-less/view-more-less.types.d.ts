import { GenericEvent } from "../abstracts/types/generic-event";
import { ViewMoreLessComponent } from "./view-more-less.component";
export { Kind, Localization } from "../../core/components/view-more-less/view-more-less.types";
export type ViewMoreLessExpandEvent = GenericEvent<ViewMoreLessComponent>;
export type ViewMoreLessCollapseEvent = GenericEvent<ViewMoreLessComponent>;
