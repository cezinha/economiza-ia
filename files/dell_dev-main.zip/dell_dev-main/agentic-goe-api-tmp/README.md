# GOE API Service

HTTP API for the GOE Dashboard **NUDDs** endpoints (SCAIF-1178/1179/1182), backed by the orchestrator PostgreSQL schema in [`agentic-goe-database-tmp`](../agentic-goe-database-tmp/).

Specification: [`HU/nudds-api-specification.md`](../agentic-goe-database-tmp/HU/nudds-api-specification.md).

---

## Prerequisites

- Python 3.12+
- [uv](https://docs.astral.sh/uv/) (recommended)
- PostgreSQL with orchestrator SQL applied — see [`agentic-goe-database-tmp/README-DEV.md`](../agentic-goe-database-tmp/README-DEV.md)

---

## Setup

Install dependencies **before** running uvicorn. The project is not installed globally; use a virtual environment or `uv`.

> **Important:** `pyproject.toml` pins `fastapi>=0.115,<0.137` because FastAPI 0.137+ breaks `prometheus-fastapi-instrumentator` when using `include_router` (HTTP 500: `'_IncludedRouter' object has no attribute 'path'`). Always install from this project (`pip install -e .` or `uv sync`) — do not rely on a global `uvicorn` or an outdated venv.

### Option A — uv (recommended)

```bash
cd agentic-goe-api-tmp
uv sync --all-groups
cp .env.example .env
# Edit .env — especially GOE_API_DATABASE_URL (see Secrets)

# Confirm FastAPI version (must be < 0.137)
uv run python -c "import fastapi; print(fastapi.__version__)"
```

Run the API with the env uv manages:

```bash
uv run uvicorn app.main:app --host 0.0.0.0 --port 8006 --reload
```

### Option B — venv + pip

```bash
cd agentic-goe-api-tmp
python3 -m venv .venv
source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install --upgrade pip
pip install -e .
cp .env.example .env
# Edit .env — especially GOE_API_DATABASE_URL (see Secrets)

# Confirm FastAPI version (must be < 0.137)
python -c "import fastapi; print(fastapi.__version__)"
```

Dev/test tools (optional):

```bash
pip install pytest pytest-asyncio pytest-cov pytest-mock httpx
```

Always activate `.venv` (or prefix commands with `.venv/bin/`) before `uvicorn` or `pytest`.

If you already had a venv and see the `_IncludedRouter` error, reinstall:

```bash
pip install -e . --force-reinstall
```

---

## Configuration / Secrets (`.env`)

Canonical template: [`.env.example`](.env.example) — placeholders only, safe to commit.

| Variable | Secret? | Description |
|----------|---------|-------------|
| `GOE_API_DATABASE_URL` | **Yes** | `postgresql+asyncpg://user:password@host:5432/jira_regrello` |
| `GOE_API_ENVIRONMENT` | No | Label (`local`, `dev`, …) |
| `GOE_API_SERVICE_HOST` | No | Uvicorn bind (default `0.0.0.0`) |
| `GOE_API_SERVICE_PORT` | No | HTTP port (default `8006`) |
| `GOE_API_LOG_LEVEL` | No | `DEBUG`, `INFO`, … |

**Secret handling:**

- Never commit `.env` or real database passwords
- Commit only `.env.example` with placeholders
- In Docker/K8s inject `GOE_API_DATABASE_URL` from a secret store, not baked into images
- Tests set `GOE_API_DISABLE_DOTENV=1` so local `.env` is not loaded (see `tests/conftest.py`)

Settings load from `.env` in cwd and next to `pyproject.toml`; OS environment variables override file values.

---

## Run locally

**Order:** install dependencies (Setup) → database → API.

```bash
# Terminal 1 — database (from agentic-goe-database-tmp)
cd agentic-goe-database-tmp
docker compose up -d
./scripts/apply-sql.sh

# Terminal 2 — API (from agentic-goe-api-tmp)
cd agentic-goe-api-tmp
cp .env.example .env   # skip if already done in Setup

# With uv:
uv run uvicorn app.main:app --host 0.0.0.0 --port 8006 --reload

# Or with venv (after pip install -e .):
source .venv/bin/activate
uvicorn app.main:app --host 0.0.0.0 --port 8006 --reload
# equivalent without activate:
# .venv/bin/uvicorn app.main:app --host 0.0.0.0 --port 8006 --reload
```

Verify with curl (see [Examples](#curl-examples) below) or open `http://localhost:8006/docs`.

---

## Run with Docker

Ensure Postgres is running (database-tmp). Update `.env` if needed:

```
GOE_API_DATABASE_URL=postgresql+asyncpg://jira_regrello:jira_regrello@host.docker.internal:5432/jira_regrello
```

```bash
docker compose up --build
```

---

## API endpoints

| Method | Path | Description |
|--------|------|-------------|
| `GET` | `/health` | Liveness probe |
| `GET` | `/status` | Service info + database connectivity |
| `GET` | `/metrics` | Prometheus metrics (when enabled) |
| `GET` | `/api/nudds/filter-options` | Filter dropdown values (SCAIF-1179) |
| `GET` | `/api/nudds` | Paginated NUDD list with enrichment (SCAIF-1178) |
| `GET` | `/api/nudds/summary` | Aggregations and charts data (SCAIF-1182) |

Optional header on NUDDs routes: `X-User-Email` — scopes platform-related data via `user_jira_platform_access`.

Spec: [`HU/nudds-api-specification.md`](../agentic-goe-database-tmp/HU/nudds-api-specification.md).

Global program status filter (`on-track`, `at-risk`, `delayed`) uses a documented MVP heuristic based on `risk_band`, risk score, and `close_date`.

---

## curl examples

Base URL (local): `http://localhost:8006`

### Health and status

```bash
# Liveness
curl -s http://localhost:8006/health | jq .

# Environment + DB reachable
curl -s http://localhost:8006/status | jq .
```

### Filter options (SCAIF-1179)

```bash
# All values (no user scope)
curl -s http://localhost:8006/api/nudds/filter-options | jq .

# Scoped to platforms Jane Doe can access (sample data)
curl -s http://localhost:8006/api/nudds/filter-options \
  -H 'X-User-Email: jane.doe@dell.com' | jq .
```

### NUDD list (SCAIF-1178)

Uses **GET with JSON body** per HU spec. Requires `Content-Type: application/json`.

```bash
# Default pagination (page 1, pageSize 25)
curl -s -X GET http://localhost:8006/api/nudds \
  -H 'Content-Type: application/json' \
  -d '{"pagination":{"page":1,"pageSize":25}}' | jq .

# Filter by status + sort
curl -s -X GET http://localhost:8006/api/nudds \
  -H 'Content-Type: application/json' \
  -H 'X-User-Email: jane.doe@dell.com' \
  -d '{
    "filters": {
      "table": { "status": ["Open", "In Progress"] }
    },
    "pagination": { "page": 1, "pageSize": 10 },
    "sorting": { "column": "updated", "direction": "desc" }
  }' | jq .
```

### Summary (SCAIF-1182)

```bash
# Full summary (no filters)
curl -s -X GET http://localhost:8006/api/nudds/summary \
  -H 'Content-Type: application/json' \
  -d '{}' | jq .

# Summary with global + risk filters
curl -s -X GET http://localhost:8006/api/nudds/summary \
  -H 'Content-Type: application/json' \
  -H 'X-User-Email: jane.doe@dell.com' \
  -d '{
    "filters": {
      "global": { "lobs": ["NB", "DT"] },
      "risk": { "bands": ["High", "Medium"], "minRiskScore": 3 }
    }
  }' | jq .
```

(`jq` is optional; omit `| jq .` if not installed.)

---

## Tests

With **uv**:

```bash
GOE_API_DISABLE_DOTENV=1 uv run pytest tests/unit
GOE_API_DISABLE_DOTENV=1 uv run pytest tests/integration -m integration
```

With **venv**:

```bash
source .venv/bin/activate
GOE_API_DISABLE_DOTENV=1 pytest tests/unit
GOE_API_DISABLE_DOTENV=1 pytest tests/integration -m integration
```

Integration tests require Postgres with sample data (`SQL/004`).

---

## Troubleshooting

| Issue | Action |
|-------|--------|
| `ModuleNotFoundError: No module named 'fastapi'` | Run Setup first: `uv sync --all-groups` or `pip install -e .` in an activated venv; then use `uv run uvicorn ...` or `.venv/bin/uvicorn ...` |
| `500` + `'_IncludedRouter' object has no attribute 'path'` | Reinstall deps so FastAPI stays `<0.137` (see `pyproject.toml`): `pip install -e .` or `uv sync --all-groups`; restart uvicorn |
| DB connection refused | Start database-tmp; check `GOE_API_DATABASE_URL` |
| `.env` not applied | Run from project root or export variables |
| Secrets committed | Rotate credentials; keep secrets in `.env` only |
