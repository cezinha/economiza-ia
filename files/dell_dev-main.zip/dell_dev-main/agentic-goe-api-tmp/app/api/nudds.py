"""NUDDs API routes."""

from __future__ import annotations

from fastapi import APIRouter, Body

from app.api.nudds_schemas import (
    FilterOptionsResponse,
    NuddsListRequest,
    NuddsListResponse,
    NuddsSummaryRequest,
    NuddsSummaryResponse,
)
from app.deps import NuddsServiceDep, UserEmailDep

router = APIRouter(prefix="/api/nudds", tags=["nudds"])


@router.get("/filter-options", response_model=FilterOptionsResponse)
async def get_filter_options(
    service: NuddsServiceDep,
    user_email: UserEmailDep,
) -> FilterOptionsResponse:
    return await service.filter_options(user_email)


@router.get("", response_model=NuddsListResponse)
async def list_nudds(
    service: NuddsServiceDep,
    user_email: UserEmailDep,
    body: NuddsListRequest | None = Body(None),
) -> NuddsListResponse:
    return await service.list_nudds(body, user_email)


@router.get("/summary", response_model=NuddsSummaryResponse)
async def get_summary(
    service: NuddsServiceDep,
    user_email: UserEmailDep,
    body: NuddsSummaryRequest | None = Body(None),
) -> NuddsSummaryResponse:
    return await service.summary(body, user_email)
