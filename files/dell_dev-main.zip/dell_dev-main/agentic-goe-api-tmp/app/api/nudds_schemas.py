"""Pydantic models for NUDDs API (SCAIF-1178/1179/1182)."""

from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field


class GlobalFilters(BaseModel):
    search: str | None = None
    organizations: list[str] | None = None
    functions: list[str] | None = None
    lobs: list[str] | None = None
    platforms: list[str] | None = None
    phases: list[str] | None = None
    statuses: list[str] | None = None
    owners: list[str] | None = None
    tasks: list[str] | None = None

    model_config = ConfigDict(extra="ignore")


class TableFilters(BaseModel):
    id: str | None = None
    status: list[str] | None = None
    lob: str | None = None
    platform: str | None = None
    impact: list[int] | None = None
    probability: list[int] | None = None
    risk: int | None = None
    band: list[str] | None = None
    created: int | None = None
    updated: int | None = None
    closeDate: int | None = None

    model_config = ConfigDict(extra="ignore")


class RiskFilters(BaseModel):
    minImpact: int | None = Field(None, ge=1, le=3)
    maxImpact: int | None = Field(None, ge=1, le=3)
    minProbability: int | None = Field(None, ge=1, le=3)
    maxProbability: int | None = Field(None, ge=1, le=3)
    minRiskScore: int | None = Field(None, ge=1, le=9)
    maxRiskScore: int | None = Field(None, ge=1, le=9)
    bands: list[str] | None = None
    statuses: list[str] | None = None

    model_config = ConfigDict(extra="ignore")


class FiltersBlock(BaseModel):
    global_: GlobalFilters | None = Field(None, alias="global")
    table: TableFilters | None = None
    risk: RiskFilters | None = None

    model_config = ConfigDict(populate_by_name=True, extra="ignore")


class PaginationRequest(BaseModel):
    page: int = Field(1, ge=1)
    pageSize: int = Field(25, ge=1, le=100)


class SortingRequest(BaseModel):
    column: str | None = None
    direction: Literal["asc", "desc"] | None = None


class NuddsListRequest(BaseModel):
    filters: FiltersBlock | None = None
    pagination: PaginationRequest | None = None
    sorting: SortingRequest | None = None


class NuddsSummaryRequest(BaseModel):
    filters: FiltersBlock | None = None


class CalendarBlock(BaseModel):
    year: str | None = None
    quarter: str | None = None
    month: str | None = None


class PeopleBlock(BaseModel):
    assignee: str | None = None
    reporter: str | None = None
    programManager: str | None = None
    projectManager: str | None = None
    engineers: list[str] = Field(default_factory=list)
    qualityEngineer: str | None = None
    procurement: str | None = None
    services: list[str] = Field(default_factory=list)
    goe: str | None = None
    edg: str | None = None


class DatesBlock(BaseModel):
    created: str | None = None
    updated: str | None = None
    conceptEntryTarget: str | None = None
    conceptExitTarget: str | None = None
    defineExitTarget: str | None = None
    baTarget: str | None = None
    ddsTarget: str | None = None
    planExitTarget: str | None = None
    rfdTarget: str | None = None
    developExitTarget: str | None = None
    rtsTarget: str | None = None
    rtoTarget: str | None = None


class NuddItemResponse(BaseModel):
    id: str
    title: str
    lob: str | None = None
    platform: str | None = None
    impact: int | None = None
    probability: int | None = None
    status: str
    created: int | None = None
    updated: int | None = None
    closeDate: int | None = None
    type: str | None = None
    resolution: str | None = None
    labels: list[Any] = Field(default_factory=list)
    programName: str | None = None
    programState: str | None = None
    domainBusiness: str | None = None
    programCategory: str | None = None
    platformModelId: str | None = None
    predecessor: str | None = None
    formFactor: str | None = None
    programClass: str | None = None
    programPhase: str | None = None
    tier: str | None = None
    cpuArchitecture: str | None = None
    odmSupplier: str | None = None
    rtsCalendar: CalendarBlock | None = None
    rtoCalendar: CalendarBlock | None = None
    people: PeopleBlock | None = None
    dates: DatesBlock | None = None


class PaginationResponse(BaseModel):
    total: int
    page: int
    pageSize: int
    totalPages: int
    hasNext: bool
    hasPrevious: bool


class NuddsListResponse(BaseModel):
    data: list[NuddItemResponse]
    pagination: PaginationResponse


class FilterOptionsResponse(BaseModel):
    organizations: list[str]
    functions: list[str]
    statuses: list[str]
    platforms: list[str]
    phases: list[str]
    lobs: list[str]
    owners: list[str]
    tasks: list[str]


class SummaryMetrics(BaseModel):
    total: int
    active: int
    completed: int
    onHold: int
    open: int
    highRisk: int
    mediumRisk: int
    lowRisk: int
    upcomingThisWeek: int
    upcomingThisMonth: int


class RiskByPhaseItem(BaseModel):
    phase: str
    low: int
    medium: int
    high: int
    totalScore: int


class MonthlyOverviewItem(BaseModel):
    month: str
    opened: int
    closed: int
    active: int


class ScatterItem(BaseModel):
    id: str
    x: int
    y: int
    color: str


class NuddsSummaryResponse(BaseModel):
    summary: SummaryMetrics
    riskByPhase: list[RiskByPhaseItem]
    monthlyOverview: list[MonthlyOverviewItem]
    scatterData: list[ScatterItem]
