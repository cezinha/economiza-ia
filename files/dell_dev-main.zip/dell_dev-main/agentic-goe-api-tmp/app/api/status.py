"""Service status endpoint."""

from __future__ import annotations

from datetime import datetime, timezone

from fastapi import APIRouter
from pydantic import BaseModel

from app.config import settings
from app.deps import NuddsServiceDep

router = APIRouter(prefix="/status", tags=["status"])


class StatusResponse(BaseModel):
    service: str
    timestamp: datetime
    environment: str
    database_connected: bool


@router.get("", response_model=StatusResponse)
async def get_status(service: NuddsServiceDep) -> StatusResponse:
    connected = await service.ping_db()
    return StatusResponse(
        service="goe-api",
        timestamp=datetime.now(timezone.utc),
        environment=settings.environment,
        database_connected=connected,
    )
