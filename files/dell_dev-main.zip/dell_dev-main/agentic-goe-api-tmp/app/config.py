"""Configuration for the GOE API service."""

from __future__ import annotations

import os
from pathlib import Path

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict

_API_ROOT = Path(__file__).resolve().parent.parent


def _settings_env_file() -> tuple[str, ...] | None:
    if os.environ.get("GOE_API_DISABLE_DOTENV", "").lower() in ("1", "true", "yes"):
        return None
    return (
        str(Path.cwd() / ".env"),
        str(_API_ROOT / ".env"),
    )


class Settings(BaseSettings):
    """Application settings loaded from environment variables."""

    model_config = SettingsConfigDict(
        case_sensitive=False,
        extra="allow",
        env_file=_settings_env_file(),
        env_file_encoding="utf-8",
    )

    environment: str = Field(default="local", validation_alias="GOE_API_ENVIRONMENT")
    service_host: str = Field(default="0.0.0.0", validation_alias="GOE_API_SERVICE_HOST")
    service_port: int = Field(default=8006, validation_alias="GOE_API_SERVICE_PORT")
    log_level: str = Field(default="INFO", validation_alias="GOE_API_LOG_LEVEL")
    database_url: str = Field(
        default="postgresql+asyncpg://jira_regrello:jira_regrello@localhost:5432/jira_regrello",
        validation_alias="GOE_API_DATABASE_URL",
    )


settings = Settings()
