"""NUDDs SQL queries (SQLAlchemy Core)."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

NUDD_FROM = """
FROM jira_nudd n
LEFT JOIN jira_platform p ON p.id = n.impacted_jira_platform_id
LEFT JOIN jira_platform_information pi ON pi.jira_platform_id = p.id
LEFT JOIN catalog_lob lob ON lob.id = n.catalog_lob_id
LEFT JOIN catalog_organization org ON org.id = lob.organization_id
LEFT JOIN catalog_nudd_task ct ON ct.id = n.catalog_nudd_task_id
LEFT JOIN catalog_phase cph ON cph.id = ct.phase_id
LEFT JOIN catalog_function cf ON cf.id = cph.function_id
LEFT JOIN assignee assignee ON assignee.id = n.assignee_id
LEFT JOIN assignee reporter ON reporter.id = n.reporter_id
"""

SORT_COLUMNS = {
    "id": "n.jira_issue_key",
    "title": "n.summary",
    "lob": "lob.code",
    "platform": "p.platform_name",
    "impact": "n.impact",
    "probability": "n.probability",
    "status": "n.status",
    "created": "n.jira_created_at",
    "updated": "n.jira_updated_at",
    "closeDate": "n.close_date",
    "risk": "n.risk_score",
    "band": "n.risk_band",
}


@dataclass
class NuddFilters:
    search: str | None = None
    organizations: list[str] = field(default_factory=list)
    functions: list[str] = field(default_factory=list)
    lobs: list[str] = field(default_factory=list)
    platforms: list[str] = field(default_factory=list)
    phases: list[str] = field(default_factory=list)
    program_statuses: list[str] = field(default_factory=list)
    owners: list[str] = field(default_factory=list)
    tasks: list[str] = field(default_factory=list)
    table_id: str | None = None
    table_status: list[str] = field(default_factory=list)
    table_lob: str | None = None
    table_platform: str | None = None
    table_impact: list[int] = field(default_factory=list)
    table_probability: list[int] = field(default_factory=list)
    table_risk: int | None = None
    table_band: list[str] = field(default_factory=list)
    min_impact: int | None = None
    max_impact: int | None = None
    min_probability: int | None = None
    max_probability: int | None = None
    min_risk_score: int | None = None
    max_risk_score: int | None = None
    risk_bands: list[str] = field(default_factory=list)
    risk_statuses: list[str] = field(default_factory=list)
    user_email: str | None = None


def _band_values(bands: list[str]) -> list[str]:
    mapping = {"low": "low", "medium": "medium", "high": "high"}
    return [mapping.get(b.lower(), b.lower()) for b in bands]


def _program_status_clause(statuses: list[str]) -> str | None:
    parts: list[str] = []
    for s in statuses:
        key = s.lower()
        if key == "at-risk":
            parts.append("(n.risk_band = 'high' OR (n.impact IS NOT NULL AND n.probability IS NOT NULL AND n.impact * n.probability >= 6))")
        elif key == "delayed":
            parts.append("(n.close_date IS NOT NULL AND n.close_date < NOW() AND n.status::text != 'Completed')")
        elif key == "on-track":
            parts.append(
                "(n.status::text NOT IN ('Completed') AND NOT (n.risk_band = 'high' OR "
                "(n.impact IS NOT NULL AND n.probability IS NOT NULL AND n.impact * n.probability >= 6)) AND "
                "NOT (n.close_date IS NOT NULL AND n.close_date < NOW()))"
            )
    if not parts:
        return None
    return "(" + " OR ".join(parts) + ")"


def build_where(filters: NuddFilters) -> tuple[str, dict[str, Any]]:
    clauses: list[str] = ["1=1"]
    params: dict[str, Any] = {}

    if filters.user_email:
        clauses.append(
            """(
              n.impacted_jira_platform_id IS NULL
              OR n.impacted_jira_platform_id IN (
                SELECT uja.jira_platform_id
                FROM user_jira_platform_access uja
                JOIN assignee a ON a.id = uja.assignee_id
                WHERE a.email = :user_email
              )
            )"""
        )
        params["user_email"] = filters.user_email

    if filters.search:
        clauses.append(
            "(n.summary ILIKE :search OR n.jira_issue_key ILIKE :search OR p.platform_name ILIKE :search)"
        )
        params["search"] = f"%{filters.search}%"

    if filters.organizations:
        clauses.append("org.code = ANY(:organizations)")
        params["organizations"] = filters.organizations

    if filters.functions:
        clauses.append("cf.code = ANY(:functions)")
        params["functions"] = filters.functions

    if filters.lobs:
        clauses.append("lob.code = ANY(:lobs)")
        params["lobs"] = filters.lobs

    if filters.platforms:
        clauses.append("(p.platform_name = ANY(:platforms) OR n.impacted_platform_name = ANY(:platforms))")
        params["platforms"] = filters.platforms

    if filters.phases:
        clauses.append("pi.program_phase::text = ANY(:phases)")
        params["phases"] = filters.phases

    if filters.tasks:
        clauses.append("ct.name = ANY(:tasks)")
        params["tasks"] = filters.tasks

    if filters.owners:
        clauses.append(
            "(assignee.display_name = ANY(:owners) OR reporter.display_name = ANY(:owners))"
        )
        params["owners"] = filters.owners

    prog = _program_status_clause(filters.program_statuses)
    if prog:
        clauses.append(prog)

    if filters.table_id:
        clauses.append("n.jira_issue_key ILIKE :table_id")
        params["table_id"] = f"%{filters.table_id}%"

    if filters.table_status:
        clauses.append("n.status::text = ANY(:table_status)")
        params["table_status"] = filters.table_status

    if filters.table_lob:
        clauses.append("lob.code = :table_lob")
        params["table_lob"] = filters.table_lob

    if filters.table_platform:
        clauses.append(
            "(p.platform_name ILIKE :table_platform OR n.impacted_platform_name ILIKE :table_platform)"
        )
        params["table_platform"] = f"%{filters.table_platform}%"

    if filters.table_impact:
        clauses.append("n.impact = ANY(:table_impact)")
        params["table_impact"] = filters.table_impact

    if filters.table_probability:
        clauses.append("n.probability = ANY(:table_probability)")
        params["table_probability"] = filters.table_probability

    if filters.table_risk is not None:
        clauses.append("n.risk_score = :table_risk")
        params["table_risk"] = filters.table_risk

    if filters.table_band:
        clauses.append("LOWER(n.risk_band) = ANY(:table_band)")
        params["table_band"] = _band_values(filters.table_band)

    if filters.min_impact is not None:
        clauses.append("n.impact >= :min_impact")
        params["min_impact"] = filters.min_impact

    if filters.max_impact is not None:
        clauses.append("n.impact <= :max_impact")
        params["max_impact"] = filters.max_impact

    if filters.min_probability is not None:
        clauses.append("n.probability >= :min_probability")
        params["min_probability"] = filters.min_probability

    if filters.max_probability is not None:
        clauses.append("n.probability <= :max_probability")
        params["max_probability"] = filters.max_probability

    if filters.min_risk_score is not None:
        clauses.append("n.risk_score >= :min_risk_score")
        params["min_risk_score"] = filters.min_risk_score

    if filters.max_risk_score is not None:
        clauses.append("n.risk_score <= :max_risk_score")
        params["max_risk_score"] = filters.max_risk_score

    if filters.risk_bands:
        clauses.append("LOWER(n.risk_band) = ANY(:risk_bands)")
        params["risk_bands"] = _band_values(filters.risk_bands)

    if filters.risk_statuses:
        clauses.append("n.status::text = ANY(:risk_statuses)")
        params["risk_statuses"] = filters.risk_statuses

    return " AND ".join(clauses), params


LIST_SELECT = """
SELECT
  n.jira_issue_key,
  n.summary,
  n.status::text AS status,
  n.resolution,
  n.nudd_type,
  n.impact,
  n.probability,
  n.risk_score,
  n.risk_band,
  n.labels,
  n.jira_created_at,
  n.jira_updated_at,
  n.close_date,
  lob.code AS lob,
  COALESCE(p.platform_name, n.impacted_platform_name) AS platform,
  p.program_name,
  pi.program_state::text AS program_state,
  pi.domain_business,
  pi.program_category,
  pi.platform_model_id_dpn,
  pi.predecessor,
  pi.form_factor,
  pi.program_class,
  pi.program_phase::text AS program_phase,
  pi.tier,
  pi.cpu_architecture,
  pi.odm_supplier,
  pi.rts_calendar_year,
  pi.rts_calendar_quarter,
  pi.rts_calendar_month,
  pi.rto_calendar_year,
  pi.rto_calendar_quarter,
  pi.rto_calendar_month,
  pi.program_manager,
  pi.product_manager,
  pi.project_manager,
  pi.engineers,
  pi.quality_engineer,
  pi.procurement,
  pi.services,
  pi.goe_person,
  pi.edg,
  pi.concept_entry_target,
  pi.concept_exit_target,
  pi.define_exit_target,
  pi.ba_target,
  pi.dds_target,
  pi.plan_exit_target,
  pi.rfd_target,
  pi.develop_exit_target,
  pi.rts_target,
  pi.rto_target,
  assignee.display_name AS assignee_name,
  reporter.display_name AS reporter_name
"""


class NuddRepository:
    def __init__(self, session: AsyncSession) -> None:
        self._session = session

    async def count(self, filters: NuddFilters) -> int:
        where, params = build_where(filters)
        sql = text(f"SELECT COUNT(*) {NUDD_FROM} WHERE {where}")
        result = await self._session.execute(sql, params)
        return int(result.scalar_one())

    async def fetch_list(
        self,
        filters: NuddFilters,
        *,
        page: int,
        page_size: int,
        sort_column: str | None,
        sort_direction: str | None,
    ) -> list[dict[str, Any]]:
        where, params = build_where(filters)
        order = "n.jira_updated_at DESC"
        if sort_column and sort_column in SORT_COLUMNS and sort_direction in ("asc", "desc"):
            order = f"{SORT_COLUMNS[sort_column]} {sort_direction.upper()} NULLS LAST"
        offset = (page - 1) * page_size
        params["limit"] = page_size
        params["offset"] = offset
        sql = text(f"{LIST_SELECT} {NUDD_FROM} WHERE {where} ORDER BY {order} LIMIT :limit OFFSET :offset")
        result = await self._session.execute(sql, params)
        return [dict(row._mapping) for row in result]

    async def fetch_filter_options(self, user_email: str | None) -> dict[str, list[str]]:
        access_filter = ""
        params: dict[str, Any] = {}
        if user_email:
            access_filter = """
              AND p.id IN (
                SELECT uja.jira_platform_id
                FROM user_jira_platform_access uja
                JOIN assignee a ON a.id = uja.assignee_id
                WHERE a.email = :user_email
              )
            """
            params["user_email"] = user_email

        orgs = await self._session.execute(
            text(
                "SELECT code FROM catalog_organization WHERE is_active ORDER BY sort_order, code"
            )
        )
        funcs = await self._session.execute(
            text("SELECT code FROM catalog_function WHERE is_active ORDER BY sort_order, code")
        )
        statuses = await self._session.execute(
            text("SELECT DISTINCT status::text FROM jira_nudd ORDER BY 1")
        )
        tasks = await self._session.execute(
            text(
                "SELECT name FROM catalog_nudd_task WHERE is_active ORDER BY sort_order, name"
            )
        )
        lobs = await self._session.execute(
            text(
                f"""
                SELECT DISTINCT lob.code
                FROM catalog_lob lob
                JOIN jira_platform p ON p.catalog_lob_id = lob.id
                WHERE lob.is_active {access_filter}
                ORDER BY 1
                """
            ),
            params,
        )
        platforms = await self._session.execute(
            text(
                f"""
                SELECT DISTINCT p.platform_name
                FROM jira_platform p
                WHERE p.platform_name IS NOT NULL {access_filter}
                ORDER BY 1
                """
            ),
            params,
        )
        phases = await self._session.execute(
            text(
                f"""
                SELECT DISTINCT pi.program_phase::text
                FROM jira_platform_information pi
                JOIN jira_platform p ON p.id = pi.jira_platform_id
                WHERE pi.program_phase IS NOT NULL {access_filter}
                ORDER BY 1
                """
            ),
            params,
        )
        owners = await self._session.execute(
            text(
                f"""
                SELECT DISTINCT name FROM (
                  SELECT assignee.display_name AS name FROM jira_nudd n
                  JOIN assignee ON assignee.id = n.assignee_id
                  LEFT JOIN jira_platform p ON p.id = n.impacted_jira_platform_id
                  WHERE assignee.display_name IS NOT NULL
                  {"AND (n.impacted_jira_platform_id IS NULL OR p.id IN (SELECT uja.jira_platform_id FROM user_jira_platform_access uja JOIN assignee a ON a.id = uja.assignee_id WHERE a.email = :user_email))" if user_email else ""}
                  UNION
                  SELECT reporter.display_name FROM jira_nudd n
                  JOIN assignee reporter ON reporter.id = n.reporter_id
                  LEFT JOIN jira_platform p ON p.id = n.impacted_jira_platform_id
                  WHERE reporter.display_name IS NOT NULL
                  {"AND (n.impacted_jira_platform_id IS NULL OR p.id IN (SELECT uja.jira_platform_id FROM user_jira_platform_access uja JOIN assignee a ON a.id = uja.assignee_id WHERE a.email = :user_email))" if user_email else ""}
                ) t
                ORDER BY 1
                """
            ),
            params,
        )

        return {
            "organizations": [r[0] for r in orgs],
            "functions": [r[0] for r in funcs],
            "statuses": [r[0] for r in statuses],
            "lobs": [r[0] for r in lobs],
            "platforms": [r[0] for r in platforms],
            "phases": [r[0] for r in phases],
            "owners": [r[0] for r in owners],
            "tasks": [r[0] for r in tasks],
        }

    async def fetch_summary(self, filters: NuddFilters) -> dict[str, Any]:
        where, params = build_where(filters)
        summary_sql = text(
            f"""
            SELECT
              COUNT(*) AS total,
              COUNT(*) FILTER (WHERE n.status::text = 'Open') AS open,
              COUNT(*) FILTER (WHERE n.status::text = 'On hold') AS on_hold,
              COUNT(*) FILTER (WHERE n.status::text = 'Completed') AS completed,
              COUNT(*) FILTER (WHERE LOWER(n.risk_band) = 'high' OR n.risk_score > 5) AS high_risk,
              COUNT(*) FILTER (WHERE LOWER(n.risk_band) = 'medium' OR (n.risk_score BETWEEN 3 AND 5)) AS medium_risk,
              COUNT(*) FILTER (WHERE LOWER(n.risk_band) = 'low' OR (n.risk_score IS NOT NULL AND n.risk_score <= 2)) AS low_risk,
              COUNT(*) FILTER (
                WHERE n.close_date >= date_trunc('week', NOW())
                  AND n.close_date < date_trunc('week', NOW()) + INTERVAL '7 days'
              ) AS upcoming_week,
              COUNT(*) FILTER (
                WHERE n.close_date >= date_trunc('month', NOW())
                  AND n.close_date < date_trunc('month', NOW()) + INTERVAL '1 month'
              ) AS upcoming_month
            {NUDD_FROM}
            WHERE {where}
            """
        )
        summary_row = (await self._session.execute(summary_sql, params)).one()._mapping

        phase_sql = text(
            f"""
            SELECT
              COALESCE(pi.program_phase::text, 'Unknown') AS phase,
              COUNT(*) FILTER (WHERE LOWER(n.risk_band) = 'low' OR (n.risk_score IS NOT NULL AND n.risk_score <= 2)) AS low,
              COUNT(*) FILTER (WHERE LOWER(n.risk_band) = 'medium' OR (n.risk_score BETWEEN 3 AND 5)) AS medium,
              COUNT(*) FILTER (WHERE LOWER(n.risk_band) = 'high' OR n.risk_score > 5) AS high,
              COALESCE(SUM(n.risk_score), 0) AS total_score
            {NUDD_FROM}
            WHERE {where}
            GROUP BY pi.program_phase
            ORDER BY phase
            """
        )
        phase_rows = (await self._session.execute(phase_sql, params)).all()

        monthly_sql = text(
            f"""
            SELECT
              to_char(date_trunc('month', n.jira_created_at), 'Mon YYYY') AS month,
              COUNT(*) AS opened,
              COUNT(*) FILTER (WHERE n.status::text = 'Completed') AS closed,
              COUNT(*) FILTER (WHERE n.status::text NOT IN ('Completed')) AS active
            {NUDD_FROM}
            WHERE {where} AND n.jira_created_at IS NOT NULL
            GROUP BY date_trunc('month', n.jira_created_at)
            ORDER BY date_trunc('month', n.jira_created_at)
            """
        )
        monthly_rows = (await self._session.execute(monthly_sql, params)).all()

        scatter_sql = text(
            f"""
            SELECT n.jira_issue_key, n.impact, n.probability, n.risk_band
            {NUDD_FROM}
            WHERE {where} AND n.impact IS NOT NULL AND n.probability IS NOT NULL
            """
        )
        scatter_rows = (await self._session.execute(scatter_sql, params)).all()

        return {
            "summary": summary_row,
            "phase_rows": phase_rows,
            "monthly_rows": monthly_rows,
            "scatter_rows": scatter_rows,
        }

    async def ping(self) -> bool:
        result = await self._session.execute(text("SELECT 1"))
        return result.scalar_one() == 1
