"""FastAPI dependency wiring."""

from __future__ import annotations

from collections.abc import AsyncIterator
from typing import Annotated

from fastapi import Depends, Header
from sqlalchemy.ext.asyncio import AsyncSession

from app.database.repository import NuddRepository
from app.database.session import get_session
from app.services.nudds import NuddsService


async def get_db_session() -> AsyncIterator[AsyncSession]:
    async for session in get_session():
        yield session


async def get_user_email(
    x_user_email: Annotated[str | None, Header(alias="X-User-Email")] = None,
) -> str | None:
    return x_user_email


async def get_nudds_service(
    session: Annotated[AsyncSession, Depends(get_db_session)],
) -> AsyncIterator[NuddsService]:
    yield NuddsService(NuddRepository(session))


NuddsServiceDep = Annotated[NuddsService, Depends(get_nudds_service)]
UserEmailDep = Annotated[str | None, Depends(get_user_email)]
