"""FastAPI entry point for the GOE API service."""

from __future__ import annotations

import logging
import os
from contextlib import asynccontextmanager
from datetime import datetime, timezone

from fastapi import FastAPI
from prometheus_fastapi_instrumentator import Instrumentator
from pydantic import BaseModel

from app.api import nudds, status
from app.config import settings
from app.database.session import dispose_db, init_db

logging.basicConfig(
    level=getattr(logging, settings.log_level.upper(), logging.INFO),
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
)


@asynccontextmanager
async def lifespan(_app: FastAPI):
    init_db()
    yield
    await dispose_db()


app = FastAPI(
    title="GOE API",
    version="0.1.0",
    lifespan=lifespan,
)

app.include_router(status.router)
app.include_router(nudds.router)

if os.environ.get("GOE_API_DISABLE_METRICS", "").lower() not in ("1", "true", "yes"):
    Instrumentator().instrument(app).expose(app, include_in_schema=False)


class HealthResponse(BaseModel):
    status: str
    service: str
    timestamp: datetime


@app.get("/health", response_model=HealthResponse)
async def health() -> HealthResponse:
    return HealthResponse(
        status="ok",
        service="goe-api",
        timestamp=datetime.now(timezone.utc),
    )
