"""NUDDs business logic and row mapping."""

from __future__ import annotations

import json
import math
from datetime import date, datetime
from typing import Any

from app.api.nudds_schemas import (
    CalendarBlock,
    DatesBlock,
    FilterOptionsResponse,
    MonthlyOverviewItem,
    NuddItemResponse,
    NuddsListRequest,
    NuddsListResponse,
    NuddsSummaryRequest,
    NuddsSummaryResponse,
    PaginationResponse,
    PeopleBlock,
    RiskByPhaseItem,
    ScatterItem,
    SummaryMetrics,
)
from app.database.repository import NuddFilters, NuddRepository

ALLOWED_PAGE_SIZES = {10, 25, 50, 100}

RISK_COLORS = {
    "high": "#40155C",
    "medium": "#994CCC",
    "low": "#C9A8E9",
}


def _ts_ms(value: datetime | None) -> int | None:
    if value is None:
        return None
    if value.tzinfo is None:
        return int(value.timestamp() * 1000)
    return int(value.timestamp() * 1000)


def _format_date(value: date | datetime | None) -> str | None:
    if value is None:
        return None
    if isinstance(value, datetime):
        value = value.date()
    return value.strftime("%d/%b/%y")


def _format_datetime(value: datetime | None) -> str | None:
    if value is None:
        return None
    return value.strftime("%d/%b/%y %I:%M %p")


def _split_list_field(value: str | None) -> list[str]:
    if not value:
        return []
    value = value.strip()
    if value.startswith("["):
        try:
            parsed = json.loads(value)
            if isinstance(parsed, list):
                return [str(v) for v in parsed]
        except json.JSONDecodeError:
            pass
    return [part.strip() for part in value.split(",") if part.strip()]


def _parse_labels(value: Any) -> list[Any]:
    if value is None:
        return []
    if isinstance(value, list):
        return value
    if isinstance(value, str):
        try:
            parsed = json.loads(value)
            return parsed if isinstance(parsed, list) else []
        except json.JSONDecodeError:
            return []
    return []


def _risk_color(band: str | None, score: int | None) -> str:
    key = (band or "").lower()
    if key in RISK_COLORS:
        return RISK_COLORS[key]
    if score is not None and score > 5:
        return RISK_COLORS["high"]
    if score is not None and score >= 3:
        return RISK_COLORS["medium"]
    return RISK_COLORS["low"]


def row_to_item(row: dict[str, Any]) -> NuddItemResponse:
    return NuddItemResponse(
        id=row["jira_issue_key"],
        title=row["summary"],
        lob=row.get("lob"),
        platform=row.get("platform"),
        impact=row.get("impact"),
        probability=row.get("probability"),
        status=row["status"],
        created=_ts_ms(row.get("jira_created_at")),
        updated=_ts_ms(row.get("jira_updated_at")),
        closeDate=_ts_ms(row.get("close_date")),
        type=row.get("nudd_type"),
        resolution=row.get("resolution"),
        labels=_parse_labels(row.get("labels")),
        programName=row.get("program_name"),
        programState=row.get("program_state"),
        domainBusiness=row.get("domain_business"),
        programCategory=row.get("program_category"),
        platformModelId=row.get("platform_model_id_dpn"),
        predecessor=row.get("predecessor"),
        formFactor=row.get("form_factor"),
        programClass=row.get("program_class"),
        programPhase=row.get("program_phase"),
        tier=row.get("tier"),
        cpuArchitecture=row.get("cpu_architecture"),
        odmSupplier=row.get("odm_supplier"),
        rtsCalendar=CalendarBlock(
            year=row.get("rts_calendar_year"),
            quarter=row.get("rts_calendar_quarter"),
            month=row.get("rts_calendar_month"),
        ),
        rtoCalendar=CalendarBlock(
            year=row.get("rto_calendar_year"),
            quarter=row.get("rto_calendar_quarter"),
            month=row.get("rto_calendar_month"),
        ),
        people=PeopleBlock(
            assignee=row.get("assignee_name"),
            reporter=row.get("reporter_name"),
            programManager=row.get("program_manager"),
            projectManager=row.get("project_manager"),
            engineers=_split_list_field(row.get("engineers")),
            qualityEngineer=row.get("quality_engineer"),
            procurement=row.get("procurement"),
            services=_split_list_field(row.get("services")),
            goe=row.get("goe_person"),
            edg=row.get("edg"),
        ),
        dates=DatesBlock(
            created=_format_datetime(row.get("jira_created_at")),
            updated=_format_datetime(row.get("jira_updated_at")),
            conceptEntryTarget=_format_date(row.get("concept_entry_target")),
            conceptExitTarget=_format_date(row.get("concept_exit_target")),
            defineExitTarget=_format_date(row.get("define_exit_target")),
            baTarget=_format_date(row.get("ba_target")),
            ddsTarget=_format_date(row.get("dds_target")),
            planExitTarget=_format_date(row.get("plan_exit_target")),
            rfdTarget=_format_date(row.get("rfd_target")),
            developExitTarget=_format_date(row.get("develop_exit_target")),
            rtsTarget=_format_date(row.get("rts_target")),
            rtoTarget=_format_date(row.get("rto_target")),
        ),
    )


def request_to_filters(
    request: NuddsListRequest | NuddsSummaryRequest | None,
    user_email: str | None,
) -> NuddFilters:
    filters = NuddFilters(user_email=user_email)
    if request is None or request.filters is None:
        return filters

    g = request.filters.global_
    if g:
        filters.search = g.search
        filters.organizations = g.organizations or []
        filters.functions = g.functions or []
        filters.lobs = g.lobs or []
        filters.platforms = g.platforms or []
        filters.phases = g.phases or []
        filters.program_statuses = g.statuses or []
        filters.owners = g.owners or []
        filters.tasks = g.tasks or []

    t = request.filters.table
    if t:
        filters.table_id = t.id
        filters.table_status = t.status or []
        filters.table_lob = t.lob
        filters.table_platform = t.platform
        filters.table_impact = t.impact or []
        filters.table_probability = t.probability or []
        filters.table_risk = t.risk
        filters.table_band = t.band or []

    r = request.filters.risk
    if r:
        filters.min_impact = r.minImpact
        filters.max_impact = r.maxImpact
        filters.min_probability = r.minProbability
        filters.max_probability = r.maxProbability
        filters.min_risk_score = r.minRiskScore
        filters.max_risk_score = r.maxRiskScore
        filters.risk_bands = r.bands or []
        filters.risk_statuses = r.statuses or []

    return filters


class NuddsService:
    def __init__(self, repo: NuddRepository) -> None:
        self._repo = repo

    async def list_nudds(
        self,
        request: NuddsListRequest | None,
        user_email: str | None,
    ) -> NuddsListResponse:
        pagination = request.pagination if request and request.pagination else None
        page = pagination.page if pagination else 1
        page_size = pagination.pageSize if pagination else 25
        if page_size not in ALLOWED_PAGE_SIZES:
            page_size = 25

        sorting = request.sorting if request and request.sorting else None
        filters = request_to_filters(request, user_email)
        total = await self._repo.count(filters)
        total_pages = max(1, math.ceil(total / page_size)) if total else 0
        rows = await self._repo.fetch_list(
            filters,
            page=page,
            page_size=page_size,
            sort_column=sorting.column if sorting else None,
            sort_direction=sorting.direction if sorting else None,
        )
        return NuddsListResponse(
            data=[row_to_item(row) for row in rows],
            pagination=PaginationResponse(
                total=total,
                page=page,
                pageSize=page_size,
                totalPages=total_pages,
                hasNext=page < total_pages,
                hasPrevious=page > 1,
            ),
        )

    async def filter_options(self, user_email: str | None) -> FilterOptionsResponse:
        data = await self._repo.fetch_filter_options(user_email)
        return FilterOptionsResponse(**data)

    async def summary(
        self,
        request: NuddsSummaryRequest | None,
        user_email: str | None,
    ) -> NuddsSummaryResponse:
        filters = request_to_filters(request, user_email)
        raw = await self._repo.fetch_summary(filters)
        s = raw["summary"]
        open_count = int(s["open"] or 0)
        on_hold = int(s["on_hold"] or 0)
        return NuddsSummaryResponse(
            summary=SummaryMetrics(
                total=int(s["total"] or 0),
                active=open_count + on_hold,
                completed=int(s["completed"] or 0),
                onHold=on_hold,
                open=open_count,
                highRisk=int(s["high_risk"] or 0),
                mediumRisk=int(s["medium_risk"] or 0),
                lowRisk=int(s["low_risk"] or 0),
                upcomingThisWeek=int(s["upcoming_week"] or 0),
                upcomingThisMonth=int(s["upcoming_month"] or 0),
            ),
            riskByPhase=[
                RiskByPhaseItem(
                    phase=row.phase,
                    low=int(row.low or 0),
                    medium=int(row.medium or 0),
                    high=int(row.high or 0),
                    totalScore=int(row.total_score or 0),
                )
                for row in raw["phase_rows"]
            ],
            monthlyOverview=[
                MonthlyOverviewItem(
                    month=row.month,
                    opened=int(row.opened or 0),
                    closed=int(row.closed or 0),
                    active=int(row.active or 0),
                )
                for row in raw["monthly_rows"]
            ],
            scatterData=[
                ScatterItem(
                    id=row.jira_issue_key,
                    x=int(row.impact),
                    y=int(row.probability),
                    color=_risk_color(row.risk_band, None),
                )
                for row in raw["scatter_rows"]
            ],
        )

    async def ping_db(self) -> bool:
        return await self._repo.ping()
