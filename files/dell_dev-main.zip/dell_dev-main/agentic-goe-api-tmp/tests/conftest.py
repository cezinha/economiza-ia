"""Pytest configuration."""

from __future__ import annotations

import os

import pytest
from httpx import ASGITransport, AsyncClient

os.environ["GOE_API_DISABLE_DOTENV"] = "1"
os.environ["GOE_API_DISABLE_METRICS"] = "1"
os.environ.setdefault(
    "GOE_API_DATABASE_URL",
    "postgresql+asyncpg://jira_regrello:jira_regrello@localhost:5432/jira_regrello",
)


@pytest.fixture
async def api_client():
    from app.database.session import dispose_db, init_db
    from app.main import app

    init_db()
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as client:
        yield client
    await dispose_db()
