"""Integration tests against PostgreSQL (requires SQL/004 sample data)."""

import pytest
from httpx import AsyncClient


@pytest.mark.integration
@pytest.mark.asyncio
async def test_filter_options(api_client: AsyncClient) -> None:
    response = await api_client.get("/api/nudds/filter-options")
    if response.status_code == 500:
        pytest.skip("PostgreSQL not available")
    assert response.status_code == 200
    body = response.json()
    assert "organizations" in body
    assert len(body["organizations"]) >= 1


@pytest.mark.integration
@pytest.mark.asyncio
async def test_filter_options_scoped_by_user(api_client: AsyncClient) -> None:
    all_resp = await api_client.get("/api/nudds/filter-options")
    scoped = await api_client.get(
        "/api/nudds/filter-options",
        headers={"X-User-Email": "jane.doe@dell.com"},
    )
    if all_resp.status_code == 500:
        pytest.skip("PostgreSQL not available")
    assert scoped.status_code == 200
    assert len(scoped.json()["platforms"]) <= len(all_resp.json()["platforms"])
