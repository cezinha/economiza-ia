"""Config tests."""

import os

from app.config import Settings


def test_settings_load_from_env(monkeypatch) -> None:
    monkeypatch.setenv("GOE_API_DISABLE_DOTENV", "1")
    monkeypatch.setenv("GOE_API_ENVIRONMENT", "test")
    monkeypatch.setenv(
        "GOE_API_DATABASE_URL",
        "postgresql+asyncpg://u:p@localhost:5432/db",
    )
    settings = Settings()
    assert settings.environment == "test"
    assert "asyncpg" in settings.database_url
