"""Unit tests for mapper helpers."""

from datetime import datetime, timezone

from app.services.nudds import _risk_color, _split_list_field, _ts_ms, row_to_item


def test_ts_ms_from_naive_datetime() -> None:
    dt = datetime(2026, 1, 15, 12, 0, 0)
    assert _ts_ms(dt) == int(dt.timestamp() * 1000)


def test_split_list_field_comma_separated() -> None:
    assert _split_list_field("A, B, C") == ["A", "B", "C"]


def test_risk_color_high() -> None:
    assert _risk_color("high", 9) == "#40155C"


def test_row_to_item_minimal() -> None:
    item = row_to_item(
        {
            "jira_issue_key": "GOEQ-5001",
            "summary": "Test NUDD",
            "status": "Open",
            "jira_created_at": datetime(2026, 1, 10, 9, 0, tzinfo=timezone.utc),
            "jira_updated_at": datetime(2026, 3, 15, 14, 30, tzinfo=timezone.utc),
            "close_date": None,
            "labels": "[]",
        }
    )
    assert item.id == "GOEQ-5001"
    assert item.title == "Test NUDD"
    assert item.status == "Open"
