Endpoint
GET /api/nudds
Request Payload
{
  "filters": {
    "global": {
      "search": "string",
      "organizations": ["string"],
      "functions": ["string"],
      "lobs": ["string"],
      "platforms": ["string"],
      "phases": ["string"],
      "statuses": ["on-track", "at-risk", "delayed"],
      "owners": ["string"],
      "tasks": ["string"]
    },
    "table": {
      "id": "string",
      "status": ["Open", "On hold", "Completed"],
      "lob": "string",
      "platform": "string",
      "impact": [1, 2, 3],
      "probability": [1, 2, 3],
      "risk": "number",
      "band": ["Low", "Medium", "High"],
      "created": "number",
      "updated": "number",
      "closeDate": "number"
    }
  },
  "pagination": {
    "page": 1,
    "pageSize": 25
  },
  "sorting": {
    "column": "string",
    "direction": "asc" | "desc" | null
  }
}

 
Note: All fields are optional. Omit any field to use default behavior (no filter for filters, default pagination, no sorting).

## Request Parameters Description
Global Filters

- search: Global search term from header search input
- organizations: Filter by organization (CSG, ISG)
- functions: Filter by function (GOE, NPI, SChM)
- lobs: Filter by line of business (DT, NB, DnCP)
- platforms: Filter by platform names
- phases: Filter by program phases (Concept, Define, Plan, Qual, Ramp, Pilot, Incubate, - Develop, Launch)
- statuses: Filter by program status (on-track, at-risk, delayed)
- owners: Filter by program owners
- tasks: Filter by specific tasks

Table Filters
- id: Filter by NUDD ID
- status: Filter by NUDD status (Open, On hold, Completed)
- lob: Filter by impacted LOB
- platform: Filter by impacted platform
- impact: Filter by risk impact level (1=Low, 2=Medium, 3=High)
- probability: Filter by risk probability (1=Unlikely, 2=Possible, 3=Likely)
- risk: Filter by computed risk score (impact × probability)
- band: Filter by overall risk band (Low, Medium, High)
- created: Filter by creation date (Unix timestamp in milliseconds)
- updated: Filter by last updated date (Unix timestamp in milliseconds)
- closeDate: Filter by close date (Unix timestamp in milliseconds)

Pagination
- page: Current page number (default: 1)
- pageSize: Number of items per page (options: 10, 25, 50, 100, default: 25)

Sorting
- column: Column name to sort by
- direction: Sort direction (asc, desc, or null for no sorting)

Response Payload
{
   "data": [
     {
       "id": "NUDD-1042",
       "title": "Firmware regression on NVMe path",
       "lob": "DT",
       "platform": "Siple Low INT NVL S1",
       "impact": 3,
       "probability": 3,
       "status": "Open",
       "created": 1713765600000,
       "updated": 1715174400000,
       "closeDate": 1717070400000,
       "type": "RTS Metrics",
       "resolution": "Unresolved",
       "labels": [],
       "programName": "Siple Low INT",
       "programState": "Active",
       "domainBusiness": "PC-Commercial",
       "programCategory": "Dell Pro Precision Laptops",
       "platformModelId": "MB18270",
       "predecessor": "Kingda Ka ARL-HX CS 18",
       "formFactor": "CS",
       "programClass": "4",
       "programPhase": "Plan",
       "tier": "1",
       "cpuArchitecture": "NVL",
       "odmSupplier": "Compal",
       "rtsCalendar": {
         "year": "CY27",
         "quarter": "Q1",
         "month": "Feb"
       },
       "rtoCalendar": {
         "year": "CY27",
         "quarter": "Q1",
         "month": "Mar"
       },
       "people": {
         "assignee": "Wang, Jeff C",
         "reporter": "Wang, Jeff",
         "programManager": "Wang, Jeff",
         "projectManager": "Wang, Jeff",
         "engineers": ["Kacelenga, Ray", "Mckittrick, Allen", "Wu, Patrick"],
         "qualityEngineer": "Thakur, Sunny",
         "procurement": "Mesfin, Ted",
         "services": ["McMillian, Herbert", "Shih, Daniel"],
         "goe": "Nanry, Bill",
         "edg": "Draca, Boris"
       },
       "dates": {
         "created": "22/Apr/26 5:26 PM",
         "updated": "10/Apr/26 9:12 PM",
         "conceptEntryTarget": "12/May/26",
         "conceptExitTarget": "15/Jul/26",
         "defineExitTarget": "15/Jul/26",
         "baTarget": "26/Aug/26",
         "ddsTarget": "15/Jul/26",
         "planExitTarget": "07/Oct/26",
         "rfdTarget": "31/Mar/27",
         "developExitTarget": "07/Apr/27",
         "rtsTarget": "21/Apr/27",
         "rtoTarget": "27/Apr/27"
       }
     }
   ],
   "pagination": {
     "total": 150,
     "page": 1,
     "pageSize": 25,
     "totalPages": 6,
     "hasNext": true,
     "hasPrevious": false
   }
}

## Response Parameters Description
Data Items

- id: Unique NUDD identifier
- title: NUDD title/description
- lob: Impacted line of business
- platform: Impacted platform name
- impact: Risk impact level (1-3)
- probability: Risk probability (1-3)
- status: NUDD status (Open, On hold, Completed)
- created: Creation date (Unix timestamp in milliseconds)
- updated: Last updated date (Unix timestamp in milliseconds)
- closeDate: Expected close date (Unix timestamp in milliseconds)
- type: NUDD type/category
- resolution: Resolution status
- labels: Array of labels/tags
- programName: Associated program name
- programState: Program state (Active, etc.)
- domainBusiness: Business domain
- programCategory: Program category
- platformModelId: Platform model ID
- predecessor: Predecessor platform
- formFactor: Form factor (CS, NB, etc.)
- programClass: Program class
- programPhase: Current program phase
- tier: Program tier
- cpuArchitecture: CPU architecture
- odmSupplier: ODM supplier
- rtsCalendar: RTS calendar information
- rtoCalendar: RTO calendar information
- people: People information object
- dates: Important dates object

Pagination Metadata
- total: Total number of items matching filters
- page: Current page number
- pageSize: Number of items per page
- totalPages: Total number of pages
- hasNext: Whether there's a next page
- hasPrevious: Whether there's a previous page

Notes
- All date fields should use Unix timestamp in milliseconds for API requests and responses
- Filter arrays are optional - omit or use empty array to apply no filter
- Pagination is optional for summary endpoint (returns all data)
- Sorting is optional - omit or use null for default ordering
- The API should support partial filter sets for flexible usage
- All filters should be applied with AND logic within the same filter group
- Different filter groups (global, table, risk) should be combined with AND logic
- Empty request object {} should return all data with default pagination

