Endpoint
GET /api/nudds/filter-options

Description

Returns distinct filter option values for NUDDs dropdowns. These values are derived from Jira issues synchronized by the jira-connector service.

Notes:
- LOB is grouped by Business unit
- Platform is grouped by LOB
- Phases is grouped by Function
- Task is grouped by Phases
- Status is about NUDD issue.

Response Payload
{
  "organizations": ["CSG", "ISG"],
  "functions": ["GOE", "NPI", "SChM"],
  "statuses": ["Open", "On hold", "Completed", "In Scoping", "In Progress"],
  "platforms": ["Siple Low INT NVL S1", "Citadel NVL", "Prowler NVL CS 16"],
  "phases": ["Concept", "Define", "Plan", "Qual", "Ramp", "Pilot", "Incubate", "Develop", "Launch", "Pre-Ideate"],
  "lobs": ["DT", "NB", "DnCP", "Rugged"],
  "owners": ["Wang, Jeff C", "Darren Cheng(PEGATRONCORP)", "Daniel Reyes"],
  "tasks": []
}

Field Descriptions
- organizations: Organization values (CSG, ISG) NOT AVAILABLE in database currently, returns hardcoded values
- functions: Function values (GOE, NPI, SChM) NOT AVAILABLE in database currently, returns hardcoded values
- statuses: Distinct NUDD status values from Jira issues
- platforms: Distinct platform values from Jira custom fields (Program Platform(s), Impacted Platform(s))
- phases: Distinct OLP Phase values from Jira custom fields
- lobs: Distinct LOB values from Jira custom fields (Impacted LOBs)
- owners: Distinct assignee and reporter display names from Jira issues
- tasks: Task values NOT AVAILABLE in database currently, returns empty array

Notes
- This endpoint queries the document_jira table for distinct values where available
- Fields not available in the database (organizations, functions, tasks) return hardcoded or empty values
- Values are filtered based on user's platform access permissions
- Empty arrays are returned if no data is available
- This endpoint should be called on page load to populate filter dropdowns

