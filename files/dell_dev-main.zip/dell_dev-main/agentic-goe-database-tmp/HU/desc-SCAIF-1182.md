Endpoint
GET /api/nudds/summary  

Request Payload
 {
   "filters": {
     "global": {
       "search": "string",
       "organizations": ["string"],
       "functions": ["string"],
       "lobs": ["string"],
       "platforms": ["string"],
       "phases": ["string"],
       "statuses": ["on-track", "at-risk", "delayed"],
       "owners": ["string"],
       "tasks": ["string"]
     },
     "risk": {
       "minImpact": 1,
       "maxImpact": 3,
       "minProbability": 1,
       "maxProbability": 3,
       "minRiskScore": 1,
       "maxRiskScore": 9,
       "bands": ["Low", "Medium", "High"],
       "statuses": ["Open", "On hold", "Completed"]
     }
   }
 }

Note: All fields are optional. Omit any field to use default behavior (no filter).

Request Parameters Description
Global Filters

Same as table endpoint (search, organizations, functions, lobs, platforms, phases, statuses, owners, tasks)

Risk Filters (for summary metrics)
- minImpact: Minimum risk impact level (1-3)
- maxImpact: Maximum risk impact level (1-3)
- minProbability: Minimum risk probability (1-3)
- maxProbability: Maximum risk probability (1-3)
- minRiskScore: Minimum computed risk score
- maxRiskScore: Maximum computed risk score
- bands: Filter by risk bands (Low, Medium, High)
- statuses: Filter by NUDD statuses

Response Payload
{
  "summary": {
    "total": 150,
    "active": 120,
    "completed": 30,
    "onHold": 15,
    "open": 105,
    "highRisk": 25,
    "mediumRisk": 45,
    "lowRisk": 50,
    "upcomingThisWeek": 8,
    "upcomingThisMonth": 22
  },
  "riskByPhase": [
    {
      "phase": "Concept",
      "low": 5,
      "medium": 3,
      "high": 2,
      "totalScore": 17
    },
    {
      "phase": "Define",
      "low": 8,
      "medium": 7,
      "high": 4,
      "totalScore": 35
    },
    {
      "phase": "Plan",
      "low": 12,
      "medium": 15,
      "high": 8,
      "totalScore": 67
    },
    {
      "phase": "Qual",
      "low": 10,
      "medium": 12,
      "high": 6,
      "totalScore": 52
    },
    {
      "phase": "Ramp",
      "low": 8,
      "medium": 5,
      "high": 3,
      "totalScore": 32
    },
    {
      "phase": "Pilot",
      "low": 4,
      "medium": 2,
      "high": 1,
      "totalScore": 11
    },
    {
      "phase": "Incubate",
      "low": 2,
      "medium": 1,
      "high": 1,
      "totalScore": 6
    },
    {
      "phase": "Develop",
      "low": 1,
      "medium": 0,
      "high": 0,
      "totalScore": 1
    }
  ],
  "monthlyOverview": [
    {
      "month": "Jan 2026",
      "opened": 15,
      "closed": 12,
      "active": 3
    },
    {
      "month": "Feb 2026",
      "opened": 18,
      "closed": 14,
      "active": 4
    },
    {
      "month": "Mar 2026",
      "opened": 22,
      "closed": 16,
      "active": 6
    },
    {
      "month": "Apr 2026",
      "opened": 20,
      "closed": 15,
      "active": 5
    },
    {
      "month": "May 2026",
      "opened": 25,
      "closed": 18,
      "active": 7
    },
    {
      "month": "Jun 2026",
      "opened": 0,
      "closed": 0,
      "active": 0
    }
  ],
  "scatterData": [
    {
      "id": "NUDD-1042",
      "x": 3,
      "y": 3,
      "color": "#40155C"
    },
    {
      "id": "NUDD-1039",
      "x": 3,
      "y": 2,
      "color": "#994CCC"
    },
    {
      "id": "NUDD-1037",
      "x": 2,
      "y": 3,
      "color": "#994CCC"
    }
  ]
}

Response Parameters Description
- Summary Metrics
- total: Total number of NUDDs
- active: Number of active NUDDs (Open + On hold)
- completed: Number of completed NUDDs
- onHold: Number of NUDDs on hold
- open: Number of open NUDDs
- highRisk: Number of high-risk NUDDs (score > 5)
- mediumRisk: Number of medium-risk NUDDs (score 3-5)
- lowRisk: Number of low-risk NUDDs (score ≤ 2)
- upcomingThisWeek: Number of NUDDs closing this week
- upcomingThisMonth: Number of NUDDs closing this month 
- Risk by Phase
- phase: Program phase name
- low: Number of low-risk NUDDs in this phase
- medium: Number of medium-risk NUDDs in this phase
- high: Number of high-risk NUDDs in this phase
- totalScore: Sum of risk scores for this phase 

Monthly Overview
- month: Month label (e.g., "Jan 2026")
- opened: Number of NUDDs opened in this month
- closed: Number of NUDDs closed in this month
- active: Number of active NUDDs at end of month 

Scatter Data
- id: NUDD ID
- x: Impact value (1-3)
- y: Probability value (1-3)
- color: Color code based on risk level 

Notes
- All date fields should use Unix timestamp in milliseconds for API requests and responses
- Filter arrays are optional - omit or use empty array to apply no filter
- Pagination is optional for summary endpoint (returns all data)
- Sorting is optional - omit or use null for default ordering
- The API should support partial filter sets for flexible usage
- All filters should be applied with AND logic within the same filter group
- Different filter groups (global, table, risk) should be combined with AND logic
- Empty request object {} should return all data with default pagination

