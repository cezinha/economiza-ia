# NUDDs API Specification

## Overview

This document defines the API endpoints, request payloads, and response payloads for the NUDDs (Non-User Defined Defects) functionality in the GOE Dashboard. The API is designed to be flexible and reusable across different contexts, including the main NUDDs page and metric card modals.

---

## 1. NUDDs Table Data Endpoint

### Endpoint
```
GET /api/nudds
```

### Request Payload

```json
{
  "filters": {
    "global": {
      "search": "string",
      "organizations": ["string"],
      "functions": ["string"],
      "lobs": ["string"],
      "platforms": ["string"],
      "phases": ["string"],
      "statuses": ["on-track", "at-risk", "delayed"],
      "owners": ["string"],
      "tasks": ["string"]
    },
    "table": {
      "id": "string",
      "status": ["Open", "On hold", "Completed"],
      "lob": "string",
      "platform": "string",
      "impact": [1, 2, 3],
      "probability": [1, 2, 3],
      "risk": "number",
      "band": ["Low", "Medium", "High"],
      "created": "number",
      "updated": "number",
      "closeDate": "number"
    }
  },
  "pagination": {
    "page": 1,
    "pageSize": 25
  },
  "sorting": {
    "column": "string",
    "direction": "asc" | "desc" | null
  }
}
```

**Note**: All fields are optional. Omit any field to use default behavior (no filter for filters, default pagination, no sorting).

### Request Parameters Description

#### Global Filters
- **search**: Global search term from header search input
- **organizations**: Filter by organization (CSG, ISG)
- **functions**: Filter by function (GOE, NPI, SChM)
- **lobs**: Filter by line of business (DT, NB, DnCP)
- **platforms**: Filter by platform names
- **phases**: Filter by program phases (Concept, Define, Plan, Qual, Ramp, Pilot, Incubate, Develop, Launch)
- **statuses**: Filter by program status (on-track, at-risk, delayed)
- **owners**: Filter by program owners
- **tasks**: Filter by specific tasks

#### Table Filters
- **id**: Filter by NUDD ID
- **status**: Filter by NUDD status (Open, On hold, Completed)
- **lob**: Filter by impacted LOB
- **platform**: Filter by impacted platform
- **impact**: Filter by risk impact level (1=Low, 2=Medium, 3=High)
- **probability**: Filter by risk probability (1=Unlikely, 2=Possible, 3=Likely)
- **risk**: Filter by computed risk score (impact × probability)
- **band**: Filter by overall risk band (Low, Medium, High)
- **created**: Filter by creation date (Unix timestamp in milliseconds)
- **updated**: Filter by last updated date (Unix timestamp in milliseconds)
- **closeDate**: Filter by close date (Unix timestamp in milliseconds)

#### Pagination
- **page**: Current page number (default: 1)
- **pageSize**: Number of items per page (options: 10, 25, 50, 100, default: 25)

#### Sorting
- **column**: Column name to sort by
- **direction**: Sort direction (asc, desc, or null for no sorting)

### Response Payload

```json
{
  "data": [
    {
      "id": "NUDD-1042",
      "title": "Firmware regression on NVMe path",
      "lob": "DT",
      "platform": "Siple Low INT NVL S1",
      "impact": 3,
      "probability": 3,
      "status": "Open",
      "created": 1713765600000,
      "updated": 1715174400000,
      "closeDate": 1717070400000,
      "type": "RTS Metrics",
      "resolution": "Unresolved",
      "labels": [],
      "programName": "Siple Low INT",
      "programState": "Active",
      "domainBusiness": "PC-Commercial",
      "programCategory": "Dell Pro Precision Laptops",
      "platformModelId": "MB18270",
      "predecessor": "Kingda Ka ARL-HX CS 18",
      "formFactor": "CS",
      "programClass": "4",
      "programPhase": "Plan",
      "tier": "1",
      "cpuArchitecture": "NVL",
      "odmSupplier": "Compal",
      "rtsCalendar": {
        "year": "CY27",
        "quarter": "Q1",
        "month": "Feb"
      },
      "rtoCalendar": {
        "year": "CY27",
        "quarter": "Q1",
        "month": "Mar"
      },
      "people": {
        "assignee": "Wang, Jeff C",
        "reporter": "Wang, Jeff",
        "programManager": "Wang, Jeff",
        "projectManager": "Wang, Jeff",
        "engineers": ["Kacelenga, Ray", "Mckittrick, Allen", "Wu, Patrick"],
        "qualityEngineer": "Thakur, Sunny",
        "procurement": "Mesfin, Ted",
        "services": ["McMillian, Herbert", "Shih, Daniel"],
        "goe": "Nanry, Bill",
        "edg": "Draca, Boris"
      },
      "dates": {
        "created": "22/Apr/26 5:26 PM",
        "updated": "10/Apr/26 9:12 PM",
        "conceptEntryTarget": "12/May/26",
        "conceptExitTarget": "15/Jul/26",
        "defineExitTarget": "15/Jul/26",
        "baTarget": "26/Aug/26",
        "ddsTarget": "15/Jul/26",
        "planExitTarget": "07/Oct/26",
        "rfdTarget": "31/Mar/27",
        "developExitTarget": "07/Apr/27",
        "rtsTarget": "21/Apr/27",
        "rtoTarget": "27/Apr/27"
      }
    }
  ],
  "pagination": {
    "total": 150,
    "page": 1,
    "pageSize": 25,
    "totalPages": 6,
    "hasNext": true,
    "hasPrevious": false
  }
}
```

### Response Parameters Description

#### Data Items
- **id**: Unique NUDD identifier
- **title**: NUDD title/description
- **lob**: Impacted line of business
- **platform**: Impacted platform name
- **impact**: Risk impact level (1-3)
- **probability**: Risk probability (1-3)
- **status**: NUDD status (Open, On hold, Completed)
- **created**: Creation date (Unix timestamp in milliseconds)
- **updated**: Last updated date (Unix timestamp in milliseconds)
- **closeDate**: Expected close date (Unix timestamp in milliseconds)
- **type**: NUDD type/category
- **resolution**: Resolution status
- **labels**: Array of labels/tags
- **programName**: Associated program name
- **programState**: Program state (Active, etc.)
- **domainBusiness**: Business domain
- **programCategory**: Program category
- **platformModelId**: Platform model ID
- **predecessor**: Predecessor platform
- **formFactor**: Form factor (CS, NB, etc.)
- **programClass**: Program class
- **programPhase**: Current program phase
- **tier**: Program tier
- **cpuArchitecture**: CPU architecture
- **odmSupplier**: ODM supplier
- **rtsCalendar**: RTS calendar information
- **rtoCalendar**: RTO calendar information
- **people**: People information object
- **dates**: Important dates object

#### Pagination Metadata
- **total**: Total number of items matching filters
- **page**: Current page number
- **pageSize**: Number of items per page
- **totalPages**: Total number of pages
- **hasNext**: Whether there's a next page
- **hasPrevious**: Whether there's a previous page

---

## 2. NUDDs Filter Options Endpoint

### Endpoint

```http
GET /api/nudds/filter-options
```

### Description

Returns distinct filter option values for NUDDs dropdowns. These values are derived from Jira issues synchronized by the jira-connector service.

### Response Payload

```json
{
  "organizations": ["CSG", "ISG"],
  "functions": ["GOE", "NPI", "SChM"],
  "statuses": ["Open", "On hold", "Completed", "In Scoping", "In Progress"],
  "platforms": ["Siple Low INT NVL S1", "Citadel NVL", "Prowler NVL CS 16"],
  "phases": ["Concept", "Define", "Plan", "Qual", "Ramp", "Pilot", "Incubate", "Develop", "Launch", "Pre-Ideate"],
  "lobs": ["DT", "NB", "DnCP", "Rugged"],
  "owners": ["Wang, Jeff C", "Darren Cheng(PEGATRONCORP)", "Daniel Reyes"],
  "tasks": []
}
```

### Field Descriptions

- **organizations**: Organization values (CSG, ISG) - **NOT AVAILABLE in database currently, returns hardcoded values**
- **functions**: Function values (GOE, NPI, SChM) - **NOT AVAILABLE in database currently, returns hardcoded values**
- **statuses**: Distinct NUDD status values from Jira issues
- **platforms**: Distinct platform values from Jira custom fields (Program Platform(s), Impacted Platform(s))
- **phases**: Distinct OLP Phase values from Jira custom fields
- **lobs**: Distinct LOB values from Jira custom fields (Impacted LOBs)
- **owners**: Distinct assignee and reporter display names from Jira issues
- **tasks**: Task values - **NOT AVAILABLE in database currently, returns empty array**

### Notes

- This endpoint queries the `document_jira` table for distinct values where available
- Fields not available in the database (organizations, functions, tasks) return hardcoded or empty values
- Values are filtered based on user's platform access permissions
- Empty arrays are returned if no data is available
- This endpoint should be called on page load to populate filter dropdowns

---

## 3. NUDDs Summary Data Endpoint

### Endpoint
```
GET /api/nudds/summary
```

### Request Payload

```json
{
  "filters": {
    "global": {
      "search": "string",
      "organizations": ["string"],
      "functions": ["string"],
      "lobs": ["string"],
      "platforms": ["string"],
      "phases": ["string"],
      "statuses": ["on-track", "at-risk", "delayed"],
      "owners": ["string"],
      "tasks": ["string"]
    },
    "risk": {
      "minImpact": 1,
      "maxImpact": 3,
      "minProbability": 1,
      "maxProbability": 3,
      "minRiskScore": 1,
      "maxRiskScore": 9,
      "bands": ["Low", "Medium", "High"],
      "statuses": ["Open", "On hold", "Completed"]
    }
  }
}
```

**Note**: All fields are optional. Omit any field to use default behavior (no filter).

### Request Parameters Description

#### Global Filters
Same as table endpoint (search, organizations, functions, lobs, platforms, phases, statuses, owners, tasks)

#### Risk Filters (for summary metrics)
- **minImpact**: Minimum risk impact level (1-3)
- **maxImpact**: Maximum risk impact level (1-3)
- **minProbability**: Minimum risk probability (1-3)
- **maxProbability**: Maximum risk probability (1-3)
- **minRiskScore**: Minimum computed risk score
- **maxRiskScore**: Maximum computed risk score
- **bands**: Filter by risk bands (Low, Medium, High)
- **statuses**: Filter by NUDD statuses

### Response Payload

```json
{
  "summary": {
    "total": 150,
    "active": 120,
    "completed": 30,
    "onHold": 15,
    "open": 105,
    "highRisk": 25,
    "mediumRisk": 45,
    "lowRisk": 50,
    "upcomingThisWeek": 8,
    "upcomingThisMonth": 22
  },
  "riskByPhase": [
    {
      "phase": "Concept",
      "low": 5,
      "medium": 3,
      "high": 2,
      "totalScore": 17
    },
    {
      "phase": "Define",
      "low": 8,
      "medium": 7,
      "high": 4,
      "totalScore": 35
    },
    {
      "phase": "Plan",
      "low": 12,
      "medium": 15,
      "high": 8,
      "totalScore": 67
    },
    {
      "phase": "Qual",
      "low": 10,
      "medium": 12,
      "high": 6,
      "totalScore": 52
    },
    {
      "phase": "Ramp",
      "low": 8,
      "medium": 5,
      "high": 3,
      "totalScore": 32
    },
    {
      "phase": "Pilot",
      "low": 4,
      "medium": 2,
      "high": 1,
      "totalScore": 11
    },
    {
      "phase": "Incubate",
      "low": 2,
      "medium": 1,
      "high": 1,
      "totalScore": 6
    },
    {
      "phase": "Develop",
      "low": 1,
      "medium": 0,
      "high": 0,
      "totalScore": 1
    }
  ],
  "monthlyOverview": [
    {
      "month": "Jan 2026",
      "opened": 15,
      "closed": 12,
      "active": 3
    },
    {
      "month": "Feb 2026",
      "opened": 18,
      "closed": 14,
      "active": 4
    },
    {
      "month": "Mar 2026",
      "opened": 22,
      "closed": 16,
      "active": 6
    },
    {
      "month": "Apr 2026",
      "opened": 20,
      "closed": 15,
      "active": 5
    },
    {
      "month": "May 2026",
      "opened": 25,
      "closed": 18,
      "active": 7
    },
    {
      "month": "Jun 2026",
      "opened": 0,
      "closed": 0,
      "active": 0
    }
  ],
  "scatterData": [
    {
      "id": "NUDD-1042",
      "x": 3,
      "y": 3,
      "color": "#40155C"
    },
    {
      "id": "NUDD-1039",
      "x": 3,
      "y": 2,
      "color": "#994CCC"
    },
    {
      "id": "NUDD-1037",
      "x": 2,
      "y": 3,
      "color": "#994CCC"
    }
  ]
}
```

### Response Parameters Description

#### Summary Metrics
- **total**: Total number of NUDDs
- **active**: Number of active NUDDs (Open + On hold)
- **completed**: Number of completed NUDDs
- **onHold**: Number of NUDDs on hold
- **open**: Number of open NUDDs
- **highRisk**: Number of high-risk NUDDs (score > 5)
- **mediumRisk**: Number of medium-risk NUDDs (score 3-5)
- **lowRisk**: Number of low-risk NUDDs (score ≤ 2)
- **upcomingThisWeek**: Number of NUDDs closing this week
- **upcomingThisMonth**: Number of NUDDs closing this month

#### Risk by Phase
- **phase**: Program phase name
- **low**: Number of low-risk NUDDs in this phase
- **medium**: Number of medium-risk NUDDs in this phase
- **high**: Number of high-risk NUDDs in this phase
- **totalScore**: Sum of risk scores for this phase

#### Monthly Overview
- **month**: Month label (e.g., "Jan 2026")
- **opened**: Number of NUDDs opened in this month
- **closed**: Number of NUDDs closed in this month
- **active**: Number of active NUDDs at end of month

#### Scatter Data
- **id**: NUDD ID
- **x**: Impact value (1-3)
- **y**: Probability value (1-3)
- **color**: Color code based on risk level

---

## 4. Flexible Usage for Metric Card Modals

Both endpoints are designed to be flexible and can be called with partial filter sets when opened from metric card modals. For example:

### High Risk Metric Card Modal Request
```json
{
  "filters": {
    "global": {
      "bands": ["High"],
      "statuses": ["Open"]
    }
  }
}
```

### Upcoming Metric Card Modal Request
```json
{
  "filters": {
    "global": {
      "closeDate": {
        "from": 1718611200000,
        "to": 1719216000000
      }
    }
  }
}
```

### Active Metric Card Modal Request
```json
{
  "filters": {
    "global": {
      "statuses": ["Open", "On hold"]
    }
  }
}
```

---

## 5. Error Responses

### 400 Bad Request
```json
{
  "error": "Bad Request",
  "message": "Invalid filter parameters",
  "details": {
    "field": "impact",
    "issue": "Value must be between 1 and 3"
  }
}
```

### 401 Unauthorized
```json
{
  "error": "Unauthorized",
  "message": "Authentication required"
}
```

### 500 Internal Server Error
```json
{
  "error": "Internal Server Error",
  "message": "An unexpected error occurred",
  "details": "Error message from server"
}
```

---

## 6. Notes

1. All date fields should use Unix timestamp in milliseconds for API requests and responses
2. Filter arrays are optional - omit or use empty array to apply no filter
3. Pagination is optional for summary endpoint (returns all data)
4. Sorting is optional - omit or use null for default ordering
5. The API should support partial filter sets for flexible usage
6. All filters should be applied with AND logic within the same filter group
7. Different filter groups (global, table, risk) should be combined with AND logic
8. Empty request object `{}` should return all data with default pagination
