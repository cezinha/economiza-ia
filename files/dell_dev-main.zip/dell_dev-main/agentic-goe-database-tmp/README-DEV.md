# Development setup (PostgreSQL in Docker)

Local development guide for the Jira ↔ Regrello orchestrator database. Target engine: **PostgreSQL 17+** (schema `public`).

For the data model and script descriptions, see [`README.md`](README.md).

---

## Prerequisites

- Docker Desktop or Docker Engine with Compose v2
- Bash (for the helper script)
- `psql` on the host is **optional** — scripts run inside the container via `docker compose exec`

---

## 1. Start PostgreSQL

From the repository root (`agentic-goe-database-tmp/`):

```bash
docker compose up -d
docker compose ps
```

Wait until the `postgres` service shows **healthy**.

Optional: copy [`.env.example`](.env.example) to `.env` to override database name, user, password, or host port.

| Variable | Default |
|----------|---------|
| `POSTGRES_DB` | `jira_regrello` |
| `POSTGRES_USER` | `jira_regrello` |
| `POSTGRES_PASSWORD` | `jira_regrello` |
| `POSTGRES_PORT` | `5432` |

---

## 2. Schema

**No extra schema setup is required.** PostgreSQL uses the `public` schema by default.

The DDL in [`SQL/001_jira_regrello_schema.sql`](SQL/001_jira_regrello_schema.sql) creates enums and tables in `public` (`current_schema()`). You do not need to run `CREATE SCHEMA` before applying the scripts.

If you later need a dedicated schema (e.g. to coexist with GOE tables in the same database), you would add `CREATE SCHEMA` and `SET search_path` before running the SQL files. That is out of scope for the current dev setup.

---

## 3. Apply SQL scripts (in order)

Scripts live in [`SQL/`](SQL/) and must run in this order:

| Order | Script | Required |
|-------|--------|----------|
| 1 | [`SQL/001_jira_regrello_schema.sql`](SQL/001_jira_regrello_schema.sql) | Yes — DDL (enums, 23 tables) |
| 2 | [`SQL/002_jira_regrello_catalog_seed.sql`](SQL/002_jira_regrello_catalog_seed.sql) | Yes — NUDDs filter catalogs |
| 3 | [`SQL/003_nudd_filter_views.sql`](SQL/003_nudd_filter_views.sql) | Yes — filter views |
| 4 | [`SQL/004_jira_regrello_sample_data.sql`](SQL/004_jira_regrello_sample_data.sql) | No — dev/demo data |

### Option A — helper script (recommended)

```bash
chmod +x scripts/apply-sql.sh   # once
./scripts/apply-sql.sh
```

Skip sample data:

```bash
./scripts/apply-sql.sh --skip-sample
```

### Option B — manual via Docker

```bash
docker compose exec -T postgres psql -U jira_regrello -d jira_regrello -v ON_ERROR_STOP=1 -f /sql/001_jira_regrello_schema.sql
docker compose exec -T postgres psql -U jira_regrello -d jira_regrello -v ON_ERROR_STOP=1 -f /sql/002_jira_regrello_catalog_seed.sql
docker compose exec -T postgres psql -U jira_regrello -d jira_regrello -v ON_ERROR_STOP=1 -f /sql/003_nudd_filter_views.sql
docker compose exec -T postgres psql -U jira_regrello -d jira_regrello -v ON_ERROR_STOP=1 -f /sql/004_jira_regrello_sample_data.sql
```

All scripts are idempotent where possible (`IF NOT EXISTS`, `ON CONFLICT DO NOTHING`).

---

## 4. Quick verification

Connect interactively:

```bash
docker compose exec -it postgres psql -U jira_regrello -d jira_regrello
```

Smoke tests (after applying through `004`):

```sql
SELECT COUNT(*) FROM catalog_organization;          -- expect 2
SELECT COUNT(*) FROM jira_nudd;                     -- expect 7
SELECT DISTINCT status FROM jira_nudd;
SELECT * FROM v_filter_org_branch LIMIT 5;
\dt
```

---

## 5. Connection string (local apps)

```
postgresql://jira_regrello:jira_regrello@localhost:5432/jira_regrello
```

---

## 6. Reset / teardown

Remove container and data volume, then re-apply:

```bash
docker compose down -v
docker compose up -d
./scripts/apply-sql.sh
```

Stop without deleting data:

```bash
docker compose down
```

---

## 7. What not to run

[`REF/`](REF/) contains read-only GOE reference dumps (`001_agentic_goe_schema.sql`, `001_agentic_goe_reference_data.sql`). They are **not** part of the orchestrator dev pipeline. Use them only as naming/mapping reference.

---

## Troubleshooting

| Issue | Action |
|-------|--------|
| Port 5432 already in use | Set `POSTGRES_PORT=5433` in `.env` and reconnect on the new port |
| `Postgres container is not running` | Run `docker compose up -d` |
| Script fails mid-way | Fix the error, then re-run `./scripts/apply-sql.sh` (scripts are idempotent) |
| Empty `v_filter_org_branch` | Run `004` or insert `jira_platform` rows with `catalog_lob_id` |
