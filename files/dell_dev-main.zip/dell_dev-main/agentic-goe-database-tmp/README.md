# Jira ↔ Regrello Data Model

Data model for the **launch orchestrator** that syncs Jira entities (Platform, issues) with Regrello instances (workflows, action items / tasks).

The source of truth for columns, types, and indexes is [`db_model_jira_regrello.dbml`](db_model_jira_regrello.dbml).

---

## Business Rules

1. **Jira is authoritative.** Every sync entity originates from Jira. A `task` always requires `jira_task_id`; `regrello_task_id` is optional until the action item exists in Regrello.
2. **Platform → workflows (1:N).** One `jira_platform` can spawn multiple `regrello_workflow` instances; there is no 1:1 mapping between platform and workflow.
3. **Issue / action item level sync.** Each `task` row links a Jira issue (`jira_task`) to a Regrello action item (`regrello_task`) when the pair exists.
4. **Shared assignees.** Assignees are defined in Jira (`sync_assignee`) and propagated to Regrello (`regrello_assignee`) using the same `assignee` row.
5. **Sync states.** The `task_state` enum includes `JIRA_ONLY` and `PENDING_REGRELLO` for issues that do not yet have a Regrello counterpart.
6. **NUDDs dashboard.** `jira_nudd` stores NUDD issues (risk, status, impacted platform). Filter dropdowns use hierarchical `catalog_*` tables with FK chains. LOB is canonical on `jira_platform.line_of_business` / `catalog_lob_id`; `domain_business` is separate on `jira_platform_information`.

---

## Entity-Relationship Diagram

Attribute-free diagram showing entities and cardinalities only.

```mermaid
erDiagram
    catalog_organization ||--o{ catalog_lob : has
    catalog_lob ||--o{ jira_platform : scopes
    catalog_function ||--o{ catalog_phase : has
    catalog_phase ||--o{ catalog_nudd_task : has
    jira_platform ||--|| jira_platform_information : extends
    jira_project ||--o{ jira_platform_project : enrolls
    jira_platform ||--o{ jira_platform_project : scoped_to
    jira_project ||--o{ jira_nudd : contains
    catalog_lob ||--o{ jira_nudd : impacted_lob
    catalog_nudd_task ||--o{ jira_nudd : filters
    jira_platform ||--o{ jira_nudd : enriches
    assignee ||--o{ user_jira_platform_access : grants
    jira_platform ||--o{ user_jira_platform_access : visible
    jira_platform ||--o{ sync_assignee : has
    assignee ||--o{ sync_assignee : ""
    jira_platform ||--o{ jira_task : contains
    jira_task ||--o{ jira_comment : has
    jira_platform ||--o{ regrello_workflow : spawns
    regrello_workflow ||--o{ regrello_stage : has
    regrello_workflow ||--o{ regrello_task : has
    regrello_task ||--o{ regrello_assignee : has
    assignee ||--o{ regrello_assignee : ""
    regrello_task ||--o{ regrello_comment : has
    regrello_task ||--o{ regrello_document : has
    regrello_comment ||--o{ regrello_document : has
    jira_task ||--o| task : syncs
    regrello_task ||--o| task : syncs
    task ||--|| sync_state : tracks
    assignee ||--o{ regrello_workflow : owns
    assignee ||--o{ jira_nudd : assignee
    assignee ||--o{ jira_nudd : reporter
```

### NUDDs filter hierarchy (SCAIF-1179)

```mermaid
flowchart TB
  subgraph orgBranch [Organization branch]
    Org[catalog_organization]
    Lob[catalog_lob]
    Plat[jira_platform]
    Org --> Lob --> Plat
  end
  subgraph funcBranch [Function branch]
    Func[catalog_function]
    Phase[catalog_phase]
    FTask[catalog_nudd_task]
    Func --> Phase --> FTask
  end
  Nudd[jira_nudd]
  Nudd --> Plat
  Nudd --> Lob
  Nudd --> FTask
  Nudd --> NuddStatus["jira_nudd.status"]
```

---

## Table Descriptions

### `jira_platform`

Root entity on the Jira side. Represents a **Platform** (epic, initiative, or container issue depending on the Jira project). Enriched with operational fields from GOE `platform` and Jira issue identifiers from GOE `platform_information`.

| Aspect | Detail |
|--------|--------|
| **Relationships** | Parent of `jira_task`, `regrello_workflow`, `sync_assignee`, and `jira_platform_project`; 1:1 with `jira_platform_information`; optional predecessor via self-reference on `jira_platform_information` |
| **Source** | Jira API; GOE `platform` / `platform_information` (header fields) |
| **Notes** | `platform_id` is the business identifier. `jira_issue_key` / `jira_issue_id` identify the Jira issue (same column names as GOE). **LOB** is canonical via `catalog_lob_id`; `line_of_business` is denormalized (= `catalog_lob.code`). `domain_business` lives on `jira_platform_information`, not here. |

---

### `jira_platform_information`

1:1 extension of `jira_platform` with the Jira custom-field snapshot (milestones, people, program metadata). Aligned with GOE `platform_information`.

| Aspect | Detail |
|--------|--------|
| **Relationships** | `jira_platform_id` → `jira_platform` (unique); optional `predecessor_jira_platform_id` → `jira_platform` |
| **Source** | Jira API (platform issue custom fields) |
| **Notes** | `domain_business` maps to API `domainBusiness`. `program_class` maps to `programClass`. `lob_code` is deprecated in favor of `jira_platform.line_of_business` / `catalog_lob_id`. |

---

### `jira_project`

Catalog of Jira projects available for platform enrollment. Aligned with GOE `jira_project`.

| Aspect | Detail |
|--------|--------|
| **Relationships** | Parent of `jira_platform_project` |
| **Source** | Jira API / GOE configuration |
| **Notes** | `project_key` is unique. Filter and issue-type configuration stored as JSON fields. |

---

### `jira_platform_project`

N:M junction linking a platform to the Jira projects it is enrolled in. Aligned with GOE `platform_jira_project`.

| Aspect | Detail |
|--------|--------|
| **Relationships** | `jira_platform_id` → `jira_platform`; `jira_project_id` → `jira_project` |
| **Source** | GOE configuration / orchestrator |
| **Notes** | `(jira_platform_id, jira_project_id)` pair is unique. Naming: `jira_` prefix + `platform_project` relationship. |

---

### `assignee`

Master person record shared between Jira and Regrello.

| Aspect | Detail |
|--------|--------|
| **Relationships** | Referenced by `sync_assignee`, `regrello_assignee`, and optionally as owner on `regrello_workflow` |
| **Source** | Jira (primary); `regrello_party_id` is populated when syncing with Regrello |
| **Notes** | `email` is the reconciliation key across systems. |

---

### `sync_assignee`

Junction table between a platform and its assignees. Source of truth for assignees from Jira.

| Aspect | Detail |
|--------|--------|
| **Relationships** | `jira_platform_id` → `jira_platform`; `assignee_id` → `assignee` |
| **Source** | Jira API (Platform issue assignees) |
| **Notes** | When creating or updating Regrello action items, the same `assignee_id` values are copied to `regrello_assignee`. |

---

### `jira_task`

Individual Jira issue (task, subtask, etc.) belonging to a platform.

| Aspect | Detail |
|--------|--------|
| **Relationships** | `jira_platform_id` → `jira_platform`; parent of `jira_comment`; referenced by `task` (required) |
| **Source** | Jira API |
| **Notes** | Formerly named `jira_data`. `jira_key` is unique (e.g. `PROJ-123`). |

---

### `jira_comment`

Comment on a Jira issue linked to the sync model via `jira_task`. Aligned with GOE `jira_comment`, adapted to use `jira_task_id` instead of the ingestion pipeline `document_id`.

| Aspect | Detail |
|--------|--------|
| **Relationships** | `jira_task_id` → `jira_task` |
| **Source** | Jira API |
| **Notes** | `(jira_task_id, comment_id)` pair is unique. Issue key is resolved via `jira_task.jira_key`. |

---

### NUDDs filter catalogs

Hierarchical catalog tables for SCAIF-1179 filter-options. FK chains avoid cumbersome SQL on string matching.

| Table | Parent | Purpose |
|-------|--------|---------|
| `catalog_organization` | — | Business unit (CSG, ISG) |
| `catalog_lob` | `catalog_organization` | LOB; `code` = `jira_platform.line_of_business` |
| `catalog_function` | — | Function (GOE, NPI, SChM) |
| `catalog_phase` | `catalog_function` | OLP Phase |
| `catalog_nudd_task` | `catalog_phase` | UI filter task (not `jira_task`) |

---

### `jira_nudd`

NUDD Jira issue for the GOE Dashboard (SCAIF-1178/1182). Risk fields and status; enriched via join to `jira_platform` / `jira_platform_information`.

| Aspect | Detail |
|--------|--------|
| **Relationships** | `jira_project_id` → `jira_project`; `catalog_lob_id` → `catalog_lob`; `catalog_nudd_task_id` → `catalog_nudd_task`; `impacted_jira_platform_id` → `jira_platform`; assignee/reporter → `assignee` |
| **Source** | Jira API (NUDD issue type) |
| **Notes** | `status` uses `nudd_status` enum. Filter-options `statuses` = `DISTINCT jira_nudd.status`. |

**Enrichment join (SCAIF-1178 response):**

```sql
SELECT n.*, pi.*
FROM jira_nudd n
LEFT JOIN jira_platform p ON p.id = n.impacted_jira_platform_id
LEFT JOIN jira_platform_information pi ON pi.jira_platform_id = p.id;
```

---

### `user_jira_platform_access`

User visibility scope for platforms (SCAIF-1179 filter-options).

| Aspect | Detail |
|--------|--------|
| **Relationships** | `assignee_id` → `assignee`; `jira_platform_id` → `jira_platform` |
| **Source** | GOE access configuration |
| **Notes** | `(assignee_id, jira_platform_id)` pair is unique. |

---

### NUDDs filter SQL

Cascade queries use FK chains (`parent_id = ?`). Optional views pre-join hierarchies: [`SQL/003_nudd_filter_views.sql`](SQL/003_nudd_filter_views.sql).

| Level | Query pattern |
|-------|----------------|
| LOBs by org | `SELECT lob_id, lob_code FROM v_filter_org_branch WHERE organization_code = ?` |
| Platforms by LOB | `SELECT platform_id, platform_name FROM v_filter_org_branch WHERE lob_id = ?` |
| Phases by function | `SELECT phase_id, phase_name FROM v_filter_function_branch WHERE function_code = ?` |
| Tasks by phase | `SELECT task_id, task_name FROM v_filter_function_branch WHERE phase_id = ?` |
| Statuses | `SELECT DISTINCT status FROM jira_nudd ORDER BY 1` |

Catalog seed data: [`SQL/002_jira_regrello_catalog_seed.sql`](SQL/002_jira_regrello_catalog_seed.sql).

---

### `regrello_workflow`

Regrello workflow instance spawned from a Jira platform.

| Aspect | Detail |
|--------|--------|
| **Relationships** | `jira_platform_id` → `jira_platform`; parent of `regrello_stage` and `regrello_task`; optional owner → `assignee` |
| **Source** | Regrello GraphQL (`workflows`) |
| **Notes** | One platform can have N workflows. Fields such as `scheduleStatus`, `percentComplete`, and `plannedDueOn` come from the workflow query. |

---

### `regrello_stage`

Stage (phase) within a Regrello workflow.

| Aspect | Detail |
|--------|--------|
| **Relationships** | `regrello_workflow_id` → `regrello_workflow` |
| **Source** | Regrello GraphQL (`workflows.stages`) |
| **Notes** | `(regrello_workflow_id, stage_id)` pair is unique. |

---

### `regrello_task`

Regrello action item (Task in the UI). Maps to each element in `openActionItems` from the workflow GraphQL response.

| Aspect | Detail |
|--------|--------|
| **Relationships** | `regrello_workflow_id` → `regrello_workflow`; parent of `regrello_assignee`, `regrello_comment`, `regrello_document`; optionally referenced by `task` |
| **Source** | Regrello GraphQL (`openActionItems` / `actionItem`) |
| **Notes** | Formerly named `regrello_data`. `regrello_uuid` enables lookup via `actionItem(input: { uuid })`. |

---

### `regrello_assignee`

Assignees for a Regrello action item.

| Aspect | Detail |
|--------|--------|
| **Relationships** | `regrello_task_id` → `regrello_task`; `assignee_id` → `assignee` |
| **Source** | Regrello GraphQL (`assignees`); values propagated from `sync_assignee` |
| **Notes** | `(regrello_task_id, assignee_id)` pair is unique. |

---

### `regrello_comment`

Comment / activity on a Regrello action item.

| Aspect | Detail |
|--------|--------|
| **Relationships** | `regrello_task_id` → `regrello_task`; referenced by `regrello_document` |
| **Source** | Regrello GraphQL (`actionItem.comments`) |
| **Notes** | `(regrello_task_id, comment_id)` pair is unique. |

---

### `regrello_document`

Document attached to a Regrello action item.

| Aspect | Detail |
|--------|--------|
| **Relationships** | `regrello_task_id` → `regrello_task`; `regrello_comment_id` → `regrello_comment` (optional) |
| **Source** | Regrello GraphQL (`actionItem.documents`) |
| **Notes** | `(regrello_task_id, document_id)` pair is unique. |

---

### `task`

Sync hub linking a Jira issue to a Regrello action item.

| Aspect | Detail |
|--------|--------|
| **Relationships** | `jira_task_id` → `jira_task` (required); `regrello_task_id` → `regrello_task` (optional); `sync_state_id` → `sync_state` |
| **Source** | Launch orchestrator (sync) |
| **Notes** | Never created without `jira_task_id`. If Regrello has no action item, `regrello_task_id` is NULL and state may be `JIRA_ONLY` or `PENDING_REGRELLO`. |

---

### `sync_state`

Sync state and timestamps for each `task`.

| Aspect | Detail |
|--------|--------|
| **Relationships** | Referenced by `task` (1:1) |
| **Source** | Launch orchestrator (sync) |
| **Notes** | `both_fresh` when `jira_synced_at >= jira_updated_at` and `regrello_synced_at >= regrello_updated_at`. States defined in `task_state` enum. |

---

## SQL deployment

Executable scripts live in [`SQL/`](SQL/). GOE reference dumps in [`REF/`](REF/) are **read-only** and are not part of the orchestrator pipeline.

For local development with Docker, see [`README-DEV.md`](README-DEV.md).

For the NUDDs HTTP API, see [`../agentic-goe-api-tmp/README.md`](../agentic-goe-api-tmp/README.md).

| Order | Script | Purpose |
|-------|--------|---------|
| 1 | [`SQL/001_jira_regrello_schema.sql`](SQL/001_jira_regrello_schema.sql) | DDL: enums, 23 tables, indexes, FKs |
| 2 | [`SQL/002_jira_regrello_catalog_seed.sql`](SQL/002_jira_regrello_catalog_seed.sql) | DML: NUDDs filter catalog hierarchy |
| 3 | [`SQL/003_nudd_filter_views.sql`](SQL/003_nudd_filter_views.sql) | Views: `v_filter_org_branch`, `v_filter_function_branch` |
| 4 | [`SQL/004_jira_regrello_sample_data.sql`](SQL/004_jira_regrello_sample_data.sql) | Dev sample data (optional) |

```bash
psql -f SQL/001_jira_regrello_schema.sql
psql -f SQL/002_jira_regrello_catalog_seed.sql
psql -f SQL/003_nudd_filter_views.sql
psql -f SQL/004_jira_regrello_sample_data.sql   # optional
```

### GOE REF → orchestrator mapping

| GOE REF (`REF/`) | Orchestrator (`SQL/`) |
|------------------|------------------------|
| `platform` (uuid PK) | `jira_platform` (bigint PK) |
| `platform_information` | `jira_platform_information` |
| `platform_jira_project` | `jira_platform_project` |
| `jira_project` (uuid PK) | `jira_project` (bigint PK) |

Sample data in `004` uses names and project keys from [`REF/001_agentic_goe_reference_data.sql`](REF/001_agentic_goe_reference_data.sql) where available; platform rows are simulated (REF has no `platform` inserts).

---

## References

- DBML schema: [`db_model_jira_regrello.dbml`](db_model_jira_regrello.dbml)
- DDL: [`SQL/001_jira_regrello_schema.sql`](SQL/001_jira_regrello_schema.sql)
- Catalog seed: [`SQL/002_jira_regrello_catalog_seed.sql`](SQL/002_jira_regrello_catalog_seed.sql)
- Filter views: [`SQL/003_nudd_filter_views.sql`](SQL/003_nudd_filter_views.sql)
- Sample data: [`SQL/004_jira_regrello_sample_data.sql`](SQL/004_jira_regrello_sample_data.sql)
- GOE reference (read-only): [`REF/`](REF/)
- NUDDs API spec: [`HU/nudds-api-specification.md`](HU/nudds-api-specification.md)
- Regrello workflow (GraphQL): [`../agentic-goe-regrello-connector/docs/workflow-req-res.md`](../agentic-goe-regrello-connector/docs/workflow-req-res.md)
- Regrello action items / tasks: [`../agentic-goe-regrello-connector/docs/tasks.md`](../agentic-goe-regrello-connector/docs/tasks.md)
