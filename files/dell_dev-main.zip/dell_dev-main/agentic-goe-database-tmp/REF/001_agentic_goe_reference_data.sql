--
-- PostgreSQL database dump
--

\restrict ZfLFhQtK1gR0IT6kipANyg4zdZnhDMMlCw8zPXCrB3yoaiWPt8x9yBled9ALdWr

-- Dumped from database version 17.9 (Debian 17.9-1.pgdg12+1)
-- Dumped by pg_dump version 17.9 (Debian 17.9-1.pgdg12+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
-- Removed: SELECT pg_catalog.set_config('search_path', '', false); to allow custom search_path
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

-- Schema is handled by devops-dbcli via SCHEMA variable in pipeline

--
-- Data for Name: app_user; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: program_name_catalog; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO program_name_catalog VALUES (1, '17G Gaines XE9712 with Nvidia HPM MAX Q with GB300', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (2, '18G Chervil (R8815)', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (3, '18G Oyster M9825', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (4, '18G Perth', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (5, '18G Toronto', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (6, '18G Toronto - R9815 Allspice (1S2U)', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (7, '18G Toronto - R9825 Anise (2S3U)', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (8, 'Aleppo', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (9, 'Aquaman S1', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (10, 'Aquaman T1', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (11, 'Arwing ARL-HX OLED CS 16 (formerly MLK)', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (12, 'Battlestar CS 18', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (13, 'Binary', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (14, 'Blackhawk K540 Chrome CS 14', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (15, 'Blackhawk K540 Chrome CS 360 11', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (16, 'Blackhawk TWL CS 14', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (17, 'Blackhawk TWL CS 360 11', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (18, 'Blackhawk TWL Chrome CS 14', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (19, 'Blade GPT CS 14', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (20, 'Blade GPT CS 16', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (21, 'Blade N1 CS 16', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (22, 'Blade PTL CS 14', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (23, 'Blade PTL CS 16', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (24, 'Bolan PTL CS 14', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (25, 'Bolt', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (26, 'Brickyard GNR Tower Base', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (27, 'Brickyard GNR Tower Expansion', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (28, 'Button - 18G M9 Nvidia Compute Node - M9822', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (29, 'CItadel OLR', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (30, 'CY24 Afon', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (31, 'CY24 Olinda', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (32, 'CY25 Renegade', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (33, 'CY26 - Kingston UFS 3.1 C128K81C', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (34, 'CY26 - Kingston UFS 3.1 C128K81CXC - 128GB', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (35, 'CY26 Foxtrot 14 & Delta 3-7', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (36, 'CY26 Kingston OM8TAP4 512GB 2280 QLC Gen4', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (37, 'CY26 KingstonOM8TAP4 512GB 2280 QLC Gen4', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (38, 'CY26 XPS California - Google Aluminium', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (39, 'CY26 Zanzibar 1U', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (40, 'CY27 Hops 2U Rack', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (41, 'CY27 Huracan NVL CS 14', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (42, 'CY27 Janus NVL-S AIO', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (43, 'CY27 Performante NVL CS 16', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (44, 'CY27 Tirich Siple Makalu Aquaman Series', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (45, 'CY27 XPS Enzo', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (46, 'Citadel NVL', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (47, 'Coker R7725xd RTS1.1', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (48, 'Congo ARL CS 14', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (49, 'Congo ARL CS 16', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (50, 'Congo GPT CS 14', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (51, 'Congo GPT CS 16', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (52, 'Congo HPT CS 14', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (53, 'Congo HPT CS 16', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (54, 'Congo LNL CS 14', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (55, 'Congo LNL CS 16', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (56, 'Congo MDS CS 14', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (57, 'Congo MDS CS 16', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (58, 'Congo NVL CS 14', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (59, 'Congo NVL CS 16', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (60, 'Congo TC ARL CS 14', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (61, 'Congo TC WCL CS 14', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (62, 'Congo WCL CS 14', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (63, 'Congo WCL CS 16', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (64, 'Crystal', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (65, 'Delta 3-7', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (66, 'Dover PTL-H MFF', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (67, 'FRC:17G Gaines XE9712 with Nvidia GB300 Bianca_ Dry Ship Config', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (68, 'FY27 March PE Block', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (69, 'FY27 May PE Block', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (70, 'Firebat HPT CS 15', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (71, 'Firebat HPT CS 16', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (72, 'Firebat RPL CS 15', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (73, 'Firebat RPL-HX-R CS 16', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (74, 'Formula Rossa NVL CS 16', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (75, 'Formula Rossa NVL CS 18', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (76, 'Foxtrot R PTL CS 14', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (77, 'Gaines 3.0 - XE9712I', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (78, 'Ghostrider PTL-H CS 14', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (79, 'Ghostrider PTL-H CS 16', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (80, 'Hanoi-P ARL-S MT', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (81, 'Hays - Toyah R5715 - RTS 1.0', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (82, 'Hays - Tule R4715 - RTS 1.0', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (83, 'Hops 2U Rack', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (84, 'Huracan PTL CS 14', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (85, 'Hyperion GNR', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (86, 'Hyperion NVL', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (87, 'Hyperion OLR', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (88, 'Hyperion RPL-S', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (89, 'Innersphere 16 N1x', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (90, 'Innersphere NVL CS 14', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (91, 'Innersphere NVL CS 16', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (92, 'Innersphere PTL CS 16', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (93, 'Ithaca TWL TC', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (94, 'JANUS N PTL AIO 24', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (95, 'JANUS N PTL AIO 27', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (96, 'Janus NVL-S 24 AIO', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (97, 'Janus NVL-S 27 AIO', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (98, 'Kilo Rugged TAB 10', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (99, 'Kilo Rugged TAB 12', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (100, 'Makalu', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (101, 'Makalu Perseus', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (102, 'Makalu-W', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (103, 'Memnon', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (104, 'Mizu  CS 13', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (105, 'Montu G N1X CS 16', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (106, 'Monza NVL ST', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (107, 'Palo AIR - Duro XE9785', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (108, 'Palo DLC - Blanco SP/AP XE9780L/XE9780LAP w/ NV B300', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (109, 'Performante', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (110, 'Performante N1 CS 16', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (111, 'Performante PTL CS 16', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (112, 'Perla XR8720t RTS 1.0', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (113, 'Perla XR8720t RTS 1.1', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (114, 'Prowler NVL CS 14', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (115, 'Prowler NVL CS 16', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (116, 'Rapterra AMD CS 14', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (117, 'Rapterra AMD CS 16', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (118, 'Rapterra NVL CS 14', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (119, 'Rapterra NVL CS 16', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (120, 'Renegade PTL-H CS 14', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (121, 'Renegade PTL-H CS 16', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (122, 'Roma WCL PTL CS 13', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (123, 'Sanctuary MLK ARL-HX CS 16', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (124, 'Sanctuary MLK ARL-HX CS 18', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (125, 'Sentry MLK2 ARL-U CS 14', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (126, 'Sentry MLK2 Essential ARL-U CS 14', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (127, 'Siple', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (128, 'Siple Perseus', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (129, 'Siple-W', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (130, 'Sirius', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (131, 'Sirius-N', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (132, 'Slate ARL CS 14 1p AL', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (133, 'Slate ARL CS 16 1p AL', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (134, 'Slate GPT CS 14', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (135, 'Slate GPT CS 16', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (136, 'Slate GPT CS 1p AL 14', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (137, 'Slate GPT CS 1p AL 16', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (138, 'Slate HPT CS 14', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (139, 'Slate HPT CS 16', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (140, 'Slate HPT CS 1p AL 14', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (141, 'Slate HPT CS 1p AL 16', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (142, 'Slate LNL CS 14', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (143, 'Slate LNL CS 14 1p AL', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (144, 'Slate LNL CS 16', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (145, 'Slate LNL CS 16 1p AL', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (146, 'Slate MDS 360 CSLW 13', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (147, 'Slate MDS 360 CSLW 14', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (148, 'Slate MDS CS 14', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (149, 'Slate MDS CS 14 1pc AL', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (150, 'Slate MDS CS 16', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (151, 'Slate Max GPT CS 14', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (152, 'Slate Max GPT CS 16', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (153, 'Slate Max PTL CS 14', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (154, 'Slate Max PTL CS 16', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (155, 'Slate NVL 360 CSLW 13', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (156, 'Slate NVL 360 CSLW 14', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (157, 'Slate NVL CS 14', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (158, 'Slate NVL CS 14 1pc AL', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (159, 'Slate NVL CS 16', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (160, 'Slate PTL CS 14', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (161, 'Slate PTL CS 14 1p AL', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (162, 'Slate PTL CS 16', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (163, 'Slate PTL CS 16 1p AL', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (164, 'Slate WCL CS 14 1p AL', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (165, 'Slate WCL CS 16 1p AL', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (166, 'Sunfire Essential HWK CS 14', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (167, 'Sunfire Essential HWK CS 15', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (168, 'Sunfire Essential MDN CS 15', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (169, 'Sunfire Essential RMB-R CS 15', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (170, 'Sunfire Essential WCL CS 14', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (171, 'Sunfire Essential WCL CS 15', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (172, 'Sunfire GPT CS 16', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (173, 'Sunfire HWK CS 14', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (174, 'Sunfire HWK CS 15', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (175, 'Sunfire MDN CS 15', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (176, 'Sunfire MLK', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (177, 'Sunfire PTL CS 16', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (178, 'Sunfire RMB-R CS 15', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (179, 'Sunfire WCL CS 14', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (180, 'Sunfire WCL CS 15', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (181, 'Sunfire WCL CS 16', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (182, 'Tereus', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (183, 'Tereus-N', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (184, 'Tirich', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (185, 'Tirich Perseus', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (186, 'Tirich-W', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (187, 'Trinity Detachable 13', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (188, 'Valencia GNR DT FT', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (189, 'Valkyrie GPT CS 16', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (190, 'Valkyrie NVL CS 16', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (191, 'Volta NVL CS 14', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (192, 'Warlock MLK3 ARL-U/H CS 15', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (193, 'Warlock MLK3 Essential ARL-U/H CS 15', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (194, 'Warlock MLK3 Essential RMB-R CS 15', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (195, 'Warlock MLK3 RMB-R CS 15', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (196, 'XE9812 Earl Grey', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (197, 'Yukon GPT 360 13', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (198, 'Yukon GPT 360 14', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (199, 'Yukon GPT CSLW 13', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (200, 'Yukon GPT CSLW 14', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (201, 'Yukon LNL 360 13', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (202, 'Yukon LNL 360 14', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (203, 'Yukon LNL CSLW 13', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (204, 'Yukon LNL CSLW 14', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (205, 'Yukon MDS', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (206, 'Yukon NVL', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (207, 'Yukon PTL 360 13', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (208, 'Yukon PTL 360 14', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (209, 'Yukon PTL CSLW 13', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (210, 'Yukon PTL CSLW 14', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (211, 'Zanzibar ARL-S 1U', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;
INSERT INTO program_name_catalog VALUES (221, 'CY26 Renegade', true, '2026-06-05 09:42:23.761848+00') ON CONFLICT ON CONSTRAINT program_name_catalog_name_key DO NOTHING;


--
-- Data for Name: platform_name_catalog; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO platform_name_catalog VALUES (1, 'Annatto', '18G Perth', true, '2026-06-05 09:42:23.761848+00', NULL, NULL) ON CONFLICT ON CONSTRAINT platform_name_catalog_name_key DO NOTHING;
INSERT INTO platform_name_catalog VALUES (2, 'Arrowroot', '18G Perth', true, '2026-06-05 09:42:23.761848+00', NULL, NULL) ON CONFLICT ON CONSTRAINT platform_name_catalog_name_key DO NOTHING;
INSERT INTO platform_name_catalog VALUES (3, 'Capers', '18G Perth', true, '2026-06-05 09:42:23.761848+00', NULL, NULL) ON CONFLICT ON CONSTRAINT platform_name_catalog_name_key DO NOTHING;
INSERT INTO platform_name_catalog VALUES (4, 'Allspice', '18G Toronto', true, '2026-06-05 09:42:23.761848+00', NULL, NULL) ON CONFLICT ON CONSTRAINT platform_name_catalog_name_key DO NOTHING;
INSERT INTO platform_name_catalog VALUES (5, 'Anise', '18G Toronto', true, '2026-06-05 09:42:23.761848+00', NULL, NULL) ON CONFLICT ON CONSTRAINT platform_name_catalog_name_key DO NOTHING;
INSERT INTO platform_name_catalog VALUES (6, 'Chervil', '18G Toronto', true, '2026-06-05 09:42:23.761848+00', NULL, NULL) ON CONFLICT ON CONSTRAINT platform_name_catalog_name_key DO NOTHING;
INSERT INTO platform_name_catalog VALUES (7, 'Foxtrot 14', 'CY26 Foxtrot 14 & Delta 3-7', true, '2026-06-05 09:42:23.761848+00', NULL, NULL) ON CONFLICT ON CONSTRAINT platform_name_catalog_name_key DO NOTHING;
INSERT INTO platform_name_catalog VALUES (8, 'Delta 3-7', 'CY26 Foxtrot 14 & Delta 3-7', true, '2026-06-05 09:42:23.761848+00', NULL, NULL) ON CONFLICT ON CONSTRAINT platform_name_catalog_name_key DO NOTHING;
INSERT INTO platform_name_catalog VALUES (9, 'Performante N1', 'Performante', true, '2026-06-05 09:42:23.761848+00', NULL, NULL) ON CONFLICT ON CONSTRAINT platform_name_catalog_name_key DO NOTHING;
INSERT INTO platform_name_catalog VALUES (12, 'Zanzibar', 'CY26 Zanzibar 1U', true, '2026-06-05 09:42:23.761848+00', NULL, NULL) ON CONFLICT ON CONSTRAINT platform_name_catalog_name_key DO NOTHING;
INSERT INTO platform_name_catalog VALUES (18, 'Tirich W', 'CY27 Tirich Siple Makalu Aquaman Series', true, '2026-06-05 09:42:23.761848+00', NULL, NULL) ON CONFLICT ON CONSTRAINT platform_name_catalog_name_key DO NOTHING;
INSERT INTO platform_name_catalog VALUES (19, 'Tirich High', 'CY27 Tirich Siple Makalu Aquaman Series', true, '2026-06-05 09:42:23.761848+00', NULL, NULL) ON CONFLICT ON CONSTRAINT platform_name_catalog_name_key DO NOTHING;
INSERT INTO platform_name_catalog VALUES (20, 'Tirich Low', 'CY27 Tirich Siple Makalu Aquaman Series', true, '2026-06-05 09:42:23.761848+00', NULL, NULL) ON CONFLICT ON CONSTRAINT platform_name_catalog_name_key DO NOTHING;
INSERT INTO platform_name_catalog VALUES (21, 'Tirich D', 'CY27 Tirich Siple Makalu Aquaman Series', true, '2026-06-05 09:42:23.761848+00', NULL, NULL) ON CONFLICT ON CONSTRAINT platform_name_catalog_name_key DO NOTHING;
INSERT INTO platform_name_catalog VALUES (22, 'Siple W', 'CY27 Tirich Siple Makalu Aquaman Series', true, '2026-06-05 09:42:23.761848+00', NULL, NULL) ON CONFLICT ON CONSTRAINT platform_name_catalog_name_key DO NOTHING;
INSERT INTO platform_name_catalog VALUES (23, 'Siple High', 'CY27 Tirich Siple Makalu Aquaman Series', true, '2026-06-05 09:42:23.761848+00', NULL, NULL) ON CONFLICT ON CONSTRAINT platform_name_catalog_name_key DO NOTHING;
INSERT INTO platform_name_catalog VALUES (24, 'Siple Low', 'CY27 Tirich Siple Makalu Aquaman Series', true, '2026-06-05 09:42:23.761848+00', NULL, NULL) ON CONFLICT ON CONSTRAINT platform_name_catalog_name_key DO NOTHING;
INSERT INTO platform_name_catalog VALUES (25, 'Siple D', 'CY27 Tirich Siple Makalu Aquaman Series', true, '2026-06-05 09:42:23.761848+00', NULL, NULL) ON CONFLICT ON CONSTRAINT platform_name_catalog_name_key DO NOTHING;
INSERT INTO platform_name_catalog VALUES (26, 'Makalu W', 'CY27 Tirich Siple Makalu Aquaman Series', true, '2026-06-05 09:42:23.761848+00', NULL, NULL) ON CONFLICT ON CONSTRAINT platform_name_catalog_name_key DO NOTHING;
INSERT INTO platform_name_catalog VALUES (27, 'Makalu High', 'CY27 Tirich Siple Makalu Aquaman Series', true, '2026-06-05 09:42:23.761848+00', NULL, NULL) ON CONFLICT ON CONSTRAINT platform_name_catalog_name_key DO NOTHING;
INSERT INTO platform_name_catalog VALUES (28, 'Makalu Low', 'CY27 Tirich Siple Makalu Aquaman Series', true, '2026-06-05 09:42:23.761848+00', NULL, NULL) ON CONFLICT ON CONSTRAINT platform_name_catalog_name_key DO NOTHING;
INSERT INTO platform_name_catalog VALUES (29, 'Hops', 'CY27 Hops 2U Rack', true, '2026-06-05 09:42:23.761848+00', NULL, NULL) ON CONFLICT ON CONSTRAINT platform_name_catalog_name_key DO NOTHING;
INSERT INTO platform_name_catalog VALUES (30, 'Citadel NVL', 'Citadel NVL', true, '2026-06-05 09:42:23.761848+00', NULL, NULL) ON CONFLICT ON CONSTRAINT platform_name_catalog_name_key DO NOTHING;
INSERT INTO platform_name_catalog VALUES (31, 'Renegade 14', 'CY26 Renegade', true, '2026-06-05 09:42:23.761848+00', NULL, NULL) ON CONFLICT ON CONSTRAINT platform_name_catalog_name_key DO NOTHING;
INSERT INTO platform_name_catalog VALUES (32, 'Renegade 16', 'CY26 Renegade', true, '2026-06-05 09:42:23.761848+00', NULL, NULL) ON CONFLICT ON CONSTRAINT platform_name_catalog_name_key DO NOTHING;
INSERT INTO platform_name_catalog VALUES (33, 'Janus N PTL AIO 24', 'CY27 Janus NVL-S AIO', true, '2026-06-05 09:42:23.761848+00', NULL, NULL) ON CONFLICT ON CONSTRAINT platform_name_catalog_name_key DO NOTHING;
INSERT INTO platform_name_catalog VALUES (34, 'Janus N PTL AIO 27', 'CY27 Janus NVL-S AIO', true, '2026-06-05 09:42:23.761848+00', NULL, NULL) ON CONFLICT ON CONSTRAINT platform_name_catalog_name_key DO NOTHING;


--
-- Data for Name: program; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: platform; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: source; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: document; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: regrello_workflow_template; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO regrello_workflow_template VALUES ('426e11f2-a938-4b48-8a1a-b7d1c75ca842', 'validate', 304, true, 'validation workflow', '2026-06-05 09:42:23.761848+00', '2026-06-05 09:42:23.761848+00') ON CONFLICT (id) DO NOTHING;
INSERT INTO regrello_workflow_template VALUES ('7e8b6add-eac5-4df7-afc5-725231766aa0', 'compare', 262, true, 'change detection workflow', '2026-06-05 09:42:23.761848+00', '2026-06-05 09:42:23.761848+00') ON CONFLICT (id) DO NOTHING;


--
-- Data for Name: change_detection_run; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: chat_logs; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: document_types; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO document_types VALUES ('4271687b-d1d2-4530-8bd8-94d7569e4fcf', 'ARD', NULL, 'Architecture Requirements Document', 'ARD outlines the key architectural requirements for Dell''s desktop platform. It focuses on feature-level expectations, not detailed design implementations.', NULL, true, '2026-06-05 09:42:23.761848+00', '2026-06-05 09:42:23.761848+00') ON CONFLICT (id) DO NOTHING;
INSERT INTO document_types VALUES ('e786a453-fd7b-482e-ac2a-567a8d2559a2', 'CSTL', NULL, 'CSTL', 'Platform certification for shipping around the world', NULL, true, '2026-06-05 09:42:23.761848+00', '2026-06-05 09:42:23.761848+00') ON CONFLICT (id) DO NOTHING;
INSERT INTO document_types VALUES ('67a99c77-ff5a-43e1-b6a8-a1b4960d2414', 'Functional Plan', NULL, 'Functional Plan', '', NULL, true, '2026-06-05 09:42:23.761848+00', '2026-06-05 09:42:23.761848+00') ON CONFLICT (id) DO NOTHING;
INSERT INTO document_types VALUES ('62ea988c-4ad3-4a1e-9a19-69497212d032', 'Program Schedule', NULL, 'Program Schedule', 'Program major Milestones (Phase exits) dates and approvals', NULL, true, '2026-06-05 09:42:23.761848+00', '2026-06-05 09:42:23.761848+00') ON CONFLICT (id) DO NOTHING;
INSERT INTO document_types VALUES ('7983837b-ebca-46bc-bf7d-2452e166d7d0', 'Build Plan', NULL, 'Build Plan', 'Factory build plan for product ramp phase with details on devices produced in each shifts, number of engineers required', NULL, true, '2026-06-05 09:42:23.761848+00', '2026-06-05 09:42:23.761848+00') ON CONFLICT (id) DO NOTHING;
INSERT INTO document_types VALUES ('1655df2f-2f35-4e0b-b4a2-94c3c2313633', 'FM-Feature Matrix', NULL, 'Feature Matrix', 'The Feature Matrix is a key document used to define and manage the technical and functional requirements of Dell''s desktop platforms. It acts as a detailed checklist that ensures all product aspects—hardware, software, compliance, and usability—are clearly outlined and aligned across teams.', NULL, true, '2026-06-05 09:42:23.761848+00', '2026-06-05 09:42:23.761848+00') ON CONFLICT (id) DO NOTHING;
INSERT INTO document_types VALUES ('644527ed-1f34-4c7e-9c07-4569fbda7871', 'PRD', NULL, 'Product Requirements Document', 'PRD is Program Requirements Document which outlines the requirements of the new program to cover from offerings, key features, marketing message and claims, cost and budget and others.', NULL, true, '2026-06-05 09:42:23.761848+00', '2026-06-05 09:42:23.761848+00') ON CONFLICT (id) DO NOTHING;
INSERT INTO document_types VALUES ('39a78d22-4a28-43d2-bf0e-bff7badb2a2f', 'ID Book', NULL, 'ID Book', 'ID book contains the ID design of the new product, as well as listing the CMF plan for Color, Material and Finish', NULL, true, '2026-06-05 09:42:23.761848+00', '2026-06-05 09:42:23.761848+00') ON CONFLICT (id) DO NOTHING;
INSERT INTO document_types VALUES ('9a1d3452-7418-4d8a-8b96-760923307b7d', 'Engineering Restrictions', NULL, 'Engineering Restrictions', 'Underlying engineering restrictions and Jira Tickets raised for exceptions', NULL, true, '2026-06-05 09:42:23.761848+00', '2026-06-05 09:42:23.761848+00') ON CONFLICT (id) DO NOTHING;
INSERT INTO document_types VALUES ('053acf7a-69aa-4999-82e1-bda72e824a03', 'GCD', NULL, 'Global Configuration Document', 'PG MKT-Complexity Management is a strategic document used to compare features and commodity offerings between a product''s predecessor and successor. It helps Dell teams understand which components—like storage, memory, graphics, or I/O—are commonly used (attach rate) and whether they should continue offering them in future platforms. This analysis supports smarter decision-making, reduces unnecessary complexity, and ensures the next-generation product meets actual customer demand.', NULL, true, '2026-06-05 09:42:23.761848+00', '2026-06-05 09:42:23.761848+00') ON CONFLICT (id) DO NOTHING;
INSERT INTO document_types VALUES ('a2fb9888-79b3-44ba-82ba-a02b94e48107', 'Complexity Matrix', NULL, 'Complexity Matrix', 'Complexity matrix provided by PG MKT for the attach rates for different offer options for the new products', NULL, true, '2026-06-05 09:42:23.761848+00', '2026-06-05 09:42:23.761848+00') ON CONFLICT (id) DO NOTHING;
INSERT INTO document_types VALUES ('a2538a44-5c1d-472d-91bc-b5e4c27be7c7', 'Ecosystem Matrix', NULL, 'Ecosystem Matrix', 'Ecosystem matrix list out the hero ecosystems tie to the new product to be test and validated throughout the development and to launch at the same time', NULL, true, '2026-06-05 09:42:23.761848+00', '2026-06-05 09:42:23.761848+00') ON CONFLICT (id) DO NOTHING;
INSERT INTO document_types VALUES ('f5a9fbe9-d989-4e37-b811-e6554be19b26', 'Golden Configuration', NULL, 'Golden Configuration', 'Golden Configs are preproduction order mock-ups used to validate factory processes. Golden Configs are also used for NPI builds to represents the most important config to validate through the builds', NULL, true, '2026-06-05 09:42:23.761848+00', '2026-06-05 09:42:23.761848+00') ON CONFLICT (id) DO NOTHING;
INSERT INTO document_types VALUES ('93e41d43-7e85-4ff7-ae29-ee59e1636211', 'Storage Matrix', NULL, 'Storage Matrix', 'A storage supportability matrix is a structured table that shows: Where drives can be placed in a system (e.g., front, mid, rear bays), What types of drives are supported in each location (e.g., NVMe, SAS, SATA), What parts are needed to support those drives (e.g., backplanes, cables, carriers)', NULL, true, '2026-06-05 09:42:23.761848+00', '2026-06-05 09:42:23.761848+00') ON CONFLICT (id) DO NOTHING;
INSERT INTO document_types VALUES ('a25c02c2-9eae-4090-9b01-1d89b8017c75', 'Memory Matrix', NULL, 'Memory Matrix', 'Provides guidance on DIMM (Dual In-line Memory Module) type/DIMM placement and DIMM feature supported for the platform', NULL, true, '2026-06-05 09:42:23.761848+00', '2026-06-05 09:42:23.761848+00') ON CONFLICT (id) DO NOTHING;
INSERT INTO document_types VALUES ('cfa762c3-e3b5-486c-a4bc-0a66b6e534bc', 'Slot Priority Matrix', NULL, 'Slot Priority Matrix', 'SPM is database for slot information of PCIe/COMMs cards for the platform', NULL, true, '2026-06-05 09:42:23.761848+00', '2026-06-05 09:42:23.761848+00') ON CONFLICT (id) DO NOTHING;
INSERT INTO document_types VALUES ('e1df7d0f-ab1e-4036-845b-17a569701850', 'Unclassified', NULL, 'Unclassified', 'Documents that do not clearly match any of the defined document types', NULL, true, '2026-06-05 09:42:23.761848+00', '2026-06-05 09:42:23.761848+00') ON CONFLICT (id) DO NOTHING;
INSERT INTO document_types VALUES ('e1213b25-624e-4b49-baec-c2c044d9da04', 'CTCR', NULL, 'CTCR', NULL, NULL, true, '2026-06-05 09:42:23.761848+00', '2026-06-05 09:42:23.761848+00') ON CONFLICT (id) DO NOTHING;
INSERT INTO document_types VALUES ('96b10714-c9a9-4d0d-926d-d4e3030e4e98', 'Validator Restriction', NULL, 'Validator Restriction', NULL, NULL, true, '2026-06-05 09:42:23.761848+00', '2026-06-05 09:42:23.761848+00') ON CONFLICT (id) DO NOTHING;


--
-- Data for Name: classification_rules; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO classification_rules VALUES ('4b1d364a-26a9-49f3-90b5-694cf331047f', '4271687b-d1d2-4530-8bd8-94d7569e4fcf', 'filename', '(?<!C)\bARD\b', 1, 0.9, true, '2026-06-05 09:42:23.761848+00', '2026-06-05 09:42:23.761848+00') ON CONFLICT (id) DO NOTHING;
INSERT INTO classification_rules VALUES ('1847aa40-ecc5-49e8-8cf4-43a968799883', '4271687b-d1d2-4530-8bd8-94d7569e4fcf', 'filename', 'ARCHITECTURE[_\s]+REQUIREMENT', 2, 0.9, true, '2026-06-05 09:42:23.761848+00', '2026-06-05 09:42:23.761848+00') ON CONFLICT (id) DO NOTHING;
INSERT INTO classification_rules VALUES ('29330423-8e5f-46df-8a41-72d08bacd302', '4271687b-d1d2-4530-8bd8-94d7569e4fcf', 'filename', 'ARCHITECTURAL[_\s]+REQUIREMENTS', 3, 0.9, true, '2026-06-05 09:42:23.761848+00', '2026-06-05 09:42:23.761848+00') ON CONFLICT (id) DO NOTHING;
INSERT INTO classification_rules VALUES ('0de350fa-00e1-474a-bf16-9733d87bea5e', 'e786a453-fd7b-482e-ac2a-567a8d2559a2', 'filename', '\bCSTL\b', 1, 0.9, true, '2026-06-05 09:42:23.761848+00', '2026-06-05 09:42:23.761848+00') ON CONFLICT (id) DO NOTHING;
INSERT INTO classification_rules VALUES ('b7fdb9f1-eaf6-4294-85dc-62b991f01fac', '67a99c77-ff5a-43e1-b6a8-a1b4960d2414', 'filename', '\bFUNCTIONAL[_\s]?PLAN\b', 1, 0.9, true, '2026-06-05 09:42:23.761848+00', '2026-06-05 09:42:23.761848+00') ON CONFLICT (id) DO NOTHING;
INSERT INTO classification_rules VALUES ('d158dc2a-226a-402c-afdf-dfa77eaaf7ac', '62ea988c-4ad3-4a1e-9a19-69497212d032', 'filename', '\b(SCHEDULE|TIMELINE)\b', 1, 0.9, true, '2026-06-05 09:42:23.761848+00', '2026-06-05 09:42:23.761848+00') ON CONFLICT (id) DO NOTHING;
INSERT INTO classification_rules VALUES ('c3f8f13b-b60e-427d-a1ab-357dac598dff', '7983837b-ebca-46bc-bf7d-2452e166d7d0', 'filename', '\bBUILD[_\s]?PLAN\b', 1, 0.9, true, '2026-06-05 09:42:23.761848+00', '2026-06-05 09:42:23.761848+00') ON CONFLICT (id) DO NOTHING;
INSERT INTO classification_rules VALUES ('0ca8fc69-c305-4718-9a8c-1fc9d6623147', '1655df2f-2f35-4e0b-b4a2-94c3c2313633', 'filename', '\bFEATURE[_\s]?MATRIX\b', 1, 0.9, true, '2026-06-05 09:42:23.761848+00', '2026-06-05 09:42:23.761848+00') ON CONFLICT (id) DO NOTHING;
INSERT INTO classification_rules VALUES ('1309e445-562c-4117-ae30-c50327002320', '1655df2f-2f35-4e0b-b4a2-94c3c2313633', 'filename', '\bFM[_\s]?MATRIX\b', 2, 0.9, true, '2026-06-05 09:42:23.761848+00', '2026-06-05 09:42:23.761848+00') ON CONFLICT (id) DO NOTHING;
INSERT INTO classification_rules VALUES ('e87d7a5b-4191-4f3f-9705-ce46d94cc67a', '1655df2f-2f35-4e0b-b4a2-94c3c2313633', 'filename', '\bFM\b', 3, 0.85, true, '2026-06-05 09:42:23.761848+00', '2026-06-05 09:42:23.761848+00') ON CONFLICT (id) DO NOTHING;
INSERT INTO classification_rules VALUES ('48a0456a-9475-40be-93b5-6751f802bd4e', '644527ed-1f34-4c7e-9c07-4569fbda7871', 'filename', '\bPRD\b', 1, 0.9, true, '2026-06-05 09:42:23.761848+00', '2026-06-05 09:42:23.761848+00') ON CONFLICT (id) DO NOTHING;
INSERT INTO classification_rules VALUES ('f16a8308-49b9-4d53-9750-9f22100874a8', '644527ed-1f34-4c7e-9c07-4569fbda7871', 'filename', 'PRODUCT[_\s]+REQUIREMENT', 2, 0.9, true, '2026-06-05 09:42:23.761848+00', '2026-06-05 09:42:23.761848+00') ON CONFLICT (id) DO NOTHING;
INSERT INTO classification_rules VALUES ('2f7eefec-894e-4e29-924e-a33fecdcbec9', '39a78d22-4a28-43d2-bf0e-bff7badb2a2f', 'filename', '\bID[_\s-]?BOOK\b', 1, 0.9, true, '2026-06-05 09:42:23.761848+00', '2026-06-05 09:42:23.761848+00') ON CONFLICT (id) DO NOTHING;
INSERT INTO classification_rules VALUES ('81b03a94-7bfc-49ec-9dc0-7eab88ffe120', '9a1d3452-7418-4d8a-8b96-760923307b7d', 'filename', 'ENGINEERING[_\s]+RESTRICTION', 1, 0.9, true, '2026-06-05 09:42:23.761848+00', '2026-06-05 09:42:23.761848+00') ON CONFLICT (id) DO NOTHING;
INSERT INTO classification_rules VALUES ('83048b84-bb5e-40ca-b3ab-57800d75ec22', '053acf7a-69aa-4999-82e1-bda72e824a03', 'filename', '\bGCD\b', 1, 0.9, true, '2026-06-05 09:42:23.761848+00', '2026-06-05 09:42:23.761848+00') ON CONFLICT (id) DO NOTHING;
INSERT INTO classification_rules VALUES ('a5181b04-e0da-48bc-9621-b27b4eaf179e', 'a2fb9888-79b3-44ba-82ba-a02b94e48107', 'filename', '\bCOMPLEXITY\b', 1, 0.85, true, '2026-06-05 09:42:23.761848+00', '2026-06-05 09:42:23.761848+00') ON CONFLICT (id) DO NOTHING;
INSERT INTO classification_rules VALUES ('beba8a21-d34b-4252-a91f-bec70553fbaa', 'a2538a44-5c1d-472d-91bc-b5e4c27be7c7', 'filename', '\bECOSYSTEM\b', 1, 0.85, true, '2026-06-05 09:42:23.761848+00', '2026-06-05 09:42:23.761848+00') ON CONFLICT (id) DO NOTHING;
INSERT INTO classification_rules VALUES ('b6a4408d-494d-4328-9e22-31d6be9943a1', '4271687b-d1d2-4530-8bd8-94d7569e4fcf', 'folder', 'ARD', 1, 0.7, true, '2026-06-05 09:42:23.761848+00', '2026-06-05 09:42:23.761848+00') ON CONFLICT (id) DO NOTHING;
INSERT INTO classification_rules VALUES ('bd379028-687a-4e90-8ce4-ff231af93c03', 'e786a453-fd7b-482e-ac2a-567a8d2559a2', 'folder', 'CSTL', 1, 0.7, true, '2026-06-05 09:42:23.761848+00', '2026-06-05 09:42:23.761848+00') ON CONFLICT (id) DO NOTHING;
INSERT INTO classification_rules VALUES ('0e507663-0e0b-4221-b469-25356a6f48d8', '67a99c77-ff5a-43e1-b6a8-a1b4960d2414', 'folder', 'FUNCTIONAL[_\s]?PLAN', 1, 0.7, true, '2026-06-05 09:42:23.761848+00', '2026-06-05 09:42:23.761848+00') ON CONFLICT (id) DO NOTHING;
INSERT INTO classification_rules VALUES ('cfbddf1a-2006-4258-a8f5-835d28074c5b', '62ea988c-4ad3-4a1e-9a19-69497212d032', 'folder', '(SCHEDULE|TIMELINE)', 1, 0.7, true, '2026-06-05 09:42:23.761848+00', '2026-06-05 09:42:23.761848+00') ON CONFLICT (id) DO NOTHING;
INSERT INTO classification_rules VALUES ('38c2df3f-e986-44aa-af26-8650a31f20be', '7983837b-ebca-46bc-bf7d-2452e166d7d0', 'folder', 'BUILD[_\s]?PLAN', 1, 0.7, true, '2026-06-05 09:42:23.761848+00', '2026-06-05 09:42:23.761848+00') ON CONFLICT (id) DO NOTHING;
INSERT INTO classification_rules VALUES ('6a5fd5b2-e291-435c-8b57-4a1b3e404e65', '1655df2f-2f35-4e0b-b4a2-94c3c2313633', 'folder', 'FEATURE[_\s]?MATRIX', 1, 0.7, true, '2026-06-05 09:42:23.761848+00', '2026-06-05 09:42:23.761848+00') ON CONFLICT (id) DO NOTHING;
INSERT INTO classification_rules VALUES ('6a41d6c0-f300-4c7b-aea4-1803d7473863', '1655df2f-2f35-4e0b-b4a2-94c3c2313633', 'folder', 'FM[_\s]?MATRIX', 2, 0.7, true, '2026-06-05 09:42:23.761848+00', '2026-06-05 09:42:23.761848+00') ON CONFLICT (id) DO NOTHING;
INSERT INTO classification_rules VALUES ('02a25c31-b3a7-4737-8a3f-68cfbf8f9a66', '1655df2f-2f35-4e0b-b4a2-94c3c2313633', 'folder', 'FM', 3, 0.65, true, '2026-06-05 09:42:23.761848+00', '2026-06-05 09:42:23.761848+00') ON CONFLICT (id) DO NOTHING;
INSERT INTO classification_rules VALUES ('84ff3574-c71d-4e8d-ac99-09c1dfeb3193', '644527ed-1f34-4c7e-9c07-4569fbda7871', 'folder', 'PRD', 1, 0.7, true, '2026-06-05 09:42:23.761848+00', '2026-06-05 09:42:23.761848+00') ON CONFLICT (id) DO NOTHING;
INSERT INTO classification_rules VALUES ('749118cc-b36b-450a-a072-7cec34d06c5b', '39a78d22-4a28-43d2-bf0e-bff7badb2a2f', 'folder', 'ID[_\s-]?BOOK', 1, 0.7, true, '2026-06-05 09:42:23.761848+00', '2026-06-05 09:42:23.761848+00') ON CONFLICT (id) DO NOTHING;
INSERT INTO classification_rules VALUES ('a716d5a6-9a26-4e78-bf8f-c614da677132', '9a1d3452-7418-4d8a-8b96-760923307b7d', 'folder', 'ENGINEERING[_\s]+RESTRICTION', 1, 0.7, true, '2026-06-05 09:42:23.761848+00', '2026-06-05 09:42:23.761848+00') ON CONFLICT (id) DO NOTHING;
INSERT INTO classification_rules VALUES ('303dcc93-fb8b-45c4-b226-12d87fb4c884', '053acf7a-69aa-4999-82e1-bda72e824a03', 'folder', 'GCD', 1, 0.7, true, '2026-06-05 09:42:23.761848+00', '2026-06-05 09:42:23.761848+00') ON CONFLICT (id) DO NOTHING;
INSERT INTO classification_rules VALUES ('6f6a7dda-82d8-45f9-9b42-598b6d83a330', 'a2fb9888-79b3-44ba-82ba-a02b94e48107', 'folder', 'COMPLEXITY', 1, 0.65, true, '2026-06-05 09:42:23.761848+00', '2026-06-05 09:42:23.761848+00') ON CONFLICT (id) DO NOTHING;
INSERT INTO classification_rules VALUES ('586d6fb5-03be-478d-8715-beed78252b27', 'a2538a44-5c1d-472d-91bc-b5e4c27be7c7', 'folder', 'ECOSYSTEM', 1, 0.65, true, '2026-06-05 09:42:23.761848+00', '2026-06-05 09:42:23.761848+00') ON CONFLICT (id) DO NOTHING;
INSERT INTO classification_rules VALUES ('b97b7b80-8892-490d-94b8-5ca18f73cfb2', 'f5a9fbe9-d989-4e37-b811-e6554be19b26', 'filename', '\bGOLDEN[_\s]?CONFIG', 1, 0.9, true, '2026-06-05 09:42:23.761848+00', '2026-06-05 09:42:23.761848+00') ON CONFLICT (id) DO NOTHING;
INSERT INTO classification_rules VALUES ('1a5ee9fe-8b88-4cf2-bc6f-3a1d6ac0cd72', 'f5a9fbe9-d989-4e37-b811-e6554be19b26', 'filename', '\bGOLDEN[_\s]?CONFIGURATION', 2, 0.9, true, '2026-06-05 09:42:23.761848+00', '2026-06-05 09:42:23.761848+00') ON CONFLICT (id) DO NOTHING;
INSERT INTO classification_rules VALUES ('29a72477-a0ee-4c17-8243-a2b457264e60', '93e41d43-7e85-4ff7-ae29-ee59e1636211', 'filename', '\bSTORAGE[_\s]?MATRIX\b', 1, 0.9, true, '2026-06-05 09:42:23.761848+00', '2026-06-05 09:42:23.761848+00') ON CONFLICT (id) DO NOTHING;
INSERT INTO classification_rules VALUES ('e7a42124-511f-46da-8a10-2f73aed5e39e', '93e41d43-7e85-4ff7-ae29-ee59e1636211', 'filename', '\bSTORAGE[_\s]+SUPPORTABILITY\b', 2, 0.9, true, '2026-06-05 09:42:23.761848+00', '2026-06-05 09:42:23.761848+00') ON CONFLICT (id) DO NOTHING;
INSERT INTO classification_rules VALUES ('1c616369-7acd-4b50-b45d-34c33857c985', 'a25c02c2-9eae-4090-9b01-1d89b8017c75', 'filename', '\bMEMORY[_\s]?MATRIX\b', 1, 0.9, true, '2026-06-05 09:42:23.761848+00', '2026-06-05 09:42:23.761848+00') ON CONFLICT (id) DO NOTHING;
INSERT INTO classification_rules VALUES ('b1537972-9481-41d2-ace4-fc7e4a022f11', 'a25c02c2-9eae-4090-9b01-1d89b8017c75', 'filename', '\bDIMM[_\s]?MATRIX\b', 2, 0.9, true, '2026-06-05 09:42:23.761848+00', '2026-06-05 09:42:23.761848+00') ON CONFLICT (id) DO NOTHING;
INSERT INTO classification_rules VALUES ('7b0d19d0-b8bd-441c-9e1e-1a072532e708', 'cfa762c3-e3b5-486c-a4bc-0a66b6e534bc', 'filename', '\bSLOT[_\s]?PRIORITY[_\s]?MATRIX\b', 1, 0.9, true, '2026-06-05 09:42:23.761848+00', '2026-06-05 09:42:23.761848+00') ON CONFLICT (id) DO NOTHING;
INSERT INTO classification_rules VALUES ('313049d7-f275-4fe6-a73a-972c7f650488', 'cfa762c3-e3b5-486c-a4bc-0a66b6e534bc', 'filename', '\bSPM\b', 2, 0.85, true, '2026-06-05 09:42:23.761848+00', '2026-06-05 09:42:23.761848+00') ON CONFLICT (id) DO NOTHING;
INSERT INTO classification_rules VALUES ('c97d8575-d8d2-41fa-b5a4-e03e2e8e2616', 'f5a9fbe9-d989-4e37-b811-e6554be19b26', 'folder', 'GOLDEN[_\s]?CONFIG', 1, 0.7, true, '2026-06-05 09:42:23.761848+00', '2026-06-05 09:42:23.761848+00') ON CONFLICT (id) DO NOTHING;
INSERT INTO classification_rules VALUES ('2ea4810e-2dc3-4188-84d4-2a868bd6b0df', '93e41d43-7e85-4ff7-ae29-ee59e1636211', 'folder', 'STORAGE[_\s]?MATRIX', 1, 0.7, true, '2026-06-05 09:42:23.761848+00', '2026-06-05 09:42:23.761848+00') ON CONFLICT (id) DO NOTHING;
INSERT INTO classification_rules VALUES ('547747c8-957a-48e9-8ce0-e7075da10329', 'a25c02c2-9eae-4090-9b01-1d89b8017c75', 'folder', 'MEMORY[_\s]?MATRIX', 1, 0.7, true, '2026-06-05 09:42:23.761848+00', '2026-06-05 09:42:23.761848+00') ON CONFLICT (id) DO NOTHING;
INSERT INTO classification_rules VALUES ('80052d80-8317-42ad-a0c0-72450e0ff12f', 'cfa762c3-e3b5-486c-a4bc-0a66b6e534bc', 'folder', 'SLOT[_\s]?PRIORITY', 1, 0.7, true, '2026-06-05 09:42:23.761848+00', '2026-06-05 09:42:23.761848+00') ON CONFLICT (id) DO NOTHING;


--
-- Data for Name: source_confluence; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: confluence_sync_state; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: document_block_groups; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: document_blocks; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: document_chunks; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: document_classification; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: document_confluence; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: document_extraction; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: document_jira; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: document_metadata; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: document_metrics; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: processing_runs; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: document_parse_result; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: document_sharepoint; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: document_validation; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: ingestion_runs; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: jira_comment; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: jira_issue_history; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: jira_project; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO jira_project VALUES ('8b3def4e-e061-4427-a325-eac82885deda', 'CPDM', 'Core Product Definition Management', 'https://jira.cpg.dell.com', '["NUDD"]', 'Program Platform(s)', 'option', true, '2026-06-05 09:42:23.761848+00', '2026-06-05 09:42:23.761848+00', 'CPG', '[]') ON CONFLICT (project_key) DO NOTHING;
INSERT INTO jira_project VALUES ('6ca34716-ed8c-480e-9b61-4be1a84eb9a9', 'GRIT', 'GRIT Platform Tracking', 'https://jira.cpg.dell.com', '["NUDD"]', 'Affected Platform(s)_Text', 'text', true, '2026-06-05 09:42:23.761848+00', '2026-06-05 09:42:23.761848+00', 'CPG', '[]') ON CONFLICT (project_key) DO NOTHING;
INSERT INTO jira_project VALUES ('9b2fee69-ee5c-47ad-8a83-a3daf3e9ff01', 'JQIM', 'Jira Quality & Issue Management', 'https://jira.cpg.dell.com', '["CSG GOE", "CSG GOE DFX"]', 'Affected Platform(s)_Text', 'text', true, '2026-06-05 09:42:23.761848+00', '2026-06-05 09:42:23.761848+00', 'CPG', '[]') ON CONFLICT (project_key) DO NOTHING;
INSERT INTO jira_project VALUES ('ac9b7756-f189-4119-8999-426a2fe7a4aa', 'DFX', 'Design for Excellence', 'https://jira.gtie.dell.com', '["DFx Intake Request"]', 'Platform Found', 'option', true, '2026-06-05 09:42:23.761848+00', '2026-06-05 09:42:23.761848+00', 'GTIE', '[]') ON CONFLICT (project_key) DO NOTHING;
INSERT INTO jira_project VALUES ('5379b70d-81a4-41c7-a68d-88a0fc9138eb', 'GOEQ', 'GOE Quality', 'https://jira.gtie.dell.com', '["NUDD"]', 'Impacted Platform/s', 'option', true, '2026-06-05 09:42:23.761848+00', '2026-06-05 09:42:23.761848+00', 'GTIE', '[]') ON CONFLICT (project_key) DO NOTHING;
INSERT INTO jira_project VALUES ('e462e223-d20f-49c1-b285-bc5f07ac4168', 'JIT', 'Jira Issue Tracker', 'https://jira.gtie.dell.com', '["Defect"]', 'Platform Found', 'option', true, '2026-06-05 09:42:23.761848+00', '2026-06-05 09:42:23.761848+00', 'GTIE', '[{"fieldName": "Originating Group", "fieldType": "option"}]') ON CONFLICT (project_key) DO NOTHING;


--
-- Data for Name: source_jira; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: jira_sync_state; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: llm_calls; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: notification_preferences; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: pipeline_runs; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: platform_information; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: platform_ingestion_sync_state; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: platform_jira_project; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: platform_raw_data; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: plm_platform; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: plm_platform_bom; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: product_line; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: program_member; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: program_unified_metadata; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: service_account; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: service_account_platform_access; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: source_sharepoint; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: sharepoint_sync_state; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: source_iomete; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: user_platform_access; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: user_session; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Name: platform_name_catalog_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('platform_name_catalog_id_seq', 34, true);


--
-- Name: program_name_catalog_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('program_name_catalog_id_seq', 221, true);


--
-- PostgreSQL database dump complete
--

\unrestrict ZfLFhQtK1gR0IT6kipANyg4zdZnhDMMlCw8zPXCrB3yoaiWPt8x9yBled9ALdWr

