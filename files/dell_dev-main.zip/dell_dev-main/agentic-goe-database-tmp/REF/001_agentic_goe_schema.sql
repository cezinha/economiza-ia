--
-- PostgreSQL database dump
--

\restrict fBpAoqimuH4ExTSyqhSIaKypaheBM6D06v1RdcxuycLGDhRqDjzjT0BYXHBE78Z

-- Dumped from database version 17.9 (Debian 17.9-1.pgdg12+1)
-- Dumped by pg_dump version 17.9 (Debian 17.9-1.pgdg12+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
-- Removed: SELECT pg_catalog.set_config('search_path', '', false); to allow custom search_path
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

-- Schema is handled by devops-dbcli via SCHEMA variable in pipeline

--
-- Extensions: uuid-ossp and vector are pre-installed or not needed
-- uuid-ossp: pre-installed in database
-- vector: AIDaaS is used for vector storage instead
--


--
-- Name: platform_lob_type; Type: TYPE; Schema: public; Owner: -
--

DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'platform_lob_type' AND typnamespace = current_schema()::regnamespace) THEN
        CREATE TYPE platform_lob_type AS ENUM (
            'NB',
            'DT',
            'Server'
        );
    END IF;
END $$;


--
-- Name: platform_phase_type; Type: TYPE; Schema: public; Owner: -
--

DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'platform_phase_type' AND typnamespace = current_schema()::regnamespace) THEN
        CREATE TYPE platform_phase_type AS ENUM (
            'Plan',
            'Concept',
            'Define',
            'Develop',
            'Launch',
            'Sustain',
            'EOL',
            'Incubate'
        );
    END IF;
END $$;


--
-- Name: platform_state_type; Type: TYPE; Schema: public; Owner: -
--

DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'platform_state_type' AND typnamespace = current_schema()::regnamespace) THEN
        CREATE TYPE platform_state_type AS ENUM (
            'Active',
            'Inactive',
            'On Hold',
            'Cancelled'
        );
    END IF;
END $$;


--
-- Name: update_pipeline_runs_updated_at(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE OR REPLACE FUNCTION update_pipeline_runs_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
        BEGIN
            NEW.updated_at = now();
            RETURN NEW;
        END;
        $$;


--
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE OR REPLACE FUNCTION update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
        BEGIN
            NEW.updated_at = NOW();
            RETURN NEW;
        END;
        $$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: app_user; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE IF NOT EXISTS app_user (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    email text NOT NULL,
    role text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    name text DEFAULT ''::text NOT NULL,
    user_function text,
    last_login_at timestamp with time zone,
    dashboard_access boolean DEFAULT true NOT NULL
);


--
-- Name: change_detection_run; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE IF NOT EXISTS change_detection_run (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    platform_id uuid NOT NULL,
    base_document_id uuid NOT NULL,
    target_document_id uuid NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    summary jsonb,
    run_metadata jsonb,
    triggered_by text,
    error_message text,
    started_at timestamp with time zone,
    completed_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    regrello_workflow_template_id uuid,
    workflow_id text,
    l1_summary_json jsonb,
    l2_summary jsonb,
    executive_summary_json jsonb,
    consolidated_change_results_json jsonb
);


--
-- Name: chat_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE IF NOT EXISTS chat_logs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    session_id uuid NOT NULL,
    trace_id uuid NOT NULL,
    user_id text,
    platform_id uuid,
    original_query text NOT NULL,
    conversation_history jsonb,
    raw_entities jsonb,
    resolved_entities jsonb,
    intent_query_type text,
    intent_archetype text,
    intent_confidence double precision,
    intent_reasoning text,
    executor_type text,
    execution_success boolean,
    execution_data jsonb,
    response_text text,
    citations jsonb,
    sources jsonb,
    needs_clarification boolean DEFAULT false NOT NULL,
    clarification_type text,
    clarification_question text,
    input_guardrail_passed boolean,
    output_guardrail_passed boolean,
    evaluation_satisfactory boolean,
    evaluation_scores jsonb,
    node_timings jsonb,
    total_duration_ms double precision,
    error text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    vector_search_results jsonb,
    pipeline_steps jsonb,
    sql_queries jsonb,
    vector_search_calls jsonb,
    username text,
    user_email text
);


--
-- Name: classification_rules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE IF NOT EXISTS classification_rules (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    doc_type_id uuid NOT NULL,
    rule_type text NOT NULL,
    pattern text NOT NULL,
    priority integer DEFAULT 1 NOT NULL,
    confidence double precision DEFAULT 0.90 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ck_classification_rules_rule_type CHECK ((rule_type = ANY (ARRAY['filename'::text, 'folder'::text])))
);


--
-- Name: confluence_sync_state; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE IF NOT EXISTS confluence_sync_state (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    source_id uuid NOT NULL,
    last_sync_timestamp timestamp with time zone,
    status text,
    last_polled_at timestamp with time zone,
    last_success_at timestamp with time zone,
    last_error text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: document; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE IF NOT EXISTS document (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    platform_id uuid NOT NULL,
    source_id uuid NOT NULL,
    external_id text,
    uri text,
    file_name text,
    file_path text,
    mime_type text,
    content_hash text,
    size_bytes bigint,
    ingestion_status text,
    ingestion_error text,
    source_modified_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_by text,
    deleted_at timestamp with time zone,
    original_uri text,
    original_filename text
);


--
-- Name: document_block_groups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE IF NOT EXISTS document_block_groups (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    document_id uuid NOT NULL,
    group_index integer NOT NULL,
    group_type text NOT NULL,
    name text,
    summary text,
    column_headers jsonb,
    children jsonb,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: document_blocks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE IF NOT EXISTS document_blocks (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    document_id uuid NOT NULL,
    block_index integer,
    content text,
    metadata jsonb,
    embedding vector,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    block_type text
);


--
-- Name: document_chunks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE IF NOT EXISTS document_chunks (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    document_id uuid NOT NULL,
    chunk_index integer NOT NULL,
    content text NOT NULL,
    token_count integer,
    block_refs jsonb,
    metadata jsonb,
    embedding text,
    chunk_strategy text,
    overlap_tokens integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: document_classification; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE IF NOT EXISTS document_classification (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    document_id uuid NOT NULL,
    status text,
    doc_type text,
    confidence double precision,
    rationale text,
    versioning_scheme text,
    series_key text,
    model_name text,
    prompt_version text,
    raw_output jsonb,
    classified_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    program_version text,
    signal text,
    subtype text,
    is_manual_override boolean DEFAULT false NOT NULL,
    override_reason text,
    overridden_by text,
    overridden_at timestamp with time zone
);


--
-- Name: document_confluence; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE IF NOT EXISTS document_confluence (
    document_id uuid NOT NULL,
    page_id text,
    page_title text,
    space_key text,
    version_number integer,
    last_modified_at timestamp with time zone,
    parent_page_id text,
    web_url text,
    is_deleted boolean,
    deleted_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    is_attachment text DEFAULT 'N'::text NOT NULL
);


--
-- Name: document_extraction; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE IF NOT EXISTS document_extraction (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    document_id uuid NOT NULL,
    doc_type text NOT NULL,
    schema_id uuid,
    extracted_entities jsonb NOT NULL,
    raw_llm_response jsonb,
    confidence double precision,
    status text DEFAULT 'pending'::text NOT NULL,
    extracted_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: document_jira; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE IF NOT EXISTS document_jira (
    document_id uuid NOT NULL,
    issue_id text,
    issue_key text,
    project_key text,
    project_id text,
    issue_type text,
    status text,
    priority text,
    resolution text,
    assignee_account_id text,
    assignee_display_name text,
    reporter_account_id text,
    reporter_display_name text,
    jira_created_at timestamp with time zone,
    jira_updated_at timestamp with time zone,
    jira_resolved_at timestamp with time zone,
    summary text,
    description text,
    attachment_id text,
    parent_issue_key text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: document_metadata; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE IF NOT EXISTS document_metadata (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    document_id uuid NOT NULL,
    namespace text,
    key text,
    value_text text,
    value_num numeric,
    value_bool boolean,
    value_date date,
    value_json jsonb,
    confidence double precision,
    provenance_run_id uuid,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: document_metrics; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE IF NOT EXISTS document_metrics (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    document_id uuid NOT NULL,
    missing_fields jsonb,
    validation_errors jsonb,
    extracted_tables_count integer,
    extracted_images_count integer,
    extracted_text_length integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: document_parse_result; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE IF NOT EXISTS document_parse_result (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    document_id uuid NOT NULL,
    processing_run_id uuid,
    blocks_container jsonb NOT NULL,
    blocks_uri text,
    parser_type text NOT NULL,
    parser_version text,
    phase1_completed_at timestamp with time zone,
    phase2_completed_at timestamp with time zone,
    stats jsonb,
    status text DEFAULT 'completed'::text NOT NULL,
    error_message text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: document_sharepoint; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE IF NOT EXISTS document_sharepoint (
    document_id uuid NOT NULL,
    site_id text,
    drive_id text,
    item_id text,
    parent_item_id text,
    path text,
    web_url text,
    etag text,
    ctag text,
    last_modified_at timestamp with time zone,
    last_modified_by text,
    is_deleted boolean,
    deleted_at timestamp with time zone,
    sensitivity_label_display_name text,
    sensitivity_classification text,
    visual_marking text,
    compliance_flags text,
    compliance_tag text,
    compliance_tag_written_time timestamp with time zone,
    compliance_tag_user_id text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    platform_id uuid NOT NULL
);


--
-- Name: document_types; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE IF NOT EXISTS document_types (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    line_of_business text,
    display_name text,
    description text,
    extraction_schema jsonb,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: document_validation; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE IF NOT EXISTS document_validation (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    document_id uuid NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    result jsonb,
    triggered_by text,
    external_reference_id text,
    error_message text,
    started_at timestamp with time zone,
    completed_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    regrello_workflow_template_id uuid
);


--
-- Name: ingestion_runs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE IF NOT EXISTS ingestion_runs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    document_id uuid NOT NULL,
    status text,
    triggered_by text,
    started_at timestamp with time zone,
    completed_at timestamp with time zone,
    error_message text
);


--
-- Name: jira_comment; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE IF NOT EXISTS jira_comment (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    document_id uuid NOT NULL,
    issue_key text NOT NULL,
    comment_id text NOT NULL,
    author_account_id text,
    author_display_name text,
    body text,
    jira_created_at timestamp with time zone,
    jira_updated_at timestamp with time zone,
    visibility_type text,
    visibility_value text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: jira_issue_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE IF NOT EXISTS jira_issue_history (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    document_id uuid NOT NULL,
    issue_key text NOT NULL,
    history_id text NOT NULL,
    change_group_id text NOT NULL,
    field_name text NOT NULL,
    field_type text,
    from_value text,
    to_value text,
    changed_by_account_id text,
    changed_by_display_name text,
    changed_at timestamp with time zone NOT NULL,
    version_number integer,
    change_sequence integer,
    change_type text,
    change_hash text,
    source_system text,
    raw_changelog_json jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: TABLE jira_issue_history; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE jira_issue_history IS 'Tracks individual field change events from Jira issue changelogs. Each row = one field change. Rows sharing the same change_group_id belong to one Jira changelog entry (one user action at one timestamp).';


--
-- Name: jira_project; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE IF NOT EXISTS jira_project (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    project_key text NOT NULL,
    project_name text,
    instance_url text,
    available_issue_types jsonb DEFAULT '[]'::jsonb NOT NULL,
    platform_filter_field text,
    platform_filter_type text,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    instance_name text,
    additional_filter_fields jsonb DEFAULT '[]'::jsonb NOT NULL
);


--
-- Name: jira_sync_state; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE IF NOT EXISTS jira_sync_state (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    source_id uuid NOT NULL,
    last_issue_updated_at timestamp with time zone,
    last_attachment_updated_at timestamp with time zone,
    last_comment_updated_at timestamp with time zone,
    next_start_at integer,
    status text,
    last_polled_at timestamp with time zone,
    last_success_at timestamp with time zone,
    last_error text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: llm_calls; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE IF NOT EXISTS llm_calls (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    chat_log_id uuid NOT NULL,
    step_name text NOT NULL,
    model text,
    prompt_messages jsonb,
    completion text,
    tokens_input integer,
    tokens_output integer,
    latency_ms double precision,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: notification_preferences; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE IF NOT EXISTS notification_preferences (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    platform_id uuid NOT NULL,
    user_email text NOT NULL,
    doc_type text NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: pipeline_runs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE IF NOT EXISTS pipeline_runs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    platform_id character varying(255) NOT NULL,
    doc_id character varying(255) NOT NULL,
    correlation_id uuid NOT NULL,
    doc_version character varying(255) NOT NULL,
    current_step character varying(50) NOT NULL,
    last_status character varying(50) NOT NULL,
    run_status character varying(50) DEFAULT 'running'::character varying NOT NULL,
    last_event_id uuid NOT NULL,
    processed_event_ids jsonb DEFAULT '[]'::jsonb NOT NULL,
    attempt_by_step jsonb DEFAULT '{}'::jsonb NOT NULL,
    source_id character varying(255),
    error_message text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    completed_at timestamp with time zone
);


--
-- Name: platform; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE IF NOT EXISTS platform (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text,
    description text,
    department text,
    line_of_business text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    status text DEFAULT 'Pending Configuration'::text NOT NULL,
    program_id uuid NOT NULL,
    platform_name text
);


--
-- Name: platform_information; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE IF NOT EXISTS platform_information (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    jira_issue_key text NOT NULL,
    jira_issue_id text,
    jira_status text,
    resolution text,
    jira_created_at timestamp with time zone,
    jira_updated_at timestamp with time zone,
    platform_name text,
    marketing_model_name text,
    domain_business text,
    program_name text,
    program_phase platform_phase_type,
    program_state platform_state_type,
    program_status_notes text,
    program_category text,
    tier text,
    cpu_architecture text,
    deliverable text,
    odm_supplier text,
    platform_model_id_dpn text,
    predecessor text,
    rts_calendar_year text,
    rts_calendar_quarter text,
    rts_calendar_month text,
    rts_actual date,
    rts_target date,
    rto_calendar_year text,
    rto_calendar_quarter text,
    rto_calendar_month text,
    rto_por date,
    rfd_por date,
    develop_exit_por date,
    launch_exit_por date,
    concept_entry_target date,
    concept_entry_actual date,
    concept_exit_target date,
    concept_exit_actual date,
    define_exit_target date,
    define_exit_actual date,
    ba_target date,
    ba_actual date,
    dds_target date,
    dds_actual date,
    plan_exit_target date,
    plan_exit_actual date,
    rfd_target date,
    rfd_actual date,
    develop_exit_target date,
    develop_exit_actual date,
    rto_target date,
    rto_actual date,
    launch_exit_target date,
    follow_up_date date,
    eol_target date,
    eosecl_target date,
    eosl_target date,
    program_manager text,
    product_manager text,
    project_manager text,
    engineers text,
    quality_engineer text,
    procurement text,
    services text,
    goe_person text,
    goe_person_email text,
    edg text,
    finance text,
    executive_status text,
    reporter text,
    assignee text,
    form_factor text,
    lob_code platform_lob_type,
    instance_name text,
    predecessor_id uuid,
    goe_id uuid,
    synced_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: platform_ingestion_sync_state; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE IF NOT EXISTS platform_ingestion_sync_state (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    source_name text NOT NULL,
    last_issue_updated_at timestamp with time zone,
    status text,
    last_polled_at timestamp with time zone,
    last_success_at timestamp with time zone,
    last_error text,
    last_run_started_at timestamp with time zone,
    last_run_total_count integer,
    last_run_synced_count integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: platform_jira_project; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE IF NOT EXISTS platform_jira_project (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    platform_id uuid NOT NULL,
    jira_project_id uuid NOT NULL,
    source_id uuid,
    enabled_issue_types jsonb DEFAULT '[]'::jsonb NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    platform_values jsonb DEFAULT '[]'::jsonb NOT NULL,
    additional_field_values jsonb DEFAULT '{}'::jsonb NOT NULL
);


--
-- Name: platform_name_catalog; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE IF NOT EXISTS platform_name_catalog (
    id integer NOT NULL,
    name text NOT NULL,
    program_name text NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    aliases jsonb,
    predecessors jsonb
);


--
-- Name: platform_name_catalog_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE IF NOT EXISTS platform_name_catalog_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: platform_name_catalog_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE platform_name_catalog_id_seq OWNED BY platform_name_catalog.id;


--
-- Name: platform_raw_data; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE IF NOT EXISTS platform_raw_data (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    jira_issue_key text NOT NULL,
    s3_bucket text NOT NULL,
    s3_key text NOT NULL,
    s3_uri text NOT NULL,
    file_size_bytes bigint,
    uploaded_at timestamp with time zone DEFAULT now() NOT NULL,
    synced_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: plm_platform; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE IF NOT EXISTS plm_platform (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    platform_id uuid NOT NULL,
    category_name text,
    category_code text,
    productline_name text,
    productline_code text,
    productline_enddate date,
    platform_name text,
    platform_code text,
    item_number text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: plm_platform_bom; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE IF NOT EXISTS plm_platform_bom (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    plm_platform_id uuid NOT NULL,
    model text,
    parent_item text,
    child_item text,
    child_item_description text,
    child_item_revision text,
    child_quantity numeric,
    bom_level integer,
    child_bom_path text,
    change_order text,
    change_date date,
    ods_active boolean,
    ods_inferred boolean,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: processing_runs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE IF NOT EXISTS processing_runs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    document_id uuid NOT NULL,
    run_type text,
    status text,
    started_at timestamp with time zone,
    completed_at timestamp with time zone,
    error_message text
);


--
-- Name: product_line; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE IF NOT EXISTS product_line (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    program_id uuid NOT NULL,
    name text,
    description text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: program; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE IF NOT EXISTS program (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: program_member; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE IF NOT EXISTS program_member (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    program_id uuid NOT NULL,
    name text NOT NULL,
    email text NOT NULL,
    role text NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    member_function text
);


--
-- Name: program_name_catalog; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE IF NOT EXISTS program_name_catalog (
    id integer NOT NULL,
    name text NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: program_name_catalog_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE IF NOT EXISTS program_name_catalog_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: program_name_catalog_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE program_name_catalog_id_seq OWNED BY program_name_catalog.id;


--
-- Name: program_unified_metadata; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE IF NOT EXISTS program_unified_metadata (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    program_id uuid NOT NULL,
    field_name text NOT NULL,
    field_category text,
    value_text text,
    value_num numeric,
    value_bool boolean,
    value_date date,
    value_json jsonb,
    source_document_id uuid NOT NULL,
    source_doc_type text,
    source_doc_version text,
    source_file_name text,
    extraction_run_id uuid,
    extraction_confidence double precision,
    source_modified_at timestamp with time zone,
    version_sort_key text,
    is_primary boolean DEFAULT true NOT NULL,
    superseded_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: regrello_workflow_template; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE IF NOT EXISTS regrello_workflow_template (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    action text NOT NULL,
    workflow_template_id integer NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    name text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: service_account; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE IF NOT EXISTS service_account (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    client_id text NOT NULL,
    name text NOT NULL,
    description text,
    role text NOT NULL,
    api_key_hash text NOT NULL,
    api_key_prefix text NOT NULL,
    status text DEFAULT 'active'::text NOT NULL,
    created_by uuid,
    last_used_at timestamp with time zone,
    expires_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ck_service_account_status CHECK ((status = ANY (ARRAY['active'::text, 'disabled'::text])))
);


--
-- Name: service_account_platform_access; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE IF NOT EXISTS service_account_platform_access (
    service_account_id uuid NOT NULL,
    platform_id uuid NOT NULL
);


--
-- Name: sharepoint_sync_state; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE IF NOT EXISTS sharepoint_sync_state (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    source_id uuid NOT NULL,
    delta_link text,
    next_link text,
    status text,
    last_polled_at timestamp with time zone,
    last_success_at timestamp with time zone,
    last_error text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    last_run_started_at timestamp with time zone,
    last_run_total_count integer,
    last_run_synced_count integer
);


--
-- Name: source; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE IF NOT EXISTS source (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    platform_id uuid NOT NULL,
    source_type text,
    connection_params jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: source_confluence; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE IF NOT EXISTS source_confluence (
    source_id uuid NOT NULL,
    space_key text,
    base_url text,
    enrolled_url text,
    filter_labels jsonb,
    filter_title_contains text,
    filter_parent_page_id text,
    filter_include_subpages boolean,
    filter_max_depth integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    page_type text,
    doc_type text
);


--
-- Name: source_iomete; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE IF NOT EXISTS source_iomete (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    platform_id uuid,
    query_type text,
    sql text,
    status text DEFAULT 'pending'::text NOT NULL,
    triggered_at timestamp with time zone,
    completed_at timestamp with time zone,
    row_count bigint,
    error_message text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: source_jira; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE IF NOT EXISTS source_jira (
    source_id uuid NOT NULL,
    instance_url text,
    instance_type text,
    api_version text,
    enrolled_project_key text,
    enrolled_project_id text,
    project_name text,
    web_url text,
    allowed_issue_types jsonb DEFAULT '[]'::jsonb,
    allowed_statuses jsonb DEFAULT '[]'::jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    platform_filter text,
    jql_query text,
    doc_type_override text,
    additional_field_values jsonb DEFAULT '{}'::jsonb NOT NULL
);


--
-- Name: COLUMN source_jira.allowed_issue_types; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN source_jira.allowed_issue_types IS 'Array of allowed issue types (e.g., ["Bug", "Story", "Task"]). Empty array = all types.';


--
-- Name: COLUMN source_jira.allowed_statuses; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN source_jira.allowed_statuses IS 'Array of allowed statuses (e.g., ["To Do", "In Progress"]). Empty array = all statuses.';


--
-- Name: COLUMN source_jira.platform_filter; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN source_jira.platform_filter IS 'Per-source platform filter Jira field name (e.g., "Affected Platform(s)"). The platform value (e.g., RENEGADE) is a runtime input, not stored here.';


--
-- Name: source_sharepoint; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE IF NOT EXISTS source_sharepoint (
    source_id uuid NOT NULL,
    enrolled_url text,
    scope_type text,
    site_id text,
    drive_id text,
    root_item_id text,
    root_path text,
    web_url text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: user_platform_access; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE IF NOT EXISTS user_platform_access (
    user_id uuid NOT NULL,
    platform_id uuid NOT NULL
);


--
-- Name: user_session; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE IF NOT EXISTS user_session (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    session_id text NOT NULL,
    user_email text NOT NULL,
    okta_uid text,
    access_token text,
    refresh_token text,
    id_token text,
    name text,
    given_name text,
    family_name text,
    department text,
    expires_at timestamp with time zone NOT NULL,
    last_activity_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: platform_name_catalog id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY platform_name_catalog ALTER COLUMN id SET DEFAULT nextval('platform_name_catalog_id_seq'::regclass);


--
-- Name: program_name_catalog id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY program_name_catalog ALTER COLUMN id SET DEFAULT nextval('program_name_catalog_id_seq'::regclass);


--
-- Name: app_user app_user_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'app_user_pkey' 
        AND connamespace = current_schema()::regnamespace
    ) THEN
        ALTER TABLE ONLY app_user
            ADD CONSTRAINT app_user_pkey PRIMARY KEY (id);
    END IF;
END $$;


--
-- Name: change_detection_run change_detection_run_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'change_detection_run_pkey' 
        AND connamespace = current_schema()::regnamespace
    ) THEN
        ALTER TABLE ONLY change_detection_run
            ADD CONSTRAINT change_detection_run_pkey PRIMARY KEY (id);
    END IF;
END $$;


--
-- Name: chat_logs chat_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'chat_logs_pkey' 
        AND connamespace = current_schema()::regnamespace
    ) THEN
        ALTER TABLE ONLY chat_logs
            ADD CONSTRAINT chat_logs_pkey PRIMARY KEY (id);
    END IF;
END $$;


--
-- Name: chat_logs chat_logs_trace_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'chat_logs_trace_id_key' 
        AND connamespace = current_schema()::regnamespace
    ) THEN
        ALTER TABLE ONLY chat_logs
            ADD CONSTRAINT chat_logs_trace_id_key UNIQUE (trace_id);
    END IF;
END $$;


--
-- Name: classification_rules classification_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'classification_rules_pkey' 
        AND connamespace = current_schema()::regnamespace
    ) THEN
        ALTER TABLE ONLY classification_rules
            ADD CONSTRAINT classification_rules_pkey PRIMARY KEY (id);
    END IF;
END $$;


--
-- Name: confluence_sync_state confluence_sync_state_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'confluence_sync_state_pkey' 
        AND connamespace = current_schema()::regnamespace
    ) THEN
        ALTER TABLE ONLY confluence_sync_state
            ADD CONSTRAINT confluence_sync_state_pkey PRIMARY KEY (id);
    END IF;
END $$;


--
-- Name: confluence_sync_state confluence_sync_state_source_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'confluence_sync_state_source_id_key' 
        AND connamespace = current_schema()::regnamespace
    ) THEN
        ALTER TABLE ONLY confluence_sync_state
            ADD CONSTRAINT confluence_sync_state_source_id_key UNIQUE (source_id);
    END IF;
END $$;


--
-- Name: document_block_groups document_block_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'document_block_groups_pkey' 
        AND connamespace = current_schema()::regnamespace
    ) THEN
        ALTER TABLE ONLY document_block_groups
            ADD CONSTRAINT document_block_groups_pkey PRIMARY KEY (id);
    END IF;
END $$;


--
-- Name: document_blocks document_blocks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'document_blocks_pkey' 
        AND connamespace = current_schema()::regnamespace
    ) THEN
        ALTER TABLE ONLY document_blocks
            ADD CONSTRAINT document_blocks_pkey PRIMARY KEY (id);
    END IF;
END $$;


--
-- Name: document_chunks document_chunks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'document_chunks_pkey' 
        AND connamespace = current_schema()::regnamespace
    ) THEN
        ALTER TABLE ONLY document_chunks
            ADD CONSTRAINT document_chunks_pkey PRIMARY KEY (id);
    END IF;
END $$;


--
-- Name: document_classification document_classification_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'document_classification_pkey' 
        AND connamespace = current_schema()::regnamespace
    ) THEN
        ALTER TABLE ONLY document_classification
            ADD CONSTRAINT document_classification_pkey PRIMARY KEY (id);
    END IF;
END $$;


--
-- Name: document_confluence document_confluence_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'document_confluence_pkey' 
        AND connamespace = current_schema()::regnamespace
    ) THEN
        ALTER TABLE ONLY document_confluence
            ADD CONSTRAINT document_confluence_pkey PRIMARY KEY (document_id);
    END IF;
END $$;


--
-- Name: document_extraction document_extraction_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'document_extraction_pkey' 
        AND connamespace = current_schema()::regnamespace
    ) THEN
        ALTER TABLE ONLY document_extraction
            ADD CONSTRAINT document_extraction_pkey PRIMARY KEY (id);
    END IF;
END $$;


--
-- Name: document_jira document_jira_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'document_jira_pkey' 
        AND connamespace = current_schema()::regnamespace
    ) THEN
        ALTER TABLE ONLY document_jira
            ADD CONSTRAINT document_jira_pkey PRIMARY KEY (document_id);
    END IF;
END $$;


--
-- Name: document_metadata document_metadata_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'document_metadata_pkey' 
        AND connamespace = current_schema()::regnamespace
    ) THEN
        ALTER TABLE ONLY document_metadata
            ADD CONSTRAINT document_metadata_pkey PRIMARY KEY (id);
    END IF;
END $$;


--
-- Name: document_metrics document_metrics_document_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'document_metrics_document_id_key' 
        AND connamespace = current_schema()::regnamespace
    ) THEN
        ALTER TABLE ONLY document_metrics
            ADD CONSTRAINT document_metrics_document_id_key UNIQUE (document_id);
    END IF;
END $$;


--
-- Name: document_metrics document_metrics_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'document_metrics_pkey' 
        AND connamespace = current_schema()::regnamespace
    ) THEN
        ALTER TABLE ONLY document_metrics
            ADD CONSTRAINT document_metrics_pkey PRIMARY KEY (id);
    END IF;
END $$;


--
-- Name: document_parse_result document_parse_result_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'document_parse_result_pkey' 
        AND connamespace = current_schema()::regnamespace
    ) THEN
        ALTER TABLE ONLY document_parse_result
            ADD CONSTRAINT document_parse_result_pkey PRIMARY KEY (id);
    END IF;
END $$;


--
-- Name: document document_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'document_pkey' 
        AND connamespace = current_schema()::regnamespace
    ) THEN
        ALTER TABLE ONLY document
            ADD CONSTRAINT document_pkey PRIMARY KEY (id);
    END IF;
END $$;


--
-- Name: document_sharepoint document_sharepoint_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'document_sharepoint_pkey' 
        AND connamespace = current_schema()::regnamespace
    ) THEN
        ALTER TABLE ONLY document_sharepoint
            ADD CONSTRAINT document_sharepoint_pkey PRIMARY KEY (document_id);
    END IF;
END $$;


--
-- Name: document_types document_types_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'document_types_pkey' 
        AND connamespace = current_schema()::regnamespace
    ) THEN
        ALTER TABLE ONLY document_types
            ADD CONSTRAINT document_types_pkey PRIMARY KEY (id);
    END IF;
END $$;


--
-- Name: document_validation document_validation_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'document_validation_pkey' 
        AND connamespace = current_schema()::regnamespace
    ) THEN
        ALTER TABLE ONLY document_validation
            ADD CONSTRAINT document_validation_pkey PRIMARY KEY (id);
    END IF;
END $$;


--
-- Name: ingestion_runs ingestion_runs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'ingestion_runs_pkey' 
        AND connamespace = current_schema()::regnamespace
    ) THEN
        ALTER TABLE ONLY ingestion_runs
            ADD CONSTRAINT ingestion_runs_pkey PRIMARY KEY (id);
    END IF;
END $$;


--
-- Name: jira_comment jira_comment_comment_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'jira_comment_comment_id_key' 
        AND connamespace = current_schema()::regnamespace
    ) THEN
        ALTER TABLE ONLY jira_comment
            ADD CONSTRAINT jira_comment_comment_id_key UNIQUE (comment_id);
    END IF;
END $$;


--
-- Name: jira_comment jira_comment_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'jira_comment_pkey' 
        AND connamespace = current_schema()::regnamespace
    ) THEN
        ALTER TABLE ONLY jira_comment
            ADD CONSTRAINT jira_comment_pkey PRIMARY KEY (id);
    END IF;
END $$;


--
-- Name: jira_issue_history jira_issue_history_change_hash_key; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'jira_issue_history_change_hash_key' 
        AND connamespace = current_schema()::regnamespace
    ) THEN
        ALTER TABLE ONLY jira_issue_history
            ADD CONSTRAINT jira_issue_history_change_hash_key UNIQUE (change_hash);
    END IF;
END $$;


--
-- Name: jira_issue_history jira_issue_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'jira_issue_history_pkey' 
        AND connamespace = current_schema()::regnamespace
    ) THEN
        ALTER TABLE ONLY jira_issue_history
            ADD CONSTRAINT jira_issue_history_pkey PRIMARY KEY (id);
    END IF;
END $$;


--
-- Name: jira_project jira_project_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'jira_project_pkey' 
        AND connamespace = current_schema()::regnamespace
    ) THEN
        ALTER TABLE ONLY jira_project
            ADD CONSTRAINT jira_project_pkey PRIMARY KEY (id);
    END IF;
END $$;


--
-- Name: jira_project jira_project_project_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'jira_project_project_key_key' 
        AND connamespace = current_schema()::regnamespace
    ) THEN
        ALTER TABLE ONLY jira_project
            ADD CONSTRAINT jira_project_project_key_key UNIQUE (project_key);
    END IF;
END $$;


--
-- Name: jira_sync_state jira_sync_state_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'jira_sync_state_pkey' 
        AND connamespace = current_schema()::regnamespace
    ) THEN
        ALTER TABLE ONLY jira_sync_state
            ADD CONSTRAINT jira_sync_state_pkey PRIMARY KEY (id);
    END IF;
END $$;


--
-- Name: jira_sync_state jira_sync_state_source_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'jira_sync_state_source_id_key' 
        AND connamespace = current_schema()::regnamespace
    ) THEN
        ALTER TABLE ONLY jira_sync_state
            ADD CONSTRAINT jira_sync_state_source_id_key UNIQUE (source_id);
    END IF;
END $$;


--
-- Name: llm_calls llm_calls_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'llm_calls_pkey' 
        AND connamespace = current_schema()::regnamespace
    ) THEN
        ALTER TABLE ONLY llm_calls
            ADD CONSTRAINT llm_calls_pkey PRIMARY KEY (id);
    END IF;
END $$;


--
-- Name: notification_preferences notification_preferences_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'notification_preferences_pkey' 
        AND connamespace = current_schema()::regnamespace
    ) THEN
        ALTER TABLE ONLY notification_preferences
            ADD CONSTRAINT notification_preferences_pkey PRIMARY KEY (id);
    END IF;
END $$;


--
-- Name: pipeline_runs pipeline_runs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'pipeline_runs_pkey' 
        AND connamespace = current_schema()::regnamespace
    ) THEN
        ALTER TABLE ONLY pipeline_runs
            ADD CONSTRAINT pipeline_runs_pkey PRIMARY KEY (id);
    END IF;
END $$;


--
-- Name: platform_information platform_information_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'platform_information_pkey' 
        AND connamespace = current_schema()::regnamespace
    ) THEN
        ALTER TABLE ONLY platform_information
            ADD CONSTRAINT platform_information_pkey PRIMARY KEY (id);
    END IF;
END $$;


--
-- Name: platform_ingestion_sync_state platform_ingestion_sync_state_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'platform_ingestion_sync_state_pkey' 
        AND connamespace = current_schema()::regnamespace
    ) THEN
        ALTER TABLE ONLY platform_ingestion_sync_state
            ADD CONSTRAINT platform_ingestion_sync_state_pkey PRIMARY KEY (id);
    END IF;
END $$;


--
-- Name: platform_name_catalog platform_name_catalog_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'platform_name_catalog_name_key' 
        AND connamespace = current_schema()::regnamespace
    ) THEN
        ALTER TABLE ONLY platform_name_catalog
            ADD CONSTRAINT platform_name_catalog_name_key UNIQUE (name);
    END IF;
END $$;


--
-- Name: platform_name_catalog platform_name_catalog_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'platform_name_catalog_pkey' 
        AND connamespace = current_schema()::regnamespace
    ) THEN
        ALTER TABLE ONLY platform_name_catalog
            ADD CONSTRAINT platform_name_catalog_pkey PRIMARY KEY (id);
    END IF;
END $$;


--
-- Name: platform_raw_data platform_raw_data_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'platform_raw_data_pkey' 
        AND connamespace = current_schema()::regnamespace
    ) THEN
        ALTER TABLE ONLY platform_raw_data
            ADD CONSTRAINT platform_raw_data_pkey PRIMARY KEY (id);
    END IF;
END $$;


--
-- Name: plm_platform_bom plm_platform_bom_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'plm_platform_bom_pkey' 
        AND connamespace = current_schema()::regnamespace
    ) THEN
        ALTER TABLE ONLY plm_platform_bom
            ADD CONSTRAINT plm_platform_bom_pkey PRIMARY KEY (id);
    END IF;
END $$;


--
-- Name: processing_runs processing_runs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'processing_runs_pkey' 
        AND connamespace = current_schema()::regnamespace
    ) THEN
        ALTER TABLE ONLY processing_runs
            ADD CONSTRAINT processing_runs_pkey PRIMARY KEY (id);
    END IF;
END $$;


--
-- Name: product_line product_line_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'product_line_pkey' 
        AND connamespace = current_schema()::regnamespace
    ) THEN
        ALTER TABLE ONLY product_line
            ADD CONSTRAINT product_line_pkey PRIMARY KEY (id);
    END IF;
END $$;


--
-- Name: platform_jira_project program_jira_project_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'program_jira_project_pkey' 
        AND connamespace = current_schema()::regnamespace
    ) THEN
        ALTER TABLE ONLY platform_jira_project
            ADD CONSTRAINT program_jira_project_pkey PRIMARY KEY (id);
    END IF;
END $$;


--
-- Name: program_member program_member_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'program_member_pkey' 
        AND connamespace = current_schema()::regnamespace
    ) THEN
        ALTER TABLE ONLY program_member
            ADD CONSTRAINT program_member_pkey PRIMARY KEY (id);
    END IF;
END $$;


--
-- Name: program_name_catalog program_name_catalog_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'program_name_catalog_name_key' 
        AND connamespace = current_schema()::regnamespace
    ) THEN
        ALTER TABLE ONLY program_name_catalog
            ADD CONSTRAINT program_name_catalog_name_key UNIQUE (name);
    END IF;
END $$;


--
-- Name: program_name_catalog program_name_catalog_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'program_name_catalog_pkey' 
        AND connamespace = current_schema()::regnamespace
    ) THEN
        ALTER TABLE ONLY program_name_catalog
            ADD CONSTRAINT program_name_catalog_pkey PRIMARY KEY (id);
    END IF;
END $$;


--
-- Name: program program_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'program_name_key' 
        AND connamespace = current_schema()::regnamespace
    ) THEN
        ALTER TABLE ONLY program
            ADD CONSTRAINT program_name_key UNIQUE (name);
    END IF;
END $$;


--
-- Name: platform program_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'program_pkey' 
        AND connamespace = current_schema()::regnamespace
    ) THEN
        ALTER TABLE ONLY platform
            ADD CONSTRAINT program_pkey PRIMARY KEY (id);
    END IF;
END $$;


--
-- Name: program program_pkey1; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'program_pkey1' 
        AND connamespace = current_schema()::regnamespace
    ) THEN
        ALTER TABLE ONLY program
            ADD CONSTRAINT program_pkey1 PRIMARY KEY (id);
    END IF;
END $$;


--
-- Name: plm_platform program_plm_platform_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'program_plm_platform_pkey' 
        AND connamespace = current_schema()::regnamespace
    ) THEN
        ALTER TABLE ONLY plm_platform
            ADD CONSTRAINT program_plm_platform_pkey PRIMARY KEY (id);
    END IF;
END $$;


--
-- Name: program_unified_metadata program_unified_metadata_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'program_unified_metadata_pkey' 
        AND connamespace = current_schema()::regnamespace
    ) THEN
        ALTER TABLE ONLY program_unified_metadata
            ADD CONSTRAINT program_unified_metadata_pkey PRIMARY KEY (id);
    END IF;
END $$;


--
-- Name: regrello_workflow_template regrello_workflow_template_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'regrello_workflow_template_pkey' 
        AND connamespace = current_schema()::regnamespace
    ) THEN
        ALTER TABLE ONLY regrello_workflow_template
            ADD CONSTRAINT regrello_workflow_template_pkey PRIMARY KEY (id);
    END IF;
END $$;


--
-- Name: service_account service_account_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'service_account_pkey' 
        AND connamespace = current_schema()::regnamespace
    ) THEN
        ALTER TABLE ONLY service_account
            ADD CONSTRAINT service_account_pkey PRIMARY KEY (id);
    END IF;
END $$;


--
-- Name: service_account_platform_access service_account_program_access_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'service_account_program_access_pkey' 
        AND connamespace = current_schema()::regnamespace
    ) THEN
        ALTER TABLE ONLY service_account_platform_access
            ADD CONSTRAINT service_account_program_access_pkey PRIMARY KEY (service_account_id, platform_id);
    END IF;
END $$;


--
-- Name: sharepoint_sync_state sharepoint_sync_state_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'sharepoint_sync_state_pkey' 
        AND connamespace = current_schema()::regnamespace
    ) THEN
        ALTER TABLE ONLY sharepoint_sync_state
            ADD CONSTRAINT sharepoint_sync_state_pkey PRIMARY KEY (id);
    END IF;
END $$;


--
-- Name: sharepoint_sync_state sharepoint_sync_state_source_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'sharepoint_sync_state_source_id_key' 
        AND connamespace = current_schema()::regnamespace
    ) THEN
        ALTER TABLE ONLY sharepoint_sync_state
            ADD CONSTRAINT sharepoint_sync_state_source_id_key UNIQUE (source_id);
    END IF;
END $$;


--
-- Name: source_confluence source_confluence_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'source_confluence_pkey' 
        AND connamespace = current_schema()::regnamespace
    ) THEN
        ALTER TABLE ONLY source_confluence
            ADD CONSTRAINT source_confluence_pkey PRIMARY KEY (source_id);
    END IF;
END $$;


--
-- Name: source_iomete source_iomete_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'source_iomete_pkey' 
        AND connamespace = current_schema()::regnamespace
    ) THEN
        ALTER TABLE ONLY source_iomete
            ADD CONSTRAINT source_iomete_pkey PRIMARY KEY (id);
    END IF;
END $$;


--
-- Name: source_jira source_jira_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'source_jira_pkey' 
        AND connamespace = current_schema()::regnamespace
    ) THEN
        ALTER TABLE ONLY source_jira
            ADD CONSTRAINT source_jira_pkey PRIMARY KEY (source_id);
    END IF;
END $$;


--
-- Name: source source_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'source_pkey' 
        AND connamespace = current_schema()::regnamespace
    ) THEN
        ALTER TABLE ONLY source
            ADD CONSTRAINT source_pkey PRIMARY KEY (id);
    END IF;
END $$;


--
-- Name: source_sharepoint source_sharepoint_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'source_sharepoint_pkey' 
        AND connamespace = current_schema()::regnamespace
    ) THEN
        ALTER TABLE ONLY source_sharepoint
            ADD CONSTRAINT source_sharepoint_pkey PRIMARY KEY (source_id);
    END IF;
END $$;


--
-- Name: document_block_groups uq_document_block_groups_document_id_group_index; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'uq_document_block_groups_document_id_group_index' 
        AND connamespace = current_schema()::regnamespace
    ) THEN
        ALTER TABLE ONLY document_block_groups
            ADD CONSTRAINT uq_document_block_groups_document_id_group_index UNIQUE (document_id, group_index);
    END IF;
END $$;


--
-- Name: document_extraction uq_document_extraction_document_id; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'uq_document_extraction_document_id' 
        AND connamespace = current_schema()::regnamespace
    ) THEN
        ALTER TABLE ONLY document_extraction
            ADD CONSTRAINT uq_document_extraction_document_id UNIQUE (document_id);
    END IF;
END $$;


--
-- Name: document_parse_result uq_document_parse_result_document_id; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'uq_document_parse_result_document_id' 
        AND connamespace = current_schema()::regnamespace
    ) THEN
        ALTER TABLE ONLY document_parse_result
            ADD CONSTRAINT uq_document_parse_result_document_id UNIQUE (document_id);
    END IF;
END $$;


--
-- Name: pipeline_runs uq_pipeline_runs_platform_doc_correlation; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'uq_pipeline_runs_platform_doc_correlation' 
        AND connamespace = current_schema()::regnamespace
    ) THEN
        ALTER TABLE ONLY pipeline_runs
            ADD CONSTRAINT uq_pipeline_runs_platform_doc_correlation UNIQUE (platform_id, doc_id, correlation_id);
    END IF;
END $$;


--
-- Name: platform_information uq_platform_information_jira_issue_key; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'uq_platform_information_jira_issue_key' 
        AND connamespace = current_schema()::regnamespace
    ) THEN
        ALTER TABLE ONLY platform_information
            ADD CONSTRAINT uq_platform_information_jira_issue_key UNIQUE (jira_issue_key);
    END IF;
END $$;


--
-- Name: platform_ingestion_sync_state uq_platform_ingestion_sync_state_source_name; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'uq_platform_ingestion_sync_state_source_name' 
        AND connamespace = current_schema()::regnamespace
    ) THEN
        ALTER TABLE ONLY platform_ingestion_sync_state
            ADD CONSTRAINT uq_platform_ingestion_sync_state_source_name UNIQUE (source_name);
    END IF;
END $$;


--
-- Name: platform_raw_data uq_platform_raw_data_jira_issue_key; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'uq_platform_raw_data_jira_issue_key' 
        AND connamespace = current_schema()::regnamespace
    ) THEN
        ALTER TABLE ONLY platform_raw_data
            ADD CONSTRAINT uq_platform_raw_data_jira_issue_key UNIQUE (jira_issue_key);
    END IF;
END $$;


--
-- Name: program_unified_metadata uq_program_field_document; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'uq_program_field_document' 
        AND connamespace = current_schema()::regnamespace
    ) THEN
        ALTER TABLE ONLY program_unified_metadata
            ADD CONSTRAINT uq_program_field_document UNIQUE (program_id, field_name, source_document_id);
    END IF;
END $$;


--
-- Name: user_platform_access user_program_access_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'user_program_access_pkey' 
        AND connamespace = current_schema()::regnamespace
    ) THEN
        ALTER TABLE ONLY user_platform_access
            ADD CONSTRAINT user_program_access_pkey PRIMARY KEY (user_id, platform_id);
    END IF;
END $$;


--
-- Name: user_session user_session_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'user_session_pkey' 
        AND connamespace = current_schema()::regnamespace
    ) THEN
        ALTER TABLE ONLY user_session
            ADD CONSTRAINT user_session_pkey PRIMARY KEY (id);
    END IF;
END $$;


--
-- Name: ix_app_user_email; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX IF NOT EXISTS ix_app_user_email ON app_user USING btree (email);


--
-- Name: ix_change_detection_run_base_document_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_change_detection_run_base_document_id ON change_detection_run USING btree (base_document_id);


--
-- Name: ix_change_detection_run_platform_base; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_change_detection_run_platform_base ON change_detection_run USING btree (platform_id, base_document_id);


--
-- Name: ix_change_detection_run_platform_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_change_detection_run_platform_id ON change_detection_run USING btree (platform_id);


--
-- Name: ix_change_detection_run_regrello_workflow_template_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_change_detection_run_regrello_workflow_template_id ON change_detection_run USING btree (regrello_workflow_template_id);


--
-- Name: ix_change_detection_run_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_change_detection_run_status ON change_detection_run USING btree (status);


--
-- Name: ix_change_detection_run_target_document_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_change_detection_run_target_document_id ON change_detection_run USING btree (target_document_id);


--
-- Name: ix_change_detection_run_workflow_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_change_detection_run_workflow_id ON change_detection_run USING btree (workflow_id);


--
-- Name: ix_chat_logs_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_chat_logs_created_at ON chat_logs USING btree (created_at);


--
-- Name: ix_chat_logs_intent_archetype; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_chat_logs_intent_archetype ON chat_logs USING btree (intent_archetype);


--
-- Name: ix_chat_logs_platform_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_chat_logs_platform_id ON chat_logs USING btree (platform_id);


--
-- Name: ix_chat_logs_session_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_chat_logs_session_created ON chat_logs USING btree (session_id, created_at);


--
-- Name: ix_chat_logs_session_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_chat_logs_session_id ON chat_logs USING btree (session_id);


--
-- Name: ix_chat_logs_trace_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX IF NOT EXISTS ix_chat_logs_trace_id ON chat_logs USING btree (trace_id);


--
-- Name: ix_chat_logs_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_chat_logs_user_id ON chat_logs USING btree (user_id);


--
-- Name: ix_classification_rules_doc_type_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_classification_rules_doc_type_id ON classification_rules USING btree (doc_type_id);


--
-- Name: ix_classification_rules_is_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_classification_rules_is_active ON classification_rules USING btree (is_active);


--
-- Name: ix_classification_rules_priority; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_classification_rules_priority ON classification_rules USING btree (priority);


--
-- Name: ix_classification_rules_rule_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_classification_rules_rule_type ON classification_rules USING btree (rule_type);


--
-- Name: ix_confluence_sync_state_last_success_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_confluence_sync_state_last_success_at ON confluence_sync_state USING btree (last_success_at);


--
-- Name: ix_confluence_sync_state_source_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_confluence_sync_state_source_id ON confluence_sync_state USING btree (source_id);


--
-- Name: ix_confluence_sync_state_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_confluence_sync_state_status ON confluence_sync_state USING btree (status);


--
-- Name: ix_doc_metadata_doc_id_ns_key_prov_run_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX IF NOT EXISTS ix_doc_metadata_doc_id_ns_key_prov_run_id ON document_metadata USING btree (document_id, namespace, key, provenance_run_id);


--
-- Name: ix_doc_sp_platform_drive_item; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX IF NOT EXISTS ix_doc_sp_platform_drive_item ON document_sharepoint USING btree (platform_id, drive_id, item_id);


--
-- Name: ix_document_block_groups_document_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_document_block_groups_document_id ON document_block_groups USING btree (document_id);


--
-- Name: ix_document_block_groups_group_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_document_block_groups_group_type ON document_block_groups USING btree (group_type);


--
-- Name: ix_document_blocks_block_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_document_blocks_block_type ON document_blocks USING btree (block_type);


--
-- Name: ix_document_blocks_document_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_document_blocks_document_id ON document_blocks USING btree (document_id);


--
-- Name: ix_document_blocks_document_id_block_index; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX IF NOT EXISTS ix_document_blocks_document_id_block_index ON document_blocks USING btree (document_id, block_index);


--
-- Name: ix_document_chunks_chunk_strategy; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_document_chunks_chunk_strategy ON document_chunks USING btree (chunk_strategy);


--
-- Name: ix_document_chunks_document_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_document_chunks_document_id ON document_chunks USING btree (document_id);


--
-- Name: ix_document_chunks_document_id_chunk_index; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX IF NOT EXISTS ix_document_chunks_document_id_chunk_index ON document_chunks USING btree (document_id, chunk_index);


--
-- Name: ix_document_chunks_metadata; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_document_chunks_metadata ON document_chunks USING gin (metadata);


--
-- Name: ix_document_classification_classified_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_document_classification_classified_at ON document_classification USING btree (classified_at);


--
-- Name: ix_document_classification_doc_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_document_classification_doc_type ON document_classification USING btree (doc_type);


--
-- Name: ix_document_classification_document_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_document_classification_document_id ON document_classification USING btree (document_id);


--
-- Name: ix_document_classification_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_document_classification_status ON document_classification USING btree (status);


--
-- Name: ix_document_confluence_is_attachment; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_document_confluence_is_attachment ON document_confluence USING btree (is_attachment);


--
-- Name: ix_document_confluence_last_modified_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_document_confluence_last_modified_at ON document_confluence USING btree (last_modified_at);


--
-- Name: ix_document_confluence_page_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_document_confluence_page_id ON document_confluence USING btree (page_id);


--
-- Name: ix_document_confluence_parent_page_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_document_confluence_parent_page_id ON document_confluence USING btree (parent_page_id);


--
-- Name: ix_document_confluence_space_key; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_document_confluence_space_key ON document_confluence USING btree (space_key);


--
-- Name: ix_document_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_document_deleted_at ON document USING btree (deleted_at);


--
-- Name: ix_document_external_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_document_external_id ON document USING btree (external_id);


--
-- Name: ix_document_extraction_doc_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_document_extraction_doc_type ON document_extraction USING btree (doc_type);


--
-- Name: ix_document_extraction_document_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_document_extraction_document_id ON document_extraction USING btree (document_id);


--
-- Name: ix_document_extraction_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_document_extraction_status ON document_extraction USING btree (status);


--
-- Name: ix_document_jira_attachment_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_document_jira_attachment_id ON document_jira USING btree (attachment_id);


--
-- Name: ix_document_jira_issue_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_document_jira_issue_id ON document_jira USING btree (issue_id);


--
-- Name: ix_document_jira_issue_key; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_document_jira_issue_key ON document_jira USING btree (issue_key);


--
-- Name: ix_document_jira_issue_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_document_jira_issue_type ON document_jira USING btree (issue_type);


--
-- Name: ix_document_jira_jira_updated_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_document_jira_jira_updated_at ON document_jira USING btree (jira_updated_at);


--
-- Name: ix_document_jira_parent_issue_key; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_document_jira_parent_issue_key ON document_jira USING btree (parent_issue_key);


--
-- Name: ix_document_jira_project_key; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_document_jira_project_key ON document_jira USING btree (project_key);


--
-- Name: ix_document_jira_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_document_jira_status ON document_jira USING btree (status);


--
-- Name: ix_document_metadata_document_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_document_metadata_document_id ON document_metadata USING btree (document_id);


--
-- Name: ix_document_parse_result_document_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_document_parse_result_document_id ON document_parse_result USING btree (document_id);


--
-- Name: ix_document_parse_result_parser_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_document_parse_result_parser_type ON document_parse_result USING btree (parser_type);


--
-- Name: ix_document_parse_result_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_document_parse_result_status ON document_parse_result USING btree (status);


--
-- Name: ix_document_platform_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_document_platform_id ON document USING btree (platform_id);


--
-- Name: ix_document_sharepoint_last_modified_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_document_sharepoint_last_modified_at ON document_sharepoint USING btree (last_modified_at);


--
-- Name: ix_document_sharepoint_parent_item_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_document_sharepoint_parent_item_id ON document_sharepoint USING btree (parent_item_id);


--
-- Name: ix_document_sharepoint_path; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_document_sharepoint_path ON document_sharepoint USING btree (path);


--
-- Name: ix_document_source_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_document_source_id ON document USING btree (source_id);


--
-- Name: ix_document_types_is_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_document_types_is_active ON document_types USING btree (is_active);


--
-- Name: ix_document_types_line_of_business; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_document_types_line_of_business ON document_types USING btree (line_of_business);


--
-- Name: ix_document_types_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_document_types_name ON document_types USING btree (name);


--
-- Name: ix_document_validation_document_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_document_validation_document_id ON document_validation USING btree (document_id);


--
-- Name: ix_document_validation_regrello_workflow_template_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_document_validation_regrello_workflow_template_id ON document_validation USING btree (regrello_workflow_template_id);


--
-- Name: ix_document_validation_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_document_validation_status ON document_validation USING btree (status);


--
-- Name: ix_ingestion_runs_document_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_ingestion_runs_document_id ON ingestion_runs USING btree (document_id);


--
-- Name: ix_jira_comment_author_account_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_jira_comment_author_account_id ON jira_comment USING btree (author_account_id);


--
-- Name: ix_jira_comment_comment_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_jira_comment_comment_id ON jira_comment USING btree (comment_id);


--
-- Name: ix_jira_comment_document_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_jira_comment_document_id ON jira_comment USING btree (document_id);


--
-- Name: ix_jira_comment_issue_key; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_jira_comment_issue_key ON jira_comment USING btree (issue_key);


--
-- Name: ix_jira_issue_history_change_group_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_jira_issue_history_change_group_id ON jira_issue_history USING btree (change_group_id);


--
-- Name: ix_jira_issue_history_change_hash; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_jira_issue_history_change_hash ON jira_issue_history USING btree (change_hash);


--
-- Name: ix_jira_issue_history_changed_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_jira_issue_history_changed_at ON jira_issue_history USING btree (changed_at);


--
-- Name: ix_jira_issue_history_document_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_jira_issue_history_document_id ON jira_issue_history USING btree (document_id);


--
-- Name: ix_jira_issue_history_field_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_jira_issue_history_field_name ON jira_issue_history USING btree (field_name);


--
-- Name: ix_jira_issue_history_issue_key; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_jira_issue_history_issue_key ON jira_issue_history USING btree (issue_key);


--
-- Name: ix_jira_issue_history_source_system; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_jira_issue_history_source_system ON jira_issue_history USING btree (source_system);


--
-- Name: ix_jira_issue_history_version_number; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_jira_issue_history_version_number ON jira_issue_history USING btree (issue_key, version_number);


--
-- Name: ix_jira_project_project_key; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_jira_project_project_key ON jira_project USING btree (project_key);


--
-- Name: ix_jira_sync_state_last_success_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_jira_sync_state_last_success_at ON jira_sync_state USING btree (last_success_at);


--
-- Name: ix_jira_sync_state_source_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_jira_sync_state_source_id ON jira_sync_state USING btree (source_id);


--
-- Name: ix_jira_sync_state_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_jira_sync_state_status ON jira_sync_state USING btree (status);


--
-- Name: ix_llm_calls_chat_log_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_llm_calls_chat_log_id ON llm_calls USING btree (chat_log_id);


--
-- Name: ix_llm_calls_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_llm_calls_created_at ON llm_calls USING btree (created_at);


--
-- Name: ix_llm_calls_step_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_llm_calls_step_name ON llm_calls USING btree (step_name);


--
-- Name: ix_notification_preferences_platform_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_notification_preferences_platform_user ON notification_preferences USING btree (platform_id, user_email);


--
-- Name: ix_pi_form_factor; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_pi_form_factor ON platform_information USING btree (form_factor);


--
-- Name: ix_pi_jira_updated_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_pi_jira_updated_at ON platform_information USING btree (jira_updated_at);


--
-- Name: ix_pi_lob_code; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_pi_lob_code ON platform_information USING btree (lob_code);


--
-- Name: ix_pi_platform_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_pi_platform_name ON platform_information USING btree (platform_name);


--
-- Name: ix_pi_predecessor_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_pi_predecessor_id ON platform_information USING btree (predecessor_id);


--
-- Name: ix_pi_program_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_pi_program_name ON platform_information USING btree (program_name);


--
-- Name: ix_pi_program_phase; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_pi_program_phase ON platform_information USING btree (program_phase);


--
-- Name: ix_pi_program_state; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_pi_program_state ON platform_information USING btree (program_state);


--
-- Name: ix_pipeline_runs_correlation_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_pipeline_runs_correlation_id ON pipeline_runs USING btree (correlation_id);


--
-- Name: ix_pipeline_runs_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_pipeline_runs_created_at ON pipeline_runs USING btree (created_at);


--
-- Name: ix_pipeline_runs_doc_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_pipeline_runs_doc_id ON pipeline_runs USING btree (doc_id);


--
-- Name: ix_pipeline_runs_platform_doc; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_pipeline_runs_platform_doc ON pipeline_runs USING btree (platform_id, doc_id);


--
-- Name: ix_pipeline_runs_platform_doc_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_pipeline_runs_platform_doc_status ON pipeline_runs USING btree (platform_id, doc_id, run_status);


--
-- Name: ix_pipeline_runs_platform_doc_version; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_pipeline_runs_platform_doc_version ON pipeline_runs USING btree (platform_id, doc_id, doc_version);


--
-- Name: ix_pipeline_runs_platform_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_pipeline_runs_platform_id ON pipeline_runs USING btree (platform_id);


--
-- Name: ix_pipeline_runs_run_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_pipeline_runs_run_status ON pipeline_runs USING btree (run_status);


--
-- Name: ix_platform_jira_project_platform_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_platform_jira_project_platform_id ON platform_jira_project USING btree (platform_id);


--
-- Name: ix_platform_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_platform_name ON platform USING btree (name);


--
-- Name: ix_platform_program_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_platform_program_id ON platform USING btree (program_id);


--
-- Name: ix_plm_platform_bom_child_item; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_plm_platform_bom_child_item ON plm_platform_bom USING btree (child_item);


--
-- Name: ix_plm_platform_bom_model; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_plm_platform_bom_model ON plm_platform_bom USING btree (model);


--
-- Name: ix_plm_platform_bom_plm_platform_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_plm_platform_bom_plm_platform_id ON plm_platform_bom USING btree (plm_platform_id);


--
-- Name: ix_plm_platform_item_number; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_plm_platform_item_number ON plm_platform USING btree (item_number);


--
-- Name: ix_plm_platform_platform_code; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_plm_platform_platform_code ON plm_platform USING btree (platform_code);


--
-- Name: ix_plm_platform_platform_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_plm_platform_platform_id ON plm_platform USING btree (platform_id);


--
-- Name: ix_prd_jira_issue_key; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_prd_jira_issue_key ON platform_raw_data USING btree (jira_issue_key);


--
-- Name: ix_processing_runs_document_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_processing_runs_document_id ON processing_runs USING btree (document_id);


--
-- Name: ix_product_line_program_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_product_line_program_id ON product_line USING btree (program_id);


--
-- Name: ix_program_jira_project_jira_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_program_jira_project_jira_project_id ON platform_jira_project USING btree (jira_project_id);


--
-- Name: ix_program_member_email; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_program_member_email ON program_member USING btree (email);


--
-- Name: ix_program_member_program_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_program_member_program_id ON program_member USING btree (program_id);


--
-- Name: ix_pum_doc_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_pum_doc_type ON program_unified_metadata USING btree (source_doc_type);


--
-- Name: ix_pum_field_category; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_pum_field_category ON program_unified_metadata USING btree (field_category);


--
-- Name: ix_pum_program_field; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_pum_program_field ON program_unified_metadata USING btree (program_id, field_name);


--
-- Name: ix_pum_program_field_primary; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_pum_program_field_primary ON program_unified_metadata USING btree (program_id, field_name) WHERE (is_primary = true);


--
-- Name: ix_pum_source_doc; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_pum_source_doc ON program_unified_metadata USING btree (source_document_id);


--
-- Name: ix_pum_version_sort; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_pum_version_sort ON program_unified_metadata USING btree (program_id, field_name, version_sort_key);


--
-- Name: ix_regrello_workflow_template_action; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_regrello_workflow_template_action ON regrello_workflow_template USING btree (action);


--
-- Name: ix_regrello_workflow_template_action_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_regrello_workflow_template_action_active ON regrello_workflow_template USING btree (action, is_active);


--
-- Name: ix_regrello_workflow_template_is_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_regrello_workflow_template_is_active ON regrello_workflow_template USING btree (is_active);


--
-- Name: ix_service_account_api_key_prefix; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_service_account_api_key_prefix ON service_account USING btree (api_key_prefix);


--
-- Name: ix_service_account_client_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX IF NOT EXISTS ix_service_account_client_id ON service_account USING btree (client_id);


--
-- Name: ix_service_account_platform_access_platform_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_service_account_platform_access_platform_id ON service_account_platform_access USING btree (platform_id);


--
-- Name: ix_service_account_platform_access_sa_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_service_account_platform_access_sa_id ON service_account_platform_access USING btree (service_account_id);


--
-- Name: ix_service_account_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_service_account_status ON service_account USING btree (status);


--
-- Name: ix_sharepoint_sync_state_last_success_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_sharepoint_sync_state_last_success_at ON sharepoint_sync_state USING btree (last_success_at);


--
-- Name: ix_sharepoint_sync_state_source_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_sharepoint_sync_state_source_id ON sharepoint_sync_state USING btree (source_id);


--
-- Name: ix_sharepoint_sync_state_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_sharepoint_sync_state_status ON sharepoint_sync_state USING btree (status);


--
-- Name: ix_source_confluence_base_url; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_source_confluence_base_url ON source_confluence USING btree (base_url);


--
-- Name: ix_source_confluence_space_key; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_source_confluence_space_key ON source_confluence USING btree (space_key);


--
-- Name: ix_source_iomete_platform_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_source_iomete_platform_id ON source_iomete USING btree (platform_id);


--
-- Name: ix_source_iomete_query_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_source_iomete_query_type ON source_iomete USING btree (query_type);


--
-- Name: ix_source_iomete_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_source_iomete_status ON source_iomete USING btree (status);


--
-- Name: ix_source_iomete_triggered_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_source_iomete_triggered_at ON source_iomete USING btree (triggered_at);


--
-- Name: ix_source_jira_instance_url; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_source_jira_instance_url ON source_jira USING btree (instance_url);


--
-- Name: ix_source_jira_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_source_jira_project_id ON source_jira USING btree (enrolled_project_id);


--
-- Name: ix_source_jira_project_key; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_source_jira_project_key ON source_jira USING btree (enrolled_project_key);


--
-- Name: ix_source_platform_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_source_platform_id ON source USING btree (platform_id);


--
-- Name: ix_source_sharepoint_drive_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_source_sharepoint_drive_id ON source_sharepoint USING btree (drive_id);


--
-- Name: ix_source_sharepoint_drive_id_root_item_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_source_sharepoint_drive_id_root_item_id ON source_sharepoint USING btree (drive_id, root_item_id);


--
-- Name: ix_source_sharepoint_site_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_source_sharepoint_site_id ON source_sharepoint USING btree (site_id);


--
-- Name: ix_source_source_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_source_source_type ON source USING btree (source_type);


--
-- Name: ix_user_platform_access_platform_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_user_platform_access_platform_id ON user_platform_access USING btree (platform_id);


--
-- Name: ix_user_program_access_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_user_program_access_user_id ON user_platform_access USING btree (user_id);


--
-- Name: ix_user_session_expires_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_user_session_expires_at ON user_session USING btree (expires_at);


--
-- Name: ix_user_session_session_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX IF NOT EXISTS ix_user_session_session_id ON user_session USING btree (session_id);


--
-- Name: ix_user_session_user_email; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX IF NOT EXISTS ix_user_session_user_email ON user_session USING btree (user_email);


--
-- Name: uq_document_types_name_lob; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX IF NOT EXISTS uq_document_types_name_lob ON document_types USING btree (name, line_of_business);


--
-- Name: uq_notification_preferences_platform_user_doctype; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX IF NOT EXISTS uq_notification_preferences_platform_user_doctype ON notification_preferences USING btree (platform_id, user_email, doc_type);


--
-- Name: uq_platform_jira_project_platform_jira; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX IF NOT EXISTS uq_platform_jira_project_platform_jira ON platform_jira_project USING btree (platform_id, jira_project_id);


--
-- Name: uq_platform_program_name; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX IF NOT EXISTS uq_platform_program_name ON platform USING btree (program_id, name);


--
-- Name: document_types set_updated_at_document_types; Type: TRIGGER; Schema: public; Owner: -
--

CREATE OR REPLACE TRIGGER set_updated_at_document_types BEFORE UPDATE ON document_types FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();


--
-- Name: document_validation set_updated_at_document_validation; Type: TRIGGER; Schema: public; Owner: -
--

CREATE OR REPLACE TRIGGER set_updated_at_document_validation BEFORE UPDATE ON document_validation FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();


--
-- Name: notification_preferences set_updated_at_notification_preferences; Type: TRIGGER; Schema: public; Owner: -
--

CREATE OR REPLACE TRIGGER set_updated_at_notification_preferences BEFORE UPDATE ON notification_preferences FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();


--
-- Name: pipeline_runs trigger_pipeline_runs_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE OR REPLACE TRIGGER trigger_pipeline_runs_updated_at BEFORE UPDATE ON pipeline_runs FOR EACH ROW EXECUTE FUNCTION update_pipeline_runs_updated_at();


--
-- Name: classification_rules update_classification_rules_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE OR REPLACE TRIGGER update_classification_rules_updated_at BEFORE UPDATE ON classification_rules FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();


--
-- Name: confluence_sync_state update_confluence_sync_state_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE OR REPLACE TRIGGER update_confluence_sync_state_updated_at BEFORE UPDATE ON confluence_sync_state FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();


--
-- Name: document_blocks update_document_blocks_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE OR REPLACE TRIGGER update_document_blocks_updated_at BEFORE UPDATE ON document_blocks FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();


--
-- Name: document_chunks update_document_chunks_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE OR REPLACE TRIGGER update_document_chunks_updated_at BEFORE UPDATE ON document_chunks FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();


--
-- Name: document_classification update_document_classification_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE OR REPLACE TRIGGER update_document_classification_updated_at BEFORE UPDATE ON document_classification FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();


--
-- Name: document_confluence update_document_confluence_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE OR REPLACE TRIGGER update_document_confluence_updated_at BEFORE UPDATE ON document_confluence FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();


--
-- Name: document_extraction update_document_extraction_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE OR REPLACE TRIGGER update_document_extraction_updated_at BEFORE UPDATE ON document_extraction FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();


--
-- Name: document_metrics update_document_metrics_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE OR REPLACE TRIGGER update_document_metrics_updated_at BEFORE UPDATE ON document_metrics FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();


--
-- Name: document_parse_result update_document_parse_result_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE OR REPLACE TRIGGER update_document_parse_result_updated_at BEFORE UPDATE ON document_parse_result FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();


--
-- Name: document_sharepoint update_document_sharepoint_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE OR REPLACE TRIGGER update_document_sharepoint_updated_at BEFORE UPDATE ON document_sharepoint FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();


--
-- Name: document update_document_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE OR REPLACE TRIGGER update_document_updated_at BEFORE UPDATE ON document FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();


--
-- Name: product_line update_product_line_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE OR REPLACE TRIGGER update_product_line_updated_at BEFORE UPDATE ON product_line FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();


--
-- Name: program_unified_metadata update_program_unified_metadata_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE OR REPLACE TRIGGER update_program_unified_metadata_updated_at BEFORE UPDATE ON program_unified_metadata FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();


--
-- Name: platform update_program_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE OR REPLACE TRIGGER update_program_updated_at BEFORE UPDATE ON platform FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();


--
-- Name: sharepoint_sync_state update_sharepoint_sync_state_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE OR REPLACE TRIGGER update_sharepoint_sync_state_updated_at BEFORE UPDATE ON sharepoint_sync_state FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();


--
-- Name: source_confluence update_source_confluence_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE OR REPLACE TRIGGER update_source_confluence_updated_at BEFORE UPDATE ON source_confluence FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();


--
-- Name: source_sharepoint update_source_sharepoint_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE OR REPLACE TRIGGER update_source_sharepoint_updated_at BEFORE UPDATE ON source_sharepoint FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();


--
-- Name: source update_source_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE OR REPLACE TRIGGER update_source_updated_at BEFORE UPDATE ON source FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();


--
-- Name: change_detection_run change_detection_run_base_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'change_detection_run_base_document_id_fkey' 
        AND connamespace = current_schema()::regnamespace
    ) THEN
        ALTER TABLE ONLY change_detection_run
            ADD CONSTRAINT change_detection_run_base_document_id_fkey FOREIGN KEY (base_document_id) REFERENCES document(id) ON DELETE CASCADE;
    END IF;
END $$;


--
-- Name: change_detection_run change_detection_run_target_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'change_detection_run_target_document_id_fkey' 
        AND connamespace = current_schema()::regnamespace
    ) THEN
        ALTER TABLE ONLY change_detection_run
            ADD CONSTRAINT change_detection_run_target_document_id_fkey FOREIGN KEY (target_document_id) REFERENCES document(id) ON DELETE CASCADE;
    END IF;
END $$;


--
-- Name: classification_rules classification_rules_doc_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'classification_rules_doc_type_id_fkey' 
        AND connamespace = current_schema()::regnamespace
    ) THEN
        ALTER TABLE ONLY classification_rules
            ADD CONSTRAINT classification_rules_doc_type_id_fkey FOREIGN KEY (doc_type_id) REFERENCES document_types(id) ON DELETE CASCADE;
    END IF;
END $$;


--
-- Name: confluence_sync_state confluence_sync_state_source_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'confluence_sync_state_source_id_fkey' 
        AND connamespace = current_schema()::regnamespace
    ) THEN
        ALTER TABLE ONLY confluence_sync_state
            ADD CONSTRAINT confluence_sync_state_source_id_fkey FOREIGN KEY (source_id) REFERENCES source_confluence(source_id) ON DELETE CASCADE;
    END IF;
END $$;


--
-- Name: document_block_groups document_block_groups_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'document_block_groups_document_id_fkey' 
        AND connamespace = current_schema()::regnamespace
    ) THEN
        ALTER TABLE ONLY document_block_groups
            ADD CONSTRAINT document_block_groups_document_id_fkey FOREIGN KEY (document_id) REFERENCES document(id) ON DELETE CASCADE;
    END IF;
END $$;


--
-- Name: document_blocks document_chunks_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'document_chunks_document_id_fkey' 
        AND connamespace = current_schema()::regnamespace
    ) THEN
        ALTER TABLE ONLY document_blocks
            ADD CONSTRAINT document_chunks_document_id_fkey FOREIGN KEY (document_id) REFERENCES document(id) ON DELETE CASCADE;
    END IF;
END $$;


--
-- Name: document_chunks document_chunks_document_id_fkey1; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'document_chunks_document_id_fkey1' 
        AND connamespace = current_schema()::regnamespace
    ) THEN
        ALTER TABLE ONLY document_chunks
            ADD CONSTRAINT document_chunks_document_id_fkey1 FOREIGN KEY (document_id) REFERENCES document(id) ON DELETE CASCADE;
    END IF;
END $$;


--
-- Name: document_classification document_classification_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'document_classification_document_id_fkey' 
        AND connamespace = current_schema()::regnamespace
    ) THEN
        ALTER TABLE ONLY document_classification
            ADD CONSTRAINT document_classification_document_id_fkey FOREIGN KEY (document_id) REFERENCES document(id) ON DELETE CASCADE;
    END IF;
END $$;


--
-- Name: document_confluence document_confluence_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'document_confluence_document_id_fkey' 
        AND connamespace = current_schema()::regnamespace
    ) THEN
        ALTER TABLE ONLY document_confluence
            ADD CONSTRAINT document_confluence_document_id_fkey FOREIGN KEY (document_id) REFERENCES document(id) ON DELETE CASCADE;
    END IF;
END $$;


--
-- Name: document_extraction document_extraction_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'document_extraction_document_id_fkey' 
        AND connamespace = current_schema()::regnamespace
    ) THEN
        ALTER TABLE ONLY document_extraction
            ADD CONSTRAINT document_extraction_document_id_fkey FOREIGN KEY (document_id) REFERENCES document(id) ON DELETE CASCADE;
    END IF;
END $$;


--
-- Name: document_extraction document_extraction_schema_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'document_extraction_schema_id_fkey' 
        AND connamespace = current_schema()::regnamespace
    ) THEN
        ALTER TABLE ONLY document_extraction
            ADD CONSTRAINT document_extraction_schema_id_fkey FOREIGN KEY (schema_id) REFERENCES document_types(id);
    END IF;
END $$;


--
-- Name: document_jira document_jira_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'document_jira_document_id_fkey' 
        AND connamespace = current_schema()::regnamespace
    ) THEN
        ALTER TABLE ONLY document_jira
            ADD CONSTRAINT document_jira_document_id_fkey FOREIGN KEY (document_id) REFERENCES document(id) ON DELETE CASCADE;
    END IF;
END $$;


--
-- Name: document_metadata document_metadata_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'document_metadata_document_id_fkey' 
        AND connamespace = current_schema()::regnamespace
    ) THEN
        ALTER TABLE ONLY document_metadata
            ADD CONSTRAINT document_metadata_document_id_fkey FOREIGN KEY (document_id) REFERENCES document(id) ON DELETE CASCADE;
    END IF;
END $$;


--
-- Name: document_metrics document_metrics_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'document_metrics_document_id_fkey' 
        AND connamespace = current_schema()::regnamespace
    ) THEN
        ALTER TABLE ONLY document_metrics
            ADD CONSTRAINT document_metrics_document_id_fkey FOREIGN KEY (document_id) REFERENCES document(id) ON DELETE CASCADE;
    END IF;
END $$;


--
-- Name: document_parse_result document_parse_result_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'document_parse_result_document_id_fkey' 
        AND connamespace = current_schema()::regnamespace
    ) THEN
        ALTER TABLE ONLY document_parse_result
            ADD CONSTRAINT document_parse_result_document_id_fkey FOREIGN KEY (document_id) REFERENCES document(id) ON DELETE CASCADE;
    END IF;
END $$;


--
-- Name: document_parse_result document_parse_result_processing_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'document_parse_result_processing_run_id_fkey' 
        AND connamespace = current_schema()::regnamespace
    ) THEN
        ALTER TABLE ONLY document_parse_result
            ADD CONSTRAINT document_parse_result_processing_run_id_fkey FOREIGN KEY (processing_run_id) REFERENCES processing_runs(id) ON DELETE SET NULL;
    END IF;
END $$;


--
-- Name: document_sharepoint document_sharepoint_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'document_sharepoint_document_id_fkey' 
        AND connamespace = current_schema()::regnamespace
    ) THEN
        ALTER TABLE ONLY document_sharepoint
            ADD CONSTRAINT document_sharepoint_document_id_fkey FOREIGN KEY (document_id) REFERENCES document(id) ON DELETE CASCADE;
    END IF;
END $$;


--
-- Name: document document_source_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'document_source_id_fkey' 
        AND connamespace = current_schema()::regnamespace
    ) THEN
        ALTER TABLE ONLY document
            ADD CONSTRAINT document_source_id_fkey FOREIGN KEY (source_id) REFERENCES source(id) ON DELETE CASCADE;
    END IF;
END $$;


--
-- Name: document_validation document_validation_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'document_validation_document_id_fkey' 
        AND connamespace = current_schema()::regnamespace
    ) THEN
        ALTER TABLE ONLY document_validation
            ADD CONSTRAINT document_validation_document_id_fkey FOREIGN KEY (document_id) REFERENCES document(id) ON DELETE CASCADE;
    END IF;
END $$;


--
-- Name: change_detection_run fk_change_detection_run_platform_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'fk_change_detection_run_platform_id' 
        AND connamespace = current_schema()::regnamespace
    ) THEN
        ALTER TABLE ONLY change_detection_run
            ADD CONSTRAINT fk_change_detection_run_platform_id FOREIGN KEY (platform_id) REFERENCES platform(id) ON DELETE CASCADE;
    END IF;
END $$;


--
-- Name: change_detection_run fk_change_detection_run_regrello_workflow_template_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'fk_change_detection_run_regrello_workflow_template_id' 
        AND connamespace = current_schema()::regnamespace
    ) THEN
        ALTER TABLE ONLY change_detection_run
            ADD CONSTRAINT fk_change_detection_run_regrello_workflow_template_id FOREIGN KEY (regrello_workflow_template_id) REFERENCES regrello_workflow_template(id) ON DELETE SET NULL;
    END IF;
END $$;


--
-- Name: chat_logs fk_chat_logs_platform_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'fk_chat_logs_platform_id' 
        AND connamespace = current_schema()::regnamespace
    ) THEN
        ALTER TABLE ONLY chat_logs
            ADD CONSTRAINT fk_chat_logs_platform_id FOREIGN KEY (platform_id) REFERENCES platform(id) ON DELETE SET NULL;
    END IF;
END $$;


--
-- Name: document fk_document_platform_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'fk_document_platform_id' 
        AND connamespace = current_schema()::regnamespace
    ) THEN
        ALTER TABLE ONLY document
            ADD CONSTRAINT fk_document_platform_id FOREIGN KEY (platform_id) REFERENCES platform(id) ON DELETE CASCADE;
    END IF;
END $$;


--
-- Name: document_sharepoint fk_document_sharepoint_platform_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'fk_document_sharepoint_platform_id' 
        AND connamespace = current_schema()::regnamespace
    ) THEN
        ALTER TABLE ONLY document_sharepoint
            ADD CONSTRAINT fk_document_sharepoint_platform_id FOREIGN KEY (platform_id) REFERENCES platform(id) ON DELETE CASCADE;
    END IF;
END $$;


--
-- Name: document_validation fk_document_validation_regrello_workflow_template_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'fk_document_validation_regrello_workflow_template_id' 
        AND connamespace = current_schema()::regnamespace
    ) THEN
        ALTER TABLE ONLY document_validation
            ADD CONSTRAINT fk_document_validation_regrello_workflow_template_id FOREIGN KEY (regrello_workflow_template_id) REFERENCES regrello_workflow_template(id) ON DELETE SET NULL;
    END IF;
END $$;


--
-- Name: notification_preferences fk_notification_preferences_platform_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'fk_notification_preferences_platform_id' 
        AND connamespace = current_schema()::regnamespace
    ) THEN
        ALTER TABLE ONLY notification_preferences
            ADD CONSTRAINT fk_notification_preferences_platform_id FOREIGN KEY (platform_id) REFERENCES platform(id) ON DELETE CASCADE;
    END IF;
END $$;


--
-- Name: platform_name_catalog fk_platform_catalog_program; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'fk_platform_catalog_program' 
        AND connamespace = current_schema()::regnamespace
    ) THEN
        ALTER TABLE ONLY platform_name_catalog
            ADD CONSTRAINT fk_platform_catalog_program FOREIGN KEY (program_name) REFERENCES program_name_catalog(name);
    END IF;
END $$;


--
-- Name: platform_jira_project fk_platform_jira_project_platform_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'fk_platform_jira_project_platform_id' 
        AND connamespace = current_schema()::regnamespace
    ) THEN
        ALTER TABLE ONLY platform_jira_project
            ADD CONSTRAINT fk_platform_jira_project_platform_id FOREIGN KEY (platform_id) REFERENCES platform(id) ON DELETE CASCADE;
    END IF;
END $$;


--
-- Name: platform fk_platform_name_catalog; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'fk_platform_name_catalog' 
        AND connamespace = current_schema()::regnamespace
    ) THEN
        ALTER TABLE ONLY platform
            ADD CONSTRAINT fk_platform_name_catalog FOREIGN KEY (platform_name) REFERENCES platform_name_catalog(name);
    END IF;
END $$;


--
-- Name: platform fk_platform_program_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'fk_platform_program_id' 
        AND connamespace = current_schema()::regnamespace
    ) THEN
        ALTER TABLE ONLY platform
            ADD CONSTRAINT fk_platform_program_id FOREIGN KEY (program_id) REFERENCES program(id) ON DELETE CASCADE;
    END IF;
END $$;


--
-- Name: plm_platform fk_plm_platform_platform_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'fk_plm_platform_platform_id' 
        AND connamespace = current_schema()::regnamespace
    ) THEN
        ALTER TABLE ONLY plm_platform
            ADD CONSTRAINT fk_plm_platform_platform_id FOREIGN KEY (platform_id) REFERENCES platform(id) ON DELETE CASCADE;
    END IF;
END $$;


--
-- Name: program fk_program_name_catalog; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'fk_program_name_catalog' 
        AND connamespace = current_schema()::regnamespace
    ) THEN
        ALTER TABLE ONLY program
            ADD CONSTRAINT fk_program_name_catalog FOREIGN KEY (name) REFERENCES program_name_catalog(name);
    END IF;
END $$;


--
-- Name: source_iomete fk_source_iomete_platform_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'fk_source_iomete_platform_id' 
        AND connamespace = current_schema()::regnamespace
    ) THEN
        ALTER TABLE ONLY source_iomete
            ADD CONSTRAINT fk_source_iomete_platform_id FOREIGN KEY (platform_id) REFERENCES platform(id) ON DELETE CASCADE;
    END IF;
END $$;


--
-- Name: source fk_source_platform_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'fk_source_platform_id' 
        AND connamespace = current_schema()::regnamespace
    ) THEN
        ALTER TABLE ONLY source
            ADD CONSTRAINT fk_source_platform_id FOREIGN KEY (platform_id) REFERENCES platform(id) ON DELETE CASCADE;
    END IF;
END $$;


--
-- Name: user_platform_access fk_user_platform_access_platform_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'fk_user_platform_access_platform_id' 
        AND connamespace = current_schema()::regnamespace
    ) THEN
        ALTER TABLE ONLY user_platform_access
            ADD CONSTRAINT fk_user_platform_access_platform_id FOREIGN KEY (platform_id) REFERENCES platform(id) ON DELETE CASCADE;
    END IF;
END $$;


--
-- Name: ingestion_runs ingestion_runs_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'ingestion_runs_document_id_fkey' 
        AND connamespace = current_schema()::regnamespace
    ) THEN
        ALTER TABLE ONLY ingestion_runs
            ADD CONSTRAINT ingestion_runs_document_id_fkey FOREIGN KEY (document_id) REFERENCES document(id) ON DELETE CASCADE;
    END IF;
END $$;


--
-- Name: jira_comment jira_comment_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'jira_comment_document_id_fkey' 
        AND connamespace = current_schema()::regnamespace
    ) THEN
        ALTER TABLE ONLY jira_comment
            ADD CONSTRAINT jira_comment_document_id_fkey FOREIGN KEY (document_id) REFERENCES document_jira(document_id) ON DELETE CASCADE;
    END IF;
END $$;


--
-- Name: jira_issue_history jira_issue_history_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'jira_issue_history_document_id_fkey' 
        AND connamespace = current_schema()::regnamespace
    ) THEN
        ALTER TABLE ONLY jira_issue_history
            ADD CONSTRAINT jira_issue_history_document_id_fkey FOREIGN KEY (document_id) REFERENCES document_jira(document_id) ON DELETE CASCADE;
    END IF;
END $$;


--
-- Name: jira_sync_state jira_sync_state_source_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'jira_sync_state_source_id_fkey' 
        AND connamespace = current_schema()::regnamespace
    ) THEN
        ALTER TABLE ONLY jira_sync_state
            ADD CONSTRAINT jira_sync_state_source_id_fkey FOREIGN KEY (source_id) REFERENCES source_jira(source_id) ON DELETE CASCADE;
    END IF;
END $$;


--
-- Name: llm_calls llm_calls_chat_log_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'llm_calls_chat_log_id_fkey' 
        AND connamespace = current_schema()::regnamespace
    ) THEN
        ALTER TABLE ONLY llm_calls
            ADD CONSTRAINT llm_calls_chat_log_id_fkey FOREIGN KEY (chat_log_id) REFERENCES chat_logs(id) ON DELETE CASCADE;
    END IF;
END $$;


--
-- Name: plm_platform_bom plm_platform_bom_plm_platform_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'plm_platform_bom_plm_platform_id_fkey' 
        AND connamespace = current_schema()::regnamespace
    ) THEN
        ALTER TABLE ONLY plm_platform_bom
            ADD CONSTRAINT plm_platform_bom_plm_platform_id_fkey FOREIGN KEY (plm_platform_id) REFERENCES plm_platform(id) ON DELETE CASCADE;
    END IF;
END $$;


--
-- Name: processing_runs processing_runs_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'processing_runs_document_id_fkey' 
        AND connamespace = current_schema()::regnamespace
    ) THEN
        ALTER TABLE ONLY processing_runs
            ADD CONSTRAINT processing_runs_document_id_fkey FOREIGN KEY (document_id) REFERENCES document(id) ON DELETE CASCADE;
    END IF;
END $$;


--
-- Name: product_line product_line_program_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'product_line_program_id_fkey' 
        AND connamespace = current_schema()::regnamespace
    ) THEN
        ALTER TABLE ONLY product_line
            ADD CONSTRAINT product_line_program_id_fkey FOREIGN KEY (program_id) REFERENCES platform(id) ON DELETE CASCADE;
    END IF;
END $$;


--
-- Name: platform_jira_project program_jira_project_jira_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'program_jira_project_jira_project_id_fkey' 
        AND connamespace = current_schema()::regnamespace
    ) THEN
        ALTER TABLE ONLY platform_jira_project
            ADD CONSTRAINT program_jira_project_jira_project_id_fkey FOREIGN KEY (jira_project_id) REFERENCES jira_project(id);
    END IF;
END $$;


--
-- Name: platform_jira_project program_jira_project_source_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'program_jira_project_source_id_fkey' 
        AND connamespace = current_schema()::regnamespace
    ) THEN
        ALTER TABLE ONLY platform_jira_project
            ADD CONSTRAINT program_jira_project_source_id_fkey FOREIGN KEY (source_id) REFERENCES source(id) ON DELETE SET NULL;
    END IF;
END $$;


--
-- Name: program_member program_member_program_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'program_member_program_id_fkey' 
        AND connamespace = current_schema()::regnamespace
    ) THEN
        ALTER TABLE ONLY program_member
            ADD CONSTRAINT program_member_program_id_fkey FOREIGN KEY (program_id) REFERENCES platform(id) ON DELETE CASCADE;
    END IF;
END $$;


--
-- Name: program_unified_metadata program_unified_metadata_program_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'program_unified_metadata_program_id_fkey' 
        AND connamespace = current_schema()::regnamespace
    ) THEN
        ALTER TABLE ONLY program_unified_metadata
            ADD CONSTRAINT program_unified_metadata_program_id_fkey FOREIGN KEY (program_id) REFERENCES platform(id) ON DELETE CASCADE;
    END IF;
END $$;


--
-- Name: program_unified_metadata program_unified_metadata_source_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'program_unified_metadata_source_document_id_fkey' 
        AND connamespace = current_schema()::regnamespace
    ) THEN
        ALTER TABLE ONLY program_unified_metadata
            ADD CONSTRAINT program_unified_metadata_source_document_id_fkey FOREIGN KEY (source_document_id) REFERENCES document(id) ON DELETE CASCADE;
    END IF;
END $$;


--
-- Name: service_account service_account_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'service_account_created_by_fkey' 
        AND connamespace = current_schema()::regnamespace
    ) THEN
        ALTER TABLE ONLY service_account
            ADD CONSTRAINT service_account_created_by_fkey FOREIGN KEY (created_by) REFERENCES app_user(id) ON DELETE SET NULL;
    END IF;
END $$;


--
-- Name: service_account_platform_access service_account_platform_access_platform_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'service_account_platform_access_platform_id_fkey' 
        AND connamespace = current_schema()::regnamespace
    ) THEN
        ALTER TABLE ONLY service_account_platform_access
            ADD CONSTRAINT service_account_platform_access_platform_id_fkey FOREIGN KEY (platform_id) REFERENCES platform(id) ON DELETE CASCADE;
    END IF;
END $$;


--
-- Name: service_account_platform_access service_account_program_access_service_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'service_account_program_access_service_account_id_fkey' 
        AND connamespace = current_schema()::regnamespace
    ) THEN
        ALTER TABLE ONLY service_account_platform_access
            ADD CONSTRAINT service_account_program_access_service_account_id_fkey FOREIGN KEY (service_account_id) REFERENCES service_account(id) ON DELETE CASCADE;
    END IF;
END $$;


--
-- Name: sharepoint_sync_state sharepoint_sync_state_source_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'sharepoint_sync_state_source_id_fkey' 
        AND connamespace = current_schema()::regnamespace
    ) THEN
        ALTER TABLE ONLY sharepoint_sync_state
            ADD CONSTRAINT sharepoint_sync_state_source_id_fkey FOREIGN KEY (source_id) REFERENCES source_sharepoint(source_id) ON DELETE CASCADE;
    END IF;
END $$;


--
-- Name: source_confluence source_confluence_source_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'source_confluence_source_id_fkey' 
        AND connamespace = current_schema()::regnamespace
    ) THEN
        ALTER TABLE ONLY source_confluence
            ADD CONSTRAINT source_confluence_source_id_fkey FOREIGN KEY (source_id) REFERENCES source(id) ON DELETE CASCADE;
    END IF;
END $$;


--
-- Name: source_jira source_jira_source_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'source_jira_source_id_fkey' 
        AND connamespace = current_schema()::regnamespace
    ) THEN
        ALTER TABLE ONLY source_jira
            ADD CONSTRAINT source_jira_source_id_fkey FOREIGN KEY (source_id) REFERENCES source(id) ON DELETE CASCADE;
    END IF;
END $$;


--
-- Name: source_sharepoint source_sharepoint_source_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'source_sharepoint_source_id_fkey' 
        AND connamespace = current_schema()::regnamespace
    ) THEN
        ALTER TABLE ONLY source_sharepoint
            ADD CONSTRAINT source_sharepoint_source_id_fkey FOREIGN KEY (source_id) REFERENCES source(id) ON DELETE CASCADE;
    END IF;
END $$;


--
-- Name: user_platform_access user_program_access_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'user_program_access_user_id_fkey' 
        AND connamespace = current_schema()::regnamespace
    ) THEN
        ALTER TABLE ONLY user_platform_access
            ADD CONSTRAINT user_program_access_user_id_fkey FOREIGN KEY (user_id) REFERENCES app_user(id) ON DELETE CASCADE;
    END IF;
END $$;


--
-- PostgreSQL database dump complete
--

\unrestrict fBpAoqimuH4ExTSyqhSIaKypaheBM6D06v1RdcxuycLGDhRqDjzjT0BYXHBE78Z

