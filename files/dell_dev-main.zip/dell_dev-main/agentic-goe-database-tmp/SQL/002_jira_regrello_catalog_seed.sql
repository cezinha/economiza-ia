-- Reference seed data for NUDDs filter catalog hierarchy (SCAIF-1179).
-- Prerequisite: SQL/001_jira_regrello_schema.sql
-- Next: SQL/003_nudd_filter_views.sql (optional), SQL/004_jira_regrello_sample_data.sql (dev)

INSERT INTO catalog_organization (code, name, sort_order) VALUES
  ('CSG', 'Client Solutions Group', 1),
  ('ISG', 'Infrastructure Solutions Group', 2)
ON CONFLICT (code) DO NOTHING;

INSERT INTO catalog_lob (organization_id, code, name, sort_order)
SELECT o.id, v.code, v.name, v.sort_order
FROM catalog_organization o
CROSS JOIN (VALUES
  ('CSG', 'DT', 'Desktop', 1),
  ('CSG', 'NB', 'Notebook', 2),
  ('CSG', 'DnCP', 'DnCP', 3),
  ('ISG', 'Server', 'Server', 4),
  ('ISG', 'Rugged', 'Rugged', 5)
) AS v(org_code, code, name, sort_order)
WHERE o.code = v.org_code
ON CONFLICT (code) DO NOTHING;

INSERT INTO catalog_function (code, name, sort_order) VALUES
  ('GOE', 'GOE', 1),
  ('NPI', 'NPI', 2),
  ('SChM', 'SChM', 3)
ON CONFLICT (code) DO NOTHING;

INSERT INTO catalog_phase (function_id, name, sort_order)
SELECT f.id, v.name, v.sort_order
FROM catalog_function f
CROSS JOIN (VALUES
  ('GOE', 'Pre-Ideate', 1),
  ('GOE', 'Concept', 2),
  ('GOE', 'Define', 3),
  ('GOE', 'Plan', 4),
  ('GOE', 'Qual', 5),
  ('GOE', 'Ramp', 6),
  ('GOE', 'Pilot', 7),
  ('GOE', 'Incubate', 8),
  ('GOE', 'Develop', 9),
  ('GOE', 'Launch', 10),
  ('NPI', 'Concept', 1),
  ('NPI', 'Define', 2),
  ('NPI', 'Plan', 3),
  ('SChM', 'Concept', 1),
  ('SChM', 'Define', 2)
) AS v(func_code, name, sort_order)
WHERE f.code = v.func_code
ON CONFLICT (function_id, name) DO NOTHING;

INSERT INTO catalog_nudd_task (phase_id, name, sort_order)
SELECT p.id, v.name, v.sort_order
FROM catalog_phase p
JOIN catalog_function f ON f.id = p.function_id
CROSS JOIN (VALUES
  ('GOE', 'Plan', 'RTS Metrics Review', 1),
  ('GOE', 'Plan', 'Platform Readiness Check', 2),
  ('GOE', 'Develop', 'Launch Gate Review', 1)
) AS v(func_code, phase_name, name, sort_order)
WHERE f.code = v.func_code AND p.name = v.phase_name
ON CONFLICT (phase_id, name) DO NOTHING;
