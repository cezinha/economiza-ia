-- Read-only views for SCAIF-1179 filter-options cascade queries.
-- Prerequisite: SQL/001_jira_regrello_schema.sql, SQL/002_jira_regrello_catalog_seed.sql
-- Platform rows (with catalog_lob_id) required for v_filter_org_branch; load via SQL/004_jira_regrello_sample_data.sql
-- See README.md § NUDDs filter SQL

CREATE OR REPLACE VIEW v_filter_org_branch AS
SELECT
  o.id AS organization_id,
  o.code AS organization_code,
  o.name AS organization_name,
  l.id AS lob_id,
  l.code AS lob_code,
  l.name AS lob_name,
  p.id AS platform_id,
  p.platform_name,
  p.line_of_business
FROM catalog_organization o
JOIN catalog_lob l ON l.organization_id = o.id AND l.is_active
JOIN jira_platform p ON p.catalog_lob_id = l.id
WHERE o.is_active;

CREATE OR REPLACE VIEW v_filter_function_branch AS
SELECT
  f.id AS function_id,
  f.code AS function_code,
  f.name AS function_name,
  ph.id AS phase_id,
  ph.name AS phase_name,
  t.id AS task_id,
  t.name AS task_name
FROM catalog_function f
JOIN catalog_phase ph ON ph.function_id = f.id AND ph.is_active
JOIN catalog_nudd_task t ON t.phase_id = ph.id AND t.is_active
WHERE f.is_active;
