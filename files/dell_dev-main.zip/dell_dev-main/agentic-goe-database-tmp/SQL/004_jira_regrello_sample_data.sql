-- Sample / dev data for NUDDs API testing (SCAIF-1178/1179/1182).
-- Prerequisite: SQL/001, SQL/002, SQL/003
-- Inspired by REF/001_agentic_goe_reference_data.sql (jira_project keys, platform_name_catalog names).
-- Idempotent: safe to re-run.
--
-- Enrichment join (SCAIF-1178):
--   SELECT n.*, pi.*
--   FROM jira_nudd n
--   LEFT JOIN jira_platform p ON p.id = n.impacted_jira_platform_id
--   LEFT JOIN jira_platform_information pi ON pi.jira_platform_id = p.id;

-- ─── Assignees ─────────────────────────────────────────────────

INSERT INTO assignee (email, display_name, jira_account_id) VALUES
  ('jane.doe@dell.com', 'Jane Doe', 'jane.doe'),
  ('john.smith@dell.com', 'John Smith', 'john.smith'),
  ('alex.chen@dell.com', 'Alex Chen', 'alex.chen')
ON CONFLICT (email) DO NOTHING;

-- ─── Jira projects (from REF: GOEQ, GRIT, CPDM) ───────────────

INSERT INTO jira_project (
  project_key, project_name, instance_url, available_issue_types,
  platform_filter_field, platform_filter_type, instance_name, additional_filter_fields
) VALUES
  (
    'GOEQ', 'GOE Quality', 'https://jira.gtie.dell.com',
    '["NUDD"]'::jsonb, 'Impacted Platform/s', 'option', 'GTIE', '[]'::jsonb
  ),
  (
    'GRIT', 'GRIT Platform Tracking', 'https://jira.cpg.dell.com',
    '["NUDD"]'::jsonb, 'Affected Platform(s)_Text', 'text', 'CPG', '[]'::jsonb
  ),
  (
    'CPDM', 'Core Product Definition Management', 'https://jira.cpg.dell.com',
    '["NUDD"]'::jsonb, 'Program Platform(s)', 'option', 'CPG', '[]'::jsonb
  )
ON CONFLICT (project_key) DO NOTHING;

-- ─── Platforms (names from REF platform_name_catalog) ──────────

INSERT INTO jira_platform (
  platform_id, platform_name, catalog_lob_id, line_of_business,
  jira_issue_key, jira_issue_id, program_name, status
)
SELECT v.platform_id, v.platform_name, l.id, l.code, v.jira_issue_key, v.jira_issue_id, v.program_name, 'Active'
FROM catalog_lob l
CROSS JOIN (VALUES
  ('PLT-PERF-N1', 'Performante N1', 'NB', 'GOE-1001', '10001', 'Performante'),
  ('PLT-FOX-14', 'Foxtrot 14', 'DT', 'GOE-1002', '10002', 'CY26 Foxtrot 14 & Delta 3-7'),
  ('PLT-ZAN-1U', 'Zanzibar', 'Server', 'GOE-1003', '10003', 'CY26 Zanzibar 1U'),
  ('PLT-CIT-NVL', 'Citadel NVL', 'Server', 'GOE-1004', '10004', 'Citadel NVL')
) AS v(platform_id, platform_name, lob_code, jira_issue_key, jira_issue_id, program_name)
WHERE l.code = v.lob_code
  AND NOT EXISTS (SELECT 1 FROM jira_platform p WHERE p.platform_id = v.platform_id);

-- ─── Platform information ──────────────────────────────────────

INSERT INTO jira_platform_information (
  jira_platform_id, domain_business, program_phase, program_state,
  program_category, program_class, tier, cpu_architecture, form_factor,
  program_manager, product_manager, rts_calendar_year, rts_calendar_quarter,
  plan_exit_target, develop_exit_target, lob_code
)
SELECT p.id, v.domain_business, v.program_phase::platform_phase, v.program_state::platform_state,
  v.program_category, v.program_class, v.tier, v.cpu_architecture, v.form_factor,
  v.program_manager, v.product_manager, v.rts_year, v.rts_quarter,
  v.plan_exit_target::date, v.develop_exit_target::date, v.lob_code::platform_lob
FROM jira_platform p
CROSS JOIN (VALUES
  ('PLT-PERF-N1', 'Commercial NB', 'Plan', 'Active', 'Premium', 'Class A', 'Tier 1', 'Intel', 'Clamshell', 'Jane Doe', 'John Smith', '2026', 'Q3', '2026-09-30', '2026-12-15', 'NB'),
  ('PLT-FOX-14', 'Commercial DT', 'Develop', 'Active', 'Mainstream', 'Class B', 'Tier 2', 'Intel', 'Tower', 'Alex Chen', 'Jane Doe', '2026', 'Q4', '2026-06-30', '2027-03-31', 'DT'),
  ('PLT-ZAN-1U', 'Enterprise Server', 'Launch', 'Active', 'Hyperscale', 'Class A', 'Tier 1', 'AMD', '1U Rack', 'John Smith', 'Alex Chen', '2026', 'Q2', '2026-04-30', '2026-08-31', 'Server'),
  ('PLT-CIT-NVL', 'AI Infrastructure', 'Qual', 'Active', 'AI/ML', 'Class A', 'Tier 1', 'NVIDIA', '4U Rack', 'Jane Doe', 'Alex Chen', '2026', 'Q1', '2026-02-28', '2026-05-31', 'Server')
) AS v(platform_id, domain_business, program_phase, program_state, program_category, program_class,
       tier, cpu_architecture, form_factor, program_manager, product_manager,
       rts_year, rts_quarter, plan_exit_target, develop_exit_target, lob_code)
WHERE p.platform_id = v.platform_id
  AND NOT EXISTS (
    SELECT 1 FROM jira_platform_information pi WHERE pi.jira_platform_id = p.id
  );

-- ─── Platform ↔ project links ──────────────────────────────────

INSERT INTO jira_platform_project (jira_platform_id, jira_project_id, enabled_issue_types)
SELECT p.id, jp.id, '["NUDD"]'::jsonb
FROM jira_platform p
JOIN jira_project jp ON jp.project_key = 'GOEQ'
WHERE p.platform_id IN ('PLT-PERF-N1', 'PLT-FOX-14', 'PLT-ZAN-1U')
ON CONFLICT (jira_platform_id, jira_project_id) DO NOTHING;

INSERT INTO jira_platform_project (jira_platform_id, jira_project_id, enabled_issue_types)
SELECT p.id, jp.id, '["NUDD"]'::jsonb
FROM jira_platform p
JOIN jira_project jp ON jp.project_key = 'GRIT'
WHERE p.platform_id = 'PLT-CIT-NVL'
ON CONFLICT (jira_platform_id, jira_project_id) DO NOTHING;

-- ─── User platform access (SCAIF-1179) ─────────────────────────

INSERT INTO user_jira_platform_access (assignee_id, jira_platform_id)
SELECT a.id, p.id
FROM assignee a
JOIN jira_platform p ON p.platform_id IN ('PLT-PERF-N1', 'PLT-FOX-14')
WHERE a.email = 'jane.doe@dell.com'
ON CONFLICT (assignee_id, jira_platform_id) DO NOTHING;

INSERT INTO user_jira_platform_access (assignee_id, jira_platform_id)
SELECT a.id, p.id
FROM assignee a
JOIN jira_platform p ON p.platform_id IN ('PLT-ZAN-1U', 'PLT-CIT-NVL')
WHERE a.email = 'john.smith@dell.com'
ON CONFLICT (assignee_id, jira_platform_id) DO NOTHING;

INSERT INTO user_jira_platform_access (assignee_id, jira_platform_id)
SELECT a.id, p.id
FROM assignee a
CROSS JOIN jira_platform p
WHERE a.email = 'alex.chen@dell.com'
ON CONFLICT (assignee_id, jira_platform_id) DO NOTHING;

-- ─── NUDD issues ───────────────────────────────────────────────

INSERT INTO jira_nudd (
  jira_issue_id, jira_issue_key, jira_project_id, summary, status,
  nudd_type, impact, probability, risk_score, risk_band,
  catalog_lob_id, impacted_platform_name, impacted_jira_platform_id,
  catalog_nudd_task_id, assignee_id, reporter_id, labels,
  jira_created_at, jira_updated_at, close_date
)
SELECT
  v.jira_issue_id,
  v.jira_issue_key,
  jp.id,
  v.summary,
  v.status::nudd_status,
  v.nudd_type,
  v.impact,
  v.probability,
  v.impact * v.probability,
  v.risk_band,
  lob.id,
  p.platform_name,
  p.id,
  t.id,
  assignee_a.id,
  reporter_a.id,
  v.labels::jsonb,
  v.jira_created_at::timestamp,
  v.jira_updated_at::timestamp,
  v.close_date::timestamp
FROM (VALUES
  ('GOEQ-5001', 'GOEQ-5001', 'GOEQ', 'RTS metrics gap on Performante N1', 'Open', 'RTS Metrics', 3, 3, 'high', 'PLT-PERF-N1', 'NB', 'GOE', 'Plan', 'RTS Metrics Review', 'jane.doe@dell.com', 'john.smith@dell.com', '["rts","nb"]', '2026-01-10 09:00:00', '2026-03-15 14:30:00', NULL),
  ('GOEQ-5002', 'GOEQ-5002', 'GOEQ', 'Platform readiness delay Foxtrot 14', 'In Progress', 'Platform Readiness', 2, 3, 'medium', 'PLT-FOX-14', 'DT', 'GOE', 'Plan', 'Platform Readiness Check', 'alex.chen@dell.com', 'jane.doe@dell.com', '["readiness"]', '2026-02-01 11:00:00', '2026-04-01 10:00:00', NULL),
  ('GOEQ-5003', 'GOEQ-5003', 'GOEQ', 'Launch gate review pending Zanzibar', 'On hold', 'Launch Gate', 2, 2, 'medium', 'PLT-ZAN-1U', 'Server', 'GOE', 'Develop', 'Launch Gate Review', 'john.smith@dell.com', 'alex.chen@dell.com', '[]', '2025-11-20 08:00:00', '2026-01-05 16:00:00', NULL),
  ('GRIT-3001', 'GRIT-3001', 'GRIT', 'Citadel NVL thermal risk', 'Open', 'Thermal', 3, 2, 'medium', 'PLT-CIT-NVL', 'Server', 'GOE', 'Develop', 'Launch Gate Review', 'jane.doe@dell.com', 'john.smith@dell.com', '["thermal","ai"]', '2026-03-01 12:00:00', '2026-05-10 09:00:00', NULL),
  ('CPDM-2001', 'CPDM-2001', 'CPDM', 'Completed NUDD - documentation closure', 'Completed', 'Documentation', 1, 1, 'low', 'PLT-PERF-N1', 'NB', 'GOE', 'Plan', 'RTS Metrics Review', 'alex.chen@dell.com', 'jane.doe@dell.com', '[]', '2025-08-01 10:00:00', '2025-12-15 17:00:00', '2025-12-15 17:00:00'),
  ('GOEQ-5004', 'GOEQ-5004', 'GOEQ', 'Scoping supply chain impact NB', 'In Scoping', 'Supply Chain', 2, 1, 'low', 'PLT-PERF-N1', 'NB', 'GOE', 'Plan', 'Platform Readiness Check', 'john.smith@dell.com', 'alex.chen@dell.com', '["supply"]', '2026-04-20 09:30:00', '2026-05-01 11:00:00', NULL),
  ('GOEQ-5005', 'GOEQ-5005', 'GOEQ', 'High risk cross-platform dependency', 'Open', 'Dependency', 3, 3, 'high', 'PLT-FOX-14', 'DT', 'GOE', 'Plan', 'RTS Metrics Review', 'jane.doe@dell.com', 'jane.doe@dell.com', '["dependency","critical"]', '2026-05-01 08:00:00', '2026-05-18 15:00:00', NULL)
) AS v(
  jira_issue_id, jira_issue_key, project_key, summary, status, nudd_type,
  impact, probability, risk_band, platform_id, lob_code, func_code, phase_name, task_name,
  assignee_email, reporter_email, labels, jira_created_at, jira_updated_at, close_date
)
JOIN jira_project jp ON jp.project_key = v.project_key
JOIN jira_platform p ON p.platform_id = v.platform_id
JOIN catalog_lob lob ON lob.code = v.lob_code
JOIN catalog_function f ON f.code = v.func_code
JOIN catalog_phase ph ON ph.function_id = f.id AND ph.name = v.phase_name
JOIN catalog_nudd_task t ON t.phase_id = ph.id AND t.name = v.task_name
JOIN assignee assignee_a ON assignee_a.email = v.assignee_email
JOIN assignee reporter_a ON reporter_a.email = v.reporter_email
WHERE NOT EXISTS (SELECT 1 FROM jira_nudd n WHERE n.jira_issue_key = v.jira_issue_key);

-- ─── Optional: minimal sync hub demo ───────────────────────────

INSERT INTO jira_task (
  jira_platform_id, jira_id, jira_key, summary, issuetype_name, project_key, project_name
)
SELECT p.id, '20001', 'GOEQ-9001', 'Launch task for Performante N1', 'Task', 'GOEQ', 'GOE Quality'
FROM jira_platform p
WHERE p.platform_id = 'PLT-PERF-N1'
  AND NOT EXISTS (SELECT 1 FROM jira_task t WHERE t.jira_key = 'GOEQ-9001');

INSERT INTO sync_state (state, jira_synced_at, jira_updated_at)
SELECT 'JIRA_ONLY', now(), now()
WHERE NOT EXISTS (
  SELECT 1 FROM task t
  JOIN jira_task jt ON jt.id = t.jira_task_id
  WHERE jt.jira_key = 'GOEQ-9001'
);

INSERT INTO task (sync_state_id, jira_task_id)
SELECT ss.id, jt.id
FROM jira_task jt
CROSS JOIN LATERAL (
  SELECT id FROM sync_state
  WHERE state = 'JIRA_ONLY'
  ORDER BY id DESC
  LIMIT 1
) ss
WHERE jt.jira_key = 'GOEQ-9001'
  AND NOT EXISTS (SELECT 1 FROM task t WHERE t.jira_task_id = jt.id);
