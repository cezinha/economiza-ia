#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"

POSTGRES_USER="${POSTGRES_USER:-jira_regrello}"
POSTGRES_DB="${POSTGRES_DB:-jira_regrello}"
SKIP_SAMPLE=false

usage() {
  cat <<EOF
Usage: $(basename "$0") [OPTIONS]

Apply orchestrator SQL scripts in order (001 → 004) against the Docker Postgres service.

Options:
  --skip-sample   Skip SQL/004_jira_regrello_sample_data.sql
  -h, --help      Show this help

Environment (optional, see .env.example):
  POSTGRES_USER   Default: jira_regrello
  POSTGRES_DB     Default: jira_regrello
EOF
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --skip-sample)
      SKIP_SAMPLE=true
      shift
      ;;
    -h|--help)
      usage
      exit 0
      ;;
    *)
      echo "Unknown option: $1" >&2
      usage >&2
      exit 1
      ;;
  esac
done

if ! docker compose ps --status running --services 2>/dev/null | grep -qx postgres; then
  echo "Postgres container is not running. Start it with: docker compose up -d" >&2
  exit 1
fi

echo "Waiting for Postgres to be healthy..."
for _ in $(seq 1 30); do
  if docker compose exec -T postgres pg_isready -U "$POSTGRES_USER" -d "$POSTGRES_DB" >/dev/null 2>&1; then
    break
  fi
  sleep 1
done

if ! docker compose exec -T postgres pg_isready -U "$POSTGRES_USER" -d "$POSTGRES_DB" >/dev/null 2>&1; then
  echo "Postgres is not ready after 30s." >&2
  exit 1
fi

run_sql() {
  local file="$1"
  echo "Applying /sql/$(basename "$file") ..."
  docker compose exec -T postgres \
    psql -U "$POSTGRES_USER" -d "$POSTGRES_DB" -v ON_ERROR_STOP=1 -f "/sql/$(basename "$file")"
}

run_sql "001_jira_regrello_schema.sql"
run_sql "002_jira_regrello_catalog_seed.sql"
run_sql "003_nudd_filter_views.sql"

if [[ "$SKIP_SAMPLE" == false ]]; then
  run_sql "004_jira_regrello_sample_data.sql"
else
  echo "Skipping SQL/004_jira_regrello_sample_data.sql (--skip-sample)"
fi

echo "Done."
