# Regrello Connector Service

HTTP façade over the Regrello GraphQL API, built from the same layout as `agentic-goe-sharepoint-connector`.

The async Regrello client (`RegrelloClient`, `Settings`) is vendored in this repo under [`regrello/`](regrello/) (same source as `agentic-goe-regrello/src/regrello`). For workflow status and most GraphQL operations, use **`POST /regrello/graphql`** on this connector ([examples](docs/examples.md)); the client keeps typed helpers only where the connector orchestrates (e.g. document upload). Sibling demos under [`agentic-goe-regrello`](../agentic-goe-regrello) `examples/` may still call the library directly.

## Setup

```bash
cd agentic-goe-regrello-connector
uv sync --all-groups
```

### Virtual environment

`uv sync` / `uv sync --all-groups` manage an isolated environment implicitly; some teams still use an explicit venv:

```bash
python3 -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install --upgrade pip
pip install -e .
```

Dev tools are listed under `[dependency-groups]` in `pyproject.toml` (uv), not setuptools extras: with **uv**, use `uv sync --all-groups`; with **pip** only, install tests with `pip install pytest pytest-asyncio pytest-cov pytest-mock` (add `mypy` if you run type checks). Run the suite with `pytest` or `.venv/bin/pytest` (see [Tests](#tests)).

## Configuration

### Environment file

Start from the canonical template: [`.env.example`](.env.example).

```bash
cp .env.example .env
```

All variable names, placeholders, and per-parameter descriptions are `#` comments in that file (including the optional **Memory backend** block).

Settings are defined in [`app/config.py`](app/config.py) with **Pydantic Settings** (`BaseSettings`). On import, `Settings` loads `.env` automatically via `model_config.env_file`: it reads `Path.cwd() / ".env"` and `.env` next to `pyproject.toml` (connector root, derived from `app/config.py`) when each file exists. If both files define the same key, the connector-root `.env` wins (pydantic merges multiple `env_file` paths with later paths overriding earlier ones). Variables already set in the **process environment** still take precedence over values from `.env` files (standard pydantic-settings behavior). You do not need to call `load_dotenv()` for `Settings` itself.

Optional alternatives if you want variables in the shell or duplicated loading: `set -a && source .env && set +a`, **`uvicorn[standard]`**’s `uvicorn ... --env-file .env`, the `dotenv` CLI, IDE run configurations, Docker `--env-file`, or Kubernetes secrets.

### Parameter reference (grouping only)

| Area | What to configure |
|------|-------------------|
| Connector process | Service bind address/port, environment label, log level. |
| Backend mode | `http` (live Regrello) vs `memory` (JSON fixture file path). |
| Regrello API | OAuth and workspace settings when using `http`; not required for `memory` (see comments in [`.env.example`](.env.example)). |
| Regrello OAuth | `REGRELLO_TOKEN_VALIDATION_WINDOW`: safety margin in seconds before token expiry; default `60`. |
| Inbound OAuth | `REGRELLO_CONNECTOR_INBOUND_AUTH_ENABLED`, introspection URL/credentials, `REGRELLO_CONNECTOR_INBOUND_AUTH_SKIP_PATHS` (see [`.env.example`](.env.example)). |

### Inbound OAuth (caller → connector)

Separate from Regrello **outbound** OAuth (`REGRELLO_CLIENT_ID` / `REGRELLO_CLIENT_SECRET`):

- When `REGRELLO_CONNECTOR_INBOUND_AUTH_ENABLED=true`, protected routes require `Authorization: Bearer <token>` from your identity provider (the token the frontend received).
- The connector validates the token via **RFC 7662 introspection** (`REGRELLO_CONNECTOR_OAUTH_INTROSPECTION_*`); it does **not** forward that token to Regrello.
- Default skip paths: `/health`, `/metrics`, `/status` (configurable via `REGRELLO_CONNECTOR_INBOUND_AUTH_SKIP_PATHS`).
- Protected routes: `POST /regrello/graphql`, `POST /regrello/documents`.
- Disabled by default (`REGRELLO_CONNECTOR_INBOUND_AUTH_ENABLED=false`) for local development and tests.

### HTTP client and OAuth

When `REGRELLO_CONNECTOR_BACKEND=http` (default):

- The connector uses a **shared `RegrelloClient` singleton** per process, created at application startup and closed on shutdown.
- OAuth tokens are **cached in memory** and reused until `expires_in - REGRELLO_TOKEN_VALIDATION_WINDOW` seconds elapse, then refreshed automatically.
- Outbound Regrello HTTP calls **retry once** on transport errors (e.g. stale connections dropped by a firewall or NAT).
- With multiple uvicorn workers, each worker process maintains its own client instance and token cache.

### Memory backend

1. Set backend and fixture path as described in the **Memory backend** section of [`.env.example`](.env.example). The documented default is [`regrello_memory_minimal.json`](regrello_memory_minimal.json) at the project root (next to `pyproject.toml`). Pytest still loads the same JSON from [`tests/fixtures/regrello_memory_minimal.json`](tests/fixtures/regrello_memory_minimal.json).
2. Optionally adjust template id so fixture keys match (see comments in [`.env.example`](.env.example)).

Run from the connector directory:

```bash
cd agentic-goe-regrello-connector
export REGRELLO_CONNECTOR_BACKEND=memory
export REGRELLO_CONNECTOR_MEMORY_FIXTURES_PATH="$(pwd)/regrello_memory_minimal.json"
uvicorn app.main:app --host 0.0.0.0 --port 8005 --reload
```

Verify:

- `GET /status` — response includes `"backend": "memory"`.
- `POST /regrello/graphql` — returns entries from `graphql_responses` keyed by `operationName`, or `default`.
- `POST /regrello/documents` — returns `document_id` from `document_upload` fixtures.

See [docs/examples.md](docs/examples.md) for cURL examples (memory and HTTP).

#### Fixture JSON schema

- **`graphql_responses`** (required): maps `operationName` strings (or `"default"`) to full GraphQL JSON bodies for `POST /regrello/graphql`.
- **`document_upload`** (required): maps `filename` strings (or `"default"`) to `{ "document_id": "..." }` or a plain id string for `POST /regrello/documents`.

#### Example fixture file

Same shape as [`regrello_memory_minimal.json`](regrello_memory_minimal.json) at the repo root and under `tests/fixtures/`:

```json
{
  "graphql_responses": {
    "default": { "data": { "workflows": [] } },
    "WorkflowStatus": {
      "data": {
        "workflows": [{ "id": "wf-known", "name": "Memory fixture workflow" }]
      }
    }
  },
  "document_upload": {
    "default": { "document_id": "mem-doc-1" }
  }
}
```

## Run locally (HTTP / default)

With `REGRELLO_CONNECTOR_BACKEND=http` (default), set the variables for `http` mode as documented in [`.env.example`](.env.example), then:

```bash
uvicorn app.main:app --host 0.0.0.0 --port 8005 --reload
```

For memory mode, use the steps in [Memory backend](#memory-backend) instead.

## Container image

Build from the **repository root** so `agentic-goe-regrello-connector/` and its `regrello/` package are on the build context:

```bash
docker build -f agentic-goe-regrello-connector/Dockerfile .
```

## Documentation

- [**Connector usage examples (cURL)**](docs/examples.md) — GraphiQL workflow, GraphQL proxy, document upload, memory fixtures
- [Overview, transport, lifecycle](docs/README.md)
- [Workflows, templates, documents (Regrello GraphQL)](docs/workflows.md)
- [ActionItems / Tasks](docs/tasks.md)

## API overview

- `GET /health` — probes
- `GET /status` — non-secret connector identity (includes `backend`: `http` or `memory`)
- `POST /regrello/graphql` — proxy any Regrello GraphQL call (`query`, `variables`, `operationName`); returns full JSON (`data`, `errors`)
- `POST /regrello/documents` — create document + upload (`filename`, `content_base64`); returns `{ "document_id" }`

## Tests

From the connector directory (with the dev environment installed, for example `uv sync --all-groups`):

```bash
pytest
```

`tests/conftest.py` sets `REGRELLO_CONNECTOR_DISABLE_DOTENV=1` before application imports so a developer `.env` (for example `REGRELLO_CONNECTOR_BACKEND=memory`) does not change unit test expectations.

If `pytest` is not on your `PATH`, use `uv run pytest` or the virtualenv’s `pytest`.
