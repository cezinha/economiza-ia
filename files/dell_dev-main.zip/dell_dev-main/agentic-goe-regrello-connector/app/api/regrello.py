"""Regrello GraphQL proxy and document upload."""

from __future__ import annotations

import base64
import logging
from typing import Annotated, Any

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel, ConfigDict, Field

from app.deps import RegrelloBackend, get_regrello_backend
from app.services.document_upload import DocumentUploadService

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/regrello", tags=["regrello"])

_document_upload_service = DocumentUploadService()


class GraphQLRequest(BaseModel):
    """Regrello GraphQL envelope (query, variables, operationName)."""

    query: str
    variables: dict[str, Any] | None = None
    operation_name: str | None = Field(None, alias="operationName")

    model_config = ConfigDict(populate_by_name=True)


class DocumentUploadRequest(BaseModel):
    """Binary document passed as base64 for JSON APIs."""

    filename: str
    content_base64: str = Field(
        ...,
        description="File contents, base64-encoded",
    )


class DocumentUploadResponse(BaseModel):
    document_id: str


RegrelloBackendDep = Annotated[RegrelloBackend, Depends(get_regrello_backend)]


def _decode_content_base64(filename: str, content_base64: str) -> bytes:
    try:
        return base64.b64decode(content_base64, validate=True)
    except (ValueError, TypeError) as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Invalid base64 for document {filename!r}: {e}",
        ) from e


@router.post("/graphql")
async def regrello_graphql_route(
    backend: RegrelloBackendDep,
    body: GraphQLRequest,
) -> dict[str, Any]:
    """Proxy a Regrello GraphQL request; returns full JSON (data and optional errors)."""

    try:
        return await backend.execute_graphql(
            query=body.query,
            variables=body.variables,
            operation_name=body.operation_name,
        )
    except (RuntimeError, ValueError) as e:
        logger.exception("GraphQL proxy failed")
        raise HTTPException(
            status_code=status.HTTP_502_BAD_GATEWAY,
            detail=str(e),
        ) from e


@router.post("/documents", response_model=DocumentUploadResponse)
async def regrello_documents_route(
    backend: RegrelloBackendDep,
    body: DocumentUploadRequest,
) -> DocumentUploadResponse:
    """Create a Regrello document and upload file content (GraphQL + signed URL PUT)."""

    content = _decode_content_base64(body.filename, body.content_base64)
    try:
        document_id = await _document_upload_service.upload(
            backend,
            body.filename,
            content,
        )
    except (RuntimeError, ValueError) as e:
        logger.exception("Document upload failed")
        raise HTTPException(
            status_code=status.HTTP_502_BAD_GATEWAY,
            detail=str(e),
        ) from e

    return DocumentUploadResponse(document_id=document_id)
