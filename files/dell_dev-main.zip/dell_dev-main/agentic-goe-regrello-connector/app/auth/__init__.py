"""Authentication for the Regrello connector.

- **Inbound** (caller → connector): OAuth token introspection (RFC 7662) when
  ``REGRELLO_CONNECTOR_INBOUND_AUTH_ENABLED`` is true. See ``app.auth.middleware``.
- **Outbound** (connector → Regrello): OAuth2 client credentials inside
  ``regrello.RegrelloClient`` (see ``app/graphql/client.py``).
"""
