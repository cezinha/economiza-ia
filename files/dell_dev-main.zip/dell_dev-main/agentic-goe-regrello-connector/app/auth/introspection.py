"""RFC 7662 OAuth token introspection for inbound caller authentication."""

from __future__ import annotations

import logging

import httpx

from app.config import Settings

logger = logging.getLogger(__name__)


class IntrospectionUnavailableError(Exception):
    """Introspection endpoint unreachable or returned an unusable response."""


async def is_token_active(token: str, *, settings: Settings) -> bool:
    """Return True when the introspection endpoint reports ``active: true``."""
    url = settings.introspection_url
    data = {"token": token, "token_type_hint": "access_token"}
    auth = httpx.BasicAuth(
        settings.regrello_connector_oauth_introspection_client_id,
        settings.regrello_connector_oauth_introspection_client_secret,
    )
    timeout = httpx.Timeout(settings.regrello_connector_oauth_introspection_timeout)

    try:
        async with httpx.AsyncClient(timeout=timeout) as client:
            response = await client.post(
                url,
                data=data,
                auth=auth,
                headers={"Content-Type": "application/x-www-form-urlencoded"},
            )
            response.raise_for_status()
            body = response.json()
    except httpx.HTTPError as exc:
        logger.warning("Token introspection failed: %s", exc)
        raise IntrospectionUnavailableError(str(exc)) from exc
    except ValueError as exc:
        logger.warning("Token introspection returned non-JSON body")
        raise IntrospectionUnavailableError("Invalid introspection response") from exc

    return body.get("active") is True
