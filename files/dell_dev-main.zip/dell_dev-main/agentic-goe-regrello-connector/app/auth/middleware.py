"""HTTP middleware for inbound OAuth token validation."""

from __future__ import annotations

from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import JSONResponse, Response

from app.auth.introspection import IntrospectionUnavailableError, is_token_active
from app.config import settings


def _extract_bearer_token(authorization: str) -> str | None:
    scheme, _, token = authorization.partition(" ")
    if scheme.lower() != "bearer" or not token.strip():
        return None
    return token.strip()


def _unauthorized(detail: str, *, www_authenticate: str = "Bearer") -> JSONResponse:
    return JSONResponse(
        status_code=401,
        content={"detail": detail},
        headers={"WWW-Authenticate": www_authenticate},
    )


def _service_unavailable(detail: str) -> JSONResponse:
    return JSONResponse(status_code=503, content={"detail": detail})


class InboundAuthMiddleware(BaseHTTPMiddleware):
    """Validate caller OAuth tokens via introspection when inbound auth is enabled."""

    async def dispatch(self, request: Request, call_next) -> Response:
        if not settings.regrello_connector_inbound_auth_enabled:
            return await call_next(request)

        if request.url.path in settings.inbound_auth_skip_paths_list:
            return await call_next(request)

        authorization = (request.headers.get("authorization") or "").strip()
        if not authorization:
            return _unauthorized("Not authenticated")

        token = _extract_bearer_token(authorization)
        if token is None:
            return _unauthorized(
                "Invalid Authorization header",
                www_authenticate='Bearer error="invalid_request"',
            )

        try:
            active = await is_token_active(token, settings=settings)
        except IntrospectionUnavailableError:
            return _service_unavailable("Token validation unavailable")

        if not active:
            return _unauthorized(
                "Invalid or inactive token",
                www_authenticate='Bearer error="invalid_token"',
            )

        return await call_next(request)
