"""Configuration for the Regrello connector service."""

from __future__ import annotations

import os
from pathlib import Path
from typing import Literal, Self

from pydantic import Field, model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

# Package layout: app/config.py -> connector root is parent of `app/` (next to pyproject.toml).
_CONNECTOR_ROOT = Path(__file__).resolve().parent.parent


def _settings_env_file() -> tuple[str, ...] | None:
    """`.env` paths for runtime; disabled when tests set REGRELLO_CONNECTOR_DISABLE_DOTENV."""
    if os.environ.get("REGRELLO_CONNECTOR_DISABLE_DOTENV", "").lower() in ("1", "true", "yes"):
        return None
    return (
        str(Path.cwd() / ".env"),
        str(_CONNECTOR_ROOT / ".env"),
    )


class Settings(BaseSettings):
    """Application settings loaded from environment variables."""

    model_config = SettingsConfigDict(
        case_sensitive=False,
        extra="allow",
        # cwd first, connector root second: pydantic merges env files with update(), so connector
        # root wins for duplicate keys. OS env still overrides dotenv (default source order).
        env_file=_settings_env_file(),
        env_file_encoding="utf-8",
    )

    environment: str = Field(default="local", validation_alias="REGRELLO_CONNECTOR_ENVIRONMENT")
    service_host: str = Field(default="0.0.0.0", validation_alias="REGRELLO_CONNECTOR_SERVICE_HOST")
    service_port: int = Field(default=8005, validation_alias="REGRELLO_CONNECTOR_SERVICE_PORT")
    log_level: str = Field(default="INFO", validation_alias="REGRELLO_CONNECTOR_LOG_LEVEL")

    regrello_connector_backend: Literal["http", "memory"] = Field(
        default="http",
        validation_alias="REGRELLO_CONNECTOR_BACKEND",
    )
    regrello_connector_memory_fixtures_path: Path | None = Field(
        default=None,
        validation_alias="REGRELLO_CONNECTOR_MEMORY_FIXTURES_PATH",
    )

    regrello_base_url: str = Field(default="", validation_alias="REGRELLO_BASE_URL")
    regrello_workspace_id: str = Field(default="", validation_alias="REGRELLO_WORKSPACE_ID")
    regrello_client_id: str = Field(default="", validation_alias="REGRELLO_CLIENT_ID")
    regrello_client_secret: str = Field(default="", validation_alias="REGRELLO_CLIENT_SECRET")
    regrello_workflow_template_id: int = Field(
        default=253,
        validation_alias="REGRELLO_WORKFLOW_TEMPLATE_ID",
    )
    regrello_verify_ssl: bool = Field(default=True, validation_alias="REGRELLO_VERIFY_SSL")
    regrello_token_validation_window: int = Field(
        default=60,
        validation_alias="REGRELLO_TOKEN_VALIDATION_WINDOW",
    )

    # Inbound OAuth (caller → connector) via RFC 7662 token introspection.
    regrello_connector_inbound_auth_enabled: bool = Field(
        default=False,
        validation_alias="REGRELLO_CONNECTOR_INBOUND_AUTH_ENABLED",
    )
    regrello_connector_oauth_introspection_base_url: str = Field(
        default="",
        validation_alias="REGRELLO_CONNECTOR_OAUTH_INTROSPECTION_BASE_URL",
    )
    regrello_connector_oauth_introspection_path: str = Field(
        default="",
        validation_alias="REGRELLO_CONNECTOR_OAUTH_INTROSPECTION_PATH",
    )
    regrello_connector_oauth_introspection_client_id: str = Field(
        default="",
        validation_alias="REGRELLO_CONNECTOR_OAUTH_INTROSPECTION_CLIENT_ID",
    )
    regrello_connector_oauth_introspection_client_secret: str = Field(
        default="",
        validation_alias="REGRELLO_CONNECTOR_OAUTH_INTROSPECTION_CLIENT_SECRET",
    )
    regrello_connector_oauth_introspection_timeout: float = Field(
        default=5.0,
        validation_alias="REGRELLO_CONNECTOR_OAUTH_INTROSPECTION_TIMEOUT",
    )
    regrello_connector_inbound_auth_skip_paths: str = Field(
        default="/health,/metrics,/status",
        validation_alias="REGRELLO_CONNECTOR_INBOUND_AUTH_SKIP_PATHS",
    )

    @property
    def introspection_url(self) -> str:
        """Full introspection endpoint URL (base + path)."""
        base = self.regrello_connector_oauth_introspection_base_url.rstrip("/")
        path = self.regrello_connector_oauth_introspection_path.strip()
        if path and not path.startswith("/"):
            path = f"/{path}"
        return f"{base}{path}"

    @property
    def inbound_auth_skip_paths_list(self) -> list[str]:
        """Comma-separated skip paths as a normalized list."""
        raw = self.regrello_connector_inbound_auth_skip_paths.strip()
        if not raw:
            return []
        return [p.strip() for p in raw.split(",") if p.strip()]

    @model_validator(mode="after")
    def validate_backend_requirements(self) -> Self:
        if self.regrello_connector_backend == "http":
            missing: list[str] = []
            if not self.regrello_base_url.strip():
                missing.append("REGRELLO_BASE_URL")
            if not self.regrello_workspace_id.strip():
                missing.append("REGRELLO_WORKSPACE_ID")
            if not self.regrello_client_id.strip():
                missing.append("REGRELLO_CLIENT_ID")
            if not self.regrello_client_secret.strip():
                missing.append("REGRELLO_CLIENT_SECRET")
            if missing:
                raise ValueError(
                    "When REGRELLO_CONNECTOR_BACKEND=http, the following environment variables "
                    f"must be set to non-empty values: {', '.join(missing)}"
                )

        if self.regrello_connector_inbound_auth_enabled:
            inbound_missing: list[str] = []
            if not self.regrello_connector_oauth_introspection_base_url.strip():
                inbound_missing.append("REGRELLO_CONNECTOR_OAUTH_INTROSPECTION_BASE_URL")
            if not self.regrello_connector_oauth_introspection_path.strip():
                inbound_missing.append("REGRELLO_CONNECTOR_OAUTH_INTROSPECTION_PATH")
            if not self.regrello_connector_oauth_introspection_client_id.strip():
                inbound_missing.append("REGRELLO_CONNECTOR_OAUTH_INTROSPECTION_CLIENT_ID")
            if not self.regrello_connector_oauth_introspection_client_secret.strip():
                inbound_missing.append("REGRELLO_CONNECTOR_OAUTH_INTROSPECTION_CLIENT_SECRET")
            if inbound_missing:
                raise ValueError(
                    "When REGRELLO_CONNECTOR_INBOUND_AUTH_ENABLED=true, the following "
                    f"environment variables must be set to non-empty values: "
                    f"{', '.join(inbound_missing)}"
                )

        if self.regrello_connector_backend == "http":
            return self

        # memory
        p = self.regrello_connector_memory_fixtures_path
        if p is None:
            raise ValueError(
                "REGRELLO_CONNECTOR_MEMORY_FIXTURES_PATH is required when "
                "REGRELLO_CONNECTOR_BACKEND=memory"
            )
        if not p.is_file():
            raise ValueError(
                f"REGRELLO_CONNECTOR_MEMORY_FIXTURES_PATH must be an existing file; got {p!r}"
            )
        return self


settings = Settings()
