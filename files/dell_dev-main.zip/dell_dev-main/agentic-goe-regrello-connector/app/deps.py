"""FastAPI dependency wiring for Regrello backends."""

from __future__ import annotations

from collections.abc import AsyncIterator
from typing import Union

from app.config import settings
from app.http.backend import RegrelloHttpBackend
from app.http.registry import get_http_backend
from app.memory.backend import RegrelloMemoryBackend

RegrelloBackend = Union[RegrelloHttpBackend, RegrelloMemoryBackend]


async def get_regrello_backend() -> AsyncIterator[RegrelloBackend]:
    """Yield the configured backend for the current request."""
    if settings.regrello_connector_backend == "http":
        yield get_http_backend()
        return

    if settings.regrello_connector_backend == "memory":
        path = settings.regrello_connector_memory_fixtures_path
        assert path is not None  # enforced by Settings validator
        backend: RegrelloBackend = RegrelloMemoryBackend.from_path(path)
        try:
            yield backend
        finally:
            await backend.aclose()
        return

    raise RuntimeError(
        f"Unsupported regrello_connector_backend: {settings.regrello_connector_backend!r}"
    )
