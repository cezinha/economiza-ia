"""HTTP backend delegating to the vendored async ``RegrelloClient``."""

from __future__ import annotations

from typing import Any

from regrello import RegrelloClient


class RegrelloHttpBackend:
    """HTTP adapter over a shared ``RegrelloClient`` (token lifecycle inside the client)."""

    def __init__(self, client: RegrelloClient) -> None:
        self._client = client

    async def execute_graphql(
        self,
        query: str,
        variables: dict[str, Any] | None = None,
        operation_name: str | None = None,
    ) -> dict[str, Any]:
        return await self._client.execute_graphql(
            query=query,
            variables=variables,
            operation_name=operation_name,
        )

    async def upload_document(self, filename: str, content: bytes) -> str:
        return await self._client.create_and_upload_document(filename, content)

    async def aclose(self) -> None:
        await self._client.aclose()
