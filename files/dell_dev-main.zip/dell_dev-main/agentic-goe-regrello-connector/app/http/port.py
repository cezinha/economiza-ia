"""HTTP backend protocol for Regrello GraphQL proxy."""

from __future__ import annotations

from typing import Any, Protocol, runtime_checkable


@runtime_checkable
class HttpBackend(Protocol):
    """Async façade over authenticated Regrello GraphQL."""

    async def execute_graphql(
        self,
        query: str,
        variables: dict[str, Any] | None = None,
        operation_name: str | None = None,
    ) -> dict[str, Any]:
        """Full Regrello GraphQL JSON response (data and optional errors)."""

    async def upload_document(self, filename: str, content: bytes) -> str:
        """Create document via GraphQL and upload bytes to signed URL."""

    async def aclose(self) -> None:
        """Release HTTP resources."""
