"""Process-wide singleton for the HTTP Regrello backend."""

from __future__ import annotations

from app.config import Settings
from app.graphql.client import create_regrello_client
from app.http.backend import RegrelloHttpBackend

_http_backend: RegrelloHttpBackend | None = None


def init_http_backend(app_settings: Settings) -> RegrelloHttpBackend:
    """Create the shared HTTP backend once per process."""
    global _http_backend
    if _http_backend is None:
        client = create_regrello_client(app_settings)
        _http_backend = RegrelloHttpBackend(client)
    return _http_backend


def get_http_backend() -> RegrelloHttpBackend:
    """Return the shared HTTP backend."""
    if _http_backend is None:
        raise RuntimeError("HTTP backend is not initialized. Call init_http_backend() first.")
    return _http_backend


async def close_http_backend() -> None:
    """Close the shared HTTP backend on application shutdown."""
    global _http_backend
    if _http_backend is not None:
        await _http_backend.aclose()
        _http_backend = None


def reset_http_backend_for_tests() -> None:
    """Clear the registry without closing (for unit tests only)."""
    global _http_backend
    _http_backend = None
