"""FastAPI entry point for the Regrello connector service."""

import logging
from contextlib import asynccontextmanager
from datetime import datetime, timezone

from fastapi import FastAPI
from pydantic import BaseModel
from prometheus_fastapi_instrumentator import Instrumentator

from app.api import regrello, status
from app.auth.middleware import InboundAuthMiddleware
from app.config import settings
from app.http.registry import close_http_backend, init_http_backend

logging.basicConfig(
    level=getattr(logging, settings.log_level.upper(), logging.INFO),
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
)


@asynccontextmanager
async def lifespan(_app: FastAPI):
    if settings.regrello_connector_backend == "http":
        init_http_backend(settings)
    yield
    await close_http_backend()


app = FastAPI(
    title="Regrello Connector",
    version="0.1.0",
    lifespan=lifespan,
)
app.add_middleware(InboundAuthMiddleware)
Instrumentator().instrument(app).expose(app, include_in_schema=False)

app.include_router(status.router)
app.include_router(regrello.router)


class HealthResponse(BaseModel):
    """Health check response model."""

    status: str
    service: str
    timestamp: datetime


@app.get("/health", response_model=HealthResponse)
async def health() -> HealthResponse:
    """Liveness/readiness probe endpoint."""

    return HealthResponse(
        status="ok",
        service="regrello-connector",
        timestamp=datetime.now(timezone.utc),
    )
