"""In-memory fixture backend for local development and tests."""

from app.memory.backend import RegrelloMemoryBackend

__all__ = ["RegrelloMemoryBackend"]
