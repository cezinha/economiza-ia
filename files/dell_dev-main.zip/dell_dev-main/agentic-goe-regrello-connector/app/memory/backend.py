"""In-memory backend driven by a JSON fixture file."""

from __future__ import annotations

import json
from copy import deepcopy
from pathlib import Path
from typing import Any


class RegrelloMemoryBackend:
    """Serve canned GraphQL and document responses from a JSON file."""

    def __init__(self, data: dict[str, Any]) -> None:
        self._data = data

    @classmethod
    def from_path(cls, path: Path) -> RegrelloMemoryBackend:
        raw = json.loads(path.read_text(encoding="utf-8"))
        if not isinstance(raw, dict):
            raise ValueError(f"Memory fixtures JSON must be an object, got {type(raw).__name__}")
        return cls(raw)

    def _resolve_graphql_response(self, operation_name: str | None) -> dict[str, Any]:
        branch = self._data.get("graphql_responses")
        if not isinstance(branch, dict):
            raise ValueError(
                "graphql_responses must be a JSON object keyed by operationName "
                "(or 'default') for memory backend execute_graphql"
            )

        if operation_name is not None and operation_name in branch:
            payload = branch[operation_name]
        elif "default" in branch:
            payload = branch["default"]
        else:
            raise ValueError(
                f"Unknown operationName {operation_name!r} for memory backend: "
                f"not defined under graphql_responses and no 'default' entry"
            )

        if not isinstance(payload, dict):
            key = operation_name if operation_name is not None else "default"
            raise ValueError(f"graphql_responses[{key!r}] must be a JSON object")
        return deepcopy(payload)

    def _resolve_document_id(self, filename: str) -> str:
        branch = self._data.get("document_upload")
        if not isinstance(branch, dict):
            raise ValueError(
                "document_upload must be a JSON object keyed by filename or 'default'"
            )

        entry: Any
        if filename in branch:
            entry = branch[filename]
        elif "default" in branch:
            entry = branch["default"]
        else:
            raise ValueError(
                f"Unknown filename {filename!r} for memory backend: "
                f"not defined under document_upload and no 'default' entry"
            )

        if isinstance(entry, str):
            return entry
        if isinstance(entry, dict):
            doc_id = entry.get("document_id")
            if doc_id is not None:
                return str(doc_id)
        raise ValueError(
            f"document_upload entry for {filename!r} must be a string id or "
            f'{{"document_id": "..."}} object'
        )

    async def execute_graphql(
        self,
        query: str,
        variables: dict[str, Any] | None = None,
        operation_name: str | None = None,
    ) -> dict[str, Any]:
        _ = (query, variables)
        return self._resolve_graphql_response(operation_name)

    async def upload_document(self, filename: str, content: bytes) -> str:
        _ = content
        return self._resolve_document_id(filename)

    async def aclose(self) -> None:
        """No HTTP resources."""
