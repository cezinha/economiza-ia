"""Memory backend protocol for fixture-driven responses."""

from __future__ import annotations

from typing import Any, Protocol, runtime_checkable


@runtime_checkable
class MemoryBackend(Protocol):
    """Fixture-backed Regrello stand-in for GraphQL and document upload."""

    async def execute_graphql(
        self,
        query: str,
        variables: dict[str, Any] | None = None,
        operation_name: str | None = None,
    ) -> dict[str, Any]:
        """Canned GraphQL JSON from fixtures."""

    async def upload_document(self, filename: str, content: bytes) -> str:
        """Return a fixture ``document_id``."""

    async def aclose(self) -> None:
        """No-op for memory backend."""
