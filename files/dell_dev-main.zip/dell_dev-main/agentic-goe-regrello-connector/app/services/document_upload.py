"""Orchestrate Regrello document create + signed URL upload."""

from __future__ import annotations

from typing import Protocol, runtime_checkable


@runtime_checkable
class DocumentUploadCapable(Protocol):
    async def upload_document(self, filename: str, content: bytes) -> str: ...


class DocumentUploadService:
    """Upload a document through the configured Regrello backend."""

    async def upload(
        self,
        backend: DocumentUploadCapable,
        filename: str,
        content: bytes,
    ) -> str:
        return await backend.upload_document(filename, content)
