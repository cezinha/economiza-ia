"""Synchronization workflows.

Regrello operations are exposed under `/regrello` instead of SharePoint-style `/sync`.
"""
