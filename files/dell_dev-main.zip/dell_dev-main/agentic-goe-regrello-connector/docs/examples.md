# Connector usage examples

Examples for calling the Regrello connector HTTP API. For Regrello GraphQL schema and field reference, see [workflows.md](workflows.md) and [README.md](README.md).

**Base URL (local):** `http://localhost:8005`

## Public API

| Method | Path | Purpose |
|--------|------|---------|
| `GET` | `/health` | Liveness probe |
| `GET` | `/status` | Non-secret config (`backend`, workspace, template id) |
| `POST` | `/regrello/graphql` | Authenticated GraphQL proxy |
| `POST` | `/regrello/documents` | Create document + upload file (GraphQL + signed URL PUT) |

## GraphiQL → connector

1. Develop and run queries in Regrello **GraphiQL**.
2. Copy the same `query`, `variables`, and `operationName` into `POST /regrello/graphql`.
3. The connector adds OAuth and forwards the envelope; the response is the **full** Regrello JSON (`data` and optional `errors`).

**Proxy contract:** GraphQL-level `errors` may appear in the body with HTTP `200`. Transport/auth failures return HTTP `502`.

### Inbound OAuth (when enabled)

When `REGRELLO_CONNECTOR_INBOUND_AUTH_ENABLED=true`, send the caller's IdP access token (not the Regrello connector token):

```bash
curl -sS -X POST "http://localhost:8005/regrello/graphql" \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer ${CALLER_ACCESS_TOKEN}" \
  -d '{
    "query": "query { __typename }",
    "variables": {},
    "operationName": null
  }'
```

`/health`, `/metrics`, and `/status` are excluded by default (`REGRELLO_CONNECTOR_INBOUND_AUTH_SKIP_PATHS`).

### Minimal GraphQL proxy

```bash
curl -sS -X POST "http://localhost:8005/regrello/graphql" \
  -H "Content-Type: application/json" \
  -d '{
    "query": "query { __typename }",
    "variables": {},
    "operationName": null
  }'
```

## Reading GraphQL responses

| Use case | Typical path in response |
|----------|--------------------------|
| Workflow by id | `jq '.data.workflows[0]'` |
| Template fields | `jq '.data.workflowTemplates[0].fieldInstances'` |
| Create workflow | `jq '.data.createWorkflowFromTemplate.workflow.id'` |
| Mutation business error | `jq '.data.createWorkflowFromTemplate.error'` |

GraphQL operation shapes match [workflows.md](workflows.md). The vendored client exposes `execute_graphql` and document upload only; workflow helpers were removed.

---

## Workflow status

Use **`POST /regrello/graphql`** (not a dedicated status route). The vendored client no longer exposes `get_workflow_status`; copy the same query from GraphiQL or use the envelope below.

| Item | Value |
|------|--------|
| Endpoint | `POST /regrello/graphql` |
| `operationName` | `WorkflowStatus` |
| `variables.id` | Workflow id (string) |
| Workflow object in response | `jq '.data.workflows[0]'` (Regrello returns a list under `workflows`) |

**Example request**

```bash
curl -sS -X POST "http://localhost:8005/regrello/graphql" \
  -H "Content-Type: application/json" \
  -d '{
    "query": "query WorkflowStatus($id: ID!) { workflows(id: $id) { id name description referenceNumber referenceNumberPrefix status: scheduleStatus createdAt startedAt completedAt endedAt updatedAt percentComplete daysDelayed isLocked hasException blueprint { id name } stages { id name status } tags { id name } __typename } }",
    "variables": { "id": "wf-123" },
    "operationName": "WorkflowStatus"
  }'
```

**Example response handling** (pipe the curl above):

```bash
jq '.data.workflows[0]'        # workflow object
jq '.errors'                   # GraphQL errors, if any (HTTP may still be 200)
```

With `REGRELLO_CONNECTOR_BACKEND=memory`, the same call returns the fixture entry keyed by `WorkflowStatus` in `graphql_responses` (see [Memory backend](#memory-backend-local--ci) below).

---

## Document upload

Orchestration endpoint: GraphQL `createDocument` + `PUT` to the signed URL (not available via `POST /regrello/graphql` alone).

| Item | Value |
|------|--------|
| Endpoint | `POST /regrello/documents` |
| Body | `filename`, `content_base64` |
| Response | `{ "document_id": "..." }` |

```bash
curl -sS -X POST "http://localhost:8005/regrello/documents" \
  -H "Content-Type: application/json" \
  -d '{
    "filename": "report.pdf",
    "content_base64": "'"$(base64 < report.pdf | tr -d '\n')"'"
  }' | jq '.document_id'
```

Use the returned id in `documentMultiValue` / `documentValue` when calling [Create workflow](#create-workflow-with-documents).

---

## Workflow template fields

Use **`POST /regrello/graphql`**. There is no `get_workflow_template_fields` helper on the client.

| Item | Value |
|------|--------|
| Endpoint | `POST /regrello/graphql` |
| `operationName` | `WorkflowTemplateFields` |
| `variables.id` | Blueprint / template id (e.g. `253`) |
| Raw fields | `jq '.data.workflowTemplates[0].fieldInstances'` |

```bash
curl -sS -X POST "http://localhost:8005/regrello/graphql" \
  -H "Content-Type: application/json" \
  -d '{
    "query": "query WorkflowTemplateFields($id: ID!) { workflowTemplates(id: $id) { id name description fieldInstances { id inputType displayOrder originalInputType spectrumFieldVersion { name description validationType { validationType } } field { id name description isMultiValued fieldType fieldUnit { name } scimAttributeName spectrumField { id uuid } } } } }",
    "variables": { "id": 253 },
    "operationName": "WorkflowTemplateFields"
  }' | jq '.data.workflowTemplates[0].fieldInstances'
```

The response is Regrello-shaped `fieldInstances`. For `createWorkflowFromTemplate`, build `fieldInstances` in your app: keep `REQUESTED` / `OPTIONAL`, set `fieldId`, `inputType`, `displayOrder`, and the correct value key (`stringValue`, `documentMultiValue`, etc.).

---

## Template field metadata

Same GraphQL call as [workflow template fields](#workflow-template-fields). Map each `fieldInstance` to `{ fieldId, fieldName, inputType, displayOrder, isMultiValued, dataType }` in your consumer, or use `fieldInstances` as returned.

---

## Create workflow (no documents)

Use **`POST /regrello/graphql`**. There is no `create_workflow` helper on the client.

| Item | Value |
|------|--------|
| Endpoint | `POST /regrello/graphql` |
| `operationName` | `CreateWorkflowFromTemplateMutation` |
| `variables.input` | `fieldInstances`, `startCondition`, `tagIds`, `workflowTemplateId` |
| Workflow id | `jq '.data.createWorkflowFromTemplate.workflow.id'` |
| Business error | `jq '.data.createWorkflowFromTemplate.error'` |

```bash
curl -sS -X POST "http://localhost:8005/regrello/graphql" \
  -H "Content-Type: application/json" \
  -d '{
    "query": "mutation CreateWorkflowFromTemplateMutation($input: CreateWorkflowFromTemplateInputs!) { createWorkflowFromTemplate(input: $input) { workflow { id } error __typename } }",
    "variables": {
      "input": {
        "fieldInstances": [
          { "fieldId": 1037, "stringValue": "My Value", "inputType": "REQUESTED", "displayOrder": 1 }
        ],
        "startCondition": "START_IMMEDIATELY",
        "tagIds": [],
        "workflowTemplateId": 253
      }
    },
    "operationName": "CreateWorkflowFromTemplateMutation"
  }' | jq '{ workflow_id: .data.createWorkflowFromTemplate.workflow.id, error: .data.createWorkflowFromTemplate.error }'
```

---

## Create workflow (with documents)

Use **`POST /regrello/documents`** per file, then **`POST /regrello/graphql`** with real `document_id` values in `fieldInstances` (no `$doc_N` placeholders on the connector).

**Step 1 — upload**

```bash
DOC_ID=$(curl -sS -X POST "http://localhost:8005/regrello/documents" \
  -H "Content-Type: application/json" \
  -d "{
    \"filename\": \"baseline.pdf\",
    \"content_base64\": \"$(base64 < baseline.pdf | tr -d '\n')\"
  }" | jq -r '.document_id')
echo "document_id=$DOC_ID"
```

**Step 2 — create workflow**

```bash
curl -sS -X POST "http://localhost:8005/regrello/graphql" \
  -H "Content-Type: application/json" \
  -d "{
    \"query\": \"mutation CreateWorkflowFromTemplateMutation(\$input: CreateWorkflowFromTemplateInputs!) { createWorkflowFromTemplate(input: \$input) { workflow { id } error } }\",
    \"variables\": {
      \"input\": {
        \"fieldInstances\": [
          { \"fieldId\": 1037, \"stringValue\": \"Product\", \"inputType\": \"REQUESTED\", \"displayOrder\": 1 },
          { \"fieldId\": 1042, \"documentMultiValue\": [\"$DOC_ID\"], \"inputType\": \"OPTIONAL\", \"displayOrder\": 2 }
        ],
        \"startCondition\": \"START_IMMEDIATELY\",
        \"tagIds\": [],
        \"workflowTemplateId\": 253
      }
    },
    \"operationName\": \"CreateWorkflowFromTemplateMutation\"
  }"
```

Repeat step 1 for each file; pass all ids in `documentMultiValue`.

---

## Memory backend (local / CI)

```bash
export REGRELLO_CONNECTOR_BACKEND=memory
export REGRELLO_CONNECTOR_MEMORY_FIXTURES_PATH="$(pwd)/regrello_memory_minimal.json"
uvicorn app.main:app --host 0.0.0.0 --port 8005 --reload
```

```bash
# GraphQL fixture (WorkflowStatus)
curl -sS -X POST "http://localhost:8005/regrello/graphql" \
  -H "Content-Type: application/json" \
  -d '{"query":"query { __typename }","operationName":"WorkflowStatus"}' \
  | jq '.data.workflows[0].id'

# Document fixture
curl -sS -X POST "http://localhost:8005/regrello/documents" \
  -H "Content-Type: application/json" \
  -d '{"filename":"test.pdf","content_base64":"'$(echo -n hi | base64)'"}' \
  | jq '.document_id'
```

Fixture schema: `graphql_responses` (keyed by `operationName` or `default`), `document_upload` (keyed by `filename` or `default` with `{ "document_id": "..." }`). See [`regrello_memory_minimal.json`](../regrello_memory_minimal.json).
