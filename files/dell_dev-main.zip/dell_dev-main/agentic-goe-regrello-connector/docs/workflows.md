# Workflows — entities and GraphQL operations

Workflow-related Regrello GraphQL: blueprints (templates), workflow instances, stages, documents, and field inputs.

Back to [overview and lifecycle](README.md).

---

## Entity: Workflow

A running process instance, usually created from a **WorkflowTemplate** (blueprint). Open work units are exposed as **`openActionItems`** (UI: tasks).

| Field | Type | Confidence | Description |
|-------|------|------------|-------------|
| `id` | `ID` / `Int` | Confirmed (tenant) | Workflow id (e.g. `2078`) |
| `scheduleStatus` | Enum | Confirmed (tenant) | e.g. `STARTED` |
| `hasException` | `Boolean` | Confirmed (tenant) | Exception flag |
| `daysDelayed` | `Int` | Confirmed (tenant) | Days delayed |
| `endDate` | `DateTime` | Confirmed (tenant) | Planned/end date for workflow |
| `percentComplete` | `Float` | Confirmed (tenant) | Progress (e.g. `0.14` = 14%) |
| `numOpenActionItems` | `Int` | Confirmed (tenant) | Count of open action items |
| `plannedDueOn` | `DateTime` | Confirmed (tenant) | Planned due date |
| `adjustedDueOn` | `DateTime` | Confirmed (tenant) | Adjusted due date |
| `owner` | `Owner` | Confirmed (tenant) | Workflow owner (`user.name`, `user.email`) |
| `openActionItems` | `[ActionItem]` | Confirmed (tenant) | Currently open action items (summary) |
| `topOpenActionItem` | `ActionItem` | Confirmed (tenant) | Next/priority open item + `workflowReference.stageId` |
| `stages` | `[Stage]` | Confirmed (tenant) | Stages (`id`, `name`) |
| `name` | `String` | Implemented | Display name (client `WorkflowStatus` query) |
| `description` | `String` | Implemented | Description |
| `referenceNumber` | `String` | Implemented | Human-readable reference |
| `referenceNumberPrefix` | `String` | Implemented | Reference prefix |
| `createdAt` / `startedAt` / `completedAt` / `endedAt` / `updatedAt` | `DateTime` | Implemented | Timestamps (client query) |
| `isLocked` | `Boolean` | Implemented | Locked from blueprint |
| `blueprint` | `Blueprint` | Implemented | Source template |
| `tags` | `[Tag]` | Implemented | Tags |

Tenant sample: [workflow-req-res.md](workflow-req-res.md).

---

## Entity: WorkflowTemplate (Blueprint)

Reusable definition for creating workflows. API field name is `workflowTemplates`; product UI calls this a **Blueprint**.

| Field | Type | Confidence | Description |
|-------|------|------------|-------------|
| `id` | `ID` | Implemented | Template id (e.g. `253`) |
| `name` | `String` | Implemented | Template name |
| `description` | `String` | Implemented | Template description |
| `fieldInstances` | `[TemplateFieldInstance]` | Implemented | Fields required/optional at workflow start |

### Nested: TemplateFieldInstance

| Field | Type | Confidence | Description |
|-------|------|------------|-------------|
| `id` | `ID` | Implemented | Template field-instance id |
| `inputType` | `String` | Implemented | e.g. `REQUESTED`, `OPTIONAL` |
| `displayOrder` | `Int` | Implemented | Sort order |
| `originalInputType` | `String` | Implemented | Original input type |
| `spectrumFieldVersion` | Object | Implemented | Version metadata, `validationType` |
| `field` | `Field` | Implemented | Underlying field definition |

### Nested: Field

| Field | Type | Confidence | Description |
|-------|------|------------|-------------|
| `id` | `Int` / `ID` | Implemented | **Use as `fieldId` in mutations** |
| `name` | `String` | Implemented | Field label |
| `description` | `String` | Implemented | Field description |
| `isMultiValued` | `Boolean` | Implemented | Single vs multi value |
| `fieldType` | `String` | Implemented | Field type |
| `fieldUnit` | Object | Implemented | Unit (`name`, e.g. document/file) |
| `scimAttributeName` | `String` | Implemented | SCIM mapping if any |
| `spectrumField` | Object | Implemented | `id`, `uuid` |

---

## Entity: ActionItem (summary on workflow)

GraphQL type for a **Task** in the Regrello UI. Listed on workflows as `openActionItems` / `topOpenActionItem`; full detail via `actionItem` query (see [tasks.md](tasks.md)).

| Field | Type | Confidence | Description |
|-------|------|------------|-------------|
| `id` | `Int` | Confirmed (tenant) | Action item id (e.g. `3566`) |
| `name` | `String` | Confirmed (tenant) | Title |
| `status` | Enum | Confirmed (tenant) | e.g. `PENDING_SUBMISSION`, `COMPLETED` |
| `assignees` | `[Assignee]` | Confirmed (tenant) | `id`, `user.name` (email in workflow list) |
| `workflowReference` | Object | Confirmed (tenant) | `stageId`, `workflowId` (on detail query) |

---

## Entity: Stage

A phase inside a workflow; action items belong to a stage via `workflowReference.stageId`.

| Field | Type | Confidence | Description |
|-------|------|------------|-------------|
| `id` | `ID` / `Int` | Confirmed (tenant) | Stage id (e.g. `4541`) |
| `name` | `String` | Confirmed (tenant) | Stage name |
| `status` | Enum | Implemented | Stage status (optional; not in tenant workflow sample) |

### Nested: Owner

| Field | Type | Confidence | Description |
|-------|------|------------|-------------|
| `user.name` | `String` | Confirmed (tenant) | Owner display / email |
| `user.email` | `String` | Confirmed (tenant) | Owner email |

---

## Entity: Document

File stored in Regrello, referenced from workflow/task field values.

| Field | Type | Confidence | Description |
|-------|------|------------|-------------|
| `id` | `ID` | Implemented | Document id (use in `documentMultiValue`) |
| `name` | `String` | Implemented | File name |
| `signedUrl` | `URL` | Implemented | Pre-signed upload URL (mutation only) |

Upload is completed with **HTTP PUT** to `signedUrl`, not GraphQL.

---

## Entity: FieldInstance (input)

Payload element for `createWorkflowFromTemplate` (and expected for task completion). Send **one** value key per instance.

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `fieldId` | `Int` | Yes | From `field.id` on template |
| `inputType` | `String` | Yes | `REQUESTED` or `OPTIONAL` |
| `displayOrder` | `Int` | Yes | Display order on template |
| `stringValue` | `String` | One of *Value* | Single string |
| `stringMultiValue` | `[String]` | One of *Value* | Multiple strings |
| `documentValue` | `ID` | One of *Value* | Single document id |
| `documentMultiValue` | `[ID]` | One of *Value* | Multiple document ids |

---

## Input type: CreateWorkflowFromTemplateInputs

Used by `createWorkflowFromTemplate`. **Official API** lists all fields; **Implemented** client sends a subset.

| Field | Type | Confidence | In `regrello/client.py`? |
|-------|------|------------|---------------------------|
| `workflowTemplateId` | `Int` / `ID` | Official API | Yes |
| `name` | `String` | Official API | **No** |
| `description` | `String` | Official API | **No** |
| `tagIds` | `[ID]` | Official API | Yes (defaults to `[]`) |
| `collaboratorPartyIds` | `[ID]` | Official API | **No** |
| `fieldInstances` | `[FieldInstance]` | Official API | Yes |
| `startCondition` | `String` | Official API | Yes (default `START_IMMEDIATELY`) |

When `startCondition` is `START_IMMEDIATELY`, the workflow starts immediately and Regrello emails **task assignees** for currently assigned tasks. To start later, omit `startCondition` and call `startWorkflow` separately.

---

## Operations

### ObtainOAuthToken

- **Type:** HTTP (not GraphQL)
- **Confidence:** Implemented

**Request**

```http
POST {REGRELLO_BASE_URL}/oauth/{REGRELLO_WORKSPACE_ID}/token
Content-Type: application/x-www-form-urlencoded

grant_type=client_credentials&client_id=...&client_secret=...
```

**Example response**

```json
{
  "access_token": "eyJhbGciOiJSUzI1NiIs...",
  "token_type": "Bearer",
  "expires_in": 3600
}
```

**cURL**

```bash
curl -sS -X POST \
  "${REGRELLO_BASE_URL}/oauth/${REGRELLO_WORKSPACE_ID}/token" \
  -H "Content-Type: application/x-www-form-urlencoded" \
  --data-urlencode "grant_type=client_credentials" \
  --data-urlencode "client_id=${REGRELLO_CLIENT_ID}" \
  --data-urlencode "client_secret=${REGRELLO_CLIENT_SECRET}"
```

Save `access_token` as `ACCESS_TOKEN` for GraphQL calls.

---

### CreateDocumentMutation

- **Type:** mutation
- **Confidence:** Implemented

**GraphQL**

```graphql
mutation CreateDocumentMutation($filename: String!) {
  createDocument(input: { name: $filename }) {
    error
    document {
      id
      name
      __typename
    }
    signedUrl
    __typename
  }
}
```

**Variables**

```json
{
  "filename": "report.pdf"
}
```

**Example response**

```json
{
  "data": {
    "createDocument": {
      "error": null,
      "document": {
        "id": "doc-abc-123",
        "name": "report.pdf",
        "__typename": "Document"
      },
      "signedUrl": "https://storage.example.com/upload?signature=...",
      "__typename": "CreateDocumentPayload"
    }
  }
}
```

**cURL**

```bash
curl -sS -X POST "${GRAPHQL_URL}" \
  -H "Authorization: Bearer ${ACCESS_TOKEN}" \
  -H "Content-Type: application/json" \
  -d '{
    "operationName": "CreateDocumentMutation",
    "query": "mutation CreateDocumentMutation($filename: String!) { createDocument(input: {name: $filename}) { error document { id name __typename } signedUrl __typename } }",
    "variables": { "filename": "report.pdf" }
  }'
```

---

### UploadDocument (HTTP PUT)

- **Type:** HTTP PUT (not GraphQL)
- **Confidence:** Implemented

Upload bytes to `signedUrl` from `CreateDocumentMutation`.

**cURL**

```bash
curl -sS -X PUT "${SIGNED_URL}" \
  -H "Content-Type: application/pdf" \
  --data-binary "@./report.pdf"
```

---

### CreateWorkflowFromTemplateMutation

- **Type:** mutation
- **Confidence:** Implemented (partial input); full input **Official API**

**GraphQL**

```graphql
mutation CreateWorkflowFromTemplateMutation($input: CreateWorkflowFromTemplateInputs!) {
  createWorkflowFromTemplate(input: $input) {
    workflow {
      id
      __typename
    }
    error
    __typename
  }
}
```

**Variables (full — Official API)**

```json
{
  "input": {
    "workflowTemplateId": 253,
    "name": "My workflow run",
    "description": "",
    "tagIds": [],
    "collaboratorPartyIds": [],
    "fieldInstances": [
      {
        "fieldId": 20,
        "stringValue": "Thena NQ14",
        "inputType": "REQUESTED",
        "displayOrder": 6
      },
      {
        "fieldId": 30,
        "documentMultiValue": ["doc-abc-123"],
        "inputType": "REQUESTED",
        "displayOrder": 13
      }
    ],
    "startCondition": "START_IMMEDIATELY"
  }
}
```

Field ids `20`, `30`, etc. are **examples** from Dell demos; discover yours via `WorkflowTemplateFields`.

**Variables (what `regrello/client.py` sends today)**

```json
{
  "input": {
    "workflowTemplateId": 253,
    "fieldInstances": [],
    "startCondition": "START_IMMEDIATELY",
    "tagIds": []
  }
}
```

**Example response**

```json
{
  "data": {
    "createWorkflowFromTemplate": {
      "workflow": {
        "id": "wf-98765",
        "__typename": "Workflow"
      },
      "error": null,
      "__typename": "CreateWorkflowFromTemplatePayload"
    }
  }
}
```

**cURL**

```bash
curl -sS -X POST "${GRAPHQL_URL}" \
  -H "Authorization: Bearer ${ACCESS_TOKEN}" \
  -H "Content-Type: application/json" \
  -d '{
    "operationName": "CreateWorkflowFromTemplateMutation",
    "query": "mutation CreateWorkflowFromTemplateMutation($input: CreateWorkflowFromTemplateInputs!) { createWorkflowFromTemplate(input: $input) { workflow { id __typename } error __typename } }",
    "variables": {
      "input": {
        "workflowTemplateId": 253,
        "name": "My workflow run",
        "description": "",
        "tagIds": [],
        "collaboratorPartyIds": [],
        "fieldInstances": [
          { "fieldId": 7, "stringValue": "Test Supplier", "inputType": "REQUESTED", "displayOrder": 1 }
        ],
        "startCondition": "START_IMMEDIATELY"
      }
    }
  }'
```

---

### StartWorkflowMutation

- **Type:** mutation
- **Confidence:** Official API (not in `regrello/client.py`)

Start a workflow that was created **without** `START_IMMEDIATELY`. Same product effect as clicking **Start workflow** in the UI (Stage 1 tasks start; assignees notified).

**GraphQL (expected shape)**

```graphql
mutation StartWorkflowMutation($input: StartWorkflowInputs!) {
  startWorkflow(input: $input) {
    workflow {
      id
      scheduleStatus
      __typename
    }
    error
    __typename
  }
}
```

**Variables (expected)**

```json
{
  "input": {
    "workflowId": "wf-98765"
  }
}
```

**Example response (expected)**

```json
{
  "data": {
    "startWorkflow": {
      "workflow": {
        "id": "wf-98765",
        "scheduleStatus": "STARTED",
        "__typename": "Workflow"
      },
      "error": null,
      "__typename": "StartWorkflowPayload"
    }
  }
}
```

**cURL**

```bash
curl -sS -X POST "${GRAPHQL_URL}" \
  -H "Authorization: Bearer ${ACCESS_TOKEN}" \
  -H "Content-Type: application/json" \
  -d '{
    "operationName": "StartWorkflowMutation",
    "query": "mutation StartWorkflowMutation($input: StartWorkflowInputs!) { startWorkflow(input: $input) { workflow { id scheduleStatus __typename } error __typename } }",
    "variables": { "input": { "workflowId": "wf-98765" } }
  }'
```

Confirm exact input type name via GraphQL introspection on your tenant.

---

### WorkflowTemplateFields

- **Type:** query
- **Confidence:** Implemented

**GraphQL**

```graphql
query WorkflowTemplateFields($id: ID!) {
  workflowTemplates(id: $id) {
    id
    name
    description
    fieldInstances {
      id
      inputType
      displayOrder
      originalInputType
      spectrumFieldVersion {
        name
        description
        validationType {
          validationType
        }
      }
      field {
        id
        name
        description
        isMultiValued
        fieldType
        fieldUnit {
          name
        }
        scimAttributeName
        spectrumField {
          id
          uuid
        }
      }
    }
  }
}
```

**Variables**

```json
{
  "id": 253
}
```

**Example response**

```json
{
  "data": {
    "workflowTemplates": [
      {
        "id": "253",
        "name": "Company Blueprint",
        "description": "Example template",
        "fieldInstances": [
          {
            "id": "fi-1",
            "inputType": "REQUESTED",
            "displayOrder": 5,
            "field": {
              "id": 29,
              "name": "LOB",
              "isMultiValued": true,
              "fieldUnit": { "name": "text" }
            }
          }
        ]
      }
    ]
  }
}
```

**cURL**

```bash
curl -sS -X POST "${GRAPHQL_URL}" \
  -H "Authorization: Bearer ${ACCESS_TOKEN}" \
  -H "Content-Type: application/json" \
  -d '{
    "operationName": "WorkflowTemplateFields",
    "query": "query WorkflowTemplateFields($id: ID!) { workflowTemplates(id: $id) { id name description fieldInstances { inputType displayOrder field { id name isMultiValued fieldUnit { name } } } } }",
    "variables": { "id": 253 }
  }'
```

---

### workflows

- **Type:** query
- **Confidence:** Confirmed (tenant)
- **Root field:** `workflows` — response key `data.workflows` (array)

Query a workflow by id. UI tasks appear as **`openActionItems`** and **`topOpenActionItem`**. Tenant capture: [workflow-req-res.md](workflow-req-res.md) (reference only; do not edit).

**GraphQL** (same shape as tenant sample; use variables for `id`)

```graphql
query {
  workflows(id: 2078) {
    scheduleStatus
    hasException
    daysDelayed
    endDate
    percentComplete
    numOpenActionItems
    plannedDueOn
    adjustedDueOn
    owner {
      user {
        name
        email
      }
    }
    openActionItems {
      id
      name
      status
      assignees {
        id
        user {
          name
        }
      }
    }
    topOpenActionItem {
      id
      name
      workflowReference {
        stageId
      }
    }
    stages {
      id
      name
    }
  }
}
```

**Variables (HTTP POST)**

```json
{
  "variables": { "id": 2078 },
  "query": "query($id: ID!) { workflows(id: $id) { scheduleStatus hasException daysDelayed endDate percentComplete numOpenActionItems plannedDueOn adjustedDueOn owner { user { name email } } openActionItems { id name status assignees { id user { name } } } topOpenActionItem { id name workflowReference { stageId } } stages { id name } } }"
}
```

**Example response**

Full JSON is in [workflow-req-res.md](workflow-req-res.md#workflow-response). Root:

```json
{
  "data": {
    "workflows": [
      {
        "scheduleStatus": "STARTED",
        "numOpenActionItems": 5,
        "openActionItems": [
          {
            "id": 3566,
            "name": "Initiate extended team formation​",
            "status": "PENDING_SUBMISSION",
            "assignees": [
              { "id": 350, "user": { "name": "tyler.roth@dellteam.com" } }
            ]
          }
        ],
        "topOpenActionItem": {
          "id": 3566,
          "workflowReference": { "stageId": 4541 }
        },
        "stages": [{ "id": 4539, "name": "1. Concept Phase Launch" }]
      }
    ]
  }
}
```

**cURL**

```bash
curl -sS -X POST "${GRAPHQL_URL}" \
  -H "Authorization: Bearer ${ACCESS_TOKEN}" \
  -H "Content-Type: application/json" \
  -d '{
    "query": "query($id: ID!) { workflows(id: $id) { scheduleStatus hasException daysDelayed endDate percentComplete numOpenActionItems openActionItems { id name status assignees { id user { name } } } topOpenActionItem { id name workflowReference { stageId } } stages { id name } } }",
    "variables": { "id": 2078 }
  }' | jq '.data.workflows[0]'
```

---

### WorkflowStatus

- **Type:** query
- **Confidence:** Implemented (additional fields on same root field `workflows`; see tenant sample above for `openActionItems`)

**GraphQL**

```graphql
query WorkflowStatus($id: ID!) {
  workflows(id: $id) {
    id
    name
    description
    referenceNumber
    referenceNumberPrefix
    status: scheduleStatus
    createdAt
    startedAt
    completedAt
    endedAt
    updatedAt
    percentComplete
    daysDelayed
    isLocked
    hasException
    blueprint {
      id
      name
    }
    stages {
      id
      name
      status
    }
    tags {
      id
      name
    }
    __typename
  }
}
```

**Variables**

```json
{
  "id": "wf-98765"
}
```

**Example response (correct API shape)**

```json
{
  "data": {
    "workflows": [
      {
        "id": "wf-98765",
        "name": "My workflow run",
        "status": "IN_PROGRESS",
        "percentComplete": 25,
        "blueprint": { "id": "253", "name": "Company Blueprint" },
        "stages": [
          { "id": "stage-1", "name": "Stage 1", "status": "ACTIVE" }
        ],
        "tags": []
      }
    ]
  }
}
```

Use `data.workflows[0]` as the workflow object.

**Connector:** use `POST /regrello/graphql` with this query; parse `data.workflows[0]` — see [examples.md](examples.md#workflow-status).

**cURL**

```bash
curl -sS -X POST "${GRAPHQL_URL}" \
  -H "Authorization: Bearer ${ACCESS_TOKEN}" \
  -H "Content-Type: application/json" \
  -d '{
    "operationName": "WorkflowStatus",
    "query": "query WorkflowStatus($id: ID!) { workflows(id: $id) { id name status: scheduleStatus percentComplete blueprint { id name } stages { id name status } tags { id name } } }",
    "variables": { "id": "wf-98765" }
  }' | jq '.data.workflows[0]'
```

---

### ListWorkflowTemplates

- **Type:** query
- **Confidence:** Official API (not in `regrello/client.py`)

**GraphQL**

```graphql
query ListWorkflowTemplates(
  $id: ID
  $includeDeleted: Boolean
  $tagIds: [ID!]
  $types: [WorkflowTemplateType!]
) {
  workflowTemplates(
    id: $id
    includeDeleted: $includeDeleted
    tagIds: $tagIds
    types: $types
  ) {
    id
    name
  }
}
```

**Variables (company blueprints)**

```json
{
  "types": ["COMPANY"]
}
```

**Example response**

```json
{
  "data": {
    "workflowTemplates": [
      { "id": "11", "name": "Blueprint" },
      { "id": "253", "name": "Company Blueprint" }
    ]
  }
}
```

**cURL**

```bash
curl -sS -X POST "${GRAPHQL_URL}" \
  -H "Authorization: Bearer ${ACCESS_TOKEN}" \
  -H "Content-Type: application/json" \
  -d '{
    "query": "query { workflowTemplates(types: [COMPANY]) { id name } }"
  }'
```

---

### FieldsQueryV2

- **Type:** query
- **Confidence:** Official API (not in `regrello/client.py`)

Global field catalog (distinct from template `fieldInstances`).

**GraphQL**

```graphql
query FieldsQueryV2(
  $fieldId: ID
  $columnCustomizationTableSpecifier: ColumnCustomizationTableSpecifier
  $limit: Int
  $offset: Int
  $sortBy: CustomFieldDefaultColumnOption
  $sortOrder: SortOrder
) {
  fieldsV2(
    fieldId: $fieldId
    columnCustomizationTableSpecifier: $columnCustomizationTableSpecifier
    limit: $limit
    offset: $offset
    sortBy: $sortBy
    sortOrder: $sortOrder
  ) {
    fields {
      id
      name
      description
      isMultiValued
      fieldType
    }
    totalCount
  }
}
```

**Variables**

```json
{
  "offset": 0,
  "limit": 500,
  "sortOrder": "ASC",
  "sortBy": "FIELD"
}
```

**Example response**

```json
{
  "data": {
    "fieldsV2": {
      "fields": [
        {
          "id": "7",
          "name": "Supplier",
          "description": null,
          "isMultiValued": false,
          "fieldType": "STRING"
        }
      ],
      "totalCount": 1
    }
  }
}
```

**cURL**

```bash
curl -sS -X POST "${GRAPHQL_URL}" \
  -H "Authorization: Bearer ${ACCESS_TOKEN}" \
  -H "Content-Type: application/json" \
  -d '{
    "operationName": "FieldsQueryV2",
    "query": "query FieldsQueryV2($limit: Int, $offset: Int, $sortBy: CustomFieldDefaultColumnOption, $sortOrder: SortOrder) { fieldsV2(limit: $limit, offset: $offset, sortBy: $sortBy, sortOrder: $sortOrder) { fields { id name description isMultiValued fieldType } totalCount } }",
    "variables": { "offset": 0, "limit": 500, "sortOrder": "ASC", "sortBy": "FIELD" }
  }'
```

---

## Connector mapping

All Regrello operations go through the connector via **`POST /regrello/graphql`** (copy queries from GraphiQL) or **`POST /regrello/documents`** for file upload orchestration.

| Regrello operation | How to call the connector |
|--------------------|---------------------------|
| `WorkflowStatus`, `WorkflowTemplateFields`, `CreateWorkflowFromTemplateMutation`, etc. | `POST /regrello/graphql` — see [examples.md](examples.md) |
| Document create + PUT upload | `POST /regrello/documents`, then pass `document_id` in `createWorkflowFromTemplate` — see [examples.md](examples.md) |

See [tasks.md](tasks.md) for **ActionItem** (UI: Task) operations. Tenant samples: [workflow-req-res.md](workflow-req-res.md), [task-req-res.md](task-req-res.md). Lifecycle: [README.md](README.md#lifecycle).
