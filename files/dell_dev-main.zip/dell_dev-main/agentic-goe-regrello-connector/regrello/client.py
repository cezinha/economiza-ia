"""Regrello API client: OAuth, GraphQL proxy, and document upload orchestration.

Workflow and template operations use ``execute_graphql`` or the connector
``POST /regrello/graphql`` endpoint (see ``docs/examples.md``).
"""

from __future__ import annotations

import asyncio
import logging
import mimetypes
from collections.abc import Awaitable, Callable
from datetime import UTC, datetime, timedelta
from typing import Any, TypeVar

import httpx

from regrello.config import Settings

_DEFAULT_OAUTH_EXPIRES_IN = 3600
_TRANSPORT_RETRY_EXCEPTIONS = (
    httpx.ConnectError,
    httpx.ReadError,
    httpx.RemoteProtocolError,
    httpx.WriteError,
)

T = TypeVar("T")


class RegrelloClient:
    """Async client for Regrello API access.

    - OAuth2 client-credentials authentication with in-memory token cache
    - ``execute_graphql`` for any Regrello query or mutation
    - ``create_and_upload_document`` for GraphQL create + signed-URL PUT
    """

    def __init__(
        self,
        settings: Settings | None = None,
        client: httpx.AsyncClient | None = None,
        timeout: float | None = 30.0,
    ) -> None:
        """Initialize Regrello client.

        Args:
            settings: Configuration settings (loads from env if not provided)
            client: Optional httpx.AsyncClient for testing
            timeout: Request timeout in seconds
        """
        self._settings = settings or Settings()
        self._access_token: str | None = None
        self._token_expires_at: datetime | None = None
        self._auth_lock = asyncio.Lock()
        self._verify_ssl: bool = self._settings.regrello_verify_ssl

        base_url = self._settings.regrello_base_url.rstrip("/")
        self._token_url = f"{base_url}/oauth/{self._settings.regrello_workspace_id}/token"
        self._graphql_url = (
            f"{base_url}/customer/workspace/{self._settings.regrello_workspace_id}/query"
        )

        if not self._verify_ssl:
            logging.warning(
                "REGRELLO_VERIFY_SSL is false; SSL certificate verification is disabled"
            )

        self._client = client or httpx.AsyncClient(timeout=timeout, verify=self._verify_ssl)

    async def aclose(self) -> None:
        """Close the HTTP client."""
        await self._client.aclose()

    async def __aenter__(self) -> RegrelloClient:
        return self

    async def __aexit__(self, *exc: Any) -> None:  # type: ignore[override]
        await self.aclose()

    def _token_is_valid(self) -> bool:
        if not self._access_token or self._token_expires_at is None:
            return False
        return datetime.now(UTC) < self._token_expires_at

    async def _ensure_valid_token(self, *, force_refresh: bool = False) -> None:
        if not force_refresh and self._token_is_valid():
            return
        async with self._auth_lock:
            if not force_refresh and self._token_is_valid():
                return
            await self._fetch_token()

    def _store_token(self, access_token: str, expires_in: int) -> None:
        window = self._settings.regrello_token_validation_window
        effective_ttl = max(expires_in - window, 0)
        self._access_token = access_token
        self._token_expires_at = datetime.now(UTC) + timedelta(seconds=effective_ttl)

    def _invalidate_token(self) -> None:
        self._access_token = None
        self._token_expires_at = None

    async def _request_with_retry(
        self,
        request: Callable[[], Awaitable[T]],
    ) -> T:
        try:
            return await request()
        except _TRANSPORT_RETRY_EXCEPTIONS:
            return await request()

    async def authenticate(self) -> str:
        """Obtain OAuth2 access token using client credentials flow.

        Returns:
            Access token string

        Raises:
            RuntimeError: If authentication fails
        """
        await self._fetch_token()
        assert self._access_token is not None
        return self._access_token

    async def _fetch_token(self) -> None:
        headers = {"Content-Type": "application/x-www-form-urlencoded"}
        data = {
            "grant_type": "client_credentials",
            "client_id": self._settings.regrello_client_id,
            "client_secret": self._settings.regrello_client_secret,
        }

        async def _post_token() -> httpx.Response:
            return await self._client.post(self._token_url, headers=headers, data=data)

        try:
            response = await self._request_with_retry(_post_token)
            response.raise_for_status()
        except httpx.HTTPError as e:
            logging.error(f"Authentication failed: {e}")
            raise RuntimeError(f"Authentication failed: {e}") from e

        token_data = response.json()
        access_token = token_data.get("access_token")
        if not access_token:
            raise RuntimeError("No access token in response")

        expires_in = token_data.get("expires_in", _DEFAULT_OAUTH_EXPIRES_IN)
        if not isinstance(expires_in, int):
            expires_in = _DEFAULT_OAUTH_EXPIRES_IN

        self._store_token(access_token, expires_in)

    def _get_auth_headers(self) -> dict[str, str]:
        """Get headers with authorization token.

        Returns:
            Headers dict with Authorization and Content-Type

        Raises:
            RuntimeError: If not authenticated
        """
        if not self._access_token:
            raise RuntimeError("Not authenticated. Call authenticate() first.")

        return {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {self._access_token}",
        }

    def _build_graphql_payload(
        self,
        query: str,
        variables: dict[str, Any] | None = None,
        operation_name: str | None = None,
    ) -> dict[str, Any]:
        payload: dict[str, Any] = {"query": query}
        if variables:
            payload["variables"] = variables
        if operation_name:
            payload["operationName"] = operation_name
        return payload

    async def _post_graphql_payload(self, payload: dict[str, Any]) -> dict[str, Any]:
        """POST a GraphQL envelope and return the full JSON body."""
        await self._ensure_valid_token()
        headers = self._get_auth_headers()
        data: dict[str, Any] = {}

        async def _send(*, auth_headers: dict[str, str]) -> httpx.Response:
            return await self._client.post(
                self._graphql_url,
                headers=auth_headers,
                json=payload,
            )

        try:
            response = await self._request_with_retry(lambda: _send(auth_headers=headers))
            if response.status_code == 401:
                self._invalidate_token()
                await self._ensure_valid_token(force_refresh=True)
                response = await _send(auth_headers=self._get_auth_headers())

            data = response.json()
            logging.debug(f"GraphQL response data: {data}")
            response.raise_for_status()
        except httpx.HTTPError as e:
            logging.error(f"GraphQL request failed: {e} \n error \n {data}")
            raise RuntimeError(f"GraphQL request failed: {e} \n error \n {data}") from e
        return data

    async def execute_graphql(
        self,
        query: str,
        variables: dict[str, Any] | None = None,
        operation_name: str | None = None,
    ) -> dict[str, Any]:
        """Execute a GraphQL request and return the full Regrello JSON response.

        Unlike ``_graphql_request``, top-level ``errors`` are returned as-is
        (no ``RuntimeError``) so callers can handle GraphQL-level failures.
        """
        payload = self._build_graphql_payload(query, variables, operation_name)
        return await self._post_graphql_payload(payload)

    async def _graphql_request(
        self,
        query: str,
        variables: dict[str, Any] | None = None,
        operation_name: str | None = None,
    ) -> dict[str, Any]:
        """Execute a GraphQL request.

        Args:
            query: GraphQL query or mutation string
            variables: Query variables
            operation_name: Optional operation name

        Returns:
            Response data dict

        Raises:
            RuntimeError: If request fails or returns errors
        """
        payload = self._build_graphql_payload(query, variables, operation_name)
        data = await self._post_graphql_payload(payload)

        if "errors" in data:
            error_messages = [err.get("message", str(err)) for err in data["errors"]]
            raise RuntimeError(f"GraphQL errors: {', '.join(error_messages)}")

        return data.get("data", {})

    async def create_document(self, filename: str) -> tuple[str, str]:
        """Create a document and get a signed upload URL.

        Args:
            filename: Name of the document to create

        Returns:
            Tuple of (signed_url, document_id)

        Raises:
            RuntimeError: If document creation fails
        """
        query = """
        mutation CreateDocumentMutation($filename: String!) {
          createDocument(input: {name: $filename}) {
            error
            document { id name __typename }
            signedUrl
            __typename
          }
        }
        """

        data = await self._graphql_request(
            query=query,
            variables={"filename": filename},
            operation_name="CreateDocumentMutation",
        )

        create_result = data.get("createDocument", {})

        if create_result.get("error"):
            raise RuntimeError(f"Document creation error: {create_result['error']}")

        signed_url = create_result.get("signedUrl")
        document = create_result.get("document", {})
        document_id = document.get("id")

        if not signed_url or not document_id:
            raise RuntimeError("Missing signed URL or document ID in response")

        return signed_url, document_id

    async def upload_file_to_url(self, signed_url: str, file_content: bytes, filename: str) -> None:
        """Upload file content to a signed URL.

        Args:
            signed_url: Pre-signed upload URL from create_document
            file_content: File content as bytes
            filename: Original filename (used to determine MIME type)

        Raises:
            RuntimeError: If upload fails
        """
        mime_type, _ = mimetypes.guess_type(filename)
        mime_type = mime_type or "application/octet-stream"
        headers = {"Content-Type": mime_type}

        async def _put() -> httpx.Response:
            return await self._client.put(
                signed_url,
                content=file_content,
                headers=headers,
            )

        try:
            response = await self._request_with_retry(_put)
            response.raise_for_status()
        except httpx.HTTPError as e:
            raise RuntimeError(f"File upload failed: {e}") from e

    async def create_and_upload_document(self, filename: str, file_content: bytes) -> str:
        """Create a document and upload its content in one operation.

        Args:
            filename: Name of the document
            file_content: File content as bytes

        Returns:
            Document ID

        Raises:
            RuntimeError: If creation or upload fails
        """
        signed_url, document_id = await self.create_document(filename)
        await self.upload_file_to_url(signed_url, file_content, filename)
        return document_id
