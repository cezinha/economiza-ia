"""Configuration settings for the Regrello API client.

Loads credentials from environment variables and a `.env` file.
"""

from pathlib import Path

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """Application settings loaded from environment variables or `.env` file."""

    # Pydantic Settings configuration
    model_config = SettingsConfigDict(
        env_file=(
            str(Path.cwd() / ".env"),
            str(Path(__file__).resolve().parents[1] / ".env"),
        ),
        env_file_encoding="utf-8",
        env_prefix="",
        case_sensitive=False,
        extra="ignore",
    )

    # Regrello API configuration
    regrello_base_url: str
    regrello_workspace_id: str
    regrello_client_id: str
    regrello_client_secret: str

    # Optional: Workflow and field configurations
    regrello_workflow_template_id: int = 253

    # SSL verification (defaults to True for security). Set to False only in development/test
    # environments with self-signed certificates. Always use proper CA bundles in production.
    regrello_verify_ssl: bool = True

    # Seconds subtracted from OAuth ``expires_in`` before treating the token as expired.
    regrello_token_validation_window: int = 60
