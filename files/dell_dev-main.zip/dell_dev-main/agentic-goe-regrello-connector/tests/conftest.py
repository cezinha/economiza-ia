"""Pytest configuration: ensure Regrello env vars exist before `app.config` imports."""

from __future__ import annotations

import os

# Do not read repo `.env` during tests (local developer files would change backend/mode).
os.environ["REGRELLO_CONNECTOR_DISABLE_DOTENV"] = "1"

# Required by `app.config.Settings` at import time — set before importing application modules.
os.environ.setdefault("REGRELLO_BASE_URL", "https://regrello.example")
os.environ.setdefault("REGRELLO_WORKSPACE_ID", "workspace-test")
os.environ.setdefault("REGRELLO_CLIENT_ID", "client-id-test")
os.environ.setdefault("REGRELLO_CLIENT_SECRET", "client-secret-test")
os.environ.setdefault("REGRELLO_TOKEN_VALIDATION_WINDOW", "60")
os.environ["REGRELLO_CONNECTOR_INBOUND_AUTH_ENABLED"] = "false"
