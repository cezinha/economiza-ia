"""``get_regrello_backend`` lifecycle and backend delegation."""

from __future__ import annotations

from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from app.deps import get_regrello_backend
from app.http.backend import RegrelloHttpBackend
from app.http.registry import init_http_backend, reset_http_backend_for_tests
from app.memory.backend import RegrelloMemoryBackend


@pytest.fixture(autouse=True)
def _reset_http_registry() -> None:
    reset_http_backend_for_tests()
    yield
    reset_http_backend_for_tests()


@pytest.mark.asyncio
async def test_get_regrello_backend_memory_aclose(tmp_path: Path) -> None:
    p = tmp_path / "fx.json"
    p.write_text(
        '{"graphql_responses":{"default":{"data":{}}},"document_upload":{"default":{"document_id":"d"}}}',
        encoding="utf-8",
    )
    fake = MagicMock()
    fake.regrello_connector_backend = "memory"
    fake.regrello_connector_memory_fixtures_path = p

    with patch("app.deps.settings", fake):
        gen = get_regrello_backend()
        backend = await gen.__anext__()
        assert isinstance(backend, RegrelloMemoryBackend)
        await gen.aclose()


@pytest.mark.asyncio
async def test_get_regrello_backend_http_yields_shared_singleton() -> None:
    mock_client = MagicMock()
    mock_client.aclose = AsyncMock()

    with patch("app.http.registry.create_regrello_client", return_value=mock_client):
        init_http_backend(MagicMock())
        gen = get_regrello_backend()
        first = await gen.__anext__()
        await gen.aclose()

        gen2 = get_regrello_backend()
        second = await gen2.__anext__()
        await gen2.aclose()

    assert isinstance(first, RegrelloHttpBackend)
    assert first is second
    mock_client.aclose.assert_not_awaited()


@pytest.mark.asyncio
async def test_regrello_http_backend_delegates_to_client() -> None:
    mock_client = MagicMock()
    mock_client.execute_graphql = AsyncMock(return_value={"data": {"x": 1}, "errors": []})
    mock_client.create_and_upload_document = AsyncMock(return_value="doc-99")
    mock_client.aclose = AsyncMock()

    backend = RegrelloHttpBackend(mock_client)
    await backend.execute_graphql("query Q { __typename }", {}, "Q")
    await backend.upload_document("f.pdf", b"content")
    await backend.aclose()

    mock_client.execute_graphql.assert_awaited_once()
    mock_client.create_and_upload_document.assert_awaited_once_with("f.pdf", b"content")
    mock_client.aclose.assert_awaited_once()


@pytest.mark.asyncio
async def test_get_regrello_backend_rejects_unknown_mode() -> None:
    fake = MagicMock()
    fake.regrello_connector_backend = "bogus"  # type: ignore[assignment]
    with patch("app.deps.settings", fake):
        gen = get_regrello_backend()
        with pytest.raises(RuntimeError, match="Unsupported"):
            await gen.__anext__()
