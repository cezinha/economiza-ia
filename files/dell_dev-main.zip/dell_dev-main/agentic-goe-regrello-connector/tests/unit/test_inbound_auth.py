"""Unit tests for OAuth token introspection client."""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch

import httpx
import pytest

from app.auth.introspection import IntrospectionUnavailableError, is_token_active
from app.config import Settings


def _settings() -> Settings:
    return Settings(
        regrello_connector_backend="http",
        regrello_base_url="https://example",
        regrello_workspace_id="w",
        regrello_client_id="c",
        regrello_client_secret="s",
        regrello_connector_inbound_auth_enabled=True,
        regrello_connector_oauth_introspection_base_url="https://auth.example.com",
        regrello_connector_oauth_introspection_path="/v1/introspect",
        regrello_connector_oauth_introspection_client_id="intro-id",
        regrello_connector_oauth_introspection_client_secret="intro-secret",
    )


@pytest.mark.asyncio
async def test_is_token_active_true() -> None:
    mock_response = MagicMock()
    mock_response.raise_for_status = MagicMock()
    mock_response.json.return_value = {"active": True}

    mock_client = AsyncMock()
    mock_client.post = AsyncMock(return_value=mock_response)
    mock_client.__aenter__ = AsyncMock(return_value=mock_client)
    mock_client.__aexit__ = AsyncMock(return_value=None)

    with patch("app.auth.introspection.httpx.AsyncClient", return_value=mock_client):
        assert await is_token_active("caller-token", settings=_settings()) is True

    mock_client.post.assert_awaited_once()
    call_kwargs = mock_client.post.await_args.kwargs
    assert call_kwargs["data"] == {
        "token": "caller-token",
        "token_type_hint": "access_token",
    }


@pytest.mark.asyncio
async def test_is_token_active_false() -> None:
    mock_response = MagicMock()
    mock_response.raise_for_status = MagicMock()
    mock_response.json.return_value = {"active": False}

    mock_client = AsyncMock()
    mock_client.post = AsyncMock(return_value=mock_response)
    mock_client.__aenter__ = AsyncMock(return_value=mock_client)
    mock_client.__aexit__ = AsyncMock(return_value=None)

    with patch("app.auth.introspection.httpx.AsyncClient", return_value=mock_client):
        assert await is_token_active("caller-token", settings=_settings()) is False


@pytest.mark.asyncio
async def test_is_token_active_missing_active_field() -> None:
    mock_response = MagicMock()
    mock_response.raise_for_status = MagicMock()
    mock_response.json.return_value = {}

    mock_client = AsyncMock()
    mock_client.post = AsyncMock(return_value=mock_response)
    mock_client.__aenter__ = AsyncMock(return_value=mock_client)
    mock_client.__aexit__ = AsyncMock(return_value=None)

    with patch("app.auth.introspection.httpx.AsyncClient", return_value=mock_client):
        assert await is_token_active("caller-token", settings=_settings()) is False


@pytest.mark.asyncio
async def test_is_token_active_http_error_raises_unavailable() -> None:
    mock_client = AsyncMock()
    mock_client.post = AsyncMock(side_effect=httpx.TimeoutException("timeout"))
    mock_client.__aenter__ = AsyncMock(return_value=mock_client)
    mock_client.__aexit__ = AsyncMock(return_value=None)

    with (
        patch("app.auth.introspection.httpx.AsyncClient", return_value=mock_client),
        pytest.raises(IntrospectionUnavailableError),
    ):
        await is_token_active("caller-token", settings=_settings())


@pytest.mark.asyncio
async def test_is_token_active_invalid_json_raises_unavailable() -> None:
    mock_response = MagicMock()
    mock_response.raise_for_status = MagicMock()
    mock_response.json.side_effect = ValueError("not json")

    mock_client = AsyncMock()
    mock_client.post = AsyncMock(return_value=mock_response)
    mock_client.__aenter__ = AsyncMock(return_value=mock_client)
    mock_client.__aexit__ = AsyncMock(return_value=None)

    with (
        patch("app.auth.introspection.httpx.AsyncClient", return_value=mock_client),
        pytest.raises(IntrospectionUnavailableError),
    ):
        await is_token_active("caller-token", settings=_settings())
