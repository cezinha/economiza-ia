"""Settings validation for inbound OAuth introspection."""

from __future__ import annotations

from pathlib import Path

import pytest
from pydantic import ValidationError

from app.config import Settings


def _http_env(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("REGRELLO_CONNECTOR_BACKEND", "http")
    monkeypatch.setenv("REGRELLO_BASE_URL", "https://example")
    monkeypatch.setenv("REGRELLO_WORKSPACE_ID", "w")
    monkeypatch.setenv("REGRELLO_CLIENT_ID", "c")
    monkeypatch.setenv("REGRELLO_CLIENT_SECRET", "s")


def _inbound_env(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("REGRELLO_CONNECTOR_INBOUND_AUTH_ENABLED", "true")
    monkeypatch.setenv(
        "REGRELLO_CONNECTOR_OAUTH_INTROSPECTION_BASE_URL",
        "https://auth.example.com/oauth2/default",
    )
    monkeypatch.setenv("REGRELLO_CONNECTOR_OAUTH_INTROSPECTION_PATH", "/v1/introspect")
    monkeypatch.setenv("REGRELLO_CONNECTOR_OAUTH_INTROSPECTION_CLIENT_ID", "intro-client")
    monkeypatch.setenv("REGRELLO_CONNECTOR_OAUTH_INTROSPECTION_CLIENT_SECRET", "intro-secret")


def test_inbound_auth_disabled_does_not_require_introspection(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    _http_env(monkeypatch)
    monkeypatch.setenv("REGRELLO_CONNECTOR_INBOUND_AUTH_ENABLED", "false")
    s = Settings()
    assert s.regrello_connector_inbound_auth_enabled is False


def test_inbound_auth_enabled_requires_base_url(monkeypatch: pytest.MonkeyPatch) -> None:
    _http_env(monkeypatch)
    _inbound_env(monkeypatch)
    monkeypatch.setenv("REGRELLO_CONNECTOR_OAUTH_INTROSPECTION_BASE_URL", "")
    with pytest.raises(ValidationError, match="REGRELLO_CONNECTOR_OAUTH_INTROSPECTION_BASE_URL"):
        Settings()


def test_inbound_auth_enabled_requires_path(monkeypatch: pytest.MonkeyPatch) -> None:
    _http_env(monkeypatch)
    _inbound_env(monkeypatch)
    monkeypatch.setenv("REGRELLO_CONNECTOR_OAUTH_INTROSPECTION_PATH", "")
    with pytest.raises(ValidationError, match="REGRELLO_CONNECTOR_OAUTH_INTROSPECTION_PATH"):
        Settings()


def test_inbound_auth_enabled_requires_client_id(monkeypatch: pytest.MonkeyPatch) -> None:
    _http_env(monkeypatch)
    _inbound_env(monkeypatch)
    monkeypatch.setenv("REGRELLO_CONNECTOR_OAUTH_INTROSPECTION_CLIENT_ID", "")
    with pytest.raises(ValidationError, match="REGRELLO_CONNECTOR_OAUTH_INTROSPECTION_CLIENT_ID"):
        Settings()


def test_inbound_auth_enabled_requires_client_secret(monkeypatch: pytest.MonkeyPatch) -> None:
    _http_env(monkeypatch)
    _inbound_env(monkeypatch)
    monkeypatch.setenv("REGRELLO_CONNECTOR_OAUTH_INTROSPECTION_CLIENT_SECRET", "")
    with pytest.raises(ValidationError, match="REGRELLO_CONNECTOR_OAUTH_INTROSPECTION_CLIENT_SECRET"):
        Settings()


def test_introspection_url_composed(monkeypatch: pytest.MonkeyPatch) -> None:
    _http_env(monkeypatch)
    _inbound_env(monkeypatch)
    s = Settings()
    assert s.introspection_url == "https://auth.example.com/oauth2/default/v1/introspect"


def test_inbound_auth_skip_paths_parsed(monkeypatch: pytest.MonkeyPatch) -> None:
    _http_env(monkeypatch)
    monkeypatch.setenv("REGRELLO_CONNECTOR_INBOUND_AUTH_SKIP_PATHS", "/health, /metrics ,/status")
    s = Settings()
    assert s.inbound_auth_skip_paths_list == ["/health", "/metrics", "/status"]


def test_introspection_path_normalized_without_leading_slash(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    _http_env(monkeypatch)
    _inbound_env(monkeypatch)
    monkeypatch.setenv("REGRELLO_CONNECTOR_OAUTH_INTROSPECTION_PATH", "v1/introspect")
    s = Settings()
    assert s.introspection_url == "https://auth.example.com/oauth2/default/v1/introspect"


def test_inbound_auth_enabled_with_memory_backend(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    p = tmp_path / "fx.json"
    p.write_text("{}", encoding="utf-8")
    monkeypatch.setenv("REGRELLO_CONNECTOR_BACKEND", "memory")
    monkeypatch.setenv("REGRELLO_CONNECTOR_MEMORY_FIXTURES_PATH", str(p))
    _inbound_env(monkeypatch)
    s = Settings()
    assert s.regrello_connector_inbound_auth_enabled is True
