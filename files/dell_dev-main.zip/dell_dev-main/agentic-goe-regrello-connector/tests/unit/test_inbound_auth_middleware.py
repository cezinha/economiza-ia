"""Middleware tests for inbound OAuth token validation."""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from fastapi.testclient import TestClient

from app.auth.introspection import IntrospectionUnavailableError
from app.config import settings
from app.deps import get_regrello_backend
from app.main import app


@pytest.fixture
def mock_backend() -> MagicMock:
    backend = MagicMock()
    backend.execute_graphql = AsyncMock(
        return_value={"data": {"workflows": []}, "errors": None},
    )
    backend.upload_document = AsyncMock(return_value="doc-1")
    backend.aclose = AsyncMock()
    return backend


@pytest.fixture
def client_with_mock(mock_backend: MagicMock) -> TestClient:
    async def _override():
        yield mock_backend

    app.dependency_overrides[get_regrello_backend] = _override
    yield TestClient(app)
    app.dependency_overrides.clear()


@pytest.fixture
def enable_inbound_auth(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(settings, "regrello_connector_inbound_auth_enabled", True)
    monkeypatch.setattr(
        settings,
        "regrello_connector_inbound_auth_skip_paths",
        "/health,/metrics,/status",
    )


def test_auth_disabled_allows_graphql_without_header(client_with_mock: TestClient) -> None:
    response = client_with_mock.post(
        "/regrello/graphql",
        json={"query": "query { __typename }"},
    )
    assert response.status_code == 200


def test_auth_enabled_skip_health_without_header(
    client_with_mock: TestClient,
    enable_inbound_auth: None,
) -> None:
    response = client_with_mock.get("/health")
    assert response.status_code == 200


def test_auth_enabled_graphql_without_header_returns_401(
    client_with_mock: TestClient,
    enable_inbound_auth: None,
) -> None:
    response = client_with_mock.post(
        "/regrello/graphql",
        json={"query": "query { __typename }"},
    )
    assert response.status_code == 401
    assert response.json()["detail"] == "Not authenticated"


def test_auth_enabled_invalid_authorization_header_returns_401(
    client_with_mock: TestClient,
    enable_inbound_auth: None,
) -> None:
    response = client_with_mock.post(
        "/regrello/graphql",
        json={"query": "query { __typename }"},
        headers={"Authorization": "Basic abc"},
    )
    assert response.status_code == 401
    assert "Invalid Authorization header" in response.json()["detail"]


@patch("app.auth.middleware.is_token_active", new_callable=AsyncMock)
def test_auth_enabled_inactive_token_returns_401(
    mock_is_active: AsyncMock,
    client_with_mock: TestClient,
    enable_inbound_auth: None,
) -> None:
    mock_is_active.return_value = False
    response = client_with_mock.post(
        "/regrello/graphql",
        json={"query": "query { __typename }"},
        headers={"Authorization": "Bearer inactive-token"},
    )
    assert response.status_code == 401
    assert response.json()["detail"] == "Invalid or inactive token"


@patch("app.auth.middleware.is_token_active", new_callable=AsyncMock)
def test_auth_enabled_active_token_allows_graphql(
    mock_is_active: AsyncMock,
    client_with_mock: TestClient,
    enable_inbound_auth: None,
) -> None:
    mock_is_active.return_value = True
    response = client_with_mock.post(
        "/regrello/graphql",
        json={"query": "query { __typename }"},
        headers={"Authorization": "Bearer valid-token"},
    )
    assert response.status_code == 200


@patch("app.auth.middleware.is_token_active", new_callable=AsyncMock)
def test_auth_enabled_introspection_unavailable_returns_503(
    mock_is_active: AsyncMock,
    client_with_mock: TestClient,
    enable_inbound_auth: None,
) -> None:
    mock_is_active.side_effect = IntrospectionUnavailableError("down")
    response = client_with_mock.post(
        "/regrello/graphql",
        json={"query": "query { __typename }"},
        headers={"Authorization": "Bearer any-token"},
    )
    assert response.status_code == 503
    assert response.json()["detail"] == "Token validation unavailable"
