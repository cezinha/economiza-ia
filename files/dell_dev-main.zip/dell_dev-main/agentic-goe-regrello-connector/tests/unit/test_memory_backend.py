"""``RegrelloMemoryBackend`` fixture resolution tests."""

from __future__ import annotations

from pathlib import Path

import pytest

from app.memory.backend import RegrelloMemoryBackend


@pytest.mark.asyncio
async def test_memory_backend_graphql_and_documents() -> None:
    path = Path(__file__).resolve().parent.parent / "fixtures" / "regrello_memory_minimal.json"
    backend = RegrelloMemoryBackend.from_path(path)

    gql_named = await backend.execute_graphql(
        "query WorkflowStatus { __typename }",
        {},
        "WorkflowStatus",
    )
    assert gql_named["data"]["workflows"][0]["id"] == "wf-known"

    gql_default = await backend.execute_graphql("query Q { __typename }", None, "OtherOp")
    assert gql_default["data"]["workflows"] == []

    doc_id = await backend.upload_document("any.pdf", b"bytes")
    assert doc_id == "mem-doc-1"

    await backend.aclose()


@pytest.mark.asyncio
async def test_memory_backend_validation_errors(tmp_path: Path) -> None:
    bad_root = tmp_path / "array.json"
    bad_root.write_text("[]", encoding="utf-8")
    with pytest.raises(ValueError, match="object"):
        RegrelloMemoryBackend.from_path(bad_root)

    with pytest.raises(ValueError, match="graphql_responses"):
        await RegrelloMemoryBackend(
            {"document_upload": {"default": {"document_id": "1"}}},
        ).execute_graphql("query Q { __typename }", None, "Missing")

    with pytest.raises(ValueError, match="document_upload"):
        await RegrelloMemoryBackend(
            {"graphql_responses": {"default": {"data": {}}}},
        ).upload_document("f.pdf", b"x")

    bad_doc = tmp_path / "bad_doc.json"
    bad_doc.write_text(
        '{"graphql_responses":{"default":{"data":{}}},"document_upload":{"default":{}}}',
        encoding="utf-8",
    )
    b = RegrelloMemoryBackend.from_path(bad_doc)
    with pytest.raises(ValueError, match="document_id"):
        await b.upload_document("f.pdf", b"x")
