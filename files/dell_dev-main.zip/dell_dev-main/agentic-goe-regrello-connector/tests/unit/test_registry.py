"""Unit tests for the shared HTTP backend registry."""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from app.config import settings as live_settings
from app.http.registry import (
    close_http_backend,
    get_http_backend,
    init_http_backend,
    reset_http_backend_for_tests,
)


@pytest.fixture(autouse=True)
def _reset_registry() -> None:
    reset_http_backend_for_tests()
    yield
    reset_http_backend_for_tests()


@pytest.mark.asyncio
async def test_init_returns_same_singleton_instance() -> None:
    mock_client = MagicMock()
    mock_client.aclose = AsyncMock()

    with patch("app.http.registry.create_regrello_client", return_value=mock_client):
        first = init_http_backend(live_settings)
        second = get_http_backend()

    assert first is second


@pytest.mark.asyncio
async def test_close_clears_registry() -> None:
    mock_client = MagicMock()
    mock_client.aclose = AsyncMock()

    with patch("app.http.registry.create_regrello_client", return_value=mock_client):
        init_http_backend(live_settings)
        await close_http_backend()

    with pytest.raises(RuntimeError, match="not initialized"):
        get_http_backend()

    mock_client.aclose.assert_awaited_once()
