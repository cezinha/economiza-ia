"""Regrello API route tests with mocked backend."""

import base64
from unittest.mock import AsyncMock, MagicMock

import pytest
from fastapi.testclient import TestClient

from app.main import app
from app.deps import get_regrello_backend


@pytest.fixture
def mock_backend() -> MagicMock:
    backend = MagicMock()
    backend.execute_graphql = AsyncMock(
        return_value={"data": {"workflows": []}, "errors": None},
    )
    backend.upload_document = AsyncMock(return_value="doc-1")
    backend.aclose = AsyncMock()
    return backend


@pytest.fixture
def client_with_mock(mock_backend: MagicMock) -> TestClient:
    async def _override():
        yield mock_backend

    app.dependency_overrides[get_regrello_backend] = _override
    yield TestClient(app)
    app.dependency_overrides.clear()


def test_execute_graphql(client_with_mock: TestClient, mock_backend: MagicMock) -> None:
    """POST `/regrello/graphql` delegates to ``execute_graphql``."""

    response = client_with_mock.post(
        "/regrello/graphql",
        json={
            "operationName": "WorkflowStatus",
            "query": "query WorkflowStatus { __typename }",
            "variables": {},
        },
    )
    assert response.status_code == 200
    assert response.json() == {"data": {"workflows": []}, "errors": None}
    mock_backend.execute_graphql.assert_awaited_once_with(
        query="query WorkflowStatus { __typename }",
        variables={},
        operation_name="WorkflowStatus",
    )


def test_execute_graphql_502_on_backend_error(
    client_with_mock: TestClient,
    mock_backend: MagicMock,
) -> None:
    mock_backend.execute_graphql = AsyncMock(side_effect=ValueError("bad graphql"))
    response = client_with_mock.post(
        "/regrello/graphql",
        json={"query": "query Q { __typename }"},
    )
    assert response.status_code == 502


def test_workflows_routes_removed(client_with_mock: TestClient) -> None:
    """Legacy ``/workflows`` routes are not registered."""

    assert client_with_mock.post("/workflows", json={"field_instances": []}).status_code == 404
    assert client_with_mock.get("/workflows/wf-1/status").status_code == 404
    assert client_with_mock.get("/workflows/template/fields").status_code == 404


def test_upload_document(client_with_mock: TestClient, mock_backend: MagicMock) -> None:
    raw = b"pdf-bytes"
    response = client_with_mock.post(
        "/regrello/documents",
        json={
            "filename": "test.pdf",
            "content_base64": base64.b64encode(raw).decode("ascii"),
        },
    )
    assert response.status_code == 200
    assert response.json() == {"document_id": "doc-1"}
    mock_backend.upload_document.assert_awaited_once_with("test.pdf", raw)


def test_upload_document_invalid_base64(client_with_mock: TestClient) -> None:
    response = client_with_mock.post(
        "/regrello/documents",
        json={"filename": "a.bin", "content_base64": "not-valid-base64!!!"},
    )
    assert response.status_code == 400


def test_upload_document_502_on_backend_error(
    client_with_mock: TestClient,
    mock_backend: MagicMock,
) -> None:
    mock_backend.upload_document = AsyncMock(side_effect=RuntimeError("upload failed"))
    response = client_with_mock.post(
        "/regrello/documents",
        json={
            "filename": "a.pdf",
            "content_base64": base64.b64encode(b"x").decode("ascii"),
        },
    )
    assert response.status_code == 502
