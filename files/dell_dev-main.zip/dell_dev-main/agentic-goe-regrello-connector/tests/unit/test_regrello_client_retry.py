"""Unit tests for RegrelloClient transport retry behavior."""

from __future__ import annotations

from datetime import UTC, datetime, timedelta
from unittest.mock import AsyncMock, MagicMock

import httpx
import pytest

from regrello.client import RegrelloClient
from regrello.config import Settings


def _settings() -> Settings:
    return Settings(
        regrello_base_url="https://tenant.regrello.com",
        regrello_workspace_id="ws",
        regrello_client_id="id",
        regrello_client_secret="secret",
    )


def _seed_token(client: RegrelloClient) -> None:
    client._access_token = "token"
    client._token_expires_at = datetime.now(UTC) + timedelta(hours=1)


@pytest.mark.asyncio
async def test_graphql_retries_once_on_connect_error() -> None:
    mock_http = MagicMock()
    ok_response = MagicMock()
    ok_response.status_code = 200
    ok_response.json.return_value = {"data": {"x": 1}}
    ok_response.raise_for_status = MagicMock()

    mock_http.post = AsyncMock(
        side_effect=[
            httpx.ConnectError("stale connection"),
            ok_response,
        ]
    )

    client = RegrelloClient(settings=_settings(), client=mock_http)
    _seed_token(client)

    result = await client.execute_graphql("query Q { x }")

    assert result == {"data": {"x": 1}}
    assert mock_http.post.await_count == 2


@pytest.mark.asyncio
async def test_graphql_does_not_retry_on_http_502() -> None:
    mock_http = MagicMock()
    bad_response = MagicMock()
    bad_response.status_code = 502
    bad_response.json.return_value = {}
    bad_response.raise_for_status.side_effect = httpx.HTTPStatusError(
        "Bad Gateway",
        request=MagicMock(),
        response=bad_response,
    )
    mock_http.post = AsyncMock(return_value=bad_response)

    client = RegrelloClient(settings=_settings(), client=mock_http)
    _seed_token(client)

    with pytest.raises(RuntimeError, match="GraphQL request failed"):
        await client.execute_graphql("query Q { x }")

    mock_http.post.assert_awaited_once()


@pytest.mark.asyncio
async def test_graphql_retries_once_on_401_after_token_refresh() -> None:
    mock_http = MagicMock()
    unauthorized = MagicMock()
    unauthorized.status_code = 401
    unauthorized.json.return_value = {}
    unauthorized.raise_for_status = MagicMock()

    ok_response = MagicMock()
    ok_response.status_code = 200
    ok_response.json.return_value = {"data": {"ok": True}}
    ok_response.raise_for_status = MagicMock()

    oauth_response = MagicMock()
    oauth_response.raise_for_status = MagicMock()
    oauth_response.json.return_value = {
        "access_token": "new-token",
        "expires_in": 3600,
    }

    mock_http.post = AsyncMock(
        side_effect=[
            unauthorized,
            oauth_response,
            ok_response,
        ]
    )

    client = RegrelloClient(settings=_settings(), client=mock_http)
    _seed_token(client)

    result = await client.execute_graphql("query Q { ok }")

    assert result == {"data": {"ok": True}}
    assert mock_http.post.await_count == 3
