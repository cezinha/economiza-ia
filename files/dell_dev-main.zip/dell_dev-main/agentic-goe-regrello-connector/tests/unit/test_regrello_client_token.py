"""Unit tests for RegrelloClient OAuth token caching."""

from __future__ import annotations

import asyncio
from datetime import UTC, datetime, timedelta
from unittest.mock import AsyncMock, MagicMock

import httpx
import pytest

from regrello.client import RegrelloClient
from regrello.config import Settings


def _settings() -> Settings:
    return Settings(
        regrello_base_url="https://tenant.regrello.com",
        regrello_workspace_id="ws",
        regrello_client_id="id",
        regrello_client_secret="secret",
        regrello_token_validation_window=60,
    )


def _oauth_response(*, access_token: str = "tok", expires_in: int = 3600) -> MagicMock:
    response = MagicMock()
    response.raise_for_status = MagicMock()
    response.json.return_value = {
        "access_token": access_token,
        "token_type": "Bearer",
        "expires_in": expires_in,
    }
    return response


@pytest.mark.asyncio
async def test_fetch_token_stores_expiry_with_validation_window() -> None:
    mock_http = MagicMock()
    mock_http.post = AsyncMock(return_value=_oauth_response(expires_in=3600))

    client = RegrelloClient(settings=_settings(), client=mock_http)
    await client.authenticate()

    assert client._access_token == "tok"
    assert client._token_expires_at is not None
    expected = datetime.now(UTC) + timedelta(seconds=3600 - 60)
    assert abs((client._token_expires_at - expected).total_seconds()) < 2


@pytest.mark.asyncio
async def test_ensure_valid_token_reuses_cached_token() -> None:
    mock_http = MagicMock()
    mock_http.post = AsyncMock(return_value=_oauth_response())

    client = RegrelloClient(settings=_settings(), client=mock_http)
    await client._ensure_valid_token()
    await client._ensure_valid_token()

    mock_http.post.assert_awaited_once()


@pytest.mark.asyncio
async def test_ensure_valid_token_refreshes_when_expired() -> None:
    mock_http = MagicMock()
    mock_http.post = AsyncMock(return_value=_oauth_response(access_token="tok2"))

    client = RegrelloClient(settings=_settings(), client=mock_http)
    client._access_token = "tok1"
    client._token_expires_at = datetime.now(UTC) - timedelta(seconds=1)

    await client._ensure_valid_token()

    assert client._access_token == "tok2"
    mock_http.post.assert_awaited_once()


@pytest.mark.asyncio
async def test_concurrent_refresh_fetches_token_once() -> None:
    mock_http = MagicMock()
    mock_http.post = AsyncMock(return_value=_oauth_response())

    client = RegrelloClient(settings=_settings(), client=mock_http)
    client._access_token = None
    client._token_expires_at = None

    await asyncio.gather(
        client._ensure_valid_token(),
        client._ensure_valid_token(),
    )

    mock_http.post.assert_awaited_once()
