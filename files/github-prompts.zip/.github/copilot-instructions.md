# Copilot Instructions - React to Angular Migration (Lean)

## Mission
- Migrate React code to Angular safely, incrementally, and with minimal behavior changes.
- Keep API contracts, business rules, and UX consistent unless explicitly requested.

## Target Stack
- Angular standalone components (no NgModules).
- Tailwind CSS v4 via PostCSS.
- State with Signal Store (@ngrx/signals).
- Atomic Design structure (atoms, molecules, organisms, pages/features).
- Transloco i18n with en.
- ESLint for static analysis.
- Prettier for code formatting.

## Migration Strategy
- Define and validate a migration plan before implementing code.
- Migrate feature-by-feature, not file-by-file.
- Preserve route paths, payload shapes, validation rules, and error states.
- Do not mix migration with broad refactors.
- Keep route definitions in src/app/app.routes.ts.

## React to Angular Mapping
- Function component -> standalone Angular component.
- Props -> @Input() and @Output() events.
- useState/useReducer -> signals or Signal Store state/methods.
- useEffect -> lifecycle hooks (ngOnInit/ngOnDestroy) and RxJS subscriptions.
- React Router -> Angular Router.
- Context -> injected service/store.
- React Query/SWR -> service + HttpClient + cache/state layer.
- JSX conditional/render lists -> Angular template syntax (@if/@for or *ngIf/*ngFor).

## Rules During Conversion
- Atoms and molecules: no store/service access.
- Organisms: compose UI, use typed inputs/outputs.
- Pages/features: only layer that injects store/services and orchestrates flow.
- Move API calls to services.
- Type models, service contracts, and component inputs/outputs explicitly.
- Reuse existing Angular patterns from the target codebase.
- Prefer explicit event names (itemSelected, userRemoved, closed).
- Keep changes lint-clean and Prettier-formatted.

## Styling and i18n
- Preserve visual behavior first; optimize later.
- Use Tailwind utility classes in templates and avoid inline styles.
- Add translated keys in src/assets/i18n/en.json.
- Use Transloco in templates and switch language through TranslocoService when needed.

## Angular-specific Styling Rules (from migration experience)
- **Global border color**: `src/styles.css` already has `* { border-color: hsl(var(--border)); }` mirroring React's `@apply border-border` reset. Do not add `border-border` per element — it is already inherited globally.
- **CSS utility escaping**: custom Tailwind-like utilities that use `/` in the class name (e.g. `bg-success/20`, `bg-primary/10`) must be defined with an escaped backslash in the selector: `.bg-success\/20 { ... }`. Without the escape the browser never matches the class.
- **Check `src/styles.css`** for existing utility variants (e.g. `bg-success\/15`, `bg-primary\/10`) before adding new ones; follow the same escape pattern already used in the file.
- **`space-y-*` vs `gap-*`**: `space-y-*` uses CSS `> * + *` selectors which break when Angular component host elements have `display: inline` (the default). Always use `flex flex-col gap-*` on containers whose direct children are Angular components (`<app-*>`).
- **Table cell heights**: match React's shadcn/ui `TableHead` (`h-12 px-4 align-middle`) and `TableCell` (`p-4 align-middle`) defaults. Use those as baseline for `<th>` and `<td>` in migrated tables.
- **thead text color**: `<th>` elements default to `text-muted-foreground`. Override per column only when the React source explicitly passes a different color (e.g. `text-primary` for highlighted headers). Use `[ngClass]="headerClass || 'text-muted-foreground'"` to keep the fallback clean.
- **Lazy routes for heavy features**: all new feature pages must be registered with `loadComponent` in `app.routes.ts` to keep the initial bundle below budget.

## Validation Checklist (Per Feature)
- Routes and navigation behave the same.
- Forms keep validation and error messages.
- Loading, empty, and error states are equivalent.
- Events/callback side effects still happen.
- Atomic layer boundaries are respected (no business logic leakage to UI layers).
- Unit tests cover primary migrated behavior.
- Lint passes for touched files.
- Formatting matches Prettier output.

## Copilot Response Style
- Start by proposing a short migration plan (scope, phases, risks, and checkpoints).
- Explain migration decisions briefly.
- List files changed and notable trade-offs.
- Flag unknowns and assumptions early.
