# React → Angular Migration Agent Team

This folder contains a set of **Copilot Agent Mode** prompt files (`.prompt.md`) that form a coordinated migration team. Each file defines a specialist agent with a focused responsibility.

## Team overview

| Agent file | Role | When to invoke |
|---|---|---|
| `migration-orchestrator.prompt.md` | Coordinates the whole migration, tracks progress, enforces the checklist | **Start here** for any new feature migration |
| `migration-analyst.prompt.md` | Reads React source, produces a structured `MigrationSpec` | Before any code is written for a feature |
| `component-builder.prompt.md` | Creates Angular standalone components (atoms → pages) | After the analyst produces the spec |
| `state-migrator.prompt.md` | Migrates state (signals, Signal Store, HttpClient services) | After components are scaffolded |
| `router-migrator.prompt.md` | Migrates routes and navigation to Angular Router | When a feature has route changes |
| `i18n-agent.prompt.md` | Extracts strings into `en.json` and adds Transloco bindings | After templates are built |
| `test-writer.prompt.md` | Writes unit tests for components, stores, and services | After implementation is complete |
| `quality-guard.prompt.md` | Runs lint/format/tsc checks and signs off the validation checklist | Last step before marking a feature DONE |

## How to use in VS Code

### Prerequisite
Enable **Agent Mode** in VS Code Copilot Chat (requires Copilot subscription with agent features).

### Starting a migration

1. Open Copilot Chat in VS Code (`Ctrl+Shift+I` / `Cmd+Shift+I`).
2. Switch to **Agent mode**.
3. Reference the orchestrator:

```
@workspace #file:.github/prompts/migration-orchestrator.prompt.md

Migrate the React feature at src/pages/Items to Angular.
```

4. The Orchestrator will guide the session, delegating to specialist agents as needed.

### Invoking a specialist directly

If you want to skip orchestration and run a single agent:

```
@workspace #file:.github/prompts/migration-analyst.prompt.md

Analyse the React component at src/components/ItemList.tsx
```

### Chaining agents manually

```
@workspace #file:.github/prompts/migration-analyst.prompt.md
Analyse src/pages/Dashboard.tsx

--- (after output) ---

@workspace #file:.github/prompts/component-builder.prompt.md
Use the MigrationSpec above and build the Angular components.

--- (after output) ---

@workspace #file:.github/prompts/quality-guard.prompt.md
Run the quality gate on the dashboard feature.
```

## Workflow diagram

```
User: "Migrate feature X"
        │
        ▼
┌─────────────────────┐
│  Orchestrator       │ ◄── coordinates everything
└──────┬──────────────┘
       │
       ▼
┌─────────────────────┐
│  Analyst            │ → MigrationSpec
└──────┬──────────────┘
       │
       ├──► Component Builder  → .component.ts / .html
       │
       ├──► State Migrator     → .store.ts / .service.ts
       │
       ├──► Router Migrator    → app.routes.ts
       │
       ├──► i18n Agent         → en.json + templates
       │
       ├──► Test Writer        → .spec.ts files
       │
       └──► Quality Guard      → lint / format / checklist ✅
```

## Target stack reference

- **Framework**: Angular (standalone components, no NgModules)
- **Styling**: Tailwind CSS v4 via PostCSS
- **State**: `@ngrx/signals` Signal Store
- **Structure**: Atomic Design (`atoms` → `molecules` → `organisms` → `pages/features`)
- **i18n**: Transloco (`src/assets/i18n/en.json`)
- **Lint**: ESLint
- **Format**: Prettier
- **Routes**: all in `src/app/app.routes.ts` using `loadComponent` (lazy)

## Key styling rules (quick reference)

- ✅ `flex flex-col gap-*` on containers with `<app-*>` children
- ✅ Escape `/` classes in `styles.css`: `.bg-primary\/10 { ... }`
- ✅ `<th>`: `h-12 px-4 align-middle text-muted-foreground`
- ✅ `<td>`: `p-4 align-middle`
- ❌ Do NOT add `border-border` per element (already global in `styles.css`)
- ❌ Do NOT use `space-y-*` on `<app-*>` containers
- ❌ Do NOT use inline `style=""` attributes
