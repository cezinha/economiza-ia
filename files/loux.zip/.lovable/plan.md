# Watchlist as default scope for Admin / User

## Goal

For the **Admin** and **User** roles, the dashboard should default to showing **only the platforms on the viewer's watchlist**, ignoring other filters. A new "Watchlist" checkbox in the Filters drawer makes this state explicit: checked = watchlist-scoped (other filters locked), unchecked = standard filtering. Platforms outside the viewer's assigned scope remain view-only even when added to the watchlist (existing executive-style behavior).

## Behavior

| Role | Watchlist checkbox | Default state | Effect when checked | Effect when unchecked |
|---|---|---|---|---|
| Admin / User | Visible | **Checked** on first load | Hides all platforms not in `watched`; locks other filter dropdowns (greyed with tooltip) | Clears all filters (same as Reset); other dropdowns become editable |
| Superadmin | Hidden | n/a | n/a — watchlist is already "all platforms" | n/a |
| Executive | Hidden | n/a | Existing behavior unchanged | Existing behavior unchanged |

View-only enforcement for non-assigned watched platforms is already handled by `useCanActOnPlatform` (admin/user can only mutate assigned platforms). **No permission changes are needed**; adding a non-assigned platform to the watchlist already shows it as read-only via existing star/lock affordances.

## Technical changes

### 1. New filter key: `watchlist` (boolean)

`src/contexts/FilterContext.tsx`
- Initialise `filters.watchlist = true` when the active role is `admin` or `user` on first render (and on role switch to admin/user if no value yet set). Other roles leave it undefined.

### 2. Apply the scope

`src/lib/applyFilters.ts`
- In `launchPasses`, when `f.watchlist === true`, intersect with the viewer's `watched` set (read via a small adapter so we avoid coupling the pure filter to the context — pass `watchedIds` in from `useFilteredLaunches`).
- In `useFilteredLaunches`, pull `watched` from `useWatchlist()`. When watchlist is active, restrict to `watched` and **skip** the other narrowing checks (status / phase / lob / platform / function) so the checkbox truly "locks" the result to the watchlist regardless of stale filter values.
- Sibling hooks (`useFilteredRisks`, `useFilteredNudds`, `useFilteredMilestones`, `useFilteredTaskQueue`, `useFilteredActivity`) already cascade through `useFilteredLaunches` or share filter keys — they will inherit the watchlist scope automatically. Confirm with a quick read; no logic changes expected beyond reading `filters.watchlist` for the row-level filters that don't go through launches.

### 3. Filters drawer UI

`src/components/shell/FiltersDrawer.tsx`
- For admin/user only, render a "Watchlist" checkbox row at the top of the scrollable body (above Business unit), with helper copy: *"Show only platforms on your watchlist. Other filters are paused while this is on."*
- When checked:
  - Pass `disabled` to every `<DdsDropdown>` (Business unit, Function, LOB, Platform, Current phase, Status, Owner, Task) with `lockedTooltip="Paused while Watchlist is on"`.
  - Hide / disable the "My defaults" and "Reset to my platforms" affordances.
- When the user **unchecks**: call `resetFilters()` then `setFilter("watchlist", false)` so all other dropdowns return to an empty/editable state.
- Re-checking later sets `filters.watchlist = true` (no need to repopulate; the watchlist scope takes over).

### 4. Filter chip / summary surfaces

`src/lib/useFilterSummary.ts` and any chips in `LockedFilterBar` / `PageHeader`:
- Add a "Watchlist" chip when active so the user can see why the dataset is narrowed. Removing the chip toggles `watchlist` off and resets filters (mirrors the checkbox).

### 5. `activeCount`

`FilterContext.activeCount` currently counts every truthy filter value. When `watchlist` is true and other filters are empty, the count should read **1** ("Watchlist"). When watchlist is on but other filters are paused, only count Watchlist itself (ignore paused values). Simple: skip counting paused filter keys when `filters.watchlist === true`.

## Out of scope

- No changes to the watchlist context, star toggles, or assignment-based permissions.
- No changes to Superadmin or Executive flows.
- No persistence of the checkbox across sessions beyond what the filter state already does (in-memory). If you want it persisted to localStorage like the watchlist itself, say the word and I'll add it.
