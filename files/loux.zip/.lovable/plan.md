Add an "Issue description" textarea as the first field in the at-risk status change form (both Confirm status and Change status flows), shown above "Root cause".

## Changes

**`src/components/dashboard/TaskDetailDrawer.tsx`**
- Extend `statusForm` state with a new `description` string field (initialized to `""` everywhere the form is reset).
- In the at-risk branch of the dialog (the non-`on-track` block), render a new textarea labeled "Issue description" with placeholder like "Briefly describe the issue" above the existing Root cause field.
- Include `description` in the submit-disabled check (required for at-risk) and pass it through wherever the form payload is consumed.

**`src/components/dashboard/RunwayBanner.tsx`** (Confirm status flow)
- If this component renders its own at-risk form, mirror the same change: add `description` to its form state, render the "Issue description" textarea as the first field, and include it in validation/submit. If it instead delegates to the same form in `TaskDetailDrawer`, no change is needed here.

On-track mode (Rationale-only) is unchanged.

## Open question
Should "Issue description" be required (blocks submit) or optional? Default in this plan: required, matching the other at-risk fields.
