## DDS Grid — Locked Standards

The dashboard is locked to the Dell Design System grid. Every layout
decision must obey these rules; CI test `src/test/dds-grid.test.ts`
asserts dashboard surface code does not violate the 4px baseline.

### Baseline
- 4px baseline grid. Every padding, margin, gap, height, and width on
  dashboard components must be a multiple of 4px (4, 8, 12, 16, 20,
  24, 32, 40, 48, 56, 64, 72, 80, 96, 128, 160).
- Disallowed Tailwind utilities in `src/components/dashboard/**` and
  `src/pages/**`: `*-0.5` (2px), `*-1.5` (6px), `*-2.5` (10px),
  `*-3.5` (14px), and arbitrary `[Npx]` values whose N is not a 4px
  multiple.

### Responsive grid (per DDS spec)
| Range          | T-shirt | Cols | Default gutter | Default margin |
|----------------|---------|------|----------------|----------------|
| 320–479        | XS      | 2    | 16             | 16             |
| 480–767        | S       | 6    | 16             | 16             |
| 768–1023       | M       | 6    | 16             | 32             |
| 1024–1365      | L       | 12   | 16             | 40             |
| 1366–1583      | XL      | 12   | 16             | 48             |
| 1584–1919      | 2XL     | 12   | 24             | 64             |
| 1920–2559      | 3XL     | 12   | 32             | 72             |
| 2560–3839      | 4XL     | 12   | 40             | 96             |
| 3840+          | 5XL     | 12   | 48             | 128            |

Compact and comfortable density variants are encoded as
`[data-density="compact"|"comfy"]` overrides on `<html>` (set via the
density switch in TopBar). All values match the DDS table verbatim.

### Primitives
- `<DdsGrid>` — only sanctioned grid container. Renders
  `grid-template-columns: repeat(var(--dds-cols), 1fr)` with
  `gap: var(--dds-gutter)`. Add `page` prop to also apply the
  `--dds-margin` page padding.
- `<DdsCol span s spanS spanM spanXs>` — declares column span at each
  breakpoint. Authors think in the L (12-col) grid; defaults handle
  M/S (6-col) and XS (2-col) sensibly.
- `px-page` / `gap-gutter` utilities bind to live tokens for the rare
  case where `<DdsGrid>` is overkill.

### Vertical rhythm
- Body line-height 24px; H1 32; H2 28; H3 24; H4 20.
- Section spacing between blocks: `space-y-8` (32px). Inside cards:
  `space-y-4` (16px).

### Forbidden
- Bespoke `grid-cols-*` in pages (use `<DdsGrid>`/`<DdsCol>`).
- Hard-coded margins that don't reference `var(--dds-margin)`.
- Any spacing utility outside the 4px scale.

---

## Elevation (DDS shadows)

The dashboard locks to the DDS 4-level elevation system. Shadow color is
Blue 900 (`#002A58`); levels step blur and offset upward.

### Tokens
- `shadow-elev-1` resting cards (KpiCard, LaunchTable, RiskPanel, …)
- `shadow-elev-2` hover on interactive cards
- `shadow-elev-3` click-through cards on hover, popovers, dropdowns
- `shadow-elev-4` modals, dialogs, high-priority notifications
- `shadow-elev-left-1..4` / `shadow-elev-right-1..4` opposite-cast variants
- `shadow-elev-inset` sunken state (use sparingly; never decorative)

### Rules (enforced by `src/test/dds-grid.test.ts`)
- Never use `shadow-sm | shadow-md | shadow-lg | shadow-xl | shadow-2xl |
  shadow-inner | shadow-[...]` on dashboard surface.
- Pick **one** light direction per screen. Mixing bottom + left/right
  shadows on the same page fails CI. Dashboard default = bottom.
- Don't overuse elevation — per DDS guidance, only elevate items where
  hierarchy actually changes.
- Never use a shadow purely for decoration (DDS accessibility rule).

---

## Color (Pattern A)

The dashboard locks to DDS light neutrals, **Pattern A**:

| Role               | DDS color  | Hex      | Token             |
|--------------------|------------|----------|-------------------|
| Page background    | Gray 100   | #F5F6F7  | `bg-background`   |
| Card / surface     | White      | #FFFFFF  | `bg-surface` / `bg-card` |
| Offset inside card | Gray 100   | #F5F6F7  | `bg-muted`        |
| Default text       | Gray 900   | #0E0E0E  | `text-foreground` |

Black (`#000000`) is deliberately not in the palette (DDS rule).

### Rules (enforced by `src/test/dds-grid.test.ts`)
- Use semantic Tailwind classes only (`bg-surface`, `bg-background`,
  `text-foreground`, `text-muted-foreground`, `bg-primary`,
  `bg-success`, `bg-danger`, etc.).
- Forbidden on dashboard surface (`src/pages/**`,
  `src/components/dashboard/**`, `src/components/shell/**`):
  - `text-white | bg-white | text-black | bg-black`
  - `*-gray-* | *-slate-* | *-zinc-* | *-neutral-* | *-stone-*`
  - Arbitrary color values: `text-[#…]`, `bg-[#…]`, `border-[#…]`,
    `text-[rgb…]`, `bg-[hsl…]`
  - Inline `style={{ color | backgroundColor | borderColor: "#…" }}`
- shadcn/ui primitives in `src/components/ui/**` are exempt — already
  token-based.
