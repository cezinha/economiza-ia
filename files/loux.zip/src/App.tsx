import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { RoleProvider } from "@/contexts/RoleContext";
import { AppShell } from "@/components/shell/AppShell";
import Index from "./pages/Index";
import LaunchesPage from "./pages/LaunchesPage";
import TasksPage from "./pages/TasksPage";
import RisksPage from "./pages/RisksPage";
import DesignIssuesPage from "./pages/DesignIssuesPage";
import ActivityPage from "./pages/ActivityPage";
import CuratorPage from "./pages/CuratorPage";
import CuratorPlatformPage from "./pages/CuratorPlatformPage";
import GoldenConfigsPage from "./pages/GoldenConfigsPage";
import BuildExecutionPage from "./pages/BuildExecutionPage";
import UserManagementPage from "./pages/UserManagementPage";
import NotFound from "./pages/NotFound";
import { seedLegacyOverrides } from "@/mocks/seedLegacyOverrides";

seedLegacyOverrides();

const queryClient = new QueryClient();


const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <RoleProvider>
        <BrowserRouter>
          <Routes>
            <Route element={<AppShell />}>
              <Route path="/" element={<Index />} />
              <Route path="/launches" element={<LaunchesPage />} />
              <Route path="/tasks" element={<TasksPage />} />
              <Route path="/curator" element={<CuratorPage />} />
              <Route path="/curator/platform/:platformId" element={<CuratorPlatformPage />} />
              <Route path="/golden-configs" element={<GoldenConfigsPage />} />
              <Route path="/build-execution" element={<BuildExecutionPage />} />
              <Route path="/risks" element={<RisksPage />} />
              <Route path="/design-issues" element={<DesignIssuesPage />} />
              <Route path="/activity" element={<ActivityPage />} />
              <Route path="/user-management" element={<UserManagementPage />} />
            </Route>
            <Route path="*" element={<NotFound />} />
          </Routes>
        </BrowserRouter>
      </RoleProvider>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
