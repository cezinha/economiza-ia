import { useCallback, useEffect, useState } from "react";
import { ChatBotIcon } from "./ChatBotIcon";
import { cn } from "@/lib/utils";
import { AssistantWindow } from "./AssistantWindow";
import type { AssistantMessageData } from "./AssistantMessage";

const STORAGE_KEY = "olp-assistant:v1";
const USER_FIRST_NAME = "Christine";

const REPLIES = [
  "Thanks for the question. I don't have a live model wired up in this PoC yet, so this is a placeholder reply.",
  "Got it — once the McKinsey AI Gateway is connected I'll be able to look that up across NUDDs, documents, and milestones.",
  "Noted. In the production build I'd search the indexed content and link the source. For now, here's a stand-in answer.",
  "Good ask. The PoC stops at the UI; the assistant routes will return real answers when the gateway is provisioned.",
];

interface PersistedState {
  messages: AssistantMessageData[];
}

function loadState(): PersistedState {
  try {
    const raw = sessionStorage.getItem(STORAGE_KEY);
    if (!raw) return { messages: [] };
    return JSON.parse(raw) as PersistedState;
  } catch {
    return { messages: [] };
  }
}

function saveState(state: PersistedState) {
  try {
    sessionStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  } catch {
    /* ignore */
  }
}

const HEADER_GRADIENT =
  "bg-[linear-gradient(135deg,hsl(225_70%_38%),hsl(285_45%_30%),hsl(330_65%_45%))]";

export function AssistantLauncher() {
  const [open, setOpen] = useState(false);
  const [messages, setMessages] = useState<AssistantMessageData[]>(() => loadState().messages);
  const [pending, setPending] = useState(false);

  useEffect(() => {
    saveState({ messages });
  }, [messages]);

  const handleSubmit = useCallback((text: string) => {
    const now = Date.now();
    const userMsg: AssistantMessageData = {
      id: `u-${now}`,
      role: "user",
      content: text,
      createdAt: now,
    };
    setMessages((prev) => [...prev, userMsg]);
    setPending(true);
    const reply = REPLIES[Math.floor(Math.random() * REPLIES.length)];
    window.setTimeout(() => {
      setMessages((prev) => [
        ...prev,
        {
          id: `a-${Date.now()}`,
          role: "assistant",
          content: reply,
          createdAt: Date.now(),
        },
      ]);
      setPending(false);
    }, 700);
  }, []);

  const handleClear = useCallback(() => {
    setMessages([]);
    setPending(false);
  }, []);

  return (
    <>
      <AssistantWindow
        open={open}
        onClose={() => setOpen(false)}
        messages={messages}
        pending={pending}
        onSubmit={handleSubmit}
        onClear={handleClear}
        userFirstName={USER_FIRST_NAME}
      />
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        aria-label={open ? "Close OLP Assistant" : "Open OLP Assistant"}
        className={cn(
          "fixed bottom-6 right-6 z-50 flex h-14 w-14 items-center justify-center rounded-full text-primary-foreground shadow-elev-3 transition-transform hover:scale-105 hover:shadow-elev-4 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-2",
          HEADER_GRADIENT,
        )}
      >
        <ChatBotIcon className="h-6 w-6" />
      </button>
    </>
  );
}
