import ReactMarkdown from "react-markdown";
import { cn } from "@/lib/utils";

export type AssistantRole = "user" | "assistant";

export interface AssistantMessageData {
  id: string;
  role: AssistantRole;
  content: string;
  createdAt: number;
}

export function AssistantMessage({ message }: { message: AssistantMessageData }) {
  const isUser = message.role === "user";
  return (
    <div className={cn("flex w-full", isUser ? "justify-end" : "justify-start")}>
      <div
        className={cn(
          "max-w-[80%] rounded-lg px-3 py-2 text-body-3 shadow-elev-1",
          isUser
            ? "bg-primary text-primary-foreground"
            : "bg-muted text-foreground",
        )}
      >
        <div className="prose prose-sm max-w-none [&>*:first-child]:mt-0 [&>*:last-child]:mb-0">
          <ReactMarkdown>{message.content}</ReactMarkdown>
        </div>
      </div>
    </div>
  );
}
