import { useEffect, useRef, useState, KeyboardEvent } from "react";
import { ArrowUp, MessageCircle, X } from "lucide-react";
import { ChatBotIcon } from "./ChatBotIcon";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { cn } from "@/lib/utils";
import { AssistantMessage, type AssistantMessageData } from "./AssistantMessage";

interface AssistantWindowProps {
  open: boolean;
  onClose: () => void;
  messages: AssistantMessageData[];
  pending: boolean;
  onSubmit: (text: string) => void;
  onClear: () => void;
  userFirstName: string;
}

const HEADER_GRADIENT = "bg-[linear-gradient(135deg,hsl(225_70%_38%),hsl(285_45%_30%),hsl(330_65%_45%))]";

export function AssistantWindow({
  open,
  onClose,
  messages,
  pending,
  onSubmit,
  onClear,
  userFirstName,
}: AssistantWindowProps) {
  const [draft, setDraft] = useState("");
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, pending, open]);

  const submit = () => {
    const text = draft.trim();
    if (!text || pending) return;
    onSubmit(text);
    setDraft("");
  };

  const onKeyDown = (e: KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      submit();
    }
  };

  if (!open) return null;

  return (
    <>
      <div
        className="fixed inset-0 z-40 bg-foreground/30 backdrop-blur-sm"
        onClick={onClose}
        aria-hidden="true"
      />
      <div
        role="dialog"
        aria-modal="true"
        aria-label="OLP Assistant"
        className={cn(
          "fixed left-1/2 top-1/2 z-50 flex -translate-x-1/2 -translate-y-1/2 flex-col overflow-hidden rounded-lg border border-border bg-surface shadow-elev-4",
          "h-[85vh] w-[92vw] m:h-[640px] m:w-[600px] m:max-w-[92vw] m:max-h-[85vh]",
        )}
      >
      {/* Header */}
      <div className={cn("flex items-center gap-3 px-4 py-3 text-primary-foreground", HEADER_GRADIENT)}>
        <ChatBotIcon className="h-5 w-5 shrink-0" />
        <span className="text-h5 flex-1 truncate">OLP assistant</span>
        <button
          type="button"
          onClick={onClose}
          aria-label="Close assistant"
          className="rounded-sm p-1 hover:bg-white/10 transition-colors"
        >
          <X className="h-4 w-4" strokeWidth={1.75} />
        </button>
      </div>

      {/* Body */}
      <div ref={scrollRef} className="flex-1 overflow-y-auto px-4 py-4">
        {messages.length === 0 ? (
          <div className="flex h-full flex-col items-center justify-center text-center">
            <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/10 text-primary">
              <MessageCircle className="h-6 w-6" strokeWidth={1.75} />
            </div>
            <p className="mt-4 text-body-2 text-foreground">
              How may I help you?
            </p>
            <p className="mt-2 max-w-xs text-caption text-muted-foreground">
              Ask about NUDDs, program documents, milestones, or any indexed content
            </p>
          </div>
        ) : (
          <div className="flex flex-col gap-3">
            {messages.map((m) => (
              <AssistantMessage key={m.id} message={m} />
            ))}
            {pending && (
              <div className="flex w-full justify-start">
                <div className="flex items-center gap-1 rounded-lg bg-muted px-3 py-2">
                  <span className="h-2 w-2 animate-pulse rounded-full bg-muted-foreground" />
                  <span className="h-2 w-2 animate-pulse rounded-full bg-muted-foreground [animation-delay:150ms]" />
                  <span className="h-2 w-2 animate-pulse rounded-full bg-muted-foreground [animation-delay:300ms]" />
                </div>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Composer */}
      <div className="border-t border-border bg-surface px-4 py-3">
        <div className="flex items-end gap-2">
          <Textarea
            value={draft}
            onChange={(e) => setDraft(e.target.value)}
            onKeyDown={onKeyDown}
            placeholder="Type your question"
            rows={2}
            className="min-h-12 resize-none border-primary/40 text-body-2 placeholder:text-body-2 focus-visible:ring-primary"
          />
          <Button
            type="button"
            size="icon"
            variant="outline"
            onClick={submit}
            disabled={!draft.trim() || pending}
            aria-label="Send message"
            className="bg-[#0672CB] text-white border-[#0672CB] hover:bg-[#055AA3] hover:text-white hover:border-[#055AA3] disabled:opacity-40"
          >
            <ArrowUp className="h-4 w-4" />
          </Button>
        </div>
        <p className="mt-2 text-caption text-muted-foreground">
          Press Enter to send, Shift+Enter for new line
        </p>
      </div>
    </div>
    </>
  );
}
