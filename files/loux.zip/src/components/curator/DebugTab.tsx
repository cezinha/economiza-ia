import { useMemo, useState } from "react";
import { Eye, Search } from "lucide-react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { cn } from "@/lib/utils";

const intents: { name: string; count: number }[] = [
  { name: "Help", count: 8 },
  { name: "hybrid_fact_lookup", count: 135 },
  { name: "Issue Lookup", count: 2 },
  { name: "Latest Document", count: 208 },
  { name: "member_query", count: 197 },
  { name: "Milestone Query", count: 78 },
  { name: "Portfolio Query", count: 5 },
  { name: "Program Status", count: 4 },
  { name: "Provenance Query", count: 4 },
  { name: "Role Lookup", count: 18 },
  { name: "Thanks", count: 1 },
];

type GroupTab = { id: string; label: string; count: number };

const sessionTabs: GroupTab[] = [{ id: "session", label: "session-...", count: 435 }];
const userTabs: GroupTab[] = [
  { id: "john", label: "John Doe", count: 519 },
  { id: "vivek", label: "Vivek Singh", count: 7 },
  { id: "ashly", label: "Ashly", count: 5 },
  { id: "akash", label: "Chandwani, Akash - Dell Team", count: 66 },
  { id: "jaskaran", label: "Sidana, Jaskaran - Dell Team", count: 30 },
  { id: "krishnan", label: "Durairajan, Krishnan", count: 12 },
];

type QueryRow = {
  time: string;
  session: string;
  query: string;
  intent: string;
  confidence: string;
  duration: string;
  status: string;
};

const queryRows: QueryRow[] = [
  { time: "4/28/26, 12:06 AM", session: "c032667b...", query: "How many document types can be compared?", intent: "Unknown", confidence: "—", duration: "15.11s", status: "—" },
  { time: "4/27/26, 9:17 PM", session: "f90bdce3...", query: "What is the summary for CPDM-21533?", intent: "Unknown", confidence: "—", duration: "12.56s", status: "—" },
  { time: "4/27/26, 9:16 PM", session: "de5d92cc...", query: "Can you share what is the risk description for CPDM-21533?", intent: "Unknown", confidence: "—", duration: "17.91s", status: "—" },
  { time: "4/27/26, 9:14 PM", session: "6a0e6a99...", query: "Can you share the description of NUDD CPDM-21533 for Renegade?", intent: "Unknown", confidence: "—", duration: "17.80s", status: "—" },
  { time: "4/27/26, 8:54 PM", session: "6c6608fe...", query: "Can you list all NUDDS for Renegade related to cosmetic issues?", intent: "Unknown", confidence: "—", duration: "28.82s", status: "—" },
  { time: "4/12/26, 12:52 PM", session: "cfec16b9...", query: "list all the nudd for cy25 renegade and provide the summary", intent: "Unknown", confidence: "—", duration: "49.08s", status: "—" },
];

export function DebugTab() {
  const [groupBy, setGroupBy] = useState<"session" | "user">("user");
  const [activeTab, setActiveTab] = useState<string>("john");
  const max = useMemo(() => Math.max(...intents.map((i) => i.count)), []);
  const tabs = groupBy === "session" ? sessionTabs : userTabs;

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-h4">Debug</h2>
        <p className="text-body-3 text-muted-foreground mt-1">
          Inspect query traffic, intent classification, and session-level activity
        </p>
      </div>

      {/* Intent Distribution */}
      <div className="rounded-lg border border-border bg-card p-6 shadow-elev-1">
        <h3 className="text-subtitle-2 mb-4">Intent Distribution</h3>
        <div className="space-y-2">
          {intents.map((i) => (
            <div key={i.name} className="grid grid-cols-[160px_1fr_48px] items-center gap-3">
              <span className="text-caption text-primary text-right">{i.name}</span>
              <div className="h-2 rounded-full bg-muted overflow-hidden">
                <div
                  className="h-full bg-primary rounded-full"
                  style={{ width: `${(i.count / max) * 100}%` }}
                />
              </div>
              <span className="text-caption text-foreground text-right tabular-nums">{i.count}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Filters */}
      <div className="grid grid-cols-1 l:grid-cols-2 gap-4">
        <div>
          <label className="text-caption text-muted-foreground block mb-2">Search by Session ID</label>
          <div className="flex gap-2">
            <Input placeholder="Enter session UUID..." />
            <Button className="gap-2"><Search className="h-4 w-4" /> Search</Button>
          </div>
        </div>
        <div>
          <label className="text-caption text-muted-foreground block mb-2">Filter Messages</label>
          <div className="relative">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input placeholder="Search in queries and responses..." className="pl-9" />
          </div>
        </div>
      </div>

      {/* Group by */}
      <div className="flex items-center gap-3">
        <span className="text-caption text-muted-foreground">Group by:</span>
        <div className="inline-flex rounded-md border border-border overflow-hidden">
          <button
            type="button"
            onClick={() => setGroupBy("session")}
            className={cn(
              "px-4 py-2 text-button-2",
              groupBy === "session" ? "bg-primary text-primary-foreground" : "bg-card text-foreground",
            )}
          >
            Session
          </button>
          <button
            type="button"
            onClick={() => setGroupBy("user")}
            className={cn(
              "px-4 py-2 text-button-2 border-l border-border",
              groupBy === "user" ? "bg-primary text-primary-foreground" : "bg-card text-foreground",
            )}
          >
            User
          </button>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex flex-wrap gap-2">
        {tabs.map((t) => {
          const active = t.id === activeTab;
          return (
            <button
              key={t.id}
              type="button"
              onClick={() => setActiveTab(t.id)}
              className={cn(
                "inline-flex items-center gap-2 rounded-md border px-3 py-2 text-button-2 transition-colors",
                active
                  ? "bg-primary text-primary-foreground border-primary"
                  : "bg-card text-foreground border-border hover:bg-muted",
              )}
            >
              {t.label}
              <span
                className={cn(
                  "rounded px-2 py-0.5 text-caption",
                  active ? "bg-primary-foreground/20 text-primary-foreground" : "bg-muted text-muted-foreground",
                )}
              >
                {t.count}
              </span>
            </button>
          );
        })}
      </div>

      {/* Query log */}
      <div className="rounded-lg border border-border bg-card shadow-elev-1">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="text-subtitle-2">Time</TableHead>
              <TableHead className="text-subtitle-2">Session</TableHead>
              <TableHead className="text-subtitle-2">Query</TableHead>
              <TableHead className="text-subtitle-2">Intent</TableHead>
              <TableHead className="text-subtitle-2 text-right">Confidence</TableHead>
              <TableHead className="text-subtitle-2 text-right">Duration</TableHead>
              <TableHead className="text-subtitle-2">Status</TableHead>
              <TableHead className="text-subtitle-2 text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {queryRows.map((r, i) => (
              <TableRow key={i}>
                <TableCell className="text-body-3">{r.time}</TableCell>
                <TableCell>
                  <Badge variant="outline" className="font-mono text-caption">{r.session}</Badge>
                </TableCell>
                <TableCell className="text-body-3 text-primary">{r.query}</TableCell>
                <TableCell className="text-body-3 text-muted-foreground">— <br /><span>{r.intent}</span></TableCell>
                <TableCell className="text-body-3 text-right tabular-nums">{r.confidence}</TableCell>
                <TableCell className="text-body-3 text-right tabular-nums">{r.duration}</TableCell>
                <TableCell className="text-body-3 text-muted-foreground">{r.status}</TableCell>
                <TableCell className="text-right">
                  <Button variant="ghost" size="icon" className="h-8 w-8 text-primary"><Eye className="h-4 w-4" /></Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
        <div className="flex justify-center p-4 border-t border-border">
          <Button variant="outline">Load More (200 of 1818)</Button>
        </div>
      </div>
    </div>
  );
}
