import { Link } from "react-router-dom";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { launches as ALL_LAUNCHES, risks, tasks, milestones, type Activity, type RAG } from "@/mocks/launches";
import { useFilteredActivity } from "@/lib/applyFilters";
import { cn } from "@/lib/utils";

const ragDot: Record<RAG, string> = {
  green: "bg-success",
  amber: "bg-warning",
  red: "bg-destructive",
};

function renderEvent(a: Activity) {
  const launch = ALL_LAUNCHES.find((l) => l.id === a.launchId);
  if (!launch) return null;

  const launchLink = (
    <Link
      to={`/launches?focus=${launch.id}`}
      className="font-medium text-foreground hover:text-primary hover:underline"
    >
      {launch.name}
    </Link>
  );

  switch (a.kind) {
    case "phase_change":
      return (
        <>
          <span className="font-medium">{a.actor}</span>{" "}
          <span className="text-muted-foreground">moved</span> {launchLink}{" "}
          <span className="text-muted-foreground">to</span>{" "}
          <span className="font-medium">{launch.phase}</span>{" "}
          <span className="text-muted-foreground">phase</span>
        </>
      );
    case "risk_raised": {
      const risk = risks.find((r) => r.id === a.refId);
      return (
        <>
          <span className="font-medium">{a.actor}</span>{" "}
          <span className="text-muted-foreground">raised risk</span>{" "}
          {risk && <span className="font-medium">"{risk.title}"</span>}{" "}
          <span className="text-muted-foreground">on</span> {launchLink}
        </>
      );
    }
    case "decision_request": {
      const task = tasks.find((t) => t.id === a.refId);
      return (
        <>
          <span className="font-medium">{a.actor}</span>{" "}
          <span className="text-muted-foreground">requested decision on</span>{" "}
          <span className="font-medium">{task?.title ?? "task"}</span>{" "}
          <span className="text-muted-foreground">·</span> {launchLink}
        </>
      );
    }
    case "approval_submitted": {
      const task = tasks.find((t) => t.id === a.refId);
      return (
        <>
          <span className="font-medium">{a.actor}</span>{" "}
          <span className="text-muted-foreground">submitted approval for</span>{" "}
          <span className="font-medium">{task?.title ?? "task"}</span>{" "}
          <span className="text-muted-foreground">·</span> {launchLink}
        </>
      );
    }
    case "milestone_done": {
      const milestone = milestones.find((m) => m.id === a.refId);
      return (
        <>
          <span className="font-medium">{a.actor}</span>{" "}
          <span className="text-muted-foreground">completed milestone</span>{" "}
          <span className="font-medium">{milestone?.name ?? "milestone"}</span>{" "}
          <span className="text-muted-foreground">on</span> {launchLink}
        </>
      );
    }
    case "launch_kickoff":
      return (
        <>
          <span className="font-medium">{a.actor}</span>{" "}
          <span className="text-muted-foreground">kicked off</span> {launchLink}{" "}
          <span className="text-muted-foreground">({launch.phase})</span>
        </>
      );
    case "assignment_request":
      return (
        <>
          <span className="font-medium">{a.actor}</span>{" "}
          <span className="text-muted-foreground">requested reassignment:</span>{" "}
          <span className="font-medium">{a.detail}</span>{" "}
          <span className="text-muted-foreground">·</span> {launchLink}
        </>
      );
    case "assignment_resolved":
      return (
        <>
          <span className="font-medium">{a.actor}</span>{" "}
          <span className="text-muted-foreground">{a.detail}</span>{" "}
          <span className="text-muted-foreground">·</span> {launchLink}
        </>
      );
    case "runway_exception":
      return (
        <>
          <span className="font-medium">{a.actor}</span>{" "}
          <span className="text-muted-foreground">{a.detail}</span>{" "}
          <span className="text-muted-foreground">·</span> {launchLink}
        </>
      );
    case "runway_resolved":
      return (
        <>
          <span className="font-medium">{a.actor}</span>{" "}
          <span className="text-muted-foreground">{a.detail}</span>{" "}
          <span className="text-muted-foreground">·</span> {launchLink}
        </>
      );
    case "milestone_shift":
      return (
        <>
          <span className="font-medium">{a.actor}</span>{" "}
          <span className="text-muted-foreground">shifted RTS on</span> {launchLink}{" "}
          <span className="text-muted-foreground">— {a.detail}</span>
        </>
      );
    case "nudd_trigger":
      return (
        <>
          <span className="font-medium">{a.actor}</span>{" "}
          <span className="text-muted-foreground">{a.detail}</span>{" "}
          <span className="text-muted-foreground">·</span> {launchLink}
        </>
      );
  }
}

export function ActivityFeed() {
  const filtered = useFilteredActivity();

  return (
    <Card className="border-border bg-surface shadow-elev-1 flex flex-col h-full">
      <CardHeader className="pb-4">
        <h5 className="text-h5 text-foreground">Activity</h5>
        <p className="text-caption text-muted-foreground">Recent portfolio events</p>
      </CardHeader>
      <CardContent className="flex-1 min-h-0">
        {filtered.length === 0 ? (
          <p className="text-body-3 text-muted-foreground">
            No recent activity for the current filters.
          </p>
        ) : (
          <ol className="relative space-y-4 border-l border-border pl-6 max-h-[640px] overflow-y-auto">
            {filtered.map((a) => {
              const launch = ALL_LAUNCHES.find((l) => l.id === a.launchId);
              return (
                <li key={a.id} className="relative">
                  <span
                    className={cn(
                      "absolute -left-7 top-2 h-2 w-2 rounded-full ring-4 ring-surface",
                      launch ? ragDot[launch.rag] : "bg-primary",
                    )}
                  />
                  <p className="text-body-3 text-foreground">{renderEvent(a)}</p>
                  <p className="text-caption text-muted-foreground mt-1">{a.timestamp}</p>
                </li>
              );
            })}
          </ol>
        )}
      </CardContent>
    </Card>
  );
}
