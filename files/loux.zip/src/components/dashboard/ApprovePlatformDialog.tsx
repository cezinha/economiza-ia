import { useEffect, useMemo, useState } from "react";
import { toast } from "sonner";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  approvePendingPlatform,
  rejectPendingPlatform,
  type PendingPlatform,
} from "@/mocks/pendingPlatforms";
import { useRole, ROLES } from "@/contexts/RoleContext";
import { ExternalLink, Search, UserCircle2, X } from "lucide-react";
import { cn } from "@/lib/utils";

// A small candidate pool reused from the people mock; this PoC keeps it local
// so we can list quickly without rebuilding the manager catalog.
const ASSIGNEE_POOL = [
  "Priya Shah", "Marcus Lee", "Hiroshi Tanaka", "Sara Okafor", "Lena Vogel",
  "Asha Rangan", "Brendan O'Neill", "Carla Méndez", "Dimitri Volkov",
  "Eun-Ji Park", "Farhan Siddiqui", "Greta Lindqvist", "Kavita Iyer",
  "Maya Goldberg", "Patricia Chan", "Ravi Subramanian", "Sigrid Hansen",
  "Tobias Hartmann", "Uma Krishnan", "Wendy Zhao",
];

interface Props {
  request: PendingPlatform | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function ApprovePlatformDialog({ request, open, onOpenChange }: Props) {
  const { role } = useRole();
  const actorLabel = ROLES.find((r) => r.value === role)?.label ?? role;

  const [owner, setOwner] = useState<string>("");
  const [assignees, setAssignees] = useState<string[]>([]);
  const [launchDate, setLaunchDate] = useState<string>("");
  const [search, setSearch] = useState("");
  const [mode, setMode] = useState<"approve" | "reject">("approve");
  const [rejectReason, setRejectReason] = useState("");

  useEffect(() => {
    if (!request || !open) return;
    setOwner(request.proposedOwner);
    setAssignees([]);
    setLaunchDate(request.proposedLaunchDate);
    setSearch("");
    setMode("approve");
    setRejectReason("");
  }, [request, open]);

  const filteredAssignees = useMemo(() => {
    const q = search.trim().toLowerCase();
    return ASSIGNEE_POOL.filter((n) => n !== owner)
      .filter((n) => (!q ? true : n.toLowerCase().includes(q)));
  }, [search, owner]);

  if (!request) return null;

  const toggleAssignee = (name: string) => {
    setAssignees((prev) =>
      prev.includes(name) ? prev.filter((n) => n !== name) : [...prev, name],
    );
  };

  const canApprove = owner.trim().length > 0 && launchDate.length > 0;

  const handleApprove = () => {
    if (!canApprove) return;
    const launch = approvePendingPlatform({
      pendingId: request.id,
      approvedBy: actorLabel,
      owner,
      additionalAssignees: assignees,
      launchDate,
    });
    if (launch) {
      toast.success(`${launch.name} is now live in the dashboard.`, {
        description: `${assignees.length + 1} assignee${assignees.length === 0 ? "" : "s"} notified.`,
      });
      onOpenChange(false);
    } else {
      toast.error("Could not approve — request may already be processed.");
    }
  };

  const handleReject = () => {
    if (rejectReason.trim().length < 4) {
      toast.error("Add a short reason so the requester knows what to fix.");
      return;
    }
    const ok = rejectPendingPlatform(request.id, actorLabel, rejectReason.trim());
    if (ok) {
      toast.success(`Rejected ${request.jiraKey}.`);
      onOpenChange(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <div className="flex items-center gap-2">
            <Badge variant="outline" className="font-mono text-caption">
              <ExternalLink className="h-3 w-3 mr-1" /> {request.jiraKey}
            </Badge>
            <Badge variant="secondary" className="text-caption">From Jira intake</Badge>
          </div>
          <DialogTitle className="text-h4 mt-2">{request.name}</DialogTitle>
          <DialogDescription className="text-body-3">
            Review the platform metadata, confirm or change the assigned owner,
            and add team members. Once approved, the platform appears on
            everyone's dashboard within {request.function} · {request.lob}.
          </DialogDescription>
        </DialogHeader>

        {mode === "approve" ? (
          <div className="space-y-5">
            <div className="grid grid-cols-3 gap-3 rounded-md border border-border bg-muted/30 px-4 py-3">
              <Meta label="LOB" value={request.lob} />
              <Meta label="Function" value={request.function === "SChM" ? "SChM" : request.function} />
              <Meta label="Region" value={request.region} />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label className="text-body-3 text-foreground">Primary owner *</Label>
                <Select value={owner} onValueChange={setOwner}>
                  <SelectTrigger>
                    <SelectValue placeholder="Pick an owner" />
                  </SelectTrigger>
                  <SelectContent>
                    {ASSIGNEE_POOL.map((n) => (
                      <SelectItem key={n} value={n}>{n}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <p className="text-caption text-muted-foreground">
                  Proposed by Jira: {request.proposedOwner}
                </p>
              </div>
              <div className="space-y-2">
                <Label className="text-body-3 text-foreground">Target launch date *</Label>
                <Input
                  type="date"
                  value={launchDate}
                  onChange={(e) => setLaunchDate(e.target.value)}
                />
                <p className="text-caption text-muted-foreground">
                  Proposed: {request.proposedLaunchDate}
                </p>
              </div>
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label className="text-body-3 text-foreground">
                  Additional assignees
                  <span className="text-caption text-muted-foreground ml-2">
                    ({assignees.length} selected)
                  </span>
                </Label>
                {assignees.length > 0 && (
                  <button
                    type="button"
                    onClick={() => setAssignees([])}
                    className="text-caption text-primary hover:underline"
                  >
                    Clear
                  </button>
                )}
              </div>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search people…"
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  className="pl-10"
                />
              </div>
              {assignees.length > 0 && (
                <div className="flex flex-wrap gap-2">
                  {assignees.map((n) => (
                    <Badge key={n} variant="secondary" className="gap-1 text-caption">
                      <UserCircle2 className="h-3 w-3" />
                      {n}
                      <button
                        type="button"
                        className="opacity-70 hover:opacity-100"
                        onClick={() => toggleAssignee(n)}
                        aria-label={`Remove ${n}`}
                      >
                        <X className="h-3 w-3" />
                      </button>
                    </Badge>
                  ))}
                </div>
              )}
              <div className="max-h-44 overflow-y-auto rounded-md border border-border">
                {filteredAssignees.length === 0 ? (
                  <p className="px-3 py-3 text-caption italic text-muted-foreground">
                    No matches.
                  </p>
                ) : (
                  <ul>
                    {filteredAssignees.slice(0, 25).map((n) => {
                      const checked = assignees.includes(n);
                      return (
                        <li key={n}>
                          <label className="flex items-center gap-3 px-3 py-2 cursor-pointer hover:bg-muted/40">
                            <Checkbox
                              checked={checked}
                              onCheckedChange={() => toggleAssignee(n)}
                            />
                            <span className="text-body-3 text-foreground">{n}</span>
                          </label>
                        </li>
                      );
                    })}
                  </ul>
                )}
              </div>
            </div>
          </div>
        ) : (
          <div className="space-y-3">
            <Label className="text-body-3 text-foreground">Reason for rejection *</Label>
            <Textarea
              rows={4}
              value={rejectReason}
              onChange={(e) => setRejectReason(e.target.value)}
              placeholder="e.g. duplicate of GOE-1399, wrong LOB, missing exec sponsor…"
            />
            <p className="text-caption text-muted-foreground">
              Sent back to the Jira reporter so they can re-submit.
            </p>
          </div>
        )}

        <DialogFooter className="flex-row justify-between sm:justify-between">
          {mode === "approve" ? (
            <>
              <Button
                variant="ghost"
                onClick={() => setMode("reject")}
                className="text-status-at-risk hover:text-status-at-risk"
              >
                Reject
              </Button>
              <div className="flex gap-2">
                <Button variant="outline" onClick={() => onOpenChange(false)}>
                  Cancel
                </Button>
                <Button onClick={handleApprove} disabled={!canApprove}>
                  Approve & publish
                </Button>
              </div>
            </>
          ) : (
            <>
              <Button variant="ghost" onClick={() => setMode("approve")}>
                Back
              </Button>
              <div className="flex gap-2">
                <Button variant="outline" onClick={() => onOpenChange(false)}>
                  Cancel
                </Button>
                <Button variant="destructive" onClick={handleReject}>
                  Confirm reject
                </Button>
              </div>
            </>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function Meta({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <p className="text-caption uppercase tracking-wide text-muted-foreground">{label}</p>
      <p className="text-body-3 text-foreground mt-1">{value}</p>
    </div>
  );
}
