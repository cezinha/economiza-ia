import { useMemo, useState } from "react";
import { toast } from "sonner";
import { AlertTriangle, ArrowRight, CheckCircle2 } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { cn } from "@/lib/utils";
import type { Launch } from "@/mocks/launches";
import {
  isAutoTask,
  taskStatus,
  tasksForLaunch,
  type TaskStatus,
} from "@/lib/launchTasks";
import type { ScheduleTrack } from "@/lib/schedule";
import { closeAndAdvance, getEffectivePhase, nextPhaseOf } from "@/mocks/phaseTransitions";
import { appendActivity } from "@/mocks/activityLog";

const TRACKS: ScheduleTrack[] = ["GOE", "NPI", "SChM"];

interface OutstandingItem {
  id: string;
  title: string;
  track: ScheduleTrack;
  status: TaskStatus;
  required: boolean;
}

function gatherOutstanding(launch: Launch, phaseName: string): OutstandingItem[] {
  const all = tasksForLaunch(launch);
  const out: OutstandingItem[] = [];
  for (const t of all) {
    if (t.phase !== phaseName) continue;
    if (isAutoTask(t)) continue;
    for (const tr of TRACKS) {
      if (!t.teams.includes(tr as never)) continue;
      const s = taskStatus(launch, t, tr);
      if (s === "completed") continue;
      out.push({
        id: `${t.id}::${tr}`,
        title: t.task,
        track: tr,
        status: s,
        required: (t.required ?? "").toLowerCase() === "required",
      });
    }
  }
  return out;
}

interface Props {
  launch: Launch;
  open: boolean;
  onOpenChange: (open: boolean) => void;
  closedBy?: string;
}

export function ClosePhaseDialog({ launch, open, onOpenChange, closedBy = "You" }: Props) {
  const [reason, setReason] = useState("");
  const currentPhase = getEffectivePhase(launch);
  const next = nextPhaseOf(currentPhase);

  const outstanding = useMemo(() => gatherOutstanding(launch, currentPhase), [launch, currentPhase, open]);
  const requiredOpen = outstanding.filter((o) => o.required);
  const optionalOpen = outstanding.filter((o) => !o.required);
  const blockedByRequired = requiredOpen.length > 0;
  const reasonRequired = blockedByRequired || optionalOpen.length > 0;
  const canConfirm = !!next && (!reasonRequired || reason.trim().length >= 8);

  const handleConfirm = () => {
    if (!next || !canConfirm) return;
    const t = closeAndAdvance({
      launch,
      closedBy,
      reason: reason.trim() || undefined,
      override: outstanding.length > 0,
    });
    if (!t) return;
    appendActivity({
      actor: closedBy,
      kind: "phase_change",
      launchId: launch.id,
      detail: `closed ${t.fromPhase} → started ${t.toPhase}${t.override ? ` (override · ${outstanding.length} open task${outstanding.length === 1 ? "" : "s"})` : ""}`,
    });
    toast.success(`${launch.name}: ${t.fromPhase} closed → ${t.toPhase} started`);
    setReason("");
    onOpenChange(false);
  };

  if (!next) {
    return (
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Already at final phase</DialogTitle>
            <DialogDescription>
              {launch.name} is at <span className="font-medium">{currentPhase}</span> — there is no next phase to launch.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button onClick={() => onOpenChange(false)}>Close</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    );
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            Close <span className="font-medium">{currentPhase}</span>
            <ArrowRight className="h-4 w-4 text-muted-foreground" />
            Start <span className="font-medium">{next}</span>
          </DialogTitle>
          <DialogDescription>
            {launch.name} · {launch.lob} · {launch.region}
          </DialogDescription>
        </DialogHeader>

        <div className={cn(
          "rounded-md border px-3 py-3",
          outstanding.length === 0 ? "border-status-on-track/30 bg-status-on-track/5" : "border-status-at-risk-mitigated/40 bg-status-at-risk-mitigated/5",
        )}>
          {outstanding.length === 0 ? (
            <div className="flex items-start gap-2">
              <CheckCircle2 className="h-4 w-4 text-status-on-track mt-1" />
              <div>
                <p className="text-body-3 text-foreground">All tasks in {currentPhase} are complete.</p>
                <p className="text-caption text-muted-foreground">You can advance the phase safely.</p>
              </div>
            </div>
          ) : (
            <div className="space-y-2">
              <div className="flex items-start gap-2">
                <AlertTriangle className={cn("h-4 w-4 mt-1", blockedByRequired ? "text-status-at-risk" : "text-status-at-risk-mitigated")} />
                <div className="flex-1">
                  <p className="text-body-3 text-foreground">
                    {outstanding.length} open task{outstanding.length === 1 ? "" : "s"} in {currentPhase}
                    {blockedByRequired && (
                      <span className="text-status-at-risk"> · {requiredOpen.length} required</span>
                    )}
                  </p>
                  <p className="text-caption text-muted-foreground">
                    Closing will mark the phase complete; open items will carry over to {next} as overrides.
                  </p>
                </div>
              </div>
              <ul className="max-h-40 overflow-y-auto space-y-1 pl-6 pr-1">
                {outstanding.slice(0, 8).map((o) => (
                  <li key={o.id} className="text-caption text-foreground flex items-start gap-2">
                    <span className={cn(
                      "mt-1 inline-block h-2 w-2 rounded-full shrink-0",
                      o.status === "at-risk" ? "bg-status-at-risk" : "bg-status-at-risk-mitigated",
                    )} />
                    <span className="flex-1">
                      <span className="text-muted-foreground mr-1">[{o.track}{o.required ? " · required" : ""}]</span>
                      {o.title}
                    </span>
                  </li>
                ))}
                {outstanding.length > 8 && (
                  <li className="text-caption text-muted-foreground">+ {outstanding.length - 8} more</li>
                )}
              </ul>
            </div>
          )}
        </div>

        {reasonRequired && (
          <div className="space-y-2">
            <Label htmlFor="phase-close-reason" className="text-body-3 text-foreground">
              Reason for advancing with open items
            </Label>
            <Textarea
              id="phase-close-reason"
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              placeholder="Explain why this phase is being closed despite open tasks (min 8 characters)…"
              rows={3}
            />
          </div>
        )}

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
          <Button onClick={handleConfirm} disabled={!canConfirm}>
            {outstanding.length === 0 ? `Close ${currentPhase} & start ${next}` : `Override & advance to ${next}`}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
