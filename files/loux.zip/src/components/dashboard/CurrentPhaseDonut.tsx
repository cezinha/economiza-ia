import { useRef } from "react";
import { useNavigate } from "react-router-dom";
import { Cell, Pie, PieChart, ResponsiveContainer, Tooltip } from "recharts";
import { Card, CardHeader, CardContent } from "@/components/ui/card";
import { useFilteredLaunches, type StatusBucket } from "@/lib/applyFilters";
import { useFilters } from "@/contexts/FilterContext";
import { platformStatus } from "@/lib/launchTasks";

const SEGMENTS = [
  {
    key: "on-track",
    label: "Achieved / on track",
    color: "hsl(var(--status-on-track))",
    filterValue: "achieved" as StatusBucket,
  },
  {
    key: "at-risk-mitigated",
    label: "Risk with mitigation",
    color: "hsl(var(--status-at-risk-mitigated))",
    filterValue: "risk-mitigated" as StatusBucket,
  },
  {
    key: "at-risk",
    label: "Missed / no mitigation plan",
    color: "hsl(var(--status-at-risk))",
    filterValue: "missed" as StatusBucket,
  },
] as const;

export function CurrentPhaseDonut() {
  const launches = useFilteredLaunches();
  const exportRef = useRef<HTMLDivElement>(null);
  const navigate = useNavigate();
  const { setManyFilters } = useFilters();

  const total = launches.length;
  const data = SEGMENTS.map((s) => ({
    ...s,
    value: launches.filter((l) => platformStatus(l) === s.key).length,
  }));
  // DDS: largest slice first, drawn clockwise from 12 o'clock.
  const chartData = [...data]
    .filter((d) => d.value > 0)
    .sort((a, b) => b.value - a.value);

  const drillTo = (filterValue: StatusBucket) => {
    setManyFilters({ status: [filterValue] });
    navigate("/launches");
  };

  return (
    <Card className="border-border bg-surface shadow-elev-1 h-full flex flex-col">
      <CardHeader className="space-y-1">
        <h5 className="text-h5 text-foreground">Current phase status</h5>
        <p className="text-body-3 text-muted-foreground">Total count across active platforms</p>
      </CardHeader>

      <CardContent className="flex-1 flex flex-col">
        <div ref={exportRef} className="bg-surface flex-1 flex flex-col">
          <div className="relative flex-1 min-h-[320px] w-full">
            {total > 0 ? (
              <>
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Tooltip
                      cursor={false}
                      wrapperStyle={{ zIndex: 50, outline: "none", pointerEvents: "none" }}
                      allowEscapeViewBox={{ x: true, y: true }}
                      contentStyle={{
                        background: "hsl(var(--surface))",
                        border: "1px solid hsl(var(--border))",
                        borderRadius: 4,
                        fontSize: 12,
                      }}
                      formatter={(value: number, _name, item: any) => {
                        const pct = Math.round((value / total) * 100);
                        return [`${value} (${pct}%)`, item?.payload?.label];
                      }}
                    />
                    <Pie
                      data={chartData}
                      dataKey="value"
                      nameKey="label"
                      cx="50%"
                      cy="50%"
                      innerRadius="55%"
                      outerRadius="85%"
                      paddingAngle={2}
                      stroke="hsl(var(--surface))"
                      strokeWidth={2}
                      startAngle={90}
                      endAngle={-270}
                      cursor="pointer"
                      onClick={(d: any) => d?.filterValue && drillTo(d.filterValue)}
                      isAnimationActive={false}
                    >
                      {chartData.map((d) => (
                        <Cell key={d.key} fill={d.color} />
                      ))}
                    </Pie>
                  </PieChart>
                </ResponsiveContainer>
                <div className="pointer-events-none absolute inset-0 flex flex-col items-center justify-center">
                  <span className="text-display-2 text-foreground tabular-nums leading-none">{total}</span>
                  <span className="mt-2 text-body-3 text-muted-foreground">Active platforms</span>
                </div>
              </>
            ) : (
              <div className="flex h-full w-full items-center justify-center rounded-lg border border-dashed border-border text-caption text-muted-foreground">
                No active platforms
              </div>
            )}
          </div>

          <div className="mt-4 flex flex-wrap items-center justify-center gap-x-6 gap-y-2">
            {SEGMENTS.map((s) => {
              const value = data.find((d) => d.key === s.key)?.value ?? 0;
              const pct = total > 0 ? Math.round((value / total) * 100) : 0;
              return (
                <button
                  key={s.key}
                  type="button"
                  onClick={() => drillTo(s.filterValue)}
                  className="inline-flex items-center gap-2 text-caption text-foreground rounded-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring hover:underline"
                  aria-label={`Open OLP schedule filtered by ${s.label}. ${value} platforms (${pct}%).`}
                >
                  <span
                    className="inline-block h-2 w-2 rounded-full"
                    style={{ background: s.color }}
                  />
                  <span>{s.label}</span>
                  <span className="tabular-nums text-muted-foreground">
                    {value} ({pct}%)
                  </span>
                </button>
              );
            })}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
