import { FileDown } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { toast } from "@/hooks/use-toast";
import { downloadCsv } from "@/lib/csv";

type Row = Record<string, unknown>;

interface Props {
  rows: Row[];
  filename: string;
  headers?: string[];
  label?: string;
}

export function DownloadCsvButton({ rows, filename, headers, label = "Download as CSV" }: Props) {
  const onClick = () => {
    if (!rows.length) {
      toast({ title: "Nothing to export", description: "No rows available for this view." });
      return;
    }
    downloadCsv(filename, rows, headers);
    toast({ title: "CSV downloaded", description: `${filename}` });
  };

  return (
    <TooltipProvider>
      <Tooltip>
        <TooltipTrigger asChild>
          <Button
            type="button"
            variant="ghost"
            size="icon"
            onClick={onClick}
            aria-label={label}
            className="h-8 w-8 shrink-0 text-muted-foreground hover:text-foreground"
          >
            <FileDown className="h-4 w-4" aria-hidden />
          </Button>
        </TooltipTrigger>
        <TooltipContent side="left">{label}</TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
}
