import { RefObject, useState } from "react";
import { Download, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { toast } from "@/hooks/use-toast";
import { exportElementToPdf } from "@/lib/exportPdf";
import { useFilterSummary } from "@/lib/useFilterSummary";
import { useRole } from "@/contexts/RoleContext";
import { ROLES } from "@/contexts/RoleContext";

interface ExportPdfButtonProps {
  targetRef: RefObject<HTMLElement>;
  title: string;
  filenameSlug: string;
  orientation?: "portrait" | "landscape";
}

export function ExportPdfButton({ targetRef, title, filenameSlug, orientation = "landscape" }: ExportPdfButtonProps) {
  const [busy, setBusy] = useState(false);
  const filterSummary = useFilterSummary();
  const { role } = useRole();
  const roleLabel = ROLES.find((r) => r.value === role)?.label ?? role;

  const onClick = async () => {
    const el = targetRef.current;
    if (!el) return;
    setBusy(true);
    try {
      await exportElementToPdf(el, { title, filenameSlug, orientation, filterSummary, role: roleLabel });
      toast({ title: "PDF downloaded", description: `${title} exported.` });
    } catch (e) {
      console.error(e);
      toast({ title: "Export failed", description: "Could not generate PDF.", variant: "destructive" });
    } finally {
      setBusy(false);
    }
  };

  return (
    <TooltipProvider>
      <Tooltip>
        <TooltipTrigger asChild>
          <Button
            type="button"
            variant="ghost"
            size="icon"
            onClick={onClick}
            disabled={busy}
            aria-label="Export as PDF"
            className="h-8 w-8 shrink-0 text-muted-foreground hover:text-foreground"
          >
            {busy ? <Loader2 className="h-4 w-4 animate-spin" aria-hidden /> : <Download className="h-4 w-4" aria-hidden />}
          </Button>
        </TooltipTrigger>
        <TooltipContent side="left">Export as PDF</TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
}
