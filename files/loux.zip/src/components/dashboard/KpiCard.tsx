import { Card } from "@/components/ui/card";
import { cn } from "@/lib/utils";
import { LucideIcon, Info, TrendingUp, TrendingDown, Minus } from "lucide-react";

const AlertNoticeIcon: LucideIcon = (({ className, ...rest }: React.SVGProps<SVGSVGElement>) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 32 32"
    fill="currentColor"
    aria-hidden="true"
    className={className}
    {...rest}
  >
    <path d="M16 2.14l-16 27.72h32l-16-27.72zM16 6.14l12.48 21.6h-24.96l12.48-21.52zM14.96 24h2v2h-2zM14.96 12.1h2v10h-2z" />
  </svg>
)) as unknown as LucideIcon;

const AlertInfoCircleIcon: LucideIcon = (({ className, ...rest }: React.SVGProps<SVGSVGElement>) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 32 32"
    fill="currentColor"
    aria-hidden="true"
    className={className}
    {...rest}
  >
    <path d="M16 0c-8.837 0-16 7.163-16 16s7.163 16 16 16c8.837 0 16-7.163 16-16v0c0-8.837-7.163-16-16-16v0zM16 29.86c-7.655 0-13.86-6.205-13.86-13.86s6.205-13.86 13.86-13.86c7.655 0 13.86 6.205 13.86 13.86v0c-0.011 7.65-6.21 13.849-13.859 13.86h-0.001zM14.72 6.72h2.56v2.56h-2.56zM14.72 12.48h2.56v12.8h-2.56z" />
  </svg>
)) as unknown as LucideIcon;

export type KpiPill = {
  label: string;
  tone: "success" | "warning" | "danger" | "info" | "neutral" | "status-success" | "status-warning" | "status-danger" | "risk-high";
};

interface KpiCardProps {
  label: string;
  value: string | number;
  subtitle?: string;
  pill?: KpiPill;
  trend?: { deltaPct: number; invertColor?: boolean };
  icon?: LucideIcon; // kept for backward compatibility; not rendered in NUDD-style layout
  tone?: "default" | "success" | "warning" | "danger";
  onClick?: () => void;
  selected?: boolean;
}

const pillStyles: Record<KpiPill["tone"], { style: React.CSSProperties; Icon: LucideIcon }> = {
  success: {
    style: { backgroundColor: "#0F2A18", color: "#3FB57A" },
    Icon: Info,
  },
  warning: {
    style: { backgroundColor: "#3D2A00", color: "#F5CD6F" },
    Icon: AlertNoticeIcon,
  },
  danger: {
    style: { backgroundColor: "#002D4B", color: "#DAF5FD" },
    Icon: AlertInfoCircleIcon,
  },
  info: {
    style: { backgroundColor: "#DAF5FD", color: "#0468A1", border: "1px solid #61C1EB" },
    Icon: AlertInfoCircleIcon,
  },
  neutral: {
    style: {},
    Icon: AlertNoticeIcon,
  },
  "status-success": {
    style: { backgroundColor: "#5D8C00", color: "#E9F5CE" },
    Icon: Info,
  },
  "status-warning": {
    style: { backgroundColor: "#E6AC28", color: "#FEEFCB" },
    Icon: Info,
  },
  "status-danger": {
    style: { backgroundColor: "#D0353F", color: "#FFECEE" },
    Icon: Info,
  },
  "risk-high": {
    style: { backgroundColor: "#40155C", color: "#FBEBFF" },
    Icon: AlertInfoCircleIcon,
  },
};


export function KpiCard({ label, value, subtitle, pill, trend, onClick, selected }: KpiCardProps) {
  const interactive = typeof onClick === "function";
  const PillIcon = pill ? pillStyles[pill.tone].Icon : null;

  const trendDir = trend ? (trend.deltaPct > 0 ? "up" : trend.deltaPct < 0 ? "down" : "flat") : "flat";
  const TrendIcon = trendDir === "up" ? TrendingUp : trendDir === "down" ? TrendingDown : Minus;
  const trendColor =
    trendDir === "flat"
      ? "#6E6E6E"
      : (() => {
          const good = trend?.invertColor ? trendDir === "down" : trendDir === "up";
          return good ? "#436F00" : "#BB2A33";
        })();

  const inner = (
    <div className="flex h-full flex-col gap-4 p-4">
      <p className="text-body-3 text-muted-foreground leading-snug">{label}</p>
      <span className="text-subtitle-1 text-foreground tabular-nums leading-none">{value}</span>
      <div className="mt-auto flex items-center justify-between gap-2">

        {subtitle ? (
          <p
            className="text-body-2 text-muted-foreground flex-1 min-w-0 line-clamp-2 leading-snug"
            title={subtitle}
          >
            {subtitle}
          </p>
        ) : (
          <span className="flex-1" />
        )}
        {trend && (
          <span
            className="inline-flex items-center gap-1 text-body-3 whitespace-nowrap shrink-0 tabular-nums"
            style={{ color: trendColor }}
          >
            {trend.deltaPct > 0 ? "+" : ""}{trend.deltaPct}% MoM
            <TrendIcon className="h-3 w-3" aria-hidden />
          </span>
        )}
        {!trend && pill && PillIcon && (
          <span
            className="inline-flex items-center gap-2 rounded-full px-3 py-1 text-body-3 whitespace-nowrap shrink-0"
            style={pillStyles[pill.tone].style}
          >
            <PillIcon className="h-3 w-3" aria-hidden />
            {pill.label}
          </span>
        )}
      </div>
    </div>
  );

  const cardClass = cn(
    "relative flex flex-col overflow-hidden border-border bg-surface shadow-elev-1 transition-shadow h-full",
    interactive &&
      "cursor-pointer hover:shadow-elev-2 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring",
    !interactive && "hover:shadow-elev-2",
    selected && "ring-2 ring-primary shadow-elev-2",
  );

  if (interactive) {
    return (
      <Card
        role="button"
        tabIndex={0}
        aria-pressed={!!selected}
        onClick={onClick}
        onKeyDown={(e) => {
          if (e.key === "Enter" || e.key === " ") {
            e.preventDefault();
            onClick?.();
          }
        }}
        className={cardClass}
      >
        {inner}
      </Card>
    );
  }

  return <Card className={cardClass}>{inner}</Card>;
}
