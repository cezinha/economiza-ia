import { useEffect, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Progress } from "@/components/ui/progress";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useFilteredLaunches } from "@/lib/applyFilters";
import { RagBadge } from "./RagBadge";
import { WatchlistStar } from "./WatchlistStar";
import { ArrowUpRight, Sparkles } from "lucide-react";
import { useRole } from "@/contexts/RoleContext";
import { useAssignedPlatformIds } from "@/lib/permissions";
import { isNewlyPublished, subscribeLaunchUpdates } from "@/mocks/pendingPlatforms";

export function LaunchTable() {
  const launches = useFilteredLaunches();
  const { role } = useRole();
  const assignedIds = useAssignedPlatformIds();
  const showAssignmentHint = (role === "user" || role === "admin") && !!assignedIds;
  const [, force] = useState(0);
  useEffect(() => subscribeLaunchUpdates(() => force((n) => n + 1)), []);
  return (
    <Card className="border-border bg-surface shadow-elev-1">
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-4">

        <div>
          <CardTitle className="text-h6 text-foreground">Active launches</CardTitle>
          <p className="text-caption text-muted-foreground mt-1">Portfolio-wide product launches in flight</p>
        </div>
        <Button variant="ghost" size="sm" className="text-primary hover:text-primary-hover">
          View all <ArrowUpRight className="ml-2 h-4 w-4" />
        </Button>
      </CardHeader>
      <CardContent className="p-0">
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow className="hover:bg-transparent">
                <TableHead className="text-caption uppercase tracking-wide text-muted-foreground">Launch</TableHead>
                <TableHead className="text-caption uppercase tracking-wide text-muted-foreground">LOB</TableHead>
                <TableHead className="text-caption uppercase tracking-wide text-muted-foreground">Phase</TableHead>
                <TableHead className="text-caption uppercase tracking-wide text-muted-foreground">Owner</TableHead>
                <TableHead className="text-caption uppercase tracking-wide text-muted-foreground w-[180px]">Progress</TableHead>
                <TableHead className="text-caption uppercase tracking-wide text-muted-foreground">Next milestone</TableHead>
                <TableHead className="text-caption uppercase tracking-wide text-muted-foreground">Status</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {launches.map((l) => {
                const isAssigned = assignedIds?.has(l.id) ?? true;
                return (
                <TableRow key={l.id} className="cursor-pointer">
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <WatchlistStar platformId={l.id} platformName={l.name} />
                      <div>
                        <div className="font-medium text-foreground flex items-center gap-2">
                          {l.name}
                          {isNewlyPublished(l.id) && (
                            <Badge variant="default" className="text-caption gap-1">
                              <Sparkles className="h-3 w-3" /> New from Jira
                            </Badge>
                          )}
                          {showAssignmentHint && !isAssigned && (
                            <Badge variant="outline" className="text-caption font-normal">
                              View only
                            </Badge>
                          )}
                        </div>
                        <div className="text-caption text-muted-foreground">{l.id} · {l.region}</div>
                      </div>
                    </div>
                  </TableCell>

                  <TableCell className="text-body-3 text-foreground">{l.lob}</TableCell>
                  <TableCell className="text-body-3 text-foreground">{l.phase}</TableCell>
                  <TableCell className="text-body-3 text-foreground">{l.owner}</TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <Progress value={l.progress} className="h-2" />
                      <span className="text-caption text-muted-foreground tabular-nums w-8 text-right">{l.progress}%</span>
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="text-body-3 text-foreground">{l.nextMilestone}</div>
                    <div className="text-caption text-muted-foreground">{l.nextMilestoneDate}</div>
                  </TableCell>
                  <TableCell><RagBadge rag={l.rag} /></TableCell>
                </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  );
}
