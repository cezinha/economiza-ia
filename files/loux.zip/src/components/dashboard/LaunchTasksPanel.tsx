import { useEffect, useMemo, useState } from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ChevronRight } from "lucide-react";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { TaskDetailDrawer } from "@/components/dashboard/TaskDetailDrawer";
import type { Launch } from "@/mocks/launches";
import {
  tasksForLaunch,
  groupTasksByPhaseAndGate,
  taskStatus,
  isAutoTask,
  worstActive,
  type TaskFunction,
  type TaskStatus,
  type LaunchTask,
} from "@/lib/launchTasks";
import { cn } from "@/lib/utils";
import { PhaseExitTracker } from "@/components/dashboard/PhaseExitTracker";
import { ScheduleDrilldown } from "@/components/dashboard/ScheduleDrilldown";

import { StatusUpdateReport } from "@/components/dashboard/StatusUpdateReport";
import { useViewFilter } from "@/contexts/ViewFilterContext";
import { useFilters } from "@/contexts/FilterContext";
import { useRole } from "@/contexts/RoleContext";
import { useAssignedPlatformIds, useCanActOnPlatform, isSensitiveLockedFor } from "@/lib/permissions";
// RunwayChip/TaskDueBadge removed — consolidated into TaskRunwayChip "Warning" pill.
import { Bell, Eye, Lock } from "lucide-react";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { useTaskNotifications } from "@/lib/taskNotifications";
import { buildLaunchDependencyResolver } from "@/lib/taskDependencies";
import { TaskDependencyChip } from "@/components/dashboard/TaskDependencyChip";
import { TaskRunwayChip } from "@/components/dashboard/TaskRunwayChip";
import { TaskExpeditedChip } from "@/components/dashboard/TaskExpeditedChip";
import { StatusLegend } from "@/components/dashboard/StatusLegend";



const trackLabel = (t: TaskFunction): string => (t === "SChM" ? "SChM" : t);

const TRACKS: TaskFunction[] = ["GOE", "NPI", "SChM"];

const PHASE_CANONICAL_TEAMS: Record<string, TaskFunction[]> = {
  Concept: ["GOE", "NPI", "SChM"],
  Define: ["GOE", "NPI", "SChM"],
  Plan: ["GOE", "NPI", "SChM"],
  Develop: ["SChM"],
  Qual: ["GOE", "NPI"],
  Pilot: ["GOE", "NPI"],
  Launch: ["SChM"],
  Ramp: ["GOE", "NPI"],
};

const STATUS_CLASS: Record<TaskStatus, string> = {
  completed: "bg-status-completed",
  "on-track": "bg-status-on-track",
  "at-risk-mitigated": "bg-status-at-risk-mitigated",
  "at-risk": "bg-status-at-risk",
  "not-started": "bg-status-not-started",
};

function StatusDot({ status, className }: { status: TaskStatus; className?: string }) {
  return (
    <span
      className={cn("inline-block h-2 w-2 rounded-full shrink-0", STATUS_CLASS[status], className)}
      aria-hidden
    />
  );
}

interface LaunchTasksPanelProps {
  launch: Launch;
  initialTab?: "report" | "tasks" | "exit" | "schedule";
  initialPhase?: string;
  initialGate?: string;
}

export function LaunchTasksPanel({ launch, initialTab, initialPhase, initialGate }: LaunchTasksPanelProps) {
  const { lockedFunction } = useViewFilter();
  void lockedFunction;
  const { filters } = useFilters();
  const fnFilter = Array.isArray(filters.function) ? (filters.function as TaskFunction[]) : [];
  const activeTrack: TaskFunction | "all" = fnFilter.length === 1 ? fnFilter[0] : "all";
  const { role } = useRole();
  const assignedIds = useAssignedPlatformIds();
  const canAct = useCanActOnPlatform(launch.id);
  const isScoped = role === "admin" || role === "user";
  const isViewOnly = isScoped && !!assignedIds && !canAct;
  const isReadOnly = role === "executive";
  

  const [selectedTask, setSelectedTask] = useState<LaunchTask | null>(null);
  const [hintDismissed, setHintDismissed] = useState(false);
  const [showCompleted, setShowCompleted] = useState(false);
  const [tab, setTab] = useState<"report" | "tasks" | "exit" | "schedule">(initialTab ?? "report");
  const [openPhases, setOpenPhases] = useState<string[]>(
    initialPhase ? [`phase-${initialPhase}`] : [],
  );

  const [openGates, setOpenGates] = useState<string[]>(
    initialPhase && initialGate ? [`gate-${initialPhase}-${initialGate}`] : [],
  );

  useEffect(() => {
    if (initialTab) setTab(initialTab);
  }, [initialTab]);

  useEffect(() => {
    if (initialPhase) {
      const v = `phase-${initialPhase}`;
      setOpenPhases((prev) => (prev.includes(v) ? prev : [...prev, v]));
    }
  }, [initialPhase]);

  useEffect(() => {
    if (initialPhase && initialGate) {
      const v = `gate-${initialPhase}-${initialGate}`;
      setOpenGates((prev) => (prev.includes(v) ? prev : [...prev, v]));
    }
  }, [initialPhase, initialGate]);

  const allLaunchTasks = tasksForLaunch(launch);
  const dependencyResolver = useMemo(
    () => buildLaunchDependencyResolver(launch, allLaunchTasks),
    [launch, allLaunchTasks],
  );
  const launchTasks =
    fnFilter.length === 0
      ? allLaunchTasks
      : allLaunchTasks.filter((t) => t.teams.some((tm) => fnFilter.includes(tm)));
  const grouped = groupTasksByPhaseAndGate(launchTasks);

  if (activeTrack !== "SChM" && !grouped.some((p) => p.phase === "Ramp")) {
    const launchIdx = grouped.findIndex((p) => p.phase === "Launch");
    const entry = { phase: "Ramp", totalTasks: 0, gates: [] };
    if (launchIdx >= 0) grouped.splice(launchIdx, 0, entry);
    else grouped.push(entry);
  }

  const phaseRolledMap = new Map<string, TaskStatus>();
  grouped.forEach((p) => {
    const all = p.gates.flatMap((g) =>
      g.tasks.flatMap((t) => t.teams.map((tm) => taskStatus(launch, t, tm))),
    );
    let rolled: TaskStatus;
    if (all.length === 0) rolled = "not-started";
    else if (all.every((s) => s === "completed")) rolled = "completed";
    else if (all.every((s) => s === "not-started")) rolled = "not-started";
    else {
      const active = all.filter((s) => s !== "completed" && s !== "not-started");
      rolled = active.length > 0 ? worstActive(active) : "on-track";
    }
    phaseRolledMap.set(p.phase, rolled);
  });
  const completedPhaseCount = grouped.filter(
    (p) => phaseRolledMap.get(p.phase) === "completed",
  ).length;
  const visibleGrouped = showCompleted
    ? grouped
    : grouped.filter((p) => phaseRolledMap.get(p.phase) !== "completed");

  return (
    <>
      {isViewOnly && (
        <div className="mb-4 flex items-start gap-2 rounded-md border border-border bg-muted/40 px-3 py-2">
          <Eye className="h-4 w-4 mt-1 text-muted-foreground shrink-0" aria-hidden />
          <p className="text-caption text-muted-foreground">
            <span className="text-foreground font-medium">View only.</span>{" "}
            {launch.name} isn't in your assigned platforms — you can browse,
            comment, flag risks, and attach files. Completing or updating
            tasks is reserved for assigned owners.
          </p>
        </div>
      )}
      <Tabs value={tab} onValueChange={(v) => setTab(v as "report" | "tasks" | "exit" | "schedule")} className="w-full">
        <TabsList>
          <TabsTrigger value="report">Status report</TabsTrigger>
          <TabsTrigger value="tasks">Task list</TabsTrigger>

          <TabsTrigger value="exit">Phase exit tracker</TabsTrigger>
          
        </TabsList>

        <TabsContent value="report" className="pt-4">
          <ScheduleDrilldown
            launchId={launch.id}
            title={`${launch.name} · Status update`}
            footer={<StatusUpdateReport launch={launch} />}
          />
        </TabsContent>

        <TabsContent value="tasks" className="pt-4">
          <StatusLegend className="mb-3" />
          <div className="flex items-center justify-start gap-4 mb-4 flex-wrap">
            <p className="text-body-3 text-muted-foreground">
              Showing {launchTasks.length} of {allLaunchTasks.length} tasks
            </p>
            {completedPhaseCount > 0 && (
              <label
                htmlFor="show-completed-phases"
                className="inline-flex items-center gap-2 cursor-pointer select-none"
              >
                <Checkbox
                  id="show-completed-phases"
                  checked={showCompleted}
                  onCheckedChange={(v) => setShowCompleted(v === true)}
                />
                <span className="text-body-3 text-muted-foreground">
                  Show {completedPhaseCount} completed phase{completedPhaseCount === 1 ? "" : "s"}
                </span>
              </label>
            )}
          </div>
          {launchTasks.length === 0 ? (
            <p className="text-body-3 text-muted-foreground italic">No tasks match this filter.</p>
          ) : visibleGrouped.length === 0 ? (
            <p className="text-body-3 text-muted-foreground italic">All phases completed.</p>
          ) : (

            <Accordion type="multiple" value={openPhases} onValueChange={setOpenPhases} className="w-full">
              {visibleGrouped.map((p) => {
                const phaseGateStatuses = p.gates.map((g) =>
                  worstActive(
                    g.tasks.flatMap((t) => t.teams.map((tm) => taskStatus(launch, t, tm))),
                  ),
                );
                const phaseRolled = phaseRolledMap.get(p.phase) ?? ("not-started" as TaskStatus);
                const derived = TRACKS.filter((tr) =>
                  p.gates.some((g) => g.tasks.some((t) => t.teams.includes(tr))),
                );
                const canonical = (PHASE_CANONICAL_TEAMS[p.phase] ?? []).filter(
                  (tr) => fnFilter.length === 0 || fnFilter.includes(tr),
                );
                const phaseTeams = derived.length > 0 ? derived : canonical;

                return (
                  <AccordionItem
                    key={p.phase}
                    value={`phase-${p.phase}`}
                    className="border-border"
                  >
                    <AccordionTrigger className="py-2 hover:no-underline">
                      <span className="flex items-center gap-2 text-body-3 font-medium text-foreground">
                        <StatusDot status={phaseRolled} />
                        {p.phase}
                        <span className="text-body-3 font-normal text-muted-foreground">
                          {p.totalTasks}
                        </span>
                        <span className="flex items-center gap-1 ml-2">
                          {phaseTeams.map((tm) => (
                            <Badge
                              key={tm}
                              variant="outline"
                              className="text-body-3 font-medium px-2 py-0"
                            >
                              {trackLabel(tm)}
                            </Badge>
                          ))}
                        </span>
                      </span>
                    </AccordionTrigger>
                    <AccordionContent className="pb-2">
                      <Accordion type="multiple" value={openGates} onValueChange={setOpenGates} className="w-full pl-4">
                        {p.gates.map((g, gi) => (
                          <AccordionItem
                            key={g.gate}
                            value={`gate-${p.phase}-${g.gate}`}
                            className="border-border"
                          >
                            <AccordionTrigger className="py-2 hover:no-underline">
                              <span className="flex items-center gap-2 text-body-3 text-foreground text-left">
                                <StatusDot status={phaseGateStatuses[gi]} />
                                {g.gate}
                                <span className="text-body-3 font-normal text-muted-foreground">
                                  {g.tasks.length}
                                </span>
                              </span>
                            </AccordionTrigger>
                            <AccordionContent className="pb-2">
                              <ul className="space-y-2 pl-4">
                                {g.tasks.map((t) => {
                                  const tStatus = worstActive(
                                    t.teams.map((tm) => taskStatus(launch, t, tm)),
                                  );
                                  const dep = dependencyResolver.chip(t);
                                  const isBlocked =
                                    tStatus !== "completed" && dep.blockers.length > 0;

                                  const sensitive = isSensitiveLockedFor(role, lockedFunction, t);
                                  const interactive = !sensitive;
                                  return (
                                    <li key={t.id}>
                                      <div
                                        role={interactive ? "button" : undefined}
                                        tabIndex={interactive ? 0 : undefined}
                                        onClick={
                                          interactive
                                            ? () => {
                                                setHintDismissed(true);
                                                setSelectedTask(t);
                                              }
                                            : undefined
                                        }
                                        onKeyDown={
                                          interactive
                                            ? (e) => {
                                                if (e.key === "Enter" || e.key === " ") {
                                                  e.preventDefault();
                                                  setHintDismissed(true);
                                                  setSelectedTask(t);
                                                }
                                              }
                                            : undefined
                                        }
                                        aria-disabled={!interactive || undefined}
                                        className={cn(
                                          "group flex items-start gap-3 text-body-3 w-full text-left rounded-md px-2 py-1 -mx-2 border-l-2 border-transparent transition-colors",
                                          interactive
                                            ? "hover:bg-muted/40 hover:border-primary cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                                            : "cursor-default",
                                          isBlocked && "opacity-60",
                                        )}
                                      >
                                        <StatusDot status={tStatus} className="mt-2" />
                                        <div className="flex flex-col gap-1 shrink-0 w-16">
                                          {t.teams.map((tm) => (
                                            <Badge
                                              key={tm}
                                              variant="outline"
                                              className="text-body-3 font-medium justify-center"
                                            >
                                              {trackLabel(tm)}
                                            </Badge>
                                          ))}
                                        </div>
                                        <div className="min-w-0 flex-1">
                                          <p className="text-body-3 text-foreground">
                                            {t.l3Id != null && (
                                              <span className="text-muted-foreground tabular-nums mr-2">#{t.l3Id}</span>
                                            )}
                                            {t.task}
                                            {isAutoTask(t) && (
                                              <Badge variant="secondary" className="ml-2 align-middle text-body-3">Auto</Badge>
                                            )}
                                            <TaskNotificationDot taskId={t.id} />
                                          </p>

                                          {t.taskEnd && (
                                            <p className="text-body-3 text-muted-foreground mt-1">
                                              {t.taskEnd}
                                            </p>
                                          )}
                                          <div className="mt-1 flex items-center gap-2 flex-wrap">
                                            <TaskRunwayChip task={t} launch={launch} status={tStatus} />
                                            <TaskExpeditedChip task={t} launch={launch} status={tStatus} />
                                            {sensitive && (
                                              <TooltipProvider delayDuration={150}>
                                                <Tooltip>
                                                  <TooltipTrigger asChild>
                                                    <Badge
                                                      variant="outline"
                                                      className="text-body-3 gap-1 cursor-default"
                                                    >
                                                      <Lock className="h-3 w-3" />
                                                      Sensitive information
                                                    </Badge>
                                                  </TooltipTrigger>
                                                  <TooltipContent side="top" className="max-w-xs text-body-3">
                                                    SChM-only task — sensitive supply chain data.
                                                    Switch to a SChM view to open.
                                                  </TooltipContent>
                                                </Tooltip>
                                              </TooltipProvider>
                                            )}
                                            {tStatus !== "completed" && (
                                              <TaskDependencyChip
                                                blockers={dep.blockers}
                                                recentlyCleared={dep.recentlyCleared}
                                                onClick={
                                                  interactive
                                                    ? () => {
                                                        setHintDismissed(true);
                                                        setSelectedTask(t);
                                                      }
                                                    : undefined
                                                }
                                              />
                                            )}
                                          </div>
                                        </div>
                                        <div className="self-center flex items-center gap-2 shrink-0">
                                          {interactive && (
                                            <button
                                              type="button"
                                              onClick={(e) => {
                                                e.stopPropagation();
                                                setHintDismissed(true);
                                                setSelectedTask(t);
                                              }}
                                              aria-label={`View details for ${t.task}`}
                                              className="inline-flex items-center gap-1 rounded-sm px-1 text-caption text-primary hover:underline whitespace-nowrap focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                                            >
                                              View details
                                              <ChevronRight className="h-3 w-3" />
                                            </button>
                                          )}
                                        </div>

                                      </div>
                                    </li>
                                  );
                                })}
                              </ul>
                            </AccordionContent>
                          </AccordionItem>
                        ))}
                      </Accordion>
                    </AccordionContent>
                  </AccordionItem>
                );
              })}
            </Accordion>
          )}
        </TabsContent>

        <TabsContent value="exit" className="pt-4">
          <PhaseExitTracker launch={launch} />
        </TabsContent>
      </Tabs>

      <TaskDetailDrawer
        task={selectedTask}
        launch={launch}
        initialStatus={
          selectedTask
            ? worstActive(selectedTask.teams.map((tm) => taskStatus(launch, selectedTask, tm)))
            : "not-started"
        }
        onOpenChange={(o) => !o && setSelectedTask(null)}
      />
      
    </>

  );
}

function TaskNotificationDot({ taskId }: { taskId: string }) {
  const summary = useTaskNotifications(taskId);
  if (summary.total === 0) return null;
  const label = summary.hasAssignmentRequest
    ? "Pending assignment request"
    : `${summary.total} notification${summary.total === 1 ? "" : "s"}`;
  return (
    <span
      className="ml-2 inline-flex items-center align-middle"
      title={label}
      aria-label={label}
    >
      <span className="relative inline-flex">
        <Bell className="h-3 w-3 text-primary" strokeWidth={2} />
        <span className="absolute -top-1 -right-1 h-2 w-2 rounded-full bg-status-at-risk" aria-hidden />
      </span>
    </span>
  );
}
