import { useEffect, useRef, useState } from "react";
import { RefreshCw } from "lucide-react";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { cn } from "@/lib/utils";

interface Props {
  intervalMs?: number;
}

/**
 * Placeholder "freshness" indicator for task data.
 * Shows "Updated N min ago" and an auto-refresh countdown.
 * No real refetch yet — purely cosmetic, ready to be wired later.
 */
export function LiveRefreshIndicator({ intervalMs = 5 * 60_000 }: Props) {
  // Random starting offset (1..4 min) so first render shows e.g. "2 min ago".
  const initialOffsetMs = useRef<number>(
    (Math.floor(Math.random() * 4) + 1) * 60_000,
  );
  const [lastUpdatedAt, setLastUpdatedAt] = useState<number>(
    () => Date.now() - initialOffsetMs.current,
  );
  const [remainingMs, setRemainingMs] = useState<number>(
    () => Math.max(1000, intervalMs - initialOffsetMs.current),
  );
  const [justRefreshed, setJustRefreshed] = useState(false);
  const [now, setNow] = useState<number>(Date.now());

  useEffect(() => {
    const id = window.setInterval(() => {
      setNow(Date.now());
      setRemainingMs((prev) => {
        const next = prev - 1000;
        if (next <= 0) {
          setLastUpdatedAt(Date.now());
          setJustRefreshed(true);
          window.setTimeout(() => setJustRefreshed(false), 700);
          return intervalMs;
        }
        return next;
      });
    }, 1000);
    return () => window.clearInterval(id);
  }, [intervalMs]);

  const minutesAgo = Math.max(1, Math.floor((now - lastUpdatedAt) / 60_000));
  const totalSeconds = Math.max(0, Math.ceil(remainingMs / 1000));
  const mm = Math.floor(totalSeconds / 60);
  const ss = String(totalSeconds % 60).padStart(2, "0");

  return (
    <TooltipProvider delayDuration={200}>
      <div className="inline-flex items-center gap-3 rounded-full border border-border bg-muted/40 px-3 py-1">
        <Tooltip>
          <TooltipTrigger asChild>
            <span className="inline-flex items-center gap-2 text-caption text-muted-foreground">
              Updated {minutesAgo} min ago
            </span>
          </TooltipTrigger>
          <TooltipContent>Data refreshes every 5 minutes or when you complete a task.</TooltipContent>
        </Tooltip>
        <span className="h-3 w-px bg-border" aria-hidden />
        <Tooltip>
          <TooltipTrigger asChild>
            <span className="inline-flex items-center gap-2 text-caption text-muted-foreground tabular-nums">
              <RefreshCw
                className={cn("h-3 w-3", justRefreshed && "animate-spin")}
                aria-hidden
              />
              Refresh in {mm}:{ss}
            </span>
          </TooltipTrigger>
          <TooltipContent>Next automatic sync with Regrello.</TooltipContent>
        </Tooltip>
      </div>
    </TooltipProvider>
  );
}
