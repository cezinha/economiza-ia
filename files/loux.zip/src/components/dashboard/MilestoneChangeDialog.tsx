import { useMemo, useState } from "react";
import { CalendarClock, AlertTriangle, ArrowRight } from "lucide-react";
import { toast } from "sonner";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import type { Launch } from "@/mocks/launches";
import { tasksForLaunch, type LaunchTask } from "@/lib/launchTasks";
import { getMinDuration } from "@/lib/minDuration";
import { setLaunchDateOverride, effectiveLaunchDate } from "@/mocks/launchDateOverrides";
import { createException } from "@/mocks/runwayExceptions";
import { CURRENT_USER_NAME } from "@/mocks/assignmentRequests";
import { resolveDueDateIso } from "@/mocks/taskDetails";

interface Props {
  launch: Launch;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}



function diffDays(aIso: string, bIso: string): number {
  const a = new Date(aIso + "T00:00:00Z").getTime();
  const b = new Date(bIso + "T00:00:00Z").getTime();
  return Math.round((a - b) / 86_400_000);
}

interface ImpactRow {
  task: LaunchTask;
  currentDue: string;
  proposedDue: string;
  shiftDays: number;
  currentRunway: number;
  proposedRunway: number;
  minDays: number;
  belowMin: boolean;
}

export function MilestoneChangeDialog({ launch, open, onOpenChange }: Props) {
  const currentRts = effectiveLaunchDate(launch);
  const [target, setTarget] = useState(currentRts);
  const [reason, setReason] = useState("");

  const todayIso = new Date().toISOString().slice(0, 10);

  const impact = useMemo(() => {
    const tasks = tasksForLaunch(launch);
    const rows: ImpactRow[] = tasks.map((t) => {
      const currentDue = resolveDueDateIso(launch, t);
      const proposedDue = resolveDueDateIso({ ...launch, launchDate: target }, t);
      const min = getMinDuration(t);
      const currentRunway = diffDays(currentDue, todayIso);
      const proposedRunway = diffDays(proposedDue, todayIso);
      const shiftDays = diffDays(proposedDue, currentDue);
      return {
        task: t,
        currentDue,
        proposedDue,
        shiftDays,
        currentRunway,
        proposedRunway,
        minDays: min.days,
        belowMin: proposedRunway < min.days,
      };
    });
    return rows;
  }, [launch, currentRts, target, todayIso]);

  const totalShiftDays = diffDays(target, currentRts);
  const flagged = impact.filter((r) => r.belowMin && !(r.currentRunway < r.minDays));
  const stillFlagged = impact.filter((r) => r.belowMin);
  const earlier = impact.filter((r) => r.shiftDays < 0).length;
  const later = impact.filter((r) => r.shiftDays > 0).length;
  const unchanged = impact.length - earlier - later;

  const apply = (alsoRequestExceptions: boolean) => {
    if (target === currentRts) {
      toast.info("Pick a different date to apply a change");
      return;
    }
    if (!reason.trim()) {
      toast.error("A reason is required for any milestone date change");
      return;
    }
    setLaunchDateOverride({
      launch,
      newDate: target,
      by: CURRENT_USER_NAME,
      reason: reason.trim(),
      flaggedTaskCount: stillFlagged.length,
    });
    if (alsoRequestExceptions) {
      for (const r of stillFlagged) {
        createException({
          taskId: r.task.id,
          taskName: r.task.task,
          launchId: launch.id,
          launchName: launch.name,
          runwayDays: r.proposedRunway,
          minDays: r.minDays,
          reason: `Auto-created from RTS shift: ${reason.trim()}`,
          requestedBy: CURRENT_USER_NAME,
        });
      }
    }
    toast.success(
      `RTS moved ${totalShiftDays >= 0 ? "+" : ""}${totalShiftDays}d` +
        (alsoRequestExceptions && stillFlagged.length
          ? ` · ${stillFlagged.length} exception${stillFlagged.length === 1 ? "" : "s"} requested`
          : ""),
    );
    onOpenChange(false);
    setReason("");
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-3xl max-h-[85vh] flex flex-col gap-0 p-0">
        <DialogHeader className="px-6 pt-6 pb-4 border-b border-border">
          <DialogTitle className="flex items-center gap-2 text-h4">
            <CalendarClock className="h-5 w-5 text-primary" />
            Edit RTS — {launch.name}
          </DialogTitle>
          <DialogDescription>
            Move the RTS milestone and preview which downstream tasks fall below their
            recommended minimum runway. The change requires a reason and is logged.
          </DialogDescription>
        </DialogHeader>

        <div className="px-6 py-4 border-b border-border space-y-3">
          <div className="grid grid-cols-1 m:grid-cols-2 gap-4">
            <div className="space-y-1">
              <Label className="text-caption">Current RTS</Label>
              <p className="text-body-2 tabular-nums text-foreground">{currentRts}</p>
            </div>
            <div className="space-y-1">
              <Label htmlFor="rts-new" className="text-caption">New RTS</Label>
              <Input
                id="rts-new"
                type="date"
                value={target}
                onChange={(e) => setTarget(e.target.value)}
              />
              <p className="text-caption text-muted-foreground tabular-nums">
                Shift: {totalShiftDays >= 0 ? "+" : ""}{totalShiftDays}d
              </p>
            </div>
          </div>
          <div className="space-y-1">
            <Label htmlFor="rts-reason" className="text-caption">Reason for change</Label>
            <Textarea
              id="rts-reason"
              rows={2}
              placeholder="e.g. POR was 6.1 but DFE completed 5.30 — pulling RTS in by 1 week to recover schedule."
              value={reason}
              onChange={(e) => setReason(e.target.value)}
            />
          </div>
        </div>

        <div className="px-6 py-3 border-b border-border flex flex-wrap items-center gap-3 text-caption text-muted-foreground">
          <span>{impact.length} task{impact.length === 1 ? "" : "s"} on this launch</span>
          <span aria-hidden>·</span>
          <span>{earlier} shift earlier</span>
          <span aria-hidden>·</span>
          <span>{later} shift later</span>
          <span aria-hidden>·</span>
          <span>{unchanged} unchanged</span>
          {stillFlagged.length > 0 && (
            <Badge variant="outline" className="gap-1 border-status-at-risk/50 text-status-at-risk">
              <AlertTriangle className="h-3 w-3" />
              {stillFlagged.length} below min
            </Badge>
          )}
        </div>

        <div className="flex-1 overflow-y-auto">
          {stillFlagged.length === 0 ? (
            <div className="px-6 py-10 text-center text-body-3 text-muted-foreground">
              No tasks fall below their recommended minimum runway with this change.
            </div>
          ) : (
            <table className="w-full text-caption">
              <thead className="sticky top-0 bg-muted/40 text-muted-foreground">
                <tr>
                  <th className="text-left px-6 py-2 font-medium">Task</th>
                  <th className="text-left px-3 py-2 font-medium">Phase</th>
                  <th className="text-right px-3 py-2 font-medium">Current</th>
                  <th className="text-right px-3 py-2 font-medium">Proposed</th>
                  <th className="text-right px-6 py-2 font-medium">Min</th>
                </tr>
              </thead>
              <tbody>
                {stillFlagged
                  .sort((a, b) => a.proposedRunway - b.proposedRunway)
                  .map((r) => {
                    const newlyFlagged = !(r.currentRunway < r.minDays);
                    return (
                      <tr key={r.task.id} className="border-t border-border">
                        <td className="px-6 py-2 text-foreground">
                          <div className="flex items-center gap-2">
                            <span className="line-clamp-1" title={r.task.task}>{r.task.task}</span>
                            {newlyFlagged && (
                              <Badge variant="outline" className="text-caption border-status-at-risk-mitigated/60 text-status-at-risk-mitigated">
                                new
                              </Badge>
                            )}
                          </div>
                        </td>
                        <td className="px-3 py-2 text-muted-foreground">{r.task.phase}</td>
                        <td className="px-3 py-2 text-right tabular-nums text-muted-foreground">
                          {r.currentRunway}d
                        </td>
                        <td className="px-3 py-2 text-right tabular-nums">
                          <span className={cn(r.belowMin && "text-status-at-risk font-medium")}>
                            <ArrowRight className="inline h-3 w-3 mr-1 text-muted-foreground" aria-hidden />
                            {r.proposedRunway}d
                          </span>
                        </td>
                        <td className="px-6 py-2 text-right tabular-nums text-muted-foreground">
                          {r.minDays}d
                        </td>
                      </tr>
                    );
                  })}
              </tbody>
            </table>
          )}
        </div>

        <DialogFooter className="px-6 py-4 border-t border-border gap-2">
          <Button variant="ghost" onClick={() => onOpenChange(false)}>Cancel</Button>
          <Button
            variant="secondary-dds"
            onClick={() => apply(false)}
            disabled={target === currentRts}
          >
            Apply change
          </Button>
          {stillFlagged.length > 0 && (
            <Button
              onClick={() => apply(true)}
              disabled={target === currentRts}
            >
              Apply &amp; request {stillFlagged.length} exception{stillFlagged.length === 1 ? "" : "s"}
            </Button>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
