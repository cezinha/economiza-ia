import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useFilteredMilestones } from "@/lib/applyFilters";
import { cn } from "@/lib/utils";
import { Calendar } from "lucide-react";

const statusCls = {
  complete: "bg-success",
  in_progress: "bg-primary",
  upcoming: "bg-muted-foreground/40",
  at_risk: "bg-danger",
};

const statusLabel = {
  complete: "Complete",
  in_progress: "In progress",
  upcoming: "Upcoming",
  at_risk: "At risk",
};

export function MilestoneTimeline() {
  const milestones = useFilteredMilestones();
  return (
    <Card className="border-border bg-surface shadow-elev-1">
      <CardHeader className="pb-4">
        <CardTitle className="text-h6 text-foreground flex items-center gap-2">
          <Calendar className="h-4 w-4 text-primary" />
          Upcoming gates & milestones
        </CardTitle>
        <p className="text-caption text-muted-foreground">Next 30 days across the portfolio</p>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {milestones.map((m) => (
            <div key={m.id} className="flex items-center gap-3">
              <div className={cn("h-2 w-2 rounded-full shrink-0", statusCls[m.status])} />
              <div className="flex-1 min-w-0">
                <p className="text-body-3 font-medium text-foreground truncate">{m.name}</p>
                <p className="text-caption text-muted-foreground">{m.launchId} · {m.date}</p>
              </div>
              <span className="text-caption text-muted-foreground shrink-0">{statusLabel[m.status]}</span>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
