import { useState } from "react";
import { KpiCard } from "@/components/dashboard/KpiCard";
import { useFilteredNudds } from "@/lib/applyFilters";
import { NuddListDrawer } from "@/components/dashboard/drawers/NuddListDrawer";
import type { NuddRow } from "@/mocks/nudds";

type Props = { onOpenRow?: (row: NuddRow) => void };

export function NuddActiveMetric({ onOpenRow }: Props = {}) {
  const NUDDS = useFilteredNudds();
  const [open, setOpen] = useState(false);

  const rows = NUDDS.filter((n) => n.status === "Open" || n.status === "On hold");
  const count = rows.length;
  const disabled = count === 0;

  // MoM delta: active count now vs active count at end of previous month.
  const now = new Date();
  const startOfThisMonth = Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), 1);
  let prevActive = 0;
  for (const n of NUDDS) {
    const created = new Date(n.created + "T00:00:00Z").getTime();
    const closed =
      n.status === "Completed" ? new Date(n.updated + "T00:00:00Z").getTime() : null;
    if (created < startOfThisMonth && (closed === null || closed >= startOfThisMonth)) {
      prevActive++;
    }
  }
  let deltaPct: number;
  if (prevActive === 0) {
    deltaPct = count === 0 ? 0 : 100;
  } else {
    deltaPct = Math.round(((count - prevActive) / prevActive) * 100);
  }

  return (
    <>
      <KpiCard
        label="Active NUDDs (open / on hold)"
        value={count}
        subtitle="Total count"
        trend={{ deltaPct, invertColor: true }}
        onClick={disabled ? undefined : () => setOpen(true)}
      />
      <NuddListDrawer
        open={open}
        onOpenChange={setOpen}
        eyebrow="Active NUDDs"
        title={`${count} active NUDD${count === 1 ? "" : "s"}`}
        description="NUDDs currently Open or On hold."
        rows={rows}
        emptyMessage="No active NUDDs."
        onSelectRow={onOpenRow}
      />
    </>
  );
}
