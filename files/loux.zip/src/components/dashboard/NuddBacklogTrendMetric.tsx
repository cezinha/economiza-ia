import { KpiCard } from "@/components/dashboard/KpiCard";
import { useFilteredNudds } from "@/lib/applyFilters";
import type { NuddRow } from "@/mocks/nudds";

type Props = { onOpenRow?: (row: NuddRow) => void };

// Compute end-of-month open/on-hold backlog for the last two months.
function backlogAt(items: { created: number; closed: number | null }[], endMs: number) {
  let n = 0;
  for (const it of items) {
    const closedByEnd = it.closed !== null && it.closed < endMs;
    if (it.created < endMs && !closedByEnd) n++;
  }
  return n;
}

export function NuddBacklogTrendMetric(_props: Props = {}) {
  const NUDDS = useFilteredNudds();

  const items = NUDDS.map((n) => ({
    created: new Date(n.created + "T00:00:00Z").getTime(),
    closed:
      n.status === "Completed"
        ? new Date(n.updated + "T00:00:00Z").getTime()
        : null,
  }));

  const now = new Date();
  const endThis = Date.UTC(now.getUTCFullYear(), now.getUTCMonth() + 1, 1);
  const endPrev = Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), 1);

  const current = backlogAt(items, endThis);
  const previous = backlogAt(items, endPrev);
  const delta = current - previous;

  const sign = delta > 0 ? "+" : delta < 0 ? "−" : "±";
  const pillLabel = `${sign}${Math.abs(delta)} MoM`;
  const tone: "warning" | "success" | "neutral" =
    delta > 0 ? "warning" : delta < 0 ? "success" : "neutral";

  return (
    <KpiCard
      label="Monthly backlog"
      value={current}
      subtitle="End of month"
      pill={{ label: pillLabel, tone }}
    />
  );
}
