import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetDescription,
} from "@/components/ui/sheet";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ChevronLeft } from "lucide-react";
import { cn } from "@/lib/utils";
import type { NuddRow } from "@/mocks/nudds";

type Props = {
  row: NuddRow | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
};

function Field({ label, value }: { label: string; value: React.ReactNode }) {
  const isEmpty = value === undefined || value === null || value === "" || value === "—";
  return (
    <div className="grid grid-cols-[180px_1fr] gap-4 py-2">
      <dt className="text-body-2 text-muted-foreground">{label}</dt>
      <dd className="text-body-2 text-foreground min-w-0 break-words">
        {isEmpty ? <span className="text-muted-foreground">—</span> : value}
      </dd>
    </div>
  );
}

function RailField({ label, value }: { label: string; value: React.ReactNode }) {
  const isEmpty = value === undefined || value === null || value === "" || value === "—";
  return (
    <div className="grid grid-cols-[110px_1fr] gap-3 py-1">
      <dt className="text-body-2 text-muted-foreground">{label}</dt>
      <dd className="text-body-2 text-foreground min-w-0 break-words">
        {isEmpty ? <span className="text-muted-foreground">—</span> : value}
      </dd>
    </div>
  );
}

function RailSection({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <section className="border-b border-border py-4 last:border-0">
      <h6 className="text-subtitle-2 text-foreground mb-2">{title}</h6>
      <dl>{children}</dl>
    </section>
  );
}

function riskBand(n: number): "Low" | "Medium" | "High" {
  if (n <= 2) return "Low";
  if (n <= 5) return "Medium";
  return "High";
}

function bandLetter(b: "Low" | "Medium" | "High"): "L" | "M" | "H" {
  return b === "Low" ? "L" : b === "Medium" ? "M" : "H";
}

function scoreLabel(n: number) {
  return n === 1 ? "Low" : n === 2 ? "Medium" : "High";
}

function probabilityLabel(n: number) {
  return n === 1 ? "Unlikely" : n === 2 ? "Possible" : "Likely";
}

export function NuddDetailDrawer({ row, open, onOpenChange }: Props) {
  if (!row) return null;
  const risk = row.impact * row.probability;
  const band = riskBand(risk);

  const jiraUrl = `https://jira.dell.com/browse/${row.id}`;

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>

      <SheetContent
        side="right"
        className={cn(
          "w-full sm:max-w-[920px] sm:w-[920px] p-0 bg-surface flex flex-col [&>button.absolute]:hidden",
        )}
      >
        <SheetHeader className="px-6 pt-4 pb-4 border-b border-border space-y-2 shrink-0">
          <button
            type="button"
            onClick={() => onOpenChange(false)}
            className="inline-flex items-center gap-1 text-button-2 text-link hover:opacity-80 self-start"
          >
            <ChevronLeft className="h-4 w-4" />
            Back
          </button>
          <div className="flex items-center gap-2 text-caption text-muted-foreground tabular-nums">
            <span>NUDDs</span>
            <span aria-hidden>/</span>
            <span className="text-foreground font-medium">{row.id}</span>
          </div>
          <SheetTitle className="text-h3 text-foreground">{row.title}</SheetTitle>
          <SheetDescription className="sr-only">
            Detailed information about {row.id}
          </SheetDescription>
          <div className="flex flex-wrap items-center gap-2 pt-1">
            <Badge
              className="rounded-full font-medium border-transparent hover:opacity-90"
              style={
                row.status === "Open"
                  ? { backgroundColor: "#40586D", color: "#EBF1F6" }
                  : row.status === "On hold"
                  ? { backgroundColor: "#839DB4", color: "#EBF1F6" }
                  : row.status === "Completed"
                  ? { backgroundColor: "#EBF1F6", color: "#0A0E14" }
                  : undefined
              }
            >
              {row.status}
            </Badge>
            <Badge
              className="rounded-full font-medium tabular-nums border-transparent hover:opacity-90"
              style={
                band === "High"
                  ? { backgroundColor: "#40155C", color: "#FBEBFF" }
                  : band === "Medium"
                  ? { backgroundColor: "#994CCC", color: "#FBEBFF" }
                  : { backgroundColor: "#ECC4FF", color: "#40155C" }
              }
            >
              {bandLetter(band)}
            </Badge>
            <Badge
              className="rounded-full font-medium border-transparent hover:opacity-90"
              style={{
                backgroundImage:
                  "linear-gradient(90deg, #0063B8 0%, #7F234F 50%, #40155C 100%)",
                color: "#FFFFFF",
              }}
            >
              Jira (via Doc Curator)
            </Badge>
          </div>
          <dl className="pt-3 flex flex-wrap gap-x-6 gap-y-1 text-body-3">
            <div className="flex items-center gap-2">
              <dt className="text-muted-foreground">Type</dt>
              <dd className="text-foreground">NUDD</dd>
            </div>
            <div className="flex items-center gap-2">
              <dt className="text-muted-foreground">Resolution</dt>
              <dd className="text-foreground">{row.resolution || "Unresolved"}</dd>
            </div>
            <div className="flex items-center gap-2">
              <dt className="text-muted-foreground">Labels</dt>
              <dd className="text-foreground">{row.lob || "None"}</dd>
            </div>
            <div className="flex items-center gap-2">
              <dt className="text-muted-foreground">Close date</dt>
              <dd className="text-foreground">{row.closeDate}</dd>
            </div>
          </dl>
        </SheetHeader>

        <div className="flex-1 overflow-y-auto">
          <div className="grid grid-cols-1 l:grid-cols-[1fr_260px] gap-6 px-6 py-4">
            {/* Main column */}
            <div className="min-w-0">
              <Tabs defaultValue="info">
                <TabsList className="h-auto rounded-none bg-transparent p-0 border-b border-border w-fit justify-start gap-0">
                  <TabsTrigger
                    value="info"
                    className="relative rounded-none border-0 bg-transparent px-6 py-3 text-button-2 text-muted-foreground data-[state=active]:bg-surface data-[state=active]:text-link data-[state=active]:shadow-none data-[state=active]:before:absolute data-[state=active]:before:inset-x-0 data-[state=active]:before:top-0 data-[state=active]:before:h-[2px] data-[state=active]:before:bg-link"
                  >
                    NUDDs info
                  </TabsTrigger>
                  <TabsTrigger
                    value="scoring"
                    className="relative rounded-none border-0 bg-transparent px-6 py-3 text-button-2 text-muted-foreground data-[state=active]:bg-surface data-[state=active]:text-link data-[state=active]:shadow-none data-[state=active]:before:absolute data-[state=active]:before:inset-x-0 data-[state=active]:before:top-0 data-[state=active]:before:h-[2px] data-[state=active]:before:bg-link"
                  >
                    NUDDS scoring
                  </TabsTrigger>
                </TabsList>
                <TabsContent value="info" className="pt-2">
                  <dl>
                    <Field label="Affected Platform(s)" value={row.platform} />
                    <Field label="Affected LOB(s)" value={row.lob} />
                    <Field label="Detailed Description" value="—" />
                    <Field label="GOE OLP Phase" value={row.programPhase} />
                    <Field label="Risk Events" value="—" />
                    <Field label="Risk Drivers" value="—" />
                    <Field label="Mitigation Plan" value="—" />
                    <Field label="NUDD/LL Type" value="—" />
                  </dl>
                </TabsContent>
                <TabsContent value="scoring" className="pt-2">
                  <dl>
                    <Field label="Decorative Finishes" value="N/A" />
                    <Field label="Mfg Diagnostics" value="N/A" />
                    <Field label="Supply Chain & Process Capability" value="—" />
                    <Field label="DFx" value="—" />
                    <Field label="Packaging" value="N/A" />
                    <Field label="Order Processing" value="N/A" />
                    <Field
                      label="Risk Impact Level"
                      value={`${row.impact} · ${scoreLabel(row.impact)}`}
                    />
                    <Field
                      label="Risk Probability"
                      value={`${row.probability} · ${probabilityLabel(row.probability)}`}
                    />
                    <Field label="Risk Priority" value={String(risk)} />
                    <Field label="Overall Risk Level" value={bandLetter(band)} />
                    <Field label="Mitigation Status" value="—" />
                    <Field label="Overall NUDD Status" value="—" />
                  </dl>
                </TabsContent>
              </Tabs>
            </div>

            {/* Right rail */}
            <aside className="min-w-0">
              <RailSection title="People">
                <RailField label="Assignee" value={row.people.assignee} />
                <RailField label="Reporter" value={row.people.reporter} />
                <RailField label="Votes" value="0" />
                <RailField label="Watchers" value="1" />
              </RailSection>
              <RailSection title="Dates">
                <RailField label="Created" value={row.dates.created} />
                <RailField label="Updated" value={row.dates.updated} />
              </RailSection>
              <RailSection title="Packages">
                <div className="grid grid-cols-2 gap-3 text-body-2 text-muted-foreground border-b border-border pb-1">
                  <span>Version</span>
                  <span>Package</span>
                </div>
                <p className="text-body-2 text-muted-foreground pt-2">—</p>
              </RailSection>
            </aside>
          </div>
        </div>

        <div className="shrink-0 border-t border-border px-6 py-4 flex justify-start gap-3 bg-surface">
          <Button
            onClick={() =>
              window.open(jiraUrl, "_blank", "noopener,noreferrer")
            }
          >
            View in Jira
          </Button>
          <Button
            variant="outline"
            onClick={() => onOpenChange(false)}
            className="bg-transparent border-[#0672CB] text-[#0672CB] hover:bg-transparent hover:text-[#0672CB]"
          >
            Close
          </Button>
        </div>
      </SheetContent>
    </Sheet>
  );
}
