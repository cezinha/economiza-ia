import { useState } from "react";
import { KpiCard } from "@/components/dashboard/KpiCard";
import { useFilteredNudds } from "@/lib/applyFilters";
import { NuddListDrawer } from "@/components/dashboard/drawers/NuddListDrawer";
import type { NuddRow } from "@/mocks/nudds";

type Props = { onOpenRow?: (row: NuddRow) => void };

function riskScore(n: NuddRow) {
  return n.impact * n.probability;
}

export function NuddHighRiskMetric({ onOpenRow }: Props = {}) {
  const NUDDS = useFilteredNudds();
  const [open, setOpen] = useState(false);

  const active = NUDDS.filter((n) => n.status === "Open" || n.status === "On hold");
  const highRows = active.filter((n) => riskScore(n) > 5);
  const count = highRows.length;
  const pct = active.length === 0 ? 0 : Math.round((count / active.length) * 100);
  const disabled = count === 0;

  return (
    <>
      <KpiCard
        label="High risk NUDDs (active)"
        value={count}
        subtitle={`Total count (${pct}% of active)`}
        pill={count > 0 ? { label: "Status", tone: "risk-high" } : undefined}
        onClick={disabled ? undefined : () => setOpen(true)}
      />
      <NuddListDrawer
        open={open}
        onOpenChange={setOpen}
        eyebrow="High risk NUDDs"
        title={`${count} high risk NUDD${count === 1 ? "" : "s"}`}
        description="Active NUDDs with an impact × probability score greater than 5."
        rows={highRows}
        emptyMessage="No high risk NUDDs."
        onSelectRow={onOpenRow}
      />
    </>
  );
}
