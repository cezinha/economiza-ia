import { useRef, useState } from "react";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { useFilteredNudds } from "@/lib/applyFilters";
import { NuddListDrawer } from "@/components/dashboard/drawers/NuddListDrawer";
import {
  Bar,
  CartesianGrid,
  ComposedChart,
  LabelList,
  Line,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";

const MONTHS_BACK = 6;

type MonthBucket = {
  key: string;
  label: string;
  start: number;
  end: number;
  Opened: number;
  ClosedNeg: number;
  closedCount: number;
  Backlog: number;
  openedIds: string[];
  closedIds: string[];
};

type SelKind = "opened" | "closed" | "backlog";
type Series = "Opened" | "Closed" | "Backlog";

const SERIES: { key: Series; label: string; color: string; kind: "bar" | "line" }[] = [
  { key: "Opened", label: "Open / on hold NUDDs", color: "#0EA0A9", kind: "bar" },
  { key: "Closed", label: "Closed NUDDs", color: "#7F234F", kind: "bar" },
  { key: "Backlog", label: "Open backlog (end of month)", color: "#0672CB", kind: "line" },
];

type Props = { onOpenRow?: (row: import("@/mocks/nudds").NuddRow) => void };

export function NuddMonthlyOverview({ onOpenRow }: Props = {}) {
  const NUDDS = useFilteredNudds();
  const exportRef = useRef<HTMLDivElement>(null);
  const [sel, setSel] = useState<{ kind: SelKind; key: string } | null>(null);
  const [isolated, setIsolated] = useState<Series | null>(null);
  const [hovered, setHovered] = useState<Series | null>(null);
  const seriesOpacity = (s: Series) => {
    if (isolated) return s === isolated ? 1 : 0;
    if (hovered) return s === hovered ? 1 : 0.25;
    return 1;
  };
  const seriesHidden = (s: Series) => isolated !== null && isolated !== s;

  const now = new Date();
  const items = NUDDS.map((n) => ({
    id: n.id,
    created: new Date(n.created + "T00:00:00Z").getTime(),
    closed:
      n.status === "Completed" ? new Date(n.updated + "T00:00:00Z").getTime() : null,
  }));

  const months: MonthBucket[] = [];
  for (let i = MONTHS_BACK - 1; i >= 0; i--) {
    const start = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth() - i, 1));
    const end = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth() - i + 1, 1));
    const openedIds: string[] = [];
    const closedIds: string[] = [];
    let backlog = 0;
    for (const it of items) {
      if (it.created >= start.getTime() && it.created < end.getTime()) {
        openedIds.push(it.id);
      }
      if (it.closed !== null && it.closed >= start.getTime() && it.closed < end.getTime()) {
        closedIds.push(it.id);
      }
      const closedByEnd = it.closed !== null && it.closed < end.getTime();
      if (it.created < end.getTime() && !closedByEnd) backlog++;
    }
    months.push({
      key: `${start.getUTCFullYear()}-${String(start.getUTCMonth() + 1).padStart(2, "0")}`,
      label: `${start.toLocaleString("en-US", { month: "short", timeZone: "UTC" })} '${String(start.getUTCFullYear()).slice(-2)}`,
      start: start.getTime(),
      end: end.getTime(),
      Opened: openedIds.length,
      closedCount: closedIds.length,
      ClosedNeg: -closedIds.length,
      Backlog: backlog,
      openedIds,
      closedIds,
    });
  }

  const currentMonth = months[months.length - 1];
  const monthLabelLong = new Date(currentMonth.start).toLocaleString("en-US", {
    month: "long",
    year: "numeric",
    timeZone: "UTC",
  });

  // Share a single integer scale between the bars (flow) and the backlog line
  // so ticks line up cleanly on both axes and no float artifacts appear.
  const niceUp = (n: number) => Math.max(2, Math.ceil(n / 2) * 2);
  const openedMax = Math.max(...months.map((m) => m.Opened), 0);
  const closedMax = niceUp(Math.max(...months.map((m) => m.closedCount), 0));
  const backlogMax = Math.max(...months.map((m) => m.Backlog), 0);
  const topMax = niceUp(Math.max(openedMax, backlogMax));
  const flowDomain: [number, number] = [-closedMax, topMax];
  const backlogDomain: [number, number] = [-closedMax, topMax];
  const leftTicks: number[] = [];
  for (let v = -closedMax; v <= topMax; v += 2) leftTicks.push(v);
  const rightTicks = leftTicks.filter((v) => v >= 0);


  return (
    <Card className="flex h-full flex-col border-border bg-surface shadow-elev-1">
      <CardHeader className="flex flex-row items-center justify-between gap-4 space-y-0">
        <div className="space-y-1">
          <h5 className="text-h6 text-foreground">Monthly backlog</h5>
          <p className="text-caption text-muted-foreground">
            Open / on hold vs closed NUDDs over last six months
          </p>
          <p className="text-caption text-muted-foreground">
            <span className="text-foreground">{currentMonth.Opened} opened</span> ·{" "}
            <span className="text-foreground">{currentMonth.closedCount} closed</span> ·{" "}
            <span className="text-foreground">{currentMonth.Backlog} backlog</span> in {monthLabelLong}
          </p>
        </div>
      </CardHeader>
      <CardContent>
        <div ref={exportRef} className="bg-surface">
          <div className="h-[340px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <ComposedChart
                data={months}
                margin={{ top: 28, right: 16, bottom: 24, left: 8 }}
                stackOffset="sign"
              >
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
                <XAxis
                  dataKey="label"
                  stroke="hsl(var(--muted-foreground))"
                  tick={{ fontSize: 12 }}
                  tickLine={false}
                  axisLine={{ stroke: "hsl(var(--border))" }}
                  label={{ value: "Month", position: "insideBottom", offset: -12, style: { fill: "hsl(var(--muted-foreground))", fontSize: 12 } }}
                />
                <YAxis
                  yAxisId="flow"
                  allowDecimals={false}
                  domain={flowDomain}
                  ticks={leftTicks}
                  stroke="hsl(var(--muted-foreground))"
                  tick={{ fontSize: 12 }}
                  tickLine={false}
                  axisLine={{ stroke: "hsl(var(--border))" }}
                  tickFormatter={(v: number) => String(Math.abs(v))}
                  label={{ value: "Total count", angle: -90, position: "insideLeft", offset: 16, style: { fill: "hsl(var(--muted-foreground))", fontSize: 12, textAnchor: "middle" } }}
                />
                <YAxis
                  yAxisId="backlog"
                  orientation="right"
                  allowDecimals={false}
                  domain={backlogDomain}
                  ticks={rightTicks}
                  stroke="hsl(var(--muted-foreground))"
                  tick={{ fontSize: 12 }}
                  tickLine={false}
                  axisLine={{ stroke: "hsl(var(--border))" }}
                  tickFormatter={(v: number) => String(v)}
                />

                <Tooltip
                  cursor={{ fill: "hsl(var(--muted))" }}
                  content={({ active, payload, label }) => {
                    if (!active || !payload?.length) return null;
                    const row = payload[0].payload as MonthBucket;
                    return (
                      <div className="rounded-sm border border-border bg-surface px-3 py-2 shadow-elev-2">
                        <div className="text-body-3 font-medium text-foreground">{label}</div>
                        <div className="mt-1 text-caption text-foreground tabular-nums">
                          Opened: {row.Opened}
                        </div>
                        <div className="text-caption text-foreground tabular-nums">
                          Closed: {row.closedCount}
                        </div>
                        <div className="text-caption text-foreground tabular-nums">
                          End-of-month backlog: {row.Backlog}
                        </div>
                      </div>
                    );
                  }}
                />
                <Bar
                  yAxisId="flow"
                  name="Open / on hold NUDDs"
                  dataKey="Opened"
                  stackId="flow"
                  fill="#0EA0A9"
                  fillOpacity={seriesOpacity("Opened")}
                  hide={seriesHidden("Opened")}
                  radius={0}
                  maxBarSize={28}
                  isAnimationActive={false}
                  className="cursor-pointer"
                  onClick={(d: { key?: string } | undefined) => {
                    if (d?.key) setSel({ kind: "opened", key: d.key });
                  }}
                >
                  <LabelList
                    dataKey="Opened"
                    position="center"
                    formatter={(v: number) => (v > 0 ? String(v) : "")}
                    fill="#FFFFFF"
                    fontSize={12}
                  />
                </Bar>
                <Bar
                  yAxisId="flow"
                  name="Closed NUDDs"
                  dataKey="ClosedNeg"
                  stackId="flow"
                  fill="#7F234F"
                  fillOpacity={seriesOpacity("Closed")}
                  hide={seriesHidden("Closed")}
                  radius={0}
                  maxBarSize={28}
                  isAnimationActive={false}
                  className="cursor-pointer"
                  onClick={(d: { key?: string } | undefined) => {
                    if (d?.key) setSel({ kind: "closed", key: d.key });
                  }}
                >
                  <LabelList
                    dataKey="closedCount"
                    position="center"
                    formatter={(v: number) => (v > 0 ? String(v) : "")}
                    fill="#FFFFFF"
                    fontSize={12}
                  />
                </Bar>
                <Line
                  yAxisId="backlog"
                  name="Open backlog (end of month)"
                  type="monotone"
                  dataKey="Backlog"
                  stroke="#0672CB"
                  strokeWidth={2}
                  strokeOpacity={seriesOpacity("Backlog")}
                  hide={seriesHidden("Backlog")}
                  isAnimationActive={false}
                  dot={{ r: 3.5, fill: "hsl(var(--surface))", stroke: "#0672CB", strokeWidth: 2, strokeOpacity: seriesOpacity("Backlog") }}
                  activeDot={{
                    r: 5,
                    className: "cursor-pointer",
                    onClick: (props: unknown) => {
                      const d = (props as { payload?: MonthBucket } | undefined)?.payload;
                      if (d) setSel({ kind: "backlog", key: d.key });
                    },
                  } as never}
                >
                  <LabelList
                    dataKey="Backlog"
                    position="top"
                    offset={10}
                    fill="#0E0E0E"
                    fontSize={12}
                  />
                </Line>
              </ComposedChart>
            </ResponsiveContainer>
          </div>
          <div
            className="flex items-center justify-center gap-6 pt-3"
            role="group"
            aria-label="Series legend"
          >
            {SERIES.map((s) => {
              const activeMarker = !isolated || isolated === s.key;
              return (
                <button
                  key={s.key}
                  type="button"
                  onClick={() => setIsolated((cur) => (cur === s.key ? null : s.key))}
                  onMouseEnter={() => !isolated && setHovered(s.key)}
                  onMouseLeave={() => setHovered(null)}
                  onFocus={() => !isolated && setHovered(s.key)}
                  onBlur={() => setHovered(null)}
                  aria-pressed={isolated === s.key}
                  className="flex items-center gap-2 text-caption text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring rounded-sm px-1"
                >
                  <span
                    className="inline-block w-3 h-3 rounded-sm border"
                    style={{
                      background: activeMarker ? s.color : "transparent",
                      borderColor: s.color,
                    }}
                    aria-hidden
                  />
                  <span className={activeMarker ? "" : "text-muted-foreground"}>
                    {s.label}
                  </span>
                </button>
              );
            })}
          </div>
        </div>
      </CardContent>
      {(() => {
        const selRow = sel ? months.find((m) => m.key === sel.key) ?? null : null;
        let ids: string[] = [];
        if (selRow && sel) {
          if (sel.kind === "opened") ids = selRow.openedIds;
          else if (sel.kind === "closed") ids = selRow.closedIds;
          else {
            const eom = selRow.end;
            ids = items
              .filter((it) => it.created < eom && !(it.closed !== null && it.closed < eom))
              .map((it) => it.id);
          }
        }
        const idSet = new Set(ids);
        const rows = NUDDS.filter((n) => idSet.has(n.id));
        const monthLabel = selRow
          ? new Date(selRow.start).toLocaleString("en-US", {
              month: "long",
              year: "numeric",
              timeZone: "UTC",
            })
          : "";
        const eyebrow = sel
          ? sel.kind === "opened"
            ? `Opened · ${monthLabel}`
            : sel.kind === "closed"
            ? `Closed · ${monthLabel}`
            : `Backlog at end of ${monthLabel}`
          : "";
        const title = sel ? `${rows.length} NUDD${rows.length === 1 ? "" : "s"}` : "";
        const description =
          sel?.kind === "opened"
            ? "NUDDs raised during this month."
            : sel?.kind === "closed"
            ? "NUDDs closed during this month."
            : "Unresolved NUDDs at the end of this month.";
        return (
          <NuddListDrawer
            open={sel !== null}
            onOpenChange={(o) => { if (!o) setSel(null); }}
            eyebrow={eyebrow}
            title={title}
            description={description}
            rows={rows}
            emptyMessage="No NUDDs for this selection."
            onSelectRow={onOpenRow}
          />
        );
      })()}
    </Card>
  );
}
