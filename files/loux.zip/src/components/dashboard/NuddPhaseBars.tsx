import { useState } from "react";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { useFilteredNudds } from "@/lib/applyFilters";
import {
  Bar,
  BarChart,
  CartesianGrid,
  LabelList,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { NuddListDrawer } from "@/components/dashboard/drawers/NuddListDrawer";
import type { NuddRow } from "@/mocks/nudds";

type Band = "High" | "Medium" | "Low";
const BANDS: Band[] = ["High", "Medium", "Low"];

function riskBand(n: number): Band {
  if (n <= 2) return "Low";
  if (n <= 5) return "Medium";
  return "High";
}

const BAND_TOKEN: Record<Band, { fill: string; labelFill: string }> = {
  High: { fill: "#40155C", labelFill: "#FBEBFF" },
  Medium: { fill: "#994CCC", labelFill: "#FBEBFF" },
  Low: { fill: "#ECC4FF", labelFill: "#40155C" },
};

type Props = { onOpenRow?: (row: NuddRow) => void };

export function NuddPhaseBars({ onOpenRow }: Props = {}) {
  const NUDDS = useFilteredNudds();
  const [sel, setSel] = useState<Band | null>(null);
  const [isolated, setIsolated] = useState<Band | null>(null);
  const [hovered, setHovered] = useState<Band | null>(null);

  const active = NUDDS.filter((n) => n.status === "Open" || n.status === "On hold");
  const byBand: Record<Band, NuddRow[]> = { High: [], Medium: [], Low: [] };
  for (const n of active) byBand[riskBand(n.impact * n.probability)].push(n);

  const total = active.length;
  const data = [
    {
      label: "Active",
      High: byBand.High.length,
      Medium: byBand.Medium.length,
      Low: byBand.Low.length,
    },
  ];

  // Round x-axis domain up so the full bar is visible
  const xMax = Math.max(5, Math.ceil(total / 5) * 5);

  const selRows = sel ? byBand[sel] : [];

  const segmentOpacity = (band: Band) => {
    if (isolated) return band === isolated ? 1 : 0;
    if (hovered) return band === hovered ? 1 : 0.25;
    return 1;
  };

  return (
    <Card className="flex h-full flex-col border-border bg-surface shadow-elev-1">
      {/* Header — 24px above + 32px between title and plot (CardHeader default + pb-8) */}
      <CardHeader className="space-y-1 pt-6 pb-8">
        <h5 className="text-h6 text-foreground">Active NUDDs by overall risk level</h5>
        <p className="text-caption text-muted-foreground">
          Total count of open / on hold NUDDs, as of today
        </p>
      </CardHeader>
      <CardContent className="flex-1 min-h-0 flex flex-col gap-6 pb-6">
        {/* Plot area + Y-axis label */}
        <div className="flex-1 min-h-[120px] w-full flex">
          <div className="flex items-center justify-center pr-2" aria-hidden>
            <span
              className="text-caption text-muted-foreground"
              style={{ writingMode: "vertical-rl", transform: "rotate(180deg)" }}
            >
              Active NUDDs
            </span>
          </div>
          <div className="flex-1 min-w-0">
            {total === 0 ? (
              <div className="flex h-full items-center justify-center text-caption text-muted-foreground">
                No active NUDDs
              </div>
            ) : (
              <ResponsiveContainer width="100%" height="100%">
                <BarChart
                  data={data}
                  layout="vertical"
                  margin={{ top: 16, right: 32, bottom: 8, left: 24 }}
                  barCategoryGap="50%"
                >
                  <CartesianGrid
                    stroke="hsl(var(--border))"
                    horizontal={false}
                    strokeDasharray="0"
                  />
                  <XAxis
                    type="number"
                    domain={[0, xMax]}
                    allowDecimals={false}
                    tickLine={false}
                    axisLine={{ stroke: "hsl(var(--border))" }}
                    tick={{ fill: "hsl(var(--muted-foreground))", fontSize: 12 }}
                    tickMargin={8}
                  />
                  <YAxis
                    type="category"
                    dataKey="label"
                    tick={false}
                    tickLine={false}
                    axisLine={false}
                    width={8}
                  />
                  <Tooltip
                    shared={false}
                    cursor={{ fill: "hsl(var(--muted))" }}
                    content={({ active: a, payload, label }) => {
                      if (!a || !payload?.length) return null;
                      return (
                        <div className="rounded-sm border border-border bg-surface px-3 py-2 shadow-elev-2 space-y-1">
                          {payload.map((p) => {
                            const name = p.name as Band;
                            const v = Number(p.value ?? 0);
                            const pct = total > 0 ? Math.round((v / total) * 100) : 0;
                            return (
                              <div
                                key={name}
                                className="text-caption text-foreground tabular-nums flex items-center gap-2"
                              >
                                <span
                                  className="inline-block w-2 h-2 rounded-sm"
                                  style={{ background: BAND_TOKEN[name].fill }}
                                />
                                <span>{name}</span>
                                <span className="text-muted-foreground">·</span>
                                <span>{label}</span>
                                <span className="ml-2">
                                  {v} ({pct}%)
                                </span>
                              </div>
                            );
                          })}
                        </div>
                      );
                    }}
                  />
                  {BANDS.map((band) => {
                    const lastVisibleBand = isolated ?? "Low";
                    return (
                    <Bar
                      key={band}
                      dataKey={band}
                      stackId="risk"
                      fill={BAND_TOKEN[band].fill}
                      fillOpacity={segmentOpacity(band)}
                      hide={isolated !== null && isolated !== band}
                      barSize={48}
                      isAnimationActive={false}
                      className="cursor-pointer"
                      onClick={() => setSel(band)}
                    >
                      <LabelList
                        dataKey={band}
                        position="center"
                        fill={BAND_TOKEN[band].labelFill}
                        fontSize={12}
                        className="tabular-nums"
                        formatter={(v: number) => (v > 0 ? v : "")}
                      />
                      {band === lastVisibleBand && (
                        <LabelList
                          dataKey={band}
                          position="right"
                          fill="hsl(var(--foreground))"
                          fontSize={12}
                          offset={8}
                          className="tabular-nums font-medium"
                          formatter={() =>
                            isolated ? byBand[isolated].length : total
                          }
                        />
                      )}
                    </Bar>
                    );
                  })}
                </BarChart>
              </ResponsiveContainer>
            )}
          </div>
        </div>
        {/* X-axis label */}
        <div className="text-center text-caption text-muted-foreground -mt-4">
          Total count
        </div>
        {/* Interactive legend */}
        <div
          className="flex items-center justify-center gap-6"
          role="group"
          aria-label="Risk level legend"
        >
          {BANDS.map((band) => {
            const activeMarker = !isolated || isolated === band;
            return (
              <button
                key={band}
                type="button"
                onClick={() => setIsolated((cur) => (cur === band ? null : band))}
                onMouseEnter={() => !isolated && setHovered(band)}
                onMouseLeave={() => setHovered(null)}
                onFocus={() => !isolated && setHovered(band)}
                onBlur={() => setHovered(null)}
                aria-pressed={isolated === band}
                className="flex items-center gap-2 text-caption text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring rounded-sm px-1"
              >
                <span
                  className="inline-block w-3 h-3 rounded-sm border"
                  style={{
                    background: activeMarker ? BAND_TOKEN[band].fill : "transparent",
                    borderColor: BAND_TOKEN[band].fill,
                  }}
                  aria-hidden
                />
                <span className={activeMarker ? "" : "text-muted-foreground"}>
                  {band}
                </span>
              </button>
            );
          })}
        </div>
      </CardContent>
      <NuddListDrawer
        open={sel !== null}
        onOpenChange={(o) => {
          if (!o) setSel(null);
        }}
        eyebrow={sel ? `Risk level · ${sel}` : ""}
        title={sel ? `${selRows.length} active NUDD${selRows.length === 1 ? "" : "s"}` : ""}
        description="Open + On hold NUDDs at this overall risk level."
        rows={selRows}
        emptyMessage="No active NUDDs at this risk level."
        onSelectRow={onOpenRow}
      />
    </Card>
  );
}
