import { DdsGrid, DdsCol } from "@/components/layout/DdsGrid";
import { type NuddRow } from "@/mocks/nudds";
import { NuddPhaseBars } from "@/components/dashboard/NuddPhaseBars";
import { NuddMonthlyOverview } from "@/components/dashboard/NuddMonthlyOverview";
import { NuddUpcomingMetric } from "@/components/dashboard/NuddUpcomingMetric";
import { NuddActiveMetric } from "@/components/dashboard/NuddActiveMetric";
import { NuddHighRiskMetric } from "@/components/dashboard/NuddHighRiskMetric";


type Props = {
  onOpenRow: (row: NuddRow) => void;
};

export function NuddSummary({ onOpenRow }: Props) {
  return (
    <div className="space-y-6">
      <DdsGrid className="[grid-auto-rows:1fr]">
        <DdsCol span={4} spanM={6} spanS={6}>
          <NuddUpcomingMetric onOpenRow={onOpenRow} />
        </DdsCol>
        <DdsCol span={4} spanM={6} spanS={6}>
          <NuddActiveMetric onOpenRow={onOpenRow} />
        </DdsCol>
        <DdsCol span={4} spanM={6} spanS={6}>
          <NuddHighRiskMetric onOpenRow={onOpenRow} />
        </DdsCol>
      </DdsGrid>

      <DdsGrid>
        <DdsCol span={4} spanM={6}>
          <NuddPhaseBars onOpenRow={onOpenRow} />
        </DdsCol>
        <DdsCol span={8} spanM={6}>
          <NuddMonthlyOverview onOpenRow={onOpenRow} />
        </DdsCol>
      </DdsGrid>
    </div>
  );
}
