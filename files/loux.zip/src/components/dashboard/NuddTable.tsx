import { Card, CardContent } from "@/components/ui/card";
import { type NuddRow } from "@/mocks/nudds";
import { useFilteredNudds } from "@/lib/applyFilters";
import { NuddTableView } from "./NuddTableView";

type Props = {
  onOpenRow: (row: NuddRow) => void;
};

export function NuddTable({ onOpenRow }: Props) {
  const NUDDS = useFilteredNudds();
  return (
    <Card className="border-border bg-surface shadow-elev-1 overflow-hidden">
      <CardContent className="p-0">
        <NuddTableView rows={NUDDS} onOpenRow={onOpenRow} />
      </CardContent>
    </Card>
  );
}
