import { useEffect, useMemo, useState } from "react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { type NuddRow, type Score } from "@/mocks/nudds";
import { DdsPagination } from "@/components/shell/DdsPagination";

const stickyId =
  "sticky left-0 z-10 bg-inherit shadow-elev-right-1 before:absolute before:right-0 before:top-0 before:bottom-0 before:w-px before:bg-border before:content-['']";
const stickyIdHeader =
  "sticky left-0 z-30 bg-card shadow-elev-right-1 before:absolute before:right-0 before:top-0 before:bottom-0 before:w-px before:bg-border before:content-['']";

function scoreLabel(n: Score) {
  return n === 1 ? "Low" : n === 2 ? "Medium" : "High";
}

function probabilityLabel(n: Score) {
  return n === 1 ? "Unlikely" : n === 2 ? "Possible" : "Likely";
}

function bandLetter(b: "Low" | "Medium" | "High"): "L" | "M" | "H" {
  return b === "Low" ? "L" : b === "Medium" ? "M" : "H";
}

function riskBand(n: number): "Low" | "Medium" | "High" {
  if (n <= 2) return "Low";
  if (n <= 5) return "Medium";
  return "High";
}

type Props = {
  rows: NuddRow[];
  onOpenRow: (row: NuddRow) => void;
  maxHeightClass?: string;
};

export function NuddTableView({ rows, onOpenRow, maxHeightClass = "max-h-[640px]" }: Props) {
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(25);
  useEffect(() => setPage(1), [rows.length]);
  const totalPages = Math.max(1, Math.ceil(rows.length / pageSize));
  const safePage = Math.min(page, totalPages);
  const pagedRows = useMemo(
    () => rows.slice((safePage - 1) * pageSize, safePage * pageSize),
    [rows, safePage, pageSize],
  );
  return (
    <>
      <Table containerClassName={maxHeightClass}>
        <TableHeader className="sticky top-0 z-20 bg-card shadow-elev-1">
          <TableRow>
            <TableHead className={cn(stickyIdHeader, "min-w-[140px] text-h6 whitespace-nowrap")}>ID</TableHead>
            <TableHead className="text-h6 whitespace-nowrap min-w-[100px]">Status</TableHead>
            <TableHead className="text-h6 whitespace-nowrap min-w-[120px]">Impacted LOB</TableHead>
            <TableHead className="text-h6 whitespace-nowrap min-w-[160px]">Impacted platform</TableHead>
            <TableHead className="text-h6 whitespace-nowrap min-w-[140px]">Risk impact level</TableHead>
            <TableHead className="text-h6 whitespace-nowrap min-w-[140px]">Risk probability</TableHead>
            <TableHead className="text-h6 whitespace-nowrap min-w-[120px]">Risk priority</TableHead>
            <TableHead className="text-h6 whitespace-nowrap min-w-[140px]">Overall risk level</TableHead>
            <TableHead className="text-h6 whitespace-nowrap min-w-[120px]">Date created</TableHead>
            <TableHead className="text-h6 whitespace-nowrap min-w-[120px]">Last updated</TableHead>
            <TableHead className="text-h6 whitespace-nowrap min-w-[120px]">Close date</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {pagedRows.map((row) => {
            const risk = row.impact * row.probability;
            const band = riskBand(risk);
            return (
              <TableRow key={row.id} className="bg-surface odd:bg-muted hover:bg-muted">
                <TableCell className={cn(stickyId, "align-top text-body-3")}>
                  <div className="flex flex-col">
                    <span className="font-medium tabular-nums text-foreground">{row.id}</span>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => onOpenRow(row)}
                      className="mt-1 h-7 w-fit border-link text-button-2 text-link bg-transparent hover:bg-link/10 hover:text-link"
                    >
                      View Details
                    </Button>
                  </div>
                </TableCell>
                <TableCell className="text-body-3">
                  <Badge
                    className="rounded-full font-medium border-transparent hover:opacity-90"
                    style={
                      row.status === "Open"
                        ? { backgroundColor: "#40586D", color: "#EBF1F6" }
                        : row.status === "On hold"
                        ? { backgroundColor: "#839DB4", color: "#EBF1F6" }
                        : row.status === "Completed"
                        ? { backgroundColor: "#EBF1F6", color: "#0A0E14" }
                        : undefined
                    }
                  >
                    {row.status}
                  </Badge>
                </TableCell>
                <TableCell className="text-body-3">{row.lob}</TableCell>
                <TableCell className="text-body-3">{row.platform}</TableCell>
                <TableCell className="text-body-3 tabular-nums">
                  {row.impact} · {scoreLabel(row.impact)}
                </TableCell>
                <TableCell className="text-body-3 tabular-nums">
                  {row.probability} · {probabilityLabel(row.probability)}
                </TableCell>
                <TableCell className="text-body-3 tabular-nums">{risk}</TableCell>
                <TableCell className="text-body-3">
                  <Badge
                    className="rounded-full font-medium tabular-nums border-transparent hover:opacity-90"
                    style={
                      band === "High"
                        ? { backgroundColor: "#40155C", color: "#FBEBFF" }
                        : band === "Medium"
                        ? { backgroundColor: "#994CCC", color: "#FBEBFF" }
                        : { backgroundColor: "#ECC4FF", color: "#40155C" }
                    }
                  >
                    {bandLetter(band)}
                  </Badge>
                </TableCell>
                <TableCell className="text-body-3 tabular-nums text-muted-foreground">{row.created}</TableCell>
                <TableCell className="text-body-3 tabular-nums text-muted-foreground">{row.updated}</TableCell>
                <TableCell className="text-body-3 tabular-nums text-muted-foreground">{row.closeDate}</TableCell>
              </TableRow>
            );
          })}
        </TableBody>
      </Table>

      {rows.length > 0 && (
        <div className="flex justify-center pt-2 pb-3">
          <DdsPagination
            page={safePage}
            pageSize={pageSize}
            totalItems={rows.length}
            itemLabel="rows"
            onPageChange={setPage}
            onPageSizeChange={setPageSize}
          />
        </div>
      )}
    </>
  );
}
