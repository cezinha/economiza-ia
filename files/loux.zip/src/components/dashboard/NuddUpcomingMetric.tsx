import { useState } from "react";
import { KpiCard } from "@/components/dashboard/KpiCard";
import { useFilteredNudds } from "@/lib/applyFilters";
import { NuddListDrawer } from "@/components/dashboard/drawers/NuddListDrawer";

const DAYS_AHEAD = 30;

type Props = { onOpenRow?: (row: import("@/mocks/nudds").NuddRow) => void };

export function NuddUpcomingMetric({ onOpenRow }: Props = {}) {
  const NUDDS = useFilteredNudds();
  const [open, setOpen] = useState(false);

  const now = new Date();
  const startMs = Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate());
  const endMs = startMs + DAYS_AHEAD * 24 * 60 * 60 * 1000;

  const parseClose = (s: string): number | null => {
    if (!s) return null;
    const m = s.match(/^(\d{1,2})\/([A-Za-z]{3})\/(\d{2,4})$/);
    if (!m) {
      const t = new Date(s).getTime();
      return Number.isFinite(t) ? t : null;
    }
    const months = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
    const mi = months.indexOf(m[2]);
    if (mi < 0) return null;
    const yy = m[3].length === 2 ? 2000 + Number(m[3]) : Number(m[3]);
    return Date.UTC(yy, mi, Number(m[1]));
  };

  const upcomingRows = NUDDS.filter((n) => {
    if (n.status === "Completed") return false;
    const t = parseClose(n.closeDate);
    if (t === null) return false;
    return t >= startMs && t < endMs;
  });
  const count = upcomingRows.length;
  const disabled = count === 0;

  return (
    <>
      <KpiCard
        label="Upcoming NUDDs"
        value={count}
        subtitle={`Due in next ${DAYS_AHEAD} days`}
        pill={count > 0 ? { label: "Action required", tone: "warning" } : undefined}
        onClick={disabled ? undefined : () => setOpen(true)}
      />

      <NuddListDrawer
        open={open}
        onOpenChange={setOpen}
        eyebrow="Upcoming NUDDs"
        title={`${count} NUDD${count === 1 ? "" : "s"} due in the next ${DAYS_AHEAD} days`}
        description="Open + On hold NUDDs with a close date in the next 30 days."
        rows={upcomingRows}
        emptyMessage="No NUDDs due in the next 30 days."
        onSelectRow={onOpenRow}
      />
    </>
  );
}
