import { useEffect, useState } from "react";
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { cn } from "@/lib/utils";
import type { Launch } from "@/mocks/launches";
import type { TaskFunction, LaunchTask } from "@/lib/launchTasks";
import { overdueTasksFor } from "@/lib/overdueTasks";
import { subscribeMinDuration } from "@/mocks/minDurationOverrides";
import { subscribeRunwayExceptions } from "@/mocks/runwayExceptions";
import { OverdueTasksDrawer } from "@/components/dashboard/drawers/OverdueTasksDrawer";

interface Props {
  launch: Launch;
  track: TaskFunction;
  onOpenTask: (task: LaunchTask) => void;
}

export function OverdueTrackBadge({ launch, track, onOpenTask }: Props) {
  const [, force] = useState(0);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const u1 = subscribeMinDuration(() => force((n) => n + 1));
    const u2 = subscribeRunwayExceptions(() => force((n) => n + 1));
    return () => { u1(); u2(); };
  }, []);

  const rows = overdueTasksFor(launch, track);
  if (rows.length === 0) return null;

  const count = rows.length;
  const label = `${count} task${count === 1 ? "" : "s"} overdue`;

  return (
    <>
      <Tooltip>
        <TooltipTrigger asChild>
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              setOpen(true);
            }}
            aria-label={`${count} overdue ${track} task${count === 1 ? "" : "s"} for ${launch.name}`}
            className={cn(
              "inline-flex items-center justify-center rounded-full border px-2 w-[108px] text-[0.75rem] leading-5 font-normal tabular-nums whitespace-nowrap",
              "border-primary/50 text-primary bg-transparent",
              "hover:bg-primary/5 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring",
            )}
          >
            {label}
          </button>
        </TooltipTrigger>
        <TooltipContent side="top">
          <span className="text-caption">Click to view overdue tasks</span>
        </TooltipContent>
      </Tooltip>
      <OverdueTasksDrawer
        open={open}
        onOpenChange={setOpen}
        launch={launch}
        track={track}
        rows={rows}
        onSelectTask={onOpenTask}
      />
    </>
  );
}
