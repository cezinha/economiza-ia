import { useEffect, useMemo, useState } from "react";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Sparkles } from "lucide-react";
import {
  getPendingPlatforms,
  subscribePendingPlatforms,
  type PendingPlatform,
} from "@/mocks/pendingPlatforms";
import { useRole } from "@/contexts/RoleContext";
import { useViewFilter } from "@/contexts/ViewFilterContext";
import { PlatformReviewDrawer } from "./PlatformReviewDrawer";
import { DdsPagination } from "@/components/shell/DdsPagination";

function relativeAge(ts: number): string {
  const min = Math.round((Date.now() - ts) / 60000);
  if (min < 60) return `${min}m ago`;
  const hr = Math.round(min / 60);
  if (hr < 24) return `${hr}h ago`;
  const d = Math.round(hr / 24);
  return `${d}d ago`;
}

/** Only rendered for GOE LOB admins (role === "admin" && function === "GOE"). */
export function PendingPlatformsCard() {
  const { role } = useRole();
  const { lockedFunction, lockedLobs } = useViewFilter();
  const [, force] = useState(0);
  const [target, setTarget] = useState<PendingPlatform | null>(null);
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);

  useEffect(() => subscribePendingPlatforms(() => force((n) => n + 1)), []);

  const allPending = getPendingPlatforms();
  const pending = useMemo(() => {
    if (role === "superadmin") return allPending;
    const scopedLobs = new Set(lockedLobs ?? []);
    return allPending.filter(
      (p) =>
        (!lockedFunction || p.function === lockedFunction) &&
        (scopedLobs.size === 0 || scopedLobs.has(p.lob)),
    );
  }, [allPending, role, lockedFunction, lockedLobs]);

  const pageItems = useMemo(
    () => pending.slice((page - 1) * pageSize, page * pageSize),
    [pending, page, pageSize],
  );

  if (role !== "superadmin" && !(role === "admin" && lockedFunction === "GOE")) return null;

  return (
    <>
      <Card className="border-border bg-surface shadow-elev-1">
        <CardHeader className="pb-2">
          <div className="min-w-0">
            <h5 className="text-h5 text-foreground">Pending platforms</h5>
            <p className="text-body-3 text-muted-foreground">Confirm new platforms ready for upload into OLP Launch Orchestrator</p>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          {pending.length === 0 ? (
            <div className="px-6 py-10 text-center">
              <Sparkles className="h-6 w-6 text-muted-foreground mx-auto mb-2" />
              <p className="text-body-3 text-foreground">You're all caught up.</p>
              <p className="text-caption text-muted-foreground mt-1">
                New platforms from Jira will appear here.
              </p>
            </div>
          ) : (
            <>
              <ul className="grid grid-cols-[auto_auto_auto_auto_auto_auto_1fr_auto] divide-y divide-border">
                {pageItems.map((p) => (
                  <li
                    key={p.id}
                    className="col-span-full grid grid-cols-subgrid items-center gap-2 px-6 py-3"
                  >
                    <p className="text-body-3 text-foreground truncate pr-6">
                      {p.name}
                    </p>
                    <Badge
                      variant={p.source === "user" ? "secondary" : "outline"}
                      className="text-body-3 w-full justify-center gap-1 font-medium border-transparent text-white bg-[linear-gradient(90deg,#0063B8_0%,#7F234F_50%,#40155C_100%)] hover:opacity-90"
                    >
                      {p.source === "user" ? "User submitted" : "Jira"}
                    </Badge>
                    <Badge variant="outline" className="text-body-3 w-full justify-center gap-1 font-medium bg-[#D9F5FD] text-[#0672CB] border-[#5CC1EE]">
                      {p.jiraKey}
                    </Badge>
                    <Badge variant="outline" className="text-body-3 w-full justify-center gap-1 font-medium bg-[#D9F5FD] text-[#0672CB] border-[#5CC1EE]">
                      {p.businessUnit}
                    </Badge>
                    <Badge variant="outline" className="text-body-3 w-full justify-center gap-1 font-medium bg-[#D9F5FD] text-[#0672CB] border-[#5CC1EE]">
                      {p.lob}
                    </Badge>
                    <Badge variant="outline" className="text-body-3 w-full justify-center gap-1 font-medium bg-[#D9F5FD] text-[#0672CB] border-[#5CC1EE]">
                      Created {relativeAge(p.requestedAt)}
                    </Badge>
                    <div />
                    <Button size="sm" variant="outline" className="h-8 py-1 !text-body-3 font-medium justify-self-end bg-transparent border-[#0672CB] text-[#0672CB] hover:bg-[#0672CB]/10 hover:text-[#0672CB]" onClick={() => setTarget(p)}>
                      Review
                    </Button>
                  </li>
                ))}
              </ul>
              <div className="border-t border-border px-6 py-3">
                <DdsPagination
                  page={page}
                  pageSize={pageSize}
                  totalItems={pending.length}
                  itemLabel="platforms"
                  onPageChange={setPage}
                  onPageSizeChange={setPageSize}
                />
              </div>
            </>
          )}
        </CardContent>
      </Card>

      <PlatformReviewDrawer
        request={target}
        open={!!target}
        onOpenChange={(o) => { if (!o) setTarget(null); }}
      />
    </>
  );
}

