import { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { ArrowRight, CheckCircle2, ClipboardList, PlayCircle } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useViewFilter } from "@/contexts/ViewFilterContext";
import { launches as ALL_LAUNCHES, type Launch } from "@/mocks/launches";
import { isAutoTask, taskStatus, tasksForLaunch } from "@/lib/launchTasks";
import type { ScheduleTrack } from "@/lib/schedule";
import {
  getEffectivePhase,
  nextPhaseOf,
  subscribePhaseTransitions,
} from "@/mocks/phaseTransitions";


import { cn } from "@/lib/utils";

const TRACKS: ScheduleTrack[] = ["GOE", "NPI", "SChM"];

interface PhaseSummary {
  total: number;
  done: number;
  open: number;
  blockers: number; // at-risk only
}

function summarize(launch: Launch, phaseName: string): PhaseSummary {
  const all = tasksForLaunch(launch);
  let total = 0, done = 0, open = 0, blockers = 0;
  for (const t of all) {
    if (t.phase !== phaseName) continue;
    if (isAutoTask(t)) continue;
    for (const tr of TRACKS) {
      if (!t.teams.includes(tr as never)) continue;
      total += 1;
      const s = taskStatus(launch, t, tr);
      if (s === "completed") done += 1;
      else if (s === "at-risk" || s === "at-risk-mitigated") {
        open += 1;
        if (s === "at-risk") blockers += 1;
      } else if (s === "on-track") {
        // pending — count as open work
        open += 1;
      }
    }
  }
  return { total, done, open, blockers };
}

export function PhaseActionsCard() {
  const navigate = useNavigate();
  const { lockedPlatformIds } = useViewFilter();
  const [, force] = useState(0);


  useEffect(() => subscribePhaseTransitions(() => force((n) => n + 1)), []);

  const platforms = useMemo(() => {
    const ids = new Set(lockedPlatformIds ?? []);
    const list = ids.size > 0 ? ALL_LAUNCHES.filter((l) => ids.has(l.id)) : ALL_LAUNCHES;
    return list;
  }, [lockedPlatformIds]);

  return (
    <section className="space-y-4">
      <div>
        <h2 className="text-h4 text-foreground inline-flex items-center gap-2">
          <PlayCircle className="h-5 w-5 text-primary" strokeWidth={1.5} />
          Phase actions
        </h2>
        <p className="text-caption text-muted-foreground mt-1">
          As phase manager you're responsible for closing the current phase and launching the next one.
        </p>
      </div>

      <Card className="border-border bg-surface shadow-elev-1">
        <CardHeader className="pb-2">
          <CardTitle className="text-h6 text-foreground">Platforms in your scope</CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <ul className="divide-y divide-border">
            {platforms.map((l) => {
              const phase = getEffectivePhase(l);
              const next = nextPhaseOf(phase);
              const s = summarize(l, phase);
              const pct = s.total > 0 ? Math.round((s.done / s.total) * 100) : 0;


              return (
                <li key={l.id} className="grid grid-cols-12 items-center gap-3 px-4 py-3">
                  <div className="col-span-4 min-w-0">
                    <p className="text-body-3 font-medium text-foreground truncate">{l.name}</p>
                    <p className="text-caption text-muted-foreground truncate">{l.lob} · {l.region} · {l.owner}</p>
                  </div>
                  <div className="col-span-3">
                    <div className="flex items-center gap-2">
                      <span className="text-caption uppercase tracking-wide text-muted-foreground">Phase</span>
                      <span className="text-body-3 text-foreground">{phase}</span>
                      {next && (
                        <>
                          <ArrowRight className="h-3 w-3 text-muted-foreground" />
                          <span className="text-caption text-muted-foreground">{next}</span>
                        </>
                      )}
                    </div>
                    <p className="text-caption text-muted-foreground tabular-nums mt-1">
                      {s.done}/{s.total} tasks · {pct}%
                    </p>
                  </div>
                  <div className="col-span-2">
                    {s.open === 0 && s.total > 0 ? (
                      <span className="inline-flex items-center gap-1 text-caption text-status-on-track">
                        <CheckCircle2 className="h-3 w-3" /> Ready to advance
                      </span>
                    ) : (
                      <span className={cn(
                        "inline-flex items-center gap-1 text-caption",
                        s.blockers > 0 ? "text-status-at-risk" : "text-status-at-risk-mitigated",
                      )}>
                        <ClipboardList className="h-3 w-3" />
                        {s.open} open{s.blockers > 0 ? ` · ${s.blockers} risk` : ""}
                      </span>
                    )}
                  </div>
                  <div className="col-span-3 flex items-center justify-end gap-2">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => navigate(`/tasks?tab=platform&launch=${l.id}`)}
                    >
                      Review
                    </Button>
                    {!next && (
                      <span className="inline-flex items-center text-caption text-muted-foreground px-2">
                        Launched
                      </span>
                    )}

                  </div>
                </li>
              );
            })}
            {platforms.length === 0 && (
              <li className="px-4 py-6 text-caption text-muted-foreground">
                No platforms in scope.
              </li>
            )}
          </ul>
        </CardContent>
      </Card>


    </section>
  );
}
