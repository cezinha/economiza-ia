import { useMemo } from "react";
import { Link } from "react-router-dom";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ChevronRight } from "lucide-react";
import type { Launch } from "@/mocks/launches";
import { phasesForLaunch, type ScheduleTrack } from "@/lib/schedule";
import {
  tasksForLaunch,
  groupTasksByPhaseAndGate,
  taskStatus,
  worstActive,
  type TaskStatus,
} from "@/lib/launchTasks";
import { KEY_MILESTONES, milestoneDate } from "@/lib/keyMilestones";
import { cn } from "@/lib/utils";
import { ScheduleDrilldown } from "@/components/dashboard/ScheduleDrilldown";


interface PhaseExitTrackerProps {
  launch: Launch;
}

const TRACKS: ScheduleTrack[] = ["SChM", "GOE", "NPI"];

const STATUS_CLASS: Record<TaskStatus, string> = {
  completed: "bg-status-completed",
  "on-track": "bg-status-on-track",
  "at-risk-mitigated": "bg-status-at-risk-mitigated",
  "at-risk": "bg-status-at-risk",
  "not-started": "bg-status-not-started",
};

const STATUS_LABEL: Record<TaskStatus, string> = {
  completed: "Completed",
  "on-track": "On track",
  "at-risk-mitigated": "At risk · mitigation plan",
  "at-risk": "At risk · no mitigation",
  "not-started": "Not started",
};

// R > Y > G > Not started > Completed
const STATUS_SORT_RANK: Record<TaskStatus, number> = {
  "at-risk": 0,
  "at-risk-mitigated": 1,
  "on-track": 2,
  "not-started": 3,
  completed: 4,
};

function rollupGateStatus(launch: Launch, tasks: ReturnType<typeof tasksForLaunch>): TaskStatus {
  const all = tasks.flatMap((t) => t.teams.map((tm) => taskStatus(launch, t, tm)));
  if (all.length === 0) return "not-started";
  if (all.every((s) => s === "completed")) return "completed";
  if (all.every((s) => s === "not-started")) return "not-started";
  const active = all.filter((s) => s !== "completed" && s !== "not-started");
  return active.length > 0 ? worstActive(active) : "on-track";
}

function fmtDate(d: Date): string {
  return d.toLocaleDateString(undefined, { month: "short", day: "numeric", year: "numeric" });
}
function daysBetween(a: Date, b: Date): number {
  return Math.round((b.getTime() - a.getTime()) / (1000 * 60 * 60 * 24));
}

export function PhaseExitTracker({ launch }: PhaseExitTrackerProps) {
  const today = new Date();

  const { phaseSpan, track } = useMemo(() => {
    for (const tr of TRACKS) {
      const spans = phasesForLaunch(launch, tr);
      const span = spans.find((p) => p.name === launch.phase);
      if (span) return { phaseSpan: span, track: tr };
    }
    const spans = phasesForLaunch(launch, "SChM");
    return { phaseSpan: spans[0], track: "SChM" as ScheduleTrack };
  }, [launch]);

  if (!phaseSpan) return null;

  // Real key milestones inside this phase span — sorted most-future → most-past.
  const phaseMilestones = KEY_MILESTONES
    .map((m) => ({ ...m, date: milestoneDate(launch.launchDate, m.offsetDays) }))
    .filter((m) => m.date >= phaseSpan.start && m.date <= phaseSpan.end)
    .sort((a, b) => b.date.getTime() - a.date.getTime());

  // Real exit criteria pulled from the task list — gates within the current phase.
  const launchTasks = tasksForLaunch(launch);
  const grouped = groupTasksByPhaseAndGate(launchTasks);
  const phaseGroup = grouped.find((p) => p.phase === phaseSpan.name);
  const criteria = (phaseGroup?.gates ?? [])
    .map((g) => ({
      gate: g.gate,
      count: g.tasks.length,
      status: rollupGateStatus(launch, g.tasks),
    }))
    .sort((a, b) => STATUS_SORT_RANK[a.status] - STATUS_SORT_RANK[b.status]);

  return (
    <section className="space-y-6">
      <div className="flex items-baseline justify-between gap-4 flex-wrap">
        <h2 className="text-h4 text-foreground">Phase exit tracker</h2>
        <span className="text-caption text-muted-foreground">
          {launch.name} · Current phase:{" "}
          <span className="font-medium text-foreground">{phaseSpan.name}</span>
        </span>

      </div>

      {/* Full multi-track timeline — mirrors the OLP schedule calendar view */}
      <ScheduleDrilldown launchId={launch.id} title="Launch phase timeline" onlyCurrentPhase />



      <div className="grid gap-6 m:grid-cols-2">
        <Card className="border-border bg-surface shadow-elev-1">
          <CardHeader>
            <h5 className="text-h5 text-foreground">
              Key milestones for current phase
            </h5>
          </CardHeader>
          <CardContent>
            {phaseMilestones.length === 0 ? (
              <p className="text-caption text-muted-foreground italic">
                No key milestones fall inside this phase.
              </p>
            ) : (
              <ul className="space-y-3">
                {phaseMilestones.map((m) => {
                  const delta = daysBetween(today, m.date);
                  const past = delta < 0;
                  const label =
                    delta === 0
                      ? "Today"
                      : past
                        ? `${Math.abs(delta)}d ago`
                        : `in ${delta}d`;
                  return (
                    <li
                      key={m.key}
                      className="flex items-center justify-between gap-3 border-b border-border last:border-0 pb-3 last:pb-0"
                    >
                      <div className="flex items-center gap-3 min-w-0">
                        <span
                          className={cn(
                            "inline-block h-2 w-2 rotate-45 shrink-0",
                            m.isPhaseExit ? "bg-milestone-phase-exit" : "bg-milestone-key",
                          )}
                          aria-hidden
                        />
                        <div className="min-w-0">
                          <p className="text-body-3 text-foreground truncate">
                            {m.fullName}{" "}
                            <span className="text-caption text-muted-foreground">({m.label})</span>
                          </p>
                          <p className="text-caption text-muted-foreground tabular-nums">
                            {fmtDate(m.date)}
                          </p>
                        </div>
                      </div>
                      <span className="text-caption text-muted-foreground tabular-nums shrink-0">
                        {label}
                      </span>
                    </li>
                  );
                })}
              </ul>
            )}
          </CardContent>
        </Card>

        <Card className="border-border bg-surface shadow-elev-1">
          <CardHeader>
            <h5 className="text-h5 text-foreground">
              Phase gate exit criteria
            </h5>
            <p className="text-caption text-muted-foreground">
              Required to exit the {phaseSpan.name} phase
            </p>
          </CardHeader>
          <CardContent>
            {criteria.length === 0 ? (
              <p className="text-caption text-muted-foreground italic">
                No exit criteria defined for this phase.
              </p>
            ) : (
              <ul className="space-y-3">
                {criteria.map((c) => {
                  const href =
                    `/tasks?tab=platform&launch=${launch.id}&inner=tasks` +
                    `&phase=${encodeURIComponent(phaseSpan.name)}` +
                    `&gate=${encodeURIComponent(c.gate)}`;
                  return (
                    <li
                      key={c.gate}
                      className="flex items-start justify-between gap-3 border-b border-border last:border-0 pb-3 last:pb-0"
                    >
                      <div className="flex items-center gap-3 min-w-0 flex-1">
                        <span
                          className={cn(
                            "inline-block h-2 w-2 rounded-full shrink-0",
                            STATUS_CLASS[c.status],
                          )}
                          aria-hidden
                        />
                        <p className="text-body-3 text-foreground min-w-0">
                          {c.gate}
                          <span className="ml-2 text-caption font-normal text-muted-foreground tabular-nums">
                            {c.count}
                          </span>
                        </p>
                      </div>
                      <div className="flex items-center gap-2 shrink-0">
                        <Link
                          to={href}
                          aria-label={`View ${phaseSpan.name} tasks for: ${c.gate}`}
                          className="inline-flex items-center gap-1 rounded-sm px-1 text-caption text-primary hover:underline whitespace-nowrap focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                        >
                          View tasks
                          <ChevronRight className="h-3 w-3" />
                        </Link>
                        <Badge
                          variant="outline"
                          className="rounded-full font-medium shrink-0"
                        >
                          {STATUS_LABEL[c.status]}
                        </Badge>
                      </div>
                    </li>
                  );
                })}
              </ul>
            )}
          </CardContent>
        </Card>
      </div>
    </section>
  );
}
