import { useRef } from "react";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { ExportPdfButton } from "@/components/dashboard/ExportPdfButton";
import { launches as ALL_LAUNCHES } from "@/mocks/launches";
import { useFilteredLaunches } from "@/lib/applyFilters";
import { useFilters } from "@/contexts/FilterContext";
import { currentPhaseName, functionStatus } from "@/lib/launchTasks";
import { phasesForLaunch, type ScheduleTrack } from "@/lib/schedule";
import {
  Bar,
  BarChart,
  CartesianGrid,
  LabelList,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";

const SERIES = [
  { key: "onTrack", label: "Achieved / on track", color: "hsl(var(--status-on-track))" },
  { key: "atRiskMit", label: "Risk with mitigation", color: "hsl(var(--status-at-risk-mitigated))" },
  { key: "atRisk", label: "Missed / no mitigation plan", color: "hsl(var(--status-at-risk))" },
] as const;

interface Props {
  track: ScheduleTrack;
}

export function PhaseStatusByTrack({ track }: Props) {
  const { filters } = useFilters();
  const exportRef = useRef<HTMLDivElement>(null);
  const fnFilter = Array.isArray(filters.function) ? (filters.function as string[]) : [];
  const trackActive = fnFilter.length === 0 || fnFilter.includes(track);
  const filteredLaunches = useFilteredLaunches();
  const launches = trackActive ? filteredLaunches : [];
  const phases = phasesForLaunch(ALL_LAUNCHES[0], track).map((p) => p.name);

  const data = phases.map((phase) => {
    const row = { phase, onTrack: 0, atRiskMit: 0, atRisk: 0, total: 0 };
    for (const l of launches) {
      if (currentPhaseName(l, track) !== phase) continue;
      const s = functionStatus(l, track);
      if (s === "on-track") row.onTrack += 1;
      else if (s === "at-risk-mitigated") row.atRiskMit += 1;
      else if (s === "at-risk") row.atRisk += 1;
      row.total += 1;
    }
    return row;
  });

  return (
    <Card className="border-border bg-surface shadow-elev-1 h-full">
      <CardHeader className="space-y-1">
        <div className="flex items-start justify-between gap-3">
          <div className="space-y-1">
            <CardTitle className="text-h5 text-foreground">
              Status distribution by current phase ({track})
            </CardTitle>
            <p className="text-body-3 text-muted-foreground">Total count across active platforms</p>
          </div>
          <ExportPdfButton
            targetRef={exportRef}
            title={`Status distribution by current phase (${track})`}
            filenameSlug={`status-distribution-${track.toLowerCase()}`}
            orientation="landscape"
          />
        </div>
      </CardHeader>
      <CardContent>
        <div ref={exportRef} className="bg-surface">
        <div className="h-[320px] w-full">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={data} margin={{ top: 24, right: 16, bottom: 24, left: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
              <XAxis
                dataKey="phase"
                stroke="hsl(var(--muted-foreground))"
                tick={{ fontSize: 12 }}
                tickLine={false}
                axisLine={{ stroke: "hsl(var(--border))" }}
                label={{
                  value: "Phase",
                  position: "insideBottom",
                  offset: -12,
                  style: { fill: "hsl(var(--muted-foreground))", fontSize: 12 },
                }}
              />
              <YAxis
                allowDecimals={false}
                stroke="hsl(var(--muted-foreground))"
                tick={{ fontSize: 12 }}
                tickLine={false}
                axisLine={{ stroke: "hsl(var(--border))" }}
                label={{
                  value: "Platform count",
                  angle: -90,
                  position: "insideLeft",
                  style: { fill: "hsl(var(--muted-foreground))", fontSize: 12, textAnchor: "middle" },
                }}
              />
              <Tooltip
                cursor={{ fill: "hsl(var(--muted))" }}
                content={({ active, payload, label }) => {
                  if (!active || !payload?.length) return null;
                  return (
                    <div className="rounded-sm border border-border bg-surface px-3 py-2 shadow-elev-2">
                      <div className="text-body-3 font-medium text-foreground">{label}</div>
                      <div className="mt-1 flex flex-col gap-1">
                        {payload.map((p) => (
                          <div
                            key={String(p.dataKey)}
                            className="flex items-center gap-2 text-caption text-foreground"
                          >
                            <span
                              className="inline-block h-2 w-2 rounded-sm"
                              style={{ background: p.color }}
                            />
                            <span>
                              {p.name} : {p.value}
                            </span>
                          </div>
                        ))}
                      </div>
                    </div>
                  );
                }}
              />
              {SERIES.map((s, i) => (
                <Bar
                  key={s.key}
                  dataKey={s.key}
                  name={s.label}
                  stackId="s"
                  fill={s.color}
                  radius={i === SERIES.length - 1 ? [4, 4, 0, 0] : [0, 0, 0, 0]}
                >
                  {i === SERIES.length - 1 && (
                    <LabelList
                      dataKey="total"
                      position="top"
                      style={{ fill: "hsl(var(--foreground))", fontSize: 12 }}
                    />
                  )}
                </Bar>
              ))}
            </BarChart>
          </ResponsiveContainer>
        </div>
        <div className="mt-2 flex flex-wrap items-center justify-center gap-4">
          {SERIES.map((s) => (
            <div key={s.key} className="flex items-center gap-2 text-caption text-foreground">
              <span className="inline-block h-2 w-2 rounded-sm" style={{ background: s.color }} />
              <span>{s.label}</span>
            </div>
          ))}
        </div>
        </div>
      </CardContent>
    </Card>
  );
}
