import { useCallback, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Card, CardHeader, CardContent } from "@/components/ui/card";

import { DdsGrid, DdsCol } from "@/components/layout/DdsGrid";
import { launches as ALL_LAUNCHES, type Launch } from "@/mocks/launches";
import { useFilteredLaunches } from "@/lib/applyFilters";
import { useFilters } from "@/contexts/FilterContext";
import { currentPhaseName, functionStatus, type TaskStatus } from "@/lib/launchTasks";
import { phasesForLaunch, type ScheduleTrack } from "@/lib/schedule";

import { FunctionStatusDrawer } from "@/components/dashboard/drawers/FunctionStatusDrawer";
import { CoreTeamDrawer } from "@/components/dashboard/drawers/CoreTeamDrawer";

import {
  Bar,
  BarChart,
  CartesianGrid,
  LabelList,
  Legend,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";

const SERIES = [
  { key: "onTrack", label: "Achieved / on track", color: "hsl(var(--status-on-track))" },
  { key: "atRiskMit", label: "Risk with mitigation", color: "hsl(var(--status-at-risk-mitigated))" },
  { key: "atRisk", label: "Missed / no mitigation plan", color: "hsl(var(--status-at-risk))" },
] as const;

const TRACKS: ScheduleTrack[] = ["GOE", "NPI", "SChM"];

export function buildData(track: ScheduleTrack, launches: Launch[]) {
  // Core team follows SChM phase definitions (Concept, Define, Plan, Develop, Launch).
  const phaseTrack: ScheduleTrack = track === "Core" ? "SChM" : track;
  const phases = phasesForLaunch(ALL_LAUNCHES[0], phaseTrack).map((p) => p.name);
  return phases.map((phase) => {
    const row = { phase, onTrack: 0, atRiskMit: 0, atRisk: 0, total: 0 };
    for (const l of launches) {
      if (currentPhaseName(l, phaseTrack) !== phase) continue;
      const s = functionStatus(l, track);
      if (s === "on-track") row.onTrack += 1;
      else if (s === "at-risk-mitigated") row.atRiskMit += 1;
      else if (s === "at-risk") row.atRisk += 1;
      row.total += 1;
    }
    return row;
  });
}

type StatusBucket = "achieved" | "risk-mitigated" | "missed";

const KEY_TO_BUCKET: Record<(typeof SERIES)[number]["key"], StatusBucket> = {
  onTrack: "achieved",
  atRiskMit: "risk-mitigated",
  atRisk: "missed",
};

export function TrackChart({
  track,
  launches,
  onSelectPhase,
  onSelectSegment,
}: {
  track: ScheduleTrack;
  launches: Launch[];
  onSelectPhase?: (phase: string) => void;
  onSelectSegment?: (phase: string, bucket: StatusBucket) => void;
}) {
  const data = buildData(track, launches);
  const interactive = Boolean(onSelectPhase || onSelectSegment);
  return (
    <div className="h-[360px] w-full">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart
          data={data}
          margin={{ top: 32, right: 32, bottom: 24, left: 24 }}
          barCategoryGap="33%"
        >
          <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
          <XAxis
            dataKey="phase"
            stroke="hsl(var(--muted-foreground))"
            tick={{ fontSize: 11 }}
            tickLine={false}
            axisLine={{ stroke: "hsl(var(--border))" }}
            interval={0}
            label={{
              value: "Phase",
              position: "insideBottom",
              offset: -12,
              style: { fill: "hsl(var(--muted-foreground))", fontSize: 12 },
            }}
          />
          <YAxis
            allowDecimals={false}
            domain={[0, "dataMax"]}
            stroke="hsl(var(--muted-foreground))"
            tick={{ fontSize: 12 }}
            tickLine={false}
            axisLine={{ stroke: "hsl(var(--border))" }}
            label={{
              value: "Platform count",
              angle: -90,
              position: "insideLeft",
              style: { fill: "hsl(var(--muted-foreground))", fontSize: 12, textAnchor: "middle" },
            }}
          />
          <Tooltip
            cursor={{ fill: "hsl(var(--muted))" }}
            wrapperStyle={{ zIndex: 50, outline: "none" }}
            content={({ active, payload, label }) => {
              if (!active || !payload?.length) return null;
              return (
                <div className="rounded-sm border border-border bg-surface px-3 py-2 shadow-elev-2 [background-color:hsl(var(--surface))]">
                  <div className="text-body-3 font-medium text-foreground">{label}</div>
                  <div className="mt-1 flex flex-col gap-1">
                    {payload.map((p) => (
                      <div
                        key={String(p.dataKey)}
                        className="flex items-center gap-2 text-caption text-foreground"
                      >
                        <span
                          className="inline-block h-2 w-2 rounded-sm"
                          style={{ background: p.color }}
                        />
                        <span>{p.name}</span>
                        <span className="ml-auto font-medium">{p.value}</span>
                      </div>
                    ))}
                  </div>
                </div>
              );
            }}
          />
          <Legend
            verticalAlign="bottom"
            align="center"
            iconType="square"
            iconSize={8}
            wrapperStyle={{ fontSize: 12, paddingTop: 24, color: "hsl(var(--muted-foreground))" }}
            formatter={(value) => (
              <span style={{ color: "hsl(var(--muted-foreground))" }}>{value}</span>
            )}
          />
          {SERIES.map((s, i) => (
            <Bar
              key={s.key}
              dataKey={s.key}
              name={s.label}
              stackId="s"
              fill={s.color}
              cursor={interactive ? "pointer" : undefined}
              onClick={
                interactive
                  ? (d: { payload?: { phase?: string; [k: string]: unknown } }) => {
                      const phase = d?.payload?.phase;
                      if (!phase) return;
                      const value = Number(d?.payload?.[s.key] ?? 0);
                      if (onSelectSegment && value > 0) {
                        onSelectSegment(phase, KEY_TO_BUCKET[s.key]);
                        return;
                      }
                      onSelectPhase?.(phase);
                    }
                  : undefined
              }
            >
              {i === SERIES.length - 1 && (
                <LabelList
                  dataKey="total"
                  position="top"
                  offset={8}
                  style={{ fill: "hsl(var(--foreground))", fontSize: 12 }}
                />
              )}
            </Bar>
          ))}
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}



export function PhaseStatusCard() {
  const { filters, setManyFilters } = useFilters();
  const fnFilter = Array.isArray(filters.function) ? (filters.function as string[]) : [];
  const filteredLaunches = useFilteredLaunches();
  const tracksToShow = TRACKS.filter(
    (t) => fnFilter.length === 0 || fnFilter.includes(t),
  );
  const [openTrack, setOpenTrack] = useState<ScheduleTrack | null>(null);
  const [coreOpen, setCoreOpen] = useState(false);
  const navigate = useNavigate();

  const drillTo = useCallback(
    (track: ScheduleTrack, phase: string) => {
      setManyFilters({ function: [track], phase: [`${track}:${phase}`], status: [] });
      navigate("/launches");
    },
    [setManyFilters, navigate],
  );

  const drillToSegment = useCallback(
    (track: ScheduleTrack, phase: string, bucket: "achieved" | "risk-mitigated" | "missed") => {
      setManyFilters({
        function: [track],
        phase: [`${track}:${phase}`],
        status: [bucket],
      });
      navigate("/launches");
    },
    [setManyFilters, navigate],
  );

  // Pick the worst Core team offender as the drawer target when opened from the column header.
  const coreWorst = useMemo(() => {
    const sev = (s: TaskStatus) =>
      s === "at-risk" ? 0 : s === "at-risk-mitigated" ? 1 : 2;
    return [...filteredLaunches].sort(
      (a, b) => sev(functionStatus(a, "Core")) - sev(functionStatus(b, "Core")),
    )[0] ?? null;
  }, [filteredLaunches]);

  // Core team column always shown; function filter only narrows GOE/NPI/SChM columns.
  return (
    <section className="space-y-4">
      <div className="space-y-4">
        <DdsGrid>
          <DdsCol span={6} spanM={6} spanS={6} spanXs={2}>
            <Card className="border-border bg-surface shadow-elev-1 h-full">
              <CardHeader className="pb-8 space-y-1">
                <h5 className="text-h5 text-foreground">Current phase status: Core team</h5>
                <p className="text-body-3 text-muted-foreground">Total count across active platforms</p>
              </CardHeader>
              <CardContent>
                <TrackChart
                  track="Core"
                  launches={filteredLaunches}
                  onSelectPhase={(p) => drillTo("Core", p)}
                  onSelectSegment={(p, b) => drillToSegment("Core", p, b)}
                />
              </CardContent>
            </Card>
          </DdsCol>
          {tracksToShow.map((t) => (
            <DdsCol key={t} span={6} spanM={6} spanS={6} spanXs={2}>
              <Card className="border-border bg-surface shadow-elev-1 h-full">
                <CardHeader className="pb-8 space-y-1">
                  <div className="flex items-start justify-between gap-2">
                    <h5 className="text-h5 text-foreground">
                      Current phase status: {t === "SChM" ? "SChM" : t}
                    </h5>
                    <span className="shrink-0 rounded-full border border-border bg-muted px-2 py-0.5 text-caption text-muted-foreground">
                      Post-MVP
                    </span>
                  </div>
                  <p className="text-body-3 text-muted-foreground">Total count across active platforms</p>
                </CardHeader>
                <CardContent>
                  <TrackChart
                    track={t}
                    launches={filteredLaunches}
                    onSelectPhase={(p) => drillTo(t, p)}
                    onSelectSegment={(p, b) => drillToSegment(t, p, b)}
                  />
                </CardContent>
              </Card>
            </DdsCol>
          ))}
        </DdsGrid>
      </div>
      <FunctionStatusDrawer
        open={openTrack !== null}
        onOpenChange={(o) => !o && setOpenTrack(null)}
        track={openTrack ?? undefined}
      />
      <CoreTeamDrawer
        open={coreOpen}
        onOpenChange={setCoreOpen}
        launch={coreWorst}
      />
    </section>
  );
}
