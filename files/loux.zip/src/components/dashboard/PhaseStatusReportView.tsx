import { useCallback } from "react";
import { useNavigate } from "react-router-dom";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { DdsGrid, DdsCol } from "@/components/layout/DdsGrid";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { useFilteredLaunches } from "@/lib/applyFilters";
import { useFilters } from "@/contexts/FilterContext";
import { currentPhaseName, functionStatus, type TaskStatus } from "@/lib/launchTasks";
import { effectiveLaunchDate } from "@/mocks/launchDateOverrides";
import type { Launch } from "@/mocks/launches";
import type { ScheduleTrack } from "@/lib/schedule";
import { TrackChart } from "@/components/dashboard/PhaseStatusCard";
import { cn } from "@/lib/utils";

const TRACKS_ALL: ScheduleTrack[] = ["Core", "GOE", "NPI", "SChM"];

const trackLabel = (t: ScheduleTrack) =>
  t === "SChM" ? "SChM" : t === "Core" ? "Core team" : t;

function statusFor(track: ScheduleTrack, l: Launch): TaskStatus {
  return functionStatus(l, track);
}

function phaseFor(track: ScheduleTrack, l: Launch): string {
  // Core team follows SChM phase definitions (Concept, Define, Plan, Develop, Launch).
  return currentPhaseName(l, track === "Core" ? "SChM" : track) ?? "";
}

const RYG_LABEL: Record<TaskStatus, { letter: string; tone: string }> = {
  completed: { letter: "G", tone: "text-status-on-track" },
  "on-track": { letter: "G", tone: "text-status-on-track" },
  "at-risk-mitigated": { letter: "Y", tone: "text-status-at-risk-mitigated" },
  "at-risk": { letter: "R", tone: "text-status-at-risk" },
  "not-started": { letter: "—", tone: "text-muted-foreground" },
};

function isRisk(s: TaskStatus) {
  return s === "at-risk" || s === "at-risk-mitigated";
}

function ExecutiveSummary({ track, launches }: { track: ScheduleTrack; launches: Launch[] }) {
  const onTrack = launches.filter((l) => statusFor(track, l) === "on-track" || statusFor(track, l) === "completed");
  const risky = launches.filter((l) => isRisk(statusFor(track, l)));

  const byPhase = new Map<string, Launch[]>();
  for (const l of risky) {
    const p = phaseFor(track, l);
    if (!byPhase.has(p)) byPhase.set(p, []);
    byPhase.get(p)!.push(l);
  }

  return (
    <Card className="border-border bg-surface shadow-elev-1 h-full">
      <CardHeader className="pb-2">
        <h5 className="text-h5 text-foreground">Executive summary</h5>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-1">
          <p className="text-body-3 text-foreground">
            <span className="font-medium">All phases: Total {launches.length} platforms,</span>{" "}
            {risky.length === 0 ? (
              <span>all in <span className="text-status-on-track font-medium">Green</span>.</span>
            ) : (
              <>
                {onTrack.length} in <span className="text-status-on-track font-medium">Green</span>,{" "}
                {risky.length} in <span className="text-status-at-risk-mitigated font-medium">Yellow / Red</span>.
              </>
            )}
          </p>
        </div>
        {byPhase.size === 0 ? (
          <p className="text-body-3 text-muted-foreground">No active risks across {trackLabel(track)} workstream.</p>
        ) : (
          [...byPhase.entries()].map(([phase, items]) => (
            <div key={phase} className="space-y-1">
              <p className="text-body-3 text-foreground font-medium">{phase} phase: {items.length} platform{items.length === 1 ? "" : "s"} flagged</p>
              <ul className="space-y-1 list-disc pl-5">
                {items.map((l) => {
                  const s = statusFor(track, l);
                  const ryg = RYG_LABEL[s];
                  return (
                    <li key={l.id} className="text-body-3 text-muted-foreground">
                      {l.name} (<span className={cn("font-medium", ryg.tone)}>{ryg.letter}</span>): placeholder
                      narrative for the {phase.toLowerCase()} phase — mitigation in progress, checkpoint pending.
                    </li>
                  );
                })}
              </ul>
            </div>
          ))
        )}
      </CardContent>
    </Card>
  );
}

function IssueTable({ track, launches }: { track: ScheduleTrack; launches: Launch[] }) {
  const rows = launches.filter((l) => isRisk(statusFor(track, l)));

  return (
    <div className="overflow-x-auto rounded-md border border-border">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead className="text-caption">Phase</TableHead>
            <TableHead className="text-caption">RYG</TableHead>
            <TableHead className="text-caption">Platform</TableHead>
            <TableHead className="text-caption">Issue description</TableHead>
            <TableHead className="text-caption">Business impact</TableHead>
            <TableHead className="text-caption">Mitigation plan</TableHead>
            <TableHead className="text-caption">Owner (target closure)</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {rows.length === 0 ? (
            <TableRow>
              <TableCell colSpan={7} className="text-body-3 text-muted-foreground text-center">
                No active issues.
              </TableCell>
            </TableRow>
          ) : (
            rows.map((l) => {
              const s = statusFor(track, l);
              const ryg = RYG_LABEL[s];
              return (
                <TableRow key={l.id}>
                  <TableCell className="text-body-3 align-top">{phaseFor(track, l)}</TableCell>
                  <TableCell className={cn("text-body-3 font-medium align-top", ryg.tone)}>{ryg.letter}</TableCell>
                  <TableCell className="text-body-3 align-top">{l.name}</TableCell>
                  <TableCell className="text-body-3 align-top">
                    {l.name} placeholder issue impacting {trackLabel(track)} readiness.
                  </TableCell>
                  <TableCell className="text-body-3 align-top">
                    Potential RTS slip; low DSI based on current outlook.
                  </TableCell>
                  <TableCell className="text-body-3 align-top">
                    Core team to finalize mitigation plan; pull-in primary supply.
                  </TableCell>
                  <TableCell className="text-body-3 align-top">
                    Core team — {effectiveLaunchDate(l)}
                  </TableCell>
                </TableRow>
              );
            })
          )}
        </TableBody>
      </Table>
    </div>
  );
}

function PhaseTrackReport({ track, launches }: { track: ScheduleTrack; launches: Launch[] }) {
  const navigate = useNavigate();
  const { setFilter } = useFilters();
  const drillTo = useCallback(
    (phase: string) => {
      setFilter("function", [track]);
      setFilter("phase", [`${track}:${phase}`]);
      navigate("/launches");
    },
    [track, setFilter, navigate],
  );
  return (
    <Card className="border-border bg-surface shadow-elev-1">
      <CardHeader className="pb-2">
        <h4 className="text-h5 text-foreground">Phase gate status report: {trackLabel(track)}</h4>
      </CardHeader>
      <CardContent className="space-y-4">
        <DdsGrid>
          <DdsCol span={12} spanM={3} spanS={6} spanXs={2}>
            <TrackChart track={track} launches={launches} onSelectPhase={drillTo} />
          </DdsCol>
          <DdsCol span={12} spanM={3} spanS={6} spanXs={2}>
            <ExecutiveSummary track={track} launches={launches} />
          </DdsCol>
        </DdsGrid>
        <IssueTable track={track} launches={launches} />
      </CardContent>
    </Card>
  );
}

export function PhaseStatusReportView() {
  const launches = useFilteredLaunches();
  const { filters } = useFilters();
  const fnFilter = Array.isArray(filters.function) ? (filters.function as string[]) : [];
  const tracks = TRACKS_ALL.filter((t) => t === "Core" || fnFilter.length === 0 || fnFilter.includes(t));

  return (
    <div className="space-y-6">
      {tracks.map((t) => (
        <PhaseTrackReport key={t} track={t} launches={launches} />
      ))}
    </div>
  );
}
