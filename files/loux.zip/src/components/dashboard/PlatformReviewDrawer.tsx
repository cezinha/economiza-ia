import { useEffect, useState } from "react";
import { toast } from "sonner";
import { ChevronLeft, ExternalLink } from "lucide-react";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetDescription,
  SheetFooter,
} from "@/components/ui/sheet";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import type { PendingPlatform } from "@/mocks/pendingPlatforms";

type Props = {
  request: PendingPlatform | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
  /** When true, fields start blank instead of auto-populated from Jira. */
  blank?: boolean;
};

type FieldKey = string;

/** Editable two-column row (label + input). */
function EditRow({
  label,
  value,
  onChange,
  editable,
}: {
  label: string;
  value: string;
  onChange: (next: string) => void;
  editable?: boolean;
}) {
  return (
    <div className="grid grid-cols-12 gap-4 py-2 border-b border-border last:border-b-0 items-center">
      <label className="col-span-5 text-body-3 text-muted-foreground">{label}</label>
      <div className="col-span-7">
        <Input
          value={value}
          onChange={(e) => onChange(e.target.value)}
          className="h-9 text-body-3"
          readOnly={!editable}
          tabIndex={editable ? 0 : -1}
          placeholder={editable ? "dd/MMM/yy" : undefined}
        />
      </div>
    </div>
  );
}

function EditList({
  fields,
  values,
  onChange,
}: {
  fields: { key: FieldKey; label: string; editable?: boolean }[];
  values: Record<FieldKey, string>;
  onChange: (key: FieldKey, next: string) => void;
}) {
  return (
    <div className="px-1">
      {fields.map((f) => (
        <EditRow
          key={f.key}
          label={f.label}
          value={values[f.key] ?? ""}
          onChange={(v) => onChange(f.key, v)}
          editable={f.editable}
        />
      ))}
    </div>
  );
}

const PROGRAM_FIELDS: { key: FieldKey; label: string }[] = [
  { key: "programName", label: "Program Name" },
  { key: "programState", label: "Program State" },
  { key: "domain", label: "Domain / Business" },
  { key: "category", label: "Program Category" },
  { key: "platformModel", label: "Platform Model ID / DPN / Release" },
  { key: "softwareVersion", label: "Software Version" },
  { key: "marketingName", label: "Marketing Model Name / SMBIOS Product Name" },
  { key: "predecessor", label: "Predecessor" },
  { key: "formFactor", label: "Form Factor" },
  { key: "programClass", label: "Program Class" },
  { key: "programPhase", label: "Program Phase" },
  { key: "tier", label: "Tier" },
  { key: "cpu", label: "CPU Architecture" },
  { key: "odm", label: "ODM / Supplier" },
  { key: "rtsYear", label: "RTS Calendar Year" },
  { key: "rtsQuarter", label: "RTS Calendar Quarter" },
  { key: "rtsMonth", label: "RTS Calendar Month" },
  { key: "rtoYear", label: "RTO Calendar Year" },
  { key: "rtoQuarter", label: "RTO Calendar Quarter" },
  { key: "rtoMonth", label: "RTO Calendar Month" },
  { key: "deliverable", label: "Deliverable" },
];

const CORE_FIELDS: { key: FieldKey; label: string }[] = [
  { key: "assignee", label: "Assignee" },
  { key: "reporter", label: "Reporter" },
  { key: "programManager", label: "Program Manager" },
  { key: "productManager", label: "Product Manager" },
  { key: "projectManager", label: "Project Manager" },
  { key: "engineers", label: "Engineers" },
  { key: "procurement", label: "Procurement" },
  { key: "goe", label: "GOE" },
];

const DATE_FIELDS: { key: FieldKey; label: string; editable?: boolean }[] = [
  { key: "created", label: "Created" },
  { key: "updated", label: "Updated" },
  { key: "conceptEntryT", label: "Concept Entry Target" },
  { key: "conceptEntryA", label: "Concept Entry Actual" },
  { key: "conceptExitT", label: "Concept Exit Target" },
  { key: "conceptExitA", label: "Concept Exit Actual" },
  { key: "defineExitT", label: "Define Exit Target" },
  { key: "defineExitA", label: "Define Exit Actual" },
  { key: "baT", label: "BA Target" },
  { key: "baA", label: "BA Actual" },
  { key: "ddsT", label: "DDS Target" },
  { key: "ddsA", label: "DDS Actual" },
  { key: "planExitT", label: "Plan Exit Target" },
  { key: "planExitA", label: "Plan Exit Actual" },
  { key: "evt", label: "EVT — Engineering Validation Test", editable: true },
  { key: "dvt1", label: "DVT1 — Design Validation Test 1", editable: true },
  { key: "dvt2", label: "DVT2 — Design Validation Test 2", editable: true },
  { key: "qpe", label: "QPE — Qualify Phase Exit", editable: true },
  { key: "ppx", label: "PPx — Pre-Production Engineering", editable: true },
  { key: "pv2", label: "PV2 — Production Validation Test 2", editable: true },
  { key: "qbld", label: "QBLD — Qual Build", editable: true },
  { key: "ppe2", label: "PPE — Pilot Phase Exit / Launch Readiness", editable: true },
  { key: "rfdT", label: "RFD Target" },
  { key: "rfdPor", label: "RFD POR" },
  { key: "rfdA", label: "RFD Actual" },
  { key: "developExitT", label: "Develop Exit Target" },
  { key: "developExitPor", label: "Develop Exit POR" },
  { key: "developExitA", label: "Develop Exit Actual" },
  { key: "rtsT", label: "RTS Target" },
  { key: "rtsPor", label: "RTS POR" },
  { key: "rtoT", label: "RTO Target" },
  { key: "rtoPor", label: "RTO POR" },
  { key: "rtoA", label: "RTO Actual" },
  { key: "launchExitT", label: "Launch Exit Target" },
  { key: "launchExitPor", label: "Launch Exit POR" },
  { key: "launchExitA", label: "Launch Exit Actual" },
  { key: "eolT", label: "EOL Target" },
  { key: "eoseclT", label: "EOSECL Target" },
  { key: "eoslT", label: "EOSL Target" },
  { key: "actualRts", label: "Actual RTS" },
];

const REQUIRED_NEW_KEYS = DATE_FIELDS.filter((f) => f.editable).map((f) => f.key);

function buildInitial(p: PendingPlatform): Record<FieldKey, string> {
  return {
    programName: p.name,
    programState: "Active",
    domain: `${p.businessUnit} - Commercial`,
    category: "Dell Pro Rugged Laptops - Dell Pro Rugged Laptops",
    platformModel: "RB14250",
    softwareVersion: "1.0.0",
    marketingName: `Dell Pro ${p.name}`,
    predecessor: "Delta",
    formFactor: "CS",
    programClass: "3",
    programPhase: "Sustain",
    tier: "2",
    cpu: "MTL",
    odm: "Pegatron",
    rtsYear: "CY24",
    rtsQuarter: "Q4",
    rtsMonth: "Oct",
    rtoYear: "CY24",
    rtoQuarter: "Q4",
    rtoMonth: "Oct",
    deliverable: "HW",

    assignee: "Huang, Ken",
    reporter: "Huang, Ken",
    programManager: "Huang, Ken",
    productManager: "Chen, Silvia",
    projectManager: "Liu, Cooper",
    engineers: "Chiu, Philip",
    procurement: "Tseng, Tzuhao",
    goe: "Qiu, Bin",

    created: "22/Jan/26 5:25 PM",
    updated: "11/May/26 8:14 PM",
    conceptEntryT: "05/Feb/23",
    conceptEntryA: "02/May/23",
    conceptExitT: "12/Sep/23",
    conceptExitA: "12/Sep/23",
    defineExitT: "12/Sep/23",
    defineExitA: "12/Sep/23",
    baT: "31/Oct/23",
    baA: "31/Oct/23",
    ddsT: "31/Oct/23",
    ddsA: "31/Oct/23",
    planExitT: "12/Dec/23",
    planExitA: "12/Dec/23",
    rfdT: "02/Sep/24",
    rfdPor: "02/Sep/24",
    rfdA: "02/Sep/24",
    developExitT: "01/Oct/24",
    developExitPor: "01/Oct/24",
    developExitA: "01/Oct/24",
    rtsT: "08/Oct/24",
    rtsPor: "08/Oct/24",
    rtoT: "08/Oct/24",
    rtoPor: "08/Oct/24",
    rtoA: "08/Oct/24",
    launchExitT: "25/Feb/25",
    launchExitPor: "25/Feb/25",
    launchExitA: "25/Feb/25",
    eolT: "30/Jun/27",
    eoseclT: "08/Apr/32",
    eoslT: "08/Apr/32",
    actualRts: "08/Oct/24",
  };
}

function emptyValues(): Record<FieldKey, string> {
  const out: Record<FieldKey, string> = {};
  for (const f of [...PROGRAM_FIELDS, ...CORE_FIELDS, ...DATE_FIELDS]) out[f.key] = "";
  return out;
}

export function PlatformReviewDrawer({ request, open, onOpenChange, blank }: Props) {
  const [values, setValues] = useState<Record<FieldKey, string>>({});

  useEffect(() => {
    if (!open) return;
    if (blank) setValues(emptyValues());
    else if (request) setValues(buildInitial(request));
  }, [request, open, blank]);

  const update = (key: FieldKey, next: string) =>
    setValues((prev) => ({ ...prev, [key]: next }));

  const canAccept = REQUIRED_NEW_KEYS.every((k) => (values[k] ?? "").trim().length > 0);

  const handleAccept = () => {
    if (!canAccept) return;
    toast.success(
      blank
        ? `Added ${values.programName || "new platform"}`
        : `Accepted ${values.programName ?? request?.name ?? "platform"}`,
    );
    onOpenChange(false);
  };

  const jiraUrl = request ? `https://jira.dell.com/browse/${request.jiraKey}` : "#";

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent
        side="right"
        className={cn(
          "w-[1200px] sm:max-w-[90vw] p-0 bg-surface flex flex-col gap-0 [&>button.absolute]:hidden",
        )}
      >
        <SheetHeader className="px-6 pt-4 pb-4 border-b border-border space-y-2 shrink-0">
          <button
            type="button"
            onClick={() => onOpenChange(false)}
            className="inline-flex items-center gap-1 text-button-2 text-link hover:opacity-80 self-start"
          >
            <ChevronLeft className="h-4 w-4" />
            Back
          </button>
          <SheetTitle className="text-h3 text-foreground">
            {blank ? "Add new platform" : (request?.name ?? "Review platform")}
          </SheetTitle>
          <SheetDescription>
            {blank
              ? "Manually enter platform details."
              : request
                ? `${request.jiraKey} · ${request.businessUnit} · ${request.lob} · Auto-populated from Jira`
                : ""}
          </SheetDescription>
        </SheetHeader>

        <div className="flex-1 overflow-y-auto px-6 py-4">
          {(request || blank) && (
            <Tabs defaultValue="program" className="mt-2">
              <TabsList>
                <TabsTrigger value="program">Program management</TabsTrigger>
                <TabsTrigger value="core">Core team</TabsTrigger>
                <TabsTrigger value="dates">Dates</TabsTrigger>
              </TabsList>
              <TabsContent value="program" className="mt-4">
                <EditList fields={PROGRAM_FIELDS} values={values} onChange={update} />
              </TabsContent>
              <TabsContent value="core" className="mt-4">
                <EditList fields={CORE_FIELDS} values={values} onChange={update} />
              </TabsContent>
              <TabsContent value="dates" className="mt-4">
                <EditList fields={DATE_FIELDS} values={values} onChange={update} />
              </TabsContent>
            </Tabs>
          )}
        </div>

        <SheetFooter className="px-6 py-4 border-t border-border flex-row justify-start sm:justify-start gap-2 sm:space-x-0">
          <Button
            onClick={handleAccept}
            className="text-button-1 text-primary-foreground"
          >
            Confirm
          </Button>
          <Button variant="secondary" onClick={() => onOpenChange(false)} className="text-button-1">
            Close
          </Button>
          {!blank && request && (
            <Button
              variant="outline"
              asChild
              className="text-button-1 gap-1"
            >
              <a href={jiraUrl} target="_blank" rel="noopener noreferrer">
                View in Jira
                <ExternalLink className="h-4 w-4" />
              </a>
            </Button>
          )}
        </SheetFooter>
      </SheetContent>
    </Sheet>
  );
}
