import { useMemo, useState } from "react";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Calendar } from "lucide-react";
import { useFilteredLaunches } from "@/lib/applyFilters";
import type { Launch } from "@/mocks/launches";
import type { PendingPlatform } from "@/mocks/pendingPlatforms";
import { PlatformReviewDrawer } from "./PlatformReviewDrawer";
import { DdsPagination } from "@/components/shell/DdsPagination";
import { StatusLegend } from "@/components/dashboard/StatusLegend";
import { cn } from "@/lib/utils";
import { platformStatus, type TaskStatus } from "@/lib/launchTasks";
import { launchToPending } from "@/lib/launchToPending";

const STATUS_CLASS: Record<TaskStatus, string> = {
  completed: "bg-status-completed",
  "on-track": "bg-status-on-track",
  "at-risk-mitigated": "bg-status-at-risk-mitigated",
  "at-risk": "bg-status-at-risk",
  "not-started": "bg-status-not-started",
};

export function PlatformScheduleTab() {
  const filtered = useFilteredLaunches();
  const [target, setTarget] = useState<PendingPlatform | null>(null);
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);

  const sorted = useMemo(
    () => [...filtered].sort((a, b) => a.launchDate.localeCompare(b.launchDate)),
    [filtered],
  );

  const pageItems = useMemo(
    () => sorted.slice((page - 1) * pageSize, page * pageSize),
    [sorted, page, pageSize],
  );

  return (
    <>
      <Card className="border-border bg-surface shadow-elev-1">
        <CardHeader className="pb-2">
          <div className="min-w-0 space-y-2">
            <h5 className="text-h5 text-foreground">Schedule</h5>
            <p className="text-body-3 text-muted-foreground">
              Review platform milestones and key dates. Open a platform to view program info, core team and dates.
            </p>
            <StatusLegend />
          </div>
        </CardHeader>
        <CardContent className="p-0">
          {sorted.length === 0 ? (
            <div className="px-6 py-10 text-center">
              <Calendar className="h-6 w-6 text-muted-foreground mx-auto mb-2" />
              <p className="text-body-3 text-foreground">No platforms in your current filter.</p>
            </div>
          ) : (
            <>
              <ul className="grid grid-cols-[auto_auto_auto_auto_1fr_auto] divide-y divide-border">
                {pageItems.map((l) => (
                  <li
                    key={l.id}
                    className="col-span-full grid grid-cols-subgrid items-center gap-2 px-6 py-3"
                  >
                    <span className="flex items-center gap-2 min-w-0 pr-6">
                      <span
                        className={cn(
                          "inline-block h-2 w-2 rounded-full shrink-0",
                          STATUS_CLASS[platformStatus(l)],
                        )}
                        aria-hidden
                      />
                      <span className="text-body-3 text-foreground truncate">{l.name}</span>
                    </span>
                    <Badge
                      variant="outline"
                      className="text-body-3 w-full justify-center gap-1 font-medium bg-[#D9F5FD] text-[#0672CB] border-[#5CC1EE]"
                    >
                      {l.lob}
                    </Badge>
                    <Badge
                      variant="outline"
                      className="text-body-3 w-full justify-center gap-1 font-medium bg-[#D9F5FD] text-[#0672CB] border-[#5CC1EE]"
                    >
                      {l.phase}
                    </Badge>
                    <Badge
                      variant="outline"
                      className="text-body-3 w-full justify-center gap-1 font-medium bg-[#D9F5FD] text-[#0672CB] border-[#5CC1EE]"
                    >
                      RTS {l.launchDate}
                    </Badge>
                    <div />
                    <Button
                      size="sm"
                      variant="outline"
                      className="h-8 py-1 !text-body-3 font-medium justify-self-end bg-transparent border-[#0672CB] text-[#0672CB] hover:bg-[#0672CB]/10 hover:text-[#0672CB]"
                      onClick={() => setTarget(launchToPending(l))}
                    >
                      View
                    </Button>
                  </li>
                ))}
              </ul>
              <div className="border-t border-border px-6 py-3">
                <DdsPagination
                  page={page}
                  pageSize={pageSize}
                  totalItems={sorted.length}
                  itemLabel="platforms"
                  onPageChange={setPage}
                  onPageSizeChange={setPageSize}
                />
              </div>
            </>
          )}
        </CardContent>
      </Card>

      <PlatformReviewDrawer
        request={target}
        open={!!target}
        onOpenChange={(o) => {
          if (!o) setTarget(null);
        }}
      />
    </>
  );
}
