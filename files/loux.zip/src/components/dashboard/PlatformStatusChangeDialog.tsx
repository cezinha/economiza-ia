import { useMemo } from "react";
import { useNavigate } from "react-router-dom";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { ArrowRight } from "lucide-react";
import { cn } from "@/lib/utils";
import { launches } from "@/mocks/launches";
import { getPlatformStatusEventDetail } from "@/mocks/platformStatusEvents";
import type { TaskStatus } from "@/lib/launchTasks";

interface Props {
  eventId: string | null;
  onClose: () => void;
}

const STATUS_LABEL: Record<TaskStatus, string> = {
  "on-track": "On track",
  "at-risk": "At risk",
  "at-risk-mitigated": "At risk (mitigated)",
  completed: "Completed",
  "not-started": "Not started",
};

const STATUS_PILL: Record<TaskStatus, string> = {
  "on-track": "bg-success/10 text-success",
  "at-risk": "bg-destructive/10 text-destructive",
  "at-risk-mitigated": "bg-warning/10 text-warning",
  completed: "bg-muted text-muted-foreground",
  "not-started": "bg-muted text-muted-foreground",
};

function formatDateTime(ts: number | undefined): string {
  if (!ts) return "—";
  return new Date(ts).toLocaleString("en-GB", {
    day: "2-digit", month: "short", year: "numeric", hour: "2-digit", minute: "2-digit",
  });
}

function StatusPill({ status }: { status: TaskStatus }) {
  return (
    <span className={cn("inline-flex items-center rounded-full px-2 h-6 text-caption font-medium", STATUS_PILL[status])}>
      {STATUS_LABEL[status]}
    </span>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <p className="text-caption font-medium uppercase tracking-wide text-muted-foreground">{label}</p>
      <p className="mt-1 text-body-3 text-foreground whitespace-pre-wrap break-words">{children}</p>
    </div>
  );
}

export function PlatformStatusChangeDialog({ eventId, onClose }: Props) {
  const navigate = useNavigate();
  const detail = useMemo(() => (eventId ? getPlatformStatusEventDetail(eventId) : null), [eventId]);
  const open = !!eventId;

  if (!detail) {
    return (
      <Dialog open={open} onOpenChange={(v) => { if (!v) onClose(); }}>
        <DialogContent className="max-w-lg bg-card shadow-elev-3">
          <DialogHeader>
            <DialogTitle className="text-h5">Status change</DialogTitle>
          </DialogHeader>
          <p className="text-body-3 text-muted-foreground">This notification is no longer available.</p>
        </DialogContent>
      </Dialog>
    );
  }

  const { event, request } = detail;
  const launch = launches.find((l) => l.id === event.launchId);
  const openPlatform = () => {
    onClose();
    if (launch) navigate(`/tasks?tab=platform&launch=${encodeURIComponent(launch.id)}`);
  };


  return (
    <Dialog open={open} onOpenChange={(v) => { if (!v) onClose(); }}>
      <DialogContent className="max-w-2xl bg-card shadow-elev-3">
        <DialogHeader>
          <DialogTitle className="text-h5">Platform status change</DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          <div>
            <p className="text-body-3 text-muted-foreground">Platform</p>
            <p className="text-h6 text-foreground">{event.launchName}</p>
            <div className="mt-2 flex items-center gap-2">
              <StatusPill status={event.fromStatus} />
              <ArrowRight className="h-4 w-4 text-muted-foreground" />
              <StatusPill status={event.toStatus} />
              <span className="ml-auto text-caption text-muted-foreground">{formatDateTime(event.ts)}</span>
            </div>
          </div>

          {request ? (
            <>
              <div className="rounded-md border border-border bg-muted/30 p-4 space-y-3">
                <p className="text-caption font-medium uppercase tracking-wide text-muted-foreground">
                  Triggering task
                </p>
                <p className="text-body-2 text-foreground">{request.taskName}</p>
              </div>

              <div className="rounded-md border border-border p-4 space-y-3">
                <p className="text-subtitle-2 text-foreground">
                  {request.directOverride ? "Direct override" : "Requested change"}
                </p>
                <div className="grid grid-cols-1 m:grid-cols-2 gap-3">
                  <Field label="Requested by">{request.requestedBy}</Field>
                  <Field label="Requested at">{formatDateTime(request.requestedAt)}</Field>
                  <Field label="Owner">{request.owner || "—"}</Field>
                  <Field label="Action due">{request.dueDate || "—"}</Field>
                </div>
                <Field label="Root cause">{request.issueDescription || "—"}</Field>
                {!request.directOverride && (
                  <>
                    <Field label="Business impact">{request.businessImpact || "—"}</Field>
                    <Field label="Action required / mitigation">{request.mitigationPlan || "—"}</Field>
                  </>
                )}
              </div>

              {request.reviewedBy && (
                <div className="rounded-md border border-border p-4 space-y-3">
                  <p className="text-subtitle-2 text-foreground">
                    {request.directOverride ? "Override author" : "Approver"}
                  </p>
                  <div className="grid grid-cols-1 m:grid-cols-2 gap-3">
                    <Field label={request.directOverride ? "Applied by" : "Approved by"}>{request.reviewedBy}</Field>
                    <Field label={request.directOverride ? "Applied at" : "Approved at"}>{formatDateTime(request.reviewedAt)}</Field>
                  </div>
                  {request.reviewerNote && <Field label="Note">{request.reviewerNote}</Field>}
                </div>
              )}
            </>
          ) : (
            <p className="text-body-3 text-muted-foreground">Underlying request details are no longer available.</p>
          )}
        </div>

        <div className="mt-2 flex justify-end gap-2">
          <Button variant="outline" onClick={onClose}>Close</Button>
          {launch && (
            <Button onClick={openPlatform}>Open platform</Button>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
