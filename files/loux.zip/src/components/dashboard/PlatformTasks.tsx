import { useMemo, useState } from "react";
import { Check, ChevronsUpDown, ChevronLeft, ChevronRight, ChevronsLeft, ChevronsRight, Filter, Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
} from "@/components/ui/command";
import { useFilteredLaunches } from "@/lib/applyFilters";
import { launches as ALL_LAUNCHES } from "@/mocks/launches";
import { useFilters } from "@/contexts/FilterContext";
import { useAssignedPlatformIds } from "@/lib/permissions";
import { platformStatus, type TaskStatus } from "@/lib/launchTasks";
import { LaunchTasksPanel } from "@/components/dashboard/LaunchTasksPanel";
import { cn } from "@/lib/utils";


const STATUS_CLASS: Record<TaskStatus, string> = {
  completed: "bg-status-completed",
  "on-track": "bg-status-on-track",
  "at-risk-mitigated": "bg-status-at-risk-mitigated",
  "at-risk": "bg-status-at-risk",
  "not-started": "bg-status-not-started",
};

interface PlatformTasksProps {
  launchId?: string;
  onChange: (launchId: string) => void;
  initialInnerTab?: "report" | "tasks" | "exit";
  initialPhase?: string;
  initialGate?: string;
}

export function PlatformTasks({ launchId, onChange, initialInnerTab, initialPhase, initialGate }: PlatformTasksProps) {
  const [open, setOpen] = useState(false);
  const filtered = useFilteredLaunches();
  const { filters, setFilter, open: openFiltersDrawer } = useFilters();
  const assignedIds = useAssignedPlatformIds();
  

  // Scope = the user's global filter set, sorted by health then RTS.
  const scoped = useMemo(
    () =>
      [...filtered].sort((a, b) => {
        const rank = (s: TaskStatus) =>
          s === "at-risk" ? 0 : s === "at-risk-mitigated" ? 1 : 2;
        const r = rank(platformStatus(a)) - rank(platformStatus(b));
        if (r !== 0) return r;
        return a.launchDate.localeCompare(b.launchDate);
      }),
    [filtered],
  );

  // Deep-linked launch may sit outside the scoped set; resolve it separately.
  const deepLinked = useMemo(
    () => (launchId ? ALL_LAUNCHES.find((l) => l.id === launchId) : undefined),
    [launchId],
  );
  const selected = deepLinked ?? scoped[0];
  const inScope = !!selected && scoped.some((l) => l.id === selected.id);
  const focusIndex = selected ? scoped.findIndex((l) => l.id === selected.id) : -1;

  const goPrev = () => {
    if (focusIndex <= 0) return;
    onChange(scoped[focusIndex - 1].id);
  };
  const goNext = () => {
    if (focusIndex < 0 || focusIndex >= scoped.length - 1) return;
    onChange(scoped[focusIndex + 1].id);
  };
  const goFirst = () => {
    if (scoped.length === 0 || focusIndex <= 0) return;
    onChange(scoped[0].id);
  };
  const goLast = () => {
    if (scoped.length === 0 || focusIndex >= scoped.length - 1) return;
    onChange(scoped[scoped.length - 1].id);
  };

  const addDeepLinkedToFilter = () => {
    if (!selected) return;
    const current = Array.isArray(filters.platform) ? (filters.platform as string[]) : [];
    if (!current.includes(selected.name)) {
      setFilter("platform", [...current, selected.name]);
    }
  };

  // Empty scope and nothing deep-linked → nudge to the filters drawer.
  if (!selected) {
    return (
      <div className="rounded-md border border-border bg-surface p-6 space-y-3">
        <p className="text-body-2 text-foreground">No platforms in your current filter.</p>
        <p className="text-caption text-muted-foreground">
          Your global filter resolves to zero platforms. Open Filters to expand the scope.
        </p>
        <Button variant="outline" size="sm" className="gap-2" onClick={openFiltersDrawer}>
          <Filter className="h-4 w-4" />
          Open Filters
        </Button>
      </div>
    );
  }




  const isViewOnly = (id: string) =>
    !!assignedIds && !assignedIds.has(id);

  const renderRow = (l: typeof selected) => (
    <span className="flex items-center gap-2 min-w-0">
      <span
        className={cn(
          "inline-block h-2 w-2 rounded-full shrink-0",
          STATUS_CLASS[platformStatus(l)],
        )}
        aria-hidden
      />
      <span className="truncate">{l.name}</span>
      <span className="text-caption text-muted-foreground truncate">
        · {l.lob} · RTS {l.launchDate}
      </span>
      {isViewOnly(l.id) && (
        <Badge variant="outline" className="text-caption font-normal ml-1">
          View only
        </Badge>
      )}
    </span>
  );

  const totalInScope = scoped.length;
  const positionLabel = inScope && focusIndex >= 0
    ? `${focusIndex + 1} of ${totalInScope} in your filter`
    : `Outside your filter · ${totalInScope} platform${totalInScope === 1 ? "" : "s"} in scope`;

  return (
    <div className="space-y-6">
      {/* Focus bar — scoped to the masthead's global Filters */}
      <div className="rounded-md border border-border bg-surface p-4 space-y-2">
        <div className="flex items-center gap-2 flex-wrap">
          <span className="text-caption text-muted-foreground">Focused platform</span>

          <div className="flex items-center gap-1">
            <Button
              variant="outline"
              size="icon"
              className="h-9 w-9"
              onClick={goFirst}
              disabled={!inScope || focusIndex <= 0}
              aria-label="First platform"
            >
              <ChevronsLeft className="h-4 w-4" />
            </Button>
            <Button
              variant="outline"
              size="icon"
              className="h-9 w-9"
              onClick={goPrev}
              disabled={!inScope || focusIndex <= 0}
              aria-label="Previous platform"
            >
              <ChevronLeft className="h-4 w-4" />
            </Button>

            <Popover open={open} onOpenChange={setOpen}>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  role="combobox"
                  aria-expanded={open}
                  className="w-[360px] max-w-full justify-between font-normal"
                  disabled={scoped.length === 0}
                >
                  {renderRow(selected)}
                  <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                </Button>
              </PopoverTrigger>
              <PopoverContent
                className="p-0 shadow-elev-2"
                style={{ width: "var(--radix-popover-trigger-width)" }}
                align="start"
                side="bottom"
                sideOffset={4}
                avoidCollisions={false}
              >
                <Command>
                  <CommandInput placeholder="Search platforms in your filter…" />
                  <CommandList>
                    <CommandEmpty>No platforms match.</CommandEmpty>
                    <CommandGroup>
                      {scoped.map((l) => (
                        <CommandItem
                          key={l.id}
                          value={l.name}
                          onSelect={() => {
                            onChange(l.id);
                            setOpen(false);
                          }}
                        >
                          <Check
                            className={cn(
                              "mr-2 h-4 w-4 shrink-0",
                              l.id === selected.id ? "opacity-100" : "opacity-0",
                            )}
                          />
                          {renderRow(l)}
                        </CommandItem>
                      ))}
                    </CommandGroup>
                  </CommandList>
                </Command>
              </PopoverContent>
            </Popover>

            <Button
              variant="outline"
              size="icon"
              className="h-9 w-9"
              onClick={goNext}
              disabled={!inScope || focusIndex < 0 || focusIndex >= scoped.length - 1}
              aria-label="Next platform"
            >
              <ChevronRight className="h-4 w-4" />
            </Button>
            <Button
              variant="outline"
              size="icon"
              className="h-9 w-9"
              onClick={goLast}
              disabled={!inScope || focusIndex < 0 || focusIndex >= scoped.length - 1}
              aria-label="Last platform"
            >
              <ChevronsRight className="h-4 w-4" />
            </Button>
          </div>

          {!inScope && (
            <Badge variant="outline" className="text-caption font-normal">
              Outside filter
            </Badge>
          )}

        </div>

        <div className="flex items-center gap-3 flex-wrap">
          <span className="text-caption text-muted-foreground">{positionLabel}</span>
          {!inScope && (
            <Button
              variant="ghost"
              size="sm"
              className="h-7 gap-1 px-2 text-caption"
              onClick={addDeepLinkedToFilter}
            >
              <Plus className="h-3 w-3" />
              Add to filter
            </Button>
          )}
        </div>
      </div>

      <LaunchTasksPanel launch={selected} initialTab={initialInnerTab} initialPhase={initialPhase} initialGate={initialGate} />
    </div>
  );
}
