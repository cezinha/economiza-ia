// Horizontal variance bar chart per track — POR vs actual phase slip in days.
import {
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  ReferenceLine,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import type { Launch } from "@/mocks/launches";
import type { ScheduleTrack } from "@/lib/schedule";
import { getPhaseVariance, classifyDelta } from "@/lib/porVariance";
import { DdsGrid, DdsCol } from "@/components/layout/DdsGrid";

const TRACKS: { id: ScheduleTrack; label: string }[] = [
  { id: "Core", label: "Core team" },
  { id: "GOE", label: "GOE" },
  { id: "NPI", label: "NPI" },
  { id: "SChM", label: "SChM" },
];

// Resolve CSS HSL token to a real color string consumable by Recharts.
function tokenColor(varName: string): string {
  if (typeof window === "undefined") return "#999";
  const v = getComputedStyle(document.documentElement).getPropertyValue(varName).trim();
  return v ? `hsl(${v})` : "#999";
}

function colorFor(delta: number): string {
  const status = classifyDelta(delta);
  switch (status) {
    case "slip-major":
      return tokenColor("--status-at-risk");
    case "slip-minor":
      return tokenColor("--status-at-risk-mitigated");
    case "pull-in":
      return tokenColor("--status-completed");
    case "on-plan":
    default:
      return tokenColor("--status-on-track");
  }
}

function TrackVarianceChart({ launch, track, label }: { launch: Launch; track: ScheduleTrack; label: string }) {
  const variance = getPhaseVariance(launch, track).filter((v) => v.deltaDays !== undefined);
  if (variance.length === 0) {
    return (
      <div className="rounded-md border border-border bg-surface p-4">
        <div className="text-subtitle-2 text-foreground mb-2">{label}</div>
        <p className="text-caption text-muted-foreground">No closed phases yet — variance will appear once a phase exits.</p>
      </div>
    );
  }
  const data = variance.map((v) => ({ phase: v.phase, delta: v.deltaDays! }));
  const maxAbs = Math.max(7, ...data.map((d) => Math.abs(d.delta)));
  return (
    <div className="rounded-md border border-border bg-surface p-4">
      <div className="text-subtitle-2 text-foreground mb-2">{label}</div>
      <div className="h-40">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={data} layout="vertical" margin={{ top: 4, right: 16, bottom: 4, left: 8 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
            <XAxis
              type="number"
              domain={[-maxAbs, maxAbs]}
              tick={{ fontSize: 11, fill: "hsl(var(--muted-foreground))" }}
              tickFormatter={(v) => `${v}d`}
            />
            <YAxis
              type="category"
              dataKey="phase"
              width={70}
              tick={{ fontSize: 11, fill: "hsl(var(--muted-foreground))" }}
            />
            <ReferenceLine x={0} stroke="hsl(var(--foreground))" strokeWidth={1} />
            <Tooltip
              cursor={{ fill: "hsl(var(--muted) / 0.4)" }}
              contentStyle={{
                background: "hsl(var(--surface))",
                border: "1px solid hsl(var(--border))",
                fontSize: 12,
              }}
              formatter={(value: number) => [`${value > 0 ? "+" : ""}${value}d`, "Δ vs POR"]}
            />
            <Bar dataKey="delta" radius={[2, 2, 2, 2]}>
              {data.map((d, i) => (
                <Cell key={i} fill={colorFor(d.delta)} />
              ))}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}

export function PorVarianceChart({ launch }: { launch: Launch }) {
  return (
    <DdsGrid>
      {TRACKS.map((t) => (
        <DdsCol key={t.id} span={12} spanM={3} spanS={3} spanXs={2}>
          <TrackVarianceChart launch={launch} track={t.id} label={t.label} />
        </DdsCol>
      ))}
    </DdsGrid>
  );
}
