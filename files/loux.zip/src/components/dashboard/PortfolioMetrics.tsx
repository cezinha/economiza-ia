import { useNavigate } from "react-router-dom";
import { KpiCard } from "@/components/dashboard/KpiCard";
import { DdsGrid, DdsCol } from "@/components/layout/DdsGrid";
import { NuddUpcomingMetric } from "@/components/dashboard/NuddUpcomingMetric";
import { useFilteredLaunches, type StatusBucket } from "@/lib/applyFilters";
import { useFilters } from "@/contexts/FilterContext";
import { useRole } from "@/contexts/RoleContext";
import {
  platformStatus,
  taskStatus,
  tasksForLaunch,
  isAutoTask,
  estimatedTaskEndDate,
  type TaskStatus,
} from "@/lib/launchTasks";
import type { ScheduleTrack } from "@/lib/schedule";

const TRACKS: ScheduleTrack[] = ["GOE", "NPI", "SChM"];

function pct(n: number, total: number) {
  if (total === 0) return "0%";
  return `${Math.round((n / total) * 100)}%`;
}

/**
 * 7-card portfolio overview, designed to sit in a half-width column next to
 * the Current phase status donut. 2-up at L/M, 1-up at XS.
 */
export function PortfolioMetrics() {
  const launches = useFilteredLaunches();
  const { filters, setManyFilters } = useFilters();
  const { role } = useRole();
  const navigate = useNavigate();
  const drillToStatus = (bucket: StatusBucket) => {
    setManyFilters({ status: [bucket] });
    navigate("/launches");
  };
  const isExecutive = role === "executive";
  const colSpan = isExecutive ? 12 : 6;
  const fnFilter = Array.isArray(filters.function) ? (filters.function as string[]) : [];
  const activeTracks: ScheduleTrack[] = TRACKS.filter(
    (t) => fnFilter.length === 0 || fnFilter.includes(t),
  );

  const now = new Date();
  const today = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate()));
  const horizon = new Date(today.getTime() + 30 * 24 * 60 * 60 * 1000);

  let overdueTasks = 0;
  let upcomingTasks = 0;
  for (const l of launches) {
    const lt = tasksForLaunch(l);
    for (const t of lt) {
      if (isAutoTask(t)) continue;
      for (const track of activeTracks) {
        if (!t.teams.includes(track as never)) continue;
        const s: TaskStatus = taskStatus(l, t, track);
        if (s === "completed" || s === "not-started") continue;
        const end = estimatedTaskEndDate(l, t);
        if (!end) continue;
        if (end.getTime() < today.getTime()) overdueTasks += 1;
        else if (end.getTime() <= horizon.getTime()) upcomingTasks += 1;
      }
    }
  }
  const activeTaskTotal = overdueTasks + upcomingTasks;

  const totalPlatforms = launches.length;
  const platformsOnTrack = launches.filter((l) => platformStatus(l) === "on-track").length;
  const platformsMitigated = launches.filter((l) => platformStatus(l) === "at-risk-mitigated").length;
  const platformsMissed = launches.filter((l) => platformStatus(l) === "at-risk").length;

  return (
    <DdsGrid className="h-full [grid-auto-rows:1fr]">
      {!isExecutive && (
        <DdsCol span={6} spanM={6} spanS={6} spanXs={2}>
          <KpiCard
            label="Overdue tasks"
            value={overdueTasks}
            subtitle={`of ${activeTaskTotal} active`}
            pill={overdueTasks > 0 ? { label: "Action required", tone: "warning" } : undefined}
          />
        </DdsCol>
      )}
      {!isExecutive && (
        <DdsCol span={6} spanM={6} spanS={6} spanXs={2}>
          <KpiCard
            label="Upcoming tasks"
            value={upcomingTasks}
            subtitle="Due in the next 30 days"
            pill={upcomingTasks > 0 ? { label: "Action required", tone: "warning" } : undefined}
          />
        </DdsCol>
      )}
      <DdsCol span={colSpan} spanM={6} spanS={6} spanXs={2}>
        <KpiCard
          label="Platforms on track"
          value={platformsOnTrack}
          subtitle={`${pct(platformsOnTrack, totalPlatforms)} of platforms`}
          pill={platformsOnTrack > 0 ? { label: "Status", tone: "status-success" } : undefined}
          onClick={() => drillToStatus("achieved")}
        />
      </DdsCol>
      <DdsCol span={colSpan} spanM={6} spanS={6} spanXs={2}>
        <KpiCard
          label="Platforms at risk (with mitigation)"
          value={platformsMitigated}
          subtitle={`${pct(platformsMitigated, totalPlatforms)} of platforms`}
          pill={platformsMitigated > 0 ? { label: "Status", tone: "status-warning" } : undefined}
          onClick={() => drillToStatus("risk-mitigated")}
        />
      </DdsCol>
      <DdsCol span={colSpan} spanM={6} spanS={6} spanXs={2}>
        <KpiCard
          label="Platforms at risk (no mitigation)"
          value={platformsMissed}
          subtitle={`${pct(platformsMissed, totalPlatforms)} of platforms`}
          pill={platformsMissed > 0 ? { label: "Status", tone: "status-danger" } : undefined}
          onClick={() => drillToStatus("missed")}
        />
      </DdsCol>
      <DdsCol span={colSpan} spanM={6} spanS={6} spanXs={2}>
        <NuddUpcomingMetric />
      </DdsCol>
    </DdsGrid>
  );
}
