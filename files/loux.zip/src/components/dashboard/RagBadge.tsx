import { cn } from "@/lib/utils";
import { RAG } from "@/mocks/launches";

const map: Record<RAG, { label: string; cls: string }> = {
  green: { label: "On track", cls: "bg-success/10 text-success ring-success/20" },
  amber: { label: "At risk", cls: "bg-warning/15 text-warning-foreground ring-warning/30" },
  red: { label: "Blocked", cls: "bg-danger/10 text-danger ring-danger/20" },
};

export function RagBadge({ rag, className }: { rag: RAG; className?: string }) {
  const m = map[rag];
  return (
    <span className={cn("inline-flex items-center gap-2 rounded-sm px-2 py-1 text-caption font-medium ring-1 ring-inset", m.cls, className)}>
      <span className={cn("h-2 w-2 rounded-full", rag === "green" ? "bg-success" : rag === "amber" ? "bg-warning" : "bg-danger")} />
      {m.label}
    </span>
  );
}
