// Completion request form. Users file this from TaskDetailDrawer; managers
// approve via StatusChangeRequestsDrawer.

import { useState } from "react";
import { toast } from "sonner";
import { z } from "zod";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import type { Launch } from "@/mocks/launches";
import type { LaunchTask } from "@/lib/launchTasks";
import { createCompletionRequest } from "@/mocks/completionRequests";
import { useCurrentUserName } from "@/lib/currentUser";

const schema = z.object({
  completionNote: z.string().trim().min(5, "Add a short note").max(1000),
  evidenceLink: z.string().trim().max(500).optional().or(z.literal("")),
  owner: z.string().trim().min(2, "Owner is required").max(120),
});

export function RequestCompletionDialog({
  launch,
  task,
  open,
  onOpenChange,
}: {
  launch: Launch;
  task: LaunchTask | null;
  open: boolean;
  onOpenChange: (o: boolean) => void;
}) {
  const requestedBy = useCurrentUserName();
  const [completionNote, setCompletionNote] = useState("");
  const [evidenceLink, setEvidenceLink] = useState("");
  const [owner, setOwner] = useState(requestedBy);
  const [errors, setErrors] = useState<Record<string, string>>({});

  const reset = () => {
    setCompletionNote("");
    setEvidenceLink("");
    setOwner(requestedBy);
    setErrors({});
  };

  const onSubmit = () => {
    if (!task) return;
    const parse = schema.safeParse({ completionNote, evidenceLink, owner });
    if (!parse.success) {
      const next: Record<string, string> = {};
      for (const issue of parse.error.issues) {
        next[String(issue.path[0])] = issue.message;
      }
      setErrors(next);
      return;
    }
    createCompletionRequest({
      launchId: launch.id,
      taskId: task.id,
      taskName: task.task,
      completionNote,
      evidenceLink: evidenceLink || undefined,
      owner,
      requestedBy,
    });
    toast.success("Completion request submitted for manager approval.");
    reset();
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={(o) => { if (!o) reset(); onOpenChange(o); }}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle>Mark task as complete</DialogTitle>
          <DialogDescription>
            “{task?.task}” on {launch.name}. A manager will review before the task is marked complete.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="note">Completion note</Label>
            <Textarea
              id="note"
              value={completionNote}
              onChange={(e) => setCompletionNote(e.target.value)}
              placeholder="What was delivered?"
              maxLength={1000}
            />
            {errors.completionNote && (
              <p className="text-caption text-danger">{errors.completionNote}</p>
            )}
          </div>
          <div className="space-y-2">
            <Label htmlFor="evidence">Evidence link (optional)</Label>
            <Input
              id="evidence"
              value={evidenceLink}
              onChange={(e) => setEvidenceLink(e.target.value)}
              placeholder="Link to artifact / approval"
              maxLength={500}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="cr-owner">Owner</Label>
            <Input
              id="cr-owner"
              value={owner}
              onChange={(e) => setOwner(e.target.value)}
              maxLength={120}
            />
            {errors.owner && <p className="text-caption text-danger">{errors.owner}</p>}
          </div>
        </div>

        <DialogFooter>
          <Button variant="ghost" onClick={() => onOpenChange(false)}>Cancel</Button>
          <Button onClick={onSubmit}>Submit request</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
