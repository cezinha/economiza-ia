import { useState } from "react";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Plus } from "lucide-react";
import { RequestPlatformDrawer } from "./RequestPlatformDrawer";

export function RequestPlatformCard() {
  const [open, setOpen] = useState(false);
  return (
    <>
      <Card className="border-border bg-surface shadow-elev-1">
        <CardHeader className="pb-2">
          <h5 className="text-h5 text-foreground">Add new platform</h5>
        </CardHeader>
        <CardContent className="flex items-center justify-between gap-4">
          <p className="text-body-3 text-muted-foreground">
            Submit a new platform for your manager's approval
          </p>
          <Button onClick={() => setOpen(true)}>
            <Plus className="h-4 w-4 mr-2" />
            Submit request
          </Button>
        </CardContent>
      </Card>
      <RequestPlatformDrawer open={open} onOpenChange={setOpen} />
    </>
  );
}
