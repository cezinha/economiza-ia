import { useState } from "react";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetDescription } from "@/components/ui/sheet";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { submitUserPlatformRequest, type BusinessUnit } from "@/mocks/pendingPlatforms";
import type { LOB, Launch } from "@/mocks/launches";
import { toast } from "sonner";

interface Props {
  open: boolean;
  onOpenChange: (o: boolean) => void;
}

const EMPTY = {
  name: "",
  product: "",
  businessUnit: "" as BusinessUnit | "",
  lob: "" as LOB | "",
  region: "" as Launch["region"] | "",
  proposedOwner: "",
  proposedLaunchDate: "",
  rationale: "",
};

export function RequestPlatformDrawer({ open, onOpenChange }: Props) {
  const [form, setForm] = useState(EMPTY);

  const set = <K extends keyof typeof EMPTY>(k: K, v: (typeof EMPTY)[K]) =>
    setForm((f) => ({ ...f, [k]: v }));

  const reset = () => setForm(EMPTY);

  const canSubmit =
    form.name.trim().length > 0 &&
    form.businessUnit &&
    form.lob &&
    form.region &&
    form.proposedLaunchDate;

  const handleCancel = () => {
    reset();
    onOpenChange(false);
  };

  const handleSubmit = () => {
    if (!canSubmit) return;
    submitUserPlatformRequest({
      name: form.name.trim().slice(0, 120),
      product: form.product.trim().slice(0, 120),
      businessUnit: form.businessUnit as BusinessUnit,
      lob: form.lob as LOB,
      region: form.region as Launch["region"],
      proposedOwner: form.proposedOwner.trim().slice(0, 80),
      proposedLaunchDate: form.proposedLaunchDate,
      rationale: form.rationale.trim().slice(0, 1000) || undefined,
    });
    toast.success("Request submitted for approval", {
      description: "Your manager has been notified.",
    });
    reset();
    onOpenChange(false);
  };

  return (
    <Sheet open={open} onOpenChange={(o) => { if (!o) reset(); onOpenChange(o); }}>
      <SheetContent side="right" className="w-full sm:max-w-xl flex flex-col">
        <SheetHeader>
          <SheetTitle>Request new platform</SheetTitle>
          <SheetDescription>
            Fill in the details below. Your manager will review and approve.
          </SheetDescription>
        </SheetHeader>

        <div className="flex-1 overflow-y-auto py-4 space-y-4">
          <div className="space-y-2">
            <Label htmlFor="rp-name">Platform name</Label>
            <Input
              id="rp-name"
              placeholder="e.g. Helios EVO 16 OLED"
              maxLength={120}
              value={form.name}
              onChange={(e) => set("name", e.target.value)}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="rp-product">Product code</Label>
            <Input
              id="rp-product"
              placeholder="e.g. HEL-EVO-16"
              maxLength={120}
              value={form.product}
              onChange={(e) => set("product", e.target.value)}
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-2">
              <Label>Business unit</Label>
              <Select value={form.businessUnit} onValueChange={(v) => set("businessUnit", v as BusinessUnit)}>
                <SelectTrigger><SelectValue placeholder="Select" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="CSG">CSG</SelectItem>
                  <SelectItem value="ISG">ISG</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Line of business</Label>
              <Select value={form.lob} onValueChange={(v) => set("lob", v as LOB)}>
                <SelectTrigger><SelectValue placeholder="Select" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="NB">NB</SelectItem>
                  <SelectItem value="DT">DT</SelectItem>
                  <SelectItem value="DnCP">DnCP</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-2">
              <Label>Region</Label>
              <Select value={form.region} onValueChange={(v) => set("region", v as Launch["region"])}>
                <SelectTrigger><SelectValue placeholder="Select" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="NA">NA</SelectItem>
                  <SelectItem value="EMEA">EMEA</SelectItem>
                  <SelectItem value="APJ">APJ</SelectItem>
                  <SelectItem value="LATAM">LATAM</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="rp-date">Proposed launch date</Label>
              <Input
                id="rp-date"
                type="date"
                value={form.proposedLaunchDate}
                onChange={(e) => set("proposedLaunchDate", e.target.value)}
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="rp-owner">Proposed owner</Label>
            <Input
              id="rp-owner"
              placeholder="e.g. Priya Shah"
              maxLength={80}
              value={form.proposedOwner}
              onChange={(e) => set("proposedOwner", e.target.value)}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="rp-notes">Rationale / notes</Label>
            <Textarea
              id="rp-notes"
              placeholder="Why this platform? Any context for your manager."
              rows={4}
              maxLength={1000}
              value={form.rationale}
              onChange={(e) => set("rationale", e.target.value)}
            />
          </div>
        </div>

        <div className="flex items-center justify-end gap-2 pt-4 border-t border-border">
          <Button variant="outline" onClick={handleCancel}>Cancel request</Button>
          <Button onClick={handleSubmit} disabled={!canSubmit}>Submit for approval</Button>
        </div>
      </SheetContent>
    </Sheet>
  );
}
