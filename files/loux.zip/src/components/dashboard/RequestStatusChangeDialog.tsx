// Status-change request form. Users file this from TaskDetailDrawer; managers
// (Admin/Superadmin) approve via StatusChangeRequestsDrawer.

import { useState } from "react";
import { toast } from "sonner";
import { z } from "zod";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import type { Launch } from "@/mocks/launches";
import type { LaunchTask, TaskStatus } from "@/lib/launchTasks";
import {
  createStatusChangeRequest,
  directOverrideStatus,
  type StatusChangeTarget,
} from "@/mocks/statusChangeRequests";
import { useCurrentUserName } from "@/lib/currentUser";
import { useRole } from "@/contexts/RoleContext";
import { canOverrideStatus } from "@/lib/permissions";

const schema = z.object({
  toStatus: z.enum(["at-risk", "at-risk-mitigated", "on-track"]),
  issueDescription: z.string().trim().min(10, "Add at least 10 characters").max(1000),
  businessImpact: z.string().trim().min(5, "Add a short impact note").max(1000),
  mitigationPlan: z.string().trim().min(5, "Add an action required").max(1000),
  owner: z.string().trim().min(2, "Owner is required").max(120),
  dueDate: z.string().min(1, "Due date is required"),
});

function defaultDue(): string {
  const d = new Date();
  d.setDate(d.getDate() + 7);
  return d.toISOString().slice(0, 10);
}

export function RequestStatusChangeDialog({
  launch,
  task,
  currentStatus,
  open,
  onOpenChange,
}: {
  launch: Launch;
  task: LaunchTask | null;
  currentStatus: TaskStatus;
  open: boolean;
  onOpenChange: (o: boolean) => void;
}) {
  const requestedBy = useCurrentUserName();
  const { role } = useRole();
  const canOverride = canOverrideStatus(role);

  const [toStatus, setToStatus] = useState<StatusChangeTarget>(
    currentStatus === "at-risk" || currentStatus === "at-risk-mitigated" ? "on-track" : "at-risk-mitigated",
  );
  const [issueDescription, setIssueDescription] = useState("");
  const [businessImpact, setBusinessImpact] = useState("");
  const [mitigationPlan, setMitigationPlan] = useState("");
  const [owner, setOwner] = useState(requestedBy);
  const [dueDate, setDueDate] = useState(defaultDue());
  const [errors, setErrors] = useState<Record<string, string>>({});

  const reset = () => {
    setIssueDescription("");
    setBusinessImpact("");
    setMitigationPlan("");
    setOwner(requestedBy);
    setDueDate(defaultDue());
    setErrors({});
  };

  const handleSubmit = (mode: "request" | "override") => {
    if (!task) return;
    const parse = schema.safeParse({
      toStatus,
      issueDescription,
      businessImpact,
      mitigationPlan,
      owner,
      dueDate,
    });
    if (!parse.success) {
      const next: Record<string, string> = {};
      for (const issue of parse.error.issues) {
        next[String(issue.path[0])] = issue.message;
      }
      setErrors(next);
      return;
    }
    if (mode === "override") {
      directOverrideStatus({
        launchId: launch.id,
        taskId: task.id,
        taskName: task.task,
        fromStatus: currentStatus,
        toStatus,
        by: requestedBy,
        note: `${issueDescription} — ${mitigationPlan}`,
        dueDate,
      });
      toast.success("Status updated (manager override).");
    } else {
      createStatusChangeRequest({
        launchId: launch.id,
        taskId: task.id,
        taskName: task.task,
        fromStatus: currentStatus,
        toStatus,
        issueDescription,
        businessImpact,
        mitigationPlan,
        owner,
        dueDate,
        requestedBy,
      });
      toast.success("Status change submitted for manager approval.");
    }
    reset();
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={(o) => { if (!o) reset(); onOpenChange(o); }}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle>Request status change</DialogTitle>
          <DialogDescription>
            “{task?.task}” on {launch.name}. A manager will review before the status changes.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          <div className="space-y-2">
            <Label>New status</Label>
            <Select value={toStatus} onValueChange={(v) => setToStatus(v as StatusChangeTarget)}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="at-risk">At risk (red)</SelectItem>
                <SelectItem value="at-risk-mitigated">At risk – mitigated (yellow)</SelectItem>
                <SelectItem value="on-track">On track (green)</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="issue">Root cause</Label>
            <Textarea
              id="issue"
              value={issueDescription}
              onChange={(e) => setIssueDescription(e.target.value)}
              placeholder="What is driving this status change?"
              maxLength={1000}
            />
            {errors.issueDescription && (
              <p className="text-caption text-danger">{errors.issueDescription}</p>
            )}
          </div>

          <div className="space-y-2">
            <Label htmlFor="impact">Business impact</Label>
            <Textarea
              id="impact"
              value={businessImpact}
              onChange={(e) => setBusinessImpact(e.target.value)}
              placeholder="Schedule, revenue, customer commitments, etc."
              maxLength={1000}
            />
            {errors.businessImpact && (
              <p className="text-caption text-danger">{errors.businessImpact}</p>
            )}
          </div>

          <div className="space-y-2">
            <Label htmlFor="mitigation">
              {toStatus === "on-track" ? "Resolution summary" : "Action required"}
            </Label>
            <Textarea
              id="mitigation"
              value={mitigationPlan}
              onChange={(e) => setMitigationPlan(e.target.value)}
              placeholder={toStatus === "on-track"
                ? "How was the issue resolved?"
                : "Recovery actions to bring this back on track."}
              maxLength={1000}
            />
            {errors.mitigationPlan && (
              <p className="text-caption text-danger">{errors.mitigationPlan}</p>
            )}
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-2">
              <Label htmlFor="owner">Owner</Label>
              <Input
                id="owner"
                value={owner}
                onChange={(e) => setOwner(e.target.value)}
                maxLength={120}
              />
              {errors.owner && (
                <p className="text-caption text-danger">{errors.owner}</p>
              )}
            </div>
            <div className="space-y-2">
              <Label htmlFor="dueDate">Due date</Label>
              <Input
                id="dueDate"
                type="date"
                value={dueDate}
                onChange={(e) => setDueDate(e.target.value)}
              />
              {errors.dueDate && (
                <p className="text-caption text-danger">{errors.dueDate}</p>
              )}
            </div>
          </div>
        </div>

        <DialogFooter className="gap-2">
          <Button variant="ghost" onClick={() => onOpenChange(false)}>Cancel</Button>
          {canOverride && (
            <Button variant="outline" onClick={() => handleSubmit("override")}>
              Set directly (override)
            </Button>
          )}
          <Button onClick={() => handleSubmit("request")}>Submit request</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
