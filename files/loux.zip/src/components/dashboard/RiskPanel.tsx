import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useFilteredRisks } from "@/lib/applyFilters";
import { cn } from "@/lib/utils";
import { AlertTriangle } from "lucide-react";

const sevCls = {
  critical: "bg-danger text-danger-foreground",
  high: "bg-warning text-warning-foreground",
  medium: "bg-muted text-foreground",
  low: "bg-muted text-muted-foreground",
};

export function RiskPanel() {
  const risks = useFilteredRisks();
  return (
    <Card className="border-border bg-surface shadow-elev-1">
      <CardHeader className="pb-4">
        <CardTitle className="text-h6 text-foreground flex items-center gap-2">
          <AlertTriangle className="h-4 w-4 text-danger" />
          Risks & blockers
        </CardTitle>
        <p className="text-caption text-muted-foreground">Open items requiring attention</p>
      </CardHeader>
      <CardContent className="p-0">
        <ul className="divide-y divide-border">
          {risks.map((r) => (
            <li key={r.id} className="px-4 py-3 hover:bg-muted/40 transition-colors">
              <div className="flex items-center gap-2">
                <span className={cn("inline-flex items-center rounded-sm px-2 py-1 text-caption font-medium uppercase", sevCls[r.severity])}>
                  {r.severity}
                </span>
                <span className="text-caption text-muted-foreground">{r.launch}</span>
              </div>
              <p className="text-body-3 font-medium text-foreground mt-1">{r.title}</p>
              <p className="text-caption text-muted-foreground mt-1">Owner: {r.owner} · Raised {r.raisedDate}</p>
            </li>
          ))}
        </ul>
      </CardContent>
    </Card>
  );
}
