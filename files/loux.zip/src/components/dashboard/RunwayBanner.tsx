import { useEffect, useState } from "react";
import { AlertTriangle, ShieldCheck, CheckCircle2, BellRing, ShieldAlert } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { toast } from "sonner";
import { cn } from "@/lib/utils";
import type { LaunchTask, TaskStatus } from "@/lib/launchTasks";
import type { Launch } from "@/mocks/launches";
import {
  getMinDuration,
  runwayDays,
  runwaySeverity,
  taskDefaultMin,
} from "@/lib/minDuration";
import {
  setMinDurationOverride,
  subscribeMinDuration,
} from "@/mocks/minDurationOverrides";
import {
  createException,
  getExceptionForTask,
  subscribeRunwayExceptions,
} from "@/mocks/runwayExceptions";
import {
  confirmOverdueStatus,
  subscribeOverdueConfirmations,
  labelFor,
  type ConfirmRyg,
} from "@/mocks/overdueConfirmations";
import { getOverdueState, formatCountdown, formatRelative } from "@/lib/overdueReview";
import { useRole } from "@/contexts/RoleContext";
import { CURRENT_USER_NAME } from "@/mocks/assignmentRequests";
import { isTaskExpedited } from "@/lib/taskExpedited";


interface Props {
  task: LaunchTask;
  launch: Launch;
  onChangeStatus?: (s: TaskStatus) => void;
}


function useRunwaySubscriptions() {
  const [, force] = useState(0);
  useEffect(() => {
    const u1 = subscribeMinDuration(() => force((n) => n + 1));
    const u2 = subscribeRunwayExceptions(() => force((n) => n + 1));
    const u3 = subscribeOverdueConfirmations(() => force((n) => n + 1));
    // Re-render every 60s so the 72h countdown ticks down.
    const tick = setInterval(() => force((n) => n + 1), 60_000);
    return () => { u1(); u2(); u3(); clearInterval(tick); };
  }, []);
}


export function MinDurationTile({ task }: { task: LaunchTask }) {
  useRunwaySubscriptions();
  const { role } = useRole();
  const isAdmin = role === "admin" || role === "superadmin";
  const min = getMinDuration(task);

  const [open, setOpen] = useState(false);
  const [days, setDays] = useState(String(min.days));
  const [reason, setReason] = useState("");

  return (
    <div className="flex items-start justify-between gap-2">
      <div>
        <p className="text-body-3 text-foreground tabular-nums">
          {min.days} day{min.days === 1 ? "" : "s"}
        </p>
        <p className="text-caption text-muted-foreground">
          {min.source}{min.source === "Default" && ` · ${task.phase}`}
        </p>
      </div>
      {isAdmin && (
        <Popover open={open} onOpenChange={(o) => { setOpen(o); if (o) setDays(String(min.days)); }}>
          <PopoverTrigger asChild>
            <Button variant="ghost" size="sm" className="text-caption -mr-2">Edit</Button>
          </PopoverTrigger>
          <PopoverContent align="end" className="w-72 space-y-3">
            <div className="space-y-2">
              <Label htmlFor="min-days" className="text-caption">Minimum days</Label>
              <Input id="min-days" type="number" min={1} value={days} onChange={(e) => setDays(e.target.value)} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="min-reason" className="text-caption">Reason</Label>
              <Textarea id="min-reason" rows={2} placeholder="Why this differs from the suggested duration…" value={reason} onChange={(e) => setReason(e.target.value)} />
              <p className="text-caption text-muted-foreground">Suggested: {taskDefaultMin(task)} days</p>
            </div>
            <div className="flex justify-end gap-2">
              <Button variant="ghost" size="sm" onClick={() => setOpen(false)}>Cancel</Button>
              <Button
                size="sm"
                onClick={() => {
                  const n = parseInt(days, 10);
                  if (!Number.isFinite(n) || n < 1) { toast.error("Enter a positive number"); return; }
                  setMinDurationOverride({
                    taskId: task.id,
                    days: n,
                    reason: reason.trim() || "(no reason given)",
                    by: CURRENT_USER_NAME,
                  });
                  toast.success(`Minimum duration set to ${n} day${n === 1 ? "" : "s"}`);
                  setOpen(false);
                }}
              >
                Save
              </Button>
            </div>
          </PopoverContent>
        </Popover>
      )}
    </div>
  );
}

export function RunwayBanner({ task, launch, onChangeStatus }: Props) {
  useRunwaySubscriptions();
  const min = getMinDuration(task);
  const runway = runwayDays(launch, task);
  const sev = runwaySeverity(runway, min.days);
  const exception = getExceptionForTask(task.id);
  const overdue = getOverdueState(task, launch, runway);

  const [open, setOpen] = useState(false);
  const [reason, setReason] = useState("");
  const [confirmOpen, setConfirmOpen] = useState(false);
  const [confirmRyg, setConfirmRyg] = useState<ConfirmRyg>("at-risk");
  const [confirmNote, setConfirmNote] = useState("");

  if (sev === "ok" && !exception) return null;

  // ---- Tone & icon selection ------------------------------------------------
  let tone = "border-info/40 bg-info/10";
  let Icon: typeof AlertTriangle = AlertTriangle;
  if (exception?.status === "approved") {
    tone = "border-status-on-track/40 bg-status-on-track/10";
    Icon = ShieldCheck;
  } else if (overdue?.escalation) {
    tone = "border-info/40 bg-info/10";
    Icon = AlertTriangle;


  } else if (overdue?.confirmation) {
    tone = "border-status-on-track/40 bg-status-on-track/10";
    Icon = CheckCircle2;
  } else if (overdue) {
    tone = "border-status-at-risk/40 bg-status-at-risk/10";
    Icon = BellRing;
  }

  // ---- Header + subtext -----------------------------------------------------
  let title: React.ReactNode;
  let subtitle: React.ReactNode;
  if (exception?.status === "approved") {
    title = <>Exception approved · short runway accepted</>;
    subtitle = (
      <>
        {runway < 0 ? `Overdue by ${Math.abs(runway)}d` : `${runway}d runway`} vs {min.days}d recommended ·
        Approved by {exception.resolvedBy ?? "—"}
        {exception.reason ? ` · "${exception.reason}"` : ""}
      </>
    );
  } else if (exception?.status === "pending") {
    title = <>Exception requested · awaiting approval</>;
    subtitle = (
      <>
        {runway < 0 ? `Overdue by ${Math.abs(runway)}d` : `Only ${runway}d`} until due — recommended minimum is {min.days}d.
        Requested by {exception.requestedBy} · "{exception.reason}"
      </>
    );
  } else if (overdue?.escalation) {
    title = <>Overdue by {overdue.overdueDays}d — escalated to manager</>;
    subtitle = (
      <>
        No status review within 72h. Auto-escalated to <span className="font-medium text-foreground">{overdue.escalation.escalatedTo}</span> {formatRelative(overdue.escalation.escalatedAt)}.
        Confirm now to clear the escalation.
      </>
    );
  } else if (overdue?.confirmation) {
    const c = overdue.confirmation;
    title = (
      <>
        Status confirmed as <span className="font-semibold">{labelFor(c.status)}</span>
      </>
    );
    subtitle = (
      <>
        Confirmed by {c.confirmedBy} · {formatRelative(c.confirmedAt)}
        {c.note ? ` · "${c.note}"` : ""}. Overdue by {overdue.overdueDays}d.
      </>
    );
  } else if (overdue) {
    title = <>Overdue by {overdue.overdueDays}d — please confirm current status</>;
    subtitle = (
      <>
        Status review required.{" "}
        {overdue.msUntilEscalation != null && (
          <>Auto-escalates to manager in <span className="font-medium text-foreground tabular-nums">{formatCountdown(overdue.msUntilEscalation)}</span>.</>
        )}
      </>
    );
  } else {
    title = <>Only {runway}d until due — recommended minimum is {min.days}d</>;
    subtitle = (
      <>
        Source: {min.source}{min.source === "Default" && ` · ${task.phase} phase default`}.
        Short timelines should be justified via an exception.
      </>
    );
  }

  const showCountdownChip =
    overdue && !overdue.confirmation && !overdue.escalation && overdue.msUntilEscalation != null;
  const countdownDanger = showCountdownChip && (overdue!.msUntilEscalation ?? 0) < 12 * 60 * 60 * 1000;

  return (
    <div className={cn("rounded-md border px-4 py-3", tone)}>
      <div className="flex items-start gap-3">
        <Icon className="h-4 w-4 mt-1 text-foreground shrink-0" aria-hidden />
        <div className="flex-1 min-w-0 space-y-1">
          <div className="flex items-center gap-2 flex-wrap">
            <p className="text-body-3 font-medium text-foreground">{title}</p>
            {showCountdownChip && (
              <Badge
                variant="outline"
                className={cn(
                  "text-caption gap-1 tabular-nums",
                  countdownDanger
                    ? "border-status-at-risk/60 text-status-at-risk"
                    : "border-border text-muted-foreground",
                )}
              >
                {formatCountdown(overdue!.msUntilEscalation!)} to escalation
              </Badge>
            )}
          </div>
          <p className="text-caption text-muted-foreground">{subtitle}</p>
        </div>
        <div className="flex items-center gap-2 shrink-0">
          {overdue && onChangeStatus && (
            <Popover open={confirmOpen} onOpenChange={setConfirmOpen}>
              <PopoverTrigger asChild>
                <Button size="sm" variant={overdue.confirmation ? "outline" : "default"}>
                  {overdue.confirmation ? "Re-confirm status" : "Confirm status"}
                </Button>
              </PopoverTrigger>
              <PopoverContent align="end" className="w-56 p-1">
                <ul>
                  {(
                    [
                      { v: "on-track", label: "On track", dot: "bg-status-on-track" },
                      { v: "at-risk-mitigated", label: "At risk (mitigated)", dot: "bg-status-at-risk-mitigated" },
                      { v: "at-risk", label: "At risk", dot: "bg-status-at-risk" },
                    ] as const
                  ).map((opt) => (
                    <li key={opt.v}>
                      <button
                        type="button"
                        onClick={() => {
                          setConfirmOpen(false);
                          onChangeStatus(opt.v as TaskStatus);
                        }}
                        className="w-full flex items-center gap-2 px-2 py-2 rounded-sm text-left text-body-3 hover:bg-muted/40 transition-colors"
                      >
                        <span
                          className={cn("inline-block h-2 w-2 rounded-full", opt.dot)}
                          aria-hidden
                        />
                        <span className="text-foreground">{opt.label}</span>
                      </button>
                    </li>
                  ))}
                </ul>
              </PopoverContent>
            </Popover>
          )}
          {overdue && !onChangeStatus && (
            <Popover
              open={confirmOpen}
              onOpenChange={(o) => {
                setConfirmOpen(o);
                if (o) {
                  setConfirmRyg(overdue.confirmation?.status ?? "at-risk");
                  setConfirmNote("");
                }
              }}
            >
              <PopoverTrigger asChild>
                <Button size="sm" variant={overdue.confirmation ? "outline" : "default"}>
                  {overdue.confirmation ? "Re-confirm status" : "Confirm status"}
                </Button>
              </PopoverTrigger>
              <PopoverContent align="end" className="w-80 space-y-3">
                <div className="space-y-2">
                  <Label className="text-caption">Current RYG status</Label>
                  <RadioGroup
                    value={confirmRyg}
                    onValueChange={(v) => setConfirmRyg(v as ConfirmRyg)}
                    className="space-y-1"
                  >
                    {(
                      [
                        { v: "on-track", label: "On track", dot: "bg-status-on-track" },
                        { v: "at-risk-mitigated", label: "At risk (mitigated)", dot: "bg-status-at-risk-mitigated" },
                        { v: "at-risk", label: "At risk", dot: "bg-status-at-risk" },
                      ] as const
                    ).map((opt) => (
                      <label
                        key={opt.v}
                        className="flex items-center gap-2 rounded-sm px-2 py-2 cursor-pointer hover:bg-muted/40"
                      >
                        <RadioGroupItem value={opt.v} id={`ryg-${opt.v}`} />
                        <span className={cn("inline-block h-2 w-2 rounded-full", opt.dot)} aria-hidden />
                        <span className="text-body-3 text-foreground">{opt.label}</span>
                      </label>
                    ))}
                  </RadioGroup>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="confirm-note" className="text-caption">Note (optional)</Label>
                  <Textarea
                    id="confirm-note"
                    rows={2}
                    placeholder="Brief context for reviewers…"
                    value={confirmNote}
                    onChange={(e) => setConfirmNote(e.target.value)}
                  />
                </div>
                <div className="flex justify-end gap-2">
                  <Button variant="ghost" size="sm" onClick={() => setConfirmOpen(false)}>Cancel</Button>
                  <Button
                    size="sm"
                    onClick={() => {
                      confirmOverdueStatus({
                        taskId: task.id,
                        taskName: task.task,
                        launchId: launch.id,
                        status: confirmRyg,
                        confirmedBy: CURRENT_USER_NAME,
                        note: confirmNote.trim() || undefined,
                      });
                      toast.success(`Status confirmed as ${labelFor(confirmRyg)}`);
                      setConfirmOpen(false);
                    }}
                  >
                    Confirm
                  </Button>
                </div>
              </PopoverContent>
            </Popover>
          )}

          {!exception && (
            <Popover open={open} onOpenChange={setOpen}>
              <PopoverTrigger asChild>
                <Button size="sm" variant="secondary-dds">Request exception</Button>
              </PopoverTrigger>
              <PopoverContent align="end" className="w-80 space-y-3">
                <div className="space-y-2">
                  <Label htmlFor="exc-reason" className="text-caption">Justification</Label>
                  <Textarea id="exc-reason" rows={3} placeholder="Why a shorter runway is acceptable…" value={reason} onChange={(e) => setReason(e.target.value)} />
                </div>
                <div className="flex justify-end gap-2">
                  <Button variant="ghost" size="sm" onClick={() => setOpen(false)}>Cancel</Button>
                  <Button
                    size="sm"
                    onClick={() => {
                      const r = reason.trim();
                      if (!r) { toast.error("Justification is required"); return; }
                      createException({
                        taskId: task.id,
                        taskName: task.task,
                        launchId: launch.id,
                        launchName: launch.name,
                        runwayDays: runway,
                        minDays: min.days,
                        reason: r,
                        requestedBy: CURRENT_USER_NAME,
                      });
                      toast.success("Exception requested");
                      setOpen(false);
                      setReason("");
                    }}
                  >
                    Submit request
                  </Button>
                </div>
              </PopoverContent>
            </Popover>
          )}
        </div>
      </div>
    </div>
  );
}


/** Compact chip for task rows in lists. Renders nothing when healthy. */
export function RunwayChip({ task, launch }: Props) {
  useRunwaySubscriptions();
  const min = getMinDuration(task);
  const runway = runwayDays(launch, task);
  const sev = runwaySeverity(runway, min.days);
  const exc = getExceptionForTask(task.id);
  if (sev === "ok" && !exc) return null;
  if (exc?.status === "approved") {
    return (
      <Badge variant="outline" className="text-body-3 gap-1 border-status-on-track/50 text-status-on-track">
        <ShieldCheck className="h-3 w-3" /> Exception
      </Badge>
    );
  }
  const cls = sev === "danger"
    ? "border-status-at-risk/50 text-status-at-risk"
    : "border-status-at-risk-mitigated/60 text-status-at-risk-mitigated";
  return (
    <Badge variant="outline" className={cn("text-body-3 gap-1", cls)} title={`Recommended minimum: ${min.days}d`}>
      <AlertTriangle className="h-3 w-3" />
      {runway < 0 ? `Overdue ${Math.abs(runway)}d` : `${runway}d / ${min.days}d`}
    </Badge>
  );
}

/**
 * Red banner shown on the task detail view when the task is being expedited
 * because its launch's RTS was pulled in. Read-only; mirrors the danger style
 * of RunwayBanner.
 */
export function ExpeditedBanner({ task, launch }: Props) {
  const info = isTaskExpedited(launch, task);
  if (!info) return null;
  return (
    <div className="rounded-md border px-4 py-3 border-status-at-risk/40 bg-status-at-risk/10">
      <div className="flex items-start gap-3">
        <AlertTriangle className="h-4 w-4 mt-1 text-foreground shrink-0" aria-hidden />
        <div className="flex-1 min-w-0 space-y-1">
          <p className="text-body-3 font-medium text-foreground">
            Expedited to meet POR schedule
          </p>
          <p className="text-caption text-muted-foreground">
            {launch.name} RTS moved {info.previousDate} → {info.newDate} ({info.pulledInDays}d earlier).
            Pull this task in to stay on plan.
          </p>
        </div>
      </div>
    </div>
  );
}
