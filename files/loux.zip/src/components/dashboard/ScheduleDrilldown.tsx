import { Fragment, useEffect, useLayoutEffect, useMemo, useRef, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { DashboardDetailDrawer, DrawerEmpty } from "@/components/dashboard/drawers/DashboardDetailDrawer";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ToggleGroup, ToggleGroupItem } from "@/components/ui/toggle-group";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ChevronRight, CalendarClock, ArrowUpDown, Flame, CalendarDays, Layers, LocateFixed, Info, MoreVertical, Pencil } from "lucide-react";

import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { useFilteredLaunches } from "@/lib/applyFilters";
import { useFilters } from "@/contexts/FilterContext";
import { phasesForLaunch, pctBetween, type ScheduleTrack } from "@/lib/schedule";
import { functionStatus, platformStatus, phaseCompletionPct, type TaskFunction, type TaskStatus } from "@/lib/launchTasks";
import { KEY_MILESTONES, milestoneDate } from "@/lib/keyMilestones";
import { getPhaseVariance, formatDelta } from "@/lib/porVariance";

import { cn } from "@/lib/utils";
import { useRole } from "@/contexts/RoleContext";
import { effectiveLaunchDate, subscribeLaunchDateOverrides, getOverride } from "@/mocks/launchDateOverrides";
import { MilestoneChangeDialog } from "@/components/dashboard/MilestoneChangeDialog";
import { PlatformReviewDrawer } from "@/components/dashboard/PlatformReviewDrawer";
import { launchToPending } from "@/lib/launchToPending";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Share2, Mail, FileDown } from "lucide-react";
import { exportElementToPdf } from "@/lib/exportPdf";
import { toast } from "@/hooks/use-toast";
import { launches as ALL_LAUNCHES, type Launch } from "@/mocks/launches";

type TaskFilter = "all" | TaskFunction;
/** Display label for a function/track. Internal id stays "SChM" (mocks). */
const trackLabel = (t: TaskFunction | ScheduleTrack): string =>
  t === "SChM" ? "SChM" : t === "Core" ? "Core team" : t;
const FILTERS: { value: TaskFilter; label: string }[] = [
  { value: "all", label: "All" },
  { value: "GOE", label: "GOE" },
  { value: "NPI", label: "NPI" },
  { value: "SChM", label: trackLabel("SChM") },
];

const TRACKS: ScheduleTrack[] = ["Core", "GOE", "NPI", "SChM"];
const PX_PER_MONTH = 96;
const PLATFORM_COL_WIDTH = 300;



// Determine the current phase per track from today's date (each track has its own
// timeline, so the "current" phase can differ between GOE/NPI and SChM).
function currentPhaseIndexFromDate(
  phases: { start: Date; end: Date }[],
  today: Date,
): number {
  const t = today.getTime();
  for (let i = 0; i < phases.length; i++) {
    if (t >= phases[i].start.getTime() && t < phases[i].end.getTime()) return i;
  }
  // Before first phase → first; after last phase → last.
  if (phases.length === 0) return 0;
  if (t < phases[0].start.getTime()) return 0;
  return phases.length - 1;
}

const STATUS_CLASS: Record<TaskStatus, string> = {
  completed: "bg-status-completed",
  "on-track": "bg-status-on-track",
  "at-risk-mitigated": "bg-status-at-risk-mitigated",
  "at-risk": "bg-status-at-risk",
  "not-started": "bg-status-not-started",
};

function StatusDot({ status, className }: { status: TaskStatus; className?: string }) {
  return (
    <span
      className={cn("inline-block h-2 w-2 rounded-full shrink-0", STATUS_CLASS[status], className)}
      aria-hidden
    />
  );
}

function phaseStatusClass(idx: number, currentIdx: number, currentStatus: TaskStatus): string {
  if (idx < currentIdx) return STATUS_CLASS.completed;
  if (idx === currentIdx) return STATUS_CLASS[currentStatus];
  return STATUS_CLASS["not-started"];
}

function startOfMonth(d: Date) {
  return new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), 1));
}
function addMonths(d: Date, n: number) {
  return new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth() + n, 1));
}

type SortMode = "priority" | "rts";
const SORT_STORAGE_KEY = "olp.scheduleSort";
const SHOW_POR_STORAGE_KEY = "olp.showPor";

export function ScheduleDrilldown({ launchId, title, footer, onlyCurrentPhase = false }: { launchId?: string; title?: string; footer?: React.ReactNode; onlyCurrentPhase?: boolean } = {}) {
  const filteredLaunches = useFilteredLaunches();
  const launches = useMemo(() => {
    if (!launchId) return filteredLaunches;
    const single = ALL_LAUNCHES.find((l) => l.id === launchId);
    return single ? [single] : [];
  }, [filteredLaunches, launchId]);
  const { filters, setFilter } = useFilters();
  const navigate = useNavigate();
  const { role } = useRole();
  const isAdmin = role === "admin" || role === "superadmin";
  const [editLaunch, setEditLaunch] = useState<Launch | null>(null);
  const [drawerLaunch, setDrawerLaunch] = useState<Launch | null>(null);
  const [coreDrawer, setCoreDrawer] = useState<Launch | null>(null);

  const handleTrackClick = (launch: Launch, track: ScheduleTrack) => {
    if (track === "Core") {
      setCoreDrawer(launch);
      return;
    }
    setFilter("function", [track]);
    navigate(`/tasks?tab=platform&launch=${encodeURIComponent(launch.id)}&inner=tasks`);
  };
  const [, force] = useState(0);
  useEffect(() => subscribeLaunchDateOverrides(() => force((n) => n + 1)), []);
  const [sortMode, setSortMode] = useState<SortMode>(() => {
    if (typeof window === "undefined") return "priority";
    return (window.localStorage.getItem(SORT_STORAGE_KEY) as SortMode) || "priority";
  });
  const handleSortChange = (next: string) => {
    if (next !== "priority" && next !== "rts") return;
    setSortMode(next);
    try {
      window.localStorage.setItem(SORT_STORAGE_KEY, next);
    } catch {
      /* noop */
    }
  };
  const [showPor, setShowPor] = useState<boolean>(() => {
    if (typeof window === "undefined") return false;
    return window.localStorage.getItem(SHOW_POR_STORAGE_KEY) === "1";
  });
  const handleShowPorChange = (next: boolean) => {
    setShowPor(next);
    try {
      window.localStorage.setItem(SHOW_POR_STORAGE_KEY, next ? "1" : "0");
    } catch {
      /* noop */
    }
  };
  const fnFilter = Array.isArray(filters.function) ? (filters.function as string[]) : [];
  const activeTracks: ScheduleTrack[] = TRACKS.filter(
    (t) => fnFilter.length === 0 || fnFilter.includes(t),
  );
  // Full extent across every platform & track
  const { start, end, ticks, totalWidth } = useMemo(() => {
    let min = Infinity;
    let max = -Infinity;
    for (const l of launches) {
      for (const track of activeTracks) {
        for (const p of phasesForLaunch(l, track)) {
          if (p.start.getTime() < min) min = p.start.getTime();
          if (p.end.getTime() > max) max = p.end.getTime();
        }
      }
    }
    if (launches.length === 0) {
      const now = new Date();
      const s = startOfMonth(now);
      return { start: s, end: addMonths(s, 1), ticks: [s, addMonths(s, 1)], totalWidth: PX_PER_MONTH };
    }
    const start = startOfMonth(new Date(min));
    const end = startOfMonth(addMonths(new Date(max), 1));
    const ticks: Date[] = [];
    const cur = new Date(start.getTime());
    while (cur <= end) {
      ticks.push(new Date(cur.getTime()));
      cur.setUTCMonth(cur.getUTCMonth() + 1);
    }
    const totalWidth = (ticks.length - 1) * PX_PER_MONTH;
    return { start, end, ticks, totalWidth };
  }, [launches, activeTracks]);

  const today = new Date();
  const todayPct = pctBetween(today, start, end);

  // Pin platform column via inner scroll
  const scrollerRef = useRef<HTMLDivElement>(null);
  const headerScrollerRef = useRef<HTMLDivElement>(null);
  const exportRef = useRef<HTMLDivElement>(null);
  const [scrollReady, setScrollReady] = useState(false);

  const centeredScrollLeft = (el: HTMLDivElement) => {
    // The inner content begins with a sticky PLATFORM_COL_WIDTH column, so the
    // gantt timeline starts at that pixel offset within the scrollable area.
    const todayPx = PLATFORM_COL_WIDTH + (todayPct / 100) * totalWidth;
    const maxScroll = Math.max(0, PLATFORM_COL_WIDTH + totalWidth - el.clientWidth);
    return Math.max(0, Math.min(maxScroll, todayPx - el.clientWidth / 2));
  };

  const scrollToToday = () => {
    const el = scrollerRef.current;
    if (!el) return;
    el.scrollTo({ left: centeredScrollLeft(el), behavior: "smooth" });
  };

  // Track viewport width of the gantt scroller (kept for future use)
  const [, setViewportW] = useState(0);
  useLayoutEffect(() => {
    const el = scrollerRef.current;
    if (!el) return;
    el.scrollLeft = centeredScrollLeft(el);
    if (headerScrollerRef.current) headerScrollerRef.current.scrollLeft = el.scrollLeft;
    setScrollReady(true);
    const update = () => setViewportW(el.clientWidth);
    update();
    const onScroll = () => {
      if (headerScrollerRef.current) headerScrollerRef.current.scrollLeft = el.scrollLeft;
    };
    el.addEventListener("scroll", onScroll, { passive: true });
    const ro = new ResizeObserver(update);
    ro.observe(el);
    return () => {
      el.removeEventListener("scroll", onScroll);
      ro.disconnect();
    };
  }, [todayPct, totalWidth]);

  const sectionTitle = title ?? (launchId ? "Platform timeline view" : "Cross-platform timeline view");
  const exportTitle = sectionTitle;
  const exportSlug = "cross-platform-timeline";
  const doExport = async () => {
    const el = exportRef.current;
    if (!el) return false;
    try {
      await exportElementToPdf(el, { title: exportTitle, filenameSlug: exportSlug, orientation: "landscape" });
      toast({ title: "PDF downloaded", description: `${exportSlug}.pdf` });
      return true;
    } catch (e) {
      toast({ title: "Export failed", description: String(e) });
      return false;
    }
  };
  const doEmail = async () => {
    const ok = await doExport();
    if (!ok) return;
    const subject = encodeURIComponent(exportTitle);
    const body = encodeURIComponent(
      `Hi,\n\nSharing the ${exportTitle}. The PDF was just downloaded to your device — please attach "${exportSlug}.pdf" to this email before sending.\n\nThanks`,
    );
    window.location.href = `mailto:?subject=${subject}&body=${body}`;
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between gap-4">
        <h2 className="text-h4 text-foreground">{sectionTitle}</h2>
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button
              type="button"
              variant="ghost"
              size="sm"
              className="gap-1 px-2 text-button-2 hover:bg-transparent"
              style={{ color: "#0672CB" }}
            >
              <Share2 className="h-4 w-4" aria-hidden />
              Share
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuItem onClick={doExport}>
              <FileDown className="mr-2 h-4 w-4" aria-hidden />
              Export as PDF
            </DropdownMenuItem>
            <DropdownMenuItem onClick={doEmail}>
              <Mail className="mr-2 h-4 w-4" aria-hidden />
              Share via email
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
      <Card className="border-border bg-surface shadow-elev-1">
        <div className="sticky top-16 z-40 bg-surface border-b border-border">
          <CardHeader className="px-4 pb-4 space-y-0 flex flex-row items-center justify-between gap-3">
            <h5 className="text-h5 text-foreground">Schedule dashboard</h5>
          </CardHeader>
        <div className="px-4 pb-4 flex flex-wrap items-center justify-between gap-x-4 gap-y-2">
          <div className="flex flex-wrap items-center gap-x-4 gap-y-2">
            {[
              { cls: "bg-status-completed", label: "Completed" },
              { cls: "bg-status-on-track", label: "Achieved / on track" },
              { cls: "bg-status-at-risk-mitigated", label: "Risk with mitigation" },
              { cls: "bg-status-at-risk", label: "Missed / no mitigation plan" },
              { cls: "bg-status-not-started", label: "Not started" },
            ].map((s) => (
              <span key={s.label} className="inline-flex items-center gap-2 text-caption text-muted-foreground">
                <span className={cn("h-2 w-2 rounded-full", s.cls)} aria-hidden />
                {s.label}
              </span>
            ))}
            <span className="inline-flex items-center gap-2 text-caption text-muted-foreground">
              <span className="h-2 w-2 rotate-45 bg-milestone-phase-exit" aria-hidden />
              Phase exit
            </span>
            <span className="inline-flex items-center gap-2 text-caption text-muted-foreground">
              <span className="h-2 w-2 rotate-45 bg-milestone-key" aria-hidden />
              Other key milestone
            </span>
            {showPor && (
              <>
                <span className="inline-flex items-center gap-2 text-caption text-muted-foreground">
                  <span className="h-2 w-2 rounded-full border bg-transparent" style={{ borderColor: "#0063B8" }} aria-hidden />
                  POR
                </span>
                <span className="inline-flex items-center gap-2 text-caption text-muted-foreground">
                  <span className="h-2 w-2" style={{ backgroundColor: "#B86B32" }} aria-hidden />
                  +Nd / −Nd slip
                </span>
              </>
            )}
          </div>
          <div className="flex flex-wrap items-center gap-2 shrink-0">
            {!launchId && (
              <div className="flex items-center gap-2">
                <span className="hidden m:inline text-body-2 text-muted-foreground">Sort</span>
                <Select value={sortMode} onValueChange={handleSortChange}>
                  <SelectTrigger
                    aria-label="Sort platforms"
                    className="h-8 w-[240px] text-body-2 font-normal"
                  >
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="priority">By status, then RTS date</SelectItem>
                    <SelectItem value="rts">By RTS date</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            )}
            <Button
              type="button"
              variant="ghost"
              size="sm"
              onClick={scrollToToday}
              className="h-8 px-3 border bg-transparent shrink-0 text-button-2 hover:bg-[#0672CB]/10 active:bg-[#0672CB]/20 focus-visible:ring-2 focus-visible:ring-[#0672CB]/40"
              style={{ borderColor: "#0672CB", color: "#0672CB" }}
            >
              View today
            </Button>
            <div className="flex items-center gap-2">
              <Checkbox
                id="show-por-checkbox"
                checked={showPor}
                onCheckedChange={(v) => handleShowPorChange(v === true)}
                aria-label="Show POR baseline overlay"
              />
              <Label htmlFor="show-por-checkbox" className="text-body-2 font-normal text-muted-foreground cursor-pointer">
                Show POR
              </Label>
            </div>
          </div>
        </div>
        {/* Sticky timeline header (Platform + month ticks), scroll-synced with body */}
        <div
          ref={headerScrollerRef}
          className={cn("overflow-x-hidden bg-surface border-t border-border", !scrollReady && "invisible")}
        >
          <div
            className="grid"
            style={{ gridTemplateColumns: `${PLATFORM_COL_WIDTH}px ${totalWidth}px`, minWidth: PLATFORM_COL_WIDTH + totalWidth }}
          >
            <div className="sticky left-0 z-30 bg-surface px-4 pt-8 pb-3 border-r border-border text-caption text-muted-foreground flex items-end">
              Platform
            </div>
            <div className="relative h-16" style={{ width: totalWidth }}>
              {/* Top row: Today pill (24px tall, with breathing room) */}
              <div className="absolute left-0 right-0 top-2 h-6">
                <div
                  className="absolute -translate-x-1/2 z-20 rounded-full bg-primary px-2 py-1 text-caption font-medium text-primary-foreground tabular-nums whitespace-nowrap shadow-elev-1 pointer-events-none"
                  style={{ left: `${todayPct}%` }}
                  aria-label="Today"
                >
                  Today · {today.toLocaleString("en", { month: "short", day: "numeric" })}
                </div>
              </div>
              {/* Bottom row: month ticks */}
              <div className="absolute left-0 right-0 bottom-0 h-6">
                {ticks.map((t, i) => {
                  const left = i * PX_PER_MONTH;
                  const monthLabel = t.toLocaleString("en", { month: "short", timeZone: "UTC" });
                  const yearShort = String(t.getUTCFullYear()).slice(-2);
                  return (
                    <div key={i} className="absolute top-0 bottom-0 flex flex-col justify-end pb-1" style={{ left }}>
                      <span className="text-caption text-muted-foreground tabular-nums whitespace-nowrap">
                        {monthLabel} '{yearShort}
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      </div>
      <CardContent className="p-0">
        <div
          ref={scrollerRef}
          className={cn("overflow-x-auto", !scrollReady && "invisible")}
        >
          <div
            ref={exportRef}
            className="relative bg-surface"
            style={{ minWidth: PLATFORM_COL_WIDTH + totalWidth }}
          >


            {/* Body — sort by selected mode */}
            <div>
              {[...launches]
                .sort((a, b) => {
                  if (sortMode === "rts") {
                    return effectiveLaunchDate(a).localeCompare(effectiveLaunchDate(b));
                  }
                  const sa = platformStatus(a);
                  const sb = platformStatus(b);
                  const rank = (s: TaskStatus) =>
                    s === "at-risk" ? 0 : s === "at-risk-mitigated" ? 1 : 2;
                  const r = rank(sa) - rank(sb);
                  if (r !== 0) return r;
                  return effectiveLaunchDate(a).localeCompare(effectiveLaunchDate(b));
                })
                .map((launch) => {
                return (
                <div key={launch.id} className="border-b border-border last:border-0">
                  {/* Gantt portion — grid + gridlines + today overlay only span this block */}
                  <div
                    className="relative grid"
                    style={{
                      gridTemplateColumns: `${PLATFORM_COL_WIDTH}px ${totalWidth}px`,
                    }}
                  >
                    {/* Row 1 — platform info (left, link to detail page), filler (right) */}
                    <div
                      className="sticky left-0 z-30 bg-surface px-4 pt-2 pb-1 border-r border-border min-w-0"
                      style={{ gridColumn: 1, gridRow: 1 }}
                    >
                      <div className="min-w-0">
                        <div className="group flex items-center gap-1 -mx-1 px-1 py-1 rounded-sm hover:bg-muted/40 transition-colors">
                          <Link
                            to={`/tasks?tab=platform&launch=${launch.id}`}
                            className="flex items-center gap-2 text-body-3 font-medium text-foreground min-w-0 flex-1 rounded-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                            aria-label={`View ${launch.name} tasks`}
                          >
                            <StatusDot status={platformStatus(launch)} />
                            <span className="truncate hover:underline min-w-0 flex-1" title={launch.name}>
                              {launch.name}
                            </span>
                          </Link>
                          {isAdmin ? (
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <button
                                  type="button"
                                  aria-label={`Actions for ${launch.name}`}
                                  style={{ color: "#0672CB" }}
                                  className="shrink-0 inline-flex h-6 w-6 items-center justify-center rounded-sm hover:bg-muted focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                                >
                                  <MoreVertical className="h-4 w-4" />
                                </button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent align="end">
                                <DropdownMenuItem onSelect={() => setDrawerLaunch(launch)}>
                                  <Pencil className="h-4 w-4 mr-2" /> Edit schedule
                                </DropdownMenuItem>
                                <DropdownMenuItem onSelect={() => setEditLaunch(launch)}>
                                  <CalendarClock className="h-4 w-4 mr-2" /> Edit RTS
                                </DropdownMenuItem>
                              </DropdownMenuContent>
                            </DropdownMenu>
                          ) : (
                            <ChevronRight className="h-4 w-4 shrink-0 text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity" />
                          )}
                        </div>
                        {(() => {
                          const eff = effectiveLaunchDate(launch);
                          const ov = getOverride(launch.id);
                          return (
                            <div className="mt-1 flex items-center gap-2">
                              <span className="text-caption text-muted-foreground tabular-nums min-w-0 truncate">
                                {launch.lob} · RTS {eff}
                              </span>
                            </div>
                          );
                        })()}
                        {showPor && (() => {
                          let worst = 0;
                          for (const t of activeTracks) {
                            for (const v of getPhaseVariance(launch, t)) {
                              if (v.deltaDays !== undefined && Math.abs(v.deltaDays) > Math.abs(worst)) worst = v.deltaDays;
                            }
                          }
                          const hasAny = activeTracks.some((t) =>
                            getPhaseVariance(launch, t).some((v) => v.deltaDays !== undefined),
                          );
                          if (!hasAny) return null;
                          const tone =
                            worst > 0 ? "bg-status-at-risk/10 text-status-at-risk"
                            : worst < 0 ? "bg-status-completed/10 text-status-completed"
                            : "bg-muted text-muted-foreground";
                          const label = worst === 0 ? "POR · on plan" : `POR ${formatDelta(worst)} worst`;
                          return (
                            <span className={cn("mt-1 inline-flex items-center gap-1 rounded-full px-2 py-1 text-caption tabular-nums leading-none", tone)}>
                              {label}
                            </span>
                          );
                        })()}
                      </div>
                    </div>
                    <div style={{ gridColumn: 2, gridRow: 1 }} className="pt-2 pb-1" />


                    {/* Milestone strip — union of GOE/NPI/SChM key gates, anchored to RTS */}
                    <div
                      className="sticky left-0 z-30 bg-surface px-4 py-1 border-r border-border flex items-center"
                      style={{ gridColumn: 1, gridRow: 2 }}
                    >
<span className="text-caption text-muted-foreground">
                        Milestones
                      </span>
                    </div>
                    <div
                      className="px-2 py-1 relative z-10"
                      style={{ gridColumn: 2, gridRow: 2 }}
                    >
                      <div className="relative h-7">
                        {KEY_MILESTONES.map((m) => {
                          const date = milestoneDate(effectiveLaunchDate(launch), m.offsetDays);
                          if (date < start || date > end) return null;
                          const left = pctBetween(date, start, end);
                          const iso = date.toISOString().slice(0, 10);
                          return (
                            <div
                              key={m.key}
                              className="absolute top-0 bottom-0 flex flex-col items-center"
                              style={{ left: `${left}%`, transform: "translateX(-50%)" }}
                              title={`${m.label} — ${m.fullName} · ${iso}`}
                            >
                              <span className="text-caption leading-tight text-muted-foreground tabular-nums whitespace-nowrap">
                                {m.label}
                              </span>
                              <span
                                className={cn(
                                  "mt-1 inline-block h-2 w-2 rotate-45",
                                  m.isPhaseExit ? "bg-milestone-phase-exit" : "bg-milestone-key",
                                )}
                                aria-hidden
                              />
                            </div>
                          );
                        })}
                      </div>
                    </div>

                    {/* Track rows — labels in pinned col, bars in timeline */}
                    {activeTracks.map((track, ti) => {
                      const phases = phasesForLaunch(launch, track);
                      const currentIdx = currentPhaseIndexFromDate(phases, today);
                      const fnStatus = functionStatus(launch, track);
                      const isLast = ti === activeTracks.length - 1;
                      return (
                        <Fragment key={track}>
                          <div
                            className={cn(
                              "sticky left-0 z-30 bg-surface px-4 border-r border-border flex flex-col justify-center gap-0",
                              isLast ? "pb-4 pt-2" : "py-2"
                            )}
                            style={{ gridColumn: 1, gridRow: ti + 3 }}
                          >
                            {showPor && (
                              <div className="inline-flex items-center gap-2 px-2 -mx-1 h-5">
                                <span className="text-caption text-muted-foreground pl-4">
                                  {trackLabel(track)} (POR)
                                </span>
                              </div>
                            )}
                            {showPor && <div className="h-3" aria-hidden />}
                            <div className="flex items-center justify-between gap-2 px-2 py-1 -mx-1 w-full">
                              <div className="flex items-center gap-2 min-w-0">
                                <StatusDot status={fnStatus} />
                                <span className="text-caption text-muted-foreground whitespace-nowrap">
                                  {trackLabel(track)}{showPor ? " (actual)" : ""}
                                </span>
                              </div>
                              <div className="flex items-center gap-2 shrink-0">
                                <Tooltip>
                                  <TooltipTrigger asChild>
                                    <button
                                      type="button"
                                      aria-label={`Why ${trackLabel(track)} status`}
                                      onClick={(e) => e.stopPropagation()}
                                      className="inline-flex items-center justify-center rounded-sm text-muted-foreground hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                                    >
                                      <Info className="h-3 w-3" />
                                    </button>
                                  </TooltipTrigger>
                                  <TooltipContent side="top" className="max-w-xs">
                                    <span className="text-caption">
                                      Status reflects latest approved status change for the selected function; placeholder rationale - to be populated from most recent request
                                    </span>
                                  </TooltipContent>
                                </Tooltip>
                                <button
                                  type="button"
                                  onClick={() => handleTrackClick(launch, track)}
                                  aria-label={`View ${trackLabel(track)} details for ${launch.name}`}
                                  className="inline-flex items-center gap-1 rounded-sm px-1 text-caption text-primary hover:underline whitespace-nowrap focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                                >
                                  View details
                                  <ChevronRight className="h-3 w-3" />
                                </button>
                              </div>
                            </div>




                          </div>
                          <div
                            className={cn("px-2 relative z-10", isLast ? "pb-4 pt-2" : "py-2")}
                            style={{ gridColumn: 2, gridRow: ti + 3 }}
                          >
                            <div className="relative flex flex-col gap-0">
                              {/* POR row — dark bars per phase, full-height */}
                              {showPor && (() => {
                                const variances = getPhaseVariance(launch, track);
                                const porByPhase = new Map(variances.map((v) => [v.phase, v.porExit]));
                                let prevPorEnd: Date | null = null;
                                const porSpans = phases.map((p) => {
                                  const porExitIso = porByPhase.get(p.name);
                                  if (!porExitIso) return null;
                                  const porEnd = new Date(porExitIso + "T00:00:00Z");
                                  const porStart = prevPorEnd ?? p.start;
                                  prevPorEnd = porEnd;
                                  return { name: p.name, start: porStart, end: porEnd, porExitIso };
                                });
                                return (
                                  <div className="relative h-5 rounded-sm bg-transparent overflow-hidden">
                                    {porSpans.map((s, i) => {
                                      if (!s) return null;
                                      if (onlyCurrentPhase && i !== currentIdx) return null;
                                      if (s.end < start || s.start > end) return null;
                                      const l = Math.max(0, pctBetween(s.start, start, end));
                                      const r = Math.min(100, pctBetween(s.end, start, end));
                                      const w = Math.max(0, r - l);
                                      if (w <= 0) return null;
                                      return (
                                        <div
                                          key={`por-${s.name}`}
                                          className="absolute top-0 bottom-0 flex items-center justify-center px-2 border-r last:border-r-0"
                                          style={{
                                            left: `${l}%`,
                                            width: `${w}%`,
                                            background: "#FFFFFF",
                                            border: "1px solid #0063B8",
                                            borderRightColor: "#0063B8",
                                          }}
                                          title={`POR ${track} · ${s.name}: ${s.start.toISOString().slice(0, 10)} → ${s.porExitIso}`}
                                        >
                                          {w > 3 && (
                                            <span className="text-caption font-medium truncate" style={{ color: "#0063B8" }}>
                                              {s.name}
                                            </span>
                                          )}
                                        </div>
                                      );
                                    })}
                                  </div>
                                );
                              })()}

                              {/* Slippage strip between POR and actual */}
                              {showPor && (() => {
                                const variances = getPhaseVariance(launch, track).filter(
                                  (v) => v.deltaDays !== undefined && v.deltaDays !== 0 && v.actualExit,
                                );
                                type Item = { v: typeof variances[number]; pct: number };
                                const items: Item[] = [];
                                for (const v of variances) {
                                  const porDate = new Date(v.porExit + "T00:00:00Z");
                                  const actDate = new Date(v.actualExit! + "T00:00:00Z");
                                  const refDate = v.deltaDays! > 0 ? actDate : porDate;
                                  if (refDate < start || refDate > end) continue;
                                  items.push({ v, pct: pctBetween(refDate, start, end) });
                                }
                                items.sort((a, b) => b.pct - a.pct);
                                const kept: Item[] = [];
                                for (const it of items) {
                                  if (kept.some((k) => Math.abs(k.pct - it.pct) < 4)) continue;
                                  kept.push(it);
                                }
                                return (
                                  <div className="relative h-3">
                                    {kept.map(({ v, pct }) => (
                                      <span
                                        key={`slip-${v.phase}`}
                                        className="absolute top-0 h-3 inline-flex items-center text-caption tabular-nums leading-none pointer-events-none"
                                        style={{ left: `${pct}%`, transform: "translateX(-50%)", color: "#B86B32" }}
                                        title={`${track} · ${v.phase}: POR ${v.porExit} → Actual ${v.actualExit} (${formatDelta(v.deltaDays)})`}
                                      >
                                        {formatDelta(v.deltaDays!)}
                                      </span>
                                    ))}
                                  </div>
                                );
                              })()}

                              {/* Actual bar — full-height, segmented per phase, shifted by actualExit slips */}
                              {(() => {
                                const variances = showPor ? getPhaseVariance(launch, track) : [];
                                const actualByPhase = new Map(variances.map((v) => [v.phase, v.actualExit]));
                                let prevActualEnd: Date | null = null;
                                return (
                                  <div className="relative h-5 rounded-sm bg-muted overflow-hidden">
                                    {phases.map((p, i) => {
                                      if (onlyCurrentPhase && i !== currentIdx) return null;
                                      let aStart = p.start;
                                      let aEnd = p.end;
                                      if (showPor) {
                                        const actExitIso = actualByPhase.get(p.name);
                                        aStart = prevActualEnd ?? p.start;
                                        aEnd = actExitIso ? new Date(actExitIso + "T00:00:00Z") : p.end;
                                        prevActualEnd = aEnd;
                                      }
                                      const left = pctBetween(aStart, start, end);
                                      const right = pctBetween(aEnd, start, end);
                                      const width = Math.max(0, right - left);
                                      if (width <= 0) return null;
                                      return (
                                        <div
                                          key={p.name}
                                          className={cn(
                                            "absolute top-0 bottom-0 flex items-center justify-center px-2 border-r border-surface last:border-r-0",
                                            phaseStatusClass(i, currentIdx, fnStatus)
                                          )}
                                          style={{ left: `${left}%`, width: `${width}%` }}
                                          title={`${track} · ${p.name}: ${aStart.toISOString().slice(0, 10)} → ${aEnd.toISOString().slice(0, 10)}`}
                                        >
                                          {width > 3 && (
                                            <span className="text-caption font-medium text-primary-foreground truncate">
                                              {p.name}
                                              {i === currentIdx && ` · ${phaseCompletionPct(launch, track, p.name, today)}%`}
                                            </span>
                                          )}
                                        </div>
                                      );
                                    })}
                                  </div>
                                );
                              })()}
                            </div>
                          </div>

                        </Fragment>
                      );
                    })}
                    {/* Gridlines + today marker — overlay scoped to this gantt block only */}
                    <div
                      className="absolute top-0 bottom-0 pointer-events-none z-0"
                      style={{ left: PLATFORM_COL_WIDTH, width: totalWidth }}
                    >
                      {ticks.map((_, i) => (
                        <div
                          key={i}
                          className="absolute top-0 bottom-0 w-px bg-border/60"
                          style={{ left: i * PX_PER_MONTH }}
                        />
                      ))}
                      <div
                        className="absolute top-0 bottom-0 w-0 border-l-2 border-dashed border-primary z-10"
                        style={{ left: `${todayPct}%` }}
                        aria-label="Today"
                      />
                    </div>
                  </div>
                </div>
                );
              })}
            </div>
          </div>
        </div>

      </CardContent>
      {footer && <div className="border-t border-border">{footer}</div>}
      {editLaunch && (
        <MilestoneChangeDialog
          launch={editLaunch}
          open={!!editLaunch}
          onOpenChange={(o) => { if (!o) setEditLaunch(null); }}
        />
      )}
      <PlatformReviewDrawer
        request={drawerLaunch ? launchToPending(drawerLaunch) : null}
        open={!!drawerLaunch}
        onOpenChange={(o) => { if (!o) setDrawerLaunch(null); }}
      />
      <DashboardDetailDrawer
        open={!!coreDrawer}
        onOpenChange={(o) => { if (!o) setCoreDrawer(null); }}
        eyebrow="OLP schedule"
        title={`Core team · ${coreDrawer?.name ?? ""}`}
      >
        <DrawerEmpty>Core team detail coming soon.</DrawerEmpty>
      </DashboardDetailDrawer>
      </Card>
    </div>
  );
}

