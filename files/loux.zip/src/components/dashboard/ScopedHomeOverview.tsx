import { useRef, useState } from "react";
import { SharePdfButton } from "@/components/shell/SharePdfButton";
import { WatchlistPanel } from "@/components/dashboard/WatchlistPanel";
import { PageHeader } from "@/components/shell/PageHeader";
import { useViewFilter } from "@/contexts/ViewFilterContext";
import { useRole } from "@/contexts/RoleContext";
import { launches as ALL_LAUNCHES } from "@/mocks/launches";
import { HomeWorkspace, HomeStack } from "@/components/dashboard/HomeWorkspace";
import { DdsGrid, DdsCol } from "@/components/layout/DdsGrid";
import { PortfolioMetrics } from "@/components/dashboard/PortfolioMetrics";
import { CurrentPhaseDonut } from "@/components/dashboard/CurrentPhaseDonut";
import { PhaseStatusCard } from "@/components/dashboard/PhaseStatusCard";
import { PhaseStatusReportView } from "@/components/dashboard/PhaseStatusReportView";
import { TaskQueue } from "@/components/dashboard/TaskQueue";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Card, CardHeader, CardContent } from "@/components/ui/card";

import { PendingPlatformsCard } from "@/components/dashboard/PendingPlatformsCard";
import { RequestPlatformCard } from "@/components/dashboard/RequestPlatformCard";
import { StatusRequestsCard } from "@/components/dashboard/StatusRequestsCard";


type Props = {
  eyebrowRole: string;
};

export function ScopedHomeOverview({ eyebrowRole }: Props) {
  const { lockedPlatformIds } = useViewFilter();
  const { role } = useRole();
  const [tab, setTab] = useState<"action-items" | "portfolio" | "report" | "watchlist">("action-items");
  const portfolioRef = useRef<HTMLDivElement>(null);
  const reportRef = useRef<HTMLDivElement>(null);


  let scopeLabel = "All platforms";
  if (lockedPlatformIds && lockedPlatformIds.length > 0) {
    if (lockedPlatformIds.length === 1) {
      const l = ALL_LAUNCHES.find((x) => x.id === lockedPlatformIds[0]);
      scopeLabel = l?.name ?? "1 platform";
    } else {
      scopeLabel = `${lockedPlatformIds.length} platforms`;
    }
  }

  return (
    <div className="space-y-8">
      <PageHeader eyebrow={`${eyebrowRole} · ${scopeLabel}`} title="Home" description="View your portfolio, reports, and open action items" />
      <HomeWorkspace>
        <HomeStack>
          <Tabs value={tab} onValueChange={(v) => setTab(v as typeof tab)}>
            <TabsList>
              <TabsTrigger value="action-items">Action items</TabsTrigger>
              <TabsTrigger value="portfolio">Summary</TabsTrigger>
              <TabsTrigger value="report">Report</TabsTrigger>
              <TabsTrigger value="watchlist" className="gap-2">
                Watchlist
                <span className="shrink-0 rounded-full border border-border bg-muted px-2 py-0.5 text-caption text-muted-foreground">
                  Post-MVP
                </span>
              </TabsTrigger>
            </TabsList>
            <TabsContent value="action-items" className="space-y-4 mt-6">
              <h2 className="text-h4 text-foreground">My action items</h2>
              
              {(role === "admin" || role === "superadmin") && <PendingPlatformsCard />}
              {role !== "executive" ? (
                <DdsGrid>
                  <DdsCol span={6} spanM={6} spanS={6} spanXs={2}>
                    <TaskQueue />
                  </DdsCol>
                  <DdsCol span={6} spanM={6} spanS={6} spanXs={2}>
                    <StatusRequestsCard />
                  </DdsCol>
                </DdsGrid>
              ) : (
                <TaskQueue />
              )}
            </TabsContent>
            <TabsContent value="portfolio" className="space-y-4 mt-6">
              <div className="flex items-center justify-between gap-4">
                <h2 className="text-h4 text-foreground">Portfolio overview</h2>
                <SharePdfButton targetRef={portfolioRef} title="Portfolio overview" filenameSlug="portfolio-overview" />
              </div>
              <div ref={portfolioRef} className="space-y-4">
                <DdsGrid>
                  <DdsCol span={6} spanM={6} spanS={6} spanXs={2} className="h-full">
                    <CurrentPhaseDonut />
                  </DdsCol>
                  <DdsCol span={6} spanM={6} spanS={6} spanXs={2} className="h-full">
                    <PortfolioMetrics />
                  </DdsCol>
                </DdsGrid>
                <PhaseStatusCard />
              </div>
            </TabsContent>
            <TabsContent value="report" className="space-y-4 mt-6">
              <div className="flex items-center justify-between gap-4">
                <h2 className="text-h4 text-foreground">Phase gate status report</h2>
                <SharePdfButton targetRef={reportRef} title="Phase gate status report" filenameSlug="phase-gate-status-report" />
              </div>
              <div ref={reportRef}>
                <PhaseStatusReportView />
              </div>
            </TabsContent>
            <TabsContent value="watchlist" className="space-y-4 mt-6">
              <WatchlistPanel />
            </TabsContent>
          </Tabs>
        </HomeStack>
      </HomeWorkspace>
    </div>
  );
}

