// Slide-over approval queue for status-change + completion requests.
// Admin / Superadmin only. Users see their own submissions read-only.
import { useEffect, useState } from "react";
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
} from "@/components/ui/sheet";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import {
  approveStatusChangeRequest,
  listStatusChangeRequests,
  rejectStatusChangeRequest,
  subscribeStatusChangeRequests,
  type StatusChangeRequest,
} from "@/mocks/statusChangeRequests";
import {
  approveCompletionRequest,
  listCompletionRequests,
  rejectCompletionRequest,
  subscribeCompletionRequests,
  type CompletionRequest,
} from "@/mocks/completionRequests";
import { launches as ALL_LAUNCHES } from "@/mocks/launches";
import { useCurrentUserName } from "@/lib/currentUser";
import { useRole } from "@/contexts/RoleContext";
import { canApproveStatusChange } from "@/lib/permissions";
import { cn } from "@/lib/utils";
import { DdsPagination } from "@/components/shell/DdsPagination";

function launchName(id: string): string {
  return ALL_LAUNCHES.find((l) => l.id === id)?.name ?? id;
}

function relTime(ms: number): string {
  if (!ms) return "—";
  const diff = Date.now() - ms;
  const min = Math.max(0, Math.round(diff / 60000));
  if (min < 1) return "just now";
  if (min < 60) return `${min} min ago`;
  const hr = Math.round(min / 60);
  if (hr < 24) return `${hr}h ago`;
  const d = Math.round(hr / 24);
  return d === 1 ? "Yesterday" : `${d}d ago`;
}

const TONE: Record<string, string> = {
  pending: "bg-status-at-risk-mitigated text-primary-foreground",
  approved: "bg-status-on-track text-primary-foreground",
  rejected: "bg-status-at-risk text-primary-foreground",
};

const TARGET_LABEL: Record<string, string> = {
  "at-risk": "At risk",
  "at-risk-mitigated": "At risk (mitigated)",
  "on-track": "On track",
};

function StatusChangeCard({
  req,
  canAct,
  reviewer,
}: {
  req: StatusChangeRequest;
  canAct: boolean;
  reviewer: string;
}) {
  const [note, setNote] = useState("");
  return (
    <div className="rounded-md border border-border bg-surface p-3 space-y-2">
      <div className="flex items-start justify-between gap-2">
        <div className="min-w-0">
          <p className="text-body-3 font-medium text-foreground truncate">
            {req.taskName} → {TARGET_LABEL[req.toStatus] ?? req.toStatus}
          </p>
          <p className="text-caption text-muted-foreground">
            {launchName(req.launchId)} · {req.requestedBy} · {relTime(req.requestedAt)}
          </p>
        </div>
        <Badge className={cn("text-caption", TONE[req.state])}>{req.state}</Badge>
      </div>
      <div className="text-caption text-muted-foreground space-y-1">
        <p><span className="text-foreground">Root cause:</span> {req.issueDescription}</p>
        <p><span className="text-foreground">Business impact:</span> {req.businessImpact}</p>
        <p><span className="text-foreground">Action required:</span> {req.mitigationPlan}</p>
        <p><span className="text-foreground">Owner:</span> {req.owner} · <span className="text-foreground">Due:</span> {req.dueDate}</p>
      </div>
      {req.state === "pending" && canAct && (
        <div className="space-y-2 pt-2">
          <Textarea
            placeholder="Reviewer note (optional)"
            value={note}
            onChange={(e) => setNote(e.target.value)}
            maxLength={400}
            className="text-caption"
          />
          <div className="flex gap-2">
            <Button
              size="sm"
              variant="outline"
              onClick={() => rejectStatusChangeRequest(req.id, reviewer, note || undefined)}
            >
              Reject
            </Button>
            <Button
              size="sm"
              onClick={() => approveStatusChangeRequest(req.id, reviewer, note || undefined)}
            >
              Approve
            </Button>
          </div>
        </div>
      )}
      {req.state !== "pending" && req.reviewerNote && (
        <p className="text-caption text-muted-foreground">Note: {req.reviewerNote}</p>
      )}
    </div>
  );
}

function CompletionCard({
  req,
  canAct,
  reviewer,
}: {
  req: CompletionRequest;
  canAct: boolean;
  reviewer: string;
}) {
  const [note, setNote] = useState("");
  return (
    <div className="rounded-md border border-border bg-surface p-3 space-y-2">
      <div className="flex items-start justify-between gap-2">
        <div className="min-w-0">
          <p className="text-body-3 font-medium text-foreground truncate">
            Complete: {req.taskName}
          </p>
          <p className="text-caption text-muted-foreground">
            {launchName(req.launchId)} · {req.requestedBy} · {relTime(req.requestedAt)}
          </p>
        </div>
        <Badge className={cn("text-caption", TONE[req.state])}>{req.state}</Badge>
      </div>
      <div className="text-caption text-muted-foreground space-y-1">
        <p><span className="text-foreground">Note:</span> {req.completionNote}</p>
        {req.evidenceLink && (
          <p><span className="text-foreground">Evidence:</span> {req.evidenceLink}</p>
        )}
        <p><span className="text-foreground">Owner:</span> {req.owner}</p>
      </div>
      {req.state === "pending" && canAct && (
        <div className="space-y-2 pt-2">
          <Textarea
            placeholder="Reviewer note (optional)"
            value={note}
            onChange={(e) => setNote(e.target.value)}
            maxLength={400}
            className="text-caption"
          />
          <div className="flex gap-2">
            <Button
              size="sm"
              variant="outline"
              onClick={() => rejectCompletionRequest(req.id, reviewer, note || undefined)}
            >
              Reject
            </Button>
            <Button
              size="sm"
              onClick={() => approveCompletionRequest(req.id, reviewer, note || undefined)}
            >
              Approve
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}

type Row =
  | { kind: "status"; id: string; req: StatusChangeRequest }
  | { kind: "completion"; id: string; req: CompletionRequest };

const STATE_BADGE: Record<string, string> = {
  approved: "bg-status-on-track text-primary-foreground",
  rejected: "bg-status-at-risk text-primary-foreground",
};

function rowTitle(r: Row): string {
  if (r.kind === "status") {
    return `${r.req.taskName} → ${TARGET_LABEL[r.req.toStatus] ?? r.req.toStatus}`;
  }
  return `Complete: ${r.req.taskName}`;
}

function rowMeta(r: Row): string {
  const req = r.req;
  return `${launchName(req.launchId)} · ${req.requestedBy} · ${relTime(req.requestedAt)}`;
}

function ReviewRequestDialog({
  row,
  onClose,
  reviewer,
}: {
  row: Row | null;
  onClose: () => void;
  reviewer: string;
}) {
  const [note, setNote] = useState("");
  useEffect(() => {
    setNote("");
  }, [row?.id]);
  if (!row) return null;
  const req = row.req;
  const approve = () => {
    if (row.kind === "status") approveStatusChangeRequest(req.id, reviewer, note || undefined);
    else approveCompletionRequest(req.id, reviewer, note || undefined);
    onClose();
  };
  const reject = () => {
    if (row.kind === "status") rejectStatusChangeRequest(req.id, reviewer, note || undefined);
    else rejectCompletionRequest(req.id, reviewer, note || undefined);
    onClose();
  };
  return (
    <Sheet open={!!row} onOpenChange={(o) => !o && onClose()}>
      <SheetContent side="right" className="w-full sm:max-w-md flex flex-col gap-0">
        <SheetHeader>
          <SheetTitle>{rowTitle(row)}</SheetTitle>
          <SheetDescription>{rowMeta(row)}</SheetDescription>
        </SheetHeader>
        <div className="flex-1 overflow-y-auto mt-4 space-y-3 text-caption text-muted-foreground">
          {row.kind === "status" ? (
            <>
              <p><span className="text-foreground">Root cause:</span> {(req as StatusChangeRequest).issueDescription}</p>
              <p><span className="text-foreground">Business impact:</span> {(req as StatusChangeRequest).businessImpact}</p>
              <p><span className="text-foreground">Action required:</span> {(req as StatusChangeRequest).mitigationPlan}</p>
              <p><span className="text-foreground">Owner:</span> {(req as StatusChangeRequest).owner} · <span className="text-foreground">Due:</span> {(req as StatusChangeRequest).dueDate}</p>
            </>
          ) : (
            <>
              <p><span className="text-foreground">Note:</span> {(req as CompletionRequest).completionNote}</p>
              {(req as CompletionRequest).evidenceLink && (
                <p><span className="text-foreground">Evidence:</span> {(req as CompletionRequest).evidenceLink}</p>
              )}
              <p><span className="text-foreground">Owner:</span> {(req as CompletionRequest).owner}</p>
            </>
          )}
          <Textarea
            placeholder="Reviewer note (optional)"
            value={note}
            onChange={(e) => setNote(e.target.value)}
            maxLength={400}
            className="text-caption"
          />
        </div>
        <div className="flex gap-2 mt-4 pt-4 border-t border-border">
          <Button variant="outline" onClick={reject}>Reject</Button>
          <Button onClick={approve}>Approve</Button>
        </div>
      </SheetContent>
    </Sheet>
  );
}

export function StatusRequestsPanel({ className }: { className?: string }) {
  const reviewer = useCurrentUserName();
  const { role } = useRole();
  const canAct = canApproveStatusChange(role);
  const [reviewing, setReviewing] = useState<Row | null>(null);
  const [pendingPage, setPendingPage] = useState(1);
  const [pendingPageSize, setPendingPageSize] = useState(10);
  const [completedPage, setCompletedPage] = useState(1);
  const [completedPageSize, setCompletedPageSize] = useState(10);

  const [, force] = useState(0);
  useEffect(() => {
    const a = subscribeStatusChangeRequests(() => force((n) => n + 1));
    const b = subscribeCompletionRequests(() => force((n) => n + 1));
    return () => { a(); b(); };
  }, []);

  const scrs = listStatusChangeRequests();
  const crs = listCompletionRequests().filter((r) => !r.systemSeeded);
  const visibleScrs = canAct ? scrs : scrs.filter((r) => r.requestedBy === reviewer);
  const visibleCrs = canAct ? crs : crs.filter((r) => r.requestedBy === reviewer);

  const allRows: Row[] = [
    ...visibleScrs.map<Row>((req) => ({ kind: "status", id: req.id, req })),
    ...visibleCrs.map<Row>((req) => ({ kind: "completion", id: req.id, req })),
  ].sort((a, b) => b.req.requestedAt - a.req.requestedAt);

  const pendingRows = allRows.filter((r) => r.req.state === "pending");
  const completedRows = allRows.filter((r) => r.req.state !== "pending");
  const pagedPending = pendingRows.slice((pendingPage - 1) * pendingPageSize, pendingPage * pendingPageSize);
  const pagedCompleted = completedRows.slice((completedPage - 1) * completedPageSize, completedPage * completedPageSize);

  return (
    <div className={cn("flex flex-col", className)}>
      <Tabs defaultValue="pending" className="flex-1 flex flex-col">
        <TabsList>
          <TabsTrigger value="pending" className="px-4 py-2 text-button-1">
            To do
            {pendingRows.length > 0 && <Badge className="ml-2">{pendingRows.length}</Badge>}
          </TabsTrigger>
          <TabsTrigger value="completed" className="px-4 py-2 text-button-1">Completed</TabsTrigger>
        </TabsList>


        <TabsContent value="pending" className="flex-1 mt-3 flex flex-col">
          {pendingRows.length === 0 ? (
            <p className="text-caption text-muted-foreground p-4 text-center">
              No to-do requests.
            </p>
          ) : (
            <>
              <div className="space-y-2 overflow-y-auto max-h-[480px]">
                {pagedPending.map((r) => (
                  <div
                    key={r.id}
                    className="rounded-md border border-border bg-surface p-3 flex items-start justify-between gap-3"
                  >
                    <div className="min-w-0">
                      <p className="text-body-3 font-medium text-foreground truncate">
                        {rowTitle(r)}
                      </p>
                      <p className="text-caption text-muted-foreground">{rowMeta(r)}</p>
                    </div>
                    {canAct && (
                      <Button size="sm" onClick={() => setReviewing(r)}>
                        Review
                      </Button>
                    )}
                  </div>
                ))}
              </div>
              <div className="border-t border-border pt-3 mt-3">
                <DdsPagination
                  page={pendingPage}
                  pageSize={pendingPageSize}
                  totalItems={pendingRows.length}
                  itemLabel="requests"
                  onPageChange={setPendingPage}
                  onPageSizeChange={setPendingPageSize}
                />
              </div>
            </>
          )}
        </TabsContent>

        <TabsContent value="completed" className="flex-1 mt-3 flex flex-col">
          {completedRows.length === 0 ? (
            <p className="text-caption text-muted-foreground p-4 text-center">
              No completed requests.
            </p>
          ) : (
            <>
              <div className="space-y-2 overflow-y-auto max-h-[480px]">
                {pagedCompleted.map((r) => (
                  <div
                    key={r.id}
                    className="rounded-md border border-border bg-surface p-3 space-y-1"
                  >
                    <div className="flex items-start justify-between gap-3">
                      <div className="min-w-0">
                        <p className="text-body-3 font-medium text-foreground truncate">
                          {rowTitle(r)}
                        </p>
                        <p className="text-caption text-muted-foreground">{rowMeta(r)}</p>
                      </div>
                      <Badge className={cn("text-caption capitalize", STATE_BADGE[r.req.state])}>
                        {r.req.state === "approved" ? "Approved" : "Rejected"}
                      </Badge>
                    </div>
                    {r.req.reviewerNote && (
                      <p className="text-caption text-muted-foreground">
                        Reviewer note: {r.req.reviewerNote}
                      </p>
                    )}
                  </div>
                ))}
              </div>
              <div className="border-t border-border pt-3 mt-3">
                <DdsPagination
                  page={completedPage}
                  pageSize={completedPageSize}
                  totalItems={completedRows.length}
                  itemLabel="requests"
                  onPageChange={setCompletedPage}
                  onPageSizeChange={setCompletedPageSize}
                />
              </div>
            </>
          )}
        </TabsContent>
      </Tabs>

      <ReviewRequestDialog
        row={reviewing}
        onClose={() => setReviewing(null)}
        reviewer={reviewer}
      />
    </div>
  );
}


export function StatusChangeRequestsDrawer({
  open,
  onOpenChange,
}: {
  open: boolean;
  onOpenChange: (o: boolean) => void;
}) {
  const { role } = useRole();
  const canAct = canApproveStatusChange(role);
  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent side="right" className="w-full sm:max-w-md flex flex-col gap-0">
        <SheetHeader>
          <SheetTitle>Approval requests</SheetTitle>
          <SheetDescription>
            {canAct
              ? "Review and approve status-change or completion requests."
              : "Your submitted requests awaiting manager review."}
          </SheetDescription>
        </SheetHeader>
        <StatusRequestsPanel className="flex-1 mt-4" />
      </SheetContent>
    </Sheet>
  );
}

