import { cn } from "@/lib/utils";

interface Props {
  className?: string;
}

const ITEMS = [
  { cls: "bg-status-completed", label: "Completed" },
  { cls: "bg-status-on-track", label: "Achieved / on track" },
  { cls: "bg-status-at-risk-mitigated", label: "Risk with mitigation" },
  { cls: "bg-status-at-risk", label: "Missed / no mitigation plan" },
  { cls: "bg-status-not-started", label: "Not started" },
];

/** Shared 5-dot status legend used across Task manager surfaces. */
export function StatusLegend({ className }: Props) {
  return (
    <div className={cn("flex flex-wrap items-center gap-x-4 gap-y-2", className)}>
      {ITEMS.map((s) => (
        <span
          key={s.label}
          className="inline-flex items-center gap-2 text-caption text-muted-foreground"
        >
          <span className={cn("h-2 w-2 rounded-full", s.cls)} aria-hidden />
          {s.label}
        </span>
      ))}
    </div>
  );
}
