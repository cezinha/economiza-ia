// Inline Status requests card surfaced under Action items on the Home page.
// Admin/Superadmin: full approval panel with tabs.
// User: flat list of their own submitted requests (status-change + completion).
import { useEffect, useState } from "react";
import { StatusRequestsPanel } from "@/components/dashboard/StatusChangeRequestsDrawer";
import { useRole } from "@/contexts/RoleContext";
import { canApproveStatusChange } from "@/lib/permissions";
import { useCurrentUserName } from "@/lib/currentUser";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { cn } from "@/lib/utils";
import {
  listStatusChangeRequests,
  subscribeStatusChangeRequests,
} from "@/mocks/statusChangeRequests";
import {
  listCompletionRequests,
  subscribeCompletionRequests,
} from "@/mocks/completionRequests";
import { launches as ALL_LAUNCHES } from "@/mocks/launches";

const TONE: Record<string, string> = {
  pending: "bg-status-at-risk-mitigated text-primary-foreground",
  approved: "bg-status-on-track text-primary-foreground",
  rejected: "bg-status-at-risk text-primary-foreground",
};

function launchName(id: string): string {
  return ALL_LAUNCHES.find((l) => l.id === id)?.name ?? id;
}

function relTime(ms: number): string {
  if (!ms) return "—";
  const diff = Date.now() - ms;
  const min = Math.max(0, Math.round(diff / 60000));
  if (min < 1) return "just now";
  if (min < 60) return `${min} min ago`;
  const hr = Math.round(min / 60);
  if (hr < 24) return `${hr}h ago`;
  const d = Math.round(hr / 24);
  return d === 1 ? "Yesterday" : `${d}d ago`;
}

type Row = {
  id: string;
  kind: "status" | "completion";
  title: string;
  launchId: string;
  state: string;
  requestedAt: number;
  reviewerNote?: string;
};

function SubmittedRequestsList({ user }: { user: string }) {
  const [, force] = useState(0);
  useEffect(() => {
    const a = subscribeStatusChangeRequests(() => force((n) => n + 1));
    const b = subscribeCompletionRequests(() => force((n) => n + 1));
    return () => { a(); b(); };
  }, []);

  const TARGET_LABEL: Record<string, string> = {
    "at-risk": "At risk",
    "at-risk-mitigated": "At risk (mitigated)",
    "on-track": "On track",
  };

  const rows: Row[] = [
    ...listStatusChangeRequests()
      .filter((r) => r.requestedBy === user)
      .map<Row>((r) => ({
        id: r.id,
        kind: "status",
        title: `${r.taskName} → ${TARGET_LABEL[r.toStatus] ?? r.toStatus}`,
        launchId: r.launchId,
        state: r.state,
        requestedAt: r.requestedAt,
        reviewerNote: r.reviewerNote,
      })),
    ...listCompletionRequests()
      .filter((r) => !r.systemSeeded && r.requestedBy === user)
      .map<Row>((r) => ({
        id: r.id,
        kind: "completion",
        title: `Complete: ${r.taskName}`,
        launchId: r.launchId,
        state: r.state,
        requestedAt: r.requestedAt,
        reviewerNote: r.reviewerNote,
      })),
  ].sort((a, b) => b.requestedAt - a.requestedAt);

  if (rows.length === 0) {
    return (
      <p className="text-caption text-muted-foreground p-4 text-center">
        No submitted requests.
      </p>
    );
  }

  return (
    <div className="space-y-2 max-h-[480px] overflow-y-auto">
      {rows.map((r) => (
        <div
          key={r.id}
          className="rounded-md border border-border bg-surface p-3 space-y-1"
        >
          <div className="flex items-start justify-between gap-2">
            <div className="min-w-0">
              <p className="text-body-3 font-medium text-foreground truncate">
                {r.title}
              </p>
              <p className="text-caption text-muted-foreground">
                {launchName(r.launchId)} · {relTime(r.requestedAt)}
              </p>
            </div>
            <Badge className={cn("text-caption", TONE[r.state])}>{r.state}</Badge>
          </div>
          {r.reviewerNote && (
            <p className="text-caption text-muted-foreground">
              Reviewer note: {r.reviewerNote}
            </p>
          )}
        </div>
      ))}
    </div>
  );
}

export function StatusRequestsCard() {
  const { role } = useRole();
  const canAct = canApproveStatusChange(role);
  const user = useCurrentUserName();
  return (
    <Card className="border-border bg-surface shadow-elev-1 flex flex-col h-full">
      <CardHeader className="pb-4">
        <h5 className="text-h5 text-foreground">Approval requests</h5>
        <p className="text-caption text-muted-foreground">
          {canAct
            ? "Review and approve status or schedule change requests"
            : "Your submitted requests awaiting manager review"}
        </p>
      </CardHeader>
      <CardContent className="flex-1 flex flex-col">
        {canAct ? <StatusRequestsPanel className="flex-1" /> : <SubmittedRequestsList user={user} />}
      </CardContent>
    </Card>
  );
}
