// Renders inline (no outer Card) — meant to sit inside the ScheduleDrilldown card footer.
import { DdsGrid, DdsCol } from "@/components/layout/DdsGrid";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { functionStatus, platformStatus, type TaskStatus } from "@/lib/launchTasks";
import type { Launch } from "@/mocks/launches";
import type { ScheduleTrack } from "@/lib/schedule";
import { effectiveLaunchDate } from "@/mocks/launchDateOverrides";
import { cn } from "@/lib/utils";
import { getPhaseVariance, VARIANCE_TONE, VARIANCE_LABEL, formatDelta } from "@/lib/porVariance";
import { PorVarianceChart } from "@/components/dashboard/PorVarianceChart";


const STATUS_CLASS: Record<TaskStatus, string> = {
  completed: "bg-status-completed",
  "on-track": "bg-status-on-track",
  "at-risk-mitigated": "bg-status-at-risk-mitigated",
  "at-risk": "bg-status-at-risk",
  "not-started": "bg-status-not-started",
};

const STATUS_LABEL: Record<TaskStatus, string> = {
  completed: "Completed",
  "on-track": "On track",
  "at-risk-mitigated": "At risk · mitigation in place",
  "at-risk": "At risk · no mitigation",
  "not-started": "Not started",
};

const TRACKS: { id: ScheduleTrack; label: string }[] = [
  { id: "Core", label: "Core team" },
  { id: "GOE", label: "GOE" },
  { id: "NPI", label: "NPI" },
  { id: "SChM", label: "SChM" },
];

function StatusDot({ status }: { status: TaskStatus }) {
  return <span className={cn("inline-block h-2 w-2 rounded-full shrink-0", STATUS_CLASS[status])} aria-hidden />;
}

function trackNote(status: TaskStatus, label: string): string {
  switch (status) {
    case "at-risk":
      return `${label} status flagged — no mitigation plan recorded yet.`;
    case "at-risk-mitigated":
      return `${label} status flagged — mitigation plan in flight.`;
    case "completed":
      return `${label} workstream complete for current phase.`;
    case "not-started":
      return `${label} workstream not yet started for current phase.`;
    default:
      return `${label} workstream tracking on plan.`;
  }
}

function platformNote(status: TaskStatus, launch: Launch): string {
  const rts = effectiveLaunchDate(launch);
  switch (status) {
    case "at-risk":
      return `Program status Red: open issues across one or more functions with no mitigation plan. RTS ${rts} at risk.`;
    case "at-risk-mitigated":
      return `Program status Yellow: active mitigation underway. Weekly tracking and status reporting at BRM. RTS ${rts}.`;
    case "completed":
      return `Program complete. RTS ${rts} achieved.`;
    case "not-started":
      return `Program not yet started. RTS ${rts}.`;
    default:
      return `Program status Green: all functions tracking on plan toward RTS ${rts}.`;
  }
}

interface IssueRow {
  challenge: string;
  impact: string;
  severity: 1 | 2 | 3;
  rootCause: string;
  action: string;
  owner: string;
}

function placeholderIssues(launch: Launch): IssueRow[] {
  const status = platformStatus(launch);
  if (status === "on-track" || status === "completed") {
    return [
      {
        challenge: "No active escalations.",
        impact: "—",
        severity: 3,
        rootCause: "—",
        action: "Continue weekly tracking at BRM.",
        owner: "Core team",
      },
    ];
  }
  return [
    {
      challenge: `Material/readiness risk impacting ${launch.name} launch plan.`,
      impact: "Low DSI for RTS based on the current supply / demand outlook.",
      severity: status === "at-risk" ? 1 : 2,
      rootCause: "Industry demand shift causing supply constraints on key components.",
      action: "Core team to finalize qualification plan for 2nd source; pull-in primary supply.",
      owner: "Core team · " + effectiveLaunchDate(launch),
    },
  ];
}

const SEVERITY_TONE: Record<1 | 2 | 3, string> = {
  1: "bg-status-at-risk text-primary-foreground",
  2: "bg-status-at-risk-mitigated text-primary-foreground",
  3: "bg-status-on-track text-primary-foreground",
};

export function StatusUpdateReport({ launch }: { launch: Launch }) {
  const olp = platformStatus(launch);
  const issues = placeholderIssues(launch);

  return (
    <div className="bg-surface">
      <div className="p-4 pt-2 space-y-6">
        <DdsGrid>
          <DdsCol span={12} spanM={3} spanS={3} spanXs={2}>
            <section className="space-y-2">
              <h6 className="text-subtitle-2 text-foreground">OLP status</h6>
              <div className="flex items-center gap-2">
                <StatusDot status={olp} />
                <span className="text-body-3 text-foreground">{STATUS_LABEL[olp]}</span>
              </div>
              <p className="text-body-3 text-muted-foreground">{platformNote(olp, launch)}</p>
            </section>
          </DdsCol>
          <DdsCol span={12} spanM={3} spanS={3} spanXs={2}>
            <section className="space-y-2">
              <h6 className="text-subtitle-2 text-foreground">Phase gate status</h6>
              <ul className="space-y-2">
                {TRACKS.map((t) => {
                  const s = functionStatus(launch, t.id);
                  return (
                    <li key={t.id} className="flex items-start gap-2">
                      <span className="mt-2"><StatusDot status={s} /></span>
                      <div className="min-w-0">
                        <div className="text-body-3 text-foreground">
                          {t.label} · <span className="text-muted-foreground">{STATUS_LABEL[s]}</span>
                        </div>
                        <p className="text-caption text-muted-foreground">{trackNote(s, t.label)}</p>
                      </div>
                    </li>
                  );
                })}
              </ul>
            </section>
          </DdsCol>
        </DdsGrid>


        <section className="space-y-2">
          <h6 className="text-subtitle-2 text-foreground">Key challenges &amp; actions</h6>
          <div className="overflow-x-auto rounded-md border border-border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="text-caption">Key challenges / escalations</TableHead>
                  <TableHead className="text-caption">Business impacts</TableHead>
                  <TableHead className="text-caption">Severity</TableHead>
                  <TableHead className="text-caption">Root causes</TableHead>
                  <TableHead className="text-caption">Action required</TableHead>
                  <TableHead className="text-caption">Owner / due</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {issues.map((row, i) => (
                  <TableRow key={i}>
                    <TableCell className="text-body-3 align-top">{row.challenge}</TableCell>
                    <TableCell className="text-body-3 align-top">{row.impact}</TableCell>
                    <TableCell className="align-top">
                      <Badge className={cn("text-caption", SEVERITY_TONE[row.severity])}>{row.severity}</Badge>
                    </TableCell>
                    <TableCell className="text-body-3 align-top">{row.rootCause}</TableCell>
                    <TableCell className="text-body-3 align-top">{row.action}</TableCell>
                    <TableCell className="text-body-3 align-top">{row.owner}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </section>

      </div>
    </div>
  );
}
