import { Lock, CheckCircle2 } from "lucide-react";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { cn } from "@/lib/utils";
import type { LaunchTask, TaskStatus } from "@/lib/launchTasks";

const STATUS_DOT: Record<TaskStatus, string> = {
  completed: "bg-status-completed",
  "on-track": "bg-status-on-track",
  "at-risk-mitigated": "bg-status-at-risk-mitigated",
  "at-risk": "bg-status-at-risk",
  "not-started": "bg-status-not-started",
};

interface BlockerRef {
  task: LaunchTask;
  status: TaskStatus;
}
interface ClearedRef {
  task: LaunchTask;
  clearedAt: Date;
}

interface Props {
  blockers: BlockerRef[];
  recentlyCleared: ClearedRef[];
  onClick?: () => void;
}

/**
 * Inline lock / readiness chip for a task row. Shows nothing when the task has
 * no actionable dependency state (no blockers and no recently cleared
 * predecessors).
 */
export function TaskDependencyChip({ blockers, recentlyCleared, onClick }: Props) {
  const handleClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    onClick?.();
  };

  if (blockers.length > 0) {
    const first = blockers[0];
    const more = blockers.length - 1;
    return (
      <TooltipProvider delayDuration={150}>
        <Tooltip>
          <TooltipTrigger asChild>
            <button
              type="button"
              onClick={handleClick}
              className="inline-flex items-center gap-1 rounded-sm bg-status-at-risk/10 text-status-at-risk px-2 py-1 text-body-3 font-medium hover:bg-status-at-risk/15 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
              aria-label={`Locked, waiting on task ${first.task.l3Id}`}
            >
              <Lock className="h-3 w-3" />
              <span>Locked · Waiting on #{first.task.l3Id}</span>
              {more > 0 && <span className="opacity-80">+{more}</span>}
            </button>
          </TooltipTrigger>
          <TooltipContent side="top" className="max-w-xs">
            <p className="text-caption font-medium mb-1">Blocked by</p>
            <ul className="space-y-1">
              {blockers.map((b) => (
                <li key={b.task.id} className="flex items-start gap-2 text-caption">
                  <span
                    className={cn(
                      "mt-1 inline-block h-2 w-2 rounded-full shrink-0",
                      STATUS_DOT[b.status],
                    )}
                    aria-hidden
                  />
                  <span>
                    <span className="font-medium">#{b.task.l3Id}</span> {b.task.task}
                  </span>
                </li>
              ))}
            </ul>
          </TooltipContent>
        </Tooltip>
      </TooltipProvider>
    );
  }

  if (recentlyCleared.length > 0) {
    const first = recentlyCleared[0];
    const more = recentlyCleared.length - 1;
    return (
      <TooltipProvider delayDuration={150}>
        <Tooltip>
          <TooltipTrigger asChild>
            <button
              type="button"
              onClick={handleClick}
              className="inline-flex items-center gap-1 rounded-sm bg-status-on-track/10 text-status-on-track px-2 py-1 text-body-3 font-medium hover:bg-status-on-track/15 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
              aria-label={`Ready, task ${first.task.l3Id} cleared`}
            >
              <CheckCircle2 className="h-3 w-3" />
              <span>Ready · #{first.task.l3Id} cleared</span>
              {more > 0 && <span className="opacity-80">+{more}</span>}
            </button>
          </TooltipTrigger>
          <TooltipContent side="top" className="max-w-xs">
            <p className="text-caption font-medium mb-1">Recently cleared</p>
            <ul className="space-y-1">
              {recentlyCleared.map((c) => (
                <li key={c.task.id} className="text-caption">
                  <span className="font-medium">#{c.task.l3Id}</span> {c.task.task}
                </li>
              ))}
            </ul>
          </TooltipContent>
        </Tooltip>
      </TooltipProvider>
    );
  }

  return null;
}
