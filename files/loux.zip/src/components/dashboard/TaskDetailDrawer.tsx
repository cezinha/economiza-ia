import { useEffect, useMemo, useRef, useState } from "react";
import { ChevronLeft, ExternalLink, Eye, File as FileIcon, Flag, Paperclip, X } from "lucide-react";
import { toast } from "sonner";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetDescription,
  SheetClose,
  SheetFooter,
} from "@/components/ui/sheet";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { cn } from "@/lib/utils";
import type { LaunchTask, TaskStatus } from "@/lib/launchTasks";
import { useIsReadOnly, canActOnPlatformInfo, useAssignedPlatformIds, useAssignedPlatformNames } from "@/lib/permissions";
import type { Launch } from "@/mocks/launches";
import {
  getTaskDetails,
  resolveDueDate,
  type TaskComment,
  type TaskOwner,
} from "@/mocks/taskDetails";
import { TaskHistorySection } from "./TaskHistorySection";
import { TaskRemindersRow } from "./TaskRemindersRow";
import { appendTaskHistory } from "@/mocks/taskHistory";
import {
  approveRequest,
  cancelRequest,
  createRequest,
  CURRENT_USER_NAME,
  formatRelative,
  pendingForTask,
  rejectRequest,
  subscribeAssignmentRequests,
  type AssignmentRequest,
} from "@/mocks/assignmentRequests";
import { useRole } from "@/contexts/RoleContext";
import { RunwayBanner, MinDurationTile, ExpeditedBanner } from "./RunwayBanner";
import { tasksForLaunch, isPhaseCloseTask } from "@/lib/launchTasks";

import { buildLaunchDependencyResolver } from "@/lib/taskDependencies";
// TaskDueBadge removed — consolidated into TaskRunwayChip "Warning" pill.
import { TaskRunwayChip } from "./TaskRunwayChip";
import { TaskExpeditedChip } from "./TaskExpeditedChip";
import { LiveRefreshIndicator } from "./LiveRefreshIndicator";
import {
  createStatusChangeRequest,
  directOverrideStatus,
  pendingStatusChangeForTask,
  type StatusChangeTarget,
} from "@/mocks/statusChangeRequests";
import {
  createCompletionRequest,
  pendingCompletionForTask,
} from "@/mocks/completionRequests";
import { canOverrideStatus } from "@/lib/permissions";
import { useCurrentUserName } from "@/lib/currentUser";

type Attachment = { id: string; name: string; size: number; type: string; addedAt: string };

const formatBytes = (n: number) => {
  if (n < 1024) return `${n} B`;
  if (n < 1024 * 1024) return `${(n / 1024).toFixed(1)} KB`;
  return `${(n / (1024 * 1024)).toFixed(1)} MB`;
};

const tokenize = (name: string) => name.replace(/\s+/g, "");

const STATUS_LABEL: Record<TaskStatus, string> = {
  completed: "Completed",
  "on-track": "On track",
  "at-risk-mitigated": "At risk (mitigated)",
  "at-risk": "At risk",
  "not-started": "Not started",
};

const STATUS_DOT: Record<TaskStatus, string> = {
  completed: "bg-status-completed",
  "on-track": "bg-status-on-track",
  "at-risk-mitigated": "bg-status-at-risk-mitigated",
  "at-risk": "bg-status-at-risk",
  "not-started": "bg-status-not-started",
};

const STATUS_OPTIONS: TaskStatus[] = [
  "on-track",
  "at-risk-mitigated",
  "at-risk",
];

interface TaskDetailDrawerProps {
  task: LaunchTask | null;
  launch: Launch;
  initialStatus: TaskStatus;
  onOpenChange: (open: boolean) => void;
}

export function TaskDetailDrawer({
  task,
  launch,
  initialStatus,
  onOpenChange,
}: TaskDetailDrawerProps) {
  const baseReadOnly = useIsReadOnly();
  const { role } = useRole();
  const assignedIds = useAssignedPlatformIds();
  const assignedNames = useAssignedPlatformNames();
  const canAct = canActOnPlatformInfo(role, assignedIds, assignedNames, {
    id: launch?.id,
    name: launch?.name,
  });
  // Split: completing/changing status/owners requires "act" (assigned platform
  // for admin/user, never for executive). Commenting/attachments are available
  // to anyone who can open the drawer — including executives and users/admins
  // browsing platforms outside their assignment.
  const isCloseTask = task ? isPhaseCloseTask(task) : false;
  const isAdminRole = role === "admin" || role === "superadmin";
  // Phase-close approval tasks are admin-only — non-admins can view but not act.
  const canComplete = !baseReadOnly && canAct && (!isCloseTask || isAdminRole);
  const canComment = true;
  const readOnly = !canComplete;

  const [status, setStatus] = useState<TaskStatus>(initialStatus);
  const [primary, setPrimary] = useState<TaskOwner | null>(null);
  const [backup, setBackup] = useState<TaskOwner | null>(null);
  const [comments, setComments] = useState<TaskComment[]>([]);
  const [draft, setDraft] = useState("");
  const [flag, setFlag] = useState(false);
  const [reassignOpen, setReassignOpen] = useState(false);
  const [mentions, setMentions] = useState<TaskOwner[]>([]);
  const [mentionQuery, setMentionQuery] = useState<string | null>(null);
  const [mentionIdx, setMentionIdx] = useState(0);
  const [attachments, setAttachments] = useState<Attachment[]>([]);
  const [pendingStatus, setPendingStatus] = useState<TaskStatus | null>(null);
  const [statusForm, setStatusForm] = useState({
    issue: "",
    impact: "",
    mitigation: "",
    owner: "",
    due: "",
  });
  const [reassignCandidate, setReassignCandidate] = useState<TaskOwner | null>(null);
  const [reassignReason, setReassignReason] = useState("");
  const [rejectReason, setRejectReason] = useState("");
  const [rejectOpen, setRejectOpen] = useState(false);
  const [, forceTick] = useState(0);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const isAdmin = isAdminRole;


  useEffect(() => {
    const unsub = subscribeAssignmentRequests(() => forceTick((n) => n + 1));
    return () => {
      unsub();
    };
  }, []);

  const pendingRequest: AssignmentRequest | undefined = task
    ? pendingForTask(task.id)
    : undefined;
  const viewerIsAssignee =
    !!pendingRequest && pendingRequest.toOwner.name === CURRENT_USER_NAME;

  const details = useMemo(
    () => (task ? getTaskDetails(task, launch) : null),
    [task, launch],
  );

  const taskFunctionLabel = useMemo(() => {
    if (!task) return "";
    return task.teams.map((t) => (t === "SChM" ? "SChM" : t)).join(" · ");
  }, [task]);

  const dependencyResolver = useMemo(
    () => buildLaunchDependencyResolver(launch, tasksForLaunch(launch)),
    [launch],
  );
  const dependencies = useMemo(
    () => (task ? dependencyResolver.full(task) : null),
    [task, dependencyResolver],
  );

  // Function-scoped owner pool for the open task. Honors the rule that only
  // people in the task's function (manager + team) can own / be mentioned /
  // be picked as the responsible owner when changing status.
  const ownerPool = useMemo<TaskOwner[]>(() => {
    if (!details) return [];
    const seen = new Set<string>();
    const out: TaskOwner[] = [];
    const push = (o: TaskOwner | null) => {
      if (!o || seen.has(o.name)) return;
      seen.add(o.name);
      out.push(o);
    };
    push(details.primaryOwner);
    push(details.backupOwner);
    for (const o of details.candidateOwners) push(o);
    return out;
  }, [details]);

  useEffect(() => {
    if (!task || !details) return;
    setStatus(initialStatus);
    setPrimary(details.primaryOwner);
    setBackup(details.backupOwner);
    setComments(details.comments);
    setDraft("");
    setFlag(false);
    setMentions([]);
    setMentionQuery(null);
    setAttachments([]);
    setReassignCandidate(null);
    setReassignReason("");
    setRejectReason("");
    setRejectOpen(false);
  }, [task, details, initialStatus]);

  if (!task || !details) return null;

  const dueCalendar = resolveDueDate(launch, task);
  const deltaLabel =
    details.deltaDays === 0
      ? "On time"
      : details.deltaDays > 0
        ? `+${details.deltaDays}d`
        : `${details.deltaDays}d`;
  const deltaTone =
    details.deltaDays === 0
      ? "text-status-on-track"
      : details.deltaDays > 0
        ? "text-status-at-risk"
        : "text-status-completed";

  const filteredMentionOptions = mentionQuery === null
    ? []
    : ownerPool.filter((o) =>
        o.name.toLowerCase().replace(/\s+/g, "").includes(mentionQuery.toLowerCase()),
      ).slice(0, 6);

  const updateDraft = (next: string, caretPos: number) => {
    setDraft(next);
    // Detect active @token immediately before caret
    const before = next.slice(0, caretPos);
    const m = before.match(/(?:^|\s)@([A-Za-z]*)$/);
    if (m) {
      setMentionQuery(m[1]);
      setMentionIdx(0);
    } else {
      setMentionQuery(null);
    }
    // Drop any mentions whose token is no longer in the text
    setMentions((prev) => prev.filter((o) => next.includes(`@${tokenize(o.name)}`)));
  };

  const insertMention = (owner: TaskOwner) => {
    const ta = textareaRef.current;
    const caret = ta?.selectionStart ?? draft.length;
    const before = draft.slice(0, caret);
    const after = draft.slice(caret);
    const replaced = before.replace(/@([A-Za-z]*)$/, `@${tokenize(owner.name)} `);
    const next = replaced + after;
    setDraft(next);
    setMentions((prev) =>
      prev.some((o) => o.name === owner.name) ? prev : [...prev, owner],
    );
    setMentionQuery(null);
    requestAnimationFrame(() => {
      const pos = replaced.length;
      ta?.focus();
      ta?.setSelectionRange(pos, pos);
    });
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (mentionQuery === null || filteredMentionOptions.length === 0) return;
    if (e.key === "ArrowDown") {
      e.preventDefault();
      setMentionIdx((i) => (i + 1) % filteredMentionOptions.length);
    } else if (e.key === "ArrowUp") {
      e.preventDefault();
      setMentionIdx((i) => (i - 1 + filteredMentionOptions.length) % filteredMentionOptions.length);
    } else if (e.key === "Enter" || e.key === "Tab") {
      e.preventDefault();
      insertMention(filteredMentionOptions[mentionIdx]);
    } else if (e.key === "Escape") {
      e.preventDefault();
      setMentionQuery(null);
    }
  };

  const postComment = () => {
    const body = draft.trim();
    if (!body) return;
    const activeMentions = mentions.filter((o) => body.includes(`@${tokenize(o.name)}`));
    setComments((c) => [
      {
        id: `local-${Date.now()}`,
        author: "You",
        initials: "YO",
        timestamp: "Just now",
        body,
        isRiskFlag: flag,
        mentions: activeMentions.map((o) => ({ name: o.name, initials: o.initials })),
      },
      ...c,
    ]);
    if (activeMentions.length > 0) {
      const names = activeMentions.map((o) => `@${o.name}`).join(", ");
      toast.success(
        `Notified ${activeMentions.length} ${activeMentions.length === 1 ? "person" : "people"}: ${names}`,
      );
    }
    setDraft("");
    setFlag(false);
    setMentions([]);
    setMentionQuery(null);
  };

  const renderCommentBody = (c: TaskComment) => {
    if (!c.mentions || c.mentions.length === 0) return c.body;
    const tokens = c.mentions.map((m) => ({ token: tokenize(m.name), name: m.name }));
    const re = new RegExp(`@(${tokens.map((t) => t.token).join("|")})\\b`, "g");
    const parts: React.ReactNode[] = [];
    let last = 0;
    let match: RegExpExecArray | null;
    let key = 0;
    while ((match = re.exec(c.body)) !== null) {
      if (match.index > last) parts.push(c.body.slice(last, match.index));
      const found = tokens.find((t) => t.token === match![1]);
      parts.push(
        <span
          key={key++}
          className="text-primary font-medium bg-primary/10 px-1 rounded"
        >
          @{found?.name ?? match[1]}
        </span>,
      );
      last = match.index + match[0].length;
    }
    if (last < c.body.length) parts.push(c.body.slice(last));
    return parts;
  };

  return (
    <Sheet open={!!task} onOpenChange={onOpenChange}>
      <SheetContent
        side="right"
        aria-label={`Task details: ${task.task}`}
        className="w-[1200px] sm:max-w-[90vw] p-0 flex flex-col gap-0 [&>button]:hidden"
      >
        <div className="px-8 pt-6 pb-4 border-b border-border">
          <div className="flex items-center justify-between gap-4 flex-wrap">
            <SheetClose asChild>
              <button
                type="button"
                className="inline-flex items-center gap-1 text-body-3 text-primary hover:underline focus:outline-none focus-visible:ring-2 focus-visible:ring-ring rounded-sm"
              >
                <ChevronLeft className="h-4 w-4" />
                Back
              </button>
            </SheetClose>
            <LiveRefreshIndicator />
          </div>
          <SheetHeader className="mt-4 text-left sm:text-left">
            <SheetDescription className="text-caption uppercase tracking-wide">
              {task.phase}
              <span aria-hidden> › </span>
              {task.gate}
            </SheetDescription>
            <SheetTitle className="text-h3 text-foreground flex items-start gap-3">
              <span className="flex-1">{task.task}</span>
              {details?.isAuto && (
                <Badge variant="secondary" className="shrink-0 mt-1">
                  Auto
                </Badge>
              )}
            </SheetTitle>
            <SheetDescription>{launch.name}</SheetDescription>
          </SheetHeader>
        </div>

        <div className="flex-1 overflow-y-auto px-8 py-6 space-y-8">
          {!canComplete && canComment && (
            <div className="flex items-start gap-2 rounded-md border border-border bg-muted/40 px-3 py-2">
              <Eye className="h-4 w-4 mt-1 text-muted-foreground shrink-0" aria-hidden />
              <p className="text-caption text-muted-foreground">
                <span className="text-foreground font-medium">Read-only.</span>{" "}
                {baseReadOnly
                  ? "You can add comments, risk flags, and attachments — completing or updating tasks is reserved for assigned owners."
                  : `${launch.name} isn't in your assigned platforms — you can add comments, risk flags, and attachments, but only assigned owners can complete or update this task.`}
              </p>
            </div>
          )}
          {/* At-a-glance */}
          <section className="grid grid-cols-2 l:grid-cols-4 gap-4">
            <Tile label="Status">
              <span className="inline-flex items-center gap-2">
                <span
                  className={cn("inline-block h-2 w-2 rounded-full", STATUS_DOT[status])}
                  aria-hidden
                />
                <span className="text-body-3 text-foreground">{STATUS_LABEL[status]}</span>
              </span>
            </Tile>
            <Tile label="Due date">
              <Badge variant="outline" className="text-caption font-medium">
                {task.taskEnd}
              </Badge>
              <p className="mt-2 text-body-3 text-foreground tabular-nums">{dueCalendar}</p>
            </Tile>
            <Tile label="Suggested min. duration">
              <MinDurationTile task={task} />
            </Tile>
            <Tile label={`Required documents and data sources (${details.requiredDocs.length})`}>
              <ul className="space-y-1">
                {details.requiredDocs.map((d) => (
                  <li
                    key={d}
                    className="flex items-start gap-2 text-body-3 text-foreground"
                  >
                    <Paperclip className="h-3 w-3 mt-1 text-muted-foreground" />
                    <span>{d}</span>
                  </li>
                ))}
              </ul>
            </Tile>
          </section>

          <RunwayBanner task={task} launch={launch} />

          <div className="flex items-center gap-2 flex-wrap">
            <TaskRunwayChip launch={launch} task={task} status={status} />
          </div>


          {/* POR vs actual */}
          <section className="space-y-3">
            <h3 className="text-subtitle-2 text-foreground">POR vs actual date</h3>
            <div className="rounded-md border border-border overflow-hidden">
              <div className="grid grid-cols-3 px-4 py-2 border-b border-border bg-muted/30 text-caption text-muted-foreground">
                <span>Series</span>
                <span>Date</span>
                <span>Delta</span>
              </div>
              <div className="grid grid-cols-3 px-4 py-3 border-b border-border text-body-3 text-foreground">
                <span>Plan of record</span>
                <span className="tabular-nums">{details.porDate}</span>
                <span className="text-muted-foreground">—</span>
              </div>
              <div className="grid grid-cols-3 px-4 py-3 text-body-3 text-foreground">
                <span>Actual / forecast</span>
                <span className="tabular-nums">{details.actualDate}</span>
                <span className={cn("tabular-nums", deltaTone)}>{deltaLabel}</span>
              </div>
            </div>
          </section>

          {/* Dependencies */}
          {dependencies && (dependencies.predecessors.length > 0 || dependencies.successors.length > 0) && (
            <section id="dependencies" className="space-y-3">
              <h3 className="text-subtitle-2 text-foreground">Dependencies</h3>
              {dependencies.blockers.length > 0 && (
                <div className="rounded-md border border-status-at-risk/40 bg-status-at-risk/10 px-4 py-3">
                  <p className="text-body-3 font-medium text-foreground">
                    This task is blocked.
                  </p>
                  <p className="text-caption text-muted-foreground mt-1">
                    Complete {dependencies.blockers.length === 1 ? "the predecessor" : `${dependencies.blockers.length} predecessors`} below to unlock it.
                  </p>
                </div>
              )}
              <div className="grid grid-cols-1 m:grid-cols-2 gap-4">
                <DependencyList
                  title="Predecessors (must complete first)"
                  items={dependencies.predecessors}
                  emptyMsg="No predecessors."
                />
                <DependencyList
                  title="Successors (waiting on this task)"
                  items={dependencies.successors}
                  emptyMsg="No successors."
                />
              </div>
            </section>
          )}

          {/* Owners */}
          <section className="space-y-3">
            <h3 className="text-subtitle-2 text-foreground">Owners</h3>
            {isCloseTask && (
              <p className="rounded-md border border-border bg-muted/40 px-3 py-2 text-caption text-muted-foreground">
                Admin approval only — {primary?.name ? `assigned to ${primary.name}` : "assigned to the function manager"}. Owner cannot be reassigned. Completing this task closes the {task.phase} phase and starts the next phase once every function has approved.
              </p>
            )}

            {details.isAuto ? (
              <p className="text-body-3 text-muted-foreground">
                Automated task — completes automatically at phase start. No owner required.
              </p>
            ) : (
              <>
                <div className="grid grid-cols-1 m:grid-cols-2 gap-4">
                  <OwnerCard label="Primary owner" owner={primary} taskFunction={taskFunctionLabel} />
                  <OwnerCard label="Backup owner" owner={backup} taskFunction={taskFunctionLabel} />
                </div>

                {pendingRequest && (
                  <div className="rounded-md border border-status-at-risk-mitigated/40 bg-status-at-risk-mitigated/10 px-4 py-3 space-y-3">
                    <div className="flex items-start justify-between gap-3">
                      <div className="min-w-0">
                        <p className="text-body-3 font-medium text-foreground">
                          Reassignment pending → {pendingRequest.toOwner.name}
                        </p>
                        <p className="text-caption text-muted-foreground">
                          Requested by {pendingRequest.requestedBy} ·{" "}
                          {formatRelative(pendingRequest.createdAt)}
                          {pendingRequest.reason ? ` · "${pendingRequest.reason}"` : ""}
                        </p>
                        {!viewerIsAssignee && (
                          <p className="mt-1 text-caption text-muted-foreground italic">
                            Awaiting response from {pendingRequest.toOwner.name}.
                            {primary?.name && ` ${primary.name} stays accountable until resolved.`}
                          </p>
                        )}
                      </div>
                      {!readOnly && (
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => {
                            cancelRequest(pendingRequest.id);
                            appendTaskHistory({
                              taskId: task.id,
                              actor: { name: "You", initials: "YO" },
                              field: "primaryOwner",
                              label: "Reassignment cancelled",
                              before: `Pending → ${pendingRequest.toOwner.name}`,
                              after: primary?.name ?? "—",
                            });
                            toast("Reassignment request cancelled");
                          }}
                        >
                          Cancel request
                        </Button>
                      )}
                    </div>

                    {viewerIsAssignee && !readOnly && (
                      <div className="flex flex-wrap items-center gap-2">
                        <Button
                          size="sm"
                          onClick={() => {
                            const prevOwner = primary;
                            approveRequest(pendingRequest.id);
                            if (prevOwner) setBackup(prevOwner);
                            setPrimary(pendingRequest.toOwner);
                            appendTaskHistory({
                              taskId: task.id,
                              actor: {
                                name: pendingRequest.toOwner.name,
                                initials: pendingRequest.toOwner.initials,
                              },
                              field: "primaryOwner",
                              label: "Primary owner",
                              before: prevOwner?.name ?? "—",
                              after: `${pendingRequest.toOwner.name} (approved; requested by ${pendingRequest.requestedBy})`,
                            });
                            toast.success(
                              `Accepted assignment — you are now the primary owner`,
                            );
                          }}
                        >
                          Approve
                        </Button>
                        <Popover open={rejectOpen} onOpenChange={setRejectOpen}>
                          <PopoverTrigger asChild>
                            <Button variant="outline" size="sm">
                              Reject with reason
                            </Button>
                          </PopoverTrigger>
                          <PopoverContent align="start" className="w-80 p-3 space-y-2">
                            <Label className="text-caption text-muted-foreground">
                              Reason for declining
                            </Label>
                            <Textarea
                              value={rejectReason}
                              onChange={(e) => setRejectReason(e.target.value)}
                              placeholder="e.g. on PTO next 2 weeks; suggest Marcus instead"
                              rows={3}
                            />
                            <div className="flex justify-end gap-2 pt-1">
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => {
                                  setRejectOpen(false);
                                  setRejectReason("");
                                }}
                              >
                                Cancel
                              </Button>
                              <Button
                                size="sm"
                                disabled={rejectReason.trim().length < 4}
                                onClick={() => {
                                  const reason = rejectReason.trim();
                                  rejectRequest(pendingRequest.id, reason);
                                  appendTaskHistory({
                                    taskId: task.id,
                                    actor: {
                                      name: pendingRequest.toOwner.name,
                                      initials: pendingRequest.toOwner.initials,
                                    },
                                    field: "primaryOwner",
                                    label: "Reassignment rejected",
                                    before: `Pending → ${pendingRequest.toOwner.name}`,
                                    after: `Rejected — ${reason}`,
                                  });
                                  setRejectOpen(false);
                                  setRejectReason("");
                                  toast("Request declined", {
                                    description: `${pendingRequest.requestedBy} has been notified.`,
                                  });
                                }}
                              >
                                Send rejection
                              </Button>
                            </div>
                          </PopoverContent>
                        </Popover>
                      </div>
                    )}
                  </div>
                )}

                <div className="flex flex-col gap-3">
                  {!readOnly && !pendingRequest && !isCloseTask && (

                  <div className="flex flex-wrap items-center gap-2">
                  <Popover open={reassignOpen} onOpenChange={(o) => {
                    setReassignOpen(o);
                    if (!o) {
                      setReassignCandidate(null);
                      setReassignReason("");
                    }
                  }}>
                    <PopoverTrigger asChild>
                      <Button variant="outline" size="sm">
                        Request reassignment
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent align="start" className="w-96 p-0">
                      <div className="p-3 border-b border-border">
                        <p className="text-body-3 font-medium text-foreground">
                          {reassignCandidate
                            ? `Send request to ${reassignCandidate.name}?`
                            : "Propose a new primary owner"}
                        </p>
                        <p className="text-caption text-muted-foreground">
                          {reassignCandidate
                            ? `${reassignCandidate.name} must approve before the swap is applied.`
                            : "They will be asked to approve before becoming the owner."}
                        </p>
                      </div>
                      {!reassignCandidate ? (
                        <ul className="max-h-64 overflow-y-auto py-1">
                          {details.candidateOwners.map((o) => (
                            <li key={o.name}>
                              <button
                                type="button"
                                onClick={() => setReassignCandidate(o)}
                                className="w-full flex items-center gap-3 px-3 py-2 text-left hover:bg-muted/40 transition-colors"
                              >
                                <Avatar className="h-7 w-7">
                                  <AvatarFallback className="text-caption">
                                    {o.initials}
                                  </AvatarFallback>
                                </Avatar>
                                <span className="min-w-0">
                                  <span className="block text-body-3 text-foreground truncate">
                                    {o.name}
                                  </span>
                                  <span className="block text-caption text-muted-foreground truncate">
                                    {o.role}
                                  </span>
                                </span>
                              </button>
                            </li>
                          ))}
                        </ul>
                      ) : (
                        <div className="p-3 space-y-3">
                          <div className="flex items-center gap-3">
                            <Avatar className="h-8 w-8">
                              <AvatarFallback className="text-caption">
                                {reassignCandidate.initials}
                              </AvatarFallback>
                            </Avatar>
                            <div className="min-w-0">
                              <p className="text-body-3 text-foreground truncate">
                                {reassignCandidate.name}
                              </p>
                              <p className="text-caption text-muted-foreground truncate">
                                {reassignCandidate.role}
                              </p>
                            </div>
                          </div>
                          <div className="space-y-1">
                            <Label className="text-caption text-muted-foreground">
                              Reason (optional)
                            </Label>
                            <Textarea
                              value={reassignReason}
                              onChange={(e) => setReassignReason(e.target.value)}
                              placeholder="e.g. better fit for the qual phase"
                              rows={3}
                            />
                          </div>
                          <div className="flex justify-between gap-2">
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => setReassignCandidate(null)}
                            >
                              Back
                            </Button>
                            <Button
                              size="sm"
                              onClick={() => {
                                createRequest({
                                  taskId: task.id,
                                  taskName: task.task,
                                  launchName: launch.name,
                                  fromOwner: primary,
                                  toOwner: reassignCandidate,
                                  requestedBy: "You",
                                  reason: reassignReason.trim() || undefined,
                                });
                                appendTaskHistory({
                                  taskId: task.id,
                                  actor: { name: "You", initials: "YO" },
                                  field: "primaryOwner",
                                  label: "Reassignment requested",
                                  before: primary?.name ?? "—",
                                  after: `Pending → ${reassignCandidate.name}`,
                                });
                                toast.success(
                                  `Request sent to ${reassignCandidate.name}`,
                                );
                                setReassignOpen(false);
                                setReassignCandidate(null);
                                setReassignReason("");
                              }}
                            >
                              Send request
                            </Button>
                          </div>
                        </div>
                      )}
                    </PopoverContent>
                  </Popover>

                  {isAdmin && (
                    <Popover>
                      <PopoverTrigger asChild>
                        <Button variant="ghost" size="sm">
                          Force reassign (admin)
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent align="start" className="w-80 p-0">
                        <div className="p-3 border-b border-border">
                          <p className="text-body-3 font-medium text-foreground">
                            Force reassign — bypass approval
                          </p>
                          <p className="text-caption text-muted-foreground">
                            Logged distinctly in history. Use only for emergencies.
                          </p>
                        </div>
                        <ul className="max-h-64 overflow-y-auto py-1">
                          {details.candidateOwners.map((o) => (
                            <li key={o.name}>
                              <button
                                type="button"
                                onClick={() => {
                                  const prevOwner = primary;
                                  if (prevOwner) setBackup(prevOwner);
                                  setPrimary(o);
                                  appendTaskHistory({
                                    taskId: task.id,
                                    actor: { name: "You", initials: "YO" },
                                    field: "primaryOwner",
                                    label: "Force-reassigned (admin)",
                                    before: prevOwner?.name ?? "—",
                                    after: `${o.name} (forced by admin)`,
                                  });
                                  toast(`Force-reassigned to ${o.name}`);
                                }}
                                className="w-full flex items-center gap-3 px-3 py-2 text-left hover:bg-muted/40 transition-colors"
                              >
                                <Avatar className="h-7 w-7">
                                  <AvatarFallback className="text-caption">
                                    {o.initials}
                                  </AvatarFallback>
                                </Avatar>
                                <span className="min-w-0">
                                  <span className="block text-body-3 text-foreground truncate">
                                    {o.name}
                                  </span>
                                  <span className="block text-caption text-muted-foreground truncate">
                                    {o.role}
                                  </span>
                                </span>
                              </button>
                            </li>
                          ))}
                        </ul>
                      </PopoverContent>
                    </Popover>
                  )}
                  </div>
                  )}
                  <Accordion type="single" collapsible>
                    <AccordionItem value="history" className="border-border">
                      <AccordionTrigger className="text-body-3 text-muted-foreground hover:no-underline py-2">
                        Assignment history
                      </AccordionTrigger>
                      <AccordionContent>
                        <ul className="space-y-2 pt-2">
                          {details.history.map((h) => (
                            <li
                              key={h.id}
                              className="flex items-start justify-between gap-4 text-body-3"
                            >
                              <span className="text-foreground">
                                Reassigned from <span className="font-medium">{h.from}</span> to{" "}
                                <span className="font-medium">{h.to}</span> by {h.by}
                              </span>
                              <span className="text-caption text-muted-foreground tabular-nums shrink-0">
                                {h.timestamp}
                              </span>
                            </li>
                          ))}
                        </ul>
                      </AccordionContent>
                    </AccordionItem>
                  </Accordion>
                </div>
              </>
            )}
          </section>

          {/* Reminders */}
          {!details.isAuto && status !== "completed" && (
            <TaskRemindersRow
              taskRef={task.id}
              rag={
                status === "at-risk"
                  ? "red"
                  : status === "at-risk-mitigated"
                    ? "amber"
                    : "green"
              }
            />
          )}

          {/* Submission notes (only when completed) */}
          {status === "completed" && (
            <section className="space-y-2">
              <h3 className="text-subtitle-2 text-foreground">Submission notes</h3>
              <p className="text-body-3 text-muted-foreground">{details.submissionNotes}</p>
            </section>
          )}

          {/* Comments & risk flags */}
          <section className="space-y-3">
            <h3 className="text-subtitle-2 text-foreground">Comments & risk flags</h3>
            <ul className="space-y-3">
              {comments.length === 0 && (
                <li className="text-caption text-muted-foreground italic">
                  No comments yet.
                </li>
              )}
              {comments.map((c) => (
                <li
                  key={c.id}
                  className="flex gap-3 p-3 rounded-md border border-border"
                >
                  <Avatar className="h-8 w-8 shrink-0">
                    <AvatarFallback className="text-caption">{c.initials}</AvatarFallback>
                  </Avatar>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="text-body-3 font-medium text-foreground">
                        {c.author}
                      </span>
                      <span className="text-caption text-muted-foreground">
                        {c.timestamp}
                      </span>
                      {c.isRiskFlag && (
                        <Badge
                          variant="outline"
                          className="text-caption gap-1 border-status-at-risk text-status-at-risk"
                        >
                          <Flag className="h-3 w-3" />
                          Risk flag
                        </Badge>
                      )}
                    </div>
                    <p className="mt-1 text-body-3 text-foreground whitespace-pre-wrap">
                      {renderCommentBody(c)}
                    </p>
                    {c.mentions && c.mentions.length > 0 && (
                      <p className="mt-1 text-caption text-muted-foreground">
                        Notified: {c.mentions.map((m) => `@${m.name}`).join(", ")}
                      </p>
                    )}
                  </div>
                </li>
              ))}
            </ul>
            {canComment && (
            <div className="space-y-2">
              <div className="relative">
                <Textarea
                  ref={textareaRef}
                  value={draft}
                  onChange={(e) => updateDraft(e.target.value, e.target.selectionStart ?? e.target.value.length)}
                  onKeyDown={handleKeyDown}
                  placeholder="Add a comment… type @ to mention"
                  rows={3}
                />
                {mentionQuery !== null && filteredMentionOptions.length > 0 && (
                  <div className="absolute left-0 right-0 top-full mt-1 z-10 rounded-md border border-border bg-popover shadow-elev-2 max-h-60 overflow-y-auto">
                    <ul>
                      {filteredMentionOptions.map((o, i) => (
                        <li key={o.name}>
                          <button
                            type="button"
                            onMouseDown={(e) => {
                              e.preventDefault();
                              insertMention(o);
                            }}
                            onMouseEnter={() => setMentionIdx(i)}
                            className={cn(
                              "w-full flex items-center gap-3 px-3 py-2 text-left transition-colors",
                              i === mentionIdx ? "bg-muted/60" : "hover:bg-muted/40",
                            )}
                          >
                            <Avatar className="h-7 w-7">
                              <AvatarFallback className="text-caption">{o.initials}</AvatarFallback>
                            </Avatar>
                            <span className="min-w-0">
                              <span className="block text-body-3 text-foreground truncate">{o.name}</span>
                              <span className="block text-caption text-muted-foreground truncate">{o.role}</span>
                            </span>
                          </button>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
              {mentions.length > 0 && (
                <p className="text-caption text-muted-foreground">
                  Will notify: {mentions.map((m) => `@${m.name}`).join(", ")}
                </p>
              )}
              <div className="flex items-center justify-between">
                <label className="inline-flex items-center gap-2 text-caption text-foreground cursor-pointer">
                  <Checkbox
                    checked={flag}
                    onCheckedChange={(v) => setFlag(v === true)}
                  />
                  Flag as risk
                </label>
                <Button size="sm" onClick={postComment} disabled={!draft.trim()}>
                  Post
                </Button>
              </div>
            </div>
            )}
          </section>

          {/* Attachments */}
          <section className="space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-subtitle-2 text-foreground">Attachments</h3>
              {canComment && (
                <>
                  <input
                    ref={fileInputRef}
                    type="file"
                    multiple
                    className="hidden"
                    onChange={(e) => {
                      const files = Array.from(e.target.files ?? []);
                      if (files.length === 0) return;
                      const added: Attachment[] = files.map((f) => ({
                        id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
                        name: f.name,
                        size: f.size,
                        type: f.type || "file",
                        addedAt: "Just now",
                      }));
                      setAttachments((a) => [...a, ...added]);
                      toast.success(`Attached ${added.length} file${added.length === 1 ? "" : "s"}`);
                      if (fileInputRef.current) fileInputRef.current.value = "";
                    }}
                  />
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => fileInputRef.current?.click()}
                    className="gap-2"
                  >
                    <Paperclip className="h-4 w-4" />
                    Add file
                  </Button>
                </>
              )}
            </div>
            <ul className="space-y-2">
              {attachments.length === 0 && (
                <li className="text-caption text-muted-foreground italic">
                  No attachments yet.
                </li>
              )}
              {attachments.map((a) => (
                <li
                  key={a.id}
                  className="flex items-center gap-3 p-3 rounded-md border border-border"
                >
                  <FileIcon className="h-5 w-5 shrink-0 text-muted-foreground" />
                  <div className="min-w-0 flex-1">
                    <p className="text-body-3 text-foreground truncate">{a.name}</p>
                    <p className="text-caption text-muted-foreground truncate">
                      {formatBytes(a.size)} · {a.type} · {a.addedAt}
                    </p>
                  </div>
                  {canComment && (
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => {
                      setAttachments((list) => list.filter((x) => x.id !== a.id));
                      toast("Attachment removed");
                    }}
                    className="gap-1 shrink-0"
                  >
                    <X className="h-4 w-4" />
                    Remove
                  </Button>
                  )}
                </li>
              ))}
            </ul>
          </section>

          {/* History */}
          <TaskHistorySection
            taskId={task.id}
            onRestoreField={(field, value) => {
              if (field === "status") {
                const map: Record<string, TaskStatus> = {
                  "On track": "on-track",
                  "At risk (mitigated)": "at-risk-mitigated",
                  "At risk": "at-risk",
                  "Not started": "not-started",
                  "Completed": "completed",
                };
                const next = map[value];
                if (next) setStatus(next);
              } else if (field === "primaryOwner") {
                const owner = ownerPool.find((o) => o.name === value);
                if (owner) setPrimary(owner);
              } else if (field === "backupOwner") {
                const owner = ownerPool.find((o) => o.name === value);
                if (owner) setBackup(owner);
              }
            }}
          />
        </div>

        {!readOnly && (
        <SheetFooter className="px-8 py-4 border-t border-border flex-row justify-start sm:justify-start gap-2 sm:space-x-0">
          {details?.isAuto ? (
            <p className="text-body-3 text-muted-foreground">
              This task is automated and will complete at phase start.
            </p>
          ) : (
            <DrawerStatusActions
              task={task}
              launch={launch}
              status={status}
              setStatus={setStatus}
              setStatusForm={setStatusForm}
              setPendingStatus={setPendingStatus}
              primaryName={primary?.name}
            />
          )}
        </SheetFooter>
        )}
      </SheetContent>
      <Dialog
        open={pendingStatus !== null}
        onOpenChange={(o) => !o && setPendingStatus(null)}
      >
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle className="text-h5 text-foreground">
              Change status
              {pendingStatus && (
                <>
                  {" "}
                  to{" "}
                  <span className="text-primary">
                    {STATUS_LABEL[pendingStatus]}
                  </span>
                </>
              )}
            </DialogTitle>
            <DialogDescription className="text-body-3 text-muted-foreground">
              Provide context so reviewers can act on this status change.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <div className="space-y-2">
              <Label htmlFor="status-issue" className="text-body-3 text-foreground">
                Root cause
              </Label>
              <Textarea
                id="status-issue"
                value={statusForm.issue}
                onChange={(e) =>
                  setStatusForm((f) => ({ ...f, issue: e.target.value }))
                }
                placeholder="What is the root cause?"
                rows={2}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="status-impact" className="text-body-3 text-foreground">
                Business impact
              </Label>
              <Textarea
                id="status-impact"
                value={statusForm.impact}
                onChange={(e) =>
                  setStatusForm((f) => ({ ...f, impact: e.target.value }))
                }
                placeholder="What is the impact on the launch?"
                rows={2}
              />
            </div>
            <div className="space-y-2">
              <Label
                htmlFor="status-mitigation"
                className="text-body-3 text-foreground"
              >
                Action required
              </Label>
              <Textarea
                id="status-mitigation"
                value={statusForm.mitigation}
                onChange={(e) =>
                  setStatusForm((f) => ({ ...f, mitigation: e.target.value }))
                }
                placeholder="What actions will resolve this?"
                rows={2}
              />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-2">
                <Label htmlFor="status-owner" className="text-body-3 text-foreground">
                  Owner
                </Label>
                <Select
                  value={statusForm.owner}
                  onValueChange={(v) =>
                    setStatusForm((f) => ({ ...f, owner: v }))
                  }
                >
                  <SelectTrigger id="status-owner">
                    <SelectValue placeholder="Select an owner" />
                  </SelectTrigger>
                  <SelectContent>
                    {ownerPool.map((o) => (
                      <SelectItem key={o.name} value={o.name}>
                        {o.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="status-due" className="text-body-3 text-foreground">
                  Due date
                </Label>
                <Input
                  id="status-due"
                  type="date"
                  value={statusForm.due}
                  onChange={(e) =>
                    setStatusForm((f) => ({ ...f, due: e.target.value }))
                  }
                />
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setPendingStatus(null)}>
              Cancel
            </Button>
            <DrawerSubmitStatus
              task={task}
              launch={launch}
              status={status}
              setStatus={setStatus}
              pendingStatus={pendingStatus}
              setPendingStatus={setPendingStatus}
              statusForm={statusForm}
            />
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </Sheet>
  );
}

function Tile({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="rounded-md border border-border p-4 bg-surface">
      <p className="text-caption text-muted-foreground">{label}</p>
      <div className="mt-2">{children}</div>
    </div>
  );
}

function ownerEmail(name: string): string {
  return (
    name
      .toLowerCase()
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .replace(/[^a-z\s.-]/g, "")
      .trim()
      .split(/\s+/)
      .join(".") + "@dell.com"
  );
}

function OwnerCard({
  label,
  owner,
  taskFunction,
}: {
  label: string;
  owner: TaskOwner | null;
  taskFunction?: string;
}) {
  if (!owner) return null;
  return (
    <div className="flex items-start gap-3 rounded-md border border-border p-4">
      <Avatar className="h-10 w-10">
        <AvatarFallback>{owner.initials}</AvatarFallback>
      </Avatar>
      <div className="min-w-0 flex-1">
        <p className="text-caption text-muted-foreground">{label}</p>
        <p className="text-body-3 font-medium text-foreground truncate">{owner.name}</p>
        
        <a
          href={`mailto:${ownerEmail(owner.name)}`}
          className="block text-caption text-primary hover:underline truncate"
        >
          {ownerEmail(owner.name)}
        </a>
        {taskFunction && (
          <p className="text-caption text-muted-foreground truncate">
            Function: <span className="text-foreground">{taskFunction}</span>
          </p>
        )}
      </div>
    </div>
  );
}

function DependencyList({
  title,
  items,
  emptyMsg,
}: {
  title: string;
  items: { task: LaunchTask; status: TaskStatus }[];
  emptyMsg: string;
}) {
  return (
    <div className="rounded-md border border-border p-4 bg-surface">
      <p className="text-caption text-muted-foreground mb-2">{title}</p>
      {items.length === 0 ? (
        <p className="text-caption text-muted-foreground italic">{emptyMsg}</p>
      ) : (
        <ul className="space-y-2">
          {items.map((d) => (
            <li key={d.task.id} className="flex items-start gap-2">
              <span
                className={cn(
                  "mt-2 inline-block h-2 w-2 rounded-full shrink-0",
                  STATUS_DOT[d.status],
                )}
                aria-hidden
              />
              <div className="min-w-0 flex-1">
                <p className="text-body-3 text-foreground">
                  <span className="text-muted-foreground tabular-nums">#{d.task.l3Id}</span>{" "}
                  {d.task.task}
                </p>
                <p className="text-caption text-muted-foreground">
                  {d.task.phase} · {STATUS_LABEL[d.status]}
                </p>
              </div>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

// ---------------------------------------------------------------------------
// New status-change + completion request flow. Routes mutations through the
// request stores so all R/Y/G changes require manager approval.
// ---------------------------------------------------------------------------

type StatusForm = { issue: string; impact: string; mitigation: string; owner: string; due: string };

function DrawerStatusActions({
  task,
  launch,
  status,
  setStatus,
  setStatusForm,
  setPendingStatus,
  primaryName,
}: {
  task: LaunchTask;
  launch: Launch;
  status: TaskStatus;
  setStatus: (s: TaskStatus) => void;
  setStatusForm: (f: StatusForm) => void;
  setPendingStatus: (s: TaskStatus | null) => void;
  primaryName?: string;
}) {
  const { role } = useRole();
  const userName = useCurrentUserName();
  const pendingCompletion = pendingCompletionForTask(task.id);
  const pendingChange = pendingStatusChangeForTask(task.id);
  const isCompleted = status === "completed";

  const handleMarkComplete = () => {
    if (isCompleted || pendingCompletion) return;
    if (canOverrideStatus(role)) {
      // Auto-approved: write a system-completion record so resolver returns "completed".
      import("@/mocks/completionRequests").then(({ seedSystemCompletion }) => {
        seedSystemCompletion({
          launchId: launch.id,
          taskId: task.id,
          taskName: task.task,
        });
        appendTaskHistory({
          taskId: task.id,
          actor: { name: userName, initials: "YO" },
          field: "status",
          label: "Status",
          before: STATUS_LABEL[status],
          after: STATUS_LABEL.completed,
          note: "Marked complete by manager.",
        });
        setStatus("completed");
        toast.success("Task marked complete.");
      });
    } else {
      createCompletionRequest({
        launchId: launch.id,
        taskId: task.id,
        taskName: task.task,
        completionNote: "Submitted from task drawer.",
        owner: primaryName ?? userName,
        requestedBy: userName,
      });
      toast.success("Completion request submitted for manager approval.");
    }
  };

  return (
    <>
      {pendingChange && (
        <Badge variant="outline" className="mr-auto">
          Pending status change → {pendingChange.toStatus}
        </Badge>
      )}
      {pendingCompletion && (
        <Badge variant="outline" className="mr-auto">
          Pending completion approval
        </Badge>
      )}
      {isCompleted || pendingCompletion ? (
        <Button variant="default" disabled>
          {isCompleted ? "Completed" : "Awaiting approval"}
        </Button>
      ) : (
        <Button variant="default" asChild>
          <a
            href="https://app.regrello.com/"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2"
          >
            Complete task
            <ExternalLink className="h-4 w-4" />
          </a>
        </Button>
      )}
      <Popover>
        <PopoverTrigger asChild>
          <Button variant="outline" disabled={!!pendingChange}>
            {pendingChange ? "Awaiting approval" : "Change status"}
          </Button>
        </PopoverTrigger>
        <PopoverContent align="start" className="w-56 p-1">
          <ul>
            {STATUS_OPTIONS.map((s) => (
              <li key={s}>
                <button
                  type="button"
                  onClick={() => {
                    setStatusForm({
                      issue: "",
                      impact: "",
                      mitigation: "",
                      owner: primaryName ?? "",
                      due: "",
                    });
                    setPendingStatus(s);
                  }}
                  className={cn(
                    "w-full flex items-center gap-2 px-2 py-2 rounded-sm text-left text-body-3 hover:bg-muted/40 transition-colors",
                    status === s && "bg-muted/60",
                  )}
                >
                  <span
                    className={cn("inline-block h-2 w-2 rounded-full", STATUS_DOT[s])}
                    aria-hidden
                  />
                  <span className="text-foreground">{STATUS_LABEL[s]}</span>
                </button>
              </li>
            ))}
          </ul>
        </PopoverContent>
      </Popover>
    </>
  );
}

function DrawerSubmitStatus({
  task,
  launch,
  status,
  setStatus,
  pendingStatus,
  setPendingStatus,
  statusForm,
}: {
  task: LaunchTask;
  launch: Launch;
  status: TaskStatus;
  setStatus: (s: TaskStatus) => void;
  pendingStatus: TaskStatus | null;
  setPendingStatus: (s: TaskStatus | null) => void;
  statusForm: StatusForm;
}) {
  const { role } = useRole();
  const userName = useCurrentUserName();
  const canOverride = canOverrideStatus(role);

  const disabled =
    !pendingStatus ||
    !statusForm.issue.trim() ||
    !statusForm.impact.trim() ||
    !statusForm.mitigation.trim() ||
    !statusForm.owner ||
    !statusForm.due;

  const submit = (mode: "request" | "override") => {
    if (!pendingStatus) return;
    const target = pendingStatus as StatusChangeTarget;
    if (mode === "override" && canOverride) {
      directOverrideStatus({
        launchId: launch.id,
        taskId: task.id,
        taskName: task.task,
        fromStatus: status,
        toStatus: target,
        by: userName,
        note: `${statusForm.issue} — ${statusForm.mitigation}`,
        dueDate: statusForm.due,
      });
      setStatus(pendingStatus);
      toast.success("Status updated (manager override).");
    } else {
      createStatusChangeRequest({
        launchId: launch.id,
        taskId: task.id,
        taskName: task.task,
        fromStatus: status,
        toStatus: target,
        issueDescription: statusForm.issue,
        businessImpact: statusForm.impact,
        mitigationPlan: statusForm.mitigation,
        owner: statusForm.owner,
        dueDate: statusForm.due,
        requestedBy: userName,
      });
      toast.success("Status change submitted for manager approval.");
    }
    setPendingStatus(null);
  };

  return (
    <>
      {canOverride && (
        <Button variant="outline" onClick={() => submit("override")} disabled={disabled}>
          Set directly
        </Button>
      )}
      <Button onClick={() => submit("request")} disabled={disabled}>
        Submit request
      </Button>
    </>
  );
}
