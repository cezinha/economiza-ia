// Small inline badge surfacing the task due-date signal. Visual only — does
// not alter the task's RYG status (changes go through the request flow).

import { AlertCircle, Clock } from "lucide-react";
import { cn } from "@/lib/utils";
import type { Launch } from "@/mocks/launches";
import type { LaunchTask } from "@/lib/launchTasks";
import { dueLabel, dueSignal } from "@/lib/taskDueSignals";

export function TaskDueBadge({
  launch,
  task,
  className,
  variant = "chip",
}: {
  launch: Launch;
  task: LaunchTask;
  className?: string;
  variant?: "chip" | "banner";
}) {
  const sig = dueSignal(launch, task);
  if (sig.severity === "none") return null;
  const label = dueLabel(sig);
  const isOverdue = sig.severity === "overdue";
  const Icon = isOverdue ? AlertCircle : Clock;

  if (variant === "banner") {
    return (
      <div
        className={cn(
          "flex items-center gap-2 rounded-md px-3 py-2 text-body-3 ring-1 ring-inset",
          isOverdue
            ? "bg-danger/10 text-danger ring-danger/20"
            : "bg-warning/10 text-warning-foreground ring-warning/30",
          className,
        )}
      >
        <Icon className="h-4 w-4 shrink-0" />
        <span>{label}</span>
      </div>
    );
  }

  return (
    <span
      className={cn(
        "inline-flex items-center gap-1 rounded-sm px-2 py-1 text-body-3 font-medium ring-1 ring-inset",
        isOverdue
          ? "bg-danger/10 text-danger ring-danger/20"
          : "bg-warning/15 text-warning-foreground ring-warning/30",
        className,
      )}
    >
      <Icon className="h-3 w-3" />
      {label}
    </span>
  );
}
