import { AlertTriangle } from "lucide-react";
import { cn } from "@/lib/utils";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import type { Launch } from "@/mocks/launches";
import type { LaunchTask, TaskStatus } from "@/lib/launchTasks";
import { isTaskExpedited } from "@/lib/taskExpedited";

interface Props {
  launch: Launch;
  task: LaunchTask;
  status?: TaskStatus;
  className?: string;
}

/**
 * Red "At risk" pill shown when a task is being expedited because its launch's
 * RTS was pulled in. Visually mirrors TaskRunwayChip but in a danger tone.
 */
export function TaskExpeditedChip({ launch, task, status, className }: Props) {
  const info = isTaskExpedited(launch, task, status);
  if (!info) return null;
  return (
    <TooltipProvider delayDuration={150}>
      <Tooltip>
        <TooltipTrigger asChild>
          <span
            className={cn(
              "inline-flex items-center gap-1 rounded-full px-2 py-1 text-caption whitespace-nowrap shrink-0 cursor-default",
              className,
            )}
            style={{ backgroundColor: "#3D0A0A", color: "#F87171" }}
          >
            <AlertTriangle className="h-3 w-3" aria-hidden />
            At risk
          </span>
        </TooltipTrigger>
        <TooltipContent side="top" className="max-w-xs text-caption">
          Expedited to meet POR schedule — RTS pulled in {info.pulledInDays}d ({info.previousDate} → {info.newDate})
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
}
