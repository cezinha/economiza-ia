import { useMemo, useState } from "react";
import { History as HistoryIcon, RotateCcw } from "lucide-react";
import { toast } from "sonner";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import { useIsReadOnly } from "@/lib/permissions";
import {
  appendTaskHistory,
  formatHistoryWhen,
  getTaskHistory,
  type TaskHistoryEntry,
  type TaskHistoryField,
} from "@/mocks/taskHistory";

const FILTERS: { value: TaskHistoryField | "all"; label: string }[] = [
  { value: "all", label: "All" },
  { value: "status", label: "Status" },
  { value: "primaryOwner", label: "Owner" },
  { value: "dueDate", label: "Due date" },
  { value: "comment", label: "Comments" },
  { value: "attachment", label: "Attachments" },
];

interface Props {
  taskId: string | number;
  onRestoreField?: (field: TaskHistoryField, value: string) => void;
}

export function TaskHistorySection({ taskId, onRestoreField }: Props) {
  const readOnly = useIsReadOnly();
  const [filter, setFilter] = useState<TaskHistoryField | "all">("all");
  // tick state to re-render after appending an entry
  const [, force] = useState(0);

  const entries = useMemo(() => getTaskHistory(taskId), [taskId, filter]); // eslint-disable-line react-hooks/exhaustive-deps

  const visible = useMemo(
    () => (filter === "all" ? entries : entries.filter((e) => e.field === filter)),
    [entries, filter],
  );

  const grouped = useMemo(() => {
    const out: { day: string; rows: TaskHistoryEntry[] }[] = [];
    for (const e of visible) {
      const { day } = formatHistoryWhen(e.timestamp);
      const last = out[out.length - 1];
      if (last && last.day === day) last.rows.push(e);
      else out.push({ day, rows: [e] });
    }
    return out;
  }, [visible]);

  const handleRestoreField = (e: TaskHistoryEntry) => {
    if (!e.before) return;
    onRestoreField?.(e.field, e.before);
    appendTaskHistory({
      taskId,
      actor: { name: "You", initials: "YO" },
      field: e.field,
      label: e.label,
      before: e.after,
      after: e.before,
      note: `Restored ${e.label.toLowerCase()} to "${e.before}"`,
    });
    force((n) => n + 1);
    toast.success(`${e.label} restored to "${e.before}"`);
  };

  const handleRestoreAll = (e: TaskHistoryEntry) => {
    appendTaskHistory({
      taskId,
      actor: { name: "You", initials: "YO" },
      field: e.field,
      label: e.label,
      before: e.after,
      after: e.before,
      note: `Restored task snapshot from ${formatHistoryWhen(e.timestamp).day}`,
    });
    if (e.before) onRestoreField?.(e.field, e.before);
    force((n) => n + 1);
    toast.success(`Restored snapshot from ${formatHistoryWhen(e.timestamp).day}`);
  };

  return (
    <section className="space-y-3">
      <div className="flex items-center justify-between gap-3 flex-wrap">
        <h3 className="text-subtitle-2 text-foreground inline-flex items-center gap-2">
          <HistoryIcon className="h-4 w-4 text-muted-foreground" />
          History
        </h3>
        <div className="flex flex-wrap gap-1">
          {FILTERS.map((f) => (
            <button
              key={f.value}
              type="button"
              onClick={() => setFilter(f.value)}
              className={cn(
                "px-2 py-1 rounded-md text-caption transition-colors border",
                filter === f.value
                  ? "bg-primary/10 border-primary/30 text-primary"
                  : "bg-transparent border-border text-muted-foreground hover:bg-muted/40",
              )}
            >
              {f.label}
            </button>
          ))}
        </div>
      </div>

      {visible.length === 0 ? (
        <p className="text-caption text-muted-foreground italic">
          No edits yet — changes you and your team make will appear here.
        </p>
      ) : (
        <ol className="space-y-4">
          {grouped.map((group) => (
            <li key={group.day} className="space-y-2">
              <p className="text-caption uppercase tracking-wide text-muted-foreground">
                {group.day}
              </p>
              <ul className="space-y-2">
                {group.rows.map((e) => {
                  const { time } = formatHistoryWhen(e.timestamp);
                  const canRestore = !readOnly && !!e.before && e.field !== "comment" && e.field !== "attachment";
                  return (
                    <li
                      key={e.id}
                      className="group flex items-start gap-3 p-3 rounded-md border border-border hover:bg-muted/30 transition-colors"
                    >
                      <Avatar className="h-7 w-7 shrink-0">
                        <AvatarFallback className="text-caption">
                          {e.actor.initials}
                        </AvatarFallback>
                      </Avatar>
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="text-body-3 font-medium text-foreground">
                            {e.actor.name}
                          </span>
                          <span className="text-caption text-muted-foreground tabular-nums">
                            {time}
                          </span>
                        </div>
                        <p className="mt-1 text-body-3 text-foreground">
                          {e.note ? (
                            <span>{e.note}</span>
                          ) : canRestore ? (
                            <>
                              <button
                                type="button"
                                onClick={() => handleRestoreField(e)}
                                className="text-foreground font-medium hover:text-primary hover:underline"
                                title={`Restore ${e.label.toLowerCase()} to "${e.before}"`}
                              >
                                {e.label}
                              </button>
                              :{" "}
                              <span className="text-muted-foreground line-through">{e.before}</span>{" "}
                              <span aria-hidden>→</span>{" "}
                              <span className="text-foreground">{e.after}</span>
                            </>
                          ) : (
                            <>
                              <span className="font-medium">{e.label}</span>:{" "}
                              {e.before && (
                                <span className="text-muted-foreground line-through">{e.before} </span>
                              )}
                              {e.after && <span className="text-foreground">→ {e.after}</span>}
                            </>
                          )}
                        </p>
                      </div>
                      {canRestore && (
                        <Button
                          variant="ghost"
                          size="sm"
                          className="opacity-0 group-hover:opacity-100 focus-visible:opacity-100 transition-opacity gap-1 shrink-0"
                          onClick={() => handleRestoreAll(e)}
                        >
                          <RotateCcw className="h-3 w-3" />
                          Restore
                        </Button>
                      )}
                      {!canRestore && e.field === "attachment" && (
                        <Badge variant="outline" className="text-caption shrink-0">
                          File
                        </Badge>
                      )}
                    </li>
                  );
                })}
              </ul>
            </li>
          ))}
        </ol>
      )}
    </section>
  );
}
