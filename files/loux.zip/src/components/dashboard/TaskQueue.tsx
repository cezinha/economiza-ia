import { useEffect, useMemo, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Eye, Lock, AlertTriangle } from "lucide-react";
import { useFilteredLaunches } from "@/lib/applyFilters";
import { useFilters } from "@/contexts/FilterContext";
import {
  tasksForLaunch,
  taskStatus,
  worstActive,
  isAutoTask,
  type LaunchTask,
  type TaskStatus,
} from "@/lib/launchTasks";
import { Badge } from "@/components/ui/badge";
import { dueDateFor } from "@/lib/tasks";
import { TaskDetailDrawer } from "@/components/dashboard/TaskDetailDrawer";
import { useIsReadOnly, canActOnPlatformInfo, useAssignedPlatformIds, useAssignedPlatformNames, isSensitiveLockedFor } from "@/lib/permissions";
import { phaseNamesFromFilter } from "@/lib/filterCascade";
import { useViewFilter } from "@/contexts/ViewFilterContext";
import { useRole } from "@/contexts/RoleContext";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import type { Launch } from "@/mocks/launches";
import {
  buildLaunchDependencyResolver,
  type LaunchDependencyResolver,
  type PredecessorRef,
  type ClearedRef,
} from "@/lib/taskDependencies";
import { TaskDependencyChip } from "@/components/dashboard/TaskDependencyChip";
import { TaskRunwayChip } from "@/components/dashboard/TaskRunwayChip";
import { type BannerBucket } from "@/components/dashboard/TaskQueueBanners";
import { taskRunwayBucket } from "@/lib/taskRunway";
import { useSearchParams } from "react-router-dom";
import { DdsPagination } from "@/components/shell/DdsPagination";
import { StatusLegend } from "@/components/dashboard/StatusLegend";
import { TaskExpeditedChip } from "@/components/dashboard/TaskExpeditedChip";

const STATUS_RANK: Record<TaskStatus, number> = {
  "at-risk": 0,
  "at-risk-mitigated": 1,
  "on-track": 2,
  "not-started": 3,
  completed: 99,
};

const STATUS_DOT: Record<TaskStatus, string> = {
  completed: "bg-status-completed",
  "on-track": "bg-status-on-track",
  "at-risk-mitigated": "bg-status-at-risk-mitigated",
  "at-risk": "bg-status-at-risk",
  "not-started": "bg-status-not-started",
};

const STATUS_LABEL: Record<TaskStatus, string> = {
  completed: "Completed",
  "on-track": "On track",
  "at-risk-mitigated": "At risk (mitigated)",
  "at-risk": "At risk",
  "not-started": "Not started",
};

interface QueueItem {
  task: LaunchTask;
  launch: Launch;
  status: TaskStatus;
  due: string;
  completedAt?: Date;
  blockers: PredecessorRef[];
  recentlyCleared: ClearedRef[];
}

function hash(s: string): number {
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

function mockCompletedAt(taskId: string): Date {
  const daysAgo = hash(taskId) % 180;
  const d = new Date();
  d.setDate(d.getDate() - daysAgo);
  return d;
}

function formatRelative(d: Date): string {
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const target = new Date(d);
  target.setHours(0, 0, 0, 0);
  const diff = Math.round((today.getTime() - target.getTime()) / 86400000);
  if (diff <= 0) return "Today";
  if (diff === 1) return "Yesterday";
  if (diff < 30) return `${diff} days ago`;
  return d.toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" });
}

export function TaskQueue({ fillHeight = false, showPostMvpBadge = true }: { fillHeight?: boolean; showPostMvpBadge?: boolean } = {}) {
  const [selected, setSelected] = useState<QueueItem | null>(null);
  const readOnly = useIsReadOnly();
  const { role } = useRole();
  const { lockedFunction } = useViewFilter();
  const assignedIds = useAssignedPlatformIds();
  const assignedNames = useAssignedPlatformNames();
  const launches = useFilteredLaunches();
  const { filters } = useFilters();

  // Clear any stale selection whose launch is no longer in the filtered set
  // (e.g. after a Business Unit filter empties the list) to avoid passing
  // an undefined launch into TaskDetailDrawer.
  useEffect(() => {
    if (selected && !launches.some((l) => l.id === selected.launch.id)) {
      setSelected(null);
    }
  }, [launches, selected]);

  const fnFilter = Array.isArray(filters.function) ? (filters.function as string[]) : [];
  const phaseFilter = phaseNamesFromFilter(Array.isArray(filters.phase) ? (filters.phase as string[]) : []);
  const taskFilter = Array.isArray(filters.task) ? (filters.task as string[]) : [];
  const statusFilter = Array.isArray(filters.status) ? (filters.status as string[]) : [];

  const statusBucket = (s: TaskStatus): "achieved" | "risk-mitigated" | "missed" | null => {
    if (s === "completed" || s === "on-track") return "achieved";
    if (s === "at-risk-mitigated") return "risk-mitigated";
    if (s === "at-risk") return "missed";
    return null;
  };

  const { todoItems, notStartedItems, completedItems } = useMemo(() => {
    const todo: QueueItem[] = [];
    const notStarted: QueueItem[] = [];
    const done: QueueItem[] = [];
    const resolvers = new Map<string, LaunchDependencyResolver>();
    for (const launch of launches) {
      const allTasks = tasksForLaunch(launch);
      const resolver = buildLaunchDependencyResolver(launch, allTasks);
      resolvers.set(launch.id, resolver);
      for (const task of allTasks) {
        if (fnFilter.length && !task.teams.some((t) => fnFilter.includes(t))) continue;
        if (phaseFilter.length && !phaseFilter.includes(task.phase)) continue;
        if (taskFilter.length && !taskFilter.includes(task.task)) continue;
        const status = worstActive(task.teams.map((tm) => taskStatus(launch, task, tm)));
        if (statusFilter.length) {
          const b = statusBucket(status);
          if (!b || !statusFilter.includes(b)) continue;
        }
        const due = dueDateFor(launch, task.taskEnd);
        const { blockers, recentlyCleared } = resolver.chip(task);
        const base = { task, launch, status, due, blockers, recentlyCleared };
        if (status === "completed") {
          done.push({ ...base, completedAt: mockCompletedAt(task.id) });
        } else if (status === "not-started") {
          notStarted.push(base);
        } else {
          todo.push(base);
        }
      }
    }
    todo.sort((a, b) => {
      const r = STATUS_RANK[a.status] - STATUS_RANK[b.status];
      if (r !== 0) return r;
      return a.due.localeCompare(b.due);
    });
    notStarted.sort((a, b) => a.due.localeCompare(b.due));
    done.sort((a, b) => (b.completedAt!.getTime() - a.completedAt!.getTime()));
    return { todoItems: todo, notStartedItems: notStarted, completedItems: done };
  }, [launches, fnFilter, phaseFilter, taskFilter, statusFilter]);

  // Runway buckets — derived from todoItems (auto/completed/phase-close already excluded by status).
  const { todoOverdueIds, todoSoonIds } = useMemo(() => {
    const overdue = new Set<string>();
    const soon = new Set<string>();
    const today = new Date();
    for (const it of todoItems) {
      const bucket = taskRunwayBucket(it.launch, it.task, { status: it.status, today });
      if (bucket === "overdue") overdue.add(it.task.id);
      else if (bucket === "soon") soon.add(it.task.id);
    }
    return { todoOverdueIds: overdue, todoSoonIds: soon };
  }, [todoItems]);

  // URL-driven bucket filter retained for deep-links from PlatformTasks runway chips.
  const [searchParams, setSearchParams] = useSearchParams();
  const urlBucket = searchParams.get("bucket");
  const initialBucket: BannerBucket | null =
    urlBucket === "overdue" || urlBucket === "soon" ? urlBucket : null;
  const [bucketFilter, setBucketFilter] = useState<BannerBucket | null>(initialBucket);
  const [tab, setTab] = useState<"todo" | "not-started" | "completed">("todo");
  const [todoPage, setTodoPage] = useState(1);
  const [todoPageSize, setTodoPageSize] = useState(10);
  const [notStartedPage, setNotStartedPage] = useState(1);
  const [notStartedPageSize, setNotStartedPageSize] = useState(10);
  const [completedPage, setCompletedPage] = useState(1);
  const [completedPageSize, setCompletedPageSize] = useState(10);

  // Clear any stale bucket from the URL once we mount — the filter chips were removed.
  useEffect(() => {
    if (bucketFilter) {
      setBucketFilter(null);
      const params = new URLSearchParams(searchParams);
      params.delete("bucket");
      setSearchParams(params, { replace: true });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const visibleTodoItems = useMemo(() => {
    if (!bucketFilter) return todoItems;
    const ids = bucketFilter === "overdue" ? todoOverdueIds : todoSoonIds;
    return todoItems.filter((it) => ids.has(it.task.id));
  }, [todoItems, bucketFilter, todoOverdueIds, todoSoonIds]);

  const pagedTodo = useMemo(
    () => visibleTodoItems.slice((todoPage - 1) * todoPageSize, todoPage * todoPageSize),
    [visibleTodoItems, todoPage, todoPageSize],
  );
  const pagedNotStarted = useMemo(
    () => notStartedItems.slice((notStartedPage - 1) * notStartedPageSize, notStartedPage * notStartedPageSize),
    [notStartedItems, notStartedPage, notStartedPageSize],
  );
  const pagedCompleted = useMemo(
    () => completedItems.slice((completedPage - 1) * completedPageSize, completedPage * completedPageSize),
    [completedItems, completedPage, completedPageSize],
  );




  const renderRow = (it: QueueItem, mode: "todo" | "not-started" | "completed") => {
    const isBlocked = mode !== "completed" && it.blockers.length > 0;
    const canAct = canActOnPlatformInfo(role, assignedIds, assignedNames, {
      id: it.launch.id,
      name: it.launch.name,
    });
    const sensitive = isSensitiveLockedFor(role, lockedFunction, it.task);
    const runwayChip: "overdue" | "soon" | null =
      mode === "todo"
        ? todoOverdueIds.has(it.task.id)
          ? "overdue"
          : todoSoonIds.has(it.task.id)
          ? "soon"
          : null
        : null;
    return (
      <li
        key={it.task.id}
        className={cn(
          "flex items-start gap-3 px-4 py-3 transition-colors",
          !sensitive && "hover:bg-muted/40",
          isBlocked && "opacity-60",
        )}
      >
        <div className="flex-1 min-w-0">
          {/* Line 1 — status dot · Platform · LOB · Phase · Owner · ID */}
          <div className="flex items-center gap-2 flex-wrap text-caption text-muted-foreground">
            <span
              className={cn(
                "inline-block h-2 w-2 rounded-full shrink-0",
                STATUS_DOT[it.status],
              )}
              aria-label={STATUS_LABEL[it.status]}
            />
            <span className="font-medium text-foreground/80">{it.launch.name}</span>
            <span>· {it.launch.lob}</span>
            <span>· {it.task.phase}</span>
            {it.launch.owner && <span>· {it.launch.owner}</span>}
            {it.task.l3Id != null && (
              <span className="tabular-nums">· ID: {it.task.l3Id}</span>
            )}
            {mode === "completed" && (
              <span>· Completed {formatRelative(it.completedAt!)}</span>
            )}
          </div>

          {/* Line 2 — Task name */}
          <p className="text-body-3 font-medium text-foreground mt-1 flex items-center gap-2 min-w-0">
            {isBlocked && (
              <Lock className="inline h-3 w-3 text-status-at-risk shrink-0" aria-hidden />
            )}
            <span className="truncate">{it.task.task}</span>
          </p>

          {/* Line 3 — Contextual badges (only if any) */}
          <div className="flex items-center gap-2 flex-wrap mt-1 empty:hidden">
            {isAutoTask(it.task) && (
              <Badge className="text-caption border-transparent text-white bg-[linear-gradient(90deg,#0063B8_0%,#7F234F_50%,#40155C_100%)] hover:opacity-90">Auto</Badge>
            )}
            {mode !== "completed" && (
              <TaskRunwayChip launch={it.launch} task={it.task} status={it.status} />
            )}
            {sensitive && (
              <TooltipProvider delayDuration={150}>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Badge variant="outline" className="text-caption gap-1 cursor-default">
                      <Lock className="h-3 w-3" />
                      Sensitive information
                    </Badge>
                  </TooltipTrigger>
                  <TooltipContent side="top" className="max-w-xs text-caption">
                    SChM-only task — sensitive supply chain data. Switch to a
                    SChM view to open.
                  </TooltipContent>
                </Tooltip>
              </TooltipProvider>
            )}
            {!sensitive && !canAct && !readOnly && mode !== "completed" && (
              <Badge variant="outline" className="text-caption">Not your platform</Badge>
            )}
            {mode !== "completed" && (
              <TaskDependencyChip
                blockers={it.blockers}
                recentlyCleared={it.recentlyCleared}
                onClick={sensitive ? undefined : () => setSelected(it)}
              />
            )}
          </div>
        </div>

        {sensitive ? null : (
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button
                  size="sm"
                  variant="outline"
                  className="shrink-0"
                  onClick={() => setSelected(it)}
                >
                  <Eye className="h-4 w-4 mr-2" /> View task
                </Button>
              </TooltipTrigger>
              {!canAct && !readOnly && mode !== "completed" && (
                <TooltipContent className="text-caption max-w-xs">
                  Read-only — this platform isn't in your assigned set. You can
                  view details and add comments, but only assigned owners can
                  complete tasks.
                </TooltipContent>
              )}
            </Tooltip>
          </TooltipProvider>
        )}
      </li>
    );
  };

  return (
    <>
      <div className={cn("space-y-4", fillHeight && "flex flex-col flex-1 min-h-0")}>
        <Card className={cn("border-border bg-surface shadow-elev-1 flex flex-col", fillHeight ? "h-full flex-1 min-h-0" : "h-full")}>
          <CardHeader className="pb-4">
            <div className="flex items-start justify-between gap-4">
              <div className="min-w-0 space-y-2">
                <h5 className="text-h5 text-foreground">Task tracker</h5>
                <p className="text-caption text-muted-foreground">Tasks across platforms</p>
                <StatusLegend />
              </div>
              {showPostMvpBadge && (
                <span className="shrink-0 rounded-full border border-border bg-muted px-2 py-0.5 text-caption text-muted-foreground">
                  Post-MVP
                </span>
              )}
            </div>
          </CardHeader>
          <CardContent className={cn("p-0", fillHeight && "flex-1 min-h-0 flex flex-col")}>

            <Tabs
              value={tab}
              onValueChange={(v) => setTab(v as "todo" | "not-started" | "completed")}
              className={cn("w-full", fillHeight && "flex-1 min-h-0 flex flex-col")}
            >
              <div className="px-4 pt-2">
                <TabsList>
                  <TabsTrigger value="todo">To do</TabsTrigger>
                  <TabsTrigger value="not-started">Not started</TabsTrigger>
                  <TabsTrigger value="completed">Completed</TabsTrigger>
                </TabsList>
              </div>

              <TabsContent value="todo" className={cn("mt-2", fillHeight && "flex-1 min-h-0 data-[state=active]:flex flex-col")}>
                {visibleTodoItems.length === 0 ? (
                  <p className="px-4 py-6 text-caption text-muted-foreground italic">
                    No open tasks.
                  </p>
                ) : (
                  <>
                    <ul className={cn("divide-y divide-border overflow-y-auto", fillHeight ? "flex-1 min-h-0" : "max-h-[288px]")}>
                      {pagedTodo.map((it) => renderRow(it, "todo"))}
                    </ul>
                    <div className="border-t border-border px-4 py-3">
                      <DdsPagination
                        page={todoPage}
                        pageSize={todoPageSize}
                        totalItems={visibleTodoItems.length}
                        itemLabel="tasks"
                        onPageChange={setTodoPage}
                        onPageSizeChange={setTodoPageSize}
                      />
                    </div>
                  </>
                )}
              </TabsContent>
            <TabsContent value="not-started" className={cn("mt-2", fillHeight && "flex-1 min-h-0 data-[state=active]:flex flex-col")}>
              {notStartedItems.length === 0 ? (
                <p className="px-4 py-6 text-caption text-muted-foreground italic">
                  No tasks waiting on a future phase.
                </p>
              ) : (
                <>
                  <ul className={cn("divide-y divide-border overflow-y-auto", fillHeight ? "flex-1 min-h-0" : "max-h-[288px]")}>
                    {pagedNotStarted.map((it) => renderRow(it, "not-started"))}
                  </ul>
                  <div className="border-t border-border px-4 py-3">
                    <DdsPagination
                      page={notStartedPage}
                      pageSize={notStartedPageSize}
                      totalItems={notStartedItems.length}
                      itemLabel="tasks"
                      onPageChange={setNotStartedPage}
                      onPageSizeChange={setNotStartedPageSize}
                    />
                  </div>
                </>
              )}
            </TabsContent>
            <TabsContent value="completed" className={cn("mt-2", fillHeight && "flex-1 min-h-0 data-[state=active]:flex flex-col")}>
              {completedItems.length === 0 ? (
                <p className="px-4 py-6 text-caption text-muted-foreground italic">
                  No completed tasks yet.
                </p>
              ) : (
                <>
                  <ul className={cn("divide-y divide-border overflow-y-auto", fillHeight ? "flex-1 min-h-0" : "max-h-[288px]")}>
                    {pagedCompleted.map((it) => renderRow(it, "completed"))}
                  </ul>
                  <div className="border-t border-border px-4 py-3">
                    <DdsPagination
                      page={completedPage}
                      pageSize={completedPageSize}
                      totalItems={completedItems.length}
                      itemLabel="tasks"
                      onPageChange={setCompletedPage}
                      onPageSizeChange={setCompletedPageSize}
                    />
                  </div>
                </>
              )}
            </TabsContent>

            </Tabs>
          </CardContent>
        </Card>
      </div>


      {selected?.launch && (
        <TaskDetailDrawer
          task={selected.task}
          launch={selected.launch}
          initialStatus={selected.status}
          onOpenChange={(o) => !o && setSelected(null)}
        />
      )}
    </>
  );
}
