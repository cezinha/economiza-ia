import { AlertTriangle } from "lucide-react";
import { cn } from "@/lib/utils";

export type BannerBucket = "overdue" | "soon";

interface Props {
  overdue: number;
  dueSoon: number;
  activeBucket?: BannerBucket | null;
  onSelectBucket?: (bucket: BannerBucket) => void;
}

interface ChipProps {
  count: number;
  bucket: BannerBucket;
  active: boolean;
  onClick?: () => void;
}

const PILL_STYLE: React.CSSProperties = {
  backgroundColor: "#3D2A00",
  color: "#F5A623",
};

function RunwayChip({ count, bucket, active, onClick }: ChipProps) {
  const empty = count === 0;
  const label = bucket === "overdue" ? "Overdue" : "Upcoming";
  const tooltip =
    bucket === "overdue"
      ? "Past their due date"
      : "Suggested duration exceeds remaining runway";

  const clickable = !empty && !!onClick;
  const Tag = clickable ? "button" : "span";

  return (
    <Tag
      type={clickable ? "button" : undefined}
      onClick={clickable ? onClick : undefined}
      aria-pressed={clickable ? active : undefined}
      title={tooltip}
      className={cn(
        "inline-flex items-center gap-2 rounded-full px-3 py-1 text-caption whitespace-nowrap shrink-0 transition",
        empty && "opacity-50 cursor-default",
        clickable && "hover:brightness-110 cursor-pointer",
        active && "ring-1 ring-offset-1 ring-offset-background",
      )}
      style={
        empty
          ? undefined
          : { ...PILL_STYLE, ...(active ? { boxShadow: "0 0 0 1px #F5A623" } : {}) }
      }
    >
      <AlertTriangle className="h-3 w-3" aria-hidden />
      <span className="tabular-nums font-medium">{count}</span>
      <span>{label}</span>
    </Tag>
  );
}

export function RunwayChips({ overdue, dueSoon, activeBucket = null, onSelectBucket }: Props) {
  return (
    <div className="flex items-center gap-2 flex-wrap">
      <RunwayChip
        count={overdue}
        bucket="overdue"
        active={activeBucket === "overdue"}
        onClick={onSelectBucket ? () => onSelectBucket("overdue") : undefined}
      />
      <RunwayChip
        count={dueSoon}
        bucket="soon"
        active={activeBucket === "soon"}
        onClick={onSelectBucket ? () => onSelectBucket("soon") : undefined}
      />
    </div>
  );
}

/** @deprecated use RunwayChips */
export const TaskQueueBanners = RunwayChips;
