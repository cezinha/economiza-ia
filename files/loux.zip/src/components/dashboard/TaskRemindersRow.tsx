import { useEffect, useState } from "react";
import { Bell, BellOff, Clock } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import {
  cadenceLabel,
  formatAbsolute,
  getReminderCadence,
  getReminderState,
  isMuted,
  isSnoozed,
  muteReminder,
  snoozeReminder,
  subscribeReminders,
  unmuteReminder,
} from "@/mocks/reminders";
import type { RAG } from "@/mocks/launches";

interface Props {
  taskRef: string;
  rag: RAG;
}

export function TaskRemindersRow({ taskRef, rag }: Props) {
  const [, force] = useState(0);
  useEffect(() => {
    const unsub = subscribeReminders(() => force((n) => n + 1));
    return () => {
      unsub();
    };
  }, []);

  const cadence = getReminderCadence(rag);
  const muted = isMuted(taskRef);
  const snoozed = isSnoozed(taskRef);
  const s = getReminderState(taskRef);

  if (cadence === "none") return null;

  const statusLabel =
    rag === "red"
      ? "At risk"
      : rag === "amber"
        ? "At risk (mitigated)"
        : "On track";

  const description = muted
    ? `Muted${s.muteExpiresAt ? ` until ${formatAbsolute(s.muteExpiresAt)}` : ""}`
    : snoozed && s.until
      ? `Snoozed until ${formatAbsolute(s.until)}`
      : `${cadence === "daily" ? "Daily" : "Weekly"} reminders active (status: ${statusLabel}). ${cadenceLabel(cadence)}.`;

  return (
    <section className="space-y-2">
      <h3 className="text-subtitle-2 text-foreground inline-flex items-center gap-2">
        <Bell className="h-4 w-4 text-muted-foreground" />
        Reminders
      </h3>
      <div className="flex items-start justify-between gap-3 rounded-md border border-border p-3 flex-wrap">
        <p className="text-body-3 text-foreground flex-1 min-w-0">
          {description}
        </p>
        <div className="flex items-center gap-2 shrink-0">
          <Popover>
            <PopoverTrigger asChild>
              <Button variant="outline" size="sm" className="gap-1">
                <Clock className="h-3 w-3" />
                Snooze
              </Button>
            </PopoverTrigger>
            <PopoverContent align="end" className="w-44 p-1">
              <ul>
                {[
                  { label: "1 day", days: 1 },
                  { label: "3 days", days: 3 },
                  { label: "1 week", days: 7 },
                ].map((opt) => (
                  <li key={opt.days}>
                    <button
                      type="button"
                      onClick={() => {
                        snoozeReminder(taskRef, opt.days);
                        toast.success(`Reminder snoozed for ${opt.label}`);
                      }}
                      className="w-full text-left px-2 py-2 rounded-sm text-body-3 hover:bg-muted/40"
                    >
                      {opt.label}
                    </button>
                  </li>
                ))}
              </ul>
            </PopoverContent>
          </Popover>
          {muted ? (
            <Button
              variant="outline"
              size="sm"
              className="gap-1"
              onClick={() => {
                unmuteReminder(taskRef);
                toast.success("Reminders unmuted");
              }}
            >
              <Bell className="h-3 w-3" />
              Unmute
            </Button>
          ) : (
            <Button
              variant="outline"
              size="sm"
              className="gap-1"
              onClick={() => {
                muteReminder(taskRef, rag);
                toast(rag === "red" ? "Muted — auto-resumes in 7 days" : "Muted");
              }}
            >
              <BellOff className="h-3 w-3" />
              Mute
            </Button>
          )}
        </div>
      </div>
    </section>
  );
}
