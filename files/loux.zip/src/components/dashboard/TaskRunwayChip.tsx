import { AlertTriangle } from "lucide-react";
import { cn } from "@/lib/utils";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import type { Launch } from "@/mocks/launches";
import type { LaunchTask, TaskStatus } from "@/lib/launchTasks";
import { taskRunwayBucket } from "@/lib/taskRunway";
import { runwayDays } from "@/lib/minDuration";
import { getOverrideBucket, getOverriddenOverdueDays } from "@/mocks/runwayBucketOverrides";

interface Props {
  launch: Launch;
  task: LaunchTask;
  status?: TaskStatus;
  className?: string;
}

/**
 * Pill rendered next to a task to flag schedule risk.
 *  - "Warning" — task min duration > runway remaining (amber)
 *  - "Overdue" — task is overdue by 7 days or less (orange/red)
 *  - "Overdue - Urgent" — task is overdue by more than 7 days (deep red)
 * Returns null for healthy / completed tasks.
 */
export function TaskRunwayChip({ launch, task, status, className }: Props) {
  const bucket = taskRunwayBucket(launch, task, { status });

  if (bucket === "soon") {
    return (
      <ChipShell
        label="Warning"
        tooltip="Time remaining is less than the suggested minimum to complete this task"
        bg="#3D2A00"
        fg="#F5A623"
        className={className}
      />
    );
  }

  if (bucket === "overdue") {
    const overrideBucket = getOverrideBucket(task.id);
    const overrideDays = getOverriddenOverdueDays(task.id);
    const overdueBy = overrideDays ?? Math.abs(runwayDays(launch, task));
    const urgent =
      overrideBucket === "overdue-urgent" ||
      (overrideBucket !== "overdue" && overdueBy > 7);
    return (
      <ChipShell
        label={urgent ? "Overdue - Urgent" : "Overdue"}
        tooltip={
          urgent
            ? `Overdue by ${overdueBy} days — escalate or request an exception`
            : `Overdue by ${overdueBy} day${overdueBy === 1 ? "" : "s"}`
        }
        bg="#3D2A00"
        fg="#F5A623"
        className={className}
      />
    );
  }

  return null;
}

function ChipShell({
  label,
  tooltip,
  bg,
  fg,
  className,
}: {
  label: string;
  tooltip: string;
  bg: string;
  fg: string;
  className?: string;
}) {
  return (
    <TooltipProvider delayDuration={150}>
      <Tooltip>
        <TooltipTrigger asChild>
          <span
            className={cn(
              "inline-flex items-center gap-1 rounded-full px-2 py-1 text-caption whitespace-nowrap shrink-0 cursor-default",
              className,
            )}
            style={{ backgroundColor: bg, color: fg }}
          >
            <AlertTriangle className="h-3 w-3" aria-hidden />
            {label}
          </span>
        </TooltipTrigger>
        <TooltipContent side="top" className="max-w-xs text-caption">
          {tooltip}
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
}
