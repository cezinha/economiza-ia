import { useMemo } from "react";
import { useNavigate } from "react-router-dom";
import { Star, Lock, X } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { MultiSelectCombobox } from "@/components/shell/MultiSelectCombobox";
import { useWatchlist } from "@/contexts/WatchlistContext";
import { launches } from "@/mocks/launches";
import { platformStatus, type TaskStatus } from "@/lib/launchTasks";
import { cn } from "@/lib/utils";

const STATUS_CLASS: Record<TaskStatus, string> = {
  "completed": "bg-status-completed",
  "on-track": "bg-status-on-track",
  "at-risk-mitigated": "bg-status-at-risk-mitigated",
  "at-risk": "bg-status-at-risk",
  "not-started": "bg-status-not-started",
};

const STATUS_LABEL: Record<TaskStatus, string> = {
  "completed": "Completed",
  "on-track": "On track",
  "at-risk-mitigated": "At risk (mitigated)",
  "at-risk": "At risk",
  "not-started": "Not started",
};

export function WatchlistPanel() {
  const navigate = useNavigate();
  const { watched, add, remove, isLocked, lockedReason, isItemLocked, itemLockedReason } = useWatchlist();
  const items = useMemo(
    () =>
      watched
        .map((id) => launches.find((l) => l.id === id))
        .filter((x): x is NonNullable<typeof x> => Boolean(x)),
    [watched],
  );

  const platformOptions = useMemo(
    () =>
      [...launches]
        .sort((a, b) => (a.lob + a.name).localeCompare(b.lob + b.name))
        .map((l) => ({ value: l.id, label: `${l.lob} · ${l.name}` })),
    [],
  );

  const onPickerChange = (next: string[]) => {
    const cur = new Set(watched);
    const incoming = new Set(next);
    for (const id of next) if (!cur.has(id)) add(id);
    for (const id of watched) if (!incoming.has(id)) remove(id);
  };

  return (
    <section className="space-y-4">
      <div className="flex flex-wrap items-center justify-start gap-3">
        <div className="flex items-center gap-3">
          <h2 className="text-h4 text-foreground">
            My watchlist
          </h2>
          <Badge variant="secondary" className="text-caption font-normal">
            {items.length}/{launches.length} platforms
          </Badge>
          {isLocked && (
            <Badge variant="secondary" className="gap-1 text-caption font-normal" title={lockedReason}>
              <Lock className="h-3 w-3" /> Locked — Superadmin default
            </Badge>
          )}
          <span className="shrink-0 rounded-full border border-border bg-muted px-2 py-0.5 text-caption text-muted-foreground">
            Post-MVP
          </span>
        </div>
        {!isLocked && (
          <div className="w-[280px]">
            <MultiSelectCombobox
              options={platformOptions}
              values={watched}
              onChange={onPickerChange}
              placeholder="Add platforms…"
              searchPlaceholder="Search platforms…"
            />
          </div>
        )}
      </div>

      {items.length === 0 ? (
        <Card className="border-dashed border-border bg-surface">
          <CardContent className="py-10 text-center">
            <p className="text-body-2 text-foreground">No platforms on your watchlist yet</p>
            <p className="text-caption text-muted-foreground mt-1">
              Use the picker above, or star any platform across the dashboard.
            </p>
          </CardContent>
        </Card>
      ) : (
        <Card className="border-border bg-surface shadow-elev-1">
          <CardContent className="p-0">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="text-caption tracking-wide text-muted-foreground">Platform</TableHead>
                  <TableHead className="text-caption tracking-wide text-muted-foreground">Business unit</TableHead>
                  <TableHead className="text-caption tracking-wide text-muted-foreground">LOB</TableHead>
                  <TableHead className="text-caption tracking-wide text-muted-foreground">Current phase</TableHead>
                  <TableHead className="w-10" />
                </TableRow>
              </TableHeader>
              <TableBody>
                {items.map((l) => {
                  const status = platformStatus(l);
                  return (
                  <TableRow
                    key={l.id}
                    className="cursor-pointer"
                    onClick={() => navigate(`/tasks?tab=platform&launch=${l.id}`)}
                  >
                    <TableCell className="text-body-3 font-medium text-foreground">
                      <span className="inline-flex items-center gap-2 min-w-0">
                        <span
                          className={cn("inline-block h-2 w-2 rounded-full shrink-0", STATUS_CLASS[status])}
                          title={STATUS_LABEL[status]}
                          aria-label={STATUS_LABEL[status]}
                        />
                        <span className="truncate">{l.name}</span>
                      </span>
                    </TableCell>
                    <TableCell className="text-body-3 text-foreground">CSG</TableCell>
                    <TableCell className="text-body-3 text-foreground">{l.lob}</TableCell>
                    <TableCell className="text-body-3 text-foreground">{l.phase}</TableCell>
                    <TableCell>
                      {isItemLocked(l.id) ? (
                        <span
                          title={isLocked ? lockedReason : itemLockedReason}
                          className="inline-flex h-7 w-7 items-center justify-center rounded-md text-muted-foreground"
                        >
                          <Lock className="h-3 w-3" />
                        </span>
                      ) : (
                        <button
                          type="button"
                          aria-label={`Remove ${l.name} from watchlist`}
                          onClick={(e) => { e.stopPropagation(); remove(l.id); }}
                          className="inline-flex h-7 w-7 items-center justify-center rounded-md text-muted-foreground hover:bg-muted hover:text-foreground"
                        >
                          <X className="h-4 w-4" />
                        </button>
                      )}
                    </TableCell>
                  </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      )}
    </section>
  );
}
