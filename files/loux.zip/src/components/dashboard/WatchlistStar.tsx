import { Star, Lock } from "lucide-react";
import { toast } from "sonner";
import { cn } from "@/lib/utils";
import { useWatchlist } from "@/contexts/WatchlistContext";

interface Props {
  platformId: string;
  platformName?: string;
  className?: string;
  /** Deprecated — kept for backwards compatibility; watchlist now shows for all roles. */
  executiveOnly?: boolean;
}

export function WatchlistStar({ platformId, platformName, className }: Props) {
  const { isWatched, toggle, isLocked, lockedReason, isItemLocked, itemLockedReason } = useWatchlist();
  const watched = isWatched(platformId);
  const itemLocked = isItemLocked(platformId);
  const locked = isLocked || itemLocked;
  const reason = isLocked ? lockedReason : itemLocked ? itemLockedReason : undefined;

  const handle = (e: React.MouseEvent) => {
    e.stopPropagation();
    e.preventDefault();
    if (locked) return;
    const nowOn = toggle(platformId);
    toast.success(
      nowOn
        ? `Added ${platformName ?? "platform"} to watchlist`
        : `Removed ${platformName ?? "platform"} from watchlist`,
    );
  };

  return (
    <button
      type="button"
      onClick={handle}
      disabled={locked}
      title={locked ? reason : undefined}
      aria-label={
        locked
          ? reason
          : watched
            ? "Remove from watchlist"
            : "Add to watchlist"
      }
      aria-pressed={watched}
      className={cn(
        "relative inline-flex h-6 w-6 items-center justify-center rounded-md transition-colors",
        !locked && "hover:bg-muted",
        locked && "cursor-default",
        className,
      )}
    >
      <Star
        className={cn(
          "h-4 w-4",
          watched ? "fill-status-at-risk-mitigated text-status-at-risk-mitigated" : "text-muted-foreground",
        )}
        strokeWidth={1.75}
      />
      {locked && (
        <Lock className="absolute -bottom-1 -right-1 h-2 w-2 text-muted-foreground" strokeWidth={2.5} />
      )}
    </button>
  );
}
