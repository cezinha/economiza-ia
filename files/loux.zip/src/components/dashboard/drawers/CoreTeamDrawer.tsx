import { useNavigate } from "react-router-dom";
import { DashboardDetailDrawer, DrawerEmpty } from "./DashboardDetailDrawer";
import { useFilters } from "@/contexts/FilterContext";
import { currentPhaseName, functionStatus, type TaskStatus } from "@/lib/launchTasks";
import type { ScheduleTrack } from "@/lib/schedule";
import type { Launch } from "@/mocks/launches";
import { coreTeamOwnStatus } from "@/mocks/coreTeamStatus";

const TRACKS: ScheduleTrack[] = ["GOE", "NPI", "SChM"];

const STATUS_DOT: Record<TaskStatus, string> = {
  completed: "bg-status-completed",
  "on-track": "bg-status-on-track",
  "at-risk-mitigated": "bg-status-at-risk-mitigated",
  "at-risk": "bg-status-at-risk",
  "not-started": "bg-status-not-started",
};

const STATUS_LABEL: Record<TaskStatus, string> = {
  completed: "Completed",
  "on-track": "On track",
  "at-risk-mitigated": "Mitigated",
  "at-risk": "At risk",
  "not-started": "Not started",
};

const trackLabel = (t: ScheduleTrack) => (t === "SChM" ? "SChM" : t);

type Props = {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  launch: Launch | null;
};

export function CoreTeamDrawer({ open, onOpenChange, launch }: Props) {
  const navigate = useNavigate();
  const { setFilter } = useFilters();

  if (!launch) {
    return (
      <DashboardDetailDrawer
        open={open}
        onOpenChange={onOpenChange}
        eyebrow="Status distribution by current phase"
        title="Core team status"
        description="Roll-up of GOE, NPI, SChM and the Core team's own signal."
      >
        <DrawerEmpty>No platform selected.</DrawerEmpty>
      </DashboardDetailDrawer>
    );
  }

  const overall = functionStatus(launch, "Core");
  const own = coreTeamOwnStatus(launch.id);

  const go = (t?: ScheduleTrack) => {
    if (t) setFilter("function", [t]);
    onOpenChange(false);
    navigate(`/tasks?tab=platform&launch=${encodeURIComponent(launch.id)}`);
  };

  const rows: Array<{
    label: string;
    status: TaskStatus;
    note?: string;
    track?: ScheduleTrack;
  }> = [
    ...TRACKS.map((t) => ({
      label: trackLabel(t),
      status: functionStatus(launch, t),
      note:
        t === "NPI"
          ? "Mirrors GOE at the function level."
          : `Current phase: ${currentPhaseName(launch, t) ?? "—"}`,
      track: t,
    })),
    {
      label: "Core team own signal",
      status: own.status,
      note: own.reason ?? "No override — defaults to on track.",
    },
  ];

  return (
    <DashboardDetailDrawer
      open={open}
      onOpenChange={onOpenChange}
      eyebrow="Status distribution by current phase"
      title={`Core team · ${launch.name}`}
      description="Roll-up of GOE, NPI, SChM and the Core team's own signal. Mirrors the Core team track on the OLP schedule."
    >
      <div className="space-y-6">
        <div className="rounded-sm border border-border bg-surface px-4 py-3 flex items-center justify-between gap-3">
          <div className="min-w-0">
            <div className="text-caption text-muted-foreground">Overall Core team status</div>
            <div className="text-subtitle-2 text-foreground truncate">{launch.name}</div>
          </div>
          <span className="inline-flex items-center gap-2 rounded-sm border border-border px-2 py-1 text-caption text-foreground">
            <span className={`inline-block h-2 w-2 rounded-full ${STATUS_DOT[overall]}`} aria-hidden />
            {STATUS_LABEL[overall]}
          </span>
        </div>

        <ul className="rounded-sm border border-border bg-surface divide-y divide-border">
          {rows.map((r) => (
            <li key={r.label} className="px-4 py-3 flex items-center gap-3">
              <button
                type="button"
                onClick={() => go(r.track)}
                className="text-body-3 text-foreground hover:text-primary hover:underline text-left flex-1 min-w-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring rounded-sm"
              >
                <div className="truncate">{r.label}</div>
                {r.note && (
                  <div className="text-caption text-muted-foreground truncate">{r.note}</div>
                )}
              </button>
              <span className="inline-flex items-center gap-2 rounded-sm border border-border px-2 py-1 text-caption text-foreground">
                <span className={`inline-block h-2 w-2 rounded-full ${STATUS_DOT[r.status]}`} aria-hidden />
                {STATUS_LABEL[r.status]}
              </span>
            </li>
          ))}
        </ul>
      </div>
    </DashboardDetailDrawer>
  );
}
