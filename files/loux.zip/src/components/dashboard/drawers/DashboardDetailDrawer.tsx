import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
} from "@/components/ui/sheet";
import { cn } from "@/lib/utils";
import type { ReactNode } from "react";

type Props = {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  eyebrow: string;
  title: string;
  description?: string;
  children: ReactNode;
};

export function DashboardDetailDrawer({
  open,
  onOpenChange,
  eyebrow,
  title,
  description,
  children,
}: Props) {
  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent
        side="right"
        className={cn(
          "w-full sm:max-w-[1000px] sm:w-[92vw] overflow-y-auto p-0 bg-surface",
        )}
      >
        <SheetHeader className="px-6 pt-6 pb-4 border-b border-border space-y-2">
          <div className="text-caption text-muted-foreground">{eyebrow}</div>
          <SheetTitle className="text-h5 text-foreground">{title}</SheetTitle>
          {description ? (
            <SheetDescription>{description}</SheetDescription>
          ) : (
            <SheetDescription className="sr-only">{title}</SheetDescription>
          )}
        </SheetHeader>
        <div className="px-6 py-6">{children}</div>
      </SheetContent>
    </Sheet>
  );
}

export function DrawerEmpty({ children }: { children: ReactNode }) {
  return (
    <div className="rounded-sm border border-dashed border-border bg-muted/40 p-8 text-center text-body-3 text-muted-foreground">
      {children}
    </div>
  );
}

const STATUS_DOT_CLASS: Record<string, string> = {
  "on-track": "bg-status-on-track",
  "at-risk-mitigated": "bg-status-at-risk-mitigated",
  "at-risk": "bg-status-at-risk",
  completed: "bg-status-completed",
  "not-started": "bg-status-not-started",
};

const STATUS_LABEL: Record<string, string> = {
  "on-track": "On track",
  "at-risk-mitigated": "At risk · mitigated",
  "at-risk": "At risk",
  completed: "Completed",
  "not-started": "Not started",
};

export function StatusChip({
  status,
  onClick,
  className,
}: {
  status: keyof typeof STATUS_DOT_CLASS;
  onClick?: () => void;
  className?: string;
}) {
  const inner = (
    <span
      className={cn(
        "inline-flex items-center gap-2 rounded-sm border border-border px-2 py-1 text-caption text-foreground",
        onClick && "hover:bg-muted cursor-pointer transition-colors",
        className,
      )}
    >
      <span
        className={cn("inline-block h-2 w-2 rounded-full", STATUS_DOT_CLASS[status])}
        aria-hidden
      />
      <span>{STATUS_LABEL[status]}</span>
    </span>
  );
  if (onClick) {
    return (
      <button type="button" onClick={onClick} className="focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring rounded-sm">
        {inner}
      </button>
    );
  }
  return inner;
}
