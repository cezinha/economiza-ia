import { useNavigate } from "react-router-dom";
import { X } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogTitle,
} from "@/components/ui/dialog";
import { DrawerEmpty } from "./DashboardDetailDrawer";
import { NuddTableView } from "../NuddTableView";
import type { NuddRow } from "@/mocks/nudds";

type Props = {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  eyebrow: string;
  title: string;
  description?: string;
  rows: NuddRow[];
  emptyMessage?: string;
  onSelectRow?: (row: NuddRow) => void;
};

export function NuddListDrawer({
  open,
  onOpenChange,
  eyebrow,
  title,
  description,
  rows,
  emptyMessage = "No NUDDs match this selection.",
  onSelectRow,
}: Props) {
  const navigate = useNavigate();

  const goRow = (row: NuddRow) => {
    onOpenChange(false);
    if (onSelectRow) {
      onSelectRow(row);
    } else {
      navigate(`/risks?tab=table&nudd=${encodeURIComponent(row.id)}`);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent
        className="max-w-[1200px] w-[92vw] gap-0 border border-border bg-card p-0 shadow-elev-3 rounded-md [&>button]:hidden flex flex-col max-h-[85vh]"
        onOpenAutoFocus={(e) => e.preventDefault()}
      >
        <div className="flex items-start justify-between px-6 py-4 border-b border-border">
          <div className="space-y-1">
            <div className="text-caption text-muted-foreground">{eyebrow}</div>
            <DialogTitle className="text-h5 text-foreground">{title}</DialogTitle>
            {description ? (
              <DialogDescription className="text-body-3 text-muted-foreground">
                {description}
              </DialogDescription>
            ) : (
              <DialogDescription className="sr-only">{title}</DialogDescription>
            )}
          </div>
          <button
            type="button"
            aria-label="Close"
            onClick={() => onOpenChange(false)}
            className="text-muted-foreground hover:text-foreground focus:outline-none focus-visible:ring-2 focus-visible:ring-[#0672CB]"
          >
            <X className="h-4 w-4" />
          </button>
        </div>
        <div className="overflow-hidden px-6 py-6">
          {rows.length === 0 ? (
            <DrawerEmpty>{emptyMessage}</DrawerEmpty>
          ) : (
            <NuddTableView rows={rows} onOpenRow={goRow} maxHeightClass="max-h-[60vh]" />
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
