import { AlertTriangle, X } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogTitle,
} from "@/components/ui/dialog";
import { DrawerEmpty } from "./DashboardDetailDrawer";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { cn } from "@/lib/utils";

import type { Launch } from "@/mocks/launches";
import type { LaunchTask, TaskFunction } from "@/lib/launchTasks";
import type { OverdueTaskRow } from "@/lib/overdueTasks";


type Props = {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  launch: Launch;
  track: TaskFunction;
  rows: OverdueTaskRow[];
  onSelectTask: (task: LaunchTask) => void;
};

export function OverdueTasksDrawer({
  open,
  onOpenChange,
  launch,
  track,
  rows,
  onSelectTask,
}: Props) {
  const count = rows.length;
  const title = `${count} overdue ${track} task${count === 1 ? "" : "s"}`;
  const description = `Open ${track} tasks for ${launch.name} that have passed their due date.`;

  const goRow = (task: LaunchTask) => {
    onOpenChange(false);
    onSelectTask(task);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent
        className="max-w-[1200px] w-[92vw] gap-0 border border-border bg-card p-0 shadow-elev-3 rounded-md [&>button]:hidden flex flex-col max-h-[85vh]"
        onOpenAutoFocus={(e) => e.preventDefault()}
      >
        <div className="flex items-start justify-between px-6 py-4 border-b border-border">
          <div className="space-y-1">
            <div className="text-caption text-muted-foreground">
              Overdue tasks · {track} · {launch.name}
            </div>
            <DialogTitle className="text-h5 text-foreground">{title}</DialogTitle>
            <DialogDescription className="text-body-3 text-muted-foreground">
              {description}
            </DialogDescription>
          </div>
          <button
            type="button"
            aria-label="Close"
            onClick={() => onOpenChange(false)}
            className="text-muted-foreground hover:text-foreground focus:outline-none focus-visible:ring-2 focus-visible:ring-[#0672CB]"
          >
            <X className="h-4 w-4" />
          </button>
        </div>
        <div className="overflow-hidden px-6 py-6">
          {count === 0 ? (
            <DrawerEmpty>No overdue tasks for this function.</DrawerEmpty>
          ) : (
            <div className="overflow-auto max-h-[60vh] rounded-md border border-border">
              <table className="w-full text-body-3 text-foreground">
                <thead className="bg-muted/40 text-caption text-muted-foreground">
                  <tr>
                    <Th>Task</Th>
                    <Th>Phase</Th>
                    <Th>Gate</Th>
                    <Th>Status</Th>
                    <Th className="text-right">Overdue</Th>
                    <Th className="text-right">Action</Th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {rows.map(({ task, overdueDays }) => {
                    const urgent = overdueDays > 7;
                    return (
                      <tr key={task.id} className="hover:bg-muted/30">
                        <Td>
                          <span className="font-medium text-foreground">{task.task}</span>
                        </Td>
                        <Td className="text-muted-foreground">{task.phase}</Td>
                        <Td className="text-muted-foreground">{task.gate}</Td>
                        <Td>
                          <OverdueChip urgent={urgent} overdueDays={overdueDays} />
                        </Td>
                        <Td className="text-right tabular-nums">{overdueDays}d</Td>
                        <Td className="text-right">
                          <button
                            type="button"
                            onClick={() => goRow(task)}
                            className="text-caption text-primary hover:underline focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring rounded-sm"
                          >
                            View Details
                          </button>
                        </Td>
                      </tr>
                    );
                  })}


                </tbody>
              </table>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}

function Th({ children, className }: { children: React.ReactNode; className?: string }) {
  return (
    <th className={cn("text-left font-normal px-4 py-2 whitespace-nowrap", className)}>
      {children}
    </th>
  );
}
function Td({ children, className }: { children: React.ReactNode; className?: string }) {
  return <td className={cn("px-4 py-3 align-middle", className)}>{children}</td>;
}

function OverdueChip({ urgent, overdueDays }: { urgent: boolean; overdueDays: number }) {
  const label = urgent ? "Overdue - Urgent" : "Overdue";
  const tooltip = urgent
    ? `Overdue by ${overdueDays} days — escalate or request an exception`
    : `Overdue by ${overdueDays} day${overdueDays === 1 ? "" : "s"}`;
  return (
    <TooltipProvider delayDuration={150}>
      <Tooltip>
        <TooltipTrigger asChild>
          <span
            className="inline-flex items-center gap-1 rounded-full px-2 py-1 text-caption whitespace-nowrap shrink-0 cursor-default"
            style={{ backgroundColor: "#3D2A00", color: "#F5A623" }}
          >
            <AlertTriangle className="h-3 w-3" aria-hidden />
            {label}
          </span>
        </TooltipTrigger>
        <TooltipContent side="top" className="max-w-xs text-caption">
          {tooltip}
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
}

