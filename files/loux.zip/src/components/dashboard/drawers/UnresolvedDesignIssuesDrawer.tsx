import { DashboardDetailDrawer, DrawerEmpty } from "./DashboardDetailDrawer";

type Props = { open: boolean; onOpenChange: (open: boolean) => void };

export function UnresolvedDesignIssuesDrawer({ open, onOpenChange }: Props) {
  return (
    <DashboardDetailDrawer
      open={open}
      onOpenChange={onOpenChange}
      eyebrow="Unresolved design issues"
      title="0 active design issues"
      description="Design issues impacting LOB, platform, risk score, status, and last updated."
    >
      <DrawerEmpty>No design issue data available yet.</DrawerEmpty>
    </DashboardDetailDrawer>
  );
}
