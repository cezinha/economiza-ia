import { useNavigate } from "react-router-dom";
import { DashboardDetailDrawer, DrawerEmpty } from "./DashboardDetailDrawer";
import { useFilteredNudds } from "@/lib/applyFilters";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";

type Props = {
  open: boolean;
  onOpenChange: (open: boolean) => void;
};

function riskBand(n: number): "Low" | "Medium" | "High" {
  if (n <= 2) return "Low";
  if (n <= 5) return "Medium";
  return "High";
}

export function UnresolvedNuddsDrawer({ open, onOpenChange }: Props) {
  const navigate = useNavigate();
  const all = useFilteredNudds();
  const rows = all.filter((n) => n.status !== "Completed");

  const goRow = (id: string) => {
    onOpenChange(false);
    navigate(`/risks?tab=table&nudd=${encodeURIComponent(id)}`);
  };

  return (
    <DashboardDetailDrawer
      open={open}
      onOpenChange={onOpenChange}
      eyebrow="Unresolved NUDDs"
      title={`${rows.length} active NUDD${rows.length === 1 ? "" : "s"}`}
      description="Active and on-hold risks. Click a row to open NUDD details."
    >
      {rows.length === 0 ? (
        <DrawerEmpty>No unresolved NUDDs for the current filters.</DrawerEmpty>
      ) : (
        <div className="rounded-sm border border-border bg-surface overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>ID</TableHead>
                <TableHead>Impacted LOB</TableHead>
                <TableHead>Impacted platform</TableHead>
                <TableHead>Risk score</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Last updated</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {rows.map((row) => {
                const risk = row.impact * row.probability;
                const band = riskBand(risk);
                return (
                  <TableRow
                    key={row.id}
                    className="cursor-pointer hover:bg-muted/60"
                    onClick={() => goRow(row.id)}
                  >
                    <TableCell>
                      <span className="text-primary hover:underline tabular-nums">{row.id}</span>
                    </TableCell>
                    <TableCell>{row.lob}</TableCell>
                    <TableCell>{row.platform}</TableCell>
                    <TableCell>
                      <Badge
                        className={`rounded-full font-medium tabular-nums border-transparent ${
                          band === "High"
                            ? "bg-risk-high text-risk-high-foreground hover:bg-risk-high"
                            : band === "Medium"
                            ? "bg-risk-medium text-risk-medium-foreground hover:bg-risk-medium"
                            : "bg-risk-low text-risk-low-foreground hover:bg-risk-low"
                        }`}
                      >
                        {risk} · {band}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <Badge variant="outline" className="rounded-full font-medium">
                        {row.status}
                      </Badge>
                    </TableCell>
                    <TableCell className="tabular-nums text-muted-foreground">{row.updated}</TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </div>
      )}
    </DashboardDetailDrawer>
  );
}
