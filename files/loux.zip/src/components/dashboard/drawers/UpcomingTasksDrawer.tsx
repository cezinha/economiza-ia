import { useNavigate } from "react-router-dom";
import { DashboardDetailDrawer, DrawerEmpty } from "./DashboardDetailDrawer";
import { useFilteredLaunches } from "@/lib/applyFilters";
import { useFilters } from "@/contexts/FilterContext";
import {
  currentPhaseName,
  isAutoTask,
  taskStatus,
  tasksForLaunch,
  type TaskStatus,
} from "@/lib/launchTasks";
import type { ScheduleTrack } from "@/lib/schedule";

type Props = {
  open: boolean;
  onOpenChange: (open: boolean) => void;
};

const TRACKS: ScheduleTrack[] = ["GOE", "NPI", "SChM"];

const STATUS_DOT: Record<TaskStatus, string> = {
  completed: "bg-status-completed",
  "on-track": "bg-status-on-track",
  "at-risk-mitigated": "bg-status-at-risk-mitigated",
  "at-risk": "bg-status-at-risk",
  "not-started": "bg-status-not-started",
};

function trackLabel(t: ScheduleTrack) {
  return t === "SChM" ? "SChM" : t;
}

export function UpcomingTasksDrawer({ open, onOpenChange }: Props) {
  const navigate = useNavigate();
  const launches = useFilteredLaunches();
  const { filters } = useFilters();
  const fnFilter = Array.isArray(filters.function) ? (filters.function as string[]) : [];
  const activeTracks: ScheduleTrack[] = TRACKS.filter(
    (t) => fnFilter.length === 0 || fnFilter.includes(t),
  );

  type Item = {
    launchId: string;
    launchName: string;
    track: ScheduleTrack;
    phase: string;
    gate: string;
    task: string;
    status: TaskStatus;
  };

  const items: Item[] = [];
  for (const l of launches) {
    for (const track of activeTracks) {
      const phase = currentPhaseName(l, track);
      if (!phase) continue;
      for (const t of tasksForLaunch(l)) {
        if (!t.teams.includes(track as never)) continue;
        if (t.phase !== phase) continue;
        if (isAutoTask(t)) continue;
        const s = taskStatus(l, t, track);
        if (s === "completed" || s === "not-started") continue;
        items.push({
          launchId: l.id,
          launchName: l.name,
          track,
          phase,
          gate: t.gate || "—",
          task: t.task,
          status: s,
        });
      }
    }
  }

  // group by platform → phase
  const byPlatform = new Map<string, { name: string; phases: Map<string, Item[]> }>();
  for (const it of items) {
    if (!byPlatform.has(it.launchId)) byPlatform.set(it.launchId, { name: it.launchName, phases: new Map() });
    const p = byPlatform.get(it.launchId)!;
    if (!p.phases.has(it.phase)) p.phases.set(it.phase, []);
    p.phases.get(it.phase)!.push(it);
  }

  const goTask = (it: Item) => {
    onOpenChange(false);
    const params = new URLSearchParams({
      tab: "platform",
      launch: it.launchId,
      inner: "tasks",
      phase: it.phase,
      gate: it.gate,
    });
    navigate(`/tasks?${params.toString()}`);
  };

  return (
    <DashboardDetailDrawer
      open={open}
      onOpenChange={onOpenChange}
      eyebrow="Upcoming tasks"
      title={`${items.length} active task${items.length === 1 ? "" : "s"}`}
      description="Grouped by platform and current phase. Click a task to open it in Task manager."
    >
      {items.length === 0 ? (
        <DrawerEmpty>No upcoming tasks for the current filters.</DrawerEmpty>
      ) : (
        <div className="space-y-8">
          {Array.from(byPlatform.entries()).map(([id, p]) => (
            <section key={id} className="space-y-3">
              <h3 className="text-subtitle-2 text-foreground">{p.name}</h3>
              <div className="space-y-3">
                {Array.from(p.phases.entries()).map(([phase, list]) => (
                  <div key={phase} className="space-y-2">
                    <div className="text-caption uppercase tracking-wide text-muted-foreground">
                      Current phase: {phase} ({list.length})
                    </div>
                    <ul className="rounded-sm border border-border bg-surface divide-y divide-border">
                      {list.map((it, i) => (
                        <li key={i} className="px-4 py-3">
                          <button
                            type="button"
                            onClick={() => goTask(it)}
                            className="w-full text-left flex items-start gap-3 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring rounded-sm"
                          >
                            <span
                              className={`mt-2 inline-block h-2 w-2 rounded-full shrink-0 ${STATUS_DOT[it.status]}`}
                              aria-hidden
                            />
                            <div className="min-w-0 flex-1">
                              <div className="text-body-3 text-foreground">{it.task}</div>
                              <div className="text-caption text-muted-foreground">
                                {trackLabel(it.track)} · {it.gate}
                              </div>
                            </div>
                          </button>
                        </li>
                      ))}
                    </ul>
                  </div>
                ))}
              </div>
            </section>
          ))}
        </div>
      )}
    </DashboardDetailDrawer>
  );
}
