import type { SVGProps } from "react";

const base = {
  viewBox: "0 0 32 32",
  fill: "currentColor",
  xmlns: "http://www.w3.org/2000/svg",
} as const;

export function SearchBackIcon(props: SVGProps<SVGSVGElement>) {
  return (
    <svg {...base} {...props}>
      <path d="M20.64 32v-32l-16.64 16zM18.5 27l-11.48-11 11.48-11zM26 0h2v32h-2z" />
    </svg>
  );
}

export function SearchForwardIcon(props: SVGProps<SVGSVGElement>) {
  return (
    <svg {...base} {...props}>
      <path d="M11.36 0v32l16.64-16zM13.5 5l11.48 11-11.48 11zM4 0h2v32h-2z" />
    </svg>
  );
}

export function ArrowTriLeftIcon(props: SVGProps<SVGSVGElement>) {
  return (
    <svg {...base} {...props}>
      <path d="M7.64 16l16.72 16v-32zM22.22 27l-11.5-11 11.5-11z" />
    </svg>
  );
}

export function ArrowTriRightIcon(props: SVGProps<SVGSVGElement>) {
  return (
    <svg {...base} {...props}>
      <path d="M7.64 0v32l16.72-16zM9.78 5l11.5 11-11.5 11z" />
    </svg>
  );
}
