import type { SVGProps } from "react";

export function PencilIcon(props: SVGProps<SVGSVGElement>) {
  return (
    <svg
      viewBox="0 0 32 32"
      xmlns="http://www.w3.org/2000/svg"
      fill="currentColor"
      aria-hidden="true"
      {...props}
    >
      <path d="M26.14 0l-22.46 22.46-3.32 8.52-0.36 1.020 1.020-0.36 8.54-3.34 22.44-22.44zM3.74 28.26l1.72-4.44 2.74 2.7zM9.74 25.040l-2.82-2.8 16-16 2.82 2.78-16 16zM24.48 4.72l1.66-1.66 2.8 2.8-1.64 1.64z" />
    </svg>
  );
}
