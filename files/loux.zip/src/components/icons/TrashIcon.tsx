import type { SVGProps } from "react";

export function TrashIcon(props: SVGProps<SVGSVGElement>) {
  return (
    <svg
      viewBox="0 0 32 32"
      xmlns="http://www.w3.org/2000/svg"
      fill="currentColor"
      aria-hidden="true"
      {...props}
    >
      <path d="M25.5 29.86h-19.2v-21.32h-2.14v23.46h23.46v-23.46h-2.12zM14.82 11.1h2.14v16.9h-2.14zM20.8 11.1h2.14v16.9h-2.14zM8.86 11.1h2.12v16.9h-2.12zM20.58 4v-4h-9.38v4h-8.96v2.18h27.52v-2.18zM13.34 2h5.32v2h-5.32z" />
    </svg>
  );
}
