import { ReactNode, ElementType } from "react";
import { cn } from "@/lib/utils";

/**
 * DDS Grid primitives — the only sanctioned way to lay out content in the dashboard.
 *
 * <DdsGrid> renders a 12/6/2-column responsive grid bound to live DDS tokens
 * (--dds-cols, --dds-gutter). XS=2 cols, S/M=6 cols, L+=12 cols per spec.
 *
 * <DdsCol> declares column span per breakpoint. Authors specify spans in the
 * 12-grid; for S/M it auto-halves and for XS it spans full row.
 */

interface DdsGridProps {
  children: ReactNode;
  className?: string;
  as?: ElementType;
  /** apply DDS responsive page margins on the outermost wrapper */
  page?: boolean;
}

export function DdsGrid({ children, className, as, page }: DdsGridProps) {
  const Tag = (as ?? "div") as ElementType;
  return (
    <Tag className={cn("dds-grid", page && "px-page", className)}>{children}</Tag>
  );
}

type Span12 = 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12;
type Span6 = 1 | 2 | 3 | 4 | 5 | 6;
type Span2 = 1 | 2;

interface DdsColProps {
  children: ReactNode;
  className?: string;
  as?: ElementType;
  /** Span on L+ (12-col). */
  span?: Span12;
  /** Override on M (6-col). Defaults to min(span, 6). */
  spanM?: Span6;
  /** Override on S (6-col). Defaults to spanM. */
  spanS?: Span6;
  /** Override on XS (2-col). Defaults to 2 (full row). */
  spanXs?: Span2;
}

// Tailwind requires literal class names in source — full lookup tables.
const xsCls: Record<Span2, string> = {
  1: "col-span-1",
  2: "col-span-2",
};
const sCls: Record<Span6, string> = {
  1: "s:col-span-1", 2: "s:col-span-2", 3: "s:col-span-3",
  4: "s:col-span-4", 5: "s:col-span-5", 6: "s:col-span-6",
};
const mCls: Record<Span6, string> = {
  1: "m:col-span-1", 2: "m:col-span-2", 3: "m:col-span-3",
  4: "m:col-span-4", 5: "m:col-span-5", 6: "m:col-span-6",
};
const lCls: Record<Span12, string> = {
  1: "l:col-span-1",  2: "l:col-span-2",  3: "l:col-span-3",  4: "l:col-span-4",
  5: "l:col-span-5",  6: "l:col-span-6",  7: "l:col-span-7",  8: "l:col-span-8",
  9: "l:col-span-9", 10: "l:col-span-10", 11: "l:col-span-11", 12: "l:col-span-12",
};

export function DdsCol({
  children,
  className,
  as,
  span = 12,
  spanM,
  spanS,
  spanXs = 2,
}: DdsColProps) {
  const Tag = (as ?? "div") as ElementType;
  const onM = (spanM ?? (Math.min(span, 6) as Span6));
  const onS = (spanS ?? onM);
  return (
    <Tag
      data-dds-col
      className={cn(xsCls[spanXs], sCls[onS], mCls[onM], lCls[span], className)}
    >
      {children}
    </Tag>
  );
}
