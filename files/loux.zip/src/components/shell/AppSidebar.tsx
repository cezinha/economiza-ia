import { useState } from "react";
import { NavLink, useLocation, useSearchParams } from "react-router-dom";
import {
  Archive,
  Sliders,
  Hammer,
  AlertTriangle,
  ChevronLeft,
  ChevronRight,
  ChevronDown,
  ChevronUp,
  Users,
} from "lucide-react";
import { useRole } from "@/contexts/RoleContext";
import { UploadedIcon } from "./UploadedIcon";
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarGroup,
  SidebarGroupContent,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  useSidebar,
} from "@/components/ui/sidebar";
import { cn } from "@/lib/utils";

/**
 * DDS Side Navigation (locked).
 * - Width: 280px expanded / 60px collapsed
 * - Item rhythm: 16px top/bottom padding, 16px icon, 4px left active marker
 * - Sentence case labels
 * - Secondary group: text-only, indented under the parent label, only when expanded
 */

type Child = { title: string; tab: string; postMvp?: boolean };
type PrimaryItem = {
  title: string;
  url: string;
  iconName?: "home" | "schedule" | "task" | "files" | "risk" | "users" | "alert" | "slider" | "datastore" | "wrench";
  icon?: React.ComponentType<{ className?: string }>;
  children?: Child[];
  postMvp?: boolean;
};

const primary: PrimaryItem[] = [
  {
    title: "Home",
    url: "/",
    iconName: "home",
    children: [
      { title: "Action items", tab: "action-items" },
      { title: "Summary", tab: "portfolio" },
      { title: "Report", tab: "report" },
      { title: "Watchlist", tab: "watchlist", postMvp: true },
    ],
  },
  { title: "OLP schedule", url: "/launches", iconName: "schedule" },
  {
    title: "Task manager",
    url: "/tasks",
    iconName: "task",
    children: [
      { title: "Action queue", tab: "queue" },
      { title: "By platform", tab: "platform" },
    ],
  },
  {
    title: "Doc and data curator",
    url: "/curator",
    iconName: "files",
    children: [
      { title: "Programs", tab: "programs" },
      { title: "Settings", tab: "settings" },
      { title: "Debug", tab: "debug" },
    ],
  },
  {
    title: "NUDDs",
    url: "/risks",
    iconName: "risk",
    children: [
      { title: "Summary", tab: "summary" },
      { title: "Table", tab: "table" },
    ],
  },
  { title: "Design issues", url: "/design-issues", iconName: "alert", postMvp: true },
  { title: "Golden configs", url: "/golden-configs", iconName: "slider", postMvp: true },
  { title: "Build execution", url: "/build-execution", iconName: "wrench", postMvp: true },
  { title: "Archive", url: "/activity", iconName: "datastore", postMvp: true },
];

const itemClass = cn(
  "relative flex items-center gap-4 w-full",
  "border-l-4 border-transparent",
  "!h-12 !py-4 !pl-3 !pr-3",
  "rounded-none",
  "text-body-3 text-sidebar-foreground",
  "transition-colors",
  "hover:!bg-sidebar-accent hover:!text-sidebar-accent-foreground",
  "data-[active=true]:!bg-sidebar-active",
  "data-[active=true]:!text-sidebar-active-foreground",
  "data-[active=true]:!border-sidebar-primary",
  "data-[active=true]:font-medium",
  "group-data-[collapsible=icon]:!h-12 group-data-[collapsible=icon]:!w-12",
  "group-data-[collapsible=icon]:!px-0 group-data-[collapsible=icon]:justify-center",
);

// Secondary item: text-only, indented so text aligns under primary label (icon 16 + gap 16 + left pad 12 = 44 → use pl-11).
const subItemClass = cn(
  "relative flex items-center w-full",
  "border-l-4 border-transparent",
  "!h-12 !py-4 !pl-11 !pr-3",
  "rounded-none",
  "text-body-3 text-sidebar-foreground",
  "transition-colors",
  "hover:!bg-sidebar-accent hover:!text-sidebar-accent-foreground",
  "data-[active=true]:!bg-sidebar-active",
  "data-[active=true]:!text-sidebar-active-foreground",
  "data-[active=true]:!border-sidebar-primary",
  "data-[active=true]:font-medium",
  "group-data-[collapsible=icon]:hidden",
);

export function AppSidebar() {
  const { state, toggleSidebar } = useSidebar();
  const collapsed = state === "collapsed";
  const { pathname } = useLocation();
  const [searchParams] = useSearchParams();
  const { role } = useRole();
  const [openGroups, setOpenGroups] = useState<Record<string, boolean>>({});
  const isActive = (path: string) => (path === "/" ? pathname === "/" : pathname.startsWith(path));

  const items: PrimaryItem[] = role === "superadmin"
    ? [...primary, { title: "User management", url: "/user-management", iconName: "users" }]
    : primary;

  const currentTab = searchParams.get("tab");

  const toggleGroup = (url: string) =>
    setOpenGroups((prev) => ({ ...prev, [url]: !prev[url] }));

  return (
    <Sidebar collapsible="icon" className="border-r border-sidebar-border">
      <SidebarContent>
        <SidebarGroup className="p-0">
          <SidebarGroupContent>
            <SidebarMenu className="gap-0">
              {items.map((item) => {
                const parentActive = isActive(item.url);
                const hasChildren = !!item.children?.length;
                const isOpen = !!openGroups[item.url];
                const showChildren = !collapsed && hasChildren && isOpen;
                const groupId = `nav-group-${item.url.replace(/\W+/g, "-")}`;
                // Dim the parent whenever the child group is expanded — only the child row should look active.
                const parentVisualActive = parentActive && !showChildren;
                return (
                  <SidebarMenuItem key={item.title}>
                    {hasChildren ? (
                      <div
                        data-active={parentVisualActive || undefined}
                        className={cn(itemClass, "pr-0")}
                      >
                        <NavLink
                          to={item.url}
                          aria-label={item.title}
                          end={item.url === "/"}
                          className={cn(
                            "flex flex-1 items-center gap-4 min-w-0 hover:text-sidebar-active-foreground",
                            "group-data-[collapsible=icon]:justify-center group-data-[collapsible=icon]:gap-0",
                            parentVisualActive ? "text-sidebar-active-foreground" : "text-sidebar-foreground"
                          )}
                        >
                          {item.iconName ? (
                            <UploadedIcon name={item.iconName} className="h-4 w-4 shrink-0" aria-hidden="true" />
                          ) : item.icon ? (
                            <item.icon className="h-4 w-4 shrink-0" />
                          ) : null}
                          {!collapsed && <span className="truncate">{item.title}</span>}
                        </NavLink>
                        {!collapsed && (
                          <button
                            type="button"
                            onClick={(e) => {
                              e.preventDefault();
                              e.stopPropagation();
                              toggleGroup(item.url);
                            }}
                            aria-expanded={isOpen}
                            aria-controls={groupId}
                            aria-label={`${isOpen ? "Collapse" : "Expand"} ${item.title}`}
                            className="flex h-full items-center justify-center px-3 text-sidebar-foreground hover:text-sidebar-active-foreground"
                          >
                            {isOpen ? (
                              <ChevronUp className="h-4 w-4" />
                            ) : (
                              <ChevronDown className="h-4 w-4" />
                            )}
                          </button>
                        )}
                      </div>
                    ) : (
                      <SidebarMenuButton
                        asChild
                        isActive={parentActive}
                        tooltip={item.title}
                        className={itemClass}
                      >
                        <NavLink to={item.url} aria-label={item.title} end={item.url === "/"}>
                          {item.iconName ? (
                            <UploadedIcon name={item.iconName} className="h-4 w-4 shrink-0" aria-hidden="true" />
                          ) : item.icon ? (
                            <item.icon className="h-4 w-4 shrink-0" />
                          ) : null}
                          {!collapsed && <span className="truncate">{item.title}</span>}
                          {!collapsed && item.postMvp && (
                            <span className="ml-auto shrink-0 rounded-full border border-border bg-muted px-2 py-0.5 text-caption text-muted-foreground">
                              Post-MVP
                            </span>
                          )}
                        </NavLink>
                      </SidebarMenuButton>
                    )}
                    {showChildren && item.children && (
                      <SidebarMenu id={groupId} className="gap-0">
                        {item.children.map((child) => {
                          const effectiveTab = currentTab ?? item.children![0].tab;
                          const childActive = parentActive && effectiveTab === child.tab;
                          return (
                            <SidebarMenuItem key={child.tab}>
                              <SidebarMenuButton
                                asChild
                                isActive={childActive}
                                className={subItemClass}
                              >
                                <NavLink
                                  to={`${item.url}?tab=${child.tab}`}
                                  aria-label={child.title}
                                >
                                  <span className="truncate">{child.title}</span>
                                  {child.postMvp && (
                                    <span className="ml-auto shrink-0 rounded-full border border-border bg-muted px-2 py-0.5 text-caption text-muted-foreground">
                                      Post-MVP
                                    </span>
                                  )}
                                </NavLink>
                              </SidebarMenuButton>
                            </SidebarMenuItem>
                          );
                        })}
                      </SidebarMenu>
                    )}
                  </SidebarMenuItem>
                );
              })}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>


      <SidebarFooter className="p-0">
        <button
          type="button"
          onClick={toggleSidebar}
          aria-label={collapsed ? "Expand side navigation" : "Collapse side navigation"}
          className={cn(
            "flex h-12 w-full items-center justify-end px-4",
            "text-sidebar-primary hover:bg-sidebar-accent hover:text-sidebar-primary",
            "transition-colors",
            "group-data-[collapsible=icon]:justify-center group-data-[collapsible=icon]:px-0",
          )}
        >
          {collapsed ? <ChevronRight className="h-4 w-4" /> : <ChevronLeft className="h-4 w-4" />}
        </button>
      </SidebarFooter>
    </Sidebar>
  );
}

