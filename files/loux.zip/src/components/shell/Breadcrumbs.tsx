import { Fragment, useState } from "react";
import { Link } from "react-router-dom";
import { ArrowLeft, MoreHorizontal } from "lucide-react";
import { cn } from "@/lib/utils";
import { UploadedIcon } from "./UploadedIcon";

export interface BreadcrumbItem {
  label: string;
  to?: string;
}

interface BreadcrumbsProps {
  items: BreadcrumbItem[];
  /** Set false to hide the auto-prepended Home icon (default true). */
  includeHome?: boolean;
  className?: string;
}

const linkClasses = cn(
  "inline-flex items-center rounded px-2 py-1 text-muted-foreground",
  "transition-colors hover:bg-breadcrumb-hover-bg hover:text-breadcrumb-link-hover",
  "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-breadcrumb-focus-ring focus-visible:ring-offset-0",
  "focus-visible:text-breadcrumb-link-hover"
);

const Separator = () => (
  <span aria-hidden className="px-1 text-muted-foreground select-none">
    /
  </span>
);

/**
 * DDS-aligned breadcrumb navigation.
 * - L+ : full trail, ellipsis-collapse middle when >3 levels
 * - M  : truncated by default when >3 levels
 * - <M : back-arrow link to previous page only
 */
export function Breadcrumbs({ items, includeHome = true, className }: BreadcrumbsProps) {
  const [expanded, setExpanded] = useState(false);

  const trail: BreadcrumbItem[] = includeHome
    ? [{ label: "Home", to: "/" }, ...items]
    : items;

  if (trail.length === 0) return null;

  const last = trail[trail.length - 1];
  const previous = trail.length > 1 ? trail[trail.length - 2] : { label: "Home", to: "/" };

  // ----- Mobile (xs/s, <768px): back arrow + previous link only -----
  const MobileTrail = (
    <nav aria-label="Breadcrumb" className={cn("m:hidden", className)}>
      {previous.to ? (
        <Link to={previous.to} className={cn(linkClasses, "text-body-3")}>
          <ArrowLeft className="mr-1 h-4 w-4" aria-hidden />
          {previous.label}
        </Link>
      ) : (
        <span className="inline-flex items-center text-body-3 text-muted-foreground">
          <ArrowLeft className="mr-1 h-4 w-4" aria-hidden />
          {previous.label}
        </span>
      )}
    </nav>
  );

  // ----- Desktop / tablet trail builder -----
  // Truncate when more than 3 levels (matches DDS): show first, …, last
  const shouldCollapse = trail.length > 3 && !expanded;
  const visible: (BreadcrumbItem | "ellipsis")[] = shouldCollapse
    ? [trail[0], "ellipsis", trail[trail.length - 1]]
    : trail;

  const DesktopTrail = (
    <nav
      aria-label="Breadcrumb"
      className={cn("hidden m:block text-body-3", className)}
    >
      <ol className="flex flex-wrap items-center">
        {visible.map((entry, idx) => {
          const isLast = idx === visible.length - 1;
          if (entry === "ellipsis") {
            return (
              <Fragment key={`ellipsis-${idx}`}>
                <li>
                  <button
                    type="button"
                    onClick={() => setExpanded(true)}
                    aria-label="Show full breadcrumb trail"
                    className={cn(linkClasses)}
                  >
                    <MoreHorizontal className="h-4 w-4" aria-hidden />
                  </button>
                </li>
                {!isLast && (
                  <li>
                    <Separator />
                  </li>
                )}
              </Fragment>
            );
          }

          const isHome = idx === 0 && includeHome && entry.label === "Home";

          let node;
          if (isLast || !entry.to) {
            node = (
              <span
                aria-current={isLast ? "page" : undefined}
                className={cn(
                  "inline-flex items-center px-2 py-1",
                  isLast ? "text-foreground font-medium" : "text-muted-foreground"
                )}
              >
                {isHome ? <UploadedIcon name="home" className="h-4 w-4" aria-hidden /> : entry.label}
              </span>
            );
          } else {
            node = (
              <Link to={entry.to} className={linkClasses} aria-label={isHome ? "Home" : undefined}>
                {isHome ? <UploadedIcon name="home" className="h-4 w-4" aria-hidden /> : entry.label}
              </Link>
            );
          }

          return (
            <Fragment key={`${entry.label}-${idx}`}>
              <li>{node}</li>
              {!isLast && (
                <li>
                  <Separator />
                </li>
              )}
            </Fragment>
          );
        })}
      </ol>
    </nav>
  );

  return (
    <>
      {MobileTrail}
      {DesktopTrail}
    </>
  );
}
