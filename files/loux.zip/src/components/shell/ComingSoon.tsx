export function ComingSoon() {
  return (
    <div className="flex flex-col items-center justify-center py-24 text-center">
      <span
        aria-hidden="true"
        className="dds-icon-mask dds-icon-alert-notice h-8 w-8"
        style={{ color: "#636363" }}
      />
      <p className="mt-4 text-h5" style={{ color: "#0E0E0E" }}>Coming soon</p>
      <p className="mt-2 text-body-2" style={{ color: "#636363" }}>To be implemented in V2.0</p>
    </div>
  );
}
