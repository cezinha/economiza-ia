import { useMemo, useState } from "react";
import { ChevronDown, Lock, X } from "lucide-react";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Checkbox } from "@/components/ui/checkbox";
import { Input } from "@/components/ui/input";
import { cn } from "@/lib/utils";

export type ComboOption = { value: string; label: string };
export type OptionGroup = { title: string; options: ComboOption[] };

type Size = "sm" | "lg";

interface BaseProps {
  label: string;
  required?: boolean;
  helperText?: string;
  errorText?: string;
  placeholder?: string;
  searchPlaceholder?: string;
  emptyText?: string;
  size?: Size;
  disabled?: boolean;
  values: string[];
  onChange: (next: string[]) => void;
  lockedValues?: string[];
  lockedTooltip?: string;
  /** When false, no "Select all" row is shown. Default true. */
  showSelectAll?: boolean;
  className?: string;
}

interface FlatProps extends BaseProps {
  options: ComboOption[];
  groups?: never;
}

interface GroupedProps extends BaseProps {
  groups: OptionGroup[];
  options?: never;
}

type Props = FlatProps | GroupedProps;

/** DDS-aligned multi-select dropdown. Supports simple or grouped lists. */
export function DdsDropdown(props: Props) {
  const {
    label,
    required,
    helperText,
    errorText,
    placeholder = "Select…",
    searchPlaceholder = "Search…",
    emptyText = "No options found",
    size = "lg",
    disabled,
    values,
    onChange,
    lockedValues = [],
    lockedTooltip = "Required by another filter",
    showSelectAll = true,
    className,
  } = props;

  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState("");

  const lockedSet = useMemo(() => new Set(lockedValues), [lockedValues]);

  // Normalize to groups
  const groups: OptionGroup[] = useMemo(() => {
    if ("groups" in props && props.groups) return props.groups;
    return [{ title: "", options: (props as FlatProps).options ?? [] }];
  }, [props]);

  const allOptions = useMemo(
    () => groups.flatMap((g) => g.options),
    [groups],
  );

  // Make sure locked values show up even if scoping removed them.
  const augmentedGroups: OptionGroup[] = useMemo(() => {
    const present = new Set(allOptions.map((o) => o.value));
    const missing = lockedValues.filter((v) => !present.has(v));
    if (!missing.length) return groups;
    const extra: ComboOption[] = missing.map((v) => ({ value: v, label: v }));
    return [...groups, { title: "", options: extra }];
  }, [groups, allOptions, lockedValues]);

  const filteredGroups: OptionGroup[] = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return augmentedGroups;
    return augmentedGroups
      .map((g) => ({
        title: g.title,
        options: g.options.filter((o) => o.label.toLowerCase().includes(q)),
      }))
      .filter((g) => g.options.length > 0);
  }, [augmentedGroups, query]);

  const displayValues = useMemo(
    () => [...values, ...lockedValues.filter((v) => !values.includes(v))],
    [values, lockedValues],
  );

  const labelFor = (v: string) => {
    for (const g of augmentedGroups) {
      const m = g.options.find((o) => o.value === v);
      if (m) return m.label;
    }
    return v;
  };

  const toggle = (v: string) => {
    if (lockedSet.has(v)) return;
    if (values.includes(v)) onChange(values.filter((x) => x !== v));
    else onChange([...values, v]);
  };

  // "Select all" handles non-locked, currently visible (filtered) options.
  const selectableVisible = filteredGroups
    .flatMap((g) => g.options)
    .map((o) => o.value)
    .filter((v) => !lockedSet.has(v));
  const allSelected =
    selectableVisible.length > 0 &&
    selectableVisible.every((v) => values.includes(v));
  const someSelected =
    !allSelected && selectableVisible.some((v) => values.includes(v));

  const toggleSelectAll = () => {
    if (allSelected) {
      onChange(values.filter((v) => !selectableVisible.includes(v)));
    } else {
      const next = new Set(values);
      for (const v of selectableVisible) next.add(v);
      onChange(Array.from(next));
    }
  };

  const clearAll = (e: React.MouseEvent) => {
    e.stopPropagation();
    onChange(values.filter((v) => lockedSet.has(v)));
  };

  const hasError = Boolean(errorText);
  const count = displayValues.length;
  const heightClass = size === "sm" ? "h-8" : "h-10";

  const groupId = useMemo(
    () => `dds-dd-${Math.random().toString(36).slice(2, 9)}`,
    [],
  );

  return (
    <div className={cn("space-y-1", className)}>
      <label
        htmlFor={groupId}
        className={cn(
          "text-body-3 font-medium block",
          hasError ? "text-destructive" : "text-foreground",
        )}
      >
        {label}
        {required && <span className="ml-1 text-destructive">*</span>}
      </label>

      <Popover open={open} onOpenChange={(o) => !disabled && setOpen(o)}>
        <PopoverTrigger asChild>
          <button
            id={groupId}
            type="button"
            role="combobox"
            aria-expanded={open}
            aria-haspopup="listbox"
            aria-invalid={hasError || undefined}
            disabled={disabled}
            className={cn(
              "flex w-full items-center justify-between gap-2 rounded-md border bg-surface px-3 text-body-3 font-normal",
              "transition-colors",
              "hover:border-primary",
              "focus:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-0 focus-visible:border-primary",
              disabled && "opacity-40 pointer-events-none",
              hasError ? "border-destructive" : "border-input",
              heightClass,
            )}
          >
            <span className="flex min-w-0 flex-1 items-center gap-2">
              {count === 0 ? (
                <span className="text-muted-foreground">{placeholder}</span>
              ) : (
                <span className="inline-flex items-center gap-1 rounded border border-input bg-muted px-2 py-1 text-caption">
                  <span>{count} selected</span>
                  {!disabled && (
                    <span
                      role="button"
                      tabIndex={-1}
                      onClick={clearAll}
                      aria-label="Clear selection"
                      className="rounded-full hover:bg-background p-1"
                    >
                      <X className="h-3 w-3" />
                    </span>
                  )}
                </span>
              )}
            </span>
            <ChevronDown
              className={cn(
                "h-4 w-4 shrink-0 text-muted-foreground transition-transform",
                open && "rotate-180",
              )}
            />
          </button>
        </PopoverTrigger>

        <PopoverContent
          className="w-[--radix-popover-trigger-width] p-0"
          align="start"
        >
          <div className="border-b border-border p-2">
            <Input
              autoFocus
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder={searchPlaceholder}
              className="h-8 text-body-3"
            />
          </div>

          <div className="max-h-72 overflow-y-auto py-1" role="listbox">
            {showSelectAll && !query && selectableVisible.length > 0 && (
              <button
                type="button"
                onClick={toggleSelectAll}
                className="flex w-full items-center gap-2 px-3 py-2 text-body-3 hover:bg-muted"
              >
                <Checkbox
                  checked={allSelected ? true : someSelected ? "indeterminate" : false}
                  className="pointer-events-none"
                />
                <span className="font-medium">Select all</span>
              </button>
            )}

            {filteredGroups.length === 0 && (
              <div className="px-3 py-4 text-body-3 text-muted-foreground">
                {emptyText}
              </div>
            )}

            {filteredGroups.map((g, gi) => (
              <div key={`${g.title}-${gi}`} role="group">
                {g.title && (
                  <div
                    role="presentation"
                    className="px-3 pt-2 pb-1 text-caption font-medium text-foreground"
                  >
                    {g.title}
                  </div>
                )}
                {g.options.map((o) => {
                  const isLocked = lockedSet.has(o.value);
                  const checked = values.includes(o.value) || isLocked;
                  return (
                    <button
                      key={o.value}
                      type="button"
                      role="option"
                      aria-selected={checked}
                      disabled={isLocked}
                      onClick={() => toggle(o.value)}
                      className={cn(
                        "flex w-full items-center gap-2 px-3 py-2 text-left text-body-3 hover:bg-muted",
                        isLocked && "opacity-60 cursor-not-allowed",
                      )}
                    >
                      <Checkbox
                        checked={checked}
                        disabled={isLocked}
                        className="pointer-events-none"
                      />
                      <span className="flex-1 truncate">{o.label}</span>
                      {isLocked && (
                        <Lock
                          className="h-3 w-3 text-muted-foreground"
                          aria-label={lockedTooltip}
                        />
                      )}
                    </button>
                  );
                })}
              </div>
            ))}
          </div>
        </PopoverContent>
      </Popover>

      {(errorText || helperText) && (
        <p
          className={cn(
            "text-caption",
            hasError
              ? "text-destructive"
              : "text-muted-foreground",
          )}
        >
          {errorText ?? helperText}
        </p>
      )}
    </div>
  );
}
