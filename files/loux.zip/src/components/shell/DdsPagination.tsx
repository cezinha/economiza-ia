import { useEffect, useState } from "react";
import {
  ArrowTriLeftIcon,
  ArrowTriRightIcon,
  SearchBackIcon,
  SearchForwardIcon,
} from "@/components/icons/PaginationIcons";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { cn } from "@/lib/utils";

interface DdsPaginationProps {
  page: number;
  pageSize: number;
  totalItems: number;
  pageSizeOptions?: number[];
  itemLabel?: string;
  onPageChange: (page: number) => void;
  onPageSizeChange: (size: number) => void;
}

export function DdsPagination({
  page,
  pageSize,
  totalItems,
  pageSizeOptions = [10, 25, 50, 100, 250],
  itemLabel = "items",
  onPageChange,
  onPageSizeChange,
}: DdsPaginationProps) {
  const totalPages = Math.max(1, Math.ceil(totalItems / pageSize));
  const safePage = Math.min(Math.max(1, page), totalPages);
  const start = totalItems === 0 ? 0 : (safePage - 1) * pageSize + 1;
  const end = Math.min(safePage * pageSize, totalItems);

  const [pageInput, setPageInput] = useState(String(safePage));
  useEffect(() => setPageInput(String(safePage)), [safePage]);

  const commitPageInput = () => {
    const n = parseInt(pageInput, 10);
    if (Number.isNaN(n)) {
      setPageInput(String(safePage));
      return;
    }
    const clamped = Math.min(Math.max(1, n), totalPages);
    if (clamped !== safePage) onPageChange(clamped);
    setPageInput(String(clamped));
  };

  const isFirst = safePage <= 1;
  const isLast = safePage >= totalPages;

  const navBtn = "h-8 w-8 text-link hover:text-link disabled:text-link disabled:opacity-40";
  const navTextBtn =
    "h-8 px-2 gap-1 text-body-3 text-link hover:text-link hover:bg-transparent disabled:text-link disabled:opacity-40";


  return (
    <div className="flex w-full flex-nowrap items-center justify-between gap-x-3 gap-y-3 text-body-3 text-muted-foreground">

      {/* Capacity */}
      <div className="flex items-center gap-2">
        <span className="hidden xs:inline">Rows per page</span>
        <Select
          value={String(pageSize)}
          onValueChange={(v) => {
            onPageSizeChange(parseInt(v, 10));
            onPageChange(1);
          }}
        >
          <SelectTrigger className="h-8 w-[76px] text-body-3 text-foreground border-foreground">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {pageSizeOptions.map((opt) => (
              <SelectItem key={opt} value={String(opt)} className="text-body-3">
                {opt}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* Range label */}
      <span className="hidden xs:inline">
        {start}–{end} of {totalItems} {itemLabel}
      </span>

      {/* Navigation */}
      <div className="flex items-center gap-1">
        <Button
          variant="ghost"
          size="icon"
          className={cn(navBtn, "hidden xs:inline-flex")}
          disabled={isFirst}
          onClick={() => onPageChange(1)}
          aria-label="First page"
        >
          <SearchBackIcon className="h-4 w-4" />
        </Button>

        <Button
          variant="ghost"
          className={navTextBtn}
          disabled={isFirst}
          onClick={() => onPageChange(safePage - 1)}
          aria-label="Previous page"
        >
          <ArrowTriLeftIcon className="h-4 w-4" />
          <span className="hidden s:inline">Previous</span>
        </Button>

        <Input
          value={pageInput}
          onChange={(e) => setPageInput(e.target.value.replace(/[^\d]/g, ""))}
          onBlur={commitPageInput}
          onKeyDown={(e) => {
            if (e.key === "Enter") {
              e.currentTarget.blur();
            }
          }}
          className="h-8 w-12 text-center text-body-3 text-foreground border-foreground"
          aria-label="Current page"
        />

        <span className="hidden xs:inline">of {totalPages}</span>

        <Button
          variant="ghost"
          className={navTextBtn}
          disabled={isLast}
          onClick={() => onPageChange(safePage + 1)}
          aria-label="Next page"
        >
          <span className="hidden s:inline">Next</span>
          <ArrowTriRightIcon className="h-4 w-4" />
        </Button>

        <Button
          variant="ghost"
          size="icon"
          className={cn(navBtn, "hidden xs:inline-flex")}
          disabled={isLast}
          onClick={() => onPageChange(totalPages)}
          aria-label="Last page"
        >
          <SearchForwardIcon className="h-4 w-4" />
        </Button>
      </div>
    </div>
  );
}

export default DdsPagination;
