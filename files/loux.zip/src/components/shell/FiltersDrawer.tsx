import { useMemo } from "react";
import { useLocation } from "react-router-dom";
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetFooter,
  SheetHeader,
  SheetTitle,
} from "@/components/ui/sheet";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { useFilters } from "@/contexts/FilterContext";
import { useRole } from "@/contexts/RoleContext";
import { useViewFilter } from "@/contexts/ViewFilterContext";
import { launches as ALL_LAUNCHES } from "@/mocks/launches";
import { DdsDropdown, type ComboOption } from "@/components/shell/DdsDropdown";
import {
  groupedLobOptions,
  groupedOwnerOptions,
  groupedPhaseOptions,
  groupedPlatformOptions,
  groupedTaskOptions,
  lockedValues,
  functionsFromPhaseFilter,
} from "@/lib/filterCascade";

const ORGANIZATION: ComboOption[] = [
  { value: "CSG", label: "CSG" },
  { value: "ISG", label: "ISG" },
];

const FUNCTION: ComboOption[] = [
  { value: "Core", label: "Core team" },
  { value: "GOE", label: "GOE" },
  { value: "NPI", label: "NPI" },
  { value: "SChM", label: "SChM" },
];

const STATUS: ComboOption[] = [
  { value: "achieved", label: "Achieved / on track" },
  { value: "risk-mitigated", label: "Risk with mitigation" },
  { value: "missed", label: "Missed / no mitigation plan" },
];

export function FiltersDrawer() {
  const { filters, setFilter, setManyFilters, isOpen, setOpen, resetFilters, close, activeCount } =
    useFilters();
  const { role } = useRole();
  const { lockedFunction, lockedLobs, lockedPlatformIds } = useViewFilter();
  const isScoped = role === "admin" || role === "user";
  const { pathname } = useLocation();
  const isOlpSchedule = pathname === "/launches";
  const watchlistOn = filters.watchlist === true;
  const showWatchlistToggle = isScoped;
  const lockTooltip = "Paused while Watchlist is on";

  const lockedPlatformNames = useMemo(() => {
    if (!isScoped || !lockedPlatformIds) return [] as string[];
    return lockedPlatformIds
      .map((id) => ALL_LAUNCHES.find((l) => l.id === id)?.name)
      .filter((n): n is string => Boolean(n));
  }, [isScoped, lockedPlatformIds]);

  const applyMyDefaults = () => {
    if (!isScoped) return;
    setFilter("organization", ["CSG"]);
    setFilter("function", lockedFunction ? [lockedFunction] : []);
    setFilter("lob", lockedLobs ?? []);
    setFilter("platform", lockedPlatformNames);
  };

  const lobGroups = useMemo(() => groupedLobOptions(filters), [filters]);
  const platformGroups = useMemo(() => groupedPlatformOptions(filters), [filters]);
  const phaseGroups = useMemo(() => groupedPhaseOptions(filters), [filters]);
  const ownerGroups = useMemo(() => groupedOwnerOptions(filters), [filters]);
  const taskGroups = useMemo(() => groupedTaskOptions(filters), [filters]);

  const get = (k: string): string[] => {
    const v = filters[k];
    return Array.isArray(v) ? (v as string[]) : [];
  };

  return (
    <Sheet open={isOpen} onOpenChange={setOpen}>
      <SheetContent side="right" className="w-full s:max-w-md flex flex-col p-0">
        <SheetHeader className="px-6 py-4 border-b border-border">
          <SheetTitle className="text-h5">Filters</SheetTitle>
          <SheetDescription className="text-body-3 text-muted-foreground">
            Refine the data shown across the dashboard
            {activeCount > 0 && ` — ${activeCount} active`}
          </SheetDescription>
        </SheetHeader>

        <div className="flex-1 overflow-y-auto px-6 py-4 space-y-4">
          {showWatchlistToggle && (
            <label
              htmlFor="filters-watchlist"
              className="flex items-start gap-3 rounded-sm border border-border bg-muted/40 p-3 cursor-pointer"
            >
              <Checkbox
                id="filters-watchlist"
                checked={watchlistOn}
                onCheckedChange={(checked) => {
                  if (checked) {
                    setManyFilters({ watchlist: true });
                  } else {
                    resetFilters();
                    setFilter("watchlist", false);
                  }
                }}
                className="mt-1"
              />
              <div className="space-y-1">
                <div className="text-body-3 text-foreground font-medium">Watchlist</div>
                <p className="text-caption text-muted-foreground">
                  Show only platforms on your watchlist. Other filters are paused while this is on.
                </p>
              </div>
            </label>
          )}

          <DdsDropdown
            label="Business unit"
            helperText="Select one or more business units"
            options={ORGANIZATION}
            values={get("organization")}
            onChange={(v) => setFilter("organization", v)}
            placeholder="All business units"
            searchPlaceholder="Search business units"
            lockedValues={lockedValues(filters, "organization")}
            lockedTooltip={watchlistOn ? lockTooltip : "Required by selected LOB or Platform"}
            disabled={watchlistOn}
          />

          <DdsDropdown
            label="Function"
            helperText="Select one or more functions"
            options={FUNCTION}
            values={get("function")}
            onChange={(v) => setFilter("function", v)}
            placeholder="All functions"
            searchPlaceholder="Search functions"
            disabled={watchlistOn}
          />

          <DdsDropdown
            label="LOB"
            helperText="Grouped by business unit"
            groups={lobGroups}
            values={get("lob")}
            onChange={(v) => setFilter("lob", v)}
            placeholder="All LOBs"
            searchPlaceholder="Search LOBs"
            lockedValues={lockedValues(filters, "lob")}
            lockedTooltip={watchlistOn ? lockTooltip : "Required by selected Platform or Owner"}
            disabled={watchlistOn}
          />

          <div className="space-y-1">
            <DdsDropdown
              label="Platform"
              helperText="Grouped by LOB"
              groups={platformGroups}
              values={get("platform")}
              onChange={(v) => setFilter("platform", v)}
              placeholder="All platforms"
              searchPlaceholder="Search platforms"
              lockedValues={lockedValues(filters, "platform")}
              lockedTooltip={watchlistOn ? lockTooltip : "Required by selected Owner"}
              disabled={watchlistOn}
            />
            {isScoped && !watchlistOn && lockedPlatformNames.length > 0 && (
              <button
                type="button"
                className="text-caption text-primary hover:underline"
                onClick={() => setFilter("platform", lockedPlatformNames)}
              >
                Reset to my platforms ({lockedPlatformNames.length})
              </button>
            )}
          </div>

          <DdsDropdown
            label="Current phase"
            helperText="Grouped by function"
            groups={phaseGroups}
            values={get("phase")}
            onChange={(v) => {
              setFilter("phase", v);
              const added = v.filter((x) => !get("phase").includes(x));
              if (added.length) {
                const addedFns = functionsFromPhaseFilter(added);
                if (addedFns.length) {
                  const current = get("function");
                  const merged = Array.from(new Set([...current, ...addedFns]));
                  if (merged.length !== current.length) setFilter("function", merged);
                }
              }
            }}
            placeholder="All phases"
            searchPlaceholder="Search phases"
            disabled={watchlistOn}
          />

          <DdsDropdown
            label="Status"
            options={STATUS}
            values={get("status")}
            onChange={(v) => setFilter("status", v)}
            placeholder="All statuses"
            searchPlaceholder="Search statuses"
            disabled={watchlistOn}
          />

          <DdsDropdown
            label="Owner"
            helperText={isOlpSchedule ? "Locked on OLP schedule" : "Grouped by function"}
            groups={ownerGroups}
            values={get("owner")}
            onChange={(v) => setFilter("owner", v)}
            placeholder="All owners"
            searchPlaceholder="Search owners"
            disabled={isOlpSchedule || watchlistOn}
          />

          <DdsDropdown
            label="Task"
            helperText={isOlpSchedule ? "Locked on OLP schedule" : "Grouped by phase exit criteria"}
            groups={taskGroups}
            values={get("task")}
            onChange={(v) => setFilter("task", v)}
            placeholder="All tasks"
            searchPlaceholder="Search tasks"
            disabled={isOlpSchedule || watchlistOn}
          />
        </div>


        <SheetFooter className="px-6 py-4 border-t border-border flex-row justify-between gap-2">
          <div className="flex items-center gap-2">
            <Button variant="ghost" onClick={resetFilters}>
              Reset
            </Button>
            {isScoped && (
              <Button variant="outline" onClick={applyMyDefaults} disabled={watchlistOn}>
                My defaults
              </Button>
            )}
          </div>
          <Button onClick={close}>Apply</Button>
        </SheetFooter>
      </SheetContent>
    </Sheet>
  );
}
