import { Pencil, Info } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { useViewFilter } from "@/contexts/ViewFilterContext";
import { useRole } from "@/contexts/RoleContext";
import { useFilters } from "@/contexts/FilterContext";
import { launches as ALL_LAUNCHES } from "@/mocks/launches";
import { useMemo } from "react";

export function LockedFilterBar() {
  const { role } = useRole();
  const { lockedFunction, lockedLobs, lockedPlatformIds, open, isLocked } = useViewFilter();
  const { filters, setFilter } = useFilters();

  const assignedNames = useMemo(() => {
    if (!lockedPlatformIds) return [] as string[];
    return lockedPlatformIds
      .map((id) => ALL_LAUNCHES.find((x) => x.id === id)?.name)
      .filter((n): n is string => Boolean(n));
  }, [lockedPlatformIds]);

  const currentPlatformFilter = Array.isArray(filters.platform)
    ? (filters.platform as string[])
    : [];

  const assignedSet = new Set(assignedNames);
  const currentSet = new Set(currentPlatformFilter);
  const isDefault =
    assignedNames.length === currentPlatformFilter.length &&
    assignedNames.every((n) => currentSet.has(n));

  const platformChip = (() => {
    if (currentPlatformFilter.length === 0) return "All in function";
    if (isDefault) return `My platforms · ${assignedNames.length}`;
    return `${currentPlatformFilter.length} selected`;
  })();

  const lobLabel = useMemo(() => {
    if (!lockedLobs || lockedLobs.length === 0) return "—";
    return lockedLobs.join(", ");
  }, [lockedLobs]);

  if (!isLocked || !lockedFunction) return null;
  if (role !== "admin" && role !== "user") return null;

  return (
    <TooltipProvider>
      <div className="flex items-center gap-3 flex-wrap rounded-md border border-border bg-surface px-4 py-2 shadow-elev-1">
        <span className="text-caption text-muted-foreground">Default scope</span>
        <Badge variant="secondary" className="text-body-3">BU · CSG</Badge>
        <Badge variant="secondary" className="text-body-3">
          Function · {lockedFunction === "SChM" ? "SChM" : lockedFunction}
        </Badge>
        <Badge variant="secondary" className="text-body-3">LOB · {lobLabel}</Badge>

        <span className="text-caption text-muted-foreground ml-2">Platforms</span>
        <Tooltip>
          <TooltipTrigger asChild>
            <Badge
              variant={isDefault || currentPlatformFilter.length === 0 ? "outline" : "default"}
              className="text-body-3 inline-flex items-center gap-1"
            >
              {platformChip}
              <Info className="h-3 w-3 opacity-60" aria-hidden />
            </Badge>
          </TooltipTrigger>
          <TooltipContent className="max-w-xs text-caption">
            These are your default filters. You can expand any of them — including
            Function or LOB — from the Filters panel. You can view every platform,
            but can only act on your assigned ones.
          </TooltipContent>
        </Tooltip>

        {!isDefault && assignedNames.length > 0 && (
          <Button
            variant="ghost"
            size="sm"
            className="h-7 px-2 text-caption"
            onClick={() => setFilter("platform", assignedNames)}
          >
            Reset to my platforms
          </Button>
        )}

        <Button
          variant="ghost"
          size="sm"
          className="ml-auto gap-2"
          onClick={open}
        >
          <Pencil className="h-4 w-4" />
          Edit assignments
        </Button>
      </div>
    </TooltipProvider>
  );
}
