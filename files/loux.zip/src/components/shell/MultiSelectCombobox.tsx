import { useState } from "react";
import { Check, ChevronsUpDown, Lock, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
} from "@/components/ui/command";
import { cn } from "@/lib/utils";

export type ComboOption = { value: string; label: string };

interface MultiSelectComboboxProps {
  options: ComboOption[];
  values: string[];
  onChange: (next: string[]) => void;
  placeholder?: string;
  searchPlaceholder?: string;
  emptyText?: string;
  className?: string;
  /** Values implied by other filters; rendered locked and not removable. */
  lockedValues?: string[];
  lockedTooltip?: string;
}

export function MultiSelectCombobox({
  options,
  values,
  onChange,
  placeholder = "Select...",
  searchPlaceholder = "Search...",
  emptyText = "No matches.",
  className,
  lockedValues = [],
  lockedTooltip = "Required by another filter",
}: MultiSelectComboboxProps) {
  const [open, setOpen] = useState(false);

  const lockedSet = new Set(lockedValues);

  const toggle = (v: string) => {
    if (lockedSet.has(v)) return;
    if (values.includes(v)) onChange(values.filter((x) => x !== v));
    else onChange([...values, v]);
  };

  // Display = explicit values + locked values not already explicit.
  const displayValues = [
    ...values,
    ...lockedValues.filter((v) => !values.includes(v)),
  ];

  // Ensure locked options appear in the dropdown even if scoping removed them.
  const optionMap = new Map(options.map((o) => [o.value, o]));
  for (const v of lockedValues) if (!optionMap.has(v)) optionMap.set(v, { value: v, label: v });
  const allOptions = Array.from(optionMap.values());

  const labelFor = (v: string) =>
    optionMap.get(v)?.label ?? v;

  const selectedCount = displayValues.length;

  return (
    <div className={cn("space-y-2", className)}>
      <Popover open={open} onOpenChange={setOpen}>
        <PopoverTrigger asChild>
          <Button
            type="button"
            variant="outline"
            role="combobox"
            aria-expanded={open}
            className="w-full justify-between text-body-3 font-normal"
          >
            <span className={cn(selectedCount === 0 && "text-muted-foreground")}>
              {selectedCount === 0 ? placeholder : `${selectedCount} selected`}
            </span>
            <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
          </Button>
        </PopoverTrigger>
        <PopoverContent
          className="w-[--radix-popover-trigger-width] p-0"
          align="start"
        >
          <Command>
            <CommandInput placeholder={searchPlaceholder} />
            <CommandList>
              <CommandEmpty>{emptyText}</CommandEmpty>
              <CommandGroup>
                {allOptions.map((o) => {
                  const isLocked = lockedSet.has(o.value);
                  const checked = values.includes(o.value) || isLocked;
                  return (
                    <CommandItem
                      key={o.value}
                      value={o.label}
                      onSelect={() => toggle(o.value)}
                      disabled={isLocked}
                      className={cn(isLocked && "opacity-60")}
                    >
                      <Check
                        className={cn(
                          "mr-2 h-4 w-4",
                          checked ? "opacity-100" : "opacity-0",
                        )}
                      />
                      <span className="flex-1">{o.label}</span>
                      {isLocked && (
                        <Lock
                          className="ml-2 h-3 w-3 text-muted-foreground"
                          aria-label={lockedTooltip}
                        />
                      )}
                    </CommandItem>
                  );
                })}
              </CommandGroup>
            </CommandList>
          </Command>
        </PopoverContent>
      </Popover>

      {displayValues.length > 0 && (
        <div className="flex flex-wrap gap-1">
          {displayValues.map((v) => {
            const isLocked = lockedSet.has(v);
            return (
              <Badge
                key={v}
                variant="secondary"
                className="text-caption font-normal pl-2 pr-1 py-0 gap-1"
              >
                {labelFor(v)}
                {isLocked ? (
                  <span
                    className="rounded-full p-1 text-muted-foreground"
                    title={lockedTooltip}
                    aria-label={lockedTooltip}
                  >
                    <Lock className="h-3 w-3" />
                  </span>
                ) : (
                  <button
                    type="button"
                    onClick={() => toggle(v)}
                    aria-label={`Remove ${labelFor(v)}`}
                    className="rounded-full hover:bg-muted/60 p-1"
                  >
                    <X className="h-3 w-3" />
                  </button>
                )}
              </Badge>
            );
          })}
        </div>
      )}
    </div>
  );
}
