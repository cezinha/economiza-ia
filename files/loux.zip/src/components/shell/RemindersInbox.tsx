import { useEffect, useMemo, useState } from "react";
import { AlertCircle, Bell, ChevronDown, Clock, Inbox, MessageSquare, ShieldAlert, Sparkles, TrendingUp } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { cn } from "@/lib/utils";
import { NUDDS } from "@/mocks/nudds";
import { launches } from "@/mocks/launches";
import { tasksForLaunch, taskStatus, type TaskStatus } from "@/lib/launchTasks";
import { dueSignal, dueLabel } from "@/lib/taskDueSignals";
import { taskRunwayBucket } from "@/lib/taskRunway";
import { useRole } from "@/contexts/RoleContext";
import { useWatchlist } from "@/contexts/WatchlistContext";
import { useAssignedPlatformIds } from "@/lib/permissions";
import {
  getAllPlatformRequests,
  subscribePendingPlatforms,
  type PendingPlatform,
} from "@/mocks/pendingPlatforms";
import { getMentions, type Mention } from "@/mocks/mentions";
import {
  getPlatformStatusEvents,
  subscribePlatformStatusEvents,
  type PlatformStatusEvent,
} from "@/mocks/platformStatusEvents";
import { PlatformStatusChangeDialog } from "@/components/dashboard/PlatformStatusChangeDialog";


function formatRelative(ts: number): string {
  const ms = Date.now() - ts;
  if (ms < 60_000) return "just now";
  const m = Math.floor(ms / 60_000);
  if (m < 60) return `${m}m ago`;
  const h = Math.floor(m / 60);
  if (h < 24) return `${h}h ago`;
  const d = Math.floor(h / 24);
  return `${d}d ago`;
}

type Accent = "primary" | "warning" | "destructive";

const ACCENT_BG: Record<Accent, string> = {
  primary: "bg-primary/10 text-primary",
  warning: "bg-warning/10 text-warning",
  destructive: "bg-destructive/10 text-destructive",
};

const ACCENT_BAR: Record<Accent, string> = {
  primary: "bg-primary",
  warning: "bg-warning",
  destructive: "bg-destructive",
};

type NuddNotification = {
  id: string;
  title: string;
  platform: string;
  closeLabel: string;
  cadence: "Daily reminder" | "Weekly reminder";
  timestamp: string;
  daysUntil: number;
  accent: Accent;
};

function formatCloseDate(iso: string): string {
  const d = new Date(iso);
  return d.toLocaleDateString("en-GB", { day: "2-digit", month: "short" });
}

const DAYS_AHEAD = 30;
const MS_PER_DAY = 86_400_000;

function parseCloseUtc(s: string): number | null {
  if (!s) return null;
  const m = s.match(/^(\d{1,2})\/([A-Za-z]{3})\/(\d{2,4})$/);
  if (!m) {
    const t = new Date(s).getTime();
    return Number.isFinite(t) ? t : null;
  }
  const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
  const mi = months.indexOf(m[2]);
  if (mi < 0) return null;
  const yy = m[3].length === 2 ? 2000 + Number(m[3]) : Number(m[3]);
  return Date.UTC(yy, mi, Number(m[1]));
}

function buildNuddNotifications(): NuddNotification[] {
  const now = new Date();
  const startMs = Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate());
  const endMs = startMs + DAYS_AHEAD * MS_PER_DAY;

  type Row = { n: (typeof NUDDS)[number]; daysUntil: number; t: number };

  return NUDDS.filter((n) => n.status === "Open" || n.status === "On hold")
    .map<Row | null>((n) => {
      const t = parseCloseUtc(n.closeDate);
      if (t === null) return null;
      const daysUntil = Math.round((t - startMs) / MS_PER_DAY);
      return { n, daysUntil, t };
    })
    .filter((x): x is Row => x !== null && x.t >= startMs && x.t < endMs)
    .sort((a, b) => a.daysUntil - b.daysUntil)
    .map(({ n, daysUntil }) => {
      const accent: Accent =
        daysUntil <= 7 ? "destructive" : daysUntil <= 14 ? "warning" : "primary";
      const cadence = daysUntil <= 7 ? "Daily reminder" : "Weekly reminder";
      const timestamp =
        daysUntil === 0 ? "Today" : daysUntil === 1 ? "in 1d" : `in ${daysUntil}d`;
      return {
        id: n.id,
        title: `${n.id} · ${n.title}`,
        platform: n.platform,
        closeLabel: formatCloseDate(n.closeDate),
        cadence,
        timestamp,
        daysUntil,
        accent,
      };
    });
}

type DueNotification = {
  id: string;
  launchId: string;
  taskName: string;
  platform: string;
  label: string;
  cadence: "Daily reminder" | "Weekly reminder";
  daysUntil: number;
  accent: Accent;
  severity: "overdue" | "approaching";
};

const TASK_CAP = 12;

function buildDueNotifications(): DueNotification[] {
  const out: DueNotification[] = [];
  for (const launch of launches) {
    for (const t of tasksForLaunch(launch)) {
      const track = t.teams[0] ?? "SChM";
      const status = taskStatus(launch, t, track);
      if (status === "completed" || status === "not-started") continue;
      const sig = dueSignal(launch, t);
      if (sig.severity === "none") continue;
      const isOverdue = sig.severity === "overdue";
      // "Warning"-pill tasks: runway shorter than the suggested minimum (and not
      // yet overdue). These should always nag daily.
      const isWarning = !isOverdue && taskRunwayBucket(launch, t, { status }) === "soon";
      const accent: Accent = isOverdue
        ? "destructive"
        : isWarning
        ? "warning"
        : "primary";
      out.push({
        id: `${launch.id}::${t.id}`,
        launchId: launch.id,
        taskName: t.task,
        platform: launch.name,
        label: dueLabel(sig),
        cadence: isOverdue || isWarning ? "Daily reminder" : "Weekly reminder",
        daysUntil: sig.daysUntil,
        accent,
        severity: sig.severity,
      });
    }
  }
  return out.sort((a, b) => {
    if (a.severity !== b.severity) return a.severity === "overdue" ? -1 : 1;
    return a.daysUntil - b.daysUntil;
  });
}

type TabKey = "all" | "tasks" | "status" | "nudds" | "requests" | "mentions";

const STATUS_LABEL_SHORT: Record<TaskStatus, string> = {
  "on-track": "On track",
  "at-risk": "At risk",
  "at-risk-mitigated": "Mitigated",
  completed: "Completed",
  "not-started": "Not started",
};

const STATUS_ACCENT: Record<TaskStatus, Accent> = {
  "on-track": "primary",
  "at-risk": "destructive",
  "at-risk-mitigated": "warning",
  completed: "primary",
  "not-started": "primary",
};

function formatRelativeTs(ts: number): string {
  return formatRelative(ts);
}


function CountBadge({ n }: { n: number }) {
  if (n <= 0) return null;
  return (
    <span className="ml-1 inline-flex h-4 min-w-4 items-center justify-center rounded-full bg-muted px-1 text-caption tabular-nums text-muted-foreground">
      {n > 99 ? "99+" : n}
    </span>
  );
}

export function RemindersInbox() {
  const navigate = useNavigate();
  const { role } = useRole();
  const { watched } = useWatchlist();
  const [open, setOpen] = useState(false);
  const [tab, setTab] = useState<TabKey>("all");
  const [, setTick] = useState(0);
  const [statusEventId, setStatusEventId] = useState<string | null>(null);
  useEffect(() => subscribePendingPlatforms(() => setTick((n) => n + 1)), []);
  useEffect(() => subscribePlatformStatusEvents(() => setTick((n) => n + 1)), []);

  const assignedIds = useAssignedPlatformIds();

  // Scope all notifications to the active viewer's watchlist. Superadmin
  // implicitly watches every platform; other roles only see signals for
  // platforms they've explicitly added to their watchlist.
  const watchedIds = useMemo(() => new Set(watched), [watched]);
  const watchedNames = useMemo(
    () => new Set(launches.filter((l) => watchedIds.has(l.id)).map((l) => l.name)),
    [watchedIds],
  );


  const nudds = useMemo(
    () => buildNuddNotifications().filter((n) => watchedNames.has(n.platform)),
    [watchedNames],
  );
  const dues = useMemo(
    () => buildDueNotifications().filter((d) => watchedIds.has(d.launchId)),
    [watchedIds],
  );
  const mentions = useMemo<Mention[]>(
    () => getMentions().filter((m) => !!m.launchId && watchedIds.has(m.launchId)),
    [watchedIds],
  );
  const canSeeApprovals = role === "admin" || role === "superadmin";
  const approvals: PendingPlatform[] = useMemo(() => {
    if (!canSeeApprovals) return [];
    return getAllPlatformRequests().filter(
      (p) => p.source === "user" && p.status === "pending" && watchedNames.has(p.name),
    );
  }, [canSeeApprovals, watchedNames]);

  // Platform-status flips: audience is independent of watchlist.
  // - superadmin / executive: all events
  // - admin / user: events for assigned platforms only
  const statusEvents: PlatformStatusEvent[] = useMemo(() => {
    const all = getPlatformStatusEvents();
    if (role === "superadmin" || role === "executive") return all;
    if (!assignedIds) return [];
    return all.filter((e) => assignedIds.has(e.launchId));
  }, [role, assignedIds]);

  const overdueCount = dues.filter((d) => d.severity === "overdue").length;
  const approachingCount = dues.length - overdueCount;
  const visibleDues = (tab === "all" || tab === "tasks") ? dues.slice(0, TASK_CAP) : [];
  const hiddenDueCount = Math.max(0, dues.length - TASK_CAP);
  const count = nudds.length + dues.length + approvals.length + mentions.length + statusEvents.length;

  const openRisks = () => { setOpen(false); navigate("/risks"); };
  const openTasks = () => { setOpen(false); navigate("/tasks"); };
  const openApprovals = () => { setOpen(false); navigate("/"); };
  const openMention = (href: string) => { setOpen(false); navigate(href); };
  const openStatusEvent = (id: string) => { setOpen(false); setStatusEventId(id); };

  const summaryParts: string[] = [];
  if (approvals.length) summaryParts.push(`${approvals.length} request${approvals.length === 1 ? "" : "s"}`);
  if (statusEvents.length) summaryParts.push(`${statusEvents.length} status change${statusEvents.length === 1 ? "" : "s"}`);
  if (overdueCount) summaryParts.push(`${overdueCount} overdue`);
  if (approachingCount) summaryParts.push(`${approachingCount} due soon`);
  if (nudds.length) summaryParts.push(`${nudds.length} NUDD${nudds.length === 1 ? "" : "s"}`);
  if (mentions.length) summaryParts.push(`${mentions.length} mention${mentions.length === 1 ? "" : "s"}`);
  const summary = count === 0 ? "You're all caught up" : summaryParts.join(" · ");


  const showRequests = canSeeApprovals;
  const showSection = (key: Exclude<TabKey, "all">) => tab === "all" || tab === key;

  const activeEmpty =
    tab === "tasks" ? dues.length === 0 :
    tab === "status" ? statusEvents.length === 0 :
    tab === "nudds" ? nudds.length === 0 :
    tab === "requests" ? approvals.length === 0 :
    tab === "mentions" ? mentions.length === 0 :
    count === 0;


  const renderTasks = visibleDues.length > 0 && showSection("tasks") && (
    <div className="p-2">
      {tab === "all" && (
        <p className="px-2 pt-1 pb-2 text-caption font-medium text-muted-foreground uppercase tracking-wide">
          Tasks
        </p>
      )}
      <ul>
        {visibleDues.map((d) => {
          const Icon = d.severity === "overdue" ? AlertCircle : Clock;
          return (
            <li key={d.id}>
              <button
                type="button"
                onClick={openTasks}
                className="relative w-full text-left flex gap-3 rounded-lg p-3 transition-colors hover:bg-muted/50"
              >
                <span aria-hidden className={cn("absolute left-0 top-3 bottom-3 w-[3px] rounded-r", ACCENT_BAR[d.accent])} />
                <div className={cn("flex h-8 w-8 shrink-0 items-center justify-center rounded-md", ACCENT_BG[d.accent])}>
                  <Icon className="h-4 w-4" />
                </div>
                <div className="min-w-0 flex-1">
                  <div className="flex items-start justify-between gap-2">
                    <p className="text-body-3 font-medium text-foreground truncate">{d.taskName}</p>
                    <span className="text-caption text-muted-foreground whitespace-nowrap pt-1">{d.label}</span>
                  </div>
                  <p className="text-caption text-muted-foreground truncate">
                    {d.platform} · {d.cadence}
                  </p>
                </div>
              </button>
            </li>
          );
        })}
      </ul>
      {tab === "all" && hiddenDueCount > 0 && (
        <button
          type="button"
          onClick={openTasks}
          className="w-full text-left px-3 py-2 text-caption text-primary hover:underline"
        >
          +{hiddenDueCount} more task{hiddenDueCount === 1 ? "" : "s"}
        </button>
      )}
      {tab === "tasks" && dues.length > TASK_CAP && (
        <button
          type="button"
          onClick={openTasks}
          className="w-full text-left px-3 py-2 text-caption text-primary hover:underline"
        >
          View all {dues.length} tasks
        </button>
      )}
    </div>
  );

  const renderStatus = statusEvents.length > 0 && showSection("status") && (
    <div className={cn("p-2", tab === "all" && dues.length > 0 && "border-t border-border")}>
      {tab === "all" && (
        <p className="px-2 pt-1 pb-2 text-caption font-medium text-muted-foreground uppercase tracking-wide">
          Platform status changes
        </p>
      )}
      <ul>
        {statusEvents.map((e) => {
          const accent = STATUS_ACCENT[e.toStatus];
          return (
            <li key={e.id}>
              <button
                type="button"
                onClick={() => openStatusEvent(e.id)}
                className="relative w-full text-left flex gap-3 rounded-lg p-3 transition-colors hover:bg-muted/50"
              >
                <span aria-hidden className={cn("absolute left-0 top-3 bottom-3 w-[3px] rounded-r", ACCENT_BAR[accent])} />
                <div className={cn("flex h-8 w-8 shrink-0 items-center justify-center rounded-md", ACCENT_BG[accent])}>
                  <TrendingUp className="h-4 w-4" />
                </div>
                <div className="min-w-0 flex-1">
                  <div className="flex items-start justify-between gap-2">
                    <p className="text-body-3 font-medium text-foreground truncate">
                      {e.launchName} · {STATUS_LABEL_SHORT[e.fromStatus]} → {STATUS_LABEL_SHORT[e.toStatus]}
                    </p>
                    <span className="text-caption text-muted-foreground whitespace-nowrap pt-1">{formatRelativeTs(e.ts)}</span>
                  </div>
                  <p className="text-caption text-muted-foreground truncate">
                    Double-click to see why
                  </p>
                </div>
              </button>
            </li>
          );
        })}
      </ul>
    </div>
  );

  const renderNudds = nudds.length > 0 && showSection("nudds") && (
    <div className={cn("p-2", tab === "all" && (dues.length > 0 || statusEvents.length > 0) && "border-t border-border")}>
      {tab === "all" && (
        <p className="px-2 pt-1 pb-2 text-caption font-medium text-muted-foreground uppercase tracking-wide">
          NUDDs
        </p>
      )}
      <ul>
        {nudds.map((n) => (
          <li key={n.id}>
            <button
              type="button"
              onClick={openRisks}
              className="relative w-full text-left flex gap-3 rounded-lg p-3 transition-colors hover:bg-muted/50"
            >
              <span aria-hidden className={cn("absolute left-0 top-3 bottom-3 w-[3px] rounded-r", ACCENT_BAR[n.accent])} />
              <div className={cn("flex h-8 w-8 shrink-0 items-center justify-center rounded-md", ACCENT_BG[n.accent])}>
                <ShieldAlert className="h-4 w-4" />
              </div>
              <div className="min-w-0 flex-1">
                <div className="flex items-start justify-between gap-2">
                  <p className="text-body-3 font-medium text-foreground truncate">{n.title}</p>
                  <span className="text-caption text-muted-foreground whitespace-nowrap pt-1">{n.timestamp}</span>
                </div>
                <p className="text-caption text-muted-foreground truncate">
                  {n.platform} · closes {n.closeLabel} · {n.cadence}
                </p>
              </div>
            </button>
          </li>
        ))}
      </ul>
    </div>
  );

  const renderRequests = approvals.length > 0 && showSection("requests") && showRequests && (
    <div className={cn("p-2", tab === "all" && (dues.length > 0 || statusEvents.length > 0 || nudds.length > 0) && "border-t border-border")}>
      {tab === "all" && (
        <p className="px-2 pt-1 pb-2 text-caption font-medium text-muted-foreground uppercase tracking-wide">
          Requests
        </p>
      )}
      <ul>
        {approvals.map((p) => (
          <li key={p.id}>
            <button
              type="button"
              onClick={openApprovals}
              className="relative w-full text-left flex gap-3 rounded-lg p-3 transition-colors hover:bg-muted/50"
            >
              <span aria-hidden className={cn("absolute left-0 top-3 bottom-3 w-[3px] rounded-r", ACCENT_BAR.primary)} />
              <div className={cn("flex h-8 w-8 shrink-0 items-center justify-center rounded-md", ACCENT_BG.primary)}>
                <Inbox className="h-4 w-4" />
              </div>
              <div className="min-w-0 flex-1">
                <div className="flex items-start justify-between gap-2">
                  <p className="text-body-3 font-medium text-foreground truncate">
                    New platform request · {p.name}
                  </p>
                  <span className="text-caption text-muted-foreground whitespace-nowrap pt-1">
                    {formatRelative(p.requestedAt)}
                  </span>
                </div>
                <p className="text-caption text-muted-foreground truncate">
                  {p.requestedBy} · {p.businessUnit} / {p.lob} · {p.region}
                </p>
              </div>
            </button>
          </li>
        ))}
      </ul>
    </div>
  );

  const renderMentions = mentions.length > 0 && showSection("mentions") && (
    <div className={cn("p-2", tab === "all" && (dues.length > 0 || statusEvents.length > 0 || nudds.length > 0 || approvals.length > 0) && "border-t border-border")}>
      {tab === "all" && (
        <p className="px-2 pt-1 pb-2 text-caption font-medium text-muted-foreground uppercase tracking-wide">
          Mentions
        </p>
      )}
      <ul>
        {mentions.map((m) => (
          <li key={m.id}>
            <button
              type="button"
              onClick={() => openMention(m.href)}
              className="relative w-full text-left flex gap-3 rounded-lg p-3 transition-colors hover:bg-muted/50"
            >
              <span aria-hidden className={cn("absolute left-0 top-3 bottom-3 w-[3px] rounded-r", ACCENT_BAR.primary)} />
              <div className={cn("flex h-8 w-8 shrink-0 items-center justify-center rounded-md", ACCENT_BG.primary)}>
                <MessageSquare className="h-4 w-4" />
              </div>
              <div className="min-w-0 flex-1">
                <div className="flex items-start justify-between gap-2">
                  <p className="text-body-3 font-medium text-foreground truncate">{m.actor}</p>
                  <span className="text-caption text-muted-foreground whitespace-nowrap pt-1">{formatRelative(m.ts)}</span>
                </div>
                <p className="text-caption text-foreground truncate">{m.snippet}</p>
                <p className="text-caption text-muted-foreground truncate">{m.context}</p>
              </div>
            </button>
          </li>
        ))}
      </ul>
    </div>
  );

  return (
    <DropdownMenu open={open} onOpenChange={setOpen}>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" className="h-10 gap-2 px-3" aria-label="Notifications">
          <span className="relative inline-flex">
            <Bell className="h-5 w-5" strokeWidth={1.5} />
            {count > 0 && (
              <span className="absolute -top-2 -right-2 inline-flex h-4 min-w-4 items-center justify-center rounded-full bg-primary px-1 text-caption font-medium text-primary-foreground">
                {count > 99 ? "99+" : count}
              </span>
            )}
          </span>
          <span className="text-body-3">Notifications</span>
          <ChevronDown className="h-4 w-4 text-muted-foreground" />
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent
        align="end"
        sideOffset={8}
        className="w-[460px] p-0 overflow-hidden border-border bg-card shadow-elev-3"
      >
        <div className="border-b border-border px-4 py-3">
          <p className="text-h6 text-foreground">Notifications</p>
          <p className="text-caption text-muted-foreground">{summary}</p>
        </div>

        <div className="border-b border-border px-2 pt-2">
          <Tabs value={tab} onValueChange={(v) => setTab(v as TabKey)}>
            <TabsList className="h-9 w-full justify-start gap-1 bg-transparent p-0">
              <TabsTrigger value="all" className="text-caption px-2 h-8 data-[state=active]:bg-muted">
                All<CountBadge n={count} />
              </TabsTrigger>
              <TabsTrigger value="tasks" className="text-caption px-2 h-8 data-[state=active]:bg-muted">
                Tasks<CountBadge n={dues.length} />
              </TabsTrigger>
              <TabsTrigger value="status" className="text-caption px-2 h-8 data-[state=active]:bg-muted">
                Status<CountBadge n={statusEvents.length} />
              </TabsTrigger>
              <TabsTrigger value="nudds" className="text-caption px-2 h-8 data-[state=active]:bg-muted">
                NUDDs<CountBadge n={nudds.length} />

              </TabsTrigger>
              {showRequests && (
                <TabsTrigger value="requests" className="text-caption px-2 h-8 data-[state=active]:bg-muted">
                  Requests<CountBadge n={approvals.length} />
                </TabsTrigger>
              )}
              <TabsTrigger value="mentions" className="text-caption px-2 h-8 data-[state=active]:bg-muted">
                Mentions<CountBadge n={mentions.length} />
              </TabsTrigger>
            </TabsList>
          </Tabs>
        </div>

        {activeEmpty ? (
          <div className="flex flex-col items-center justify-center px-6 py-12 text-center">
            <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/10 mb-3">
              <Sparkles className="h-6 w-6 text-primary" />
            </div>
            <p className="text-body-3 font-medium text-foreground">
              {count === 0 ? "No notifications yet" : "Nothing here yet"}
            </p>
            <p className="text-caption text-muted-foreground mt-1">
              {count === 0 ? "Upcoming NUDDs and due tasks will appear here." : "Switch tabs to see other notifications."}
            </p>
          </div>
        ) : (
          <div className="max-h-[520px] overflow-y-auto">
            {renderTasks}
            {renderStatus}
            {renderNudds}
            {renderRequests}
            {renderMentions}
          </div>
        )}
      </DropdownMenuContent>
      <PlatformStatusChangeDialog
        eventId={statusEventId}
        onClose={() => setStatusEventId(null)}
      />
    </DropdownMenu>
  );
}

