import { useEffect, useRef } from "react";
import { useViewFilter } from "@/contexts/ViewFilterContext";
import { useFilters } from "@/contexts/FilterContext";
import { useRole } from "@/contexts/RoleContext";
import { launches as ALL_LAUNCHES } from "@/mocks/launches";

/**
 * Mirrors the role-view scope (Function / LOB / Platforms) into the global
 * Filter sheet for admin and user roles, so the Filters panel reflects what's
 * locked. Cleared when leaving an admin/user role.
 */
export function RoleViewFilterSync() {
  const { role } = useRole();
  const { lockedFunction, lockedLobs, lockedPlatformIds } = useViewFilter();
  const { setFilter, filters } = useFilters();
  const lastApplied = useRef<string>("");

  useEffect(() => {
    const isScoped = role === "admin" || role === "user";
    if (!isScoped) {
      if (lastApplied.current) {
        setFilter("organization", []);
        setFilter("function", []);
        setFilter("lob", []);
        setFilter("platform", []);
        lastApplied.current = "";
      }
      return;
    }
    if (!lockedFunction || !lockedPlatformIds || !lockedLobs) return;

    const platformNames = lockedPlatformIds
      .map((id) => ALL_LAUNCHES.find((l) => l.id === id)?.name)
      .filter((n): n is string => Boolean(n));

    const bu = ["CSG"];
    const fn = [lockedFunction];
    const lobs = [...lockedLobs];

    const key = JSON.stringify({ role, bu, fn, lobs, platformNames });
    if (key === lastApplied.current) return;
    lastApplied.current = key;

    // All four scope filters are soft defaults — seeded once per scope change.
    // User edits stick (including expanding Function/LOB/Platforms beyond their
    // assignment). Action gating still enforces "act only on assigned platforms".
    setFilter("organization", bu);
    setFilter("function", fn);
    setFilter("lob", lobs);
    setFilter("platform", platformNames);
    void filters;

  }, [role, lockedFunction, lockedLobs, lockedPlatformIds, setFilter, filters]);

  return null;
}
