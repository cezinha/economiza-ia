import { useEffect, useMemo, useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { useViewFilter } from "@/contexts/ViewFilterContext";
import { useRole, ROLES } from "@/contexts/RoleContext";
import { launches as ALL_LAUNCHES } from "@/mocks/launches";
import { launchHasFunction, type TaskFunction } from "@/lib/launchTasks";
import { Search } from "lucide-react";
import { cn } from "@/lib/utils";

const FUNCTIONS: { value: TaskFunction; label: string }[] = [
  { value: "GOE", label: "GOE" },
  { value: "NPI", label: "NPI" },
  { value: "SChM", label: "SChM" },
];

export function RoleViewModal() {
  const {
    isOpen,
    apply,
    cancel,
    pendingRole,
    modalPrefillFunction,
    modalPrefillLobs,
    modalPrefillPlatformIds,
  } = useViewFilter();
  const { role } = useRole();
  const displayRole = pendingRole ?? role;
  const roleLabel = ROLES.find((r) => r.value === displayRole)?.label ?? displayRole;

  const [fn, setFn] = useState<TaskFunction | null>(modalPrefillFunction);
  const [lobs, setLobs] = useState<string[]>(modalPrefillLobs ?? []);
  const [platformIds, setPlatformIds] = useState<string[]>(modalPrefillPlatformIds ?? []);
  const [search, setSearch] = useState("");

  useEffect(() => {
    if (isOpen) {
      setFn(modalPrefillFunction);
      setLobs(modalPrefillLobs ?? []);
      setPlatformIds(modalPrefillPlatformIds ?? []);
      setSearch("");
    }
  }, [isOpen, modalPrefillFunction, modalPrefillLobs, modalPrefillPlatformIds]);

  // Function change → reset LOBs and Platforms.
  const handleFnChange = (next: TaskFunction) => {
    if (next !== fn) {
      setFn(next);
      setLobs([]);
      setPlatformIds([]);
    }
  };

  // LOBs eligible for the chosen function.
  const fnEligibleLaunches = useMemo(() => {
    if (!fn) return [] as typeof ALL_LAUNCHES;
    return ALL_LAUNCHES.filter((l) => launchHasFunction(l, fn));
  }, [fn]);

  const lobOptions = useMemo(() => {
    return Array.from(new Set(fnEligibleLaunches.map((l) => l.lob))).sort();
  }, [fnEligibleLaunches]);

  const toggleLob = (lob: string) => {
    setLobs((prev) => {
      const next = prev.includes(lob) ? prev.filter((x) => x !== lob) : [...prev, lob];
      // Drop platforms no longer matching the new LOB set.
      const allowed = new Set(
        fnEligibleLaunches.filter((l) => next.includes(l.lob)).map((l) => l.id),
      );
      setPlatformIds((p) => p.filter((id) => allowed.has(id)));
      return next;
    });
  };

  // Platform list filtered by Function AND LOB selection.
  const lobEligible = useMemo(() => {
    if (lobs.length === 0) return [] as typeof ALL_LAUNCHES;
    return fnEligibleLaunches.filter((l) => lobs.includes(l.lob));
  }, [fnEligibleLaunches, lobs]);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    if (!q) return lobEligible;
    return lobEligible.filter(
      (l) =>
        l.name.toLowerCase().includes(q) ||
        l.lob.toLowerCase().includes(q) ||
        l.region.toLowerCase().includes(q),
    );
  }, [search, lobEligible]);

  const allSelected = filtered.length > 0 && filtered.every((l) => platformIds.includes(l.id));

  const togglePlatform = (id: string) => {
    setPlatformIds((prev) =>
      prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id],
    );
  };

  const toggleAllVisible = () => {
    const ids = filtered.map((l) => l.id);
    if (allSelected) {
      setPlatformIds((prev) => prev.filter((id) => !ids.includes(id)));
    } else {
      setPlatformIds((prev) => Array.from(new Set([...prev, ...ids])));
    }
  };

  const lobsEnabled = fn !== null;
  const platformsEnabled = lobsEnabled && lobs.length > 0;
  const canApply = fn !== null && lobs.length > 0 && platformIds.length > 0;

  return (
    <Dialog
      open={isOpen}
      onOpenChange={(next) => {
        if (!next) cancel();
      }}
    >
      <DialogContent className="max-w-xl">
        <DialogHeader>
          <DialogTitle>Set your view as {roleLabel}</DialogTitle>
          <DialogDescription>
            Pick the function you operate in, then the LOB(s), then your platforms. {roleLabel}{" "}
            dashboards are scoped to that selection. You can change this later.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6">
          {/* Step 1 — Function */}
          <div className="space-y-2">
            <Label className="text-body-3 text-foreground">1. Function</Label>
            <RadioGroup
              value={fn ?? ""}
              onValueChange={(v) => handleFnChange(v as TaskFunction)}
              className="flex gap-4"
            >
              {FUNCTIONS.map((f) => (
                <label
                  key={f.value}
                  className={cn(
                    "flex items-center gap-2 rounded-md border border-border px-3 py-2 cursor-pointer",
                    fn === f.value && "border-primary bg-primary/5",
                  )}
                >
                  <RadioGroupItem value={f.value} id={`fn-${f.value}`} />
                  <span className="text-body-3 text-foreground">{f.label}</span>
                </label>
              ))}
            </RadioGroup>
          </div>

          {/* Step 2 — LOB */}
          <div
            className={cn("space-y-2", !lobsEnabled && "opacity-50 pointer-events-none")}
            aria-disabled={!lobsEnabled}
          >
            <Label className="text-body-3 text-foreground">
              2. LOB{" "}
              <span className="text-caption text-muted-foreground">
                ({lobs.length} selected)
              </span>
            </Label>
            {!lobsEnabled && (
              <p className="text-caption text-muted-foreground">Select a function first.</p>
            )}
            {lobsEnabled && lobOptions.length === 0 && (
              <p className="text-caption text-muted-foreground">No LOBs available for this function.</p>
            )}
            {lobsEnabled && lobOptions.length > 0 && (
              <div className="flex flex-wrap gap-2">
                {lobOptions.map((lob) => {
                  const checked = lobs.includes(lob);
                  return (
                    <button
                      type="button"
                      key={lob}
                      onClick={() => toggleLob(lob)}
                      className={cn(
                        "flex items-center gap-2 rounded-md border border-border px-3 py-2 text-body-3 cursor-pointer",
                        checked && "border-primary bg-primary/5",
                      )}
                    >
                      <Checkbox checked={checked} className="pointer-events-none" />
                      <span className="text-foreground">{lob}</span>
                    </button>
                  );
                })}
              </div>
            )}
          </div>

          {/* Step 3 — Platforms */}
          <div
            className={cn("space-y-2", !platformsEnabled && "opacity-50 pointer-events-none")}
            aria-disabled={!platformsEnabled}
          >
            <div className="flex items-center justify-between">
              <Label className="text-body-3 text-foreground">
                3. Platforms{" "}
                <span className="text-caption text-muted-foreground">
                  ({platformIds.length} selected)
                </span>
              </Label>
              <button
                type="button"
                onClick={toggleAllVisible}
                className="text-caption text-primary hover:underline"
              >
                {allSelected ? "Clear visible" : "Select all visible"}
              </button>
            </div>
            {!platformsEnabled && (
              <p className="text-caption text-muted-foreground">
                Select at least one LOB to choose platforms.
              </p>
            )}
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search platforms…"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="pl-10"
              />
            </div>
            <div className="max-h-64 overflow-y-auto rounded-md border border-border">
              {filtered.length === 0 ? (
                <p className="px-3 py-4 text-caption italic text-muted-foreground">
                  No platforms match.
                </p>
              ) : (
                <ul>
                  {filtered.map((l) => {
                    const checked = platformIds.includes(l.id);
                    return (
                      <li key={l.id}>
                        <label className="flex items-center gap-3 px-3 py-2 cursor-pointer hover:bg-muted/40">
                          <Checkbox
                            checked={checked}
                            onCheckedChange={() => togglePlatform(l.id)}
                          />
                          <span className="flex-1 min-w-0">
                            <span className="block text-body-3 text-foreground truncate">
                              {l.name}
                            </span>
                            <span className="block text-caption text-muted-foreground truncate">
                              {l.lob}
                            </span>
                          </span>
                        </label>
                      </li>
                    );
                  })}
                </ul>
              )}
            </div>
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={cancel}>
            Cancel
          </Button>
          <Button
            disabled={!canApply}
            onClick={() => fn && apply(fn, lobs, platformIds)}
          >
            Apply
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
