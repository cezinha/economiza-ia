import { RefObject } from "react";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Share2, Mail, FileDown } from "lucide-react";
import { exportElementToPdf } from "@/lib/exportPdf";
import { toast } from "@/hooks/use-toast";

type Props = {
  targetRef: RefObject<HTMLElement>;
  title: string;
  filenameSlug: string;
  orientation?: "portrait" | "landscape";
};

/** Reusable Share dropdown: Export as PDF / Share via email. */
export function SharePdfButton({ targetRef, title, filenameSlug, orientation = "landscape" }: Props) {
  const handleExport = async () => {
    const el = targetRef.current;
    if (!el) return;
    try {
      await exportElementToPdf(el, { title, filenameSlug, orientation });
      toast({ title: "PDF downloaded", description: `${filenameSlug}.pdf` });
    } catch (e) {
      toast({ title: "Export failed", description: String(e) });
    }
  };

  const handleEmail = async () => {
    const el = targetRef.current;
    if (!el) return;
    try {
      await exportElementToPdf(el, { title, filenameSlug, orientation });
      const subject = encodeURIComponent(title);
      const body = encodeURIComponent(
        `Hi,\n\nSharing the ${title}. The PDF was just downloaded to your device — please attach "${filenameSlug}.pdf" to this email before sending.\n\nThanks`,
      );
      window.location.href = `mailto:?subject=${subject}&body=${body}`;
      toast({ title: "Email ready", description: "PDF downloaded — attach it to the email draft." });
    } catch (e) {
      toast({ title: "Email failed", description: String(e) });
    }
  };

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button
          type="button"
          variant="ghost"
          size="sm"
          className="gap-1 px-2 text-button-2 hover:bg-transparent"
          style={{ color: "#0672CB" }}
        >
          <Share2 className="h-4 w-4" aria-hidden />
          Share
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end">
        <DropdownMenuItem onClick={handleExport}>
          <FileDown className="mr-2 h-4 w-4" aria-hidden />
          Export as PDF
        </DropdownMenuItem>
        <DropdownMenuItem onClick={handleEmail}>
          <Mail className="mr-2 h-4 w-4" aria-hidden />
          Share via email
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
