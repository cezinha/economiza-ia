import { Search, ChevronDown, Filter, User, Info } from "lucide-react";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useRole, ROLES, Role } from "@/contexts/RoleContext";
import { useFilters } from "@/contexts/FilterContext";
import { useViewFilter } from "@/contexts/ViewFilterContext";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useEffect, useState } from "react";
import dellLogo from "@/assets/dell-technologies-logo.png";
import { RemindersInbox } from "./RemindersInbox";


type Density = "compact" | "default" | "comfy";


export function TopBar() {
  const { role } = useRole();
  const { requestRoleSwitch } = useViewFilter();
  const { open: openFilters, activeCount } = useFilters();
  const [density, setDensity] = useState<Density>("default");

  useEffect(() => {
    document.documentElement.dataset.density = density;
  }, [density]);


  const currentRoleLabel = ROLES.find((r) => r.value === role)?.label ?? role;

  return (
    <header className="sticky top-0 z-50 flex h-16 items-center gap-6 border-b border-border bg-surface px-4 m:px-6">
      {/* Brand / masthead */}
      <div className="flex items-center gap-3 shrink-0">
        <img src={dellLogo} alt="Dell Technologies" className="h-6 w-auto" />
        
        <span className="text-body-2 text-foreground ml-2">OLP Launch Orchestrator</span>
      </div>

      {/* Search hidden for now */}
      <div className="flex-1" />

      <div className="ml-auto flex items-center gap-2">
        {/* Filters */}
        <Button
          variant="outline"
          className="h-10 gap-2 px-3 bg-[#0672CB] text-white border-[#0672CB] hover:bg-[#0672CB]/90 hover:text-white"
          onClick={openFilters}
          aria-label="Filter"

        >
          <Filter className="h-4 w-4" />
          <span className="text-body-3">Filter</span>
          {activeCount > 0 && (
            <span className="inline-flex h-5 min-w-5 items-center justify-center rounded-full bg-white px-1 text-caption font-medium text-[#0672CB]">
              {activeCount}
            </span>
          )}
        </Button>


        {/* Reminders */}
        <RemindersInbox />





        {/* Profile (with Density + View as inside) */}
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" className="h-10 gap-2 px-3">
              <User className="h-5 w-5" strokeWidth={1.5} />
              <span className="text-body-3">Profile</span>
              <ChevronDown className="h-4 w-4 text-muted-foreground" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-72 p-4 space-y-4">
            {/* Density — DDS Select */}
            <div className="space-y-2">
              <label htmlFor="density-select" className="block text-body-3 text-foreground">
                Density
              </label>
              <Select value={density} onValueChange={(v) => setDensity(v as Density)}>
                <SelectTrigger id="density-select" className="h-8 w-full bg-surface cursor-pointer transition-colors hover:border-primary">
                  <SelectValue placeholder="Select one" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="compact">Compact</SelectItem>
                  <SelectItem value="default">Default</SelectItem>
                  <SelectItem value="comfy">Comfortable</SelectItem>
                </SelectContent>
              </Select>
              <p className="text-caption text-muted-foreground">
                Control spacing across the dashboard
              </p>

            </div>

            {/* View as — DDS Select */}
            <div className="space-y-2">
              <div className="flex items-center gap-1">
                <label htmlFor="view-as-select" className="block text-body-3 text-foreground">
                  View as
                </label>
                <Popover>
                  <PopoverTrigger asChild>
                    <button
                      type="button"
                      aria-label="About View as"
                      className="inline-flex h-4 w-4 items-center justify-center text-muted-foreground hover:text-foreground focus:outline-none focus:ring-2 focus:ring-ring rounded-full"
                    >
                      <Info className="h-4 w-4" strokeWidth={1.75} />
                    </button>
                  </PopoverTrigger>
                  <PopoverContent side="top" align="start" className="w-60 text-caption text-foreground">
                    Demo-only; in the actual dashboard, users will be locked to their account role.
                  </PopoverContent>
                </Popover>
              </div>
              <Select value={role} onValueChange={(v) => requestRoleSwitch(v as Role)}>
                <SelectTrigger id="view-as-select" className="h-8 w-full bg-surface cursor-pointer transition-colors hover:border-primary">
                  <SelectValue placeholder="Select one" />
                </SelectTrigger>
                <SelectContent>
                  {ROLES.map((r) => (
                    <SelectItem key={r.value} value={r.value}>
                      {r.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <p className="text-caption text-muted-foreground flex flex-wrap items-center gap-1">
                [Demo] Preview the dashboard as another role
                <br />
                <span>Currently:</span>
                <span
                  className="inline-flex items-center rounded-full px-2 text-caption"
                  style={{
                    backgroundColor:
                      role === "superadmin"
                        ? "#1D2C3B"
                        : role === "executive"
                        ? "#141D28"
                        : role === "admin"
                        ? "#293B4D"
                        : "#40586D",
                    color: "#EBF1F6",
                  }}
                >
                  {currentRoleLabel}
                </span>
              </p>


            </div>
          </DropdownMenuContent>

        </DropdownMenu>
      </div>
    </header>
  );
}

