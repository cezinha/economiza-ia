import * as DialogPrimitive from "@radix-ui/react-dialog";
import { ChevronLeft } from "lucide-react";
import * as React from "react";

import { cn } from "@/lib/utils";

type DdsDrawerSize = "xs" | "sm" | "md" | "lg";

const SIZE_CLASS: Record<DdsDrawerSize, string> = {
  xs: "w-[320px]",
  sm: "w-[560px]",
  md: "w-[920px]",
  lg: "w-[1200px]",
};

interface DdsDrawerProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  size?: DdsDrawerSize;
  ariaLabel?: string;
  children: React.ReactNode;
}

export function DdsDrawer({
  open,
  onOpenChange,
  size = "sm",
  ariaLabel,
  children,
}: DdsDrawerProps) {
  return (
    <DialogPrimitive.Root open={open} onOpenChange={onOpenChange}>
      <DialogPrimitive.Portal>
        <DialogPrimitive.Overlay
          className="fixed inset-0 z-50 bg-foreground/40 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0"
        />
        <DialogPrimitive.Content
          aria-label={ariaLabel}
          className={cn(
            "fixed inset-y-0 right-0 z-50 flex h-full flex-col bg-card shadow-elev-left-4 transition ease-in-out",
            "data-[state=open]:animate-in data-[state=closed]:animate-out",
            "data-[state=closed]:slide-out-to-right data-[state=open]:slide-in-from-right",
            "data-[state=closed]:duration-300 data-[state=open]:duration-500",
            "max-w-[90vw]",
            SIZE_CLASS[size],
          )}
        >
          {children}
        </DialogPrimitive.Content>
      </DialogPrimitive.Portal>
    </DialogPrimitive.Root>
  );
}

export function DdsDrawerHeader({
  children,
  className,
}: {
  children?: React.ReactNode;
  className?: string;
}) {
  return (
    <div className={cn("flex flex-col gap-4 border-b border-border px-6 py-6", className)}>
      <DialogPrimitive.Close asChild>
        <button
          type="button"
          className="inline-flex w-fit items-center gap-1 text-button-2 text-[#0672CB] hover:text-[#055AA3] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#0672CB] focus-visible:ring-offset-2"
        >
          <ChevronLeft className="h-4 w-4" />
          Back
        </button>
      </DialogPrimitive.Close>
      {children}
    </div>
  );
}

export function DdsDrawerTitle({
  children,
  className,
}: {
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <DialogPrimitive.Title className={cn("text-h4 text-foreground", className)}>
      {children}
    </DialogPrimitive.Title>
  );
}

export function DdsDrawerDescription({
  children,
  className,
}: {
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <DialogPrimitive.Description className={cn("text-body-2 text-muted-foreground", className)}>
      {children}
    </DialogPrimitive.Description>
  );
}

export function DdsDrawerBody({
  children,
  className,
}: {
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <div className={cn("flex-1 overflow-y-auto px-6 py-6", className)}>
      {children}
    </div>
  );
}

export function DdsDrawerFooter({
  children,
  className,
}: {
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <div className={cn("flex items-center gap-3 border-t border-border px-6 py-4", className)}>
      {children}
    </div>
  );
}
