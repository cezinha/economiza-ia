import {
  DdsDrawer,
  DdsDrawerHeader,
  DdsDrawerTitle,
} from "@/components/ui/dds-drawer";
import { AddUserForm } from "./AddUserForm";

interface AddUserDrawerProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function AddUserDrawer({ open, onOpenChange }: AddUserDrawerProps) {
  return (
    <DdsDrawer open={open} onOpenChange={onOpenChange} size="sm" ariaLabel="Add User">
      <DdsDrawerHeader>
        <DdsDrawerTitle className="text-h3">Add new user</DdsDrawerTitle>
        <p className="text-subtitle-2 text-muted-foreground mt-2">Add a new user to the platform with the appropriate role</p>
      </DdsDrawerHeader>
      <AddUserForm onClose={() => onOpenChange(false)} />
    </DdsDrawer>
  );
}
