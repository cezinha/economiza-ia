import { useEffect, useMemo, useRef, useState } from "react";
import { Check, ChevronDown, X } from "lucide-react";
import { DdsDrawerBody, DdsDrawerFooter } from "@/components/ui/dds-drawer";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { launches } from "@/mocks/launches";
import { ALL_USERS, type DirectoryUser } from "@/mocks/users";

const PRIMARY_BTN =
  "gap-2 text-button-1 bg-[#0672CB] text-white hover:bg-[#055AA3] active:bg-[#044A87] focus-visible:ring-2 focus-visible:ring-[#0672CB] focus-visible:ring-offset-2 disabled:opacity-40 disabled:bg-[#0672CB]";
const SECONDARY_BTN =
  "gap-2 text-button-1 bg-transparent border-[#0672CB] text-[#0672CB] hover:bg-[#0672CB]/10 hover:text-[#0672CB] active:bg-[#0672CB]/20 focus-visible:ring-2 focus-visible:ring-[#0672CB] focus-visible:ring-offset-2 disabled:opacity-40";
const TRIGGER_CLS =
  "flex h-8 w-full items-center justify-between rounded-md border border-border bg-card px-3 text-body-2 text-left hover:border-[#0672CB] focus:border-[#0672CB] focus:outline-none focus:ring-1 focus:ring-[#0672CB] disabled:cursor-not-allowed";

interface FilterableSelectProps {
  value: string;
  onChange: (v: string) => void;
  options: string[];
  disabled?: boolean;
  placeholder?: string;
}

function FilterableSelect({ value, onChange, options, disabled, placeholder }: FilterableSelectProps) {
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState("");
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (open) {
      setQuery("");
      setTimeout(() => inputRef.current?.focus(), 0);
    }
  }, [open]);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    const list = q ? options.filter((o) => o.toLowerCase().includes(q)) : options;
    return [...list].sort((a, b) => a.localeCompare(b));
  }, [options, query]);

  return (
    <Popover open={open} onOpenChange={(o) => !disabled && setOpen(o)}>
      <PopoverTrigger asChild>
        <button type="button" disabled={disabled} className={TRIGGER_CLS}>
          {open ? (
            <input
              ref={inputRef}
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder={value || placeholder || ""}
              className="w-full bg-transparent text-body-2 outline-none"
              onClick={(e) => e.stopPropagation()}
            />
          ) : (
            <span className={value ? "" : "text-muted-foreground"}>{value || placeholder || ""}</span>
          )}
          <ChevronDown className="h-4 w-4 shrink-0 opacity-60" />
        </button>
      </PopoverTrigger>
      <PopoverContent
        className="w-[--radix-popover-trigger-width] p-1 bg-card max-h-60 overflow-y-auto overscroll-contain"
        align="start"
        onWheel={(e) => e.stopPropagation()}
        onTouchMove={(e) => e.stopPropagation()}
      >
        {filtered.length === 0 ? (
          <div className="px-3 py-2 text-body-2 text-muted-foreground">No options found</div>
        ) : (
          filtered.map((o) => (
            <button
              type="button"
              key={o}
              onClick={() => { onChange(o); setOpen(false); }}
              className={`flex w-full items-center justify-between rounded px-2 py-1 text-body-2 text-left hover:bg-[#EBF5FB] ${o === value ? "bg-[#D9F5FD]" : ""}`}
            >
              <span>{o}</span>
              {o === value && <Check className="h-4 w-4 text-[#0672CB]" />}
            </button>
          ))
        )}
      </PopoverContent>
    </Popover>
  );
}

const ROLE_OPTIONS = ["User", "Admin", "Super Admin", "Executive"];
const BU_OPTIONS = ["CSG", "ISG"];
const FUNC_OPTIONS = ["GOE", "NPI", "SChM"];
const LOB_BY_BU: Record<string, string[]> = {
  CSG: ["DT", "DnCP", "NB"],
  ISG: ["Network EQ", "S&S", "Server", "Storage"],
};
const MANAGER_ADMINS: DirectoryUser[] = ALL_USERS
  .filter((u) => u.role === "Admin" && u.enabled)
  .sort((a, b) => a.displayName.localeCompare(b.displayName));
const MANAGER_OPTIONS = MANAGER_ADMINS.map((u) => u.displayName);

interface AddUserFormProps {
  onClose: () => void;
  submitLabel?: string;
  bulk?: boolean;
  initialUser?: DirectoryUser;
}

export function AddUserForm({ onClose, submitLabel = "Add User", bulk = false, initialUser }: AddUserFormProps) {
  const editMode = !!initialUser;
  const [enabled, setEnabled] = useState(initialUser?.enabled ?? true);
  const [role, setRole] = useState<string>(initialUser?.role ?? "");
  const [name, setName] = useState(initialUser?.name ?? "");
  const [email, setEmail] = useState(initialUser?.email ?? "");
  const [manager, setManager] = useState(initialUser?.managerName ?? "");
  const [bu, setBu] = useState(initialUser && initialUser.businessUnit !== "All" ? initialUser.businessUnit : "");
  const [func, setFunc] = useState(initialUser && initialUser.function !== "All" ? initialUser.function : "");
  const [lob, setLob] = useState(initialUser && initialUser.lob !== "All" ? initialUser.lob : "");
  const [platforms, setPlatforms] = useState<string[]>(initialUser?.assignedPlatformNames ?? []);
  const [platformsOpen, setPlatformsOpen] = useState(false);
  const [platformsQuery, setPlatformsQuery] = useState("");

  const isAdmin = role === "Admin";
  const isUser = role === "User";

  const selectedManager = useMemo(
    () => (isUser && manager ? MANAGER_ADMINS.find((u) => u.displayName === manager) : undefined),
    [isUser, manager],
  );

  useEffect(() => {
    if (!isUser) return;
    if (selectedManager) {
      const mgrBu = selectedManager.businessUnit === "All" ? "" : selectedManager.businessUnit;
      const mgrFn = selectedManager.function === "All" ? "" : selectedManager.function;
      const mgrLob = selectedManager.lob === "All" ? "" : selectedManager.lob;
      setBu(mgrBu);
      setFunc(mgrFn);
      setLob(mgrLob);
      setPlatforms((prev) => prev.filter((p) => selectedManager.assignedPlatformNames.includes(p)));
    } else {
      setBu(""); setFunc(""); setLob(""); setPlatforms([]);
    }
  }, [isUser, selectedManager]);

  const userScopeLocked = isUser && !selectedManager;
  const scopeLocked = !role || role === "Super Admin" || role === "Executive" || userScopeLocked;
  const buLocked = isUser ? true : scopeLocked;
  const funcLocked = isUser ? true : (scopeLocked || !bu);
  const lobLocked = isUser ? true : (scopeLocked || !func);
  const platformsLocked = isUser ? !selectedManager : (scopeLocked || !lob);
  const managerLocked = editMode ? false : !isUser;
  const managerRequired = isUser;
  const baseFilled = (bulk || name.trim().length > 0) && email.trim().length > 0 && !!role;
  const scopeFilled = !!bu && !!func && !!lob && platforms.length > 0;
  const accessLocked = editMode ? false : (!baseFilled
    || (isUser && (!manager || !scopeFilled))
    || (isAdmin && !scopeFilled));
  const lockedCls = (l: boolean) => (l ? "opacity-40 pointer-events-none" : "");
  const managerLockedClass = lockedCls(managerLocked);
  const accessLockedClass = lockedCls(accessLocked);
  const scopeRequired = isAdmin || isUser;
  const requiredMark = <span className="text-destructive">*</span>;

  const emailValid = bulk
    ? email.trim().length > 0 && email.split(/\r?\n/).map((s) => s.trim()).filter(Boolean).every((s) => /^[^\s@]+@(dell|dellteam)\.com$/i.test(s))
    : /^[^\s@]+@(dell|dellteam)\.com$/i.test(email.trim());
  const scopeValid = !scopeRequired || (!!bu && !!func && !!lob && platforms.length > 0);
  const managerValid = !managerRequired || !!manager;

  const lobOptions = bu ? LOB_BY_BU[bu] ?? [] : [];

  const availablePlatforms = useMemo(() => {
    if (isUser) return selectedManager ? [...selectedManager.assignedPlatformNames].sort() : [];
    if (!bu || !lob) return [] as string[];
    return launches.filter((l) => l.lob === lob).map((l) => l.name).sort();
  }, [isUser, selectedManager, bu, lob]);

  const filteredPlatforms = useMemo(() => {
    const q = platformsQuery.trim().toLowerCase();
    return q ? availablePlatforms.filter((p) => p.toLowerCase().includes(q)) : availablePlatforms;
  }, [availablePlatforms, platformsQuery]);

  const togglePlatform = (p: string) => {
    setPlatforms((prev) => (prev.includes(p) ? prev.filter((x) => x !== p) : [...prev, p]));
  };

  const hasChanges = useMemo(() => {
    if (!editMode || !initialUser) return true;
    const initBu = initialUser.businessUnit === "All" ? "" : initialUser.businessUnit;
    const initFn = initialUser.function === "All" ? "" : initialUser.function;
    const initLob = initialUser.lob === "All" ? "" : initialUser.lob;
    const initPlatforms = [...initialUser.assignedPlatformNames].sort().join("|");
    const curPlatforms = [...platforms].sort().join("|");
    return (
      role !== initialUser.role ||
      manager !== (initialUser.managerName ?? "") ||
      bu !== initBu ||
      func !== initFn ||
      lob !== initLob ||
      enabled !== initialUser.enabled ||
      curPlatforms !== initPlatforms
    );
  }, [editMode, initialUser, role, manager, bu, func, lob, enabled, platforms]);

  const canSubmit = (bulk || name.trim().length > 0) && emailValid && !!role && enabled && scopeValid && managerValid && (!editMode || hasChanges);

  const emailLocked = editMode ? true : (bulk ? false : name.trim().length === 0);
  const roleLocked = editMode ? false : (bulk ? email.trim().length === 0 : (emailLocked || email.trim().length === 0));
  const nameLocked = editMode;

  return (
    <>
      <DdsDrawerBody>
        <form className="space-y-5" onSubmit={(e) => { e.preventDefault(); onClose(); }}>
          {!bulk && (
            <div className={`space-y-2 ${lockedCls(nameLocked)}`} aria-disabled={nameLocked}>
              <Label htmlFor="add-name" className="text-body-2 font-normal">Full name {!editMode && !nameLocked && requiredMark}</Label>
              <Input id="add-name" value={name} onChange={(e) => setName(e.target.value)} maxLength={100} disabled={nameLocked} />
            </div>
          )}
          <div className={`space-y-2 ${lockedCls(emailLocked)}`} aria-disabled={emailLocked}>
            <Label htmlFor="add-email" className="text-body-2 font-normal">{bulk ? "Email addresses (enter one email per line)" : "Email address"} {!editMode && !emailLocked && requiredMark}</Label>
            {bulk ? (
              <textarea
                id="add-email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                rows={5}
                className="flex w-full rounded-md border border-border bg-card px-3 py-2 text-body-2 hover:border-[#0672CB] focus:border-[#0672CB] focus:outline-none focus:ring-1 focus:ring-[#0672CB]"
              />
            ) : (
              <Input id="add-email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} maxLength={255} disabled={emailLocked} />
            )}
            <p className="text-caption text-muted-foreground">Only @dell.com and @dellteam.com email addresses permitted</p>
          </div>
          <div className={`space-y-2 ${lockedCls(roleLocked)}`} aria-disabled={roleLocked}>
            <Label className="text-body-2 font-normal">{bulk ? "Roles for all users" : "Role"} {!editMode && !roleLocked && requiredMark}</Label>
            <FilterableSelect value={role} onChange={setRole} options={ROLE_OPTIONS} disabled={roleLocked} />
          </div>
          {(isUser || (!editMode && !role)) && (
            <div className={`space-y-2 ${managerLockedClass}`} aria-disabled={managerLocked}>
              <Label className="text-body-2 font-normal">Manager {!editMode && managerRequired && !managerLocked && requiredMark}</Label>
              <FilterableSelect value={manager} onChange={setManager} options={MANAGER_OPTIONS} disabled={managerLocked} />
            </div>
          )}
          {(scopeRequired || (!editMode && !role)) && (
            <>
              <div className={`space-y-2 ${!isUser ? lockedCls(buLocked) : ""} ${isUser ? "opacity-40 pointer-events-none" : ""}`} aria-disabled={buLocked}>
                <Label className="text-body-2 font-normal">Business unit {!editMode && scopeRequired && !buLocked && requiredMark}</Label>
                {isUser ? (
                  <div className="flex h-8 items-center rounded-md border border-border bg-muted px-3 text-body-2 text-foreground">
                    {bu || <span className="text-muted-foreground">Select a Manager</span>}
                  </div>
                ) : (
                  <FilterableSelect
                    value={bu}
                    onChange={(v) => { setBu(v); setFunc(""); setLob(""); setPlatforms([]); }}
                    options={BU_OPTIONS}
                    disabled={buLocked}
                  />
                )}
              </div>
              <div className={`space-y-2 ${!isUser ? lockedCls(funcLocked) : ""} ${isUser ? "opacity-40 pointer-events-none" : ""}`} aria-disabled={funcLocked}>
                <Label className="text-body-2 font-normal">Function {!editMode && scopeRequired && !funcLocked && requiredMark}</Label>
                {isUser ? (
                  <div className="flex h-8 items-center rounded-md border border-border bg-muted px-3 text-body-2 text-foreground">
                    {func || <span className="text-muted-foreground">Select a Manager</span>}
                  </div>
                ) : (
                  <FilterableSelect
                    value={func}
                    onChange={(v) => { setFunc(v); setLob(""); setPlatforms([]); }}
                    options={FUNC_OPTIONS}
                    disabled={funcLocked}
                  />
                )}
              </div>
              <div className={`space-y-2 ${!isUser ? lockedCls(lobLocked) : ""} ${isUser ? "opacity-40 pointer-events-none" : ""}`} aria-disabled={lobLocked}>
                <Label className="text-body-2 font-normal">LOB {!editMode && scopeRequired && !lobLocked && requiredMark}</Label>
                {isUser ? (
                  <div className="flex h-8 items-center rounded-md border border-border bg-muted px-3 text-body-2 text-foreground">
                    {lob || <span className="text-muted-foreground">Select a Manager</span>}
                  </div>
                ) : (
                  <FilterableSelect
                    value={lob}
                    onChange={(v) => { setLob(v); setPlatforms([]); }}
                    options={lobOptions}
                    disabled={lobLocked}
                  />
                )}
              </div>
              <div className={`space-y-2 ${lockedCls(platformsLocked)}`} aria-disabled={platformsLocked}>
                <Label className="text-body-2 font-normal">Platforms {!editMode && scopeRequired && !platformsLocked && requiredMark}</Label>
                <Popover open={platformsOpen} onOpenChange={(o) => { if (!platformsLocked) { setPlatformsOpen(o); if (o) setPlatformsQuery(""); } }}>
                  <PopoverTrigger asChild>
                    <button
                      type="button"
                      disabled={platformsLocked}
                      className="flex h-8 w-full items-center justify-between rounded-md border border-border bg-card px-3 text-body-2 text-left hover:border-[#0672CB] focus:border-[#0672CB] focus:outline-none focus:ring-1 focus:ring-[#0672CB] disabled:cursor-not-allowed"
                    >
                      {platforms.length === 0 ? (
                        <span>&nbsp;</span>
                      ) : (
                        <span className="inline-flex items-center gap-1 rounded bg-[#D9F5FD] px-2 py-[2px] text-body-2 text-[#0E0E0E]">
                          {platforms.length} selected
                          <X
                            className="h-3 w-3 cursor-pointer"
                            onClick={(e) => { e.stopPropagation(); setPlatforms([]); }}
                          />
                        </span>
                      )}
                      <ChevronDown className="h-4 w-4 shrink-0 opacity-60" />
                    </button>
                  </PopoverTrigger>
                  <PopoverContent
                    className="w-[--radix-popover-trigger-width] p-1 bg-card"
                    align="start"
                    onWheel={(e) => e.stopPropagation()}
                    onTouchMove={(e) => e.stopPropagation()}
                  >
                    <input
                      autoFocus
                      value={platformsQuery}
                      onChange={(e) => setPlatformsQuery(e.target.value)}
                      placeholder="Filter platforms"
                      className="mb-1 w-full rounded border border-border bg-card px-2 py-1 text-body-2 outline-none focus:border-[#0672CB]"
                    />
                    <div className="max-h-60 overflow-y-auto overscroll-contain">
                      {filteredPlatforms.length === 0 ? (
                        <div className="px-3 py-2 text-body-2 text-muted-foreground">No options found</div>
                      ) : (
                        <>
                          {platformsQuery.trim() === "" && (() => {
                            const allSelected = availablePlatforms.length > 0 && availablePlatforms.every((p) => platforms.includes(p));
                            const someSelected = !allSelected && availablePlatforms.some((p) => platforms.includes(p));
                            return (
                              <label className="flex w-full items-center gap-2 rounded px-2 py-1 text-body-2 hover:bg-[#EBF5FB] cursor-pointer border-b border-border">
                                <Checkbox
                                  checked={allSelected ? true : someSelected ? "indeterminate" : false}
                                  onCheckedChange={() => setPlatforms(allSelected ? [] : [...availablePlatforms])}
                                />
                                <span>Select all</span>
                              </label>
                            );
                          })()}
                          {filteredPlatforms.map((p) => {
                            const checked = platforms.includes(p);
                            return (
                              <label
                                key={p}
                                className="flex w-full items-center gap-2 rounded px-2 py-1 text-body-2 hover:bg-[#EBF5FB] cursor-pointer"
                              >
                                <Checkbox checked={checked} onCheckedChange={() => togglePlatform(p)} />
                                <span>{p}</span>
                              </label>
                            );
                          })}
                        </>
                      )}
                    </div>
                  </PopoverContent>
                </Popover>
              </div>
            </>
          )}
          <div className={`flex items-center gap-2 ${accessLockedClass}`} aria-disabled={accessLocked}>
            <Checkbox id="add-access" checked={enabled} onCheckedChange={(v) => setEnabled(v === true)} disabled={accessLocked} />
            <Label htmlFor="add-access" className="text-body-2 font-normal">Dashboard access {!editMode && role && !accessLocked && requiredMark}</Label>
          </div>
        </form>
      </DdsDrawerBody>
      <DdsDrawerFooter>
        <Button className={PRIMARY_BTN} disabled={!canSubmit} onClick={onClose}>{submitLabel}</Button>
        <Button variant="outline" className={SECONDARY_BTN} onClick={onClose}>Cancel</Button>
      </DdsDrawerFooter>
    </>
  );
}
