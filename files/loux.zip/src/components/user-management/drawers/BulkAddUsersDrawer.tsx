import {
  DdsDrawer,
  DdsDrawerHeader,
  DdsDrawerTitle,
} from "@/components/ui/dds-drawer";
import { AddUserForm } from "./AddUserForm";

interface BulkAddUsersDrawerProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function BulkAddUsersDrawer({ open, onOpenChange }: BulkAddUsersDrawerProps) {
  return (
    <DdsDrawer open={open} onOpenChange={onOpenChange} size="sm" ariaLabel="Bulk Add Users">
      <DdsDrawerHeader>
        <DdsDrawerTitle className="text-h3">Bulk add users</DdsDrawerTitle>
        <p className="text-subtitle-2 text-muted-foreground mt-2">Add multiple users at once - enter one email per line</p>
      </DdsDrawerHeader>
      <AddUserForm onClose={() => onOpenChange(false)} submitLabel="Add Users" bulk />
    </DdsDrawer>
  );
}
