import { AlertTriangle } from "lucide-react";
import {
  DdsDrawer,
  DdsDrawerBody,
  DdsDrawerFooter,
  DdsDrawerHeader,
  DdsDrawerTitle,
} from "@/components/ui/dds-drawer";
import { Button } from "@/components/ui/button";
import type { DirectoryUser } from "@/mocks/users";

const DANGER_BTN =
  "gap-2 text-button-1 bg-destructive text-destructive-foreground hover:bg-destructive/90 focus-visible:ring-2 focus-visible:ring-destructive focus-visible:ring-offset-2";
const SECONDARY_BTN =
  "gap-2 text-button-1 bg-transparent border-[#0672CB] text-[#0672CB] hover:bg-[#0672CB]/10 hover:text-[#0672CB] active:bg-[#0672CB]/20 focus-visible:ring-2 focus-visible:ring-[#0672CB] focus-visible:ring-offset-2";

interface DeleteUserDrawerProps {
  user: DirectoryUser | null;
  onOpenChange: (open: boolean) => void;
}

export function DeleteUserDrawer({ user, onOpenChange }: DeleteUserDrawerProps) {
  if (!user) {
    return (
      <DdsDrawer open={false} onOpenChange={onOpenChange} size="xs" ariaLabel="Delete user">
        <div />
      </DdsDrawer>
    );
  }

  return (
    <DdsDrawer open={true} onOpenChange={onOpenChange} size="xs" ariaLabel={`Delete ${user.displayName}`}>
      <DdsDrawerHeader>
        <DdsDrawerTitle>Delete user</DdsDrawerTitle>
      </DdsDrawerHeader>
      <DdsDrawerBody>
        <div className="space-y-4">
          <div className="flex items-center gap-3 rounded-md border border-destructive/30 bg-destructive/10 p-4 text-destructive">
            <AlertTriangle className="h-5 w-5 shrink-0" />
            <span className="text-body-2">This action cannot be undone.</span>
          </div>
          <p className="text-body-2 text-foreground">
            Are you sure you want to remove <span className="text-h6">{user.displayName}</span> from
            OLP Launch Orchestrator?
          </p>
          <p className="text-body-3 text-muted-foreground">{user.email}</p>
        </div>
      </DdsDrawerBody>
      <DdsDrawerFooter>
        <Button className={DANGER_BTN} onClick={() => onOpenChange(false)}>Delete</Button>
        <Button variant="outline" className={SECONDARY_BTN} onClick={() => onOpenChange(false)}>Cancel</Button>
      </DdsDrawerFooter>
    </DdsDrawer>
  );
}
