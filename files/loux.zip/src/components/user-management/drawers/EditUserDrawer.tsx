import { useEffect, useState } from "react";
import {
  DdsDrawer,
  DdsDrawerBody,
  DdsDrawerFooter,
  DdsDrawerHeader,
  DdsDrawerTitle,
} from "@/components/ui/dds-drawer";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import type { DirectoryUser } from "@/mocks/users";

const PRIMARY_BTN =
  "gap-2 text-button-1 bg-[#0672CB] text-white hover:bg-[#055AA3] active:bg-[#044A87] focus-visible:ring-2 focus-visible:ring-[#0672CB] focus-visible:ring-offset-2 disabled:opacity-40 disabled:bg-[#0672CB]";
const SECONDARY_BTN =
  "gap-2 text-button-1 bg-transparent border-[#0672CB] text-[#0672CB] hover:bg-[#0672CB]/10 hover:text-[#0672CB] active:bg-[#0672CB]/20 focus-visible:ring-2 focus-visible:ring-[#0672CB] focus-visible:ring-offset-2 disabled:opacity-40";

interface EditUserDrawerProps {
  user: DirectoryUser | null;
  onOpenChange: (open: boolean) => void;
}

export function EditUserDrawer({ user, onOpenChange }: EditUserDrawerProps) {
  const [enabled, setEnabled] = useState(true);

  useEffect(() => {
    if (user) setEnabled(user.enabled);
  }, [user]);

  if (!user) {
    return (
      <DdsDrawer open={false} onOpenChange={onOpenChange} size="sm" ariaLabel="Edit user">
        <div />
      </DdsDrawer>
    );
  }

  return (
    <DdsDrawer open={true} onOpenChange={onOpenChange} size="sm" ariaLabel={`Edit ${user.displayName}`}>
      <DdsDrawerHeader>
        <DdsDrawerTitle>Edit user — {user.displayName}</DdsDrawerTitle>
      </DdsDrawerHeader>
      <DdsDrawerBody>
        <form className="space-y-5" onSubmit={(e) => { e.preventDefault(); onOpenChange(false); }}>
          <div className="space-y-2">
            <Label htmlFor="edit-name" className="text-h6">Name</Label>
            <Input id="edit-name" defaultValue={user.displayName} />
          </div>
          <div className="space-y-2">
            <Label htmlFor="edit-email" className="text-h6">Email</Label>
            <Input id="edit-email" type="email" defaultValue={user.email} />
          </div>
          <div className="space-y-2">
            <Label className="text-h6">Role</Label>
            <Select defaultValue={user.role}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="User">User</SelectItem>
                <SelectItem value="Admin">Admin</SelectItem>
                <SelectItem value="Super Admin">Super Admin</SelectItem>
                <SelectItem value="Executive">Executive</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="flex items-center justify-between">
            <Label htmlFor="edit-access" className="text-h6">Access enabled</Label>
            <Switch id="edit-access" checked={enabled} onCheckedChange={setEnabled} />
          </div>
          <div className="space-y-2">
            <Label className="text-h6">Business unit</Label>
            <Select defaultValue={user.businessUnit}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="CSG">CSG</SelectItem>
                <SelectItem value="ISG">ISG</SelectItem>
                <SelectItem value="All">All</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label className="text-h6">Function</Label>
            <Select defaultValue={user.function}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="GOE">GOE</SelectItem>
                <SelectItem value="NPI">NPI</SelectItem>
                <SelectItem value="SChM">SChM</SelectItem>
                <SelectItem value="All">All</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label htmlFor="edit-lob" className="text-h6">LOB</Label>
            <Input id="edit-lob" defaultValue={user.lob} />
          </div>
          <div className="space-y-2">
            <Label htmlFor="edit-platforms" className="text-h6">Platforms</Label>
            <Input id="edit-platforms" defaultValue={user.programs} />
          </div>
        </form>
      </DdsDrawerBody>
      <DdsDrawerFooter>
        <Button className={PRIMARY_BTN} onClick={() => onOpenChange(false)}>Save changes</Button>
        <Button variant="outline" className={SECONDARY_BTN} onClick={() => onOpenChange(false)}>Cancel</Button>
      </DdsDrawerFooter>
    </DdsDrawer>
  );
}
