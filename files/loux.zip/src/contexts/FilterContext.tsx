import { createContext, ReactNode, useCallback, useContext, useEffect, useMemo, useRef, useState } from "react";
import { useRole } from "@/contexts/RoleContext";

export type FilterValues = Record<string, unknown>;

type FilterContextValue = {
  filters: FilterValues;
  setFilter: (key: string, value: unknown) => void;
  setManyFilters: (patch: FilterValues) => void;
  resetFilters: () => void;
  isOpen: boolean;
  open: () => void;
  close: () => void;
  setOpen: (open: boolean) => void;
  activeCount: number;
};

const FilterContext = createContext<FilterContextValue | undefined>(undefined);

function isActive(value: unknown): boolean {
  if (value === undefined || value === null || value === "") return false;
  if (Array.isArray(value)) return value.length > 0;
  if (typeof value === "object") return Object.keys(value as object).length > 0;
  return true;
}

export function FilterProvider({ children }: { children: ReactNode }) {
  const { role } = useRole();
  const [filters, setFilters] = useState<FilterValues>({});
  const [isOpen, setIsOpen] = useState(false);
  const seededRolesRef = useRef<Set<string>>(new Set());

  // Seed the Watchlist scope as the default view for Admin/User the first time
  // we see each of those roles in this session. Other roles never auto-enable it.
  useEffect(() => {
    if (role !== "admin" && role !== "user") return;
    if (seededRolesRef.current.has(role)) return;
    seededRolesRef.current.add(role);
    setFilters((prev) => (prev.watchlist === undefined ? { ...prev, watchlist: true } : prev));
  }, [role]);

  const setFilter = useCallback((key: string, value: unknown) => {
    setFilters((prev) => ({ ...prev, [key]: value }));
  }, []);

  const setManyFilters = useCallback((patch: FilterValues) => {
    setFilters((prev) => ({ ...prev, ...patch }));
  }, []);

  const resetFilters = useCallback(() => setFilters({}), []);
  const open = useCallback(() => setIsOpen(true), []);
  const close = useCallback(() => setIsOpen(false), []);

  const activeCount = useMemo(() => {
    // When Watchlist scope is on, other filter keys are "paused" and shouldn't
    // inflate the active count — show 1 for the Watchlist lock itself.
    if (filters.watchlist === true) return 1;
    return Object.entries(filters)
      .filter(([k, v]) => k !== "watchlist" && isActive(v))
      .length;
  }, [filters]);

  const value = useMemo(
    () => ({ filters, setFilter, setManyFilters, resetFilters, isOpen, open, close, setOpen: setIsOpen, activeCount }),
    [filters, setFilter, setManyFilters, resetFilters, isOpen, open, close, activeCount],
  );

  return <FilterContext.Provider value={value}>{children}</FilterContext.Provider>;
}

export function useFilters() {
  const ctx = useContext(FilterContext);
  if (!ctx) throw new Error("useFilters must be used within a FilterProvider");
  return ctx;
}
