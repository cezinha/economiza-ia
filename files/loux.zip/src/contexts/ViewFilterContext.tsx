import { createContext, useCallback, useContext, useMemo, useState, ReactNode } from "react";
import type { TaskFunction } from "@/lib/launchTasks";
import { useRole, type Role } from "@/contexts/RoleContext";

const STORAGE_KEY = "viewFilter:v2";

interface StoredState {
  role: Role;
  fn: TaskFunction;
  lobs: string[];
  platformIds: string[];
}

interface ViewFilterValue {
  /** Locked function (only meaningful for admin/user). */
  lockedFunction: TaskFunction | null;
  /** Locked LOBs (only meaningful for admin/user). */
  lockedLobs: string[] | null;
  /** Locked launch ids (only meaningful for admin/user). null = no scope. */
  lockedPlatformIds: string[] | null;
  /** True when the role requires setup but no selection has been made. */
  isLocked: boolean;
  /** Modal open state. */
  isOpen: boolean;
  /** Role being scoped in the modal — pending target if mid-switch, else current role. */
  pendingRole: Role | null;
  /** Prefill values for the modal (based on pendingRole). */
  modalPrefillFunction: TaskFunction | null;
  modalPrefillLobs: string[] | null;
  modalPrefillPlatformIds: string[] | null;
  /** Open the modal for the current role (Edit view affordance). */
  open: () => void;
  /** Request a role switch from the TopBar. Opens the popup for admin/user. */
  requestRoleSwitch: (next: Role) => void;
  apply: (fn: TaskFunction, lobs: string[], platformIds: string[]) => void;
  cancel: () => void;
}

const ViewFilterContext = createContext<ViewFilterValue | undefined>(undefined);

function readStored(): Record<string, StoredState> {
  try {
    const raw = sessionStorage.getItem(STORAGE_KEY);
    if (!raw) return {};
    return JSON.parse(raw) as Record<string, StoredState>;
  } catch {
    return {};
  }
}

function writeStored(map: Record<string, StoredState>) {
  try {
    sessionStorage.setItem(STORAGE_KEY, JSON.stringify(map));
  } catch {
    /* ignore */
  }
}

export function ViewFilterProvider({ children }: { children: ReactNode }) {
  const { role, setRole } = useRole();
  const [stored, setStored] = useState<Record<string, StoredState>>(() => readStored());
  const [isOpen, setIsOpen] = useState(false);
  const [pendingTarget, setPendingTarget] = useState<Role | null>(null);

  const requiresScoping = role === "admin" || role === "user";
  const current = requiresScoping ? stored[role] : undefined;

  const pendingRole: Role | null = pendingTarget ?? (requiresScoping ? role : null);
  const prefillSource = pendingTarget ? stored[pendingTarget] : current;

  const requestRoleSwitch = useCallback((next: Role) => {
    if (next === "admin" || next === "user") {
      setPendingTarget(next);
      setIsOpen(true);
    } else {
      setPendingTarget(null);
      setIsOpen(false);
      setRole(next);
    }
  }, [setRole]);

  const apply = useCallback(
    (fn: TaskFunction, lobs: string[], platformIds: string[]) => {
      const target = pendingTarget ?? (requiresScoping ? role : null);
      if (!target) return;
      const next = { ...stored, [target]: { role: target, fn, lobs, platformIds } };
      setStored(next);
      writeStored(next);
      setIsOpen(false);
      if (pendingTarget && pendingTarget !== role) {
        setRole(pendingTarget);
      }
      setPendingTarget(null);
    },
    [pendingTarget, role, requiresScoping, stored, setRole],
  );

  const cancel = useCallback(() => {
    setIsOpen(false);
    setPendingTarget(null);
  }, []);

  const open = useCallback(() => {
    setPendingTarget(null);
    setIsOpen(true);
  }, []);

  const value = useMemo<ViewFilterValue>(
    () => ({
      lockedFunction: current?.fn ?? null,
      lockedLobs: current?.lobs ?? null,
      lockedPlatformIds: current?.platformIds ?? null,
      isLocked: requiresScoping,
      isOpen,
      pendingRole,
      modalPrefillFunction: prefillSource?.fn ?? null,
      modalPrefillLobs: prefillSource?.lobs ?? null,
      modalPrefillPlatformIds: prefillSource?.platformIds ?? null,
      open,
      requestRoleSwitch,
      apply,
      cancel,
    }),
    [current, requiresScoping, isOpen, pendingRole, prefillSource, open, requestRoleSwitch, apply, cancel],
  );

  return <ViewFilterContext.Provider value={value}>{children}</ViewFilterContext.Provider>;
}

export function useViewFilter(): ViewFilterValue {
  const ctx = useContext(ViewFilterContext);
  if (!ctx) throw new Error("useViewFilter must be used within ViewFilterProvider");
  return ctx;
}
