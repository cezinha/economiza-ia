import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import { useRole } from "@/contexts/RoleContext";
import { useViewFilter } from "@/contexts/ViewFilterContext";
import { launches } from "@/mocks/launches";

const STORAGE_KEY = "executive.watchlist.v1";

interface WatchlistContextValue {
  watched: string[];
  isWatched: (id: string) => boolean;
  toggle: (id: string) => boolean;
  add: (id: string) => void;
  remove: (id: string) => void;
  /** True when the whole watchlist is locked (superadmin watches all). */
  isLocked: boolean;
  lockedReason?: string;
  /** True for a specific platform that the viewer cannot remove (assigned scope). */
  isItemLocked: (id: string) => boolean;
  itemLockedReason?: string;
}

const WatchlistContext = createContext<WatchlistContextValue | undefined>(undefined);

function loadInitial(): string[] {
  if (typeof window === "undefined") return [];
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed.filter((v): v is string => typeof v === "string") : [];
  } catch {
    return [];
  }
}

export function WatchlistProvider({ children }: { children: ReactNode }) {
  const { role } = useRole();
  const { lockedPlatformIds } = useViewFilter();
  const [personal, setPersonal] = useState<string[]>(loadInitial);

  useEffect(() => {
    try {
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(personal));
    } catch {
      /* ignore */
    }
  }, [personal]);

  const isLocked = role === "superadmin";
  const lockedReason = isLocked ? "Superadmin watches all platforms by default" : undefined;

  const allIds = useMemo(() => launches.map((l) => l.id), []);

  // Admin/User: assigned-scope platforms are always on the watchlist and cannot be removed.
  // Additional platforms may be added — those remain view-only (no action permissions).
  const assignedSet = useMemo(() => {
    if (role !== "admin" && role !== "user") return null;
    return new Set(lockedPlatformIds ?? []);
  }, [role, lockedPlatformIds]);

  const watched = useMemo(() => {
    if (isLocked) return allIds;
    if (!assignedSet) return personal;
    const merged = [...assignedSet];
    for (const id of personal) if (!assignedSet.has(id)) merged.push(id);
    return merged;
  }, [isLocked, allIds, assignedSet, personal]);

  const isItemLocked = useCallback(
    (id: string) => {
      if (isLocked) return true;
      return assignedSet ? assignedSet.has(id) : false;
    },
    [isLocked, assignedSet],
  );
  const itemLockedReason = assignedSet
    ? "This platform is part of your assigned scope and cannot be removed"
    : lockedReason;

  const isWatched = useCallback((id: string) => watched.includes(id), [watched]);
  const add = useCallback((id: string) => {
    if (isLocked) return;
    setPersonal((cur) => (cur.includes(id) ? cur : [...cur, id]));
  }, [isLocked]);
  const remove = useCallback((id: string) => {
    if (isLocked) return;
    if (assignedSet && assignedSet.has(id)) return;
    setPersonal((cur) => cur.filter((x) => x !== id));
  }, [isLocked, assignedSet]);
  const toggle = useCallback((id: string): boolean => {
    if (isLocked) return true;
    if (assignedSet && assignedSet.has(id)) return true;
    let next = false;
    setPersonal((cur) => {
      if (cur.includes(id)) { next = false; return cur.filter((x) => x !== id); }
      next = true;
      return [...cur, id];
    });
    return !personal.includes(id);
  }, [isLocked, assignedSet, personal]);

  const value = useMemo(
    () => ({ watched, isWatched, toggle, add, remove, isLocked, lockedReason, isItemLocked, itemLockedReason }),
    [watched, isWatched, toggle, add, remove, isLocked, lockedReason, isItemLocked, itemLockedReason],
  );
  return <WatchlistContext.Provider value={value}>{children}</WatchlistContext.Provider>;
}

export function useWatchlist() {
  const ctx = useContext(WatchlistContext);
  if (!ctx) throw new Error("useWatchlist must be used within WatchlistProvider");
  return ctx;
}
