import { useEffect, useMemo, useState } from "react";
import { useFilters } from "@/contexts/FilterContext";
import {
  launches as ALL_LAUNCHES,
  risks as ALL_RISKS,
  tasks as ALL_TASK_QUEUE,
  milestones as ALL_MILESTONES,
  type Launch,
  type Risk,
  type TaskItem,
  type Milestone,
  type Activity,
  type RAG,
} from "@/mocks/launches";
import { getAllActivity, subscribeActivity } from "@/mocks/activityLog";
import { NUDDS, type NuddRow } from "@/mocks/nudds";
import { phasesForLaunch, type ScheduleTrack } from "@/lib/schedule";
import { mergeImplied, phaseNamesFromFilter, parsePhaseValue, LOB_TO_ORG } from "@/lib/filterCascade";
import { tasksForLaunch, currentPhaseName, platformStatus, functionStatus, type TaskFunction, type TaskStatus } from "@/lib/launchTasks";
import { subscribeLaunchUpdates } from "@/mocks/pendingPlatforms";
import { useWatchlist } from "@/contexts/WatchlistContext";

const ALL_TRACKS: ScheduleTrack[] = ["GOE", "NPI", "SChM"];

/** Names of the per-track current phase for a launch as of `today`. */
function currentPhaseNames(l: Launch, today: Date): string[] {
  const out: string[] = [];
  for (const track of ALL_TRACKS) {
    const phases = phasesForLaunch(l, track);
    const t = today.getTime();
    let idx = -1;
    for (let i = 0; i < phases.length; i++) {
      if (t >= phases[i].start.getTime() && t < phases[i].end.getTime()) { idx = i; break; }
    }
    if (idx === -1) {
      if (phases.length === 0) continue;
      idx = t < phases[0].start.getTime() ? 0 : phases.length - 1;
    }
    out.push(phases[idx].name);
  }
  return out;
}

export type StatusBucket = "achieved" | "risk-mitigated" | "missed";

const arr = (v: unknown): string[] => (Array.isArray(v) ? (v as string[]) : []);

/** All current data is treated as CSG. ISG-only filter collapses to empty. */
export function passesOrganization(orgFilter: string[]): boolean {
  if (orgFilter.length === 0) return true;
  return orgFilter.includes("CSG");
}

export function ragToStatus(rag: RAG): StatusBucket {
  if (rag === "green") return "achieved";
  if (rag === "amber") return "risk-mitigated";
  return "missed";
}

export function platformStatusToBucket(s: TaskStatus): StatusBucket {
  if (s === "at-risk") return "missed";
  if (s === "at-risk-mitigated") return "risk-mitigated";
  // on-track, completed, not-started
  return "achieved";
}

export function severityToStatus(
  s: Risk["severity"],
): StatusBucket {
  if (s === "low") return "achieved";
  if (s === "critical") return "missed";
  return "risk-mitigated";
}

export function milestoneToStatus(s: Milestone["status"]): StatusBucket {
  if (s === "at_risk") return "risk-mitigated";
  return "achieved";
}

export function nuddToStatus(n: NuddRow): StatusBucket {
  const r = n.impact * n.probability;
  if (r <= 2) return "achieved";
  if (r <= 5) return "risk-mitigated";
  return "missed";
}

/** Apply launch-relevant filters. Phase = per-track current phase (any track match). */
function launchPasses(
  l: Launch,
  f: ReturnType<typeof useFilters>["filters"],
  today: Date,
  watchedIds: Set<string> | null,
): boolean {
  // Watchlist scope short-circuits everything else.
  if (f.watchlist === true) {
    if (!watchedIds) return false;
    return watchedIds.has(l.id);
  }
  const org = arr(f.organization);
  const lob = arr(f.lob);
  const platform = arr(f.platform);
  const phase = arr(f.phase);
  const status = arr(f.status);
  const fn = arr(f.function);
  if (org.length && !org.includes(LOB_TO_ORG[l.lob])) return false;
  if (lob.length && !lob.includes(l.lob)) return false;
  if (platform.length && !platform.includes(l.name)) return false;
  if (phase.length) {
    // Phase values may be "Track:Phase" (preferred) or a bare phase name (legacy).
    const pairs = phase.map(parsePhaseValue);
    const cur = currentPhaseNames(l, today);
    const ok = pairs.some(({ fn, phase: p }) => {
      if (fn) {
        const onTrack = currentPhaseName(l, fn as ScheduleTrack);
        return onTrack === p;
      }
      return cur.includes(p);
    });
    if (!ok) return false;
  }
  // Owner is locked on the OLP schedule page — do not narrow launches by owner.
  if (status.length) {
    // If a single function is selected, status filters apply to that function's
    // per-track status; otherwise fall back to overall platform status.
    const bucket =
      fn.length === 1
        ? platformStatusToBucket(functionStatus(l, fn[0] as ScheduleTrack))
        : platformStatusToBucket(platformStatus(l));
    if (!status.includes(bucket)) return false;
  }
  return true;
}

export function useFilteredLaunches(): Launch[] {
  const { filters: raw } = useFilters();
  const { watched } = useWatchlist();
  const [tick, setTick] = useState(0);
  useEffect(() => subscribeLaunchUpdates(() => setTick((n) => n + 1)), []);
  return useMemo(() => {
    const filters = mergeImplied(raw);
    if (filters.watchlist !== true && !passesOrganization(arr(filters.organization))) return [];
    const today = new Date();
    const watchedIds = new Set<string>(watched);
    void tick;
    return ALL_LAUNCHES.filter((l) => launchPasses(l, filters, today, watchedIds));
  }, [raw, tick, watched]);
}


function useLockedNames(): Set<string> | null {
  // Platform scope is no longer hard-locked — visibility is governed by
  // Function/LOB locks (mirrored as filter values). Return null to skip.
  return null;
}

export function useFilteredRisks(): Risk[] {
  const { filters: raw } = useFilters();
  const { watched } = useWatchlist();
  const lockedNames = useLockedNames();
  return useMemo(() => {
    const filters = mergeImplied(raw);
    if (filters.watchlist === true) {
      const watchedNames = new Set(
        ALL_LAUNCHES.filter((l) => watched.includes(l.id)).map((l) => l.name),
      );
      return ALL_RISKS.filter((r) => watchedNames.has(r.launch));
    }
    if (!passesOrganization(arr(filters.organization))) return [];
    const platform = arr(filters.platform);
    const owner = arr(filters.owner);
    const status = arr(filters.status);
    const lob = arr(filters.lob);
    const phase = phaseNamesFromFilter(arr(filters.phase));
    const launchByName = new Map(ALL_LAUNCHES.map((l) => [l.name, l]));
    return ALL_RISKS.filter((r) => {
      if (lockedNames && !lockedNames.has(r.launch)) return false;
      if (platform.length && !platform.includes(r.launch)) return false;
      if (owner.length && !owner.includes(r.owner)) return false;
      if (status.length && !status.includes(severityToStatus(r.severity)))
        return false;
      const l = launchByName.get(r.launch);
      if (lob.length && (!l || !lob.includes(l.lob))) return false;
      if (phase.length && (!l || !phase.includes(l.phase))) return false;
      return true;
    });
  }, [raw, lockedNames, watched]);
}

export function useFilteredNudds(): NuddRow[] {
  const { filters: raw } = useFilters();
  const { watched } = useWatchlist();
  const lockedNames = useLockedNames();
  return useMemo(() => {
    const filters = mergeImplied(raw);
    if (filters.watchlist === true) {
      const watchedNames = new Set(
        ALL_LAUNCHES.filter((l) => watched.includes(l.id)).map((l) => l.name),
      );
      return NUDDS.filter((n) => watchedNames.has(n.platform));
    }
    if (!passesOrganization(arr(filters.organization))) return [];
    const lob = arr(filters.lob);
    const platform = arr(filters.platform);
    const owner = arr(filters.owner);
    const status = arr(filters.status);
    const fn = arr(filters.function) as TaskFunction[];
    const phase = phaseNamesFromFilter(arr(filters.phase));
    const launchByName = new Map(ALL_LAUNCHES.map((l) => [l.name, l]));
    return NUDDS.filter((n) => {
      if (lockedNames && !lockedNames.has(n.platform)) return false;
      if (lob.length && !lob.includes(n.lob)) return false;
      if (platform.length && !platform.includes(n.platform)) return false;
      if (owner.length && !owner.includes(n.people.assignee)) return false;
      if (status.length && !status.includes(nuddToStatus(n))) return false;
      if (fn.length || phase.length) {
        const launch = launchByName.get(n.platform);
        if (!launch) return false;
        const launchTracks = new Set<TaskFunction>();
        for (const t of tasksForLaunch(launch)) for (const team of t.teams) launchTracks.add(team);
        const tracks = (fn.length ? fn.filter((f) => launchTracks.has(f)) : Array.from(launchTracks));
        if (tracks.length === 0) return false;
        if (phase.length) {
          const ok = tracks.some((tr) => {
            const ph = currentPhaseName(launch, tr as ScheduleTrack);
            return ph != null && phase.includes(ph);
          });
          if (!ok) return false;
        }
      }
      return true;
    });
  }, [raw, lockedNames, watched]);
}

export function useFilteredMilestones(): Milestone[] {
  const { filters: raw } = useFilters();
  const launches = useFilteredLaunches();
  return useMemo(() => {
    const ids = new Set(launches.map((l) => l.id));
    const status = arr(raw.status);
    return ALL_MILESTONES.filter((m) => {
      if (!ids.has(m.launchId)) return false;
      if (status.length && !status.includes(milestoneToStatus(m.status)))
        return false;
      return true;
    });
  }, [launches, raw]);
}

export function useFilteredTaskQueue(): TaskItem[] {
  const { filters: raw } = useFilters();
  const { watched } = useWatchlist();
  const lockedNames = useLockedNames();
  return useMemo(() => {
    const filters = mergeImplied(raw);
    if (filters.watchlist === true) {
      const watchedNames = new Set(
        ALL_LAUNCHES.filter((l) => watched.includes(l.id)).map((l) => l.name),
      );
      return ALL_TASK_QUEUE.filter((t) => watchedNames.has(t.launch));
    }
    if (!passesOrganization(arr(filters.organization))) return [];
    const platform = arr(filters.platform);
    const owner = arr(filters.owner);
    const task = arr(filters.task);
    const lob = arr(filters.lob);
    const phase = phaseNamesFromFilter(arr(filters.phase));
    const launchByName = new Map(ALL_LAUNCHES.map((l) => [l.name, l]));
    return ALL_TASK_QUEUE.filter((t) => {
      if (lockedNames && !lockedNames.has(t.launch)) return false;
      if (platform.length && !platform.includes(t.launch)) return false;
      if (owner.length && !owner.includes(t.assignee)) return false;
      if (task.length && !task.includes(t.title)) return false;
      const l = launchByName.get(t.launch);
      if (lob.length && (!l || !lob.includes(l.lob))) return false;
      if (phase.length && (!l || !phase.includes(l.phase))) return false;
      return true;
    });
  }, [raw, lockedNames, watched]);
}

export function useFilteredActivity(): Activity[] {
  const { filters: raw } = useFilters();
  const launches = useFilteredLaunches();
  const [, force] = useState(0);
  useEffect(() => subscribeActivity(() => force((n) => n + 1)), []);
  return useMemo(() => {
    const ids = new Set(launches.map((l) => l.id));
    const owner = arr(raw.owner);
    return getAllActivity().filter((a) => {
      if (!ids.has(a.launchId)) return false;
      if (owner.length && !owner.includes(a.actor)) return false;
      return true;
    });
  }, [launches, raw]);
}
