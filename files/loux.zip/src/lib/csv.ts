// Tiny RFC-4180 CSV writer with browser download helper.

type Row = Record<string, unknown>;

function escapeField(value: unknown): string {
  if (value === null || value === undefined) return "";
  const s = String(value);
  if (/[",\r\n]/.test(s)) {
    return `"${s.replace(/"/g, '""')}"`;
  }
  return s;
}

export function toCsv(rows: Row[], headers?: string[]): string {
  const keys =
    headers ??
    Array.from(
      rows.reduce<Set<string>>((acc, r) => {
        Object.keys(r).forEach((k) => acc.add(k));
        return acc;
      }, new Set())
    );
  const head = keys.map(escapeField).join(",");
  const body = rows
    .map((r) => keys.map((k) => escapeField(r[k])).join(","))
    .join("\r\n");
  return body ? `${head}\r\n${body}` : head;
}

export function downloadCsv(filename: string, rows: Row[], headers?: string[]): void {
  const csv = toCsv(rows, headers);
  const blob = new Blob([`\uFEFF${csv}`], { type: "text/csv;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename.endsWith(".csv") ? filename : `${filename}.csv`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  setTimeout(() => URL.revokeObjectURL(url), 0);
}
