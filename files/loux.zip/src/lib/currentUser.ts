// Lightweight current-user shim for the PoC. Role drives identity since we
// don't have auth wired yet. Replace with real auth context when Cloud lands.
import { useRole, type Role } from "@/contexts/RoleContext";

const NAME_BY_ROLE: Record<Role, string> = {
  superadmin: "Super Admin",
  admin: "Workspace Admin",
  user: "Demo User",
  executive: "Exec Viewer",
};

export function useCurrentUserName(): string {
  const { role } = useRole();
  return NAME_BY_ROLE[role];
}
