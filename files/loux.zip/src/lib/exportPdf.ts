import html2canvas from "html2canvas";
import jsPDF from "jspdf";

export interface ExportPdfOptions {
  title: string;
  filenameSlug: string;
  orientation?: "portrait" | "landscape";
  filterSummary?: string;
  role?: string;
}

function todayStamp(): string {
  const d = new Date();
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

export async function exportElementToPdf(
  el: HTMLElement,
  opts: ExportPdfOptions,
): Promise<void> {
  const { title, filenameSlug, orientation = "landscape", filterSummary, role } = opts;

  // Allow chart animations to settle.
  await new Promise<void>((r) => requestAnimationFrame(() => r()));

  const canvas = await html2canvas(el, {
    scale: 2,
    backgroundColor: "#ffffff",
    useCORS: true,
    logging: false,
    windowWidth: el.scrollWidth,
  });

  const pdf = new jsPDF({ orientation, unit: "pt", format: "letter" });
  const pageW = pdf.internal.pageSize.getWidth();
  const pageH = pdf.internal.pageSize.getHeight();
  const margin = 36;

  // Header
  pdf.setFont("helvetica", "bold");
  pdf.setFontSize(14);
  pdf.setTextColor(14, 14, 14);
  pdf.text(title, margin, margin + 4);

  pdf.setFont("helvetica", "normal");
  pdf.setFontSize(9);
  pdf.setTextColor(110, 110, 110);
  pdf.text("Dell Product Launch Dashboard", pageW - margin, margin + 4, { align: "right" });

  if (filterSummary) {
    pdf.setFontSize(8);
    pdf.setTextColor(120, 120, 120);
    const truncated = filterSummary.length > 180 ? filterSummary.slice(0, 177) + "…" : filterSummary;
    pdf.text(truncated, margin, margin + 18);
  }

  // Image area
  const imgTop = margin + 30;
  const footerH = 24;
  const availW = pageW - margin * 2;
  const availH = pageH - imgTop - footerH - margin;

  const imgRatio = canvas.width / canvas.height;
  let drawW = availW;
  let drawH = drawW / imgRatio;
  if (drawH > availH) {
    drawH = availH;
    drawW = drawH * imgRatio;
  }
  const drawX = margin + (availW - drawW) / 2;
  const drawY = imgTop;

  pdf.addImage(canvas.toDataURL("image/png"), "PNG", drawX, drawY, drawW, drawH, undefined, "FAST");

  // Footer
  const footerY = pageH - margin;
  pdf.setFontSize(8);
  pdf.setTextColor(140, 140, 140);
  const footerLeft = `Generated ${todayStamp()}${role ? ` · Role: ${role}` : ""}`;
  pdf.text(footerLeft, margin, footerY);

  pdf.save(`${filenameSlug}_${todayStamp()}.pdf`);
}
