import { launches } from "@/mocks/launches";
import rawTasks from "@/mocks/olpTasks.json";
import { OWNERS } from "@/mocks/taskDetails";

const OWNER_ROLES: Record<string, string> = Object.fromEntries(
  OWNERS.map((o) => [o.name, o.role]),
);


export const LOB_TO_ORG: Record<string, "CSG" | "ISG"> = {
  DT: "CSG",
  NB: "CSG",
  DnCP: "CSG",
  Server: "ISG",
  Storage: "ISG",
  "S&S": "ISG",
  "Network Eq": "ISG",
};

export const ALL_LOBS = ["DT", "NB", "DnCP", "Server", "Storage", "S&S", "Network Eq"];
export const PHASE_ORDER = [
  "Concept",
  "Define",
  "Plan",
  "Develop",
  "Qual",
  "Pilot",
  "Ramp",
  "Launch",
];

/** Canonical phase set per function (derived from olpTasks.json, stable across mock churn). */
export const PHASES_BY_FUNCTION: Record<"Core" | "GOE" | "NPI" | "SChM", string[]> = {
  Core: ["Concept", "Define", "Plan", "Develop", "Launch"],
  GOE: ["Concept", "Define", "Plan", "Qual", "Pilot"],
  NPI: ["Define", "Plan", "Qual", "Pilot"],
  SChM: ["Define", "Plan", "Develop", "Qual", "Pilot", "Launch"],
};
export const FUNCTION_ORDER: ("Core" | "GOE" | "NPI" | "SChM")[] = ["Core", "GOE", "NPI", "SChM"];

/** Phase filter values are encoded as "Function:Phase" (e.g. "GOE:Concept"). */
export function parsePhaseValue(v: string): { fn: string; phase: string } {
  const i = v.indexOf(":");
  if (i < 0) return { fn: "", phase: v };
  return { fn: v.slice(0, i), phase: v.slice(i + 1) };
}
export function phaseNamesFromFilter(values: string[]): string[] {
  return uniq(values.map((v) => parsePhaseValue(v).phase));
}
export function functionsFromPhaseFilter(values: string[]): string[] {
  return uniq(values.map((v) => parsePhaseValue(v).fn).filter(Boolean));
}

type Filters = Record<string, unknown>;
const arr = (v: unknown): string[] => (Array.isArray(v) ? (v as string[]) : []);
const uniq = <T,>(xs: T[]): T[] => Array.from(new Set(xs));

type TaskDef = {
  task: string;
  lobs: string[];
  phase?: string;
  gate?: string;
  teams?: string[];
};
const TASKS = rawTasks as TaskDef[];

export type Group<T = string> = { title: string; options: { value: T; label: string }[] };

/** Parents implied by current child selections. */
export function impliedParents(f: Filters): {
  organization: string[];
  lob: string[];
  platform: string[];
} {
  const platform = arr(f.platform);
  const lob = arr(f.lob);
  const owner = arr(f.owner);

  const platformsFromOwner = owner.length
    ? launches.filter((l) => owner.includes(l.owner)).map((l) => l.name)
    : [];
  const allPlatforms = new Set([...platform, ...platformsFromOwner]);

  const lobsFromPlatform = launches
    .filter((l) => allPlatforms.has(l.name))
    .map((l) => l.lob as string);
  const allLobs = new Set<string>([...lob, ...lobsFromPlatform]);

  const orgsFromLob = Array.from(allLobs)
    .map((l) => LOB_TO_ORG[l])
    .filter(Boolean);

  return {
    organization: uniq(orgsFromLob),
    lob: uniq(lobsFromPlatform),
    platform: uniq(platformsFromOwner),
  };
}

/** Filters with parent values unioned with implied values (used at read time). */
export function mergeImplied(f: Filters): Filters {
  const imp = impliedParents(f);
  return {
    ...f,
    organization: uniq([...arr(f.organization), ...imp.organization]),
    lob: uniq([...arr(f.lob), ...imp.lob]),
    platform: uniq([...arr(f.platform), ...imp.platform]),
  };
}

export function lockedValues(
  f: Filters,
  kind: "organization" | "lob" | "platform",
): string[] {
  return impliedParents(f)[kind];
}

function passesOrg(lobOfLaunch: string, org: string[]): boolean {
  if (!org.length) return true;
  return org.includes(LOB_TO_ORG[lobOfLaunch]);
}

export function scopedPlatformOptions(f: Filters): string[] {
  const merged = mergeImplied(f);
  const org = arr(merged.organization);
  const lob = arr(merged.lob);
  const phase = phaseNamesFromFilter(arr(f.phase));
  const owner = arr(f.owner);
  const task = arr(f.task);

  let taskLobs: Set<string> | null = null;
  if (task.length) {
    taskLobs = new Set();
    for (const t of TASKS) if (task.includes(t.task)) for (const lo of t.lobs) taskLobs.add(lo);
  }

  return uniq(
    launches
      .filter((l) => {
        if (!passesOrg(l.lob, org)) return false;
        if (lob.length && !lob.includes(l.lob)) return false;
        if (phase.length && !phase.includes(l.phase)) return false;
        if (owner.length && !owner.includes(l.owner)) return false;
        if (taskLobs && !taskLobs.has(l.lob)) return false;
        return true;
      })
      .map((l) => l.name),
  ).sort();
}

export function scopedLobOptions(f: Filters): string[] {
  const org = arr(mergeImplied(f).organization);
  if (!org.length) return ALL_LOBS;
  return ALL_LOBS.filter((l) => org.includes(LOB_TO_ORG[l]));
}

export function scopedOwnerOptions(f: Filters): string[] {
  const merged = mergeImplied(f);
  const org = arr(merged.organization);
  const lob = arr(merged.lob);
  const platform = arr(merged.platform);
  const phase = phaseNamesFromFilter(arr(f.phase));
  return uniq(
    launches
      .filter((l) => {
        if (!passesOrg(l.lob, org)) return false;
        if (lob.length && !lob.includes(l.lob)) return false;
        if (platform.length && !platform.includes(l.name)) return false;
        if (phase.length && !phase.includes(l.phase)) return false;
        return true;
      })
      .map((l) => l.owner),
  ).sort();
}

export function scopedPhaseOptions(f: Filters): string[] {
  const merged = mergeImplied(f);
  const org = arr(merged.organization);
  const lob = arr(merged.lob);
  const platform = arr(merged.platform);
  const owner = arr(f.owner);
  const seen = new Set(
    launches
      .filter((l) => {
        if (!passesOrg(l.lob, org)) return false;
        if (lob.length && !lob.includes(l.lob)) return false;
        if (platform.length && !platform.includes(l.name)) return false;
        if (owner.length && !owner.includes(l.owner)) return false;
        return true;
      })
      .map((l) => l.phase as string),
  );
  return PHASE_ORDER.filter((p) => seen.has(p));
}

export function scopedTaskOptions(f: Filters): string[] {
  const lob = arr(mergeImplied(f).lob);
  const filtered = lob.length
    ? TASKS.filter((t) => t.lobs.some((l) => lob.includes(l)))
    : TASKS;
  return uniq(filtered.map((t) => t.task)).sort();
}

// ----- Grouped variants (presentation only, no scoping changes) -----

const toOpts = (vs: string[]) => vs.map((v) => ({ value: v, label: v }));

/** LOB options grouped by Business Unit (CSG / ISG). */
export function groupedLobOptions(f: Filters): Group[] {
  const flat = scopedLobOptions(f);
  const byOrg: Record<string, string[]> = { CSG: [], ISG: [] };
  for (const l of flat) {
    const org = LOB_TO_ORG[l];
    if (org) byOrg[org].push(l);
  }
  return (["CSG", "ISG"] as const)
    .filter((o) => byOrg[o].length)
    .map((o) => ({ title: o, options: toOpts(byOrg[o].sort()) }));
}

/** Platform options grouped by LOB. */
export function groupedPlatformOptions(f: Filters): Group[] {
  const allowed = new Set(scopedPlatformOptions(f));
  const byLob = new Map<string, string[]>();
  for (const l of launches) {
    if (!allowed.has(l.name)) continue;
    const arr = byLob.get(l.lob) ?? [];
    arr.push(l.name);
    byLob.set(l.lob, arr);
  }
  return Array.from(byLob.entries())
    .sort(([a], [b]) => a.localeCompare(b))
    .map(([lob, names]) => ({
      title: lob,
      options: toOpts(uniq(names).sort()),
    }));
}

/** Owner options grouped by function (Core/GOE/NPI/SChM), with an Other bucket for PG owners without a function role. */
export function groupedOwnerOptions(f: Filters): Group[] {
  const allowed = new Set(scopedOwnerOptions(f));
  const byFn = new Map<string, Set<string>>();
  const FN_KEYS: Record<string, ("Core" | "GOE" | "NPI" | "SChM")> = {
    Core: "Core", GOE: "GOE", NPI: "NPI", SChM: "SChM", SCHM: "SChM", "SCHEDULE": "SChM",
  };
  const inferFn = (name: string): ("Core" | "GOE" | "NPI" | "SChM" | "Other") => {
    const o = OWNER_ROLES[name];
    if (!o) return "Other";
    const upper = o.toUpperCase();
    if (upper.includes("GOE")) return "GOE";
    if (upper.includes("NPI")) return "NPI";
    if (upper.includes("SCHEDULE") || upper.includes("SCHM")) return "SChM";
    if (upper.includes("CORE")) return "Core";
    return "Other";
  };
  for (const name of allowed) {
    const fn = inferFn(name);
    const set = byFn.get(fn) ?? new Set<string>();
    set.add(name);
    byFn.set(fn, set);
  }
  const order: string[] = [...FUNCTION_ORDER, "Other"];
  const label = (fn: string) => (fn === "SChM" ? "SChM" : fn === "Core" ? "Core team" : fn === "Other" ? "Program governance" : fn);
  return order
    .filter((fn) => byFn.has(fn))
    .map((fn) => ({
      title: label(fn),
      options: toOpts(Array.from(byFn.get(fn) ?? []).sort()),
    }));
}


/** Phase options grouped by function (canonical list, independent of current launches). */
export function groupedPhaseOptions(_f: Filters): Group[] {
  return FUNCTION_ORDER.map((fn) => ({
    title: fn === "SChM" ? "SChM" : fn === "Core" ? "Core team" : fn,
    options: PHASES_BY_FUNCTION[fn].map((p) => ({
      value: `${fn}:${p}`,
      label: p,
    })),
  }));
}

/** Task options grouped by "Phase: Gate (L2 exit criteria)". */
export function groupedTaskOptions(f: Filters): Group[] {
  const lob = arr(mergeImplied(f).lob);
  const filtered = lob.length
    ? TASKS.filter((t) => t.lobs.some((l) => lob.includes(l)))
    : TASKS;
  // group key -> set of task names (dedupe)
  const groups = new Map<string, Set<string>>();
  for (const t of filtered) {
    const phase = t.phase ?? "Other";
    const gate = t.gate ?? "—";
    const key = `${phase}: ${gate}`;
    const set = groups.get(key) ?? new Set<string>();
    set.add(t.task);
    groups.set(key, set);
  }
  // sort by phase order then gate text
  const phaseRank = (k: string) => {
    const p = k.split(":")[0].trim();
    const i = PHASE_ORDER.indexOf(p);
    return i === -1 ? PHASE_ORDER.length : i;
  };
  return Array.from(groups.entries())
    .sort(([a], [b]) => {
      const pa = phaseRank(a);
      const pb = phaseRank(b);
      if (pa !== pb) return pa - pb;
      return a.localeCompare(b);
    })
    .map(([title, tasks]) => ({
      title,
      options: toOpts(Array.from(tasks).sort()),
    }));
}
