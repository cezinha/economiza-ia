export interface KeyMilestone {
  key: string;
  label: string;
  fullName: string;
  offsetDays: number;
  isPhaseExit?: boolean;
}

// Key milestones — union across GOE/NPI/SChM, anchored to launch RTS date.
export const KEY_MILESTONES: KeyMilestone[] = [
  { key: "CPE",   label: "CPE",  fullName: "Concept Phase Exit",                  offsetDays: -270, isPhaseExit: true },
  { key: "DPE",   label: "DPE",  fullName: "Define Phase Exit",                   offsetDays: -210, isPhaseExit: true },
  { key: "BA",    label: "BA",   fullName: "Business Approval",                   offsetDays: -180 },
  { key: "PPE-1", label: "PPE",  fullName: "Plan Phase Exit",                     offsetDays: -150, isPhaseExit: true },
  { key: "EVT",   label: "EVT",  fullName: "Engineering Validation Test",         offsetDays: -135 },
  { key: "DVT1",  label: "DVT1", fullName: "Design Validation Test 1",            offsetDays: -120 },
  { key: "DVT2",  label: "DVT2", fullName: "Design Validation Test 2",            offsetDays: -105 },
  { key: "QPE",   label: "QPE",  fullName: "Qualify Phase Exit",                  offsetDays:  -90, isPhaseExit: true },
  { key: "PPx",   label: "PPx",  fullName: "Pre-Production Engineering",          offsetDays:  -75 },
  { key: "PV2",   label: "PV2",  fullName: "Production Validation Test 2",        offsetDays:  -60 },
  { key: "QBLD",  label: "QBLD", fullName: "Qual Build",                          offsetDays:  -45 },
  { key: "PPE-2", label: "PPE",  fullName: "Pilot Phase Exit / Launch Readiness", offsetDays:  -30, isPhaseExit: true },
  { key: "RTO",   label: "RTO",  fullName: "Ready To Order",                      offsetDays:   15 },
  { key: "RTS",   label: "RTS",  fullName: "Ready To Ship",                       offsetDays:   30 },
];

export function milestoneDate(launchIso: string, offsetDays: number): Date {
  const d = new Date(launchIso + "T00:00:00Z");
  d.setUTCDate(d.getUTCDate() + offsetDays);
  return d;
}

/** Map a gate code (e.g. "DPE", "DVT1") to its offsetDays from RTS, or null. */
export function gateOffsetDays(gateCode: string): number | null {
  const m = KEY_MILESTONES.find((k) => k.label === gateCode || k.key === gateCode);
  return m ? m.offsetDays : null;
}
