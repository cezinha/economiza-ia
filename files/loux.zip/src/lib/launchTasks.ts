import type { Launch } from "@/mocks/launches";
import rawTasks from "@/mocks/olpTasks.json";
import { phasesForLaunch, pctBetween, type ScheduleTrack } from "@/lib/schedule";
import { launchOverrides } from "@/mocks/taskOverrides";
import { gateOffsetDays, milestoneDate } from "@/lib/keyMilestones";
import { effectiveLaunchDate } from "@/mocks/launchDateOverrides";
import { coreTeamOwnStatus } from "@/mocks/coreTeamStatus";
import { approvedStatusForTask } from "@/mocks/statusChangeRequests";
import { isTaskCompleted } from "@/mocks/completionRequests";
import { predecessorIdsFor } from "@/lib/taskPredecessors";


export type TaskStatus =
  | "completed"
  | "on-track"
  | "at-risk-mitigated"
  | "at-risk"
  | "not-started";


export type TaskFunction = "GOE" | "NPI" | "SChM";
export type LineOfBusiness = "NB" | "DT" | "DnCP";

export interface OlpTaskDef {
  l3Id: number | null;
  phase: string;
  gate: string;
  task: string;
  teams: TaskFunction[];
  lobs: LineOfBusiness[];
  required: "Required" | "Optional" | null;
  taskEnd: string;
}

export interface LaunchTask extends OlpTaskDef {
  id: string;
  launchId: string;
}

const TASK_DEFS = rawTasks as OlpTaskDef[];

// ---- Phase-exit close synthetic tasks --------------------------------------

/** Anchor gate code (from KEY_MILESTONES) per phase used for the close task. */
const PHASE_CLOSE_ANCHOR: Record<string, string> = {
  Concept: "CPE",
  Define: "DPE",
  Plan: "PPE",
  Develop: "PPE",
  Qual: "QPE",
  Pilot: "PPE-2",
  Launch: "RTS",
};

export const PHASE_CLOSE_TASK_END_PREFIX = "PHASE_CLOSE:";

export function isPhaseCloseTask(task: { gate?: string; taskEnd?: string }): boolean {
  const g = task.gate ?? "";
  return (
    g.startsWith("Confirm ") ||
    g.startsWith("Close ") || // legacy
    (task.taskEnd ?? "").startsWith(PHASE_CLOSE_TASK_END_PREFIX)
  );
}


export function phaseCloseAnchorKey(phase: string): string | null {
  return PHASE_CLOSE_ANCHOR[phase] ?? null;
}

function buildPhaseCloseTasks(launch: Launch, base: LaunchTask[]): LaunchTask[] {
  const lob = launch.lob as LineOfBusiness;
  const seen = new Set<string>();
  const out: LaunchTask[] = [];
  for (const t of base) {
    if (!PHASE_CLOSE_ANCHOR[t.phase]) continue;
    for (const fn of t.teams) {
      const key = `${t.phase}|${fn}`;
      if (seen.has(key)) continue;
      seen.add(key);
      out.push({
        l3Id: null,
        phase: t.phase,
        gate: `Confirm ${t.phase} exit`,
        task: `Approve ${t.phase} exit (admin-only)`,
        teams: [fn],
        lobs: [lob],
        required: "Required",
        taskEnd: `${PHASE_CLOSE_TASK_END_PREFIX}${t.phase}`,
        launchId: launch.id,
        id: `${launch.id}-close-${t.phase}-${fn}`,
      });

    }
  }
  return out;
}

export function tasksForLaunch(launch: Launch): LaunchTask[] {
  const lob = launch.lob as LineOfBusiness;
  const base: LaunchTask[] = TASK_DEFS
    .filter((t) => t.lobs.includes(lob))
    .map((t, i) => ({
      ...t,
      launchId: launch.id,
      id: `${launch.id}-${t.l3Id ?? i}-${t.teams.join("_")}`,
    }));
  const closes = buildPhaseCloseTasks(launch, base);
  return [...base, ...closes];
}




/** True when `launch` participates in the given function/track. */
export function launchHasFunction(launch: Launch, fn: TaskFunction): boolean {
  for (const t of tasksForLaunch(launch)) if (t.teams.includes(fn)) return true;
  return false;
}

/** All functions a launch participates in, in canonical order. */
export function launchFunctions(launch: Launch): TaskFunction[] {
  const order: TaskFunction[] = ["GOE", "NPI", "SChM"];
  const set = new Set<TaskFunction>();
  for (const t of tasksForLaunch(launch)) for (const team of t.teams) set.add(team);
  return order.filter((f) => set.has(f));
}

// ---- Sorting / grouping ----

const PHASE_ORDER = ["Concept", "Define", "Plan", "Develop", "Qual", "Pilot", "Ramp", "Launch"];
const GATE_RANKS: { match: RegExp; rank: number }[] = [
  { match: /\bCPE\b/i, rank: 1 },
  { match: /\bDPE\b/i, rank: 2 },
  { match: /\bDev\s*PE\b/i, rank: 3 },
  { match: /\bPPE\b/i, rank: 4 },
  { match: /\bDVT2\b/i, rank: 5 },
  { match: /Pilot\s*Start/i, rank: 6 },
  { match: /\bRPE\b/i, rank: 7 },
  { match: /\bFRC\b/i, rank: 8 },
];

export function taskEndOrder(task: { taskEnd: string }): [number, number] {
  const s = (task.taskEnd ?? "").trim();
  if (!s) return [99, Number.POSITIVE_INFINITY];
  if (s.startsWith(PHASE_CLOSE_TASK_END_PREFIX)) {
    return [999, Number.POSITIVE_INFINITY];
  }
  const gate = GATE_RANKS.find((g) => g.match.test(s));
  const gateRank = gate ? gate.rank : 50;
  // Parse "- N days" or "+ N days" (case-insensitive). No match → offset 0.
  const m = s.match(/([+\-])\s*(\d+)\s*day/i);
  let offset = 0;
  if (m) {
    const sign = m[1] === "-" ? -1 : 1;
    offset = sign * parseInt(m[2], 10);
  }
  return [gateRank, offset];
}

function compareTaskEnd(a: { taskEnd: string }, b: { taskEnd: string }): number {
  const [ag, ao] = taskEndOrder(a);
  const [bg, bo] = taskEndOrder(b);
  if (ag !== bg) return ag - bg;
  return ao - bo; // most-negative first → earliest
}

export interface GateGroup {
  gate: string;
  tasks: LaunchTask[];
}
export interface PhaseGroup {
  phase: string;
  totalTasks: number;
  gates: GateGroup[];
}

export function groupTasksByPhaseAndGate(tasks: LaunchTask[]): PhaseGroup[] {
  const byPhase = new Map<string, Map<string, LaunchTask[]>>();
  for (const t of tasks) {
    const phase = t.phase || "Other";
    const gate = t.gate || "—";
    if (!byPhase.has(phase)) byPhase.set(phase, new Map());
    const gates = byPhase.get(phase)!;
    if (!gates.has(gate)) gates.set(gate, []);
    gates.get(gate)!.push(t);
  }
  const phases = Array.from(byPhase.keys()).sort((a, b) => {
    const ai = PHASE_ORDER.indexOf(a);
    const bi = PHASE_ORDER.indexOf(b);
    return (ai === -1 ? 99 : ai) - (bi === -1 ? 99 : bi);
  });
  return phases.map((phase) => {
    const gatesMap = byPhase.get(phase)!;
    const gates: GateGroup[] = Array.from(gatesMap.entries()).map(([gate, ts]) => ({
      gate,
      tasks: [...ts].sort(compareTaskEnd),
    }));
    const totalTasks = gates.reduce((n, g) => n + g.tasks.length, 0);
    return { phase, totalTasks, gates };
  });
}


// ---- Status rollup ---------------------------------------------------------

/** Returns the name of the current phase for a launch's track based on today. */
export function currentPhaseName(launch: Launch, track: ScheduleTrack, today: Date = new Date()): string | null {
  const phases = phasesForLaunch(launch, track);
  if (phases.length === 0) return null;
  const t = today.getTime();
  for (const p of phases) {
    if (t >= p.start.getTime() && t < p.end.getTime()) return p.name;
  }
  // Before first → first; after last → last.
  if (t < phases[0].start.getTime()) return phases[0].name;
  return phases[phases.length - 1].name;
}

const ACTIVE_RANK: Record<TaskStatus, number> = {
  "at-risk": 4,
  "at-risk-mitigated": 3,
  "on-track": 2,
  "not-started": 1,
  completed: 0,
};

/** Worst (R > Y > G) within active-phase rollups. Falls back to the first if all equal. */
export function worstActive(statuses: TaskStatus[]): TaskStatus {
  if (statuses.length === 0) return "on-track";
  return statuses.reduce((acc, s) => (ACTIVE_RANK[s] > ACTIVE_RANK[acc] ? s : acc));
}

/**
 * Unified phase rank that interleaves both tracks chronologically by their
 * relative day offsets to launchDate. Used to decide whether a task's phase is
 * before / equal / after the current phase regardless of which track owns it.
 *   GOE/NPI: Concept · Define · Plan · Qual    · Pilot  · Ramp
 *   SChM:    Concept · Define · Plan · Develop · Launch
 */
const PHASE_RANK: Record<string, number> = {
  Concept: 0,
  Define: 1,
  Plan: 2,
  Develop: 3,
  Qual: 3,
  Pilot: 4,
  Launch: 4,
  Ramp: 5,
};

function rankOf(phase: string): number {
  return PHASE_RANK[phase] ?? 0;
}

/**
 * Per-task status. Past phase tasks → completed; future → not-started; current
 * phase tasks default to on-track unless an override flips the *first*
 * current-phase task on that track to R/Y.
 */
export function taskStatus(
  launch: Launch,
  task: LaunchTask,
  track: ScheduleTrack,
  today: Date = new Date(),
  visited?: Set<string>,
): TaskStatus {
  // 1. Approved completion request — task is done.
  if (isTaskCompleted(task.id)) return "completed";

  // Auto tasks NEVER take R/Y/G. They auto-complete only when their phase is
  // active AND every predecessor task has resolved to `completed`. Otherwise
  // they sit as `not-started` (future) or `completed` (past).
  if (isAutoTask(task)) {
    const currentName = currentPhaseName(launch, track, today);
    if (!currentName) return "not-started";
    const cur = rankOf(currentName);
    const tp = rankOf(task.phase);
    if (tp < cur) return "completed";
    if (tp > cur) return "not-started";
    return autoPredecessorsReady(launch, task, today, visited) ? "completed" : "not-started";
  }

  // 2. Approved status-change request (per-task R/Y/G) — highest priority.
  const approved = approvedStatusForTask(task.id);
  if (approved) return approved;

  const currentName = currentPhaseName(launch, track, today);
  if (!currentName) return "on-track";
  const cur = rankOf(currentName);
  const tp = rankOf(task.phase);

  // 3. Past phases keep the seeded "completed" rendering for visual continuity.
  if (tp < cur) return "completed";

  // 4. Future phases — phase has not started yet → gray.
  if (tp > cur) return "not-started";

  // 5. Legacy track-level seeded overrides (only when no per-task approved
  //    request exists). Preserves the demo's RYG story for the seeded mock
  //    launches until the seed gets fully migrated to per-task requests.
  const overrides = launchOverrides[launch.id] ?? [];
  const ov = overrides.find((o) => o.track === track);
  if (ov) {
    const firstId = firstCurrentPhaseTaskId(launch, track, currentName);
    if (firstId === task.id) return ov.status;
  }

  // 6. Default — current-phase task with no escalation → on track (green).
  return "on-track";
}

// ---- Auto predecessor lookup ----------------------------------------------

interface AutoLookup {
  byL3: Map<number, LaunchTask[]>;
}
const autoLookupCache = new Map<string, AutoLookup>();

function getAutoLookup(launch: Launch): AutoLookup {
  const cached = autoLookupCache.get(launch.id);
  if (cached) return cached;
  const byL3 = new Map<number, LaunchTask[]>();
  for (const t of tasksForLaunch(launch)) {
    if (t.l3Id == null) continue;
    const arr = byL3.get(t.l3Id);
    if (arr) arr.push(t);
    else byL3.set(t.l3Id, [t]);
  }
  const lookup: AutoLookup = { byL3 };
  autoLookupCache.set(launch.id, lookup);
  return lookup;
}

function autoPredecessorsReady(
  launch: Launch,
  task: LaunchTask,
  today: Date,
  visitedIn?: Set<string>,
): boolean {
  const lob = launch.lob as LineOfBusiness;
  const ids = predecessorIdsFor(task, lob);
  if (ids.length === 0) return true;
  const visited = visitedIn ?? new Set<string>();
  if (visited.has(task.id)) return true; // cycle guard
  visited.add(task.id);
  const { byL3 } = getAutoLookup(launch);
  for (const id of ids) {
    const candidates = byL3.get(id);
    if (!candidates || candidates.length === 0) continue;
    const pred = candidates.find((c) => c.phase === task.phase) ?? candidates[0];
    if (pred.id === task.id) continue;
    const status = worstActive(
      pred.teams.map((tm) => taskStatus(launch, pred, tm, today, visited)),
    );
    if (status !== "completed") return false;
  }
  return true;
}


// ---- Automation ----

const AUTO_KEYWORDS =
  /^\s*(Upload|Sync|Refresh|Generate|Publish|Distribute|Notify|Archive|Lock|Pull|Send|Post|Draft|Review|Finalize)\b/i;

function autoHash(s: string): number {
  let h = 0;
  for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) >>> 0;
  return h;
}

/**
 * Deterministic ~25% of catalog tasks are flagged as automatable. Auto tasks
 * have no human owner and complete automatically when their phase starts.
 */
export function isAutoTask(task: { l3Id: number | null; task: string; teams: TaskFunction[] }): boolean {
  const key = `${task.l3Id ?? "x"}::${task.task}::${task.teams.join(",")}`;
  const h = autoHash(key);
  if (AUTO_KEYWORDS.test(task.task)) return h % 2 === 0;
  return h % 8 === 0;
}

/** Memoize: first task id (in catalog order) belonging to the current phase + track. */
const firstCurrentCache = new Map<string, string | null>();
function firstCurrentPhaseTaskId(launch: Launch, track: ScheduleTrack, currentName: string): string | null {
  const key = `${launch.id}::${track}::${currentName}`;
  if (firstCurrentCache.has(key)) return firstCurrentCache.get(key)!;
  const tf: TaskFunction = track === "Core" ? "SChM" : track;
  const tasks = tasksForLaunch(launch).filter((t) => t.teams.includes(tf) && t.phase === currentName);
  const id = tasks[0]?.id ?? null;
  firstCurrentCache.set(key, id);
  return id;
}

/** Gate status = worst of its tasks (in active-phase context). */
export function gateStatus(tasks: LaunchTask[], launch: Launch, track: ScheduleTrack): TaskStatus {
  if (tasks.length === 0) return "not-started";
  const statuses = tasks.map((t) => taskStatus(launch, t, track));
  // If everything is completed → completed; everything not-started → not-started.
  if (statuses.every((s) => s === "completed")) return "completed";
  if (statuses.every((s) => s === "not-started")) return "not-started";
  // Active context: ignore completed/not-started when computing worst active.
  const active = statuses.filter((s) => s !== "completed" && s !== "not-started");
  return active.length > 0 ? worstActive(active) : "on-track";
}

/** Function (track) status = status of its current phase = worst of its current-phase gates. */
export function functionStatus(launch: Launch, track: ScheduleTrack): TaskStatus {
  // NPI mirrors GOE at the function level (extended-team rule).
  if (track === "NPI") return functionStatus(launch, "GOE");
  if (track === "Core") {
    // Core team status is independent of GOE/NPI/SChM — it reflects only the
    // Core team's own per-platform signal (defaults to on-track).
    return coreTeamOwnStatus(launch.id).status;
  }
  const tf: TaskFunction = track;
  const currentName = currentPhaseName(launch, track);
  if (!currentName) return "on-track";
  const tasks = tasksForLaunch(launch).filter(
    (t) => t.teams.includes(tf) && t.phase === currentName,
  );
  // Group by gate, roll up gates, then worst-of-gates.
  const gateMap = new Map<string, LaunchTask[]>();
  for (const t of tasks) {
    const g = t.gate || "—";
    if (!gateMap.has(g)) gateMap.set(g, []);
    gateMap.get(g)!.push(t);
  }
  const gateStatuses = Array.from(gateMap.values()).map((g) => gateStatus(g, launch, track));
  if (gateStatuses.length === 0) return "on-track";
  const active = gateStatuses.filter((s) => s !== "completed" && s !== "not-started");
  return active.length > 0 ? worstActive(active) : "on-track";
}

/** Platform status = worst of Core, GOE, NPI, SChM function statuses. */
export function platformStatus(launch: Launch): TaskStatus {
  const tracks: ScheduleTrack[] = ["Core", "GOE", "NPI", "SChM"];
  const statuses = tracks.map((t) => functionStatus(launch, t));
  const active = statuses.filter((s) => s !== "completed" && s !== "not-started");
  return active.length > 0 ? worstActive(active) : "on-track";
}


/**
 * Estimated end date of a task, in absolute calendar time. Parses the gate code
 * (CPE/DPE/PPE/EVT/DVT1/DVT2/QPE/PPx/PV2/QBLD/RTO/RTS) plus an optional
 * "± N (days|weeks)" offset out of the freeform `taskEnd` string.
 */
export function estimatedTaskEndDate(launch: Launch, task: LaunchTask): Date | null {
  const s = (task.taskEnd ?? "").trim();
  if (!s) return null;
  const codes = ["CPE","DPE","DevPE","PPE","EVT","DVT1","DVT2","QPE","PPx","PV2","QBLD","RTO","RTS"];
  let gate: string | null = null;
  for (const c of codes) {
    const re = new RegExp(`\\b${c}\\b`, "i");
    if (re.test(s)) { gate = c.toUpperCase() === "DEVPE" ? "PPE" : c; break; }
  }
  if (!gate) return null;
  const baseOffset = gateOffsetDays(gate);
  if (baseOffset === null) return null;
  const m = s.match(/([+\-])\s*(\d+)\s*(day|week|wk)/i);
  let extra = 0;
  if (m) {
    const sign = m[1] === "-" ? -1 : 1;
    const n = parseInt(m[2], 10);
    const mult = /week|wk/i.test(m[3]) ? 7 : 1;
    extra = sign * n * mult;
  }
  return milestoneDate(effectiveLaunchDate(launch), baseOffset + extra);
}

/**
 * Mock completion % for a (launch, track, phase). Counts tasks whose estimated
 * end date is on or before today over total tasks in that phase+track. When
 * none are parseable, falls back to elapsed time within the phase span.
 */
export function phaseCompletionPct(
  launch: Launch,
  track: ScheduleTrack,
  phaseName: string,
  today: Date = new Date(),
): number {
  const tf: TaskFunction = track === "Core" ? "SChM" : track;
  const tasks = tasksForLaunch(launch).filter(
    (t) => t.teams.includes(tf) && t.phase === phaseName,
  );
  let total = 0;
  let done = 0;
  for (const t of tasks) {
    const end = estimatedTaskEndDate(launch, t);
    if (!end) continue;
    total++;
    if (end.getTime() <= today.getTime()) done++;
  }
  let pct: number;
  if (total > 0) {
    pct = (done / total) * 100;
  } else {
    const phases = phasesForLaunch(launch, track);
    const span = phases.find((p) => p.name === phaseName);
    pct = span ? pctBetween(today, span.start, span.end) : 0;
  }
  return Math.max(0, Math.min(100, Math.round(pct)));
}
