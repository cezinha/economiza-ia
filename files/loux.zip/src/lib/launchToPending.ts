import type { Launch } from "@/mocks/launches";
import type { PendingPlatform } from "@/mocks/pendingPlatforms";

/** Adapt a Launch into the PendingPlatform shape the review drawer expects. */
export function launchToPending(l: Launch): PendingPlatform {
  return {
    id: l.id,
    jiraKey: `OLP-${l.id.toUpperCase()}`,
    name: l.name,
    product: l.product,
    businessUnit: l.lob === "DnCP" ? "ISG" : "CSG",
    lob: l.lob,
    function: "GOE",
    region: l.region,
    proposedOwner: l.owner,
    proposedLaunchDate: l.launchDate,
    requestedBy: "Jira",
    requestedAt: Date.now(),
    status: "approved",
    source: "jira",
  };
}
