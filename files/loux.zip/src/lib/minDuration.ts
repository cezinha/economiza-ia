// Per-task minimum recommended duration in calendar days.
// Source priority: user override → phase default. Historical-baseline source is
// stubbed for the PoC (no completed-program data wired yet).

import { isAutoTask, type LaunchTask } from "@/lib/launchTasks";
import type { Launch } from "@/mocks/launches";
import { getMinDurationOverride } from "@/mocks/minDurationOverrides";
import { effectiveLaunchDate } from "@/mocks/launchDateOverrides";
import { resolveDueDateIso } from "@/mocks/taskDetails";

export type MinDurationSource = "User-set" | "Historical" | "Default";

export interface MinDurationInfo {
  days: number;
  source: MinDurationSource;
  sampleSize?: number;
}

// Deterministic 32-bit hash → stable per task.id across renders/sessions.
function hashTaskId(id: string): number {
  let h = 2166136261 >>> 0;
  for (let i = 0; i < id.length; i++) {
    h ^= id.charCodeAt(i);
    h = Math.imul(h, 16777619) >>> 0;
  }
  return h;
}

/** Default min duration: 0d for auto tasks, otherwise a stable 1–20d per task. */
function defaultMinDays(task: LaunchTask): number {
  if (isAutoTask(task)) return 0;
  return (hashTaskId(task.id) % 20) + 1;
}

export function getMinDuration(task: LaunchTask): MinDurationInfo {
  const ov = getMinDurationOverride(task.id);
  if (ov) return { days: ov.days, source: "User-set" };
  return { days: defaultMinDays(task), source: "Default" };
}


/** Calendar-day runway between today and the task's effective due date. */
export function runwayDays(launch: Launch, task: LaunchTask, today: Date = new Date()): number {
  const dueIso = resolveDueDateIso(launch, task);
  const due = new Date(dueIso + "T00:00:00Z");
  const t = Date.UTC(today.getUTCFullYear(), today.getUTCMonth(), today.getUTCDate());
  return Math.round((due.getTime() - t) / 86_400_000);
}

export type RunwaySeverity = "ok" | "warn" | "danger";

export function runwaySeverity(runway: number, min: number): RunwaySeverity {
  if (runway < 0 || runway < min * 0.5) return "danger";
  if (runway < min) return "warn";
  return "ok";
}

/** Per-task default min duration (excludes user overrides). */
export function taskDefaultMin(task: LaunchTask): number {
  return defaultMinDays(task);
}

export { effectiveLaunchDate };
