import { launches as LAUNCHES, type Launch } from "@/mocks/launches";
import { phasesForLaunch } from "@/lib/schedule";
import {
  POC_TODAY,
  addDays,
  minDate,
  maxDate,
  toISODate,
  toDrawerDate,
} from "@/lib/pocToday";

// Re-export so existing imports from `@/lib/nuddDates` keep working.
export { POC_TODAY, addDays, minDate, maxDate, toISODate, toDrawerDate };


function findLaunch(platformName: string): Launch | undefined {
  return LAUNCHES.find((l) => l.name === platformName);
}

/** Develop phase exit per SChM track = launchDate − 90 days. */
export function developExitDate(platformName: string): Date {
  const launch = findLaunch(platformName);
  if (!launch) throw new Error(`No launch for platform ${platformName}`);
  const spans = phasesForLaunch(launch, "SChM");
  const develop = spans.find((s) => s.name === "Develop");
  if (!develop) throw new Error(`No Develop span for ${platformName}`);
  return develop.end;
}

/** GOE OLP phase span for a platform + programPhase. */
export function goePhaseSpan(
  platformName: string,
  phase: string,
): { start: Date; end: Date } {
  const launch = findLaunch(platformName);
  if (!launch) throw new Error(`No launch for platform ${platformName}`);
  const spans = phasesForLaunch(launch, "GOE");
  const match = spans.find((s) => s.name === phase);
  if (!match) {
    throw new Error(`Phase ${phase} not found in GOE track for ${platformName}`);
  }
  return { start: match.start, end: match.end };
}


export type NuddDateInputs = {
  platform: string;
  programPhase: string;
  status: "Open" | "On hold" | "Completed";
  /** Used to deterministically pick a time-of-day for drawer strings. */
  seed: string;
};

export type NuddDateOutputs = {
  createdISO: string;
  updatedISO: string;
  closeISO: string;
  createdDrawer: string;
  updatedDrawer: string;
};

function seedNum(seed: string): number {
  let h = 0;
  for (let i = 0; i < seed.length; i++) h = (h * 31 + seed.charCodeAt(i)) >>> 0;
  return h;
}

export function computeNuddDates(input: NuddDateInputs): NuddDateOutputs {
  const developExit = developExitDate(input.platform);
  const phase = goePhaseSpan(input.platform, input.programPhase);

  // closeDate: before Develop exit, anchored relative to today.
  const closeUpperFromDevelop = addDays(developExit, -7);
  const closeUpperByStatus =
    input.status === "Completed" ? addDays(POC_TODAY, -7) : addDays(POC_TODAY, 60);
  const close = minDate(closeUpperFromDevelop, closeUpperByStatus);

  // updated: before close, not after today.
  const updated = minDate(addDays(close, -3), POC_TODAY);

  // created: inside GOE phase span AND before updated. Take the latest valid date.
  const createdTarget = addDays(updated, -7);
  const created = maxDate(phase.start, minDate(phase.end, createdTarget));

  if (created.getTime() >= updated.getTime()) {
    throw new Error(
      `Cannot satisfy created<updated for ${input.seed} (phase ${input.programPhase} on ${input.platform})`,
    );
  }

  const s = seedNum(input.seed);
  const createdHour = 8 + (s % 9); // 8..16
  const createdMinute = (s >> 3) % 60;
  const updatedHour = 13 + ((s >> 5) % 7); // 13..19
  const updatedMinute = (s >> 7) % 60;

  return {
    createdISO: toISODate(created),
    updatedISO: toISODate(updated),
    closeISO: toISODate(close),
    createdDrawer: toDrawerDate(created, createdHour, createdMinute),
    updatedDrawer: toDrawerDate(updated, updatedHour, updatedMinute),
  };
}
