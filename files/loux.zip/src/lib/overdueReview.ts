import type { LaunchTask } from "@/lib/launchTasks";
import type { Launch } from "@/mocks/launches";
import {
  ensureEscalation,
  getConfirmation,
  getEscalation,
  REVIEW_WINDOW_MS,
  type OverdueConfirmation,
  type OverdueEscalation,
} from "@/mocks/overdueConfirmations";

export interface OverdueState {
  isOverdue: boolean;
  overdueSince: number;
  overdueDays: number;
  confirmation?: OverdueConfirmation;
  escalation?: OverdueEscalation;
  /** ms until auto-escalation. undefined when already confirmed or escalated. */
  msUntilEscalation?: number;
}

/**
 * Derive overdue review state from the task's runway (negative = overdue).
 * `overdueSince` is synthesized from runway days so the 72h countdown reflects
 * how long the task has been overdue.
 */
export function getOverdueState(
  task: LaunchTask,
  launch: Launch,
  runwayDays: number,
): OverdueState | undefined {
  if (runwayDays >= 0) return undefined;
  const overdueDays = Math.abs(runwayDays);
  const overdueSince = Date.now() - overdueDays * 86_400_000;
  const confirmation = getConfirmation(task.id);
  let escalation = getEscalation(task.id);
  if (!confirmation && !escalation) {
    escalation = ensureEscalation(task.id, task.task, launch.id, overdueSince);
  }
  const msUntilEscalation = confirmation || escalation
    ? undefined
    : Math.max(0, REVIEW_WINDOW_MS - (Date.now() - overdueSince));
  return {
    isOverdue: true,
    overdueSince,
    overdueDays,
    confirmation,
    escalation,
    msUntilEscalation,
  };
}

export function formatCountdown(ms: number): string {
  if (ms <= 0) return "now";
  const totalMinutes = Math.floor(ms / 60_000);
  const days = Math.floor(totalMinutes / (60 * 24));
  const hours = Math.floor((totalMinutes % (60 * 24)) / 60);
  const minutes = totalMinutes % 60;
  if (days > 0) return `${days}d ${hours}h`;
  if (hours > 0) return `${hours}h ${minutes}m`;
  return `${minutes}m`;
}

export function formatRelative(ms: number): string {
  const diff = Math.max(0, Date.now() - ms);
  const mins = Math.floor(diff / 60_000);
  if (mins < 1) return "just now";
  if (mins < 60) return `${mins}m ago`;
  const hours = Math.floor(mins / 60);
  if (hours < 24) return `${hours}h ago`;
  const days = Math.floor(hours / 24);
  return `${days}d ago`;
}
