// Per-track overdue task computation for the OLP schedule.

import { runwayDays } from "@/lib/minDuration";
import {
  tasksForLaunch,
  taskStatus,
  type LaunchTask,
  type TaskFunction,
  type TaskStatus,
} from "@/lib/launchTasks";
import type { Launch } from "@/mocks/launches";
import type { ScheduleTrack } from "@/lib/schedule";

export interface OverdueTaskRow {
  task: LaunchTask;
  overdueDays: number;
  status: TaskStatus;
}

export function overdueTasksFor(launch: Launch, track: TaskFunction): OverdueTaskRow[] {
  const scheduleTrack = track as ScheduleTrack;
  const rows: OverdueTaskRow[] = [];
  for (const task of tasksForLaunch(launch)) {
    if (!task.teams.includes(track)) continue;
    const status = taskStatus(launch, task, scheduleTrack);
    if (status === "completed" || status === "not-started") continue;
    const runway = runwayDays(launch, task);
    if (runway >= 0) continue;
    rows.push({ task, overdueDays: Math.abs(runway), status });
  }
  rows.sort((a, b) => b.overdueDays - a.overdueDays);
  return rows;
}
