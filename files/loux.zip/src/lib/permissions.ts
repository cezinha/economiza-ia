import { useMemo } from "react";
import { useRole, type Role } from "@/contexts/RoleContext";
import { useViewFilter } from "@/contexts/ViewFilterContext";
import { launches as ALL_LAUNCHES } from "@/mocks/launches";
import type { LaunchTask, TaskFunction } from "@/lib/launchTasks";

/** True when the active role has view-only access (no mutations). */
export function useIsReadOnly() {
  return useRole().role === "executive";
}

/**
 * True when a SChM-only task should be hidden behind a "Sensitive information"
 * lock for the active viewer. Applies only to admin/user whose locked function
 * is GOE or NPI. Superadmin, Executive, and SChM-scoped admins/users see
 * SChM tasks normally.
 */
export function isSensitiveLockedFor(
  role: Role,
  lockedFunction: TaskFunction | null,
  task: Pick<LaunchTask, "teams">,
): boolean {
  if (role !== "admin" && role !== "user") return false;
  if (lockedFunction === "SChM") return false;
  return task.teams.length === 1 && task.teams[0] === "SChM";
}

/** Hook variant of `isSensitiveLockedFor` for component call sites. */
export function useIsSensitiveLocked(task: Pick<LaunchTask, "teams"> | null | undefined): boolean {
  const { role } = useRole();
  const { lockedFunction } = useViewFilter();
  if (!task) return false;
  return isSensitiveLockedFor(role, lockedFunction, task);
}

/** Set of assigned platform IDs for the active role (User/Admin scoping). */
export function useAssignedPlatformIds(): Set<string> | null {
  const { lockedPlatformIds } = useViewFilter();
  return useMemo(
    () => (lockedPlatformIds ? new Set(lockedPlatformIds) : null),
    [lockedPlatformIds],
  );
}

/** Names of the user's assigned platforms (for display + name-based lookups). */
export function useAssignedPlatformNames(): Set<string> | null {
  const ids = useAssignedPlatformIds();
  return useMemo(() => {
    if (!ids) return null;
    return new Set(
      ALL_LAUNCHES.filter((l) => ids.has(l.id)).map((l) => l.name),
    );
  }, [ids]);
}

/**
 * Whether the active role can mutate data for a given platform.
 * - superadmin: always
 * - executive: never (read-only)
 * - admin / user: only assigned platforms
 *
 * Pass an id (preferred) or a display name.
 */
export function useCanActOnPlatform(
  platformIdOrName: string | null | undefined,
): boolean {
  const { role } = useRole();
  const ids = useAssignedPlatformIds();
  const names = useAssignedPlatformNames();
  return useMemo(() => {
    if (!platformIdOrName) return false;
    if (role === "executive") return false;
    if (role === "superadmin") return true;
    if (!ids || !names) return false;
    return ids.has(platformIdOrName) || names.has(platformIdOrName);
  }, [role, ids, names, platformIdOrName]);
}

/** Same as useCanActOnPlatform but for arbitrary launch refs ({id, name}). */
export function canActOnPlatformInfo(
  role: ReturnType<typeof useRole>["role"],
  assignedIds: Set<string> | null,
  assignedNames: Set<string> | null,
  ref: { id?: string; name?: string } | null | undefined,
): boolean {
  if (!ref) return false;
  if (role === "executive") return false;
  if (role === "superadmin") return true;
  if (!assignedIds || !assignedNames) return false;
  return (
    (!!ref.id && assignedIds.has(ref.id)) ||
    (!!ref.name && assignedNames.has(ref.name))
  );
}

// ---- Status-change / completion approval permissions ----------------------

/** Anyone who can act on the platform can file a status change or completion
 *  request. Executive view stays read-only. */
export function canRequestStatusChange(role: Role): boolean {
  return role !== "executive";
}

/** Only Admin and Superadmin can approve / reject queued requests. */
export function canApproveStatusChange(role: Role): boolean {
  return role === "admin" || role === "superadmin";
}

/** Same set may also override status directly (writes an auto-approved record). */
export function canOverrideStatus(role: Role): boolean {
  return canApproveStatusChange(role);
}
