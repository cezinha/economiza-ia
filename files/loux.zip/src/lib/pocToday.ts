// Shared "today" anchor for all mock data. Captured once per module load so a
// single session is stable, but follows the real clock across reloads — the
// dashboard story (phases, NUDDs, milestones, due dates) shifts day-by-day
// without us touching the seeded data.

const MS_DAY = 24 * 60 * 60 * 1000;

function startOfTodayUTC(): Date {
  const now = new Date();
  return new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate()));
}

/** UTC midnight of today, captured at module load. */
export const POC_TODAY: Date = startOfTodayUTC();

export function addDays(d: Date, days: number): Date {
  return new Date(d.getTime() + days * MS_DAY);
}

export function minDate(a: Date, b: Date): Date {
  return a.getTime() <= b.getTime() ? a : b;
}

export function maxDate(a: Date, b: Date): Date {
  return a.getTime() >= b.getTime() ? a : b;
}

function pad(n: number): string {
  return n.toString().padStart(2, "0");
}

/** YYYY-MM-DD in UTC. */
export function toISODate(d: Date): string {
  return `${d.getUTCFullYear()}-${pad(d.getUTCMonth() + 1)}-${pad(d.getUTCDate())}`;
}

const MONTHS = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];

/** DD/MMM/YY h:MM AM/PM in UTC. */
export function toDrawerDate(d: Date, hour: number, minute: number): string {
  const yy = d.getUTCFullYear() % 100;
  const dd = pad(d.getUTCDate());
  const mmm = MONTHS[d.getUTCMonth()];
  const ampm = hour >= 12 ? "PM" : "AM";
  const h12 = hour % 12 === 0 ? 12 : hour % 12;
  return `${dd}/${mmm}/${pad(yy)} ${h12}:${pad(minute)} ${ampm}`;
}

/** Convenience: today + offset days as ISO YYYY-MM-DD. */
export function todayPlus(offsetDays: number): string {
  return toISODate(addDays(POC_TODAY, offsetDays));
}
