// POR vs actuals variance helpers — phase-exit level.
import type { Launch } from "@/mocks/launches";
import type { ScheduleTrack } from "@/lib/schedule";
import { porFor, porDeltaDays, type PorPhaseRecord } from "@/mocks/porBaseline";

export type VarianceStatus = "on-plan" | "pull-in" | "slip-minor" | "slip-major" | "pending";

export interface PhaseVariance extends PorPhaseRecord {
  deltaDays?: number;
  status: VarianceStatus;
}

export function classifyDelta(delta: number | undefined): VarianceStatus {
  if (delta === undefined) return "pending";
  if (delta === 0) return "on-plan";
  if (delta < 0) return "pull-in";
  if (delta <= 7) return "slip-minor";
  return "slip-major";
}

export function getPhaseVariance(launch: Launch, track: ScheduleTrack): PhaseVariance[] {
  return porFor(launch, track).map((p) => {
    const delta = p.actualExit ? porDeltaDays(p.porExit, p.actualExit) : undefined;
    return { ...p, deltaDays: delta, status: classifyDelta(delta) };
  });
}

export const VARIANCE_TONE: Record<VarianceStatus, string> = {
  "on-plan": "bg-status-on-track",
  "pull-in": "bg-status-completed",
  "slip-minor": "bg-status-at-risk-mitigated",
  "slip-major": "bg-status-at-risk",
  pending: "bg-status-not-started",
};

export const VARIANCE_LABEL: Record<VarianceStatus, string> = {
  "on-plan": "On plan",
  "pull-in": "Pulled in",
  "slip-minor": "Slip · minor",
  "slip-major": "Slip · major",
  pending: "Pending",
};

export function formatDelta(d: number | undefined): string {
  if (d === undefined) return "—";
  if (d === 0) return "0d";
  return d > 0 ? `+${d}d` : `${d}d`;
}
