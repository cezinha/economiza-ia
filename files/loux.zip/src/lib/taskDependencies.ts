import type { Launch } from "@/mocks/launches";
import {
  taskStatus,
  worstActive,
  type LaunchTask,
  type LineOfBusiness,
  type TaskStatus,
} from "@/lib/launchTasks";
import { catalogIndex, parsePredecessorIds } from "@/lib/taskPredecessors";

const RECENT_DAYS = 7;

export { parsePredecessorIds };

function statusOf(launch: Launch, t: LaunchTask): TaskStatus {
  return worstActive(t.teams.map((tm) => taskStatus(launch, t, tm)));
}

/**
 * Deterministic mock completion timestamp for a completed task. Mirrors the
 * helper in TaskQueue so the chip's "recently cleared" decision matches the
 * "Completed N days ago" label the user sees elsewhere.
 */
export function mockCompletedAt(taskId: string): Date {
  let h = 2166136261;
  for (let i = 0; i < taskId.length; i++) {
    h ^= taskId.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  const daysAgo = (h >>> 0) % 180;
  const d = new Date();
  d.setDate(d.getDate() - daysAgo);
  return d;
}

export interface PredecessorRef {
  task: LaunchTask;
  status: TaskStatus;
}
export interface ClearedRef {
  task: LaunchTask;
  clearedAt: Date;
}

export interface DependencyState {
  blockers: PredecessorRef[];
  recentlyCleared: ClearedRef[];
  predecessors: PredecessorRef[];
  successors: PredecessorRef[];
}

/**
 * Build a per-launch lookup helper. Indexes tasks by l3Id once, then resolves
 * predecessor/successor relationships from the catalog without rescanning on
 * each call.
 */
export function buildLaunchDependencyResolver(
  launch: Launch,
  allTasks: LaunchTask[],
) {
  const lob = launch.lob as LineOfBusiness;
  const byL3: Map<number, LaunchTask[]> = new Map();
  for (const t of allTasks) {
    if (t.l3Id == null) continue;
    const arr = byL3.get(t.l3Id);
    if (arr) arr.push(t);
    else byL3.set(t.l3Id, [t]);
  }

  // Predecessor ids per task id (cached).
  const predIdCache = new Map<string, number[]>();
  const predIdsFor = (t: LaunchTask): number[] => {
    if (predIdCache.has(t.id)) return predIdCache.get(t.id)!;
    const cat = t.l3Id != null ? catalogIndex.get(`${t.phase}::${t.l3Id}`) : undefined;
    const ids = cat ? parsePredecessorIds(cat.predecessors, lob) : [];
    predIdCache.set(t.id, ids);
    return ids;
  };

  // Reverse map: predecessor l3Id → [tasks that depend on it]
  const successorMap: Map<number, LaunchTask[]> = new Map();
  for (const t of allTasks) {
    for (const id of predIdsFor(t)) {
      const arr = successorMap.get(id);
      if (arr) arr.push(t);
      else successorMap.set(id, [t]);
    }
  }

  const lookupPredecessor = (id: number, ownerPhase: string): LaunchTask | null => {
    const candidates = byL3.get(id);
    if (!candidates || candidates.length === 0) return null;
    return candidates.find((c) => c.phase === ownerPhase) ?? candidates[0];
  };

  return {
    /** Full dependency state for the drawer. */
    full(task: LaunchTask): DependencyState {
      const ids = predIdsFor(task);
      const predecessors = ids
        .map((id) => lookupPredecessor(id, task.phase))
        .filter((t): t is LaunchTask => !!t && t.id !== task.id)
        .map((t) => ({ task: t, status: statusOf(launch, t) }));

      const successorTasks = task.l3Id != null ? successorMap.get(task.l3Id) ?? [] : [];
      const successors = successorTasks
        .filter((t) => t.id !== task.id)
        .map((t) => ({ task: t, status: statusOf(launch, t) }));

      const blockers = predecessors.filter((p) => p.status !== "completed");
      const recentlyCleared: ClearedRef[] = predecessors
        .filter((p) => p.status === "completed")
        .map((p) => ({ task: p.task, clearedAt: mockCompletedAt(p.task.id) }))
        .filter((p) => (Date.now() - p.clearedAt.getTime()) / 86_400_000 <= RECENT_DAYS);

      return { blockers, recentlyCleared, predecessors, successors };
    },
    /** Lightweight: just the chip-relevant data for a task. */
    chip(task: LaunchTask): { blockers: PredecessorRef[]; recentlyCleared: ClearedRef[] } {
      const ids = predIdsFor(task);
      if (ids.length === 0) return { blockers: [], recentlyCleared: [] };
      const predecessors = ids
        .map((id) => lookupPredecessor(id, task.phase))
        .filter((t): t is LaunchTask => !!t && t.id !== task.id)
        .map((t) => ({ task: t, status: statusOf(launch, t) }));
      const blockers = predecessors.filter((p) => p.status !== "completed");
      const recentlyCleared: ClearedRef[] = predecessors
        .filter((p) => p.status === "completed")
        .map((p) => ({ task: p.task, clearedAt: mockCompletedAt(p.task.id) }))
        .filter((p) => (Date.now() - p.clearedAt.getTime()) / 86_400_000 <= RECENT_DAYS);
      return { blockers, recentlyCleared };
    },
  };
}

export type LaunchDependencyResolver = ReturnType<typeof buildLaunchDependencyResolver>;
