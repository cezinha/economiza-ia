// Due-date signal helper: classifies tasks as "ok", "approaching" (due soon
// within the recommended minimum runway), or "overdue". Powers badges,
// drawer banners, and inbox notifications. Does NOT change task status — the
// new model requires an explicit user request + manager approval to flip RYG.

import type { Launch } from "@/mocks/launches";
import type { LaunchTask } from "@/lib/launchTasks";
import { getMinDuration, runwayDays } from "@/lib/minDuration";

export type DueSeverity = "none" | "approaching" | "overdue";

/** Cap "approaching" warnings so very long minimum durations don't fire too early. */
const APPROACHING_CAP_DAYS = 14;

export interface DueSignal {
  severity: DueSeverity;
  daysUntil: number;
  /** Threshold in days at/under which `approaching` triggers. */
  threshold: number;
}

export function dueSignal(launch: Launch, task: LaunchTask, today: Date = new Date()): DueSignal {
  const daysUntil = runwayDays(launch, task, today);
  const min = getMinDuration(task).days;
  const threshold = Math.max(1, Math.min(APPROACHING_CAP_DAYS, min));
  if (daysUntil < 0) return { severity: "overdue", daysUntil, threshold };
  if (daysUntil <= threshold) return { severity: "approaching", daysUntil, threshold };
  return { severity: "none", daysUntil, threshold };
}

export function dueLabel(s: DueSignal): string {
  if (s.severity === "overdue") {
    const n = Math.abs(s.daysUntil);
    return n === 0 ? "Overdue today" : `Overdue ${n}d`;
  }
  if (s.severity === "approaching") {
    if (s.daysUntil === 0) return "Due today";
    if (s.daysUntil === 1) return "Due tomorrow";
    return `Due in ${s.daysUntil}d`;
  }
  return "";
}
