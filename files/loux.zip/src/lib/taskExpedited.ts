// Detects when a task is being expedited because its launch's RTS was pulled in.
// Mock heuristic: any non-completed task on a launch whose override's newDate is
// earlier than the previous date is considered "expedited to meet POR schedule".

import type { Launch } from "@/mocks/launches";
import type { LaunchTask, TaskStatus } from "@/lib/launchTasks";
import { getOverride } from "@/mocks/launchDateOverrides";

export interface ExpeditedInfo {
  previousDate: string;
  newDate: string;
  pulledInDays: number;
}

function daysBetween(aIso: string, bIso: string): number {
  const a = new Date(aIso + "T00:00:00Z").getTime();
  const b = new Date(bIso + "T00:00:00Z").getTime();
  return Math.round((a - b) / 86400000);
}

export function isTaskExpedited(
  launch: Pick<Launch, "id">,
  _task: LaunchTask,
  status?: TaskStatus,
): ExpeditedInfo | null {
  if (status === "completed") return null;
  const o = getOverride(launch.id);
  if (!o) return null;
  const pulledInDays = daysBetween(o.previousDate, o.newDate);
  if (pulledInDays <= 0) return null;
  return { previousDate: o.previousDate, newDate: o.newDate, pulledInDays };
}
