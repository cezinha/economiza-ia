import type { Launch } from "@/mocks/launches";
import { effectiveLaunchDate } from "@/mocks/launchDateOverrides";

/**
 * Source of truth for mock task comment bodies. Used both to render the
 * comment thread in `TaskDetailDrawer` (via `taskDetails.ts`) and to detect
 * "mitigation plan" comments that downgrade an overdue task from red → yellow
 * (in `launchTasks.ts → taskStatus`). Keep a couple of bodies that match
 * /mitigat/i so the yellow path is reachable in the seeded mock.
 */
export const TASK_COMMENT_BODIES = [
  "Initial scoping looks fine — confirmed alignment with the GOE charter.",
  "Need GSM input on supplier capacity before we can move forward.",
  "Engineering flagged a thermal margin concern; tracking via JIRA.",
  "Aligned with the extended team in today's review; no blockers.",
  "Pulling forward by 2 days to de-risk the downstream gate.",
  "Mitigation plan in place: added a parallel review track to recover the slip.",
  "Mitigation plan: re-sequenced downstream tasks and secured backup supplier capacity.",
];

function hash(str: string): number {
  let h = 0;
  for (let i = 0; i < str.length; i++) h = (h * 31 + str.charCodeAt(i)) >>> 0;
  return h;
}

/** Deterministic comment bodies for a given task id. Mirrors taskDetails.ts. */
export function taskCommentBodies(taskId: string): string[] {
  const seed = hash(taskId);
  const count = (seed % 3) + 1;
  const out: string[] = [];
  for (let i = 0; i < count; i++) {
    out.push(TASK_COMMENT_BODIES[(seed + i) % TASK_COMMENT_BODIES.length]);
  }
  return out;
}

/** True when any seeded comment for this task mentions a mitigation plan. */
export function hasMitigationComment(taskId: string): boolean {
  return taskCommentBodies(taskId).some((b) => /mitigat/i.test(b));
}

function parseOffsetDays(taskEnd: string): number {
  const m = taskEnd.match(/([+\-])\s*(\d+)\s*day/i);
  if (!m) return 0;
  return (m[1] === "-" ? -1 : 1) * parseInt(m[2], 10);
}

function addDays(iso: string, days: number): string {
  const d = new Date(iso);
  d.setDate(d.getDate() + days);
  return d.toISOString().slice(0, 10);
}

/** ISO YYYY-MM-DD effective due date for a task on a launch. */
export function taskDueDateIso(launch: Launch, taskEnd: string): string {
  const offset = parseOffsetDays(taskEnd);
  return addDays(effectiveLaunchDate(launch), offset - 60);
}

/** True when the task's effective due date is strictly before `today`. */
export function isTaskOverdue(
  launch: Launch,
  taskEnd: string,
  today: Date = new Date(),
): boolean {
  const dueIso = taskDueDateIso(launch, taskEnd);
  return new Date(dueIso).getTime() < today.getTime();
}
