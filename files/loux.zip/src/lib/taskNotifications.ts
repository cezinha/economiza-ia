// Counts of non-runway notifications attached to a single task. Currently
// covers pending assignment requests; designed to grow as new flows land.

import { useEffect, useState } from "react";
import {
  pendingForTask as pendingAssignmentForTask,
  subscribeAssignmentRequests,
} from "@/mocks/assignmentRequests";

export interface TaskNotificationSummary {
  total: number;
  hasAssignmentRequest: boolean;
}

export function getTaskNotificationSummary(taskId: string): TaskNotificationSummary {
  const req = pendingAssignmentForTask(taskId);
  let total = 0;
  if (req) total += 1;
  return { total, hasAssignmentRequest: !!req };
}

export function useTaskNotifications(taskId: string): TaskNotificationSummary {
  const [, force] = useState(0);
  useEffect(() => {
    const unsub = subscribeAssignmentRequests(() => force((n) => n + 1));
    return () => {
      unsub();
    };
  }, []);
  return getTaskNotificationSummary(taskId);
}
