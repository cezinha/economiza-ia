// Shared catalog index + predecessor parsing. Lives in its own module so both
// `launchTasks.ts` and `taskDependencies.ts` can import it without creating a
// circular dependency (taskDependencies imports taskStatus from launchTasks).

import { taskCatalog, type CatalogTask } from "@/mocks/taskCatalog";
import type { LineOfBusiness, LaunchTask } from "@/lib/launchTasks";

/** Catalog index keyed by `${phase}::${l3Id}`. */
export const catalogIndex: Map<string, CatalogTask> = (() => {
  const m = new Map<string, CatalogTask>();
  for (const c of taskCatalog) {
    const id = parseInt(c.l3Id, 10);
    if (Number.isFinite(id)) m.set(`${c.l1Phase}::${id}`, c);
  }
  return m;
})();

const LOB_TAGS: Record<LineOfBusiness, string[]> = {
  NB: ["NB"],
  DT: ["DT"],
  DnCP: ["DnCP"],
};

/**
 * Parse a free-text predecessors string from the catalog. See doc in the
 * original taskDependencies.ts for examples / rules.
 */
export function parsePredecessorIds(raw: string, lob: LineOfBusiness): number[] {
  if (!raw) return [];
  const lobTokens = LOB_TAGS[lob];
  const segments = raw.split("|").map((s) => s.trim()).filter(Boolean);
  const out = new Set<number>();
  for (const seg of segments) {
    let body = seg;
    const tag = seg.match(/^\[([^\]]+)\]\s*(.*)$/);
    if (tag) {
      const tags = tag[1].split("/").map((t) => t.trim());
      const matches = tags.some((t) => lobTokens.includes(t));
      if (!matches) continue;
      body = tag[2];
    }
    if (/^\s*NA\s*$/i.test(body)) continue;
    body = body.replace(/\([^)]*\)/g, "");
    const matchRange = body.match(/^[\s\d,]+/);
    const numeric = matchRange ? matchRange[0] : "";
    for (const m of numeric.matchAll(/\d+/g)) {
      out.add(parseInt(m[0], 10));
    }
  }
  return Array.from(out);
}

/** Numeric predecessor l3Ids for a single task. */
export function predecessorIdsFor(task: LaunchTask, lob: LineOfBusiness): number[] {
  if (task.l3Id == null) return [];
  const cat = catalogIndex.get(`${task.phase}::${task.l3Id}`);
  if (!cat) return [];
  return parsePredecessorIds(cat.predecessors, lob);
}
