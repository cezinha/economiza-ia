import type { Launch } from "@/mocks/launches";
import type { LaunchTask } from "@/lib/launchTasks";
import { isAutoTask } from "@/lib/launchTasks";
import { getMinDuration, runwayDays } from "@/lib/minDuration";
import { getOverrideBucket } from "@/mocks/runwayBucketOverrides";

export type RunwayBucket = "overdue" | "soon" | "ok" | "n/a";

/**
 * Kept for backward compatibility with any UI strings; no longer used in the
 * bucket math.
 */
export const DUE_SOON_DAYS = 14;

/**
 * Classify a task into a runway bucket relative to today.
 *
 * - "n/a" only when the task is completed.
 * - "overdue" when the due date has passed (any RAG status, including auto/
 *   phase-close).
 * - "soon" (a.k.a. "upcoming") when the task's suggested minimum duration
 *   exceeds the days of runway remaining — i.e. there isn't enough time left
 *   to finish it on time. Auto tasks have a 0d min, so they never bucket here.
 * - "ok" otherwise.
 */
export function taskRunwayBucket(
  launch: Launch,
  task: LaunchTask,
  opts: { status?: string; today?: Date } = {},
): RunwayBucket {
  if (opts.status === "completed") return "n/a";

  // Mock-only override so the demo shows a deliberate mix of Warning /
  // Overdue / Overdue-Urgent badges. Auto tasks are excluded to preserve
  // their "no chip" behavior.
  if (!isAutoTask(task)) {
    const override = getOverrideBucket(task.id);
    if (override === "warn") return "soon";
    if (override === "overdue" || override === "overdue-urgent") return "overdue";
    if (override === "ok") return "ok";
  }

  const runway = runwayDays(launch, task, opts.today ?? new Date());
  if (runway < 0) return "overdue";
  const min = getMinDuration(task).days;
  if (min > runway) return "soon";
  return "ok";
}
