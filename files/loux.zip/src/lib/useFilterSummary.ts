import { useFilters } from "@/contexts/FilterContext";

function formatValue(v: unknown): string {
  if (Array.isArray(v)) return v.map(String).join(", ");
  if (v && typeof v === "object") return Object.values(v as Record<string, unknown>).map(String).join(", ");
  return String(v);
}

const LABELS: Record<string, string> = {
  lob: "LOB",
  region: "Region",
  phase: "Phase",
  rag: "RAG",
  owner: "Owner",
  product: "Product",
  track: "Track",
  status: "Status",
  search: "Search",
};

export function useFilterSummary(): string {
  const { filters } = useFilters();
  if (filters.watchlist === true) return "Filters — Watchlist";
  const parts: string[] = [];
  for (const [k, v] of Object.entries(filters)) {
    if (k === "watchlist") continue;
    if (v === undefined || v === null || v === "") continue;
    if (Array.isArray(v) && v.length === 0) continue;
    if (typeof v === "object" && !Array.isArray(v) && Object.keys(v as object).length === 0) continue;
    const label = LABELS[k] ?? k;
    parts.push(`${label}: ${formatValue(v)}`);
  }
  return parts.length ? `Filters — ${parts.join(" · ")}` : "Filters — none";
}
