// Runtime activity log. Wraps the seeded `activity` array from launches.ts and
// adds in-memory entries appended by the assignment, runway-exception, milestone
// and NUDD-trigger flows. Components should subscribe via `subscribeActivity`
// and read via `getAllActivity()` so they re-render on new entries.

import { activity as SEEDED, type Activity, type ActivityKind } from "@/mocks/launches";

const runtime: Activity[] = [];
const listeners = new Set<() => void>();

function notify() {
  for (const l of listeners) l();
}

export function subscribeActivity(fn: () => void): () => void {
  listeners.add(fn);
  return () => listeners.delete(fn);
}

function relativeStamp(ms: number): string {
  const diff = Date.now() - ms;
  const min = Math.max(0, Math.round(diff / 60000));
  if (min < 1) return "just now";
  if (min < 60) return `${min} min ago`;
  const hr = Math.round(min / 60);
  if (hr < 24) return `${hr}h ago`;
  const d = Math.round(hr / 24);
  return d === 1 ? "Yesterday" : `${d}d ago`;
}

export function appendActivity(input: {
  actor: string;
  kind: ActivityKind;
  launchId: string;
  refId?: string;
  detail?: string;
}): Activity {
  const now = Date.now();
  const a: Activity = {
    id: `act-${now}-${Math.random().toString(36).slice(2, 6)}`,
    timestamp: relativeStamp(now),
    ts: now,
    ...input,
  };
  runtime.unshift(a);
  notify();
  return a;
}

export function getAllActivity(): Activity[] {
  // Refresh relative stamps each read so "12 min ago" stays accurate.
  for (const a of runtime) {
    if (a.ts) a.timestamp = relativeStamp(a.ts);
  }
  return [...runtime, ...SEEDED];
}
