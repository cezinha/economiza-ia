// In-memory mock store for task assignment approval/rejection flow.
// PoC only — no persistence beyond the session.

import type { TaskOwner } from "@/mocks/taskDetails";
import { appendActivity } from "@/mocks/activityLog";
import { launches } from "@/mocks/launches";

function launchIdFor(name: string): string {
  return launches.find((l) => l.name === name)?.id ?? launches[0].id;
}

export type AssignmentRequestStatus = "pending" | "approved" | "rejected" | "cancelled";

export interface AssignmentRequest {
  id: string;
  taskId: string;
  taskName: string;
  launchName: string;
  fromOwner: TaskOwner | null;
  toOwner: TaskOwner;
  requestedBy: string;
  reason?: string;
  status: AssignmentRequestStatus;
  createdAt: number; // ms epoch
  resolvedAt?: number;
  resolutionReason?: string;
}

// Treat this as the "logged-in" user for the PoC. Pending requests targeted at
// this person become actionable in the inbox / drawer banner.
export const CURRENT_USER_NAME = "Priya Shah";

const requests: AssignmentRequest[] = [];
const listeners = new Set<() => void>();

function notify() {
  for (const l of listeners) l();
}

export function subscribeAssignmentRequests(fn: () => void): () => void {
  listeners.add(fn);
  return () => listeners.delete(fn);
}

export function allRequests(): AssignmentRequest[] {
  return requests.slice();
}

export function pendingForUser(name: string): AssignmentRequest[] {
  return requests.filter((r) => r.status === "pending" && r.toOwner.name === name);
}

export function pendingForTask(taskId: string): AssignmentRequest | undefined {
  return requests.find((r) => r.taskId === taskId && r.status === "pending");
}

export function pendingCount(): number {
  return requests.filter((r) => r.status === "pending").length;
}

export function createRequest(input: {
  taskId: string;
  taskName: string;
  launchName: string;
  fromOwner: TaskOwner | null;
  toOwner: TaskOwner;
  requestedBy: string;
  reason?: string;
}): AssignmentRequest {
  // Cancel any existing pending request for the same task.
  for (const r of requests) {
    if (r.taskId === input.taskId && r.status === "pending") {
      r.status = "cancelled";
      r.resolvedAt = Date.now();
      r.resolutionReason = "Superseded by a newer request";
    }
  }
  const req: AssignmentRequest = {
    id: `req-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
    status: "pending",
    createdAt: Date.now(),
    ...input,
  };
  requests.unshift(req);
  appendActivity({
    actor: input.requestedBy,
    kind: "assignment_request",
    launchId: launchIdFor(input.launchName),
    refId: input.taskId,
    detail: `${input.taskName} → ${input.toOwner.name}${input.reason ? ` (${input.reason})` : ""}`,
  });
  notify();
  return req;
}

export function approveRequest(id: string): AssignmentRequest | undefined {
  const r = requests.find((x) => x.id === id);
  if (!r || r.status !== "pending") return r;
  r.status = "approved";
  r.resolvedAt = Date.now();
  appendActivity({
    actor: r.toOwner.name,
    kind: "assignment_resolved",
    launchId: launchIdFor(r.launchName),
    refId: r.taskId,
    detail: `accepted reassignment of ${r.taskName}`,
  });
  notify();
  return r;
}

export function rejectRequest(id: string, reason: string): AssignmentRequest | undefined {
  const r = requests.find((x) => x.id === id);
  if (!r || r.status !== "pending") return r;
  r.status = "rejected";
  r.resolvedAt = Date.now();
  r.resolutionReason = reason;
  appendActivity({
    actor: r.toOwner.name,
    kind: "assignment_resolved",
    launchId: launchIdFor(r.launchName),
    refId: r.taskId,
    detail: `declined reassignment of ${r.taskName} — ${reason}`,
  });
  notify();
  return r;
}

export function cancelRequest(id: string): void {
  const r = requests.find((x) => x.id === id);
  if (!r || r.status !== "pending") return;
  r.status = "cancelled";
  r.resolvedAt = Date.now();
  notify();
}

export function formatRelative(ts: number): string {
  const diffMs = Date.now() - ts;
  const min = Math.round(diffMs / 60000);
  if (min < 1) return "just now";
  if (min < 60) return `${min} min ago`;
  const hr = Math.round(min / 60);
  if (hr < 24) return `${hr}h ago`;
  const d = Math.round(hr / 24);
  return `${d}d ago`;
}
