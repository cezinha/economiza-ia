// In-memory queue for user-submitted "mark complete" requests.
// Approved entries make the task render as `completed` in the status resolver.

import { appendActivity } from "@/mocks/activityLog";
import { appendTaskHistory } from "@/mocks/taskHistory";
import { initialsFor } from "@/mocks/statusChangeRequests";

export type CompletionState = "pending" | "approved" | "rejected";

export interface CompletionRequest {
  id: string;
  launchId: string;
  taskId: string;
  taskName: string;
  completionNote: string;
  evidenceLink?: string;
  owner: string;
  requestedBy: string;
  requestedAt: number;
  state: CompletionState;
  reviewedBy?: string;
  reviewedAt?: number;
  reviewerNote?: string;
  /** True when system auto-seeded (e.g. past phases, auto tasks). */
  systemSeeded?: boolean;
}

const requests: CompletionRequest[] = [];
const listeners = new Set<() => void>();

function notify() {
  for (const l of listeners) l();
}

export function subscribeCompletionRequests(fn: () => void): () => void {
  listeners.add(fn);
  return () => listeners.delete(fn);
}

export function listCompletionRequests(filter?: {
  state?: CompletionState;
  launchId?: string;
  taskId?: string;
}): CompletionRequest[] {
  return requests.filter((r) => {
    if (filter?.state && r.state !== filter.state) return false;
    if (filter?.launchId && r.launchId !== filter.launchId) return false;
    if (filter?.taskId && r.taskId !== filter.taskId) return false;
    return true;
  });
}

export function pendingCompletionCount(): number {
  return requests.reduce((n, r) => n + (r.state === "pending" ? 1 : 0), 0);
}

export function pendingCompletionForTask(taskId: string): CompletionRequest | undefined {
  return requests.find((r) => r.state === "pending" && r.taskId === taskId);
}

export function isTaskCompleted(taskId: string): boolean {
  return requests.some((r) => r.state === "approved" && r.taskId === taskId);
}

export function createCompletionRequest(input: {
  launchId: string;
  taskId: string;
  taskName: string;
  completionNote: string;
  evidenceLink?: string;
  owner: string;
  requestedBy: string;
}): CompletionRequest {
  const entry: CompletionRequest = {
    id: `cr-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
    state: "pending",
    requestedAt: Date.now(),
    ...input,
  };
  requests.unshift(entry);
  appendActivity({
    actor: input.requestedBy,
    kind: "task_request_created",
    launchId: input.launchId,
    refId: entry.id,
    detail: `Requested to mark complete "${input.taskName}"`,
  });
  appendTaskHistory({
    taskId: input.taskId,
    actor: { name: input.requestedBy, initials: initialsFor(input.requestedBy) },
    field: "status",
    label: "Completion requested",
    before: null,
    after: "Pending approval",
    note: input.completionNote,
  });
  notify();
  return entry;
}

export function approveCompletionRequest(id: string, by: string, note?: string): void {
  const req = requests.find((r) => r.id === id);
  if (!req || req.state !== "pending") return;
  req.state = "approved";
  req.reviewedBy = by;
  req.reviewedAt = Date.now();
  req.reviewerNote = note;
  appendActivity({
    actor: by,
    kind: "task_request_approved",
    launchId: req.launchId,
    refId: req.id,
    detail: `Approved completion "${req.taskName}"`,
  });
  appendTaskHistory({
    taskId: req.taskId,
    actor: { name: by, initials: initialsFor(by) },
    field: "status",
    label: "Status",
    before: "On track",
    after: "Completed",
    note,

  });
  notify();
  // If this was a phase-close approval task, see if the phase can now advance.
  import("@/mocks/phaseTransitions")
    .then(({ maybeAdvanceOnCloseCompletion }) => maybeAdvanceOnCloseCompletion(req.launchId, by))
    .catch(() => {});
}


export function rejectCompletionRequest(id: string, by: string, note?: string): void {
  const req = requests.find((r) => r.id === id);
  if (!req || req.state !== "pending") return;
  req.state = "rejected";
  req.reviewedBy = by;
  req.reviewedAt = Date.now();
  req.reviewerNote = note;
  appendActivity({
    actor: by,
    kind: "task_request_rejected",
    launchId: req.launchId,
    refId: req.id,
    detail: `Rejected completion "${req.taskName}"${note ? ` — ${note}` : ""}`,
  });
  notify();
}

/** Seed a system-approved completion (used to backfill past-phase tasks). */
export function seedSystemCompletion(input: {
  launchId: string;
  taskId: string;
  taskName: string;
}): void {
  if (isTaskCompleted(input.taskId)) return;
  requests.push({
    id: `cr-seed-${input.taskId}`,
    state: "approved",
    launchId: input.launchId,
    taskId: input.taskId,
    taskName: input.taskName,
    completionNote: "Auto-completed when phase ended.",
    owner: "System",
    requestedBy: "System",
    requestedAt: 0,
    reviewedBy: "System",
    reviewedAt: 0,
    systemSeeded: true,
  });
}
