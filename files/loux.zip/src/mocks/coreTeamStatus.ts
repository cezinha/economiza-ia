import type { TaskStatus } from "@/lib/launchTasks";

export interface CoreTeamSignal {
  status: TaskStatus;
  reason?: string;
}

/**
 * Per-platform Core team own-signal overrides. The 15 platforms split evenly:
 *  - 5 on-track (no entry → default on-track)
 *  - 5 at-risk-mitigated (the 5 amber platforms)
 *  - 5 at-risk (the 5 red platforms)
 *
 * Keep aligned with the platform-rag distribution in `src/mocks/launches.ts`.
 */
export const CORE_TEAM_OVERRIDES: Record<string, CoreTeamSignal> = {
  // Demo: Core green on a platform where GOE/NPI/SChM are all red.
  "L-2003": { status: "on-track", reason: "Core deliverables on plan; firmware regression is a GOE-owned issue." },

  // Demo: Core red on a platform where GOE/NPI/SChM are all green.
  "L-2001": { status: "at-risk", reason: "Core team lead on extended leave; cross-functional coordination blocked." },

  // Amber platforms — Core team has a mitigated risk.
  "L-2002": { status: "at-risk-mitigated", reason: "EU cert delay; comms plan rebaselined." },
  "L-2006": { status: "at-risk-mitigated", reason: "Pricing dependency; exec review scheduled." },
  "L-2015": { status: "at-risk-mitigated", reason: "EOL inventory overhang; sell-through plan in place." },
  "L-2008": { status: "at-risk-mitigated", reason: "Beta customer slot unconfirmed; backup line-up identified." },
  "L-2013": { status: "at-risk-mitigated", reason: "Panel sourcing risk; dual-sourcing in flight." },

  // Red platforms — Core team escalation open.
  "L-2004": { status: "at-risk", reason: "BOM still unresolved; supplier RFQ slipping." },
  "L-2010": { status: "at-risk", reason: "Cross-functional staffing gap; backfill not identified." },
  "L-2014": { status: "at-risk", reason: "Concept gate inputs missing from PM track." },
  "L-2009": { status: "at-risk", reason: "Core team lead unassigned for >2 weeks." },
};

export function coreTeamOwnStatus(launchId: string): CoreTeamSignal {
  return CORE_TEAM_OVERRIDES[launchId] ?? { status: "on-track" };
}
