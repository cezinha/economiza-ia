import { POC_TODAY, addDays, toISODate } from "@/lib/pocToday";

export type CuratorDocStatus = "Active" | "Pending review" | "Archived";
export type CuratorDataSource = "SharePoint" | "Jira" | "Confluence" | "Regrello";

export type CuratorDoc = {
  id: string;
  name: string;
  type: string;
  lob: string;
  lastUpdated: string; // YYYY-MM-DD
  status: CuratorDocStatus;
  sizeKb: number;
  dataSource: CuratorDataSource;
};

const DATA_SOURCE_BY_TYPE: Record<string, CuratorDataSource> = {
  ARD: "Confluence",
  PRD: "Confluence",
  "Functional Plan": "Confluence",
  "FM-Feature Matrix": "Regrello",
  "Program Schedule": "Regrello",
  "Build Plan": "Regrello",
  CSTL: "SharePoint",
  "Complexity Matrix": "SharePoint",
  "Memory Matrix": "SharePoint",
  "Storage Matrix": "SharePoint",
  "Slot Priority Matrix": "SharePoint",
  "ID Book": "SharePoint",
};


const DOC_TYPES: { type: string; ext: string }[] = [
  { type: "ARD", ext: "docx" },
  { type: "PRD", ext: "docx" },
  { type: "Build Plan", ext: "xlsx" },
  { type: "CSTL", ext: "pdf" },
  { type: "Program Schedule", ext: "mpp" },
  { type: "Complexity Matrix", ext: "xlsx" },
  { type: "Memory Matrix", ext: "xlsx" },
  { type: "Storage Matrix", ext: "xlsx" },
  { type: "Slot Priority Matrix", ext: "xlsx" },
  { type: "ID Book", ext: "pdf" },
  { type: "Functional Plan", ext: "docx" },
  { type: "FM-Feature Matrix", ext: "xlsx" },
];

const STATUSES: CuratorDocStatus[] = ["Active", "Active", "Active", "Pending review", "Archived"];

function hash(s: string): number {
  let h = 0;
  for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) >>> 0;
  return h;
}

function pad(n: number): string {
  return n.toString().padStart(2, "0");
}

export function buildCuratorDocs(launchId: string, platform: string, lob: string): CuratorDoc[] {
  const h = hash(launchId);
  const count = 8 + (h % 5); // 8..12
  const docs: CuratorDoc[] = [];
  for (let i = 0; i < count; i++) {
    const meta = DOC_TYPES[(h + i * 7) % DOC_TYPES.length];
    const status = STATUSES[(h + i * 3) % STATUSES.length];
    const daysBack = 1 + ((h + i * 11) % 150); // 1..150 days before today
    const sizeKb = 80 + ((h + i * 17) % 4800);
    const slug = platform.replace(/[^A-Za-z0-9]+/g, "_");
    docs.push({
      id: `${launchId}-DOC-${pad(i + 1)}`,
      name: `${meta.type}_${slug}_v${1 + ((h + i) % 4)}.${meta.ext}`,
      type: meta.type,
      lob,
      lastUpdated: toISODate(addDays(POC_TODAY, -daysBack)),
      status,
      sizeKb,
      dataSource: DATA_SOURCE_BY_TYPE[meta.type] ?? "SharePoint",
    });
  }
  return docs.sort((a, b) => (a.lastUpdated < b.lastUpdated ? 1 : -1));
}
