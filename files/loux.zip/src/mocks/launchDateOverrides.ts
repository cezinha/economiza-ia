// In-memory mock store for milestone-date (RTS) overrides.
// Lets the UI shift a launch's RTS without mutating the source mock data and
// log the rationale (per the AS note: "POR was 6.1, but DFE completed 5.30,
// log this for XYZ reason for that date").

import type { Launch } from "@/mocks/launches";
import { launches as LIVE_LAUNCHES } from "@/mocks/launches";
import { appendActivity } from "@/mocks/activityLog";

export interface LaunchDateOverride {
  launchId: string;
  newDate: string; // ISO YYYY-MM-DD
  previousDate: string;
  by: string;
  at: number;
  reason: string;
  flaggedTaskCount: number;
}

const overrides = new Map<string, LaunchDateOverride>();
const history: LaunchDateOverride[] = [];
const listeners = new Set<() => void>();

// Seed a few pre-applied RTS pull-ins so the "At risk" expedited chip is
// visible out of the box across Task tracker / Task list / detail drawer.
function seedOverride(launchId: string, daysIn: number, reason: string) {
  const launch = LIVE_LAUNCHES.find((l) => l.id === launchId);
  if (!launch) return;
  const prev = launch.launchDate;
  const d = new Date(prev + "T00:00:00Z");
  d.setUTCDate(d.getUTCDate() - daysIn);
  const newDate = d.toISOString().slice(0, 10);
  const entry: LaunchDateOverride = {
    launchId,
    newDate,
    previousDate: prev,
    by: "System (seed)",
    at: Date.now(),
    reason,
    flaggedTaskCount: 0,
  };
  overrides.set(launchId, entry);
  history.unshift(entry);
}
seedOverride("L-2004", 21, "DFE accelerated for CRA window — pull RTS in 3 weeks");
seedOverride("L-2003", 14, "Channel commit moved up; expedite Plan-phase tasks");
seedOverride("L-2009", 10, "Holiday retail window — compress runway");
seedOverride("L-2014", 18, "S2426HS — exec committed earlier RTS; expedite Concept tasks");
seedOverride("L-2008", 12, "Rapterra AMD CS 16 — channel slot pulled in; compress Plan phase");

function notify() {
  for (const l of listeners) l();
}

export function subscribeLaunchDateOverrides(fn: () => void): () => void {
  listeners.add(fn);
  return () => listeners.delete(fn);
}

/** Effective RTS date — override if present, otherwise the seeded launchDate. */
export function effectiveLaunchDate(launch: Pick<Launch, "id" | "launchDate">): string {
  return overrides.get(launch.id)?.newDate ?? launch.launchDate;
}

export function getOverride(launchId: string): LaunchDateOverride | undefined {
  return overrides.get(launchId);
}

export function setLaunchDateOverride(input: {
  launch: Pick<Launch, "id" | "launchDate">;
  newDate: string;
  by: string;
  reason: string;
  flaggedTaskCount: number;
}): LaunchDateOverride {
  const previousDate = effectiveLaunchDate(input.launch);
  const entry: LaunchDateOverride = {
    launchId: input.launch.id,
    newDate: input.newDate,
    previousDate,
    by: input.by,
    at: Date.now(),
    reason: input.reason,
    flaggedTaskCount: input.flaggedTaskCount,
  };
  overrides.set(input.launch.id, entry);
  history.unshift(entry);
  appendActivity({
    actor: input.by,
    kind: "milestone_shift",
    launchId: input.launch.id,
    detail: `RTS moved ${previousDate} → ${input.newDate}${input.flaggedTaskCount ? ` · ${input.flaggedTaskCount} task${input.flaggedTaskCount === 1 ? "" : "s"} below min` : ""} — ${input.reason}`,
  });
  notify();
  return entry;
}

export function getLaunchDateHistory(launchId?: string): LaunchDateOverride[] {
  return launchId ? history.filter((h) => h.launchId === launchId) : history.slice();
}
