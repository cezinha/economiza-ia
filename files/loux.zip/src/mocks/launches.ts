export type RAG = "green" | "amber" | "red";
export type Phase = "Concept" | "Define" | "Plan" | "Develop" | "Qual" | "Pilot" | "Launch";
export type LOB = "DT" | "NB" | "DnCP";

export interface PgComponent {
  id: string;
  name: string; // "Marketing", "Core Team", "Quality", "Regulatory", "Supply", "Finance", "Comms"
  rag: RAG;
  reason?: string;
  owner?: string;
}

export interface PgStatusBlock {
  syncedAt: string;        // ISO "from Jira"
  jiraKey: string;         // e.g. "PG-DT-HYP-2026"
  overallReason?: string;  // headline reason rolled up by PG owner
  escalation: string[];    // ordered escalation path
  components: PgComponent[];
}

export interface Launch {
  id: string;
  name: string;
  product: string;
  lob: LOB;
  region: "NA" | "EMEA" | "APJ" | "LATAM";
  owner: string;
  phase: Phase;
  rag: RAG;
  progress: number; // 0-100
  nextMilestone: string;
  nextMilestoneDate: string;
  launchDate: string;
  /** Program (PG) status pulled from Jira — read-only, broader than GOE/NPI/SChM. */
  pg?: PgStatusBlock;
}

export interface Milestone {
  id: string;
  launchId: string;
  name: string;
  date: string;
  status: "complete" | "in_progress" | "upcoming" | "at_risk";
}

export interface TaskItem {
  id: string;
  title: string;
  launch: string;
  type: "approval" | "review" | "input" | "decision";
  priority: "high" | "medium" | "low";
  due: string;
  assignee: string;
}

export interface Risk {
  id: string;
  launch: string;
  title: string;
  severity: "critical" | "high" | "medium" | "low";
  owner: string;
  raisedDate: string;
}

export type ActivityKind =
  | "phase_change"
  | "risk_raised"
  | "decision_request"
  | "approval_submitted"
  | "milestone_done"
  | "launch_kickoff"
  | "assignment_request"
  | "assignment_resolved"
  | "runway_exception"
  | "runway_resolved"
  | "milestone_shift"
  | "nudd_trigger"
  | "task_added"
  | "task_deleted"
  | "task_request_created"
  | "task_request_approved"
  | "task_request_rejected"
  | "overdue_confirmed"
  | "overdue_escalated";


export interface Activity {
  id: string;
  actor: string;
  kind: ActivityKind;
  launchId: string;
  refId?: string;
  timestamp: string;
  /** Free-form descriptor used for the new dynamic kinds. */
  detail?: string;
  /** Optional epoch ms for sorting runtime entries before the seeded ones. */
  ts?: number;
}

// All dates below are derived from today via `src/lib/pocToday.ts`, so the
// demo story (today inside every phase, balanced RAG, NUDD windows, due dates)
// stays valid regardless of when the dashboard is opened. See `.lovable/plan.md`.
import { POC_TODAY, addDays, toISODate, todayPlus } from "@/lib/pocToday";

type LaunchSeed = {
  id: string;
  name: string;
  lob: LOB;
  region: Launch["region"];
  owner: string;
  /** Days from POC_TODAY → launchDate. Picked to spread today's position across the 360-day window. */
  launchOffsetDays: number;
  /** Days from POC_TODAY → nextMilestoneDate (always inside the current phase). */
  milestoneOffsetDays: number;
  progress: number;
  rag: RAG;
  /** Legacy `phase` field — set to the current SChM phase given the offset. */
  phase: Phase;
  nextMilestone: string;
};

const LAUNCH_SEEDS: LaunchSeed[] = [
  // GREEN platforms — all four tracks green.
  { id: "L-2001", name: "Hyperion RPL-S",           lob: "DT",   region: "NA",    owner: "Priya Shah",      launchOffsetDays:  -14, milestoneOffsetDays:  16, progress: 96, rag: "green", phase: "Launch",  nextMilestone: "Launch exit review"        },
  { id: "L-2012", name: "U40 Conference",           lob: "DnCP", region: "NA",    owner: "Jordan Nguyen",   launchOffsetDays:    8, milestoneOffsetDays:  38, progress: 90, rag: "green", phase: "Launch",  nextMilestone: "Retail listing live"       },
  { id: "L-2007", name: "Formula Rossa NVL CS 1",   lob: "NB",   region: "EMEA",  owner: "Camila Souza",    launchOffsetDays:   31, milestoneOffsetDays:  61, progress: 83, rag: "green", phase: "Launch",  nextMilestone: "Channel enablement"        },
  { id: "L-2005", name: "Vesta-P INT WCLR 24 AIO",  lob: "DT",   region: "EMEA",  owner: "Lena Vogel",      launchOffsetDays:   52, milestoneOffsetDays:  82, progress: 77, rag: "green", phase: "Launch",  nextMilestone: "Pilot exit review"         },
  { id: "L-2011", name: "U2726DER",                 lob: "DnCP", region: "EMEA",  owner: "Elena Marchetti", launchOffsetDays:   74, milestoneOffsetDays: 104, progress: 71, rag: "green", phase: "Launch",  nextMilestone: "Color calibration QA"      },

  // AMBER platforms — Core + all tracks at-risk-mitigated.
  { id: "L-2002", name: "Citadel NVL",              lob: "DT",   region: "EMEA",  owner: "Marcus Lee",      launchOffsetDays:   96, milestoneOffsetDays:   6, progress: 65, rag: "amber", phase: "Develop", nextMilestone: "Develop exit review"       },
  { id: "L-2006", name: "Prowler NVL CS 16",        lob: "NB",   region: "NA",    owner: "Daniel Reyes",    launchOffsetDays:  118, milestoneOffsetDays:  28, progress: 59, rag: "amber", phase: "Develop", nextMilestone: "Pricing approval"          },
  { id: "L-2015", name: "P2226H",                   lob: "DnCP", region: "EMEA",  owner: "Felix Bauer",     launchOffsetDays:  140, milestoneOffsetDays:  50, progress: 53, rag: "amber", phase: "Develop", nextMilestone: "Reg compliance sign-off"   },
  { id: "L-2008", name: "Rapterra AMD CS 16",       lob: "NB",   region: "APJ",   owner: "Aisha Khan",      launchOffsetDays:  162, milestoneOffsetDays:  12, progress: 47, rag: "amber", phase: "Plan",    nextMilestone: "Plan exit review"          },
  { id: "L-2013", name: "AQ2426HL",                 lob: "DnCP", region: "APJ",   owner: "Yuki Sato",       launchOffsetDays:  184, milestoneOffsetDays:  34, progress: 41, rag: "amber", phase: "Plan",    nextMilestone: "Panel sourcing lock"       },

  // RED platforms — Core + all tracks at-risk.
  { id: "L-2003", name: "Siple Low INT NVL S1",     lob: "DT",   region: "APJ",   owner: "Hiroshi Tanaka",  launchOffsetDays:  206, milestoneOffsetDays:  56, progress: 34, rag: "red",   phase: "Plan",    nextMilestone: "Plan exit review"          },
  { id: "L-2004", name: "Makalu-W INT NVL M2",      lob: "DT",   region: "NA",    owner: "Sara Okafor",     launchOffsetDays:  228, milestoneOffsetDays:  18, progress: 28, rag: "red",   phase: "Define",  nextMilestone: "Define exit review"        },
  { id: "L-2010", name: "Volta NVL CS 14",          lob: "NB",   region: "LATAM", owner: "Mateo Alvarez",   launchOffsetDays:  250, milestoneOffsetDays:  40, progress: 22, rag: "red",   phase: "Define",  nextMilestone: "Supplier RFQ close"        },
  { id: "L-2014", name: "S2426HS",                  lob: "DnCP", region: "NA",    owner: "Olivia Park",     launchOffsetDays:  272, milestoneOffsetDays:   2, progress: 16, rag: "red",   phase: "Concept", nextMilestone: "Concept gate review"       },
  { id: "L-2009", name: "Battlestar CS 18",         lob: "NB",   region: "NA",    owner: "Noah Bennett",    launchOffsetDays:  294, milestoneOffsetDays:  24, progress: 10, rag: "red",   phase: "Concept", nextMilestone: "Concept gate review"       },
];

export const launches: Launch[] = LAUNCH_SEEDS.map((s) => ({
  id: s.id,
  name: s.name,
  product: s.name,
  lob: s.lob,
  region: s.region,
  owner: s.owner,
  phase: s.phase,
  rag: s.rag,
  progress: s.progress,
  nextMilestone: s.nextMilestone,
  nextMilestoneDate: todayPlus(s.milestoneOffsetDays),
  launchDate: todayPlus(s.launchOffsetDays),
}));


/**
 * PG (Program) status snapshots — pulled from Jira PG dashboard.
 * Layered onto launches below. Read-only across the app.
 * `syncedAt` is anchored ~8 hours before "now" so the snapshot always feels fresh.
 */
const SYNCED_AT: string = new Date(POC_TODAY.getTime() + 8 * 60 * 60 * 1000).toISOString();

const PG_SEEDS: Record<string, PgStatusBlock> = {
  "L-2001": {
    jiraKey: "PG-DT-HYP-2026", syncedAt: SYNCED_AT,
    overallReason: "Marketing creative pending sign-off; otherwise on track.",
    escalation: ["Priya Shah (GOE Lead)", "R. Mehta (PG Owner)", "J. Patel (Exec Sponsor)"],
    components: [
      { id: "c1", name: "Marketing",  rag: "amber", reason: "Launch creative review running late by 3 days.", owner: "Lina Costa" },
      { id: "c2", name: "Core Team",  rag: "green", owner: "R. Mehta" },
      { id: "c3", name: "Quality",    rag: "green", owner: "K. Iyer" },
      { id: "c4", name: "Regulatory", rag: "green", owner: "T. Brooks" },
    ],
  },
  "L-2002": {
    jiraKey: "PG-DT-CIT-2026", syncedAt: SYNCED_AT,
    overallReason: "EU cyber cert delay puts launch readiness at risk.",
    escalation: ["Marcus Lee (GOE Lead)", "S. Park (PG Owner)", "J. Patel (Exec Sponsor)"],
    components: [
      { id: "c1", name: "Regulatory", rag: "red",   reason: "EU CRA certification slipping ~2 weeks.", owner: "T. Brooks" },
      { id: "c2", name: "Marketing",  rag: "amber", reason: "Holding creative until cert dates confirm.",   owner: "Lina Costa" },
      { id: "c3", name: "Core Team",  rag: "amber", reason: "Re-baselining schedule.",                       owner: "S. Park" },
      { id: "c4", name: "Quality",    rag: "green", owner: "K. Iyer" },
    ],
  },
  "L-2003": {
    jiraKey: "PG-DT-SIP-2026", syncedAt: SYNCED_AT,
    overallReason: "Firmware regression blocking Develop exit; multiple components red.",
    escalation: ["Hiroshi Tanaka (GOE Lead)", "S. Park (PG Owner)", "J. Patel (Exec Sponsor)"],
    components: [
      { id: "c1", name: "Core Team",  rag: "red",   reason: "Firmware NVMe regression; no fix ETA.",          owner: "S. Park" },
      { id: "c2", name: "Quality",    rag: "red",   reason: "Cannot enter QPE until regression cleared.",     owner: "K. Iyer" },
      { id: "c3", name: "Marketing",  rag: "amber", reason: "Holding asset production.",                       owner: "Lina Costa" },
      { id: "c4", name: "Regulatory", rag: "green", owner: "T. Brooks" },
    ],
  },
  "L-2004": {
    jiraKey: "PG-DT-MAK-2026", syncedAt: SYNCED_AT,
    escalation: ["Sara Okafor (GOE Lead)", "R. Mehta (PG Owner)"],
    components: [
      { id: "c1", name: "Marketing",  rag: "green", owner: "Lina Costa" },
      { id: "c2", name: "Core Team",  rag: "green", owner: "R. Mehta" },
      { id: "c3", name: "Quality",    rag: "green", owner: "K. Iyer" },
      { id: "c4", name: "Regulatory", rag: "green", owner: "T. Brooks" },
    ],
  },
  "L-2005": {
    jiraKey: "PG-DT-VES-2026", syncedAt: SYNCED_AT,
    escalation: ["Lena Vogel (GOE Lead)", "R. Mehta (PG Owner)"],
    components: [
      { id: "c1", name: "Marketing",  rag: "green", owner: "Lina Costa" },
      { id: "c2", name: "Core Team",  rag: "green", owner: "R. Mehta" },
      { id: "c3", name: "Quality",    rag: "green", owner: "K. Iyer" },
    ],
  },
  "L-2006": {
    jiraKey: "PG-NB-PRO-2026", syncedAt: SYNCED_AT,
    overallReason: "Pricing approval pending; channel comms not finalized.",
    escalation: ["Daniel Reyes (GOE Lead)", "R. Mehta (PG Owner)"],
    components: [
      { id: "c1", name: "Finance",    rag: "amber", reason: "Pricing approval pending exec review.",          owner: "M. Davies" },
      { id: "c2", name: "Marketing",  rag: "amber", reason: "Channel comms blocked on pricing.",              owner: "Lina Costa" },
      { id: "c3", name: "Core Team",  rag: "amber", owner: "R. Mehta" },
      { id: "c4", name: "Quality",    rag: "green", owner: "K. Iyer" },
    ],
  },
  "L-2007": {
    jiraKey: "PG-NB-FRA-2026", syncedAt: SYNCED_AT,
    escalation: ["Camila Souza (GOE Lead)", "R. Mehta (PG Owner)"],
    components: [
      { id: "c1", name: "Marketing",  rag: "green", owner: "Lina Costa" },
      { id: "c2", name: "Core Team",  rag: "green", owner: "R. Mehta" },
      { id: "c3", name: "Quality",    rag: "green", owner: "K. Iyer" },
    ],
  },
  "L-2008": {
    jiraKey: "PG-NB-RAP-2026", syncedAt: SYNCED_AT,
    overallReason: "Beta customer slot unconfirmed; thermal validation in progress.",
    escalation: ["Aisha Khan (GOE Lead)", "S. Park (PG Owner)"],
    components: [
      { id: "c1", name: "Core Team",  rag: "amber", reason: "Beta customer slot unconfirmed.",                 owner: "S. Park" },
      { id: "c2", name: "Quality",    rag: "amber", reason: "Thermal validation underway.",                    owner: "K. Iyer" },
      { id: "c3", name: "Marketing",  rag: "green", owner: "Lina Costa" },
    ],
  },
  "L-2009": {
    jiraKey: "PG-NB-BAT-2026", syncedAt: SYNCED_AT,
    escalation: ["Noah Bennett (GOE Lead)", "R. Mehta (PG Owner)"],
    components: [
      { id: "c1", name: "Core Team",  rag: "green", owner: "R. Mehta" },
      { id: "c2", name: "Marketing",  rag: "green", owner: "Lina Costa" },
    ],
  },
  "L-2010": {
    jiraKey: "PG-NB-VOL-2026", syncedAt: SYNCED_AT,
    escalation: ["Mateo Alvarez (GOE Lead)", "R. Mehta (PG Owner)"],
    components: [
      { id: "c1", name: "Core Team",  rag: "green", owner: "R. Mehta" },
      { id: "c2", name: "Marketing",  rag: "green", owner: "Lina Costa" },
      { id: "c3", name: "Quality",    rag: "green", owner: "K. Iyer" },
    ],
  },
  "L-2011": {
    jiraKey: "PG-DP-U27-2026", syncedAt: SYNCED_AT,
    escalation: ["Elena Marchetti (GOE Lead)", "R. Mehta (PG Owner)"],
    components: [
      { id: "c1", name: "Marketing",  rag: "green", owner: "Lina Costa" },
      { id: "c2", name: "Core Team",  rag: "green", owner: "R. Mehta" },
      { id: "c3", name: "Quality",    rag: "green", owner: "K. Iyer" },
    ],
  },
  "L-2012": {
    jiraKey: "PG-DP-U40-2026", syncedAt: SYNCED_AT,
    escalation: ["Jordan Nguyen (GOE Lead)", "R. Mehta (PG Owner)"],
    components: [
      { id: "c1", name: "Marketing",  rag: "green", owner: "Lina Costa" },
      { id: "c2", name: "Core Team",  rag: "green", owner: "R. Mehta" },
    ],
  },
  "L-2013": {
    jiraKey: "PG-DP-AQ2-2026", syncedAt: SYNCED_AT,
    overallReason: "Panel sourcing risk; marketing planning unaffected.",
    escalation: ["Yuki Sato (GOE Lead)", "S. Park (PG Owner)"],
    components: [
      { id: "c1", name: "Supply",     rag: "amber", reason: "Panel sourcing lock at risk; dual-sourcing in flight.", owner: "M. Davies" },
      { id: "c2", name: "Core Team",  rag: "amber", owner: "S. Park" },
      { id: "c3", name: "Marketing",  rag: "green", owner: "Lina Costa" },
    ],
  },
  "L-2014": {
    jiraKey: "PG-DP-S24-2026", syncedAt: SYNCED_AT,
    escalation: ["Olivia Park (GOE Lead)", "R. Mehta (PG Owner)"],
    components: [
      { id: "c1", name: "Core Team",  rag: "green", owner: "R. Mehta" },
      { id: "c2", name: "Marketing",  rag: "green", owner: "Lina Costa" },
    ],
  },
  "L-2015": {
    jiraKey: "PG-DP-P22-2026", syncedAt: SYNCED_AT,
    overallReason: "EOL inventory overhang plus reg sign-off slip.",
    escalation: ["Felix Bauer (GOE Lead)", "S. Park (PG Owner)"],
    components: [
      { id: "c1", name: "Supply",     rag: "red",   reason: "EOL inventory overhang in EMEA.",                owner: "M. Davies" },
      { id: "c2", name: "Regulatory", rag: "amber", reason: "Reg compliance sign-off slipping.",              owner: "T. Brooks" },
      { id: "c3", name: "Marketing",  rag: "amber", owner: "Lina Costa" },
      { id: "c4", name: "Core Team",  rag: "amber", owner: "S. Park" },
    ],
  },
};

for (const l of launches) {
  if (PG_SEEDS[l.id]) (l as Launch).pg = PG_SEEDS[l.id];
}

// Milestone dates anchored to today so the timeline always feels fresh.
export const milestones: Milestone[] = [
  { id: "M1", launchId: "L-2001", name: "Channel enablement",      date: todayPlus(  2), status: "in_progress" },
  { id: "M2", launchId: "L-2002", name: "Reg compliance sign-off", date: todayPlus( -1), status: "at_risk"     },
  { id: "M3", launchId: "L-2003", name: "Firmware freeze",         date: todayPlus( -6), status: "at_risk"     },
  { id: "M4", launchId: "L-2006", name: "Pricing approval",        date: todayPlus( -4), status: "in_progress" },
  { id: "M5", launchId: "L-2011", name: "Color calibration QA",    date: todayPlus(  6), status: "upcoming"    },
  { id: "M6", launchId: "L-2008", name: "Beta customer kickoff",   date: todayPlus(  8), status: "upcoming"    },
  { id: "M7", launchId: "L-2011", name: "Panel sourcing",          date: todayPlus( -7), status: "complete"    },
];

// Task due dates anchored to today: mix of slightly overdue and upcoming.
export const tasks: TaskItem[] = [
  { id: "T-201", title: "Approve Hyperion RPL-S launch comms",     launch: "Hyperion RPL-S",         type: "approval", priority: "high",   due: todayPlus( -7), assignee: "You" },
  { id: "T-202", title: "Review Citadel NVL risk register",        launch: "Citadel NVL",            type: "review",   priority: "high",   due: todayPlus( -6), assignee: "You" },
  { id: "T-203", title: "Decision: Siple firmware slip",           launch: "Siple Low INT NVL S1",   type: "decision", priority: "high",   due: todayPlus( -8), assignee: "You" },
  { id: "T-204", title: "Pricing approval — Prowler NVL CS 16",    launch: "Prowler NVL CS 16",      type: "approval", priority: "medium", due: todayPlus( -4), assignee: "You" },
  { id: "T-205", title: "Input needed: Makalu-W BOM",              launch: "Makalu-W INT NVL M2",    type: "input",    priority: "medium", due: todayPlus(  0), assignee: "You" },
  { id: "T-206", title: "Review U40 Conference retail assets",     launch: "U40 Conference",         type: "review",   priority: "low",    due: todayPlus(  3), assignee: "You" },
];

// Risk raised dates anchored to recent past.
export const risks: Risk[] = [
  { id: "R-301", launch: "Siple Low INT NVL S1",   title: "Firmware regression on NVMe path",     severity: "critical", owner: "Hiroshi Tanaka",  raisedDate: todayPlus(-12) },
  { id: "R-302", launch: "Citadel NVL",            title: "EU cybersecurity certification delay", severity: "high",     owner: "Marcus Lee",      raisedDate: todayPlus(-11) },
  { id: "R-303", launch: "Prowler NVL CS 16",      title: "Margin below threshold in EMEA",       severity: "high",     owner: "Daniel Reyes",    raisedDate: todayPlus(-10) },
  { id: "R-304", launch: "Rapterra AMD CS 16",     title: "Beta customer slot unconfirmed",       severity: "medium",   owner: "Aisha Khan",      raisedDate: todayPlus( -9) },
  { id: "R-305", launch: "P2226H",                 title: "EOL inventory overhang in EMEA",       severity: "high",     owner: "Felix Bauer",     raisedDate: todayPlus(-13) },
];


export const activity: Activity[] = [
  { id: "A1", actor: "Priya Shah",      kind: "phase_change",       launchId: "L-2001",                   timestamp: "2h ago" },
  { id: "A2", actor: "Marcus Lee",      kind: "risk_raised",        launchId: "L-2002", refId: "R-302",   timestamp: "4h ago" },
  { id: "A3", actor: "Hiroshi Tanaka",  kind: "decision_request",   launchId: "L-2003", refId: "T-203",   timestamp: "6h ago" },
  { id: "A4", actor: "Daniel Reyes",    kind: "approval_submitted", launchId: "L-2006", refId: "T-204",   timestamp: "Yesterday" },
  { id: "A5", actor: "Elena Marchetti", kind: "milestone_done",     launchId: "L-2011", refId: "M7",      timestamp: "Yesterday" },
  { id: "A6", actor: "Sara Okafor",     kind: "launch_kickoff",     launchId: "L-2004",                   timestamp: "2d ago" },
];

export const kpis = {
  inFlight: launches.length,
  onTrackPct: Math.round((launches.filter(l => l.rag === "green").length / launches.length) * 100),
  blockers: risks.filter(r => r.severity === "critical" || r.severity === "high").length,
  upcomingGates: milestones.filter(m => m.status === "in_progress" || m.status === "upcoming" || m.status === "at_risk").length,
};
