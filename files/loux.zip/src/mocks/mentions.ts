import { launches } from "@/mocks/launches";

export interface Mention {
  id: string;
  actor: string;
  snippet: string;
  context: string;
  href: string;
  ts: number;
  launchId?: string;
}

const HOUR = 3_600_000;
const NOW = Date.now();

const SEEDS: Array<Omit<Mention, "id" | "ts" | "href" | "context" | "launchId"> & { launchIndex: number; hoursAgo: number }> = [
  { actor: "Priya Shah",      snippet: "@you can you confirm the launch exit review date?",        launchIndex: 0, hoursAgo: 1 },
  { actor: "Marcus Lee",      snippet: "@you flagging the Develop exit slip — please weigh in.",   launchIndex: 5, hoursAgo: 4 },
  { actor: "Aisha Khan",      snippet: "@you need your sign-off on the Plan exit review.",         launchIndex: 8, hoursAgo: 9 },
  { actor: "Jordan Nguyen",   snippet: "@you retail listing copy ready for review.",               launchIndex: 1, hoursAgo: 22 },
  { actor: "Camila Souza",    snippet: "@you channel enablement deck attached — feedback?",        launchIndex: 2, hoursAgo: 30 },
];

const MENTIONS: Mention[] = SEEDS.map((s, i) => {
  const l = launches[s.launchIndex];
  return {
    id: `m-${i + 1}`,
    actor: s.actor,
    snippet: s.snippet,
    context: l ? `${l.name} · ${l.nextMilestone}` : "Platform",
    href: l ? `/tasks?tab=platform&launch=${l.id}` : "/",
    ts: NOW - s.hoursAgo * HOUR,
    launchId: l?.id,
  };
}).filter((m) => m.launchId);

export function getMentions(): Mention[] {
  return MENTIONS;
}
