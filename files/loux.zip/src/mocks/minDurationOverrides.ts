// Per-task minimum-duration overrides. Admins set them in the task drawer.
// Keyed by task.id so launch-specific overrides don't bleed across launches.

export interface MinDurationOverride {
  taskId: string;
  days: number;
  reason: string;
  by: string;
  at: number;
}

const overrides = new Map<string, MinDurationOverride>();
const listeners = new Set<() => void>();

function notify() { for (const l of listeners) l(); }

export function subscribeMinDuration(fn: () => void): () => void {
  listeners.add(fn);
  return () => listeners.delete(fn);
}

export function getMinDurationOverride(taskId: string): MinDurationOverride | undefined {
  return overrides.get(taskId);
}

export function setMinDurationOverride(input: {
  taskId: string;
  days: number;
  reason: string;
  by: string;
}): MinDurationOverride {
  const entry: MinDurationOverride = { ...input, at: Date.now() };
  overrides.set(input.taskId, entry);
  notify();
  return entry;
}

export function clearMinDurationOverride(taskId: string) {
  overrides.delete(taskId);
  notify();
}
