// Derives upcoming-date triggers from the NUDD records. A trigger is raised
// when one of the key target dates on an Open / On-hold NUDD falls within the
// configured horizon. PoC only — acknowledgements are session-local.

import { NUDDS, type NuddRow } from "@/mocks/nudds";

export type NuddTriggerSeverity = "danger" | "warn" | "info";

export interface NuddTrigger {
  id: string;
  nuddId: string;
  title: string;
  platform: string;
  lob: string;
  dateLabel: string;
  dateIso: string;
  daysUntil: number;
  severity: NuddTriggerSeverity;
}

const HORIZON_DAYS = 45;
const ackd = new Set<string>();
const listeners = new Set<() => void>();

const notify = () => listeners.forEach((l) => l());

export function subscribeNuddTriggers(fn: () => void): () => void {
  listeners.add(fn);
  return () => listeners.delete(fn);
}

// "12/May/26" → ISO yyyy-mm-dd
function parseDdMmmYy(s: string | undefined): string | null {
  if (!s) return null;
  const head = s.split(" ")[0];
  const m = head.match(/^(\d{1,2})\/([A-Za-z]{3})\/(\d{2})$/);
  if (!m) return null;
  const months = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
  const mi = months.indexOf(m[2]);
  if (mi < 0) return null;
  const yyyy = 2000 + parseInt(m[3], 10);
  return `${yyyy}-${String(mi + 1).padStart(2, "0")}-${m[1].padStart(2, "0")}`;
}

const WATCHED: Array<{ key: keyof NuddRow["dates"]; label: string }> = [
  { key: "conceptExitTarget", label: "Concept exit" },
  { key: "defineExitTarget", label: "Define exit" },
  { key: "baTarget", label: "BA target" },
  { key: "ddsTarget", label: "DDS target" },
  { key: "planExitTarget", label: "Plan exit" },
  { key: "rfdTarget", label: "RFD" },
  { key: "developExitTarget", label: "Develop exit" },
  { key: "rtsTarget", label: "RTS" },
  { key: "rtoTarget", label: "RTO" },
];

function severityFor(days: number): NuddTriggerSeverity {
  if (days <= 0) return "danger";
  if (days <= 7) return "danger";
  if (days <= 21) return "warn";
  return "info";
}

export function getNuddTriggers(): NuddTrigger[] {
  const now = Date.now();
  const triggers: NuddTrigger[] = [];
  for (const n of NUDDS) {
    if (n.status === "Completed") continue;
    for (const w of WATCHED) {
      const iso = parseDdMmmYy(n.dates[w.key]);
      if (!iso) continue;
      const t = new Date(iso + "T09:00:00").getTime();
      const days = Math.round((t - now) / 86400000);
      if (days > HORIZON_DAYS) continue;
      const id = `${n.id}:${w.key}`;
      if (ackd.has(id)) continue;
      triggers.push({
        id,
        nuddId: n.id,
        title: n.title,
        platform: n.platform,
        lob: n.lob,
        dateLabel: w.label,
        dateIso: iso,
        daysUntil: days,
        severity: severityFor(days),
      });
    }
  }
  // Sort by urgency (overdue first, then closest)
  triggers.sort((a, b) => a.daysUntil - b.daysUntil);
  return triggers;
}

export function ackNuddTrigger(id: string) {
  ackd.add(id);
  notify();
}

export function unackAllNuddTriggers() {
  ackd.clear();
  notify();
}
