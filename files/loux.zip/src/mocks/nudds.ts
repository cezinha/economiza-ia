import { computeNuddDates } from "@/lib/nuddDates";

export type NuddStatus = "Open" | "On hold" | "Completed";
export type Score = 1 | 2 | 3;

export type NuddRow = {
  id: string;
  title: string;
  lob: string;
  platform: string;
  impact: Score;
  probability: Score;
  status: NuddStatus;
  created: string;
  updated: string;
  closeDate: string;

  // Details
  type: string;
  resolution: string;
  labels: string[];
  programName: string;
  programState: string;
  domainBusiness: string;
  programCategory: string;
  platformModelId: string;
  predecessor: string;
  formFactor: string;
  programClass: string;
  programPhase: string;
  tier: string;
  cpuArchitecture: string;
  odmSupplier: string;
  rtsCalendar: { year: string; quarter: string; month: string };
  rtoCalendar: { year: string; quarter: string; month: string };

  people: {
    assignee: string;
    reporter: string;
    programManager: string;
    projectManager: string;
    engineers: string[];
    qualityEngineer: string;
    procurement: string;
    services: string[];
    goe: string;
    edg: string;
  };

  dates: {
    created: string;
    updated: string;
    conceptEntryTarget: string;
    conceptExitTarget: string;
    defineExitTarget: string;
    baTarget: string;
    ddsTarget: string;
    planExitTarget: string;
    rfdTarget: string;
    developExitTarget: string;
    rtsTarget: string;
    rtoTarget: string;
  };
};

const baseDates: NuddRow["dates"] = {
  created: "22/Jan/26 5:26 PM",
  updated: "10/Apr/26 9:12 PM",
  conceptEntryTarget: "12/May/26",
  conceptExitTarget: "15/Jul/26",
  defineExitTarget: "15/Jul/26",
  baTarget: "26/Aug/26",
  ddsTarget: "15/Jul/26",
  planExitTarget: "07/Oct/26",
  rfdTarget: "31/Mar/27",
  developExitTarget: "07/Apr/27",
  rtsTarget: "21/Apr/27",
  rtoTarget: "27/Apr/27",
};

const basePeople: NuddRow["people"] = {
  assignee: "Wang, Jeff C",
  reporter: "Wang, Jeff",
  programManager: "Wang, Jeff",
  projectManager: "Wang, Jeff",
  engineers: ["Kacelenga, Ray", "Mckittrick, Allen", "Wu, Patrick"],
  qualityEngineer: "Thakur, Sunny",
  procurement: "Mesfin, Ted",
  services: ["McMillian, Herbert", "Shih, Daniel"],
  goe: "Nanry, Bill",
  edg: "Draca, Boris",
};

type RawNudd = NuddRow & {
  overrideDates?: {
    createdISO: string;
    updatedISO: string;
    closeISO: string;
    createdDrawer: string;
    updatedDrawer: string;
  };
};

const RAW_NUDDS: RawNudd[] = [
  {
    id: "NUDD-1042",
    title: "Firmware regression on NVMe path",
    lob: "DT",
    platform: "Siple Low INT NVL S1",
    impact: 3,
    probability: 3,
    status: "Open",
    created: "2026-04-22",
    updated: "2026-05-08",
    closeDate: "2026-05-30",
    type: "RTS Metrics",
    resolution: "Unresolved",
    labels: [],
    programName: "Siple Low INT",
    programState: "Active",
    domainBusiness: "PC-Commercial",
    programCategory: "Dell Pro Precision Laptops",
    platformModelId: "MB18270",
    predecessor: "Kingda Ka ARL-HX CS 18",
    formFactor: "CS",
    programClass: "4",
    programPhase: "Plan",
    tier: "1",
    cpuArchitecture: "NVL",
    odmSupplier: "Compal",
    rtsCalendar: { year: "CY27", quarter: "Q1", month: "Feb" },
    rtoCalendar: { year: "CY27", quarter: "Q1", month: "Mar" },
    people: basePeople,
    dates: { ...baseDates, created: "22/Apr/26 5:26 PM", updated: "08/May/26 9:12 PM" },
  },
  {
    id: "NUDD-1039",
    title: "EU cybersecurity certification delay",
    lob: "DT",
    platform: "Citadel NVL",
    impact: 3,
    probability: 2,
    status: "Open",
    created: "2026-04-18",
    updated: "2026-05-09",
    closeDate: "2026-06-12",
    type: "RTS Metrics",
    resolution: "Unresolved",
    labels: ["compliance", "EU"],
    programName: "Citadel",
    programState: "Active",
    domainBusiness: "PC-Commercial",
    programCategory: "Dell Pro Notebooks",
    platformModelId: "MB18341",
    predecessor: "Citadel ARL-HX",
    formFactor: "NB",
    programClass: "3",
    programPhase: "Plan",
    tier: "1",
    cpuArchitecture: "NVL",
    odmSupplier: "Quanta",
    rtsCalendar: { year: "CY26", quarter: "Q4", month: "Nov" },
    rtoCalendar: { year: "CY27", quarter: "Q1", month: "Jan" },
    people: { ...basePeople, assignee: "Marcus Lee" },
    dates: { ...baseDates, created: "18/Apr/26 9:00 AM", updated: "09/May/26 4:11 PM" },
  },
  {
    id: "NUDD-1037",
    title: "Margin below threshold in EMEA",
    lob: "NB",
    platform: "Prowler NVL CS 16",
    impact: 2,
    probability: 3,
    status: "On hold",
    created: "2026-04-15",
    updated: "2026-05-10",
    closeDate: "2026-05-22",
    type: "RTS Metrics",
    resolution: "Unresolved",
    labels: ["finance"],
    programName: "Prowler",
    programState: "Active",
    domainBusiness: "PC-Commercial",
    programCategory: "Alienware Laptops",
    platformModelId: "AA18350",
    predecessor: "Prowler ARL-HX CS 16",
    formFactor: "CS",
    programClass: "4",
    programPhase: "Plan",
    tier: "1",
    cpuArchitecture: "NVL",
    odmSupplier: "Compal",
    rtsCalendar: { year: "CY27", quarter: "Q1", month: "Feb" },
    rtoCalendar: { year: "CY27", quarter: "Q1", month: "Mar" },
    people: { ...basePeople, assignee: "Daniel Reyes" },
    dates: { ...baseDates, created: "15/Apr/26 11:42 AM", updated: "10/May/26 1:02 PM" },
  },
  {
    id: "NUDD-1031",
    title: "Beta customer slot unconfirmed",
    lob: "NB",
    platform: "Rapterra AMD CS 16",
    impact: 2,
    probability: 2,
    status: "On hold",
    created: "2026-05-04",
    updated: "2026-05-20",
    closeDate: "2026-06-18",
    type: "RTS Metrics",
    resolution: "Unresolved",
    labels: [],
    programName: "Rapterra",
    programState: "Active",
    domainBusiness: "PC-Consumer",
    programCategory: "Dell Pro Desktops",
    platformModelId: "MB18412",
    predecessor: "Rapterra Intel CS 16",
    formFactor: "CS",
    programClass: "3",
    programPhase: "Define",
    tier: "2",
    cpuArchitecture: "AMD",
    odmSupplier: "Wistron",
    rtsCalendar: { year: "CY27", quarter: "Q2", month: "Apr" },
    rtoCalendar: { year: "CY27", quarter: "Q2", month: "May" },
    people: { ...basePeople, assignee: "Aisha Khan" },
    dates: { ...baseDates, created: "04/May/26 8:14 AM", updated: "20/May/26 6:45 PM" },
    overrideDates: {
      createdISO: "2026-05-04",
      updatedISO: "2026-05-20",
      closeISO: "2026-06-18",
      createdDrawer: "04/May/26 8:14 AM",
      updatedDrawer: "20/May/26 6:45 PM",
    },
  } as RawNudd,

  {
    id: "NUDD-1028",
    title: "EOL inventory overhang in EMEA",
    lob: "DnCP",
    platform: "P2226H",
    impact: 3,
    probability: 3,
    status: "Open",
    created: "2026-03-28",
    updated: "2026-05-01",
    closeDate: "2026-05-02",
    type: "RTS Metrics",
    resolution: "Unresolved",
    labels: ["EOL", "EMEA"],
    programName: "P2226H Display",
    programState: "Active",
    domainBusiness: "Displays",
    programCategory: "Dell Professional Displays",
    platformModelId: "P2226H",
    predecessor: "P2225H",
    formFactor: "Display",
    programClass: "2",
    programPhase: "Qual",
    tier: "2",
    cpuArchitecture: "—",
    odmSupplier: "Wistron",
    rtsCalendar: { year: "CY26", quarter: "Q3", month: "Aug" },
    rtoCalendar: { year: "CY26", quarter: "Q3", month: "Sep" },
    people: { ...basePeople, assignee: "Felix Bauer" },
    dates: { ...baseDates, created: "28/Mar/26 10:30 AM", updated: "01/May/26 3:21 PM" },
  },
  {
    id: "NUDD-1024",
    title: "Supply chain capacity at risk",
    lob: "DT",
    platform: "Siple Low INT NVL S1",
    impact: 2,
    probability: 2,
    status: "Open",
    created: "2026-03-21",
    updated: "2026-05-05",
    closeDate: "2026-05-25",
    type: "RTS Metrics",
    resolution: "Unresolved",
    labels: ["supply"],
    programName: "Siple Low INT",
    programState: "Active",
    domainBusiness: "PC-Commercial",
    programCategory: "Dell Pro Precision Laptops",
    platformModelId: "MB18270",
    predecessor: "Kingda Ka ARL-HX CS 18",
    formFactor: "CS",
    programClass: "4",
    programPhase: "Concept",
    tier: "1",
    cpuArchitecture: "NVL",
    odmSupplier: "Compal",
    rtsCalendar: { year: "CY27", quarter: "Q1", month: "Feb" },
    rtoCalendar: { year: "CY27", quarter: "Q1", month: "Mar" },
    people: basePeople,
    dates: { ...baseDates, created: "21/Mar/26 2:18 PM", updated: "05/May/26 11:00 AM" },
  },
  {
    id: "NUDD-1019",
    title: "BIOS validation slipped one sprint",
    lob: "DT",
    platform: "Citadel NVL",
    impact: 1,
    probability: 2,
    status: "Completed",
    created: "2026-03-12",
    updated: "2026-04-23",
    closeDate: "2026-04-24",
    type: "RTS Metrics",
    resolution: "Done",
    labels: ["BIOS"],
    programName: "Citadel",
    programState: "Active",
    domainBusiness: "PC-Commercial",
    programCategory: "Dell Pro Notebooks",
    platformModelId: "MB18341",
    predecessor: "Citadel ARL-HX",
    formFactor: "NB",
    programClass: "3",
    programPhase: "Plan",
    tier: "1",
    cpuArchitecture: "NVL",
    odmSupplier: "Quanta",
    rtsCalendar: { year: "CY26", quarter: "Q4", month: "Nov" },
    rtoCalendar: { year: "CY27", quarter: "Q1", month: "Jan" },
    people: basePeople,
    dates: { ...baseDates, created: "12/Mar/26 9:50 AM", updated: "23/Apr/26 5:00 PM" },
  },
  {
    id: "NUDD-1011",
    title: "Thermal headroom miss on lid",
    lob: "NB",
    platform: "Prowler NVL CS 16",
    impact: 3,
    probability: 1,
    status: "Completed",
    created: "2026-02-26",
    updated: "2026-04-08",
    closeDate: "2026-04-09",
    type: "RTS Metrics",
    resolution: "Done",
    labels: ["thermal"],
    programName: "Prowler",
    programState: "Active",
    domainBusiness: "PC-Commercial",
    programCategory: "Alienware Laptops",
    platformModelId: "AA18350",
    predecessor: "Prowler ARL-HX CS 16",
    formFactor: "CS",
    programClass: "4",
    programPhase: "Plan",
    tier: "1",
    cpuArchitecture: "NVL",
    odmSupplier: "Compal",
    rtsCalendar: { year: "CY27", quarter: "Q1", month: "Feb" },
    rtoCalendar: { year: "CY27", quarter: "Q1", month: "Mar" },
    people: basePeople,
    dates: { ...baseDates, created: "26/Feb/26 1:08 PM", updated: "08/Apr/26 10:14 AM" },
  },
];

/**
 * Derive all date fields from the platform launch + programPhase so the mock
 * data always satisfies:
 *   - closeDate < platform Develop phase exit
 *   - updated < closeDate AND updated <= today
 *   - created < updated AND created within the GOE OLP phase span
 * See `src/lib/nuddDates.ts`.
 */
export const NUDDS: NuddRow[] = RAW_NUDDS.map((row) => {
  const d = row.overrideDates ?? computeNuddDates({
    platform: row.platform,
    programPhase: row.programPhase,
    status: row.status,
    seed: row.id,
  });
  const { overrideDates: _o, ...rest } = row;
  return {
    ...rest,
    created: d.createdISO,
    updated: d.updatedISO,
    closeDate: d.closeISO,
    dates: {
      ...row.dates,
      created: d.createdDrawer,
      updated: d.updatedDrawer,
    },
  };
});

