// Manual RYG confirmations on overdue tasks, with 72h auto-escalation to a
// manager. Pure mock state — no backend.

import { appendActivity } from "@/mocks/activityLog";
import { ALL_MANAGERS } from "@/mocks/people";

export type ConfirmRyg = "on-track" | "at-risk-mitigated" | "at-risk";

export interface OverdueConfirmation {
  taskId: string;
  status: ConfirmRyg;
  confirmedBy: string;
  confirmedAt: number;
  note?: string;
}

export interface OverdueEscalation {
  taskId: string;
  escalatedAt: number;
  escalatedTo: string;
}

export const REVIEW_WINDOW_MS = 72 * 60 * 60 * 1000;

const confirmations = new Map<string, OverdueConfirmation>();
const escalations = new Map<string, OverdueEscalation>();
const listeners = new Set<() => void>();

function notify() { for (const l of listeners) l(); }

export function subscribeOverdueConfirmations(fn: () => void): () => void {
  listeners.add(fn);
  return () => { listeners.delete(fn); };
}

export function getConfirmation(taskId: string): OverdueConfirmation | undefined {
  return confirmations.get(taskId);
}

export function getEscalation(taskId: string): OverdueEscalation | undefined {
  return escalations.get(taskId);
}

export function confirmOverdueStatus(input: {
  taskId: string;
  taskName: string;
  launchId: string;
  status: ConfirmRyg;
  confirmedBy: string;
  note?: string;
}): OverdueConfirmation {
  const rec: OverdueConfirmation = {
    taskId: input.taskId,
    status: input.status,
    confirmedBy: input.confirmedBy,
    confirmedAt: Date.now(),
    note: input.note,
  };
  confirmations.set(input.taskId, rec);
  // A fresh confirmation clears any prior escalation.
  escalations.delete(input.taskId);
  appendActivity({
    actor: input.confirmedBy,
    kind: "overdue_confirmed",
    launchId: input.launchId,
    refId: input.taskId,
    detail: `confirmed overdue status as ${labelFor(input.status)} on ${input.taskName}`,
  });
  notify();
  return rec;
}

/** Pick a deterministic manager for a task, used as the escalation target. */
export function managerForTask(taskId: string, launchId: string): string {
  const launchMgrs = ALL_MANAGERS.filter((m) => m.launchId === launchId);
  const pool = launchMgrs.length > 0 ? launchMgrs : ALL_MANAGERS;
  if (pool.length === 0) return "Program manager";
  let h = 2166136261;
  for (let i = 0; i < taskId.length; i++) {
    h ^= taskId.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return pool[(h >>> 0) % pool.length].name;
}

/** Lazily record escalation if review window has passed without confirmation. */
export function ensureEscalation(
  taskId: string,
  taskName: string,
  launchId: string,
  overdueSince: number,
): OverdueEscalation | undefined {
  if (confirmations.has(taskId)) return undefined;
  const existing = escalations.get(taskId);
  if (existing) return existing;
  if (Date.now() - overdueSince < REVIEW_WINDOW_MS) return undefined;
  const target = managerForTask(taskId, launchId);
  const rec: OverdueEscalation = {
    taskId,
    escalatedAt: Date.now(),
    escalatedTo: target,
  };
  escalations.set(taskId, rec);
  appendActivity({
    actor: "System",
    kind: "overdue_escalated",
    launchId,
    refId: taskId,
    detail: `auto-escalated overdue task ${taskName} to ${target} — no status review within 72h`,
  });
  // Notify on next tick so callers that triggered this during render aren't
  // re-entered synchronously.
  queueMicrotask(notify);
  return rec;
}

export function labelFor(s: ConfirmRyg): string {
  return s === "on-track"
    ? "On track"
    : s === "at-risk-mitigated"
      ? "At risk (mitigated)"
      : "At risk";
}
