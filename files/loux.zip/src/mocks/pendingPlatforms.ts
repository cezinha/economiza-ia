// Runtime store for inbound platforms from Jira awaiting admin confirmation.
// Mock-only: lives in memory; approving a request publishes the platform to
// the live `launches` array so it appears for everyone in scope.

import { launches as LIVE_LAUNCHES, type LOB, type Launch } from "@/mocks/launches";
import type { TaskFunction } from "@/lib/launchTasks";
import { appendActivity } from "@/mocks/activityLog";
import { todayPlus } from "@/lib/pocToday";

export type BusinessUnit = "CSG" | "ISG";

export type RequestSource = "jira" | "user";

export interface PendingPlatform {
  id: string;            // local id
  jiraKey: string;       // e.g. "GOE-1423" or "REQ-001"
  name: string;
  product: string;
  businessUnit: BusinessUnit;
  lob: LOB;
  function: TaskFunction;
  region: Launch["region"];
  proposedOwner: string;
  proposedLaunchDate: string; // ISO yyyy-mm-dd
  requestedBy: string;        // Jira reporter or user display name
  requestedAt: number;
  status: "pending" | "approved" | "rejected";
  source: RequestSource;
  rationale?: string;
  // Filled on approval:
  approvedOwner?: string;
  additionalAssignees?: string[];
  approvedAt?: number;
  rejectedReason?: string;
}

const seed: PendingPlatform[] = [
  {
    id: "pp-001",
    jiraKey: "GOE-1423",
    name: "Helios EVO 16 OLED",
    businessUnit: "CSG",
    product: "Helios EVO 16 OLED",
    lob: "DT",
    function: "GOE",
    region: "NA",
    proposedOwner: "Priya Shah",
    proposedLaunchDate: todayPlus(176),
    requestedBy: "Jira",
    requestedAt: Date.now() - 1000 * 60 * 60 * 6,
    status: "pending",
    source: "jira",
  },
  {
    id: "pp-002",
    jiraKey: "GOE-1431",
    name: "Cascade NB 14 Air",
    businessUnit: "CSG",
    product: "Cascade NB 14 Air",
    lob: "NB",
    function: "GOE",
    region: "EMEA",
    proposedOwner: "Marcus Lee",
    proposedLaunchDate: todayPlus(247),
    requestedBy: "Jira",
    requestedAt: Date.now() - 1000 * 60 * 60 * 28,
    status: "pending",
    source: "jira",
  },
  {
    id: "pp-003",
    jiraKey: "GOE-1448",
    name: "Aurora DnCP Edge 7",
    businessUnit: "CSG",
    product: "Aurora DnCP Edge 7",
    lob: "DnCP",
    function: "GOE",
    region: "APJ",
    proposedOwner: "Hiroshi Tanaka",
    proposedLaunchDate: todayPlus(260),
    requestedBy: "Jira",
    requestedAt: Date.now() - 1000 * 60 * 60 * 52,
    status: "pending",
    source: "jira",
  },
  {
    id: "pp-004",
    jiraKey: "GOE-1457",
    name: "Titan CSG NB 15",
    businessUnit: "CSG",
    product: "Titan CSG NB 15",
    lob: "NB",
    function: "GOE",
    region: "NA",
    proposedOwner: "Elena Rossi",
    proposedLaunchDate: todayPlus(290),
    requestedBy: "Jira",
    requestedAt: Date.now() - 1000 * 60 * 60 * 73,
    status: "pending",
    source: "jira",
  },
  {
    id: "pp-005",
    jiraKey: "GOE-1462",
    name: "Nimbus DT Slim 13",
    businessUnit: "CSG",
    product: "Nimbus DT Slim 13",
    lob: "DT",
    function: "GOE",
    region: "EMEA",
    proposedOwner: "Owen Becker",
    proposedLaunchDate: todayPlus(305),
    requestedBy: "Jira",
    requestedAt: Date.now() - 1000 * 60 * 60 * 96,
    status: "pending",
    source: "jira",
  },
];

const store: PendingPlatform[] = [...seed];
const newlyPublished = new Set<string>(); // launchId — for "New from Jira" badge
const listeners = new Set<() => void>();
const launchListeners = new Set<() => void>();

function notify() { for (const l of listeners) l(); }
function notifyLaunches() { for (const l of launchListeners) l(); }

export function subscribePendingPlatforms(fn: () => void): () => void {
  listeners.add(fn);
  return () => { listeners.delete(fn); };
}

/** Subscribe to "live launches" mutations (new platforms published). */
export function subscribeLaunchUpdates(fn: () => void): () => void {
  launchListeners.add(fn);
  return () => { launchListeners.delete(fn); };
}

export function getPendingPlatforms(): PendingPlatform[] {
  return store.filter((p) => p.status === "pending");
}

export function getAllPlatformRequests(): PendingPlatform[] {
  return [...store].sort((a, b) => b.requestedAt - a.requestedAt);
}

export function isNewlyPublished(launchId: string): boolean {
  return newlyPublished.has(launchId);
}

function nextLaunchId(): string {
  let n = 9000;
  const taken = new Set(LIVE_LAUNCHES.map((l) => l.id));
  while (taken.has(`L-${n}`)) n += 1;
  return `L-${n}`;
}

export interface ApproveInput {
  pendingId: string;
  approvedBy: string;
  owner: string;
  additionalAssignees: string[];
  launchDate: string;
}

export function approvePendingPlatform(input: ApproveInput): Launch | null {
  const p = store.find((x) => x.id === input.pendingId);
  if (!p || p.status !== "pending") return null;

  const launch: Launch = {
    id: nextLaunchId(),
    name: p.name,
    product: p.product,
    lob: p.lob,
    region: p.region,
    owner: input.owner,
    phase: "Concept",
    rag: "green",
    progress: 0,
    nextMilestone: "Concept review",
    nextMilestoneDate: input.launchDate,
    launchDate: input.launchDate,
  };
  LIVE_LAUNCHES.push(launch);
  newlyPublished.add(launch.id);
  // Auto-expire the "New" tag after 5 minutes (for the live demo session).
  setTimeout(() => { newlyPublished.delete(launch.id); notifyLaunches(); }, 5 * 60 * 1000);

  p.status = "approved";
  p.approvedOwner = input.owner;
  p.additionalAssignees = input.additionalAssignees;
  p.approvedAt = Date.now();

  appendActivity({
    actor: input.approvedBy,
    kind: "launch_kickoff",
    launchId: launch.id,
    detail: `Approved from Jira ${p.jiraKey} · owner ${input.owner}${
      input.additionalAssignees.length ? ` · +${input.additionalAssignees.length} assignees` : ""
    }`,
  });

  notify();
  notifyLaunches();
  return launch;
}

export function rejectPendingPlatform(
  pendingId: string,
  rejectedBy: string,
  reason: string,
): boolean {
  const p = store.find((x) => x.id === pendingId);
  if (!p || p.status !== "pending") return false;
  p.status = "rejected";
  p.rejectedReason = reason;
  appendActivity({
    actor: rejectedBy,
    kind: "decision_request",
    launchId: "—",
    detail: `Rejected Jira intake ${p.jiraKey} (${p.name}): ${reason}`,
  });
  notify();
  return true;
}

let userReqSeq = 1;
function nextRequestKey(): string {
  return `REQ-${String(userReqSeq++).padStart(3, "0")}`;
}

export interface UserRequestInput {
  name: string;
  product: string;
  businessUnit: BusinessUnit;
  lob: LOB;
  region: Launch["region"];
  proposedOwner: string;
  proposedLaunchDate: string;
  rationale?: string;
  requestedBy?: string;
}

export function submitUserPlatformRequest(input: UserRequestInput): PendingPlatform {
  const req: PendingPlatform = {
    id: `pp-user-${Date.now()}`,
    jiraKey: nextRequestKey(),
    name: input.name,
    product: input.product || input.name,
    businessUnit: input.businessUnit,
    lob: input.lob,
    function: "GOE",
    region: input.region,
    proposedOwner: input.proposedOwner,
    proposedLaunchDate: input.proposedLaunchDate,
    requestedBy: input.requestedBy ?? "You",
    requestedAt: Date.now(),
    status: "pending",
    source: "user",
    rationale: input.rationale,
  };
  store.unshift(req);
  notify();
  return req;
}
