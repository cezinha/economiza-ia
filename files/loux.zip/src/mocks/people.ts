import { launches as ALL_LAUNCHES, type Launch } from "@/mocks/launches";
import { launchFunctions, type TaskFunction } from "@/lib/launchTasks";

export interface Manager {
  id: string;
  name: string;
  function: TaskFunction;
  launchId: string;
}

export interface TeamMember {
  id: string;
  name: string;
  function: TaskFunction;
  launchId: string;
  managerId: string;
}

// Curated, deterministic name pool — kept long enough that collisions across
// (launch, function) buckets are spread out.
const MANAGER_POOL = [
  "Asha Rangan", "Brendan O'Neill", "Carla Méndez", "Dimitri Volkov",
  "Eun-Ji Park", "Farhan Siddiqui", "Greta Lindqvist", "Hassan Bakr",
  "Ines Roussel", "Junichi Mori", "Kavita Iyer", "Lukas Becker",
  "Maya Goldberg", "Nikolai Petrov", "Oluwaseun Adebayo", "Patricia Chan",
  "Quinn Harper", "Ravi Subramanian", "Sigrid Hansen", "Tobias Hartmann",
  "Uma Krishnan", "Viktor Novak", "Wendy Zhao", "Xiomara Vega",
  "Yara Haddad", "Zander Brooks", "Aiko Tanabe", "Boris Kowalski",
  "Celine Dubois", "Diego Castillo",
];

const MEMBER_POOL = [
  "Anika Patel", "Ben Carter", "Chloe Nguyen", "Diego Romero",
  "Elif Yıldız", "Finn O'Brien", "Gabriela Costa", "Hugo Martin",
  "Ines Carvalho", "Jakob Müller", "Kira Volkova", "Liam Walsh",
  "Maya Cohen", "Nora Lindgren", "Omar Khalil", "Petra Novák",
  "Quentin Laurent", "Rhea Kapoor", "Sven Eriksson", "Tara Singh",
  "Umar Farooq", "Vera Ilic", "Will Hendricks", "Xochitl Ramos",
  "Yusuf Demir", "Zoe Kallis", "Aarav Mehta", "Bianca Ferreira",
  "Caleb Foster", "Dahlia Brennan", "Esme Laurent", "Felix Andersen",
  "Gia Romano", "Hana Suzuki", "Ivan Petrović", "Jade Ferreira",
  "Kai Nakamura", "Leila Saidi", "Mateo Rivas", "Nadia Haddad",
  "Owen Brennan", "Priya Anand", "Rafael Lima", "Sana Qureshi",
  "Theo Koch", "Uma Reddy", "Vince Calderón", "Wren Halloway",
  "Xander Pope", "Yuri Sokolov",
];

// Tiny seedable PRNG (mulberry32) for deterministic name picks.
function mulberry32(seed: number) {
  let t = seed >>> 0;
  return () => {
    t = (t + 0x6D2B79F5) >>> 0;
    let r = Math.imul(t ^ (t >>> 15), 1 | t);
    r = (r + Math.imul(r ^ (r >>> 7), 61 | r)) ^ r;
    return ((r ^ (r >>> 14)) >>> 0) / 4294967296;
  };
}

function hashKey(s: string): number {
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

const MANAGERS: Manager[] = [];
const MEMBERS: TeamMember[] = [];

(function build() {
  // Distribute manager picks across pool in deterministic global order.
  let mgrCursor = 0;
  let memCursor = 0;
  const launchOrdered: Launch[] = [...ALL_LAUNCHES].sort((a, b) => a.id.localeCompare(b.id));

  for (const launch of launchOrdered) {
    for (const fn of launchFunctions(launch)) {
      const seed = hashKey(`${launch.id}|${fn}`);
      const rnd = mulberry32(seed);

      const managerName = MANAGER_POOL[mgrCursor % MANAGER_POOL.length];
      mgrCursor++;
      const manager: Manager = {
        id: `MGR-${launch.id}-${fn}`,
        name: managerName,
        function: fn,
        launchId: launch.id,
      };
      MANAGERS.push(manager);

      const teamSize = 3 + Math.floor(rnd() * 3); // 3..5
      for (let i = 0; i < teamSize; i++) {
        const memberName = MEMBER_POOL[memCursor % MEMBER_POOL.length];
        memCursor++;
        MEMBERS.push({
          id: `MEM-${launch.id}-${fn}-${i + 1}`,
          name: memberName,
          function: fn,
          launchId: launch.id,
          managerId: manager.id,
        });
      }
    }
  }
})();

export function managersFor(launchId: string, fn?: TaskFunction): Manager[] {
  return MANAGERS.filter((m) => m.launchId === launchId && (!fn || m.function === fn));
}

export function membersFor(launchId: string, fn?: TaskFunction): TeamMember[] {
  return MEMBERS.filter((m) => m.launchId === launchId && (!fn || m.function === fn));
}

/** Manager + members eligible to be assigned to a task in `(launchId, fn)`. */
export function assignableFor(launchId: string, fn: TaskFunction): (Manager | TeamMember)[] {
  return [...managersFor(launchId, fn), ...membersFor(launchId, fn)];
}

export function managerOf(memberId: string): Manager | undefined {
  const m = MEMBERS.find((x) => x.id === memberId);
  if (!m) return undefined;
  return MANAGERS.find((mg) => mg.id === m.managerId);
}

/** Deterministic round-robin assignee for a task identified by stable key. */
export function pickAssignee(launchId: string, fn: TaskFunction, taskKey: string): Manager | TeamMember | undefined {
  const pool = assignableFor(launchId, fn);
  if (pool.length === 0) return undefined;
  return pool[hashKey(taskKey) % pool.length];
}

export const ALL_MANAGERS = MANAGERS;
export const ALL_MEMBERS = MEMBERS;
