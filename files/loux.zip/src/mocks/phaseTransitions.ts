// Runtime store of manager-driven phase transitions for platforms.
// Mock-only: changes live in memory and trigger subscriber re-renders.

import { PHASE_ORDER, type OlpPhase } from "@/mocks/taskCatalog";
import { launches as ALL_LAUNCHES, type Launch, type Phase } from "@/mocks/launches";


export interface PhaseTransition {
  id: string;
  launchId: string;
  fromPhase: string;
  toPhase: string;
  closedBy: string;
  closedAt: number;
  reason?: string;
  /** True if there were outstanding tasks at close time (override). */
  override: boolean;
}

const overrides = new Map<string, string>(); // launchId -> current phase
const history: PhaseTransition[] = [];
const listeners = new Set<() => void>();

function notify() { for (const l of listeners) l(); }

export function subscribePhaseTransitions(fn: () => void): () => void {
  listeners.add(fn);
  return () => { listeners.delete(fn); };
}

export function getEffectivePhase(launch: Launch): string {
  return overrides.get(launch.id) ?? launch.phase;
}

export function getPhaseHistory(launchId?: string): PhaseTransition[] {
  if (!launchId) return [...history];
  return history.filter((h) => h.launchId === launchId);
}

export function nextPhaseOf(current: string): string | null {
  const i = PHASE_ORDER.indexOf(current as OlpPhase);
  if (i < 0 || i >= PHASE_ORDER.length - 1) return null;
  return PHASE_ORDER[i + 1];
}

export function isLaunched(launch: Launch): boolean {
  return getEffectivePhase(launch) === "Launch" && Boolean(overrides.get(launch.id));
}

export function closeAndAdvance(input: {
  launch: Launch;
  closedBy: string;
  reason?: string;
  override: boolean;
}): PhaseTransition | null {
  const cur = getEffectivePhase(input.launch);
  const next = nextPhaseOf(cur);
  if (!next) return null;
  overrides.set(input.launch.id, next);
  // Reflect on the underlying mock so other selectors see it. Safe: PoC.
  (input.launch as Launch & { phase: Phase }).phase = next as Phase;
  const t: PhaseTransition = {
    id: `pt-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
    launchId: input.launch.id,
    fromPhase: cur,
    toPhase: next,
    closedBy: input.closedBy,
    closedAt: Date.now(),
    reason: input.reason,
    override: input.override,
  };
  history.unshift(t);
  notify();
  return t;
}

/**
 * If a phase-close approval task was just completed, check whether *all*
 * per-function close tasks for that phase are now complete. If yes, advance
 * the platform to the next phase. Mock-only — no-op on backend.
 */
export async function maybeAdvanceOnCloseCompletion(launchId: string, by: string): Promise<void> {
  const launch = ALL_LAUNCHES.find((l) => l.id === launchId);
  if (!launch) return;
  const [{ tasksForLaunch, isPhaseCloseTask }, { isTaskCompleted }, { appendActivity }] = await Promise.all([
    import("@/lib/launchTasks"),
    import("@/mocks/completionRequests"),
    import("@/mocks/activityLog"),
  ]);
  const phase = getEffectivePhase(launch);
  const closeTasks = tasksForLaunch(launch).filter(
    (t) => t.phase === phase && isPhaseCloseTask(t),
  );
  if (closeTasks.length === 0) return;
  if (!closeTasks.every((t) => isTaskCompleted(t.id))) return;
  const t = closeAndAdvance({ launch, closedBy: by, override: false });
  if (!t) return;
  appendActivity({
    actor: by,
    kind: "phase_change",
    launchId: launch.id,
    detail: `closed ${t.fromPhase} → started ${t.toPhase} (all Confirm ${t.fromPhase} exit approvals received)`,
  });
}

