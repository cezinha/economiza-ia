// Tracks platform-level rolled-up status flips (Green/Amber/Red).
// Emits an event whenever an approved/direct-override status change request
// causes platformStatus(launch) to move to a different bucket.

import { launches } from "@/mocks/launches";
import { platformStatus, type TaskStatus } from "@/lib/launchTasks";
import {
  listStatusChangeRequests,
  subscribeStatusChangeRequests,
  type StatusChangeRequest,
} from "@/mocks/statusChangeRequests";

export interface PlatformStatusEvent {
  id: string;
  launchId: string;
  launchName: string;
  fromStatus: TaskStatus;
  toStatus: TaskStatus;
  requestId: string;
  ts: number;
}

const events: PlatformStatusEvent[] = [];
const snapshot = new Map<string, TaskStatus>();
const listeners = new Set<() => void>();
let initialized = false;

function emit() {
  for (const l of listeners) l();
}

function snapshotAll() {
  for (const l of launches) snapshot.set(l.id, platformStatus(l));
}

function pushEvent(launchId: string, launchName: string, from: TaskStatus, to: TaskStatus, req: StatusChangeRequest | undefined) {
  if (!req) return;
  events.unshift({
    id: `pse-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
    launchId,
    launchName,
    fromStatus: from,
    toStatus: to,
    requestId: req.id,
    ts: req.reviewedAt ?? req.requestedAt,
  });
}

function detectFlips() {
  for (const l of launches) {
    const prev = snapshot.get(l.id) ?? "on-track";
    const next = platformStatus(l);
    if (prev !== next) {
      const latestApproved = listStatusChangeRequests({ launchId: l.id, state: "approved" })[0];
      pushEvent(l.id, l.name, prev, next, latestApproved);
      snapshot.set(l.id, next);
    }
  }
}

function ensureInit() {
  if (initialized) return;
  initialized = true;

  // Seed: pretend each currently non-green platform just flipped from on-track,
  // anchored to its latest approved request. This populates the section on first load.
  for (const l of launches) {
    const current = platformStatus(l);
    if (current === "at-risk" || current === "at-risk-mitigated") {
      const latest = listStatusChangeRequests({ launchId: l.id, state: "approved" })[0];
      if (latest) pushEvent(l.id, l.name, "on-track", current, latest);
    }
  }
  events.sort((a, b) => b.ts - a.ts);
  snapshotAll();

  subscribeStatusChangeRequests(() => {
    detectFlips();
    emit();
  });
}

export function getPlatformStatusEvents(): PlatformStatusEvent[] {
  ensureInit();
  return events.slice();
}

export function subscribePlatformStatusEvents(cb: () => void): () => void {
  ensureInit();
  listeners.add(cb);
  return () => { listeners.delete(cb); };
}

export function getPlatformStatusEventDetail(eventId: string):
  | { event: PlatformStatusEvent; request: StatusChangeRequest | undefined }
  | null {
  ensureInit();
  const ev = events.find((e) => e.id === eventId);
  if (!ev) return null;
  const all = listStatusChangeRequests();
  const request = all.find((r) => r.id === ev.requestId);
  return { event: ev, request };
}
