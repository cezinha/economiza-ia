// Plan of Record (POR) baseline per launch + track + phase exit.
// POR is anchored to the launch's *original* launchDate (pre-override), so
// downstream slips from RTS moves are surfaced naturally. Actuals are
// deterministically perturbed off POR using a launch-id+phase hash so the
// mock data is realistic and stable across reloads.

import type { Launch } from "@/mocks/launches";
import type { ScheduleTrack } from "@/lib/schedule";
import { phasesForLaunch } from "@/lib/schedule";

export interface PorPhaseRecord {
  phase: string;
  /** ISO YYYY-MM-DD — phase exit date as originally planned (POR). */
  porExit: string;
  /** ISO YYYY-MM-DD — actual close date if phase has closed. Undefined for future phases. */
  actualExit?: string;
}

const TODAY_MS = Date.now();
const DAY_MS = 24 * 60 * 60 * 1000;

function hash(s: string): number {
  let h = 5381;
  for (let i = 0; i < s.length; i++) h = ((h << 5) + h + s.charCodeAt(i)) | 0;
  return Math.abs(h);
}

function toIso(d: Date): string {
  return d.toISOString().slice(0, 10);
}

function addDaysIso(iso: string, days: number): string {
  const d = new Date(iso + "T00:00:00Z");
  d.setUTCDate(d.getUTCDate() + days);
  return toIso(d);
}

/**
 * Compute POR phase-exit records for a launch + track.
 * - POR exits are derived from launch.launchDate (raw, not effective).
 * - Actuals are filled for phases whose POR exit is in the past, perturbed
 *   deterministically by ±0–14 days (skewed slightly toward slip).
 */
export function porFor(launch: Launch, track: ScheduleTrack): PorPhaseRecord[] {
  // Build a synthetic "POR launch" using the raw launchDate so effectiveLaunchDate
  // overrides do not pollute the baseline.
  const porLaunch: Launch = { ...launch, launchDate: launch.launchDate };
  const phases = phasesForLaunch(porLaunch, track);
  return phases.map((p) => {
    const porExitIso = toIso(p.end);
    const exitMs = p.end.getTime();
    const isClosed = exitMs < TODAY_MS;
    if (!isClosed) {
      return { phase: p.name, porExit: porExitIso };
    }
    // Perturb: range -3..+18 days, skewed toward slip
    const h = hash(`${launch.id}:${track}:${p.name}`);
    const delta = (h % 22) - 3; // -3..+18
    return {
      phase: p.name,
      porExit: porExitIso,
      actualExit: addDaysIso(porExitIso, delta),
    };
  });
}

export function porDeltaDays(porExit: string, actualExit: string): number {
  const a = new Date(actualExit + "T00:00:00Z").getTime();
  const b = new Date(porExit + "T00:00:00Z").getTime();
  return Math.round((a - b) / DAY_MS);
}
