// Mock reminders derived from launches. Cadence is automatic: red = 24h,
// otherwise weekly. Per-task snooze and mute are PoC-local in-memory state.
import { launches, type Launch, type RAG } from "./launches";

export type Cadence = "daily" | "weekly" | "none";

export interface Reminder {
  id: string;
  /** Stable id used to key the row & snooze/mute maps */
  taskRef: string;
  title: string;
  platform: string;
  rag: RAG;
  cadence: Cadence;
  /** ISO timestamp for the next reminder firing */
  nextAt: string;
  /** Source launch (for navigation) */
  launchId: string;
}

export function getReminderCadence(rag: RAG): Cadence {
  if (rag === "red") return "daily";
  return "weekly";
}

export function cadenceLabel(c: Cadence): string {
  if (c === "daily") return "Every 24h, 9:00 AM";
  if (c === "weekly") return "Weekly, Mondays 9:00 AM";
  return "No reminders";
}

const nextNineAm = (offsetDays: number): string => {
  const d = new Date();
  d.setDate(d.getDate() + offsetDays);
  d.setHours(9, 0, 0, 0);
  return d.toISOString();
};

const nextMonday9 = (): string => {
  const d = new Date();
  const dow = d.getDay(); // 0=Sun
  const days = (8 - dow) % 7 || 7;
  d.setDate(d.getDate() + days);
  d.setHours(9, 0, 0, 0);
  return d.toISOString();
};

export function reminderForLaunch(l: Launch): Reminder {
  const cadence = getReminderCadence(l.rag);
  const nextAt = cadence === "daily" ? nextNineAm(0) : nextMonday9();
  return {
    id: `r-${l.id}`,
    taskRef: `task-${l.id}`,
    title: l.nextMilestone,
    platform: l.name,
    rag: l.rag,
    cadence,
    nextAt,
    launchId: l.id,
  };
}

export function getAllReminders(): Reminder[] {
  return launches.map(reminderForLaunch);
}

// In-memory snooze / mute state (session only)
type SnoozeState = { until?: string; muted?: boolean; muteExpiresAt?: string };
const state: Record<string, SnoozeState> = {};
const listeners = new Set<() => void>();

export function subscribeReminders(fn: () => void) {
  listeners.add(fn);
  return () => listeners.delete(fn);
}
const notify = () => listeners.forEach((l) => l());

export function getReminderState(taskRef: string): SnoozeState {
  return state[taskRef] ?? {};
}

export function snoozeReminder(taskRef: string, days: number) {
  const d = new Date();
  d.setDate(d.getDate() + days);
  state[taskRef] = { ...(state[taskRef] ?? {}), until: d.toISOString() };
  notify();
}

export function muteReminder(taskRef: string, rag: RAG) {
  // Red tasks auto-unmute after 7 days; non-red are permanent until manual unmute.
  if (rag === "red") {
    const d = new Date();
    d.setDate(d.getDate() + 7);
    state[taskRef] = { ...(state[taskRef] ?? {}), muted: true, muteExpiresAt: d.toISOString() };
  } else {
    state[taskRef] = { ...(state[taskRef] ?? {}), muted: true };
  }
  notify();
}

export function unmuteReminder(taskRef: string) {
  state[taskRef] = { ...(state[taskRef] ?? {}), muted: false, muteExpiresAt: undefined };
  notify();
}

export function isMuted(taskRef: string): boolean {
  const s = state[taskRef];
  if (!s?.muted) return false;
  if (s.muteExpiresAt && new Date(s.muteExpiresAt).getTime() < Date.now()) return false;
  return true;
}

export function isSnoozed(taskRef: string): boolean {
  const s = state[taskRef];
  if (!s?.until) return false;
  return new Date(s.until).getTime() > Date.now();
}

export function formatNextReminder(iso: string): string {
  const ms = new Date(iso).getTime() - Date.now();
  if (ms <= 0) return "any moment";
  const hours = Math.round(ms / 36e5);
  if (hours < 24) return `in ${hours}h`;
  const days = Math.round(hours / 24);
  if (days === 1) return "tomorrow";
  return `in ${days}d`;
}

export function formatAbsolute(iso: string): string {
  const d = new Date(iso);
  return d.toLocaleString(undefined, {
    weekday: "short",
    hour: "numeric",
    minute: "2-digit",
  });
}
