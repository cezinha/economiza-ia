// Deterministic per-task badge assignment used by the To-do list so the demo
// shows a healthy mix of Warning, Overdue, and Overdue - Urgent chips. This is
// a presentation-only override; real due dates and min-duration math are
// untouched.

export type OverrideBucket = "warn" | "overdue" | "overdue-urgent" | "ok";

function hash(id: string): number {
  let h = 2166136261 >>> 0;
  for (let i = 0; i < id.length; i++) {
    h ^= id.charCodeAt(i);
    h = Math.imul(h, 16777619) >>> 0;
  }
  return h;
}

/**
 * Stable bucket per task id. Distribution across non-auto, non-completed
 * tasks: ~40% ok, ~25% warn, ~20% overdue, ~15% overdue-urgent.
 */
export function getOverrideBucket(taskId: string): OverrideBucket {
  const slot = hash(taskId) % 100;
  if (slot < 40) return "ok";
  if (slot < 65) return "warn";
  if (slot < 85) return "overdue";
  return "overdue-urgent";
}

/** Stable "overdue by N days" used for tooltip text when bucket is overridden. */
export function getOverriddenOverdueDays(taskId: string): number | null {
  const bucket = getOverrideBucket(taskId);
  const h = hash(taskId + ":days");
  if (bucket === "overdue") return (h % 7) + 1; // 1..7
  if (bucket === "overdue-urgent") return (h % 14) + 8; // 8..21
  return null;
}
