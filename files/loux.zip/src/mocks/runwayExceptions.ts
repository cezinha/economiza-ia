// Exception requests for tasks whose runway is below the recommended minimum.

import { appendActivity } from "@/mocks/activityLog";

export type RunwayExceptionStatus = "pending" | "approved" | "rejected";

export interface RunwayException {
  id: string;
  taskId: string;
  taskName: string;
  launchId: string;
  launchName: string;
  runwayDays: number;
  minDays: number;
  reason: string;
  requestedBy: string;
  status: RunwayExceptionStatus;
  createdAt: number;
  resolvedAt?: number;
  resolvedBy?: string;
  resolutionReason?: string;
}

const list: RunwayException[] = [];
const listeners = new Set<() => void>();

function notify() { for (const l of listeners) l(); }

export function subscribeRunwayExceptions(fn: () => void): () => void {
  listeners.add(fn);
  return () => listeners.delete(fn);
}

export function getExceptionForTask(taskId: string): RunwayException | undefined {
  // Most recent (pending or approved) wins
  return list.find((e) => e.taskId === taskId && e.status !== "rejected");
}

export function allExceptions(): RunwayException[] { return list.slice(); }

export function pendingExceptions(): RunwayException[] {
  return list.filter((e) => e.status === "pending");
}

export function createException(input: Omit<RunwayException, "id" | "status" | "createdAt">): RunwayException {
  const e: RunwayException = {
    ...input,
    id: `exc-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
    status: "pending",
    createdAt: Date.now(),
  };
  list.unshift(e);
  appendActivity({
    actor: input.requestedBy,
    kind: "runway_exception",
    launchId: input.launchId,
    refId: input.taskId,
    detail: `requested runway exception for ${input.taskName} (${input.runwayDays}d vs ${input.minDays}d min)`,
  });
  notify();
  return e;
}

export function approveException(id: string, by: string): void {
  const e = list.find((x) => x.id === id);
  if (!e || e.status !== "pending") return;
  e.status = "approved";
  e.resolvedAt = Date.now();
  e.resolvedBy = by;
  appendActivity({
    actor: by,
    kind: "runway_resolved",
    launchId: e.launchId,
    refId: e.taskId,
    detail: `approved runway exception for ${e.taskName}`,
  });
  notify();
}

export function rejectException(id: string, by: string, reason: string): void {
  const e = list.find((x) => x.id === id);
  if (!e || e.status !== "pending") return;
  e.status = "rejected";
  e.resolvedAt = Date.now();
  e.resolvedBy = by;
  e.resolutionReason = reason;
  appendActivity({
    actor: by,
    kind: "runway_resolved",
    launchId: e.launchId,
    refId: e.taskId,
    detail: `rejected runway exception for ${e.taskName} — ${reason}`,
  });
  notify();
}
