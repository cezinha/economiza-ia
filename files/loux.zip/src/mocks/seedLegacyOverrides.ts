// Seeds the demo status-change request data. For each tuned R / Y override in
// launchOverrides, we generate a realistic two-step audit trail:
//   1) the task owner submits a StatusChangeRequest with root cause,
//      business impact, action required, owner, and due date.
//   2) a manager approves it ~1–3 days later.
//
// In addition we seed a few R/Y → Green recovery arcs on amber platforms so
// the history drawer shows a complete "flagged → mitigated → resolved" story.
//
// Everything is in-memory mock data; imported once from App.tsx.

import { launches } from "@/mocks/launches";
import { launchOverrides } from "@/mocks/taskOverrides";
import { phasesForLaunch, type ScheduleTrack } from "@/lib/schedule";
import {
  tasksForLaunch,
  currentPhaseName,
  type TaskFunction,
} from "@/lib/launchTasks";
import {
  approveStatusChangeRequest,
  createStatusChangeRequest,
  listStatusChangeRequests,
} from "@/mocks/statusChangeRequests";

let seeded = false;

const SEED_MANAGER = "Priya Raman";

// Per-track owner pool (engineers / leads who would file the request).
const REQUESTERS: Record<ScheduleTrack, string[]> = {
  GOE: ["Marcus Lee", "Aisha Khan", "Diego Alvarez", "Hana Park", "Sven Borg"],
  NPI: ["Sara Okafor", "Tomás Ruiz", "Linh Tran", "Olu Adeyemi", "Mei Watanabe"],
  SChM: ["Jordan Patel", "Elena García", "Ravi Menon", "Chloé Martin", "Yara Haddad"],
  Core: ["Priya Shah", "Wei Chen", "Noor Rahman", "Ben Carter", "Anya Volkov"],
};

// Canned per-track content keyed by severity so the 15 platforms don't read identically.
const CONTENT: Record<
  ScheduleTrack,
  { red: ContentTriplet[]; amber: ContentTriplet[] }
> = {
  GOE: {
    red: [
      {
        cause: "Validation lab capacity oversubscribed; thermal runs pushed by 2 weeks.",
        impact: "Threatens QPE exit by 10 business days and RTS commit to top-3 EMEA customers.",
        action: "Secure 2 additional chambers from Round Rock site; daily standup until backlog cleared.",
      },
      {
        cause: "EMI failure on Rev-B board during pre-compliance sweep at 230 MHz.",
        impact: "Pilot build cannot ship to FCC lab — 3-week regulatory slip risk.",
        action: "Spin Rev-C with revised shielding gasket; re-run pre-compliance Wk +2.",
      },
      {
        cause: "Supplier audit flagged two non-conformances on chassis tolerances.",
        impact: "Risk of receiving 800 units that fail incoming QA — pilot dates impacted.",
        action: "On-site SQE intervention; first-article re-submit required before bulk ship.",
      },
    ],
    amber: [
      {
        cause: "Display vendor switched LCD driver IC mid-bring-up.",
        impact: "Re-tuning backlight curve adds 5 days to qual; mitigation in place.",
        action: "Vendor on-site Mon–Wed; calibration data delivered by Friday.",
      },
      {
        cause: "Touchpad firmware regression seen on 3/12 EVT units.",
        impact: "Cosmetic — does not block phase exit but tracked weekly.",
        action: "Vendor patch in test; gate on 100% pass across next EVT lot.",
      },
    ],
  },
  NPI: {
    red: [
      {
        cause: "Tooling for top-cover stamp damaged at supplier; replacement lead time 4 weeks.",
        impact: "Pilot build start at risk by 3 weeks; revenue ramp pushed one quarter.",
        action: "Dual-source stamping at Penang site; air-freight tools by Wk +1.",
      },
      {
        cause: "BOM cost over target by $9.40/unit driven by NAND price spike.",
        impact: "Margin below threshold; PPE exit blocked until BOM walk approved.",
        action: "Re-quote 3 alt suppliers; finance to review revised margin Wk +2.",
      },
      {
        cause: "Pilot line yield at 71% — 18 pts below entry criteria.",
        impact: "Cannot exit Pilot phase; ship-hold on first 2,000 units.",
        action: "Yield task force stood up; daily Pareto reviews; root-cause by Wk +2.",
      },
    ],
    amber: [
      {
        cause: "Logistics provider re-routed via Hamburg adding 4 days transit.",
        impact: "Minor — covered by safety stock at distribution hub.",
        action: "Lock alt carrier for next 3 shipments; monitor weekly.",
      },
      {
        cause: "Carton artwork rev pending legal approval in 2 SKUs.",
        impact: "Will not block ship if cleared by Wk +1.",
        action: "Legal review scheduled; backup artwork on standby.",
      },
    ],
  },
  SChM: {
    red: [
      {
        cause: "Long-lead memory module slipped 5 weeks per supplier commit revision.",
        impact: "DPE → PPE handoff delayed; downstream qual builds at risk.",
        action: "Allocate from corporate buffer; lock weekly OTD reviews with supplier.",
      },
      {
        cause: "Customs hold on display panels in CN — paperwork mismatch.",
        impact: "PPE-2 build start at risk by 8 working days.",
        action: "Logistics to refile; expedite via bonded warehouse Wk +1.",
      },
      {
        cause: "PCBA fab capacity reallocated to higher-priority program.",
        impact: "Forecast vs commit gap of 1,200 units in next pull.",
        action: "Escalate to ops VP; secure capacity at secondary fab by Wk +2.",
      },
    ],
    amber: [
      {
        cause: "Connector shortage flagged 6 weeks out — small but real exposure.",
        impact: "Manageable with current safety stock + alt source.",
        action: "Qualify alt connector; PO placed for buffer stock.",
      },
      {
        cause: "Forecast revised up 8% — current commit can absorb but tight.",
        impact: "No phase impact; watching weekly.",
        action: "Re-confirm allocation with top 2 suppliers; review again Wk +2.",
      },
    ],
  },
  Core: {
    red: [
      {
        cause: "Cross-functional dependency owner unassigned for 9 days.",
        impact: "Blocks gate readiness review; cascades to phase exit decision.",
        action: "Core lead to nominate owner by EOW; coverage plan documented.",
      },
    ],
    amber: [
      {
        cause: "Two open action items from last gate review still unresolved.",
        impact: "No date impact yet; flagged for visibility.",
        action: "Close out items by next core team review.",
      },
    ],
  },
};

interface ContentTriplet {
  cause: string;
  impact: string;
  action: string;
}

function firstCurrentPhaseTaskId(
  launch: (typeof launches)[number],
  track: ScheduleTrack,
  currentName: string,
): { id: string; name: string } | null {
  const tf: TaskFunction = track === "Core" ? "SChM" : track;
  const tasks = tasksForLaunch(launch).filter(
    (t) => t.teams.includes(tf) && t.phase === currentName,
  );
  const first = tasks[0];
  return first ? { id: first.id, name: first.task } : null;
}

function pick<T>(arr: T[], idx: number): T {
  return arr[idx % arr.length];
}

function isoDaysFromNow(days: number): string {
  return new Date(Date.now() + days * 86_400_000).toISOString().slice(0, 10);
}

// Backdate the latest-inserted request + approval timestamps in a stable way.
function backdateLatest(opts: {
  requestedDaysAgo: number;
  approvedDaysAgo: number;
}) {
  const all = listStatusChangeRequests();
  const latest = all[0];
  if (!latest) return;
  latest.requestedAt = Date.now() - opts.requestedDaysAgo * 86_400_000;
  if (latest.reviewedAt) {
    latest.reviewedAt = Date.now() - opts.approvedDaysAgo * 86_400_000;
  }
}

export function seedLegacyOverrides(): void {
  if (seeded) return;
  seeded = true;

  // If something already seeded (e.g. HMR), bail.
  if (listStatusChangeRequests({ state: "approved" }).length > 0) {
    return;
  }

  let i = 0;
  for (const [launchId, overrides] of Object.entries(launchOverrides)) {
    const launch = launches.find((l) => l.id === launchId);
    if (!launch) continue;
    if (phasesForLaunch(launch, "GOE").length === 0) continue;

    for (const ov of overrides) {
      const current = currentPhaseName(launch, ov.track);
      if (!current) continue;
      const task = firstCurrentPhaseTaskId(launch, ov.track, current);
      if (!task) continue;

      const severity = ov.status === "at-risk" ? "red" : "amber";
      const triplet = pick(CONTENT[ov.track][severity], i);
      const requester = pick(REQUESTERS[ov.track], i);
      const requestedDaysAgo = 7 + ((i * 3) % 18); // 7..24 days ago
      const approvedDaysAgo = Math.max(1, requestedDaysAgo - (1 + (i % 3))); // 1–3 days after request
      const dueDate = isoDaysFromNow(5 + (i % 10)); // 5–14 days out

      const created = createStatusChangeRequest({
        launchId,
        taskId: task.id,
        taskName: task.name,
        fromStatus: "on-track",
        toStatus: ov.status,
        issueDescription: triplet.cause,
        businessImpact: triplet.impact,
        mitigationPlan: triplet.action,
        owner: requester,
        dueDate,
        requestedBy: requester,
        requestedAt: Date.now() - requestedDaysAgo * 86_400_000,
      });
      approveStatusChangeRequest(
        created.id,
        SEED_MANAGER,
        severity === "red"
          ? "Risk acknowledged — mitigation plan approved. Track weekly."
          : "Mitigation accepted; revisit at next gate review.",
      );
      backdateLatest({ requestedDaysAgo, approvedDaysAgo });
      i++;
    }
  }

  // Seed a handful of full R/Y → Green recovery arcs on amber platforms so the
  // history drawer shows the full "flagged → mitigated → resolved" story.
  const recoveryLaunches: Array<{ id: string; track: ScheduleTrack }> = [
    { id: "L-2002", track: "GOE" },
    { id: "L-2006", track: "NPI" },
    { id: "L-2015", track: "SChM" },
  ];

  for (const { id: launchId, track } of recoveryLaunches) {
    const launch = launches.find((l) => l.id === launchId);
    if (!launch) continue;
    const current = currentPhaseName(launch, track);
    if (!current) continue;
    const allTasks = tasksForLaunch(launch).filter(
      (t) => t.teams.includes(track === "Core" ? "SChM" : track) && t.phase === current,
    );
    // Use the second task in the phase so we don't collide with the override
    // seeded above (which uses the first task).
    const target = allTasks[1] ?? allTasks[0];
    if (!target) continue;

    const requester = pick(REQUESTERS[track], i + 1);
    const triplet = pick(CONTENT[track].amber, i);

    // Step 1: flagged Yellow ~21 days ago, approved 19 days ago.
    const flagged = createStatusChangeRequest({
      launchId,
      taskId: target.id,
      taskName: target.task,
      fromStatus: "on-track",
      toStatus: "at-risk-mitigated",
      issueDescription: triplet.cause,
      businessImpact: triplet.impact,
      mitigationPlan: triplet.action,
      owner: requester,
      dueDate: isoDaysFromNow(-5),
      requestedBy: requester,
      requestedAt: Date.now() - 21 * 86_400_000,
    });
    approveStatusChangeRequest(
      flagged.id,
      SEED_MANAGER,
      "Mitigation accepted. Track recovery weekly.",
    );
    backdateLatest({ requestedDaysAgo: 21, approvedDaysAgo: 19 });

    // Step 2: resolved Green ~4 days ago, approved 2 days ago.
    const resolved = createStatusChangeRequest({
      launchId,
      taskId: target.id,
      taskName: target.task,
      fromStatus: "at-risk-mitigated",
      toStatus: "on-track",
      issueDescription: triplet.cause,
      businessImpact: "Recovered — no further schedule exposure.",
      mitigationPlan: `Closed: ${triplet.action} Evidence reviewed and accepted.`,
      owner: requester,
      dueDate: isoDaysFromNow(0),
      requestedBy: requester,
      requestedAt: Date.now() - 4 * 86_400_000,
    });
    approveStatusChangeRequest(
      resolved.id,
      SEED_MANAGER,
      "Resolution evidence accepted. Status returned to Green.",
    );
    backdateLatest({ requestedDaysAgo: 4, approvedDaysAgo: 2 });
    i++;
  }
}
