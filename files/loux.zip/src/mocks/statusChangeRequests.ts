// In-memory queue for user-submitted task status-change requests.
// Approved entries become the source of truth for the task's R/Y/G status,
// replacing the legacy track-level `launchOverrides` mock.

import type { TaskStatus } from "@/lib/launchTasks";
import { appendActivity } from "@/mocks/activityLog";
import { appendTaskHistory } from "@/mocks/taskHistory";

export type StatusChangeTarget = "at-risk" | "at-risk-mitigated" | "on-track";

export type RequestState = "pending" | "approved" | "rejected";

export interface StatusChangeRequest {
  id: string;
  launchId: string;
  taskId: string;
  taskName: string;
  fromStatus: TaskStatus;
  toStatus: StatusChangeTarget;
  /** Root cause / issue description. */
  issueDescription: string;
  businessImpact: string;
  /** Action required / mitigation or resolution plan. */
  mitigationPlan: string;
  owner: string;
  /** ISO yyyy-mm-dd target completion date for the action. */
  dueDate: string;
  requestedBy: string;
  requestedAt: number;
  state: RequestState;
  reviewedBy?: string;
  reviewedAt?: number;
  reviewerNote?: string;
  /** True when an Admin/Superadmin wrote the override directly without a form. */
  directOverride?: boolean;
}

const requests: StatusChangeRequest[] = [];
const listeners = new Set<() => void>();

function notify() {
  for (const l of listeners) l();
}

export function subscribeStatusChangeRequests(fn: () => void): () => void {
  listeners.add(fn);
  return () => listeners.delete(fn);
}

export function listStatusChangeRequests(filter?: {
  state?: RequestState;
  launchId?: string;
  taskId?: string;
}): StatusChangeRequest[] {
  return requests.filter((r) => {
    if (filter?.state && r.state !== filter.state) return false;
    if (filter?.launchId && r.launchId !== filter.launchId) return false;
    if (filter?.taskId && r.taskId !== filter.taskId) return false;
    return true;
  });
}

export function pendingStatusChangeCount(): number {
  return requests.reduce((n, r) => n + (r.state === "pending" ? 1 : 0), 0);
}

export function pendingStatusChangeForTask(taskId: string): StatusChangeRequest | undefined {
  return requests.find((r) => r.state === "pending" && r.taskId === taskId);
}

/** Most recent approved override for this task, if any. */
export function approvedStatusForTask(taskId: string): StatusChangeTarget | null {
  // Iterate newest-first
  for (const r of requests) {
    if (r.state === "approved" && r.taskId === taskId) return r.toStatus;
  }
  return null;
}

function statusLabel(s: TaskStatus | StatusChangeTarget): string {
  switch (s) {
    case "at-risk": return "At risk";
    case "at-risk-mitigated": return "At risk (mitigated)";
    case "on-track": return "On track";
    case "completed": return "Completed";
    case "not-started": return "Not started";
    default: return String(s);
  }
}

export function createStatusChangeRequest(input: {
  launchId: string;
  taskId: string;
  taskName: string;
  fromStatus: TaskStatus;
  toStatus: StatusChangeTarget;
  issueDescription: string;
  businessImpact: string;
  mitigationPlan: string;
  owner: string;
  dueDate: string;
  requestedBy: string;
  /** Optional override for the request timestamp (used by seed). */
  requestedAt?: number;
}): StatusChangeRequest {
  const entry: StatusChangeRequest = {
    id: `scr-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
    state: "pending",
    requestedAt: input.requestedAt ?? Date.now(),
    launchId: input.launchId,
    taskId: input.taskId,
    taskName: input.taskName,
    fromStatus: input.fromStatus,
    toStatus: input.toStatus,
    issueDescription: input.issueDescription,
    businessImpact: input.businessImpact,
    mitigationPlan: input.mitigationPlan,
    owner: input.owner,
    dueDate: input.dueDate,
    requestedBy: input.requestedBy,
  };
  requests.unshift(entry);
  appendActivity({
    actor: input.requestedBy,
    kind: "task_request_created",
    launchId: input.launchId,
    refId: entry.id,
    detail: `Requested status change "${input.taskName}" → ${statusLabel(input.toStatus)}`,
  });
  appendTaskHistory({
    taskId: input.taskId,
    actor: { name: input.requestedBy, initials: initialsFor(input.requestedBy) },
    field: "status",
    label: "Status change requested",
    before: statusLabel(input.fromStatus),
    after: statusLabel(input.toStatus),
    note: `Requested by ${input.requestedBy}. Root cause: ${input.issueDescription} Business impact: ${input.businessImpact} Action required: ${input.mitigationPlan} Owner: ${input.owner}. Due ${input.dueDate}.`,
  });
  notify();
  return entry;
}

export function approveStatusChangeRequest(id: string, by: string, note?: string): void {
  const req = requests.find((r) => r.id === id);
  if (!req || req.state !== "pending") return;
  req.state = "approved";
  req.reviewedBy = by;
  req.reviewedAt = Date.now();
  req.reviewerNote = note;
  appendActivity({
    actor: by,
    kind: "task_request_approved",
    launchId: req.launchId,
    refId: req.id,
    detail: `Approved status change "${req.taskName}" → ${statusLabel(req.toStatus)}`,
  });
  appendTaskHistory({
    taskId: req.taskId,
    actor: { name: by, initials: initialsFor(by) },
    field: "status",
    label: "Status change approved",
    before: statusLabel(req.fromStatus),
    after: statusLabel(req.toStatus),
    note: `Approved by ${by}. Originally requested by ${req.requestedBy}.${note ? ` Note: ${note}` : ""}`,
  });
  notify();
}

export function rejectStatusChangeRequest(id: string, by: string, note?: string): void {
  const req = requests.find((r) => r.id === id);
  if (!req || req.state !== "pending") return;
  req.state = "rejected";
  req.reviewedBy = by;
  req.reviewedAt = Date.now();
  req.reviewerNote = note;
  appendActivity({
    actor: by,
    kind: "task_request_rejected",
    launchId: req.launchId,
    refId: req.id,
    detail: `Rejected status change "${req.taskName}"${note ? ` — ${note}` : ""}`,
  });
  appendTaskHistory({
    taskId: req.taskId,
    actor: { name: by, initials: initialsFor(by) },
    field: "status",
    label: "Status change rejected",
    before: null,
    after: null,
    note: `Rejected by ${by}. Originally requested by ${req.requestedBy}.${note ? ` Reason: ${note}` : ""}`,
  });
  notify();
}

/**
 * Admin/Superadmin direct override — bypasses the form/approval queue and
 * writes an already-approved request. Audit trail still captured.
 */
export function directOverrideStatus(input: {
  launchId: string;
  taskId: string;
  taskName: string;
  fromStatus: TaskStatus;
  toStatus: StatusChangeTarget;
  by: string;
  note: string;
  dueDate?: string;
}): StatusChangeRequest {
  const entry: StatusChangeRequest = {
    id: `scr-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
    state: "approved",
    launchId: input.launchId,
    taskId: input.taskId,
    taskName: input.taskName,
    fromStatus: input.fromStatus,
    toStatus: input.toStatus,
    issueDescription: input.note,
    businessImpact: "",
    mitigationPlan: "",
    owner: input.by,
    dueDate:
      input.dueDate ??
      new Date(Date.now() + 7 * 86_400_000).toISOString().slice(0, 10),
    requestedBy: input.by,
    requestedAt: Date.now(),
    reviewedBy: input.by,
    reviewedAt: Date.now(),
    directOverride: true,
  };
  requests.unshift(entry);
  appendActivity({
    actor: input.by,
    kind: "task_request_approved",
    launchId: input.launchId,
    refId: entry.id,
    detail: `Direct status override "${input.taskName}" → ${statusLabel(input.toStatus)}`,
  });
  appendTaskHistory({
    taskId: input.taskId,
    actor: { name: input.by, initials: initialsFor(input.by) },
    field: "status",
    label: "Status (override)",
    before: statusLabel(input.fromStatus),
    after: statusLabel(input.toStatus),
    note: `Direct override by ${input.by}.${input.note ? ` Note: ${input.note}` : ""}`,
  });
  notify();
  return entry;
}

function initialsFor(name: string): string {
  return name
    .split(/\s+/)
    .map((w) => w[0])
    .filter(Boolean)
    .slice(0, 2)
    .join("")
    .toUpperCase();
}

export { initialsFor };
