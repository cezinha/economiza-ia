import { isAutoTask, isPhaseCloseTask, type LaunchTask, type TaskFunction } from "@/lib/launchTasks";
import { dueDateFor } from "@/lib/tasks";
import type { Launch } from "@/mocks/launches";
import { effectiveLaunchDate } from "@/mocks/launchDateOverrides";
import { managersFor, membersFor } from "@/mocks/people";
import { gateOffsetDays } from "@/lib/keyMilestones";
import { phasesForLaunch, type ScheduleTrack } from "@/lib/schedule";

function initialsOf(name: string): string {
  return name
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 2)
    .map((w) => w[0]?.toUpperCase() ?? "")
    .join("");
}

/**
 * Function-scoped owner pool for a (launch, function) pair. Manager appears
 * first, then team members. Each TeamMember reports to that single Manager,
 * matching the demo rule: 1 manager per function per platform; users only
 * handle tasks within their function.
 */
function ownersForLaunchFn(launchId: string, fn: TaskFunction): TaskOwner[] {
  const mgrs = managersFor(launchId, fn).map<TaskOwner>((m) => ({
    name: m.name,
    role: `${fn} Manager`,
    initials: initialsOf(m.name),
  }));
  const mems = membersFor(launchId, fn).map<TaskOwner>((m) => ({
    name: m.name,
    role: `${fn} Team`,
    initials: initialsOf(m.name),
  }));
  return [...mgrs, ...mems];
}

export interface TaskOwner {
  name: string;
  role: string;
  initials: string;
}

export interface TaskComment {
  id: string;
  author: string;
  initials: string;
  timestamp: string;
  body: string;
  isRiskFlag?: boolean;
  mentions?: { name: string; initials: string }[];
}

export interface AssignmentEvent {
  id: string;
  timestamp: string;
  from: string;
  to: string;
  by: string;
}

export interface TaskDetails {
  primaryOwner: TaskOwner | null;
  backupOwner: TaskOwner | null;
  comments: TaskComment[];
  history: AssignmentEvent[];
  porDate: string;
  actualDate: string;
  deltaDays: number;
  submissionNotes: string;
  requiredDocs: string[];
  candidateOwners: TaskOwner[];
  isAuto: boolean;
}

export const OWNERS: TaskOwner[] = [
  { name: "Priya Shah", role: "GOE Program Lead", initials: "PS" },
  { name: "Marcus Lee", role: "NPI Engineering", initials: "ML" },
  { name: "Hiroshi Tanaka", role: "Schedule Manager", initials: "HT" },
  { name: "Sara Okafor", role: "GOE Program Lead", initials: "SO" },
  { name: "Daniel Reyes", role: "NPI Engineering", initials: "DR" },
  { name: "Aisha Khan", role: "Schedule Manager", initials: "AK" },
  { name: "Lena Vogel", role: "GOE Program Lead", initials: "LV" },
  { name: "Camila Souza", role: "NPI Engineering", initials: "CS" },
  { name: "Yuki Sato", role: "Schedule Manager", initials: "YS" },
  { name: "Felix Bauer", role: "GOE Program Lead", initials: "FB" },
];

import { TASK_COMMENT_BODIES as COMMENT_BODIES } from "@/lib/taskMitigation";

function hash(str: string): number {
  let h = 0;
  for (let i = 0; i < str.length; i++) h = (h * 31 + str.charCodeAt(i)) >>> 0;
  return h;
}

function pick<T>(arr: T[], seed: number, offset = 0): T {
  return arr[(seed + offset) % arr.length];
}

/**
 * Parse a taskEnd string like "CPE - 7 Days", "DPE + 14 days", "BA - 2wks", "DPE".
 * Returns the milestone code and signed day offset (weeks normalized to days).
 * Returns { code: null, offsetDays: 0 } when no recognizable milestone is found.
 */
function parseTaskEnd(taskEnd: string): { code: string | null; offsetDays: number } {
  if (!taskEnd) return { code: null, offsetDays: 0 };
  const m = taskEnd.trim().match(
    /^([A-Za-z][A-Za-z0-9-]*)\s*(?:([+-])\s*(\d+)\s*(day|days|wk|wks|week|weeks))?\s*$/i,
  );
  if (!m) return { code: null, offsetDays: 0 };
  const code = m[1].toUpperCase();
  if (!m[2]) return { code, offsetDays: 0 };
  const sign = m[2] === "-" ? -1 : 1;
  const n = parseInt(m[3], 10);
  const mult = /^w/i.test(m[4]) ? 7 : 1;
  return { code, offsetDays: sign * n * mult };
}

function addDays(iso: string, days: number): string {
  const d = new Date(iso);
  d.setDate(d.getDate() + days);
  return d.toISOString().slice(0, 10);
}

function formatDate(iso: string): string {
  return new Date(iso).toLocaleDateString("en-US", {
    month: "short",
    day: "numeric",
    year: "numeric",
  });
}

/**
 * ISO date of the phase exit for this task, picking the earliest end across
 * the tracks the task belongs to (strictest cap). Returns null if not found.
 */
function phaseExitIso(launch: Launch, task: LaunchTask): string | null {
  const tracks: ScheduleTrack[] = (task.teams ?? []).map((t) =>
    t === "SChM" ? "SChM" : (t as ScheduleTrack),
  );
  if (tracks.length === 0) tracks.push("GOE");
  let earliest: Date | null = null;
  for (const tr of tracks) {
    const phases = phasesForLaunch(launch, tr);
    const span = phases.find((p) => p.name === task.phase);
    if (span && (!earliest || span.end < earliest)) earliest = span.end;
  }
  return earliest ? earliest.toISOString().slice(0, 10) : null;
}

/** ISO YYYY-MM-DD form of the task's effective due date. */
export function resolveDueDateIso(launch: Launch, task: LaunchTask): string {
  // Phase-close tasks already anchor to the exact phase-exit date.
  if (isPhaseCloseTask(task)) return dueDateFor(launch, task.taskEnd);
  const { code, offsetDays } = parseTaskEnd(task.taskEnd);
  const msOffset = code ? gateOffsetDays(code) : null;
  const anchorOffset = msOffset != null ? msOffset + offsetDays : offsetDays - 60;
  const raw = addDays(effectiveLaunchDate(launch), anchorOffset);
  const exit = phaseExitIso(launch, task);
  return exit && raw > exit ? exit : raw;
}

export function resolveDueDate(launch: Launch, task: LaunchTask): string {
  return formatDate(resolveDueDateIso(launch, task));
}

export function getTaskDetails(task: LaunchTask, launch: Launch): TaskDetails {
  const seed = hash(task.id);
  const auto = isAutoTask(task);
  const isClose = isPhaseCloseTask(task);
  const fn = (task.teams[0] ?? "GOE") as TaskFunction;
  const fnPool = ownersForLaunchFn(launch.id, fn);
  // Fallback to legacy OWNERS only if the function pool is empty (shouldn't happen
  // once people.ts seeds every (launch, fn) pair, but defensive).
  const pool = fnPool.length > 0 ? fnPool : OWNERS;
  // Phase-close approval tasks are always owned by the function's Manager.
  const managerOwner = isClose ? pool.find((o) => /Manager$/.test(o.role)) ?? pool[0] : null;
  const primaryOwner = auto ? null : (isClose ? managerOwner : pick(pool, seed));
  const backupOwner = auto
    ? null
    : isClose
    ? null
    : (pool.length > 1 ? pick(pool.filter((o) => o.name !== primaryOwner!.name), seed, 3) : primaryOwner);
  const candidateOwners = auto || isClose
    ? []
    : pool.filter(
        (o) =>
          o.name !== primaryOwner!.name && o.name !== backupOwner!.name,
      );


  const commentCount = (seed % 3) + 1;
  const comments: TaskComment[] = Array.from({ length: commentCount }).map((_, i) => {
    const author = pick(pool, seed, i + 1);
    const daysAgo = (i + 1) * ((seed % 4) + 1);
    return {
      id: `${task.id}-c${i}`,
      author: author.name,
      initials: author.initials,
      timestamp: `${daysAgo}d ago`,
      body: pick(COMMENT_BODIES, seed, i),
      isRiskFlag: i === 0 && seed % 5 === 0,
    };
  });

  // POR mirrors the resolved due date so the displayed T-minus stays consistent.
  const porIso = resolveDueDateIso(launch, task);
  const drift = isClose ? 0 : (seed % 7) - 3; // -3 .. +3
  const actualIso = addDays(porIso, drift);

  const history: AssignmentEvent[] = auto || isClose
    ? []
    : [
        {
          id: `${task.id}-h1`,
          timestamp: formatDate(addDays(porIso, -45)),
          from: "Unassigned",
          to: pick(pool, seed, 5).name,
          by: "System",
        },
        {
          id: `${task.id}-h2`,
          timestamp: formatDate(addDays(porIso, -20)),
          from: pick(pool, seed, 5).name,
          to: primaryOwner!.name,
          by: pick(pool, seed, 7).name,
        },
      ];



  // Required docs from task name heuristics
  const requiredDocs: string[] = [];
  const t = task.task.toLowerCase();
  if (t.includes("upload")) {
    const m = task.task.match(/Upload (?:the )?(.+?)(?:\s*[\-,]|$)/i);
    if (m) requiredDocs.push(m[1].trim());
  }
  if (t.includes("review")) requiredDocs.push("Review findings memo");
  if (t.includes("schedule")) requiredDocs.push("Schedule worksheet");
  if (t.includes("nudd")) requiredDocs.push("NUDD register entry");
  if (requiredDocs.length === 0) requiredDocs.push("Completion attestation");

  const submissionNotes = auto
    ? "Completed automatically by the system at phase start."
    : "Submitted with full sign-off from the extended team. Supporting artifacts uploaded to the program drive; downstream gate notified.";

  return {
    primaryOwner,
    backupOwner,
    candidateOwners,
    comments,
    history,
    porDate: formatDate(porIso),
    actualDate: formatDate(actualIso),
    deltaDays: drift,
    submissionNotes,
    requiredDocs,
    isAuto: auto,
  };
}
