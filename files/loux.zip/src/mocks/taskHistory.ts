// Mock task version history store. Reverse-chronological per task.
// Field-level diffs allow surgical "restore this field" actions.

export type TaskHistoryField =
  | "status"
  | "primaryOwner"
  | "backupOwner"
  | "dueDate"
  | "comment"
  | "attachment";

export interface TaskHistoryEntry {
  id: string;
  taskId: string | number;
  /** ISO timestamp */
  timestamp: string;
  actor: { name: string; initials: string };
  field: TaskHistoryField;
  /** Display label e.g. "Status", "Primary owner" */
  label: string;
  before: string | null;
  after: string | null;
  /** For comments / attachments where before/after isn't applicable */
  note?: string;
}

const FIELD_LABEL: Record<TaskHistoryField, string> = {
  status: "Status",
  primaryOwner: "Primary owner",
  backupOwner: "Backup owner",
  dueDate: "Due date",
  comment: "Comment",
  attachment: "Attachment",
};

export const taskHistoryFieldLabel = (f: TaskHistoryField) => FIELD_LABEL[f];

// Seed a few demo entries for any task — keyed by taskId. We use a generic
// fallback so every task appears to have at least some history in the PoC.
const seed = (taskId: string | number): TaskHistoryEntry[] => {
  const tid = String(taskId);
  const day = (ago: number) => {
    const d = new Date();
    d.setDate(d.getDate() - ago);
    d.setHours(9, 12, 0, 0);
    return d.toISOString();
  };
  return [
    {
      id: `${tid}-h1`,
      taskId,
      timestamp: day(0),
      actor: { name: "Aisha Khan", initials: "AK" },
      field: "status",
      label: FIELD_LABEL.status,
      before: "On track",
      after: "At risk",
    },
    {
      id: `${tid}-h2`,
      taskId,
      timestamp: day(1),
      actor: { name: "Marcus Lee", initials: "ML" },
      field: "primaryOwner",
      label: FIELD_LABEL.primaryOwner,
      before: "Alex Chen",
      after: "Priya Shah",
    },
    {
      id: `${tid}-h3`,
      taskId,
      timestamp: day(3),
      actor: { name: "Priya Shah", initials: "PS" },
      field: "comment",
      label: FIELD_LABEL.comment,
      before: null,
      after: null,
      note: "Comment added: \"Pinging supplier for ETA confirmation.\"",
    },
    {
      id: `${tid}-h4`,
      taskId,
      timestamp: day(7),
      actor: { name: "Sara Okafor", initials: "SO" },
      field: "dueDate",
      label: FIELD_LABEL.dueDate,
      before: "CPE + 7 Days",
      after: "CPE + 14 Days",
    },
    {
      id: `${tid}-h5`,
      taskId,
      timestamp: day(9),
      actor: { name: "System", initials: "SY" },
      field: "attachment",
      label: FIELD_LABEL.attachment,
      before: null,
      after: null,
      note: "Attachment added: BOM_v3.xlsx",
    },
  ];
};

const runtime: Record<string, TaskHistoryEntry[]> = {};

export function getTaskHistory(taskId: string | number): TaskHistoryEntry[] {
  const k = String(taskId);
  const extra = runtime[k] ?? [];
  return [...extra, ...seed(taskId)].sort((a, b) =>
    b.timestamp.localeCompare(a.timestamp),
  );
}

export function appendTaskHistory(entry: Omit<TaskHistoryEntry, "id" | "timestamp"> & { timestamp?: string }) {
  const k = String(entry.taskId);
  const full: TaskHistoryEntry = {
    id: `${k}-r${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
    timestamp: entry.timestamp ?? new Date().toISOString(),
    ...entry,
  };
  runtime[k] = [full, ...(runtime[k] ?? [])];
  return full;
}

export function formatHistoryWhen(iso: string): { day: string; time: string } {
  const d = new Date(iso);
  const today = new Date();
  const yest = new Date();
  yest.setDate(today.getDate() - 1);
  const sameDay = (a: Date, b: Date) =>
    a.getFullYear() === b.getFullYear() &&
    a.getMonth() === b.getMonth() &&
    a.getDate() === b.getDate();

  const day = sameDay(d, today)
    ? "Today"
    : sameDay(d, yest)
      ? "Yesterday"
      : d.toLocaleDateString(undefined, { month: "short", day: "numeric" });
  const time = d.toLocaleTimeString(undefined, { hour: "numeric", minute: "2-digit" });
  return { day, time };
}
