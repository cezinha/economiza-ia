import type { ScheduleTrack } from "@/lib/schedule";

export type OverrideStatus = "at-risk" | "at-risk-mitigated";

export interface LaunchStatusOverride {
  /** Which function track this override applies to. */
  track: ScheduleTrack;
  /** Status to apply to the first current-phase task on that track. */
  status: OverrideStatus;
}

/**
 * Per-platform tuned mock — each entry flips the first current-phase task on
 * the given track to R/Y so the rollup (task → gate → phase → function →
 * platform) produces a deliberate story aligned with each launch's `rag`
 * value in `src/mocks/launches.ts`.
 *
 * Distribution (kept in sync with launches + coreTeamStatus):
 *  - 5 GREEN platforms → no overrides anywhere.
 *  - 5 AMBER platforms → at-risk-mitigated on GOE, NPI, SChM.
 *  - 5 RED   platforms → at-risk on GOE, NPI, SChM.
 *
 * Net per-track tallies across the 15 launches: 5G / 5Y / 5R for GOE, NPI,
 * SChM, and (via coreTeamStatus) Core.
 */
export const launchOverrides: Record<string, LaunchStatusOverride[]> = {
  // RED platforms
  "L-2003": [
    { track: "GOE",  status: "at-risk" },
    { track: "NPI",  status: "at-risk" },
    { track: "SChM", status: "at-risk" },
  ],
  "L-2004": [
    { track: "GOE",  status: "at-risk" },
    { track: "NPI",  status: "at-risk" },
    { track: "SChM", status: "at-risk" },
  ],
  "L-2010": [
    { track: "GOE",  status: "at-risk" },
    { track: "NPI",  status: "at-risk" },
    { track: "SChM", status: "at-risk" },
  ],
  "L-2014": [
    { track: "GOE",  status: "at-risk" },
    { track: "NPI",  status: "at-risk" },
    { track: "SChM", status: "at-risk" },
  ],
  "L-2009": [
    { track: "GOE",  status: "at-risk" },
    { track: "NPI",  status: "at-risk" },
    { track: "SChM", status: "at-risk" },
  ],

  // AMBER platforms
  "L-2002": [
    { track: "GOE",  status: "at-risk-mitigated" },
    { track: "NPI",  status: "at-risk-mitigated" },
    { track: "SChM", status: "at-risk-mitigated" },
  ],
  "L-2006": [
    { track: "GOE",  status: "at-risk-mitigated" },
    { track: "NPI",  status: "at-risk-mitigated" },
    { track: "SChM", status: "at-risk-mitigated" },
  ],
  "L-2015": [
    { track: "GOE",  status: "at-risk-mitigated" },
    { track: "NPI",  status: "at-risk-mitigated" },
    { track: "SChM", status: "at-risk-mitigated" },
  ],
  "L-2008": [
    { track: "GOE",  status: "at-risk-mitigated" },
    { track: "NPI",  status: "at-risk-mitigated" },
    { track: "SChM", status: "at-risk-mitigated" },
  ],
  "L-2013": [
    { track: "GOE",  status: "at-risk-mitigated" },
    { track: "NPI",  status: "at-risk-mitigated" },
    { track: "SChM", status: "at-risk-mitigated" },
  ],

  // GREEN platforms (L-2001, L-2012, L-2007, L-2005, L-2011) → no overrides.
};
