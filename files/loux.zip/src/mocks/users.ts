// Single source of truth for the "User management" directory.
//
// Generated deterministically from `launches.ts` so the directory always
// satisfies these rules:
//   • Every platform has exactly one Admin per function (GOE / NPI / SChM).
//   • Each Admin manages 2–5 platforms inside a single (BU, Function, LOB).
//   • Each User reports to exactly one Admin, inherits that Admin's
//     BU / Function / LOB, and holds a non-empty subset of the Admin's
//     platforms.
//   • Each Admin has 3–5 Users assigned to them.

import { launches as ALL_LAUNCHES } from "@/mocks/launches";
import { LOB_TO_ORG } from "@/lib/filterCascade";
import type { TaskFunction } from "@/lib/launchTasks";

export type UserRole = "Super Admin" | "Executive" | "Admin" | "User";

export type BusinessUnit = "CSG" | "ISG" | "All";
export type UserFunction = TaskFunction | "All"; // "GOE" | "NPI" | "SChM" | "All"

export interface DirectoryUser {
  id: string;
  name: string;          // "First Last"
  displayName: string;   // Shown in the table
  initials: string;
  email: string;
  role: UserRole;
  enabled: boolean;
  businessUnit: BusinessUnit;
  function: UserFunction;
  lob: string;
  programs: string;      // launch count, or "All" for demo seeds
  dateAdded: string;
  assignedPlatformIds: string[];
  assignedPlatformNames: string[];
  /** For Users: the Admin they report to. */
  managerId?: string;
  managerName?: string;
}

// ---------- helpers ----------
function hashKey(s: string): number {
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

function asciiFold(s: string): string {
  return s
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-zA-Z0-9 .'-]/g, "");
}

function splitName(full: string): { first: string; last: string } {
  const parts = asciiFold(full).trim().split(/\s+/);
  if (parts.length === 1) return { first: parts[0], last: "" };
  const last = parts[parts.length - 1];
  const first = parts.slice(0, -1).join(" ");
  return { first, last };
}

function initialsOf(full: string): string {
  const { first, last } = splitName(full);
  const a = first.charAt(0).toUpperCase();
  const b = last.charAt(0).toUpperCase();
  return (a + b) || full.slice(0, 2).toUpperCase();
}

function emailOf(full: string, suffix?: number): string {
  const { first, last } = splitName(full);
  const local = (last ? `${first}.${last}` : first)
    .toLowerCase()
    .replace(/['.\s]+/g, ".")
    .replace(/\.+/g, ".")
    .replace(/^\.|\.$/g, "");
  return `${local}${suffix ? suffix : ""}@dell.com`;
}

function displayNameOf(full: string): string {
  const { first, last } = splitName(full);
  return last ? `${first} ${last}` : full;
}

function dateAddedOf(): string {
  const d = new Date();
  return `${d.getMonth() + 1}/${d.getDate()}/${d.getFullYear()}`;
}

function enabledFor(name: string): boolean {
  return hashKey(`enabled|${name}`) % 20 !== 0;
}

// ---------- name pools ----------
const ADMIN_POOL = [
  "Asha Rangan", "Brendan O'Neill", "Carla Mendez", "Dimitri Volkov",
  "Eun-Ji Park", "Farhan Siddiqui", "Greta Lindqvist", "Hassan Bakr",
  "Ines Roussel", "Junichi Mori", "Kavita Iyer", "Lukas Becker",
  "Maya Goldberg", "Nikolai Petrov", "Oluwaseun Adebayo", "Patricia Chan",
  "Quinn Harper", "Ravi Subramanian", "Sigrid Hansen", "Tobias Hartmann",
  "Uma Krishnan", "Viktor Novak", "Wendy Zhao", "Xiomara Vega",
];

const USER_POOL = [
  "Anika Patel", "Ben Carter", "Chloe Nguyen", "Diego Romero",
  "Elif Yildiz", "Finn O'Brien", "Gabriela Costa", "Hugo Martin",
  "Ines Carvalho", "Jakob Muller", "Kira Volkova", "Liam Walsh",
  "Maya Cohen", "Nora Lindgren", "Omar Khalil", "Petra Novak",
  "Quentin Laurent", "Rhea Kapoor", "Sven Eriksson", "Tara Singh",
  "Umar Farooq", "Vera Ilic", "Will Hendricks", "Xochitl Ramos",
  "Yusuf Demir", "Zoe Kallis", "Aarav Mehta", "Bianca Ferreira",
  "Caleb Foster", "Dahlia Brennan", "Esme Laurent", "Felix Andersen",
  "Gia Romano", "Hana Suzuki", "Ivan Petrovic", "Jade Ferreira",
  "Kai Nakamura", "Leila Saidi", "Mateo Rivas", "Nadia Haddad",
  "Owen Brennan", "Priya Anand", "Rafael Lima", "Sana Qureshi",
  "Theo Koch", "Uma Reddy", "Vince Calderon", "Wren Halloway",
  "Xander Pope", "Yuri Sokolov",
];

// ---------- partitioning ----------
/** Split N items into chunks of size 2..5, as evenly as possible. */
function chunkSizes(n: number): number[] {
  if (n <= 5) return [n];
  // Try chunk counts from ceil(n/5) upward; pick the smallest k where n/k ∈ [2,5].
  for (let k = Math.ceil(n / 5); k <= Math.floor(n / 2); k++) {
    const base = Math.floor(n / k);
    const extra = n % k;
    if (base >= 2 && base + (extra > 0 ? 1 : 0) <= 5) {
      const out: number[] = [];
      for (let i = 0; i < k; i++) out.push(base + (i < extra ? 1 : 0));
      return out;
    }
  }
  return [n];
}

// ---------- generate Admins ----------
const FUNCTIONS: TaskFunction[] = ["GOE", "NPI", "SChM"];

const launchesById = new Map(ALL_LAUNCHES.map((l) => [l.id, l]));

// (BU, LOB) → ordered platform ids
const platformsByLob = new Map<string, string[]>();
for (const l of ALL_LAUNCHES) {
  const list = platformsByLob.get(l.lob) ?? [];
  list.push(l.id);
  platformsByLob.set(l.lob, list);
}
for (const [k, v] of platformsByLob) {
  platformsByLob.set(k, [...v].sort());
}

const orderedLobs = [...platformsByLob.keys()].sort();

interface AdminSeed {
  bu: BusinessUnit;
  fn: TaskFunction;
  lob: string;
  platformIds: string[];
}

const adminSeeds: AdminSeed[] = [];
for (const lob of orderedLobs) {
  const bu = (LOB_TO_ORG[lob] ?? "CSG") as BusinessUnit;
  const platforms = platformsByLob.get(lob)!;
  for (const fn of FUNCTIONS) {
    const sizes = chunkSizes(platforms.length);
    let cursor = 0;
    for (const size of sizes) {
      adminSeeds.push({
        bu,
        fn,
        lob,
        platformIds: platforms.slice(cursor, cursor + size),
      });
      cursor += size;
    }
  }
}

// Mint Admins with deterministic name picks (avoid name reuse within Admins).
const usedAdminNames = new Set<string>();
function pickAdminName(seedKey: string): string {
  const start = hashKey(`admin|${seedKey}`) % ADMIN_POOL.length;
  for (let i = 0; i < ADMIN_POOL.length; i++) {
    const candidate = ADMIN_POOL[(start + i) % ADMIN_POOL.length];
    if (!usedAdminNames.has(candidate)) {
      usedAdminNames.add(candidate);
      return candidate;
    }
  }
  // Pool exhausted → suffix
  const base = ADMIN_POOL[start];
  let n = 2;
  while (usedAdminNames.has(`${base} ${n}`)) n++;
  const out = `${base} ${n}`;
  usedAdminNames.add(out);
  return out;
}

const adminUsers: DirectoryUser[] = adminSeeds.map((seed, idx) => {
  const seedKey = `${seed.bu}|${seed.fn}|${seed.lob}|${idx}`;
  const name = pickAdminName(seedKey);
  const display = displayNameOf(name);
  return {
    id: `U-A-${hashKey(seedKey).toString(36)}`,
    name,
    displayName: display,
    initials: initialsOf(name),
    email: emailOf(name),
    role: "Admin",
    enabled: enabledFor(name),
    businessUnit: seed.bu,
    function: seed.fn,
    lob: seed.lob,
    programs: String(seed.platformIds.length),
    dateAdded: dateAddedOf(),
    assignedPlatformIds: seed.platformIds,
    assignedPlatformNames: seed.platformIds
      .map((id) => launchesById.get(id)?.name)
      .filter((n): n is string => !!n),
  };
});

// ---------- generate Users (3–5 per Admin) ----------
const usedUserNames = new Set<string>(usedAdminNames);
let userEmailCursor = 0;
function pickUserName(seedKey: string): string {
  const start = hashKey(`user|${seedKey}`) % USER_POOL.length;
  for (let i = 0; i < USER_POOL.length; i++) {
    const candidate = USER_POOL[(start + i) % USER_POOL.length];
    if (!usedUserNames.has(candidate)) {
      usedUserNames.add(candidate);
      return candidate;
    }
  }
  const base = USER_POOL[start];
  let n = 2;
  while (usedUserNames.has(`${base} ${n}`)) n++;
  const out = `${base} ${n}`;
  usedUserNames.add(out);
  return out;
}

const userRecords: DirectoryUser[] = [];
for (const admin of adminUsers) {
  const userCount = 3 + (hashKey(`ucount|${admin.id}`) % 3); // 3..5
  const mgrIds = admin.assignedPlatformIds;
  for (let i = 0; i < userCount; i++) {
    const seedKey = `${admin.id}|${i}`;
    const name = pickUserName(seedKey);
    const display = displayNameOf(name);
    const startSeed = hashKey(`pstart|${seedKey}`);
    const countSeed = hashKey(`pcount|${seedKey}`);
    const subsetSize = 1 + (countSeed % mgrIds.length);
    const start = startSeed % mgrIds.length;
    const picked = new Set<string>();
    for (let j = 0; j < subsetSize; j++) picked.add(mgrIds[(start + j) % mgrIds.length]);
    const ids = Array.from(picked);
    const baseEmail = emailOf(name);
    // Guarantee email uniqueness if a suffixed name collides.
    let email = baseEmail;
    if (userRecords.some((u) => u.email === email) || adminUsers.some((u) => u.email === email)) {
      userEmailCursor++;
      email = emailOf(name, userEmailCursor);
    }
    userRecords.push({
      id: `U-U-${hashKey(seedKey).toString(36)}`,
      name,
      displayName: display,
      initials: initialsOf(name),
      email,
      role: "User",
      enabled: enabledFor(name),
      businessUnit: admin.businessUnit,
      function: admin.function,
      lob: admin.lob,
      programs: String(ids.length),
      dateAdded: dateAddedOf(),
      assignedPlatformIds: ids,
      assignedPlatformNames: ids
        .map((id) => launchesById.get(id)?.name)
        .filter((n): n is string => !!n),
      managerId: admin.id,
      managerName: admin.displayName,
    });
  }
}

// ---------- demo seeds (kept verbatim) ----------
const DEMO_USERS: DirectoryUser[] = [
  {
    id: "U-demo-superadmin",
    name: "Demo Super Admin",
    displayName: "Demo Super Admin",
    initials: "DS",
    email: "demo.superadmin@dell.com",
    role: "Super Admin",
    enabled: true,
    businessUnit: "All",
    function: "All",
    lob: "All",
    programs: "All",
    dateAdded: dateAddedOf(),
    assignedPlatformIds: ALL_LAUNCHES.map((l) => l.id),
    assignedPlatformNames: ALL_LAUNCHES.map((l) => l.name),
  },
  {
    id: "U-demo-executive",
    name: "Demo Executive",
    displayName: "Demo Executive",
    initials: "DE",
    email: "demo.executive@dell.com",
    role: "Executive",
    enabled: true,
    businessUnit: "All",
    function: "All",
    lob: "All",
    programs: "All",
    dateAdded: dateAddedOf(),
    assignedPlatformIds: ALL_LAUNCHES.map((l) => l.id),
    assignedPlatformNames: ALL_LAUNCHES.map((l) => l.name),
  },
];

// ---------- final export ----------
const rolePriority: Record<UserRole, number> = { "Super Admin": 0, Executive: 1, Admin: 2, User: 3 };

export const ALL_USERS: DirectoryUser[] = [...DEMO_USERS, ...adminUsers, ...userRecords].sort((a, b) => {
  const r = rolePriority[a.role] - rolePriority[b.role];
  if (r !== 0) return r;
  return a.displayName.localeCompare(b.displayName);
});

export function userById(id: string): DirectoryUser | undefined {
  return ALL_USERS.find((u) => u.id === id);
}

// ---------- dev-only sanity checks ----------
if (import.meta.env?.DEV) {
  // 1) Every launch appears in exactly 3 Admin platform sets (one per function).
  for (const l of ALL_LAUNCHES) {
    const owners = adminUsers.filter((a) => a.assignedPlatformIds.includes(l.id));
    const fns = new Set(owners.map((a) => a.function));
    console.assert(
      owners.length === 3 && fns.size === 3,
      `[users] launch ${l.id} should have 1 Admin per function, got`, owners,
    );
  }
  // 2) Admin platform counts within 2..5 (or === total LOB platforms when ≤5).
  for (const a of adminUsers) {
    console.assert(
      a.assignedPlatformIds.length >= 2 && a.assignedPlatformIds.length <= 5,
      `[users] admin ${a.id} platform count out of range`, a,
    );
  }
  // 3) Each Admin has 3..5 Users; users inherit scope and subset of platforms.
  for (const a of adminUsers) {
    const team = userRecords.filter((u) => u.managerId === a.id);
    console.assert(
      team.length >= 3 && team.length <= 5,
      `[users] admin ${a.id} should have 3..5 users, got ${team.length}`,
    );
    for (const u of team) {
      console.assert(
        u.businessUnit === a.businessUnit && u.function === a.function && u.lob === a.lob,
        `[users] user ${u.id} scope mismatches manager`, u, a,
      );
      console.assert(
        u.assignedPlatformIds.length > 0 &&
          u.assignedPlatformIds.every((id) => a.assignedPlatformIds.includes(id)),
        `[users] user ${u.id} platforms must be subset of manager`, u, a,
      );
    }
  }
}
