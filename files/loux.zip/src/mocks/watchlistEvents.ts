import { launches } from "@/mocks/launches";
import { NUDDS } from "@/mocks/nudds";

export type WatchlistEventKind = "phase" | "nudd" | "task" | "milestone";

export interface WatchlistEvent {
  id: string;
  platformId: string;
  platformName: string;
  kind: WatchlistEventKind;
  message: string;
  detail?: string;
  createdAt: string; // human-readable
  ts: number; // epoch ms for sorting
  read: boolean;
}

const READ_KEY = "executive.watchlist.events.read.v1";

function loadRead(): Set<string> {
  if (typeof window === "undefined") return new Set();
  try {
    const raw = window.localStorage.getItem(READ_KEY);
    if (!raw) return new Set();
    const parsed = JSON.parse(raw);
    return new Set(Array.isArray(parsed) ? parsed.filter((v): v is string => typeof v === "string") : []);
  } catch {
    return new Set();
  }
}

function persistRead() {
  try {
    window.localStorage.setItem(READ_KEY, JSON.stringify(Array.from(readIds)));
  } catch {
    /* ignore */
  }
}

const readIds: Set<string> = loadRead();

const subscribers = new Set<() => void>();
function emit() { for (const s of subscribers) s(); }

export function subscribeWatchlistEvents(cb: () => void): () => void {
  subscribers.add(cb);
  return () => { subscribers.delete(cb); };
}

// Build events derived from launches + NUDDs at module init.
const NOW = Date.now();
const HOUR = 3_600_000;

function relTime(ts: number): string {
  const diff = NOW - ts;
  const h = Math.round(diff / HOUR);
  if (h < 1) return "just now";
  if (h < 24) return `${h}h ago`;
  const d = Math.round(h / 24);
  return d === 1 ? "Yesterday" : `${d}d ago`;
}

const ALL_EVENTS: WatchlistEvent[] = (() => {
  const out: WatchlistEvent[] = [];
  let n = 0;
  for (const l of launches) {
    if (l.rag === "red") {
      const ts = NOW - (2 + (n % 6)) * HOUR;
      out.push({
        id: `we-${++n}`,
        platformId: l.id,
        platformName: l.name,
        kind: "phase",
        message: `${l.phase} phase flagged red`,
        detail: `Next milestone "${l.nextMilestone}" due ${l.nextMilestoneDate}`,
        createdAt: relTime(ts),
        ts,
        read: false,
      });
    } else if (l.rag === "amber") {
      const ts = NOW - (8 + (n % 12)) * HOUR;
      out.push({
        id: `we-${++n}`,
        platformId: l.id,
        platformName: l.name,
        kind: "task",
        message: `Task at risk with mitigation`,
        detail: `${l.nextMilestone} — ${l.nextMilestoneDate}`,
        createdAt: relTime(ts),
        ts,
        read: false,
      });
    }
    // Milestone reminder: any platform with upcoming milestone in next 14 days
    const due = new Date(l.nextMilestoneDate).getTime();
    if (!isNaN(due) && due - NOW < 14 * 24 * HOUR && due - NOW > 0) {
      const ts = NOW - (1 + (n % 4)) * HOUR;
      out.push({
        id: `we-${++n}`,
        platformId: l.id,
        platformName: l.name,
        kind: "milestone",
        message: `Upcoming milestone: ${l.nextMilestone}`,
        detail: `Due ${l.nextMilestoneDate}`,
        createdAt: relTime(ts),
        ts,
        read: false,
      });
    }
  }
  // NUDD escalations: any open NUDD
  for (const nudd of NUDDS) {
    if (nudd.status !== "Open") continue;
    const launch = launches.find((l) => l.name === nudd.platform);
    if (!launch) continue;
    const ts = NOW - (3 + (n % 10)) * HOUR;
    out.push({
      id: `we-${++n}`,
      platformId: launch.id,
      platformName: launch.name,
      kind: "nudd",
      message: `Open NUDD: ${nudd.title}`,
      detail: `Severity ${nudd.impact * nudd.probability}/9`,
      createdAt: relTime(ts),
      ts,
      read: false,
    });
  }
  out.sort((a, b) => b.ts - a.ts);
  return out;
})();

export function getWatchlistEvents(platformIds: string[]): WatchlistEvent[] {
  if (platformIds.length === 0) return [];
  const set = new Set(platformIds);
  return ALL_EVENTS
    .filter((e) => set.has(e.platformId))
    .map((e) => ({ ...e, read: readIds.has(e.id) }));
}

export function unreadWatchlistCount(platformIds: string[]): number {
  return getWatchlistEvents(platformIds).filter((e) => !e.read).length;
}

export function markEventRead(id: string) {
  if (readIds.has(id)) return;
  readIds.add(id);
  persistRead();
  emit();
}

export function markAllRead(platformIds: string[]) {
  let changed = false;
  for (const e of getWatchlistEvents(platformIds)) {
    if (!readIds.has(e.id)) { readIds.add(e.id); changed = true; }
  }
  if (changed) { persistRead(); emit(); }
}
