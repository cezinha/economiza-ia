import { PageHeader } from "@/components/shell/PageHeader";
import { ComingSoon } from "@/components/shell/ComingSoon";

export default function ActivityPage() {
  return (
    <div className="space-y-8">
      <PageHeader eyebrow="Audit" title="Archive" breadcrumbs={[{ label: "Archive" }]} />
      <ComingSoon />
    </div>
  );
}
