import { PageHeader } from "@/components/shell/PageHeader";
import { ComingSoon } from "@/components/shell/ComingSoon";

export default function BuildExecutionPage() {
  return (
    <div className="space-y-8">
      <PageHeader title="Build execution" breadcrumbs={[{ label: "Build execution" }]} />
      <ComingSoon />
    </div>
  );
}
