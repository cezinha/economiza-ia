import { useState } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { Eye, Pencil, Trash2, Folder, Filter, Bell, Plus, Mail, Check, Info } from "lucide-react";
import { PageHeader } from "@/components/shell/PageHeader";
import { DebugTab } from "@/components/curator/DebugTab";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { cn } from "@/lib/utils";
import { useIsReadOnly } from "@/lib/permissions";
import { launches } from "@/mocks/launches";
import { LOB_TO_ORG } from "@/lib/filterCascade";
import { DdsPagination } from "@/components/shell/DdsPagination";

/* ------------------------------- Programs ------------------------------- */

type ProgramRow = {
  launchId: string;
  organization: "CSG" | "ISG";
  lob: string;
  platform: string;
  status: "Active" | "Pending confirmation";
  totalDocuments: number;
};

/** Deterministic mock document count per launch id (stable across renders). */
function mockDocCount(id: string): number {
  let h = 0;
  for (let i = 0; i < id.length; i++) h = (h * 31 + id.charCodeAt(i)) >>> 0;
  return (h % 1400) + 200;
}

const programRows: ProgramRow[] = launches.map((l, i) => ({
  launchId: l.id,
  organization: (LOB_TO_ORG[l.lob] ?? "CSG") as "CSG" | "ISG",
  lob: l.lob,
  platform: l.name,
  // Deterministic mix: indices 2 and 9 are "Pending confirmation"
  status: i === 2 || i === 9 ? "Pending confirmation" : "Active",
  totalDocuments: mockDocCount(l.id),
}));

function StatusBadge({ status }: { status: ProgramRow["status"] }) {
  if (status === "Active") {
    return (
      <Badge
        className="border-0 font-normal hover:opacity-90 gap-1"
        style={{ backgroundColor: "#0672CB", color: "#D9F5FD" }}
      >
        <Check className="h-3 w-3" strokeWidth={3} aria-hidden />
        Active
      </Badge>
    );
  }
  return (
    <Badge
      className="border-0 font-normal hover:opacity-90 gap-1"
      style={{ backgroundColor: "#6E6E6E", color: "#F5F6F7" }}
    >
      <TooltipProvider delayDuration={150}>
        <Tooltip>
          <TooltipTrigger asChild>
            <button
              type="button"
              className="inline-flex items-center justify-center focus:outline-none"
              aria-label="Configuration pending admin completion"
            >
              <Info className="h-3 w-3" strokeWidth={2.5} aria-hidden />
            </button>
          </TooltipTrigger>
          <TooltipContent side="top">Configuration pending admin completion</TooltipContent>
        </Tooltip>
      </TooltipProvider>
      Pending confirmation
    </Badge>
  );
}

function ProgramsTab() {
  const navigate = useNavigate();
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(25);
  const totalItems = programRows.length;
  const totalPages = Math.max(1, Math.ceil(totalItems / pageSize));
  const safePage = Math.min(page, totalPages);
  const pagedRows = programRows.slice((safePage - 1) * pageSize, safePage * pageSize);
  const stickyRight = "sticky right-0 bg-inherit shadow-elev-left-1 before:absolute before:left-0 before:top-0 before:bottom-0 before:w-px before:bg-border before:content-['']";
  return (
    <div className="rounded-lg border border-border bg-card p-6 shadow-elev-1 space-y-6">
      <Table containerClassName="max-h-[640px]">
        <TableHeader className="sticky top-0 z-10 bg-card shadow-elev-1">
          <TableRow>
            <TableHead className="text-h6">Business unit</TableHead>
            <TableHead className="text-h6">LOB</TableHead>
            <TableHead className="text-h6">Platform</TableHead>
            <TableHead className="text-h6">Status</TableHead>
            <TableHead className="text-h6 text-right">Total documents</TableHead>
            <TableHead className={cn("text-h6 z-20 bg-card", stickyRight)}>
              <div className="flex justify-end">
                <span className="w-[112px] text-left">Full list</span>
              </div>
            </TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {pagedRows.map((row, idx) => {
            const go = () => navigate(`/curator/platform/${row.launchId}`);
            return (
              <TableRow
                key={`${row.launchId}-${idx}`}
                className={idx % 2 === 0 ? "bg-muted hover:bg-muted" : "bg-card hover:bg-card"}
              >
                <TableCell className="text-body-3" style={{ color: "#0E0E0E" }}>{row.organization}</TableCell>
                <TableCell className="text-body-3" style={{ color: "#0E0E0E" }}>{row.lob}</TableCell>
                <TableCell className="text-body-3" style={{ color: "#0E0E0E" }}>{row.platform}</TableCell>
                <TableCell><StatusBadge status={row.status} /></TableCell>
                <TableCell className="text-body-3 text-right tabular-nums" style={{ color: "#0E0E0E" }}>
                  {row.totalDocuments.toLocaleString()}
                </TableCell>
                <TableCell className={cn(stickyRight)}>
                  <div className="flex justify-end">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={go}
                      className="w-[112px] text-button-2 border bg-transparent hover:bg-[#0672CB]/10 active:bg-[#0672CB]/20 focus-visible:ring-2 focus-visible:ring-[#0672CB]/40"
                      style={{ borderColor: "#0672CB", color: "#0672CB" }}
                    >
                      View details
                    </Button>
                  </div>
                </TableCell>
              </TableRow>
            );
          })}
        </TableBody>
      </Table>
      <div className="flex justify-center pt-2">
        <DdsPagination
          page={safePage}
          pageSize={pageSize}
          totalItems={totalItems}
          itemLabel="rows"
          onPageChange={setPage}
          onPageSizeChange={setPageSize}
        />
      </div>
    </div>
  );
}

/* ------------------------------- Settings ------------------------------- */

type SettingsSection = "doctypes" | "rules" | "notifications";

const settingsNav: { id: SettingsSection; label: string; icon: typeof Folder }[] = [
  { id: "doctypes", label: "Document Types", icon: Folder },
  { id: "rules", label: "Classification Rules", icon: Filter },
  { id: "notifications", label: "Notifications", icon: Bell },
];


/* Document Types */

type SchemaState = "Defined" | "None";
type DocTypeRow = {
  name: string;
  displayName: string;
  lob: string;
  description: string;
  schema: SchemaState;
  rules: number;
  active: boolean;
};

const docTypeRows: DocTypeRow[] = [
  { name: "ARD", displayName: "Architecture Requirements Document", lob: "Notebook", description: "ARD outlines the key architectural requiremen...", schema: "Defined", rules: 0, active: true },
  { name: "ARD", displayName: "Architecture Requirements Document", lob: "—", description: "ARD outlines the key architectural requiremen...", schema: "Defined", rules: 4, active: false },
  { name: "Build Plan", displayName: "Build Plan", lob: "Notebook", description: "Factory build plan for product ramp.", schema: "Defined", rules: 0, active: true },
  { name: "Build Plan", displayName: "Build Plan", lob: "—", description: "Factory build plan for product ramp.", schema: "None", rules: 2, active: true },
  { name: "Cable Plan/Cable List", displayName: "—", lob: "—", description: "—", schema: "None", rules: 0, active: true },
  { name: "CIT", displayName: "Chassis Integration Test", lob: "Server", description: "—", schema: "None", rules: 0, active: true },
  { name: "Complexity Matrix", displayName: "Complexity Matrix", lob: "Notebook", description: "Complexity matrix provided by PMO.", schema: "Defined", rules: 0, active: true },
  { name: "Complexity Matrix", displayName: "Complexity Matrix", lob: "—", description: "Complexity matrix provided by PMO.", schema: "None", rules: 2, active: true },
  { name: "CSTL", displayName: "CSTL", lob: "Desktop", description: "Platform certification for shipping.", schema: "Defined", rules: 0, active: true },
  { name: "CSTL", displayName: "CSTL", lob: "—", description: "Platform certification for shipping.", schema: "None", rules: 2, active: true },
  { name: "CSTL", displayName: "CSTL", lob: "Notebook", description: "Platform certification for shipping.", schema: "Defined", rules: 0, active: true },
  { name: "CTCR", displayName: "CTCR", lob: "—", description: "—", schema: "None", rules: 0, active: true },
  { name: "Engg. NUDD", displayName: "Engineering NUDD", lob: "—", description: "JIRA NUDD issue from engineering.", schema: "None", rules: 0, active: true },
  { name: "Memory Matrix", displayName: "Memory Matrix", lob: "—", description: "Provides guidance on DIMM (Dual In-line Me...", schema: "None", rules: 3, active: true },
  { name: "Ops NUDD", displayName: "Ops NUDD", lob: "—", description: "JIRA NUDD issue from operations.", schema: "None", rules: 0, active: true },
  { name: "PRD", displayName: "Product Requirements Document", lob: "—", description: "PRD is Program Requirements Document.", schema: "Defined", rules: 3, active: true },
  { name: "PRD", displayName: "Product Requirements Document", lob: "Notebook", description: "PRD is Program Requirements Document.", schema: "Defined", rules: 0, active: true },
  { name: "Program Schedule", displayName: "Program Schedule", lob: "Desktop", description: "Program major Milestones (Phase Exits).", schema: "Defined", rules: 0, active: true },
  { name: "Slot Priority Matrix", displayName: "Slot Priority Matrix", lob: "—", description: "SPM is database for slot information.", schema: "None", rules: 3, active: true },
  { name: "Storage Matrix", displayName: "Storage Matrix", lob: "—", description: "A storage supportability matrix.", schema: "None", rules: 3, active: true },
];

function DocumentTypesSection() {
  const readOnly = useIsReadOnly();
  return (
    <div className="rounded-lg border border-border bg-card p-6 shadow-elev-1 space-y-6">
      <div className="flex items-start justify-between gap-4">
        <div>
          <h2 className="text-h5">Document Types</h2>
          <p className="text-body-3 text-muted-foreground mt-1">Define and manage your document type classifications</p>
        </div>
        {!readOnly && (
        <Button className="gap-2">
          <Plus className="h-4 w-4" /> Add Type
        </Button>
        )}
      </div>

      <Table>
        <TableHeader>
          <TableRow>
            <TableHead className="text-subtitle-2">Name</TableHead>
            <TableHead className="text-subtitle-2">Display Name</TableHead>
            <TableHead className="text-subtitle-2">LOB</TableHead>
            <TableHead className="text-subtitle-2">Description</TableHead>
            <TableHead className="text-subtitle-2">Schema</TableHead>
            <TableHead className="text-subtitle-2 text-right">Rules</TableHead>
            <TableHead className="text-subtitle-2">Status</TableHead>
            <TableHead className="text-subtitle-2 text-right">Actions</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {docTypeRows.map((row, i) => (
            <TableRow key={`${row.name}-${row.lob}-${i}`}>
              <TableCell>
                <Badge variant="outline" className="font-mono text-caption">{row.name}</Badge>
              </TableCell>
              <TableCell className="text-body-3">{row.displayName}</TableCell>
              <TableCell className="text-body-3 text-primary">{row.lob}</TableCell>
              <TableCell className="text-body-3 text-muted-foreground max-w-xs truncate">{row.description}</TableCell>
              <TableCell>
                {row.schema === "Defined" ? (
                  <Badge className="border-0 bg-status-active/15 text-status-active hover:bg-status-active/15">Defined</Badge>
                ) : (
                  <Badge variant="outline" className="text-muted-foreground">None</Badge>
                )}
              </TableCell>
              <TableCell className="text-body-3 text-right tabular-nums">{row.rules}</TableCell>
              <TableCell>
                {row.active ? (
                  <Badge className="border-0 bg-status-active/15 text-status-active hover:bg-status-active/15">Active</Badge>
                ) : (
                  <Badge variant="outline" className="text-muted-foreground">Inactive</Badge>
                )}
              </TableCell>
              <TableCell>
                <div className="flex items-center justify-end gap-1">
                  <Button variant="ghost" size="icon" className="h-8 w-8"><Eye className="h-4 w-4" /></Button>
                  {!readOnly && <Button variant="ghost" size="icon" className="h-8 w-8"><Pencil className="h-4 w-4" /></Button>}
                  {!readOnly && <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive"><Trash2 className="h-4 w-4" /></Button>}
                </div>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
}

/* Classification Rules */

type RuleType = "FILENAME" | "FOLDER";
type RuleRow = {
  documentType: string;
  type: RuleType;
  pattern: string;
  priority: number;
  confidence: number;
};

const ruleRows: RuleRow[] = [
  { documentType: "ARD", type: "FILENAME", pattern: "(?<!C)\\bARD\\b", priority: 1, confidence: 0.9 },
  { documentType: "CSTL", type: "FILENAME", pattern: "\\bCSTL\\b", priority: 1, confidence: 0.9 },
  { documentType: "Functional Plan", type: "FILENAME", pattern: "\\bFUNCTIONAL[_\\s]?PLAN\\b", priority: 1, confidence: 0.9 },
  { documentType: "Program Schedule", type: "FILENAME", pattern: "\\b(SCHEDULE|TIMELINE)\\b", priority: 1, confidence: 0.9 },
  { documentType: "Build Plan", type: "FILENAME", pattern: "\\bBUILD[_\\s]?PLAN\\b", priority: 1, confidence: 0.9 },
  { documentType: "FM-Feature Matrix", type: "FILENAME", pattern: "\\bFEATURE[_\\s]?MATRIX\\b", priority: 1, confidence: 0.9 },
  { documentType: "PRD", type: "FILENAME", pattern: "\\bPRD\\b", priority: 1, confidence: 0.9 },
  { documentType: "ID Book", type: "FILENAME", pattern: "\\bID[_\\s-]?BOOK\\b", priority: 1, confidence: 0.9 },
  { documentType: "Engineering Restrictions", type: "FILENAME", pattern: "ENGINEERING[_\\s]+RESTRICTION", priority: 1, confidence: 0.9 },
  { documentType: "GCD", type: "FILENAME", pattern: "\\bGCD\\b", priority: 1, confidence: 0.9 },
  { documentType: "Complexity Matrix", type: "FILENAME", pattern: "\\bCOMPLEXITY\\b", priority: 1, confidence: 0.9 },
  { documentType: "Ecosystem Matrix", type: "FILENAME", pattern: "\\bECOSYSTEM\\b", priority: 1, confidence: 0.9 },
  { documentType: "ARD", type: "FOLDER", pattern: "ARD", priority: 1, confidence: 0.7 },
  { documentType: "CSTL", type: "FOLDER", pattern: "CSTL", priority: 1, confidence: 0.7 },
  { documentType: "Functional Plan", type: "FOLDER", pattern: "FUNCTIONAL[_\\s]?PLAN", priority: 1, confidence: 0.7 },
  { documentType: "Program Schedule", type: "FOLDER", pattern: "(SCHEDULE|TIMELINE)", priority: 1, confidence: 0.7 },
  { documentType: "Build Plan", type: "FOLDER", pattern: "BUILD[_\\s]?PLAN", priority: 1, confidence: 0.7 },
  { documentType: "FM-Feature Matrix", type: "FOLDER", pattern: "FEATURE[_\\s]?MATRIX", priority: 1, confidence: 0.7 },
  { documentType: "PRD", type: "FOLDER", pattern: "PRD", priority: 1, confidence: 0.7 },
  { documentType: "ID Book", type: "FOLDER", pattern: "ID[_\\s-]?BOOK", priority: 1, confidence: 0.7 },
  { documentType: "Engineering Restrictions", type: "FOLDER", pattern: "ENGINEERING[_\\s]+RESTRICTION", priority: 1, confidence: 0.7 },
  { documentType: "GCD", type: "FOLDER", pattern: "GCD", priority: 1, confidence: 0.7 },
  { documentType: "Complexity Matrix", type: "FOLDER", pattern: "COMPLEXITY", priority: 1, confidence: 0.65 },
  { documentType: "Ecosystem Matrix", type: "FOLDER", pattern: "ECOSYSTEM", priority: 1, confidence: 0.65 },
];

function ClassificationRulesSection() {
  const readOnly = useIsReadOnly();
  return (
    <div className="rounded-lg border border-border bg-card p-6 shadow-elev-1 space-y-6">
      <div className="flex items-start justify-between gap-4">
        <div>
          <h2 className="text-h5">Classification Rules</h2>
          <p className="text-body-3 text-muted-foreground mt-1">Configure pattern-based rules for automatic document classification</p>
        </div>
        <div className="flex items-center gap-3">
          <Button variant="outline">All Document Types</Button>
          {!readOnly && (
          <Button className="gap-2">
            <Plus className="h-4 w-4" /> Add Rule
          </Button>
          )}
        </div>
      </div>

      <Table>
        <TableHeader>
          <TableRow>
            <TableHead className="text-subtitle-2">Document Type</TableHead>
            <TableHead className="text-subtitle-2">Type</TableHead>
            <TableHead className="text-subtitle-2">Pattern</TableHead>
            <TableHead className="text-subtitle-2 text-right">Priority</TableHead>
            <TableHead className="text-subtitle-2 text-right">Confidence</TableHead>
            <TableHead className="text-subtitle-2">Status</TableHead>
            <TableHead className="text-subtitle-2 text-right">Actions</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {ruleRows.map((r, i) => (
            <TableRow key={`${r.documentType}-${r.type}-${i}`}>
              <TableCell>
                <Badge variant="outline" className="font-mono text-caption">{r.documentType}</Badge>
              </TableCell>
              <TableCell>
                <Badge className="border-0 bg-accent text-accent-foreground hover:bg-accent">{r.type}</Badge>
              </TableCell>
              <TableCell className="font-mono text-caption text-primary">{r.pattern}</TableCell>
              <TableCell className="text-body-3 text-right tabular-nums">{r.priority}</TableCell>
              <TableCell className="text-body-3 text-right tabular-nums">{r.confidence}</TableCell>
              <TableCell>
                <Badge className="border-0 bg-status-active/15 text-status-active hover:bg-status-active/15">Active</Badge>
              </TableCell>
              <TableCell>
                <div className="flex items-center justify-end gap-1">
                  <Button variant="ghost" size="icon" className="h-8 w-8"><Eye className="h-4 w-4" /></Button>
                  {!readOnly && <Button variant="ghost" size="icon" className="h-8 w-8"><Pencil className="h-4 w-4" /></Button>}
                  {!readOnly && <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive"><Trash2 className="h-4 w-4" /></Button>}
                </div>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
}

/* Notifications */

function NotificationsSection() {
  const readOnly = useIsReadOnly();
  const [unit, setUnit] = useState<"hours" | "days">("days");
  const [value, setValue] = useState(3);
  const totalHours = unit === "days" ? value * 24 : value;

  return (
    <div className="rounded-lg border border-border bg-card p-6 shadow-elev-1 space-y-6">
      <div>
        <h2 className="text-h5">Notifications</h2>
        <p className="text-body-3 text-muted-foreground mt-1">
          Trigger email notifications for change-detection results within a time window
        </p>
      </div>

      <div className="space-y-3">
        <div>
          <h3 className="text-subtitle-2">Lookback Window</h3>
          <p className="text-body-3 text-muted-foreground">
            Select how far back to look for change-detection runs when sending notifications.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <Input
            type="number"
            min={1}
            value={value}
            onChange={(e) => setValue(Math.max(1, Number(e.target.value) || 1))}
            className="w-20"
            disabled={readOnly}
          />
          <div className="inline-flex rounded-md border border-border overflow-hidden">
            <button
              type="button"
              disabled={readOnly}
              onClick={() => setUnit("hours")}
              className={cn(
                "px-4 py-2 text-button-2 disabled:opacity-60 disabled:cursor-not-allowed",
                unit === "hours" ? "bg-primary text-primary-foreground" : "bg-card text-foreground",
              )}
            >
              Hours
            </button>
            <button
              type="button"
              disabled={readOnly}
              onClick={() => setUnit("days")}
              className={cn(
                "px-4 py-2 text-button-2 border-l border-border disabled:opacity-60 disabled:cursor-not-allowed",
                unit === "days" ? "bg-primary text-primary-foreground" : "bg-card text-foreground",
              )}
            >
              Days
            </button>
          </div>
        </div>

        <p className="text-body-3 text-muted-foreground">
          Notifications will cover the last <span className="font-medium text-foreground">{value} {unit}</span>
          {unit === "days" && <> ({totalHours} hours)</>}
        </p>
      </div>

      {!readOnly && (
      <Button className="gap-2">
        <Mail className="h-4 w-4" /> Send Notifications
      </Button>
      )}
    </div>
  );
}

/* Settings tab shell */

function SettingsTab() {
  const [section, setSection] = useState<SettingsSection>("doctypes");

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-h4">Settings</h2>
        <p className="text-subtitle-2 text-muted-foreground mt-1">
          Manage document types, classification rules, and notification frequency
        </p>
      </div>

      <div role="tablist" aria-label="Settings sections" className="flex items-stretch gap-1 border-b border-border bg-muted/40 rounded-t-md p-1">
        {settingsNav.map((item) => {
          const Icon = item.icon;
          const active = section === item.id;
          return (
            <button
              key={item.id}
              type="button"
              role="tab"
              aria-selected={active}
              onClick={() => setSection(item.id)}
              className={cn(
                "relative flex items-center gap-2 px-4 py-2 text-body-3 transition-colors border-t-2",
                active
                  ? "bg-card text-primary font-medium rounded-t-sm shadow-elev-1 border-primary"
                  : "bg-transparent text-muted-foreground hover:text-foreground border-transparent",
              )}
            >
              <Icon className="h-4 w-4" />
              {item.label}
            </button>
          );
        })}
      </div>

      <div className="min-w-0">
        {section === "doctypes" && <DocumentTypesSection />}
        {section === "rules" && <ClassificationRulesSection />}
        {section === "notifications" && <NotificationsSection />}
      </div>
    </div>
  );
}

/* ----------------------------------------------------------------------- */

export default function CuratorPage() {
  const [searchParams, setSearchParams] = useSearchParams();
  const param = searchParams.get("tab");
  const tab = param === "settings" || param === "debug" ? param : "programs";
  const setTab = (v: string) => {
    const next = new URLSearchParams(searchParams);
    if (v === "programs") next.delete("tab");
    else next.set("tab", v);
    setSearchParams(next, { replace: true });
  };
  return (
    <div className="space-y-8">
      <PageHeader
        eyebrow="Knowledge"
        title="Doc and data curator"
        description="Access required documents / data artifacts and receive change notifications"
        breadcrumbs={[{ label: "Doc and data curator" }]}
      />

      <Tabs value={tab} onValueChange={setTab} className="w-full">
        <TabsList>
          <TabsTrigger value="programs">Programs</TabsTrigger>
          <TabsTrigger value="settings">Settings</TabsTrigger>
          <TabsTrigger value="debug">Debug</TabsTrigger>
        </TabsList>

        <TabsContent value="programs" className="mt-6">
          <ProgramsTab />
        </TabsContent>
        <TabsContent value="settings" className="mt-6">
          <SettingsTab />
        </TabsContent>
        <TabsContent value="debug" className="mt-6">
          <DebugTab />
        </TabsContent>
      </Tabs>
    </div>
  );
}
