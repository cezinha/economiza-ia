import { useMemo, useState } from "react";
import { Link, useParams } from "react-router-dom";
import { ArrowLeft, Download, Eye, FileText } from "lucide-react";
import { PageHeader } from "@/components/shell/PageHeader";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { launches } from "@/mocks/launches";
import { LOB_TO_ORG } from "@/lib/filterCascade";
import { buildCuratorDocs, type CuratorDocStatus, type CuratorDataSource } from "@/mocks/curatorDocuments";
import { cn } from "@/lib/utils";

function StatusBadge({ status }: { status: CuratorDocStatus }) {
  if (status === "Active") {
    return (
      <Badge className="border-0 bg-status-active/15 text-status-active hover:bg-status-active/15">
        Active
      </Badge>
    );
  }
  if (status === "Pending review") {
    return (
      <Badge className="border-0 bg-warning/15 text-warning hover:bg-warning/15">
        Pending review
      </Badge>
    );
  }
  return (
    <Badge variant="outline" className="text-muted-foreground">
      Archived
    </Badge>
  );
}

const DATA_SOURCE_DOT: Record<CuratorDataSource, string> = {
  SharePoint: "bg-primary",
  Jira: "bg-warning",
  Confluence: "bg-status-active",
  Regrello: "bg-accent",
};

function DataSourceBadge({ source }: { source: CuratorDataSource }) {
  return (
    <Badge variant="outline" className="gap-2 text-caption font-normal">
      <span className={cn("inline-block h-2 w-2 rounded-full", DATA_SOURCE_DOT[source])} aria-hidden />
      {source}
    </Badge>
  );
}

function formatSize(kb: number): string {
  if (kb < 1024) return `${kb} KB`;
  return `${(kb / 1024).toFixed(1)} MB`;
}

type FilterKey = "name" | "type" | "lob" | "lastUpdated" | "size" | "status" | "dataSource";

const EMPTY_FILTERS: Record<FilterKey, string> = {
  name: "",
  type: "",
  lob: "",
  lastUpdated: "",
  size: "",
  status: "",
  dataSource: "",
};

export default function CuratorPlatformPage() {
  const { platformId } = useParams<{ platformId: string }>();
  const launch = useMemo(
    () => launches.find((l) => l.id === platformId),
    [platformId],
  );
  const [filters, setFilters] = useState<Record<FilterKey, string>>(EMPTY_FILTERS);

  if (!launch) {
    return (
      <div className="space-y-6">
        <PageHeader
          title="Platform not found"
          breadcrumbs={[
            { label: "Doc & data curator", to: "/curator" },
            { label: "Not found" },
          ]}
        />
        <Link to="/curator" className="inline-flex items-center gap-2 text-primary text-body-3">
          <ArrowLeft className="h-4 w-4" /> Back to curator
        </Link>
      </div>
    );
  }

  const org = (LOB_TO_ORG[launch.lob] ?? "CSG") as "CSG" | "ISG";
  const docs = useMemo(
    () => buildCuratorDocs(launch.id, launch.name, launch.lob),
    [launch.id, launch.name, launch.lob],
  );

  const filteredDocs = useMemo(() => {
    const match = (val: string, q: string) =>
      q.trim() === "" || val.toLowerCase().includes(q.trim().toLowerCase());
    return docs.filter((d) =>
      match(d.name, filters.name) &&
      match(d.type, filters.type) &&
      match(d.lob, filters.lob) &&
      match(d.lastUpdated, filters.lastUpdated) &&
      match(formatSize(d.sizeKb), filters.size) &&
      match(d.status, filters.status) &&
      match(d.dataSource, filters.dataSource)
    );
  }, [docs, filters]);

  const lastUpdated = docs.length > 0 ? docs[0].lastUpdated : "—";

  const setFilter = (key: FilterKey) => (e: React.ChangeEvent<HTMLInputElement>) =>
    setFilters((prev) => ({ ...prev, [key]: e.target.value }));

  return (
    <div className="space-y-6">
      <PageHeader
        title={launch.name}
        description={`Documents and data sources for ${launch.name}`}
        breadcrumbs={[
          { label: "Doc & data curator", to: "/curator" },
          { label: launch.name },
        ]}
        actions={
          <Button asChild variant="ghost" className="gap-2">
            <Link to="/curator">
              <ArrowLeft className="h-4 w-4" /> Back to programs
            </Link>
          </Button>
        }
      />

      <div className="grid grid-cols-2 gap-4 s:grid-cols-4">
        <SummaryCard label="Business unit" value={org} />
        <SummaryCard label="LOB" value={launch.lob} />
        <SummaryCard label="Total documents" value={docs.length.toString()} />
        <SummaryCard label="Last updated" value={lastUpdated} />
      </div>

      <div className="rounded-lg border border-border bg-card shadow-elev-1">
        <div className="flex items-center justify-between px-6 py-4 border-b border-border">
          <div>
            <h2 className="text-h6">Documents &amp; data sources</h2>
            <p className="text-body-3 text-muted-foreground mt-1">
              {filteredDocs.length} of {docs.length} item{docs.length === 1 ? "" : "s"} associated with this platform
            </p>
          </div>
        </div>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="text-subtitle-2">Name</TableHead>
              <TableHead className="text-subtitle-2">Document type</TableHead>
              <TableHead className="text-subtitle-2">LOB</TableHead>
              <TableHead className="text-subtitle-2">Last updated</TableHead>
              <TableHead className="text-subtitle-2 text-right">Size</TableHead>
              <TableHead className="text-subtitle-2">Status</TableHead>
              <TableHead className="text-subtitle-2">Data source</TableHead>
              <TableHead className="text-subtitle-2 text-right">Actions</TableHead>
            </TableRow>
            <TableRow className="hover:bg-transparent">
              <TableHead className="py-2">
                <Input value={filters.name} onChange={setFilter("name")} placeholder="Filter…" className="h-8 text-body-3" />
              </TableHead>
              <TableHead className="py-2">
                <Input value={filters.type} onChange={setFilter("type")} placeholder="Filter…" className="h-8 text-body-3" />
              </TableHead>
              <TableHead className="py-2">
                <Input value={filters.lob} onChange={setFilter("lob")} placeholder="Filter…" className="h-8 text-body-3" />
              </TableHead>
              <TableHead className="py-2">
                <Input value={filters.lastUpdated} onChange={setFilter("lastUpdated")} placeholder="Filter…" className="h-8 text-body-3" />
              </TableHead>
              <TableHead className="py-2">
                <Input value={filters.size} onChange={setFilter("size")} placeholder="Filter…" className="h-8 text-body-3" />
              </TableHead>
              <TableHead className="py-2">
                <Input value={filters.status} onChange={setFilter("status")} placeholder="Filter…" className="h-8 text-body-3" />
              </TableHead>
              <TableHead className="py-2">
                <Input value={filters.dataSource} onChange={setFilter("dataSource")} placeholder="Filter…" className="h-8 text-body-3" />
              </TableHead>
              <TableHead className="py-2" />
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredDocs.length === 0 ? (
              <TableRow>
                <TableCell colSpan={8} className="text-center text-body-3 text-muted-foreground py-8">
                  No documents match your filters
                </TableCell>
              </TableRow>
            ) : (
              filteredDocs.map((d) => (
                <TableRow key={d.id}>
                  <TableCell>
                    <div className="flex items-center gap-3">
                      <div className="flex h-8 w-8 items-center justify-center rounded bg-muted">
                        <FileText className="h-4 w-4 text-muted-foreground" />
                      </div>
                      <span className="text-body-3 font-medium">{d.name}</span>
                    </div>
                  </TableCell>
                  <TableCell>
                    <Badge variant="outline" className="font-mono text-caption">
                      {d.type}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-body-3">{d.lob}</TableCell>
                  <TableCell className="text-body-3 tabular-nums">{d.lastUpdated}</TableCell>
                  <TableCell className="text-body-3 text-right tabular-nums">
                    {formatSize(d.sizeKb)}
                  </TableCell>
                  <TableCell>
                    <StatusBadge status={d.status} />
                  </TableCell>
                  <TableCell>
                    <DataSourceBadge source={d.dataSource} />
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center justify-end gap-1">
                      <Button variant="ghost" size="icon" className="h-8 w-8" aria-label="View">
                        <Eye className="h-4 w-4" />
                      </Button>
                      <Button variant="ghost" size="icon" className="h-8 w-8" aria-label="Download">
                        <Download className="h-4 w-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}

function SummaryCard({ label, value }: { label: string; value: string }) {
  return (
    <div className={cn("rounded-lg border border-border bg-card p-4 shadow-elev-1")}>
      <p className="text-caption text-muted-foreground uppercase tracking-wide">{label}</p>
      <p className="text-h6 text-foreground mt-1">{value}</p>
    </div>
  );
}
