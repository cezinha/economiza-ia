import { PageHeader } from "@/components/shell/PageHeader";
import { ComingSoon } from "@/components/shell/ComingSoon";

export default function DesignIssuesPage() {
  return (
    <div className="space-y-8">
      <PageHeader eyebrow="Quality" title="Design issues" breadcrumbs={[{ label: "Design issues" }]} />
      <ComingSoon />
    </div>
  );
}
