import { PageHeader } from "@/components/shell/PageHeader";
import { ComingSoon } from "@/components/shell/ComingSoon";

export default function GoldenConfigsPage() {
  return (
    <div className="space-y-8">
      <PageHeader title="Golden configs" breadcrumbs={[{ label: "Golden configs" }]} />
      <ComingSoon />
    </div>
  );
}
