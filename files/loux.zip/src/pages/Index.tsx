import { SuperadminOverview } from "./overviews/SuperadminOverview";

export default function Index() {
  // All roles currently share the Superadmin home; per-role restrictions
  // will be layered on top in a follow-up.
  return <SuperadminOverview />;
}
