import { useEffect, useRef, useState } from "react";
import { useSearchParams } from "react-router-dom";
import { PageHeader } from "@/components/shell/PageHeader";
import { NuddTable } from "@/components/dashboard/NuddTable";
import { NuddSummary } from "@/components/dashboard/NuddSummary";
import { NuddDetailDrawer } from "@/components/dashboard/NuddDetailDrawer";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { NUDDS, type NuddRow } from "@/mocks/nudds";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Share2, Mail, FileDown } from "lucide-react";
import { exportElementToPdf } from "@/lib/exportPdf";
import { toast } from "@/hooks/use-toast";


export default function RisksPage() {
  const [searchParams, setSearchParams] = useSearchParams();
  const [selected, setSelected] = useState<NuddRow | null>(null);
  const [open, setOpen] = useState(false);
  const tab = searchParams.get("tab") === "table" ? "table" : "summary";
  const nuddParam = searchParams.get("nudd");
  const summaryRef = useRef<HTMLDivElement>(null);
  const tableRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!nuddParam) return;
    const row = NUDDS.find((n) => n.id === nuddParam);
    if (row) {
      setSelected(row);
      setOpen(true);
    }
  }, [nuddParam]);

  const openRow = (row: NuddRow) => {
    setSelected(row);
    setOpen(true);
  };

  const handleOpenChange = (next: boolean) => {
    setOpen(next);
    if (!next && nuddParam) {
      const np = new URLSearchParams(searchParams);
      np.delete("nudd");
      setSearchParams(np, { replace: true });
    }
  };

  const setTab = (value: string) => {
    const next = new URLSearchParams(searchParams);
    if (value === "summary") next.delete("tab");
    else next.set("tab", value);
    setSearchParams(next, { replace: true });
  };

  const activeMeta = () =>
    tab === "table"
      ? { el: tableRef.current, label: "Full list", slug: "nudds-table" }
      : { el: summaryRef.current, label: "Summary", slug: "nudds-summary" };

  const handleExport = async () => {
    const { el, label, slug } = activeMeta();
    if (!el) return;
    try {
      await exportElementToPdf(el, {
        title: `NUDDs tracking report — ${label}`,
        filenameSlug: slug,
        orientation: "landscape",
      });
      toast({ title: "PDF downloaded", description: `${slug}.pdf` });
    } catch (e) {
      toast({ title: "Export failed", description: String(e) });
    }
  };

  const handleEmail = async () => {
    const { el, label, slug } = activeMeta();
    if (!el) return;
    try {
      await exportElementToPdf(el, {
        title: `NUDDs tracking report — ${label}`,
        filenameSlug: slug,
        orientation: "landscape",
      });
      const subject = encodeURIComponent(`NUDDs tracking report — ${label}`);
      const body = encodeURIComponent(
        `Hi,\n\nSharing the NUDDs tracking report (${label}). The PDF was just downloaded to your device — please attach "${slug}.pdf" to this email before sending.\n\nThanks`,
      );
      window.location.href = `mailto:?subject=${subject}&body=${body}`;
      toast({
        title: "Email ready",
        description: "PDF downloaded — attach it to the email draft.",
      });
    } catch (e) {
      toast({ title: "Email failed", description: String(e) });
    }
  };

  return (
    <div className="space-y-8">
      <PageHeader
        eyebrow="Risk register"
        title="NUDDs"
        description="Track NUDDs across your portfolio by impacted platform, severity, and status"
        breadcrumbs={[{ label: "NUDDs" }]}
      />
      <Tabs value={tab} onValueChange={setTab} className="space-y-6">
        <TabsList>
          <TabsTrigger value="summary">Summary</TabsTrigger>
          <TabsTrigger value="table">Table</TabsTrigger>
        </TabsList>
        <div className="flex items-center justify-between gap-4 pt-2">
          <h2 className="text-h4 text-foreground">NUDDs tracking report</h2>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button
                type="button"
                variant="ghost"
                size="sm"
                className="gap-1 px-2 text-button-2 hover:bg-transparent"
                style={{ color: "#0672CB" }}
              >
                <Share2 className="h-4 w-4" aria-hidden />
                Share
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem onClick={handleExport}>
                <FileDown className="mr-2 h-4 w-4" aria-hidden />
                Export as PDF
              </DropdownMenuItem>
              <DropdownMenuItem onClick={handleEmail}>
                <Mail className="mr-2 h-4 w-4" aria-hidden />
                Share via email
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
        <TabsContent value="summary" className="space-y-4">
          <div ref={summaryRef} className="space-y-4">
            <h3 className="text-h5 text-foreground">Overview</h3>
            <NuddSummary onOpenRow={openRow} />
          </div>
        </TabsContent>
        <TabsContent value="table" className="space-y-4">
          <div ref={tableRef} className="space-y-4">
            <h3 className="text-h5 text-foreground">Full list</h3>
            <NuddTable onOpenRow={openRow} />
          </div>
        </TabsContent>
      </Tabs>
      <NuddDetailDrawer row={selected} open={open} onOpenChange={handleOpenChange} />
    </div>
  );
}
