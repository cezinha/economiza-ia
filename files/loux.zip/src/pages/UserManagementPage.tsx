import { useEffect, useMemo, useState } from "react";
import { Navigate } from "react-router-dom";
import { X } from "lucide-react";
import { Dialog, DialogContent, DialogTitle } from "@/components/ui/dialog";
import { SearchIcon } from "@/components/icons/SearchIcon";
import { PlusAddIcon } from "@/components/icons/PlusAddIcon";
import { UserGroupIcon } from "@/components/icons/UserGroupIcon";
import { PencilIcon } from "@/components/icons/PencilIcon";
import { TrashIcon } from "@/components/icons/TrashIcon";
import { PageHeader } from "@/components/shell/PageHeader";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { DdsPagination } from "@/components/shell/DdsPagination";
import { cn } from "@/lib/utils";
import { useIsReadOnly } from "@/lib/permissions";
import { useRole } from "@/contexts/RoleContext";

import { ALL_USERS, type DirectoryUser, type UserRole } from "@/mocks/users";
import { AddUserDrawer } from "@/components/user-management/drawers/AddUserDrawer";
import { BulkAddUsersDrawer } from "@/components/user-management/drawers/BulkAddUsersDrawer";
import { EditUserDrawer } from "@/components/user-management/drawers/EditUserDrawer";
import { DeleteUserDrawer } from "@/components/user-management/drawers/DeleteUserDrawer";
import { AddUserForm } from "@/components/user-management/drawers/AddUserForm";

function RoleBadge({ role }: { role: UserRole }) {
  const palette: Record<UserRole, { bg: string; fg: string }> = {
    "Super Admin": { bg: "#1D2C3B", fg: "#EBF1F6" },
    Executive: { bg: "#141D28", fg: "#EBF1F6" },
    Admin: { bg: "#293B4D", fg: "#EBF1F6" },
    User: { bg: "#40586D", fg: "#EBF1F6" },
  };
  const { bg, fg } = palette[role];
  return (
    <Badge
      className="border-0 text-body-3 font-normal hover:bg-transparent"
      style={{ backgroundColor: bg, color: fg }}
    >
      {role}
    </Badge>
  );
}

export default function UserManagementPage() {
  const [query, setQuery] = useState("");
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(25);
  const { role } = useRole();
  const readOnly = useIsReadOnly();
  const [addOpen, setAddOpen] = useState(false);
  const [bulkOpen, setBulkOpen] = useState(false);
  const [editing, setEditing] = useState<DirectoryUser | null>(null);
  const [deleting, setDeleting] = useState<DirectoryUser | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => setPage(1), [query]);

  useEffect(() => {
    const t = setTimeout(() => setLoading(false), 800);
    return () => clearTimeout(t);
  }, []);

  const shuffledUsers = useMemo(() => {
    const arr = [...ALL_USERS];
    for (let i = arr.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [arr[i], arr[j]] = [arr[j], arr[i]];
    }
    return arr;
  }, []);

  const filteredRows = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return shuffledUsers;
    return shuffledUsers.filter((u) => u.name.toLowerCase().includes(q));
  }, [query, shuffledUsers]);

  const totalPages = Math.max(1, Math.ceil(filteredRows.length / pageSize));
  const safePage = Math.min(page, totalPages);
  const pagedRows = useMemo(
    () => filteredRows.slice((safePage - 1) * pageSize, safePage * pageSize),
    [filteredRows, safePage, pageSize],
  );

  if (role !== "superadmin") {
    return <Navigate to="/" replace />;
  }

  return (
    <div className="space-y-8">
      <PageHeader
        eyebrow="Settings"
        title="User management"
        description="Manage user access and permissions throughout OLP Launch Orchestrator"
        breadcrumbs={[{ label: "User management" }]}
      />
      <div className="space-y-4">
        <h3 className="text-h4 text-foreground">Registered accounts</h3>
        <div className="rounded-lg border border-border bg-card p-6 shadow-elev-1 space-y-6">
        <div className="flex items-start justify-between gap-4">
          <div>
            <h2 className="text-h5">Master list</h2>
          </div>
          {!readOnly && (
            <div className="flex items-center gap-4">
              <Button
                onClick={() => setAddOpen(true)}
                className="gap-2 text-button-1 bg-[#0672CB] text-white hover:bg-[#055AA3] active:bg-[#044A87] focus-visible:ring-2 focus-visible:ring-[#0672CB] focus-visible:ring-offset-2 disabled:opacity-40 disabled:bg-[#0672CB]"
              >
                Add User <PlusAddIcon className="h-4 w-4" />
              </Button>
              <Button
                variant="outline"
                onClick={() => setBulkOpen(true)}
                className="gap-2 text-button-1 bg-transparent border-[#0672CB] text-[#0672CB] hover:bg-[#0672CB]/10 hover:text-[#0672CB] active:bg-[#0672CB]/20 focus-visible:ring-2 focus-visible:ring-[#0672CB] focus-visible:ring-offset-2 disabled:opacity-40"
              >
                Bulk Add Users <UserGroupIcon className="h-4 w-4" />
              </Button>
            </div>
          )}
        </div>

        <div className="group relative max-w-md focus-within:opacity-100 hover:opacity-100">
          <Input
            placeholder="Search users"
            className="pr-9 border-input transition-colors hover:border-primary focus-visible:border-primary focus-visible:ring-1 focus-visible:ring-primary focus-visible:ring-offset-0 disabled:opacity-40"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            disabled={loading}
          />
          <SearchIcon className="pointer-events-none absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground transition-colors group-hover:text-primary group-focus-within:text-primary" />
        </div>

        <Table containerClassName="max-h-[640px]">
          <TableHeader className="sticky top-0 z-10 bg-card shadow-elev-1">

            <TableRow>
              <TableHead className="text-h6">Name</TableHead>
              <TableHead className="text-h6">Email</TableHead>
              <TableHead className="text-h6">Role</TableHead>
              <TableHead className="text-h6">Access</TableHead>
              <TableHead className="text-h6">Business unit</TableHead>
              <TableHead className="text-h6">Function</TableHead>
              <TableHead className="text-h6">LOB</TableHead>
              <TableHead className="text-h6">Platforms</TableHead>
              <TableHead className="text-h6">Date added</TableHead>
              <TableHead className="text-h6 sticky right-0 z-20 bg-card shadow-elev-left-1 before:absolute before:left-0 before:top-0 before:bottom-0 before:w-px before:bg-border before:content-['']">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody aria-busy={loading || undefined}>
            {loading ? (
              Array.from({ length: pageSize }).map((_, idx) => (
                <TableRow key={`sk-${idx}`} className={idx % 2 === 0 ? "bg-muted hover:bg-muted" : "bg-card hover:bg-card"}>
                  <TableCell>
                    <div className="flex items-center gap-3">
                      {idx === 0 && <span className="sr-only">Loading users…</span>}
                      <Skeleton className="h-8 w-8 rounded-full bg-muted" />
                      <Skeleton className="h-3 w-32 rounded bg-muted" />
                    </div>
                  </TableCell>
                  <TableCell><Skeleton className="h-3 w-48 rounded bg-muted" /></TableCell>
                  <TableCell><Skeleton className="h-5 w-20 rounded bg-muted" /></TableCell>
                  <TableCell><Skeleton className="h-5 w-16 rounded bg-muted" /></TableCell>
                  <TableCell><Skeleton className="h-3 w-12 rounded bg-muted" /></TableCell>
                  <TableCell><Skeleton className="h-3 w-12 rounded bg-muted" /></TableCell>
                  <TableCell><Skeleton className="h-3 w-12 rounded bg-muted" /></TableCell>
                  <TableCell><Skeleton className="h-3 w-24 rounded bg-muted" /></TableCell>
                  <TableCell><Skeleton className="h-3 w-20 rounded bg-muted" /></TableCell>
                  <TableCell className="sticky right-0 bg-inherit shadow-elev-left-1 before:absolute before:left-0 before:top-0 before:bottom-0 before:w-px before:bg-border before:content-['']">
                    <div className="flex items-center gap-2">
                      <Skeleton className="h-8 w-8 rounded bg-muted" />
                      <Skeleton className="h-8 w-8 rounded bg-muted" />
                    </div>
                  </TableCell>
                </TableRow>
              ))
            ) : filteredRows.length === 0 ? (
              <TableRow>
                <TableCell colSpan={10} className="text-center text-body-3 text-muted-foreground py-8">
                  No users match your search.
                </TableCell>
              </TableRow>
            ) : pagedRows.map((u, idx) => (
              <TableRow key={u.id} className={idx % 2 === 0 ? "bg-muted hover:bg-muted" : "bg-card hover:bg-card"}>

                <TableCell>
                  <div className="flex items-center gap-3">
                    <div className="flex h-8 w-8 items-center justify-center rounded-full bg-muted text-caption font-medium">
                      {u.initials}
                    </div>
                    <span className="text-body-3 font-medium">{u.displayName}</span>
                  </div>
                </TableCell>
                <TableCell className="text-body-3">{u.email}</TableCell>
                <TableCell><RoleBadge role={u.role} /></TableCell>
                <TableCell>
                  {u.enabled ? (
                    <Badge className="border-0 text-body-3 font-normal hover:bg-transparent" style={{ backgroundColor: "#0672CB", color: "#D9F5FD" }}>Enabled</Badge>
                  ) : (
                    <Badge className="border-0 text-body-3 font-normal hover:bg-transparent" style={{ backgroundColor: "#7E7E7E", color: "#F5F6F7" }}>Disabled</Badge>
                  )}
                </TableCell>
                <TableCell className="text-body-3">{u.role === "Super Admin" || u.role === "Executive" ? "All" : u.businessUnit}</TableCell>
                <TableCell className="text-body-3">{u.role === "Super Admin" || u.role === "Executive" ? "All" : u.function}</TableCell>
                <TableCell className="text-body-3">{u.role === "Super Admin" || u.role === "Executive" ? "All" : u.lob}</TableCell>
                <TableCell className="text-body-3">{u.role === "Super Admin" || u.role === "Executive" ? "All" : u.programs}</TableCell>
                <TableCell className="text-body-3">{u.dateAdded}</TableCell>
                <TableCell className="sticky right-0 bg-inherit shadow-elev-left-1 before:absolute before:left-0 before:top-0 before:bottom-0 before:w-px before:bg-border before:content-['']">
                  <div className="flex items-center gap-2">
                    {!readOnly && <Button variant="ghost" size="icon" className="h-8 w-8" aria-label={`Edit ${u.displayName}`} onClick={() => setEditing(u)}><PencilIcon className="h-4 w-4" /></Button>}
                    {!readOnly && <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive" aria-label={`Delete ${u.displayName}`} onClick={() => setDeleting(u)}><TrashIcon className="h-4 w-4" /></Button>}
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>

        {!loading && filteredRows.length > 0 && (
          <div className="flex justify-center pt-2">
            <DdsPagination
              page={safePage}
              pageSize={pageSize}
              totalItems={filteredRows.length}
              itemLabel="rows"
              onPageChange={setPage}
              onPageSizeChange={setPageSize}
            />
          </div>
        )}
        </div>
      </div>

      <AddUserDrawer open={addOpen} onOpenChange={setAddOpen} />
      <BulkAddUsersDrawer open={bulkOpen} onOpenChange={setBulkOpen} />

      <Dialog open={!!editing} onOpenChange={(o) => { if (!o) setEditing(null); }}>
        <DialogContent
          className="max-w-[560px] gap-0 border border-border bg-card p-0 shadow-elev-3 rounded-md [&>button]:hidden flex flex-col max-h-[85vh]"
          onOpenAutoFocus={(e) => e.preventDefault()}
        >
          <div className="flex items-start justify-between px-4 py-3 border-b border-border">
            <DialogTitle className="text-h5 text-foreground">Edit user</DialogTitle>
            <button
              type="button"
              aria-label="Close"
              onClick={() => setEditing(null)}
              className="text-muted-foreground hover:text-foreground focus:outline-none focus-visible:ring-2 focus-visible:ring-[#0672CB]"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
          {editing && <AddUserForm key={editing.id} onClose={() => setEditing(null)} submitLabel="Update" initialUser={editing} />}
        </DialogContent>
      </Dialog>

      <Dialog open={!!deleting} onOpenChange={(o) => { if (!o) setDeleting(null); }}>
        <DialogContent
          className="max-w-[480px] gap-0 border border-border bg-card p-0 shadow-elev-3 rounded-md [&>button]:hidden"
          onOpenAutoFocus={(e) => e.preventDefault()}
        >
          <div className="flex items-start justify-between px-4 py-3 border-b border-border">
            <DialogTitle className="text-h5 text-foreground">Confirm delete?</DialogTitle>
            <button
              type="button"
              aria-label="Close"
              onClick={() => setDeleting(null)}
              className="text-muted-foreground hover:text-foreground focus:outline-none focus-visible:ring-2 focus-visible:ring-[#0672CB]"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
          <div className="px-4 py-4 space-y-2">
            <p className="text-body-2 text-foreground">Are you sure you want to remove {deleting?.displayName}?</p>
            <p className="text-caption text-muted-foreground">This will remove the user and their platform access. This action cannot be undone.</p>
          </div>
          <div className="flex justify-end gap-2 px-4 py-3 border-t border-border">
            <Button
              variant="outline"
              onClick={() => setDeleting(null)}
              className="gap-2 text-button-1 bg-transparent border-[#0672CB] text-[#0672CB] hover:bg-[#0672CB]/10 hover:text-[#0672CB] active:bg-[#0672CB]/20 focus-visible:ring-2 focus-visible:ring-[#0672CB] focus-visible:ring-offset-2"
            >
              Cancel
            </Button>
            <Button
              onClick={() => setDeleting(null)}
              className="gap-2 text-button-1 bg-[#E4002B] text-white hover:bg-[#B80023] active:bg-[#8F001B] focus-visible:ring-2 focus-visible:ring-[#E4002B] focus-visible:ring-offset-2"
            >
              Remove
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
