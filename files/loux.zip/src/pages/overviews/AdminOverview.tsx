import { ScopedHomeOverview } from "@/components/dashboard/ScopedHomeOverview";

export function AdminOverview() {
  return <ScopedHomeOverview eyebrowRole="Admin" />;
}
