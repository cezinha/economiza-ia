import { PageHeader } from "@/components/shell/PageHeader";
import { DdsGrid, DdsCol } from "@/components/layout/DdsGrid";
import { PortfolioMetrics } from "@/components/dashboard/PortfolioMetrics";
import { CurrentPhaseDonut } from "@/components/dashboard/CurrentPhaseDonut";
import { PhaseStatusCard } from "@/components/dashboard/PhaseStatusCard";
import { WatchlistPanel } from "@/components/dashboard/WatchlistPanel";
import { HomeWorkspace, HomeStack } from "@/components/dashboard/HomeWorkspace";


export function ExecutiveOverview() {
  return (
    <div className="space-y-8">
      <PageHeader
        eyebrow="Executive view"
        title="Home"
      />
      <HomeWorkspace>
        <HomeStack>
          <section className="space-y-4">
            <h2 className="text-h4 text-foreground">Portfolio overview</h2>
            <DdsGrid>
              <DdsCol span={6} spanM={6} spanS={6} spanXs={2}>
                <CurrentPhaseDonut />
              </DdsCol>
              <DdsCol span={6} spanM={6} spanS={6} spanXs={2}>
                <PortfolioMetrics />
              </DdsCol>
            </DdsGrid>
          </section>
          <WatchlistPanel />
          <PhaseStatusCard />
        </HomeStack>
      </HomeWorkspace>
    </div>
  );
}

