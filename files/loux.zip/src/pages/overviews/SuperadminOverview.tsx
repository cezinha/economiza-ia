import { useRef } from "react";
import { useSearchParams } from "react-router-dom";
import { SharePdfButton } from "@/components/shell/SharePdfButton";
import { WatchlistPanel } from "@/components/dashboard/WatchlistPanel";
import { PageHeader } from "@/components/shell/PageHeader";
import { HomeWorkspace, HomeStack } from "@/components/dashboard/HomeWorkspace";
import { DdsGrid, DdsCol } from "@/components/layout/DdsGrid";
import { PortfolioMetrics } from "@/components/dashboard/PortfolioMetrics";
import { CurrentPhaseDonut } from "@/components/dashboard/CurrentPhaseDonut";
import { PhaseStatusCard } from "@/components/dashboard/PhaseStatusCard";
import { PhaseStatusReportView } from "@/components/dashboard/PhaseStatusReportView";
import { TaskQueue } from "@/components/dashboard/TaskQueue";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Card, CardHeader, CardContent } from "@/components/ui/card";

import { PendingPlatformsCard } from "@/components/dashboard/PendingPlatformsCard";
import { StatusRequestsCard } from "@/components/dashboard/StatusRequestsCard";
import { useRole } from "@/contexts/RoleContext";

type HomeTab = "action-items" | "portfolio" | "report" | "watchlist";
const HOME_TABS: HomeTab[] = ["action-items", "portfolio", "report", "watchlist"];

export function SuperadminOverview() {
  const { role } = useRole();
  const isExecutive = role === "executive";
  const [searchParams, setSearchParams] = useSearchParams();
  const defaultTab: HomeTab = isExecutive ? "portfolio" : "action-items";
  const param = searchParams.get("tab") as HomeTab | null;
  let tab: HomeTab = param && HOME_TABS.includes(param) ? param : defaultTab;
  if (isExecutive && tab === "action-items") tab = "portfolio";
  const setTab = (v: string) => {
    const next = new URLSearchParams(searchParams);
    next.set("tab", v);
    setSearchParams(next, { replace: true });
  };
  const portfolioRef = useRef<HTMLDivElement>(null);
  const reportRef = useRef<HTMLDivElement>(null);
  return (
    <div className="space-y-8">
      <PageHeader
        eyebrow="Superadmin · Single pane of glass"
        title="Home"
        description="View your portfolio, reports, and open action items"
      />
      <HomeWorkspace>
        <HomeStack>
          <Tabs value={tab} onValueChange={setTab}>
            <TabsList>
              {!isExecutive && <TabsTrigger value="action-items">Action items</TabsTrigger>}
              <TabsTrigger value="portfolio">Summary</TabsTrigger>
              <TabsTrigger value="report">Report</TabsTrigger>
              <TabsTrigger value="watchlist" className="gap-2">
                Watchlist
                <span className="shrink-0 rounded-full border border-border bg-muted px-2 py-0.5 text-caption text-muted-foreground">
                  Post-MVP
                </span>
              </TabsTrigger>
            </TabsList>
            {!isExecutive && (
              <TabsContent value="action-items" className="space-y-4 mt-6">
                <h2 className="text-h4 text-foreground">My action items</h2>
                <PendingPlatformsCard />
                <DdsGrid>
                  <DdsCol span={6} spanM={6} spanS={6} spanXs={2}>
                    <TaskQueue />
                  </DdsCol>
                  <DdsCol span={6} spanM={6} spanS={6} spanXs={2}>
                    <StatusRequestsCard />
                  </DdsCol>
                </DdsGrid>
              </TabsContent>
            )}
            <TabsContent value="portfolio" className="space-y-4 mt-6">
              <div className="flex items-center justify-between gap-4">
                <h2 className="text-h4 text-foreground">Portfolio overview</h2>
                <SharePdfButton targetRef={portfolioRef} title="Portfolio overview" filenameSlug="portfolio-overview" />
              </div>
              <div ref={portfolioRef} className="space-y-4">
                <DdsGrid>
                  <DdsCol span={6} spanM={6} spanS={6} spanXs={2} className="h-full">
                    <CurrentPhaseDonut />
                  </DdsCol>
                  <DdsCol span={6} spanM={6} spanS={6} spanXs={2} className="h-full">
                    <PortfolioMetrics />
                  </DdsCol>
                </DdsGrid>
                <PhaseStatusCard />
              </div>
            </TabsContent>
            <TabsContent value="report" className="space-y-4 mt-6">
              <div className="flex items-center justify-between gap-4">
                <h2 className="text-h4 text-foreground">Phase gate status report</h2>
                <SharePdfButton targetRef={reportRef} title="Phase gate status report" filenameSlug="phase-gate-status-report" />
              </div>
              <div ref={reportRef}>
                <PhaseStatusReportView />
              </div>
            </TabsContent>
            <TabsContent value="watchlist" className="space-y-4 mt-6">
              <WatchlistPanel />
            </TabsContent>
          </Tabs>
        </HomeStack>
      </HomeWorkspace>
    </div>
  );
}

