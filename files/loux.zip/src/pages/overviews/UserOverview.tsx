import { ScopedHomeOverview } from "@/components/dashboard/ScopedHomeOverview";

export function UserOverview() {
  return <ScopedHomeOverview eyebrowRole="User" />;
}
