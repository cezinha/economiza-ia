import { describe, it, expect } from "vitest";
import { readFileSync, readdirSync, statSync } from "node:fs";
import { join, extname } from "node:path";

/**
 * DDS Grid lock-in.
 * Ensures dashboard surface code never uses spacing utilities that violate
 * the 4px baseline grid, and that pages compose layout via the DDS
 * primitives instead of bespoke `grid-cols-*` classes.
 */

const ROOTS = ["src/pages", "src/components/dashboard", "src/components/shell"];

const FORBIDDEN_SPACING = [
  // 2px / 6px / 10px / 14px Tailwind utilities (not 4px multiples)
  /\b(?:p|px|py|pt|pr|pb|pl|m|mx|my|mt|mr|mb|ml|gap|gap-x|gap-y|space-x|space-y|w|h|min-w|min-h|max-w|max-h|top|right|bottom|left|inset)-(?:0\.5|1\.5|2\.5|3\.5)\b/,
];

// DDS elevation: only token-based shadows allowed on dashboard surface.
const FORBIDDEN_SHADOWS = [
  /\bshadow-(?:sm|md|lg|xl|2xl|inner|none)\b/,
  // arbitrary shadow values like shadow-[...]
  /\bshadow-\[[^\]]+\]/,
];

// Pages must use DdsGrid; bespoke responsive grid-cols are forbidden in pages.
const FORBIDDEN_IN_PAGES = [/\bgrid-cols-\d+\b/];

function* walk(dir: string): Generator<string> {
  for (const entry of readdirSync(dir)) {
    const full = join(dir, entry);
    const s = statSync(full);
    if (s.isDirectory()) yield* walk(full);
    else if ([".ts", ".tsx"].includes(extname(full))) yield full;
  }
}

describe("DDS grid compliance", () => {
  it("no off-grid spacing utilities in dashboard surface", () => {
    const violations: string[] = [];
    for (const root of ROOTS) {
      for (const file of walk(root)) {
        const src = readFileSync(file, "utf8");
        for (const re of FORBIDDEN_SPACING) {
          const m = src.match(re);
          if (m) violations.push(`${file}: "${m[0]}"`);
        }
      }
    }
    expect(violations, violations.join("\n")).toEqual([]);
  });

  it("pages compose layout via DdsGrid (no bespoke grid-cols-*)", () => {
    const violations: string[] = [];
    for (const file of walk("src/pages")) {
      const src = readFileSync(file, "utf8");
      for (const re of FORBIDDEN_IN_PAGES) {
        const m = src.match(re);
        if (m) violations.push(`${file}: "${m[0]}"`);
      }
    }
    expect(violations, violations.join("\n")).toEqual([]);
  });

  it("dashboard surface uses DDS elevation tokens (no raw shadow-sm/md/lg/xl/2xl/inner)", () => {
    const violations: string[] = [];
    for (const root of ROOTS) {
      for (const file of walk(root)) {
        const src = readFileSync(file, "utf8");
        for (const re of FORBIDDEN_SHADOWS) {
          const m = src.match(re);
          if (m) violations.push(`${file}: "${m[0]}"`);
        }
      }
    }
    expect(violations, violations.join("\n")).toEqual([]);
  });

  it("only ONE elevation light direction used per page (no mixed bottom/left/right)", () => {
    const violations: string[] = [];
    for (const file of walk("src/pages")) {
      const src = readFileSync(file, "utf8");
      const hasBottom = /\bshadow-elev-(?:1|2|3|4)\b/.test(src);
      const hasLeft = /\bshadow-elev-left-/.test(src);
      const hasRight = /\bshadow-elev-right-/.test(src);
      const dirs = [hasBottom, hasLeft, hasRight].filter(Boolean).length;
      if (dirs > 1) violations.push(`${file}: mixed elevation light directions`);
    }
    expect(violations, violations.join("\n")).toEqual([]);
  });

  it("dashboard surface uses DDS color tokens (no raw white/black/gray/slate/zinc/neutral/stone or hex)", () => {
    const FORBIDDEN_COLORS: RegExp[] = [
      // Tailwind raw color utilities
      /\b(?:text|bg|border|ring|fill|stroke|from|to|via)-(?:white|black)\b/,
      /\b(?:text|bg|border|ring|fill|stroke|from|to|via)-(?:gray|slate|zinc|neutral|stone)-\d+\b/,
      // Arbitrary color values
      /\b(?:text|bg|border|ring|fill|stroke)-\[#[0-9a-fA-F]{3,8}\]/,
      /\b(?:text|bg|border|ring|fill|stroke)-\[(?:rgb|hsl)/,
      // Inline style hex/rgb
      /style=\{\{[^}]*(?:color|backgroundColor|borderColor)\s*:\s*['"]\s*#/,
    ];
    const violations: string[] = [];
    for (const root of ROOTS) {
      for (const file of walk(root)) {
        const src = readFileSync(file, "utf8");
        for (const re of FORBIDDEN_COLORS) {
          const m = src.match(re);
          if (m) violations.push(`${file}: "${m[0]}"`);
        }
      }
    }
    expect(violations, violations.join("\n")).toEqual([]);
  });
});
