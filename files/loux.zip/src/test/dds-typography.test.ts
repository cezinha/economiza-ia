import { describe, it, expect } from "vitest";
import { readdirSync, readFileSync, statSync } from "node:fs";
import { join } from "node:path";

/**
 * DDS Typography lock.
 *
 * Forbids raw Tailwind text-size utilities and heavy font-weight utilities
 * on the dashboard surface. All typography must use named DDS tokens
 * (text-display-1..3, text-h1..h6, text-subtitle-1..2, text-body-1..3,
 * text-button-1..2, text-caption).
 *
 * Allow-listed:
 *   - src/components/ui/**  (shadcn primitives — they expose their own variants)
 *   - lines containing the comment marker  // dds-type-ignore
 */

const SCAN_DIRS = [
  "src/pages",
  "src/components/dashboard",
  "src/components/shell",
  "src/components/layout",
];

const FORBIDDEN_SIZE = /\btext-(xs|sm|base|lg|xl|2xl|3xl|4xl|5xl|6xl|7xl|8xl|9xl)\b/;
const FORBIDDEN_ARB_PX = /\btext-\[\d+px\]/;
const FORBIDDEN_WEIGHT = /\bfont-(thin|semibold|bold|extrabold|black)\b/;

function walk(dir: string): string[] {
  const out: string[] = [];
  for (const name of readdirSync(dir)) {
    const p = join(dir, name);
    const s = statSync(p);
    if (s.isDirectory()) out.push(...walk(p));
    else if (p.endsWith(".tsx")) out.push(p);
  }
  return out;
}

describe("DDS typography lock", () => {
  const files = SCAN_DIRS.flatMap(walk);

  it("scans at least one file", () => {
    expect(files.length).toBeGreaterThan(0);
  });

  for (const file of files) {
    it(`${file} uses only DDS type tokens`, () => {
      const lines = readFileSync(file, "utf8").split("\n");
      const offenses: string[] = [];
      lines.forEach((line, i) => {
        if (line.includes("dds-type-ignore")) return;
        if (FORBIDDEN_SIZE.test(line) || FORBIDDEN_ARB_PX.test(line) || FORBIDDEN_WEIGHT.test(line)) {
          offenses.push(`  line ${i + 1}: ${line.trim()}`);
        }
      });
      if (offenses.length) {
        throw new Error(
          `${file} contains forbidden raw type utilities:\n${offenses.join("\n")}\n` +
            `Use DDS tokens (text-h1..h6, text-body-1..3, text-caption, text-button-1..2, text-subtitle-1..2, text-display-1..3).`,
        );
      }
      expect(offenses).toHaveLength(0);
    });
  }
});
