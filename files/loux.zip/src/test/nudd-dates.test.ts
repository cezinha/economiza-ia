import { describe, it, expect } from "vitest";
import { NUDDS } from "@/mocks/nudds";
import {
  POC_TODAY,
  developExitDate,
  goePhaseSpan,
} from "@/lib/nuddDates";

function parseISO(s: string): Date {
  return new Date(s + "T00:00:00Z");
}

describe("NUDD mock date constraints", () => {
  for (const row of NUDDS) {
    describe(row.id, () => {
      const created = parseISO(row.created);
      const updated = parseISO(row.updated);
      const close = parseISO(row.closeDate);
      const developExit = developExitDate(row.platform);
      const phase = goePhaseSpan(row.platform, row.programPhase);

      it("closeDate is before Develop phase exit", () => {
        expect(close.getTime()).toBeLessThan(developExit.getTime());
      });

      it("updated is before closeDate and not after today", () => {
        expect(updated.getTime()).toBeLessThan(close.getTime());
        expect(updated.getTime()).toBeLessThanOrEqual(POC_TODAY.getTime());
      });

      it("created is before updated and within the GOE OLP phase span", () => {
        expect(created.getTime()).toBeLessThan(updated.getTime());
        expect(created.getTime()).toBeGreaterThanOrEqual(phase.start.getTime());
        expect(created.getTime()).toBeLessThanOrEqual(phase.end.getTime());
      });
    });
  }
});
