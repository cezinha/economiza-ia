---
name: Regrello Integration
description: Mapping from Regrello task statuses (blue/green/yellow/red) to internal dashboard TaskStatus and rollup behavior
type: feature
---
- Inbound task data is sourced from Regrello. Adapter lives at `src/lib/regrelloMapping.ts` (`mapRegrelloStatus`).
- **Status mapping**:
  - 🔵 Blue (Complete) → `completed` → "Done"
  - 🟢 Green (On Track) → `on-track` → "On Track"
  - 🟡 Yellow (Overdue) → `late` → **"At Risk w/ No Plan" (Red)**
  - 🔴 Red (Problem) → `late` → "At Risk w/ No Plan" (Red)
- **Key gap**: Regrello has no native "mitigated risk" concept, so dashboard Yellow ("At Risk w/ Mitigation") is never produced by the adapter directly.
- **Yellow disambiguation (Option 2 — chosen)**: owners promote a Regrello Red/Yellow task to dashboard Yellow via the existing `StatusFlagContext` Confirm/Override flow. No Regrello schema change required; override is auditable via task history.
- Status badges should display a tooltip (`explainRegrelloMapping`) showing the Regrello→Dashboard translation for transparency.
- Rollups (`computeRollupStatus`) operate on the mapped/effective TaskStatus, so Regrello Red/Yellow automatically escalates phase + platform to Red unless an owner-set Yellow override is in effect.
