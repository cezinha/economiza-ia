---
name: Status Flagging
description: Auto-suggested R/Y status changes based on due-date proximity; Confirm mutates effective task status which rolls up to phase/platform
type: feature
---
- `src/lib/statusFlagging.ts` exposes `evaluateTaskFlag(task)` returning `{ suggested, severity: 'yellow'|'red', reason, daysUntilDue }` or null.
- Severity rules: overdue → red `late`; due today/tomorrow → red `late`; pending due ≤3 days → yellow `at-risk` watch.
- `StatusFlagContext` (wrapping the app) scans `programSchedules` and exposes `flags`, `confirmedStatuses`, `confirmFlag`, `overrideFlag`, `clearOverride`, `getEffectiveStatus`.
- **Confirm** writes the suggested status into `confirmedStatuses` AND syncs into `scheduleData.setTaskStatusOverrides`, so `computeRollupStatus` (used by Gantt, ProgramStatusSummary, CurrentHomePage, Schedule, StatusUpdateModal) escalates phase/platform color automatically. **Override** only dismisses the flag for the session; status is unchanged.
- `NotificationCenter` renders a "Status Flags" group above standard notifications with Confirm / Override buttons; unread badge count includes flag count.
- `TaskDetailPanel` shows the effective (overridden) status badge, an inline flag chip with Confirm/Override, and an "Auto-flagged · confirmed" caption with **Undo** action when an override is active. Both Confirm/Override/Undo append a history comment.
