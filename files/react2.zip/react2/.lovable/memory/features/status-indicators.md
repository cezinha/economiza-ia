---
name: Status Indicators
description: RYG status indicators and the any-task-Y/R rollup escalation rule
type: feature
---
- Labels: Green = "On Track", Yellow = "At Risk w/ Mitigation", Red = "At Risk w/ No Plan", Gray = "Not Started".
- `TaskStatus` = `completed | on-track | at-risk | pending | late`.
- `PhaseStatus` = `on-track | at-risk | delayed | not-started`.
- **Rollup rule (`computeRollupStatus` in `src/data/scheduleData.ts`)**: severity wins.
  - any task `late` → phase/platform `delayed` (Red)
  - else any task `at-risk` → phase/platform `at-risk` (Yellow)
  - else all completed → `on-track`; all pending → `not-started`; otherwise `on-track`
- Effective task status incorporates overrides from `StatusFlagContext` via the module-level `setTaskStatusOverrides` registry, so a single confirmed Yellow/Red flag escalates its phase and the overall platform automatically.
