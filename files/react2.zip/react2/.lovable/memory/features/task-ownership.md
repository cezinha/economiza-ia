---
name: Task Ownership
description: Primary + backup owner model with assignment-history audit log
type: feature
---
- `ScheduleTask` extended with optional `backupOwner: string` and `assignmentHistory: AssignmentHistoryEntry[]` (`{ from, to, reason, changedBy, timestamp, type: 'primary'|'backup' }`).
- `getBackupOwner(taskId, primaryOwner)` deterministically picks a distinct owner from `ownerDetails` so every task always has a fallback even if the data file does not seed one.
- `TaskReassignmentDialog` includes a radio (Primary vs Backup) and shows the current value of the selected slot. Confirming appends a history entry rather than overwriting silently.
- `TaskDetailPanel` displays Primary Owner + Backup Owner separately and renders a collapsible "Assignment History" log (most recent first). Local state mirrors changes in-session since the data layer is read-only.
