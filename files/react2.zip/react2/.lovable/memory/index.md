# Memory: index.md
Updated: today

# Project Memory

## Core
- App is 'OLP Launch Orchestrator'. Product platforms must be named 'Laptop 1' through 'Laptop 7'.
- Design: Dell Blue/Navy, Apple-like rounded-2xl cards, Framer-motion. Status: Green, Yellow, Red, Gray.
- Architecture: 198-item master Task Sheet drives 5 canonical phases (Concept, Define, Plan, Develop/Qual, Pilot/Ramp/Launch).
- Constraint: Supabase disabled. Use manual external credentials for any DB/cloud integrations.
- Navigation: Left sidebar must auto-collapse & lock when Schedule Task Detail is open.
- Status labels: Green=On Track, Yellow=At Risk w/ Mitigation, Red=At Risk w/ No Plan, Gray=Not Started.
- NUDDs (`/nudds`, JIRA-integrated, Project GRIT) and Design Issues (`/design-issues`, DFx-integrated) are separate sidebar tabs.

## Memories
- [View Hierarchy](mem://architecture/view-hierarchy) — Nested sidebar nav logic and auto-collapse rules
- [Task Data Integration](mem://architecture/task-data-integration) — 198-item master task sheet and owner categorizations
- [Auth & Roles](mem://features/auth-roles) — Role-based landing pages and header profile dropdown options
- [Doc Curator](mem://features/doc-curator) — KPI summary, document tables, and GOE Assistant chatbot
- [Executive Dashboard](mem://features/executive-dashboard) — Read-only summary, AI banner, monthly scorecard, and NPI status
- [Manufacturing Tracking](mem://features/manufacturing-tracking) — Golden Configs (dual-table) and Build Execution (Built to RTS timeline)
- [Phase Gate Exit](mem://features/phase-gate-exit) — Flat criteria list with badges and 3-category supporting docs
- [Platform Summary](mem://features/platform-summary) — 3-column scannable exec dashboard with donut and stacked cost charts
- [Program Details](mem://features/program-details) — 1-pager summary with schedule widget and risk summary engine
- [Program Overview](mem://features/program-overview) — Home Page metrics table linking to platform summaries
- [Regrello Integration](mem://features/regrello-integration) — Regrello status (blue/green/yellow/red) → dashboard TaskStatus mapping; Yellow gap handled via owner override
- [Risk Analysis](mem://features/risk-analysis) — Scatter charts, stacked bars, KPIs, and unified Excel-exportable tables
- [Schedule Tracking](mem://features/schedule-tracking) — Phase/Milestone/Task hierarchy, task panels, and dynamic RTS calculation
- [Status Flagging](mem://features/status-flagging) — Auto Y/R suggestions from due dates with confirm/override workflow
- [Status Indicators](mem://features/status-indicators) — RYG labels: On Track, At Risk w/ Mitigation, At Risk w/ No Plan
- [Synchronized Dashboards](mem://features/synchronized-dashboards) — Clicking home page timeline syncs sidebar and Schedule view
- [Task Completion Interface](mem://features/task-completion-interface) — 3-panel task execution dashboard with checklists and risk flags
- [Task Ownership](mem://features/task-ownership) — Primary + backup owners with assignment-history audit log
- [Visual Identity](mem://style/visual-identity) — Dell colors, Apple-like spacing, text sizes, and Framer-motion usage
