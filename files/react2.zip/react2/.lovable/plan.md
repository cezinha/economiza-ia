
## Goal

Update `20260421_Dashboard_requirements_v2.xlsx` → save as `20260421_Dashboard_requirements_v3.xlsx` with corrected Epic descriptions (Column N) and Gherkin user stories (Column O) for requirements **(21)**, **(24)**, **(49)**, and **(59)**.

## Scope corrections

- **(21) Communication within the dashboard** — Rewrite as in-dashboard communication: comments, @-mentions, notifications routing, threaded discussions on programs/tasks. (Drops the prior "share with extended team / recurring notifications" framing.)
- **(24) Task collaboration** — Add the **missing Epic description** (Column N currently empty). Cover task-level comments, @-mentions, attachments, watchers, **task reassignment via `TaskReassignmentDialog`**, and **assignment history audit log** (per `mem://features/task-ownership`). Keep/refresh the Gherkin.
- **(49) NUDD integration** — Rewrite explicitly as **one-way, read-only**: NUDDs page ← JIRA (via Doc & Data Curator). My Tasks "NUDDs Impacting Platform" view ← NUDDs page. **No write-back to JIRA, no two-way sync, no conflict resolution language anywhere.**
- **(59) Notification Center** — Add the **missing Epic description** (Column N currently empty). Describe the existing bell-icon Notification Center (`NotificationCenter.tsx`): unread badge, All / Urgent / Info filter tabs, mark read/unread, overdue-lock, status-flag confirm/override, "View All" dialog. Add context that notifications cover **upcoming tasks, issues, NUDDs, and required actions**. Refresh the Gherkin to match.

## Format (unchanged from prior approved epics)

- **Epic (Column N)** — 6 blocks: `WHERE IT LIVES`, `HOW IT WORKS`, `DATA SOURCE`, `DATA NEEDED`, `AUTOMATION OPPORTUNITY`, `RELEVANT USER GROUPS`.
- **Gherkin (Column O)** — `Feature:` + `Background:` + 5–8 `Scenario:` blocks using concrete UI labels from the live dashboard (NotificationCenter tabs, TaskReassignmentDialog fields, NUDDs page, My Tasks views).

## Steps

1. Copy `/mnt/documents/20260421_Dashboard_requirements_v2.xlsx` → `/tmp/req_v2.xlsx`.
2. Run a Python (`openpyxl`) script that:
   - Locates rows where Column A (No.) ∈ {21, 24, 49, 59}.
   - Overwrites Column N (Epic) and Column O (Gherkin) with the rewritten content above.
   - Preserves all other rows, columns, formatting, column widths, wrap settings, and the 18 previously authored epics/Gherkins.
   - Saves to `/mnt/documents/20260421_Dashboard_requirements_v3.xlsx`.
3. Verify by re-reading the four target rows and printing Epic + Gherkin to confirm content and wrapping.
4. Emit a `<lov-artifact>` tag for the v3 file so you can preview/download it.

## Out of scope

- No changes to the other 18 epics/Gherkins.
- No code changes to the app — workbook only.
- No edits to other columns (Description, Sprint, MVP category, etc.).
