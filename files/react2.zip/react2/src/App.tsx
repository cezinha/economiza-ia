import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { ThemeProvider } from "@/hooks/use-theme";
import { TimezoneProvider } from "@/hooks/use-timezone";
import DashboardLayout from "@/components/dashboard/DashboardLayout";
import Index from "./pages/Index.tsx";
import PhaseGate from "./pages/PhaseGate.tsx";
import Schedule from "./pages/Schedule.tsx";
import Nudds from "./pages/Nudds.tsx";
import DesignIssues from "./pages/DesignIssues.tsx";

import BuildExecution from "./pages/BuildExecution.tsx";
import ProgramDetails from "./pages/ProgramDetails.tsx";
import NotFound from "./pages/NotFound.tsx";
import PlatformSummary from "./pages/PlatformSummary.tsx";
import DocCurator from "./pages/DocCurator.tsx";
import CurrentTask from "./pages/CurrentTask.tsx";
import MyTasks from "./pages/MyTasks.tsx";
import Archive from "./pages/Archive.tsx";
import Login from "./pages/Login.tsx";
import Dependencies from "./pages/Dependencies.tsx";
import FactoryConstraints from "./pages/FactoryConstraints.tsx";
import Compliance from "./pages/Compliance.tsx";
import SupplyChain from "./pages/SupplyChain.tsx";
import AuditLog from "./pages/AuditLog.tsx";

import DocumentRepository from "./pages/DocumentRepository.tsx";
import GoldenConfigs from "./pages/GoldenConfigs.tsx";
import { WatchlistProvider } from "./contexts/WatchlistContext";
import { PlatformProvider } from "./contexts/PlatformContext";
import { UniversalFilterProvider } from "./contexts/UniversalFilterContext";
import { RoleProvider } from "./contexts/RoleContext";
import { PhaseGateReportProvider } from "./contexts/PhaseGateReportContext";
import { StatusFlagProvider } from "./contexts/StatusFlagContext";
import { HomeFilterProvider } from "./contexts/HomeFilterContext";


const queryClient = new QueryClient();

const App = () => (
  <TimezoneProvider>
  <ThemeProvider>
    
    <RoleProvider>
    <PhaseGateReportProvider>
    <PlatformProvider>
    <UniversalFilterProvider>
    <WatchlistProvider>
    <StatusFlagProvider>
    <HomeFilterProvider>
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Sonner />
        <BrowserRouter>
          <Routes>
            <Route path="/login" element={<Login />} />
            <Route element={<DashboardLayout />}>
              <Route path="/" element={<Index />} />
              <Route path="/phase-gate" element={<PhaseGate />} />
              <Route path="/program-details" element={<ProgramDetails />} />
              <Route path="/schedule" element={<Schedule />} />
              <Route path="/nudds" element={<Nudds />} />
              <Route path="/design-issues" element={<DesignIssues />} />
              
              <Route path="/build-execution" element={<BuildExecution />} />
              <Route path="/platform-summary" element={<PlatformSummary />} />
              <Route path="/doc-curator" element={<DocCurator />} />
              <Route path="/current-task" element={<CurrentTask />} />
              <Route path="/my-tasks" element={<MyTasks />} />
              <Route path="/archive" element={<Archive />} />
              <Route path="/dependencies" element={<Dependencies />} />
              <Route path="/factory-constraints" element={<FactoryConstraints />} />
              <Route path="/compliance" element={<Compliance />} />
              <Route path="/supply-chain" element={<SupplyChain />} />
              <Route path="/audit-log" element={<AuditLog />} />
              
              <Route path="/document-repository" element={<DocumentRepository />} />
              <Route path="/golden-configs" element={<GoldenConfigs />} />
            </Route>
            <Route path="*" element={<NotFound />} />
          </Routes>
        </BrowserRouter>
      </TooltipProvider>
    </QueryClientProvider>
    </HomeFilterProvider>
    </StatusFlagProvider>
    </WatchlistProvider>
    </UniversalFilterProvider>
    </PlatformProvider>
    </PhaseGateReportProvider>
    </RoleProvider>
    
  </ThemeProvider>
  </TimezoneProvider>
);

export default App;
