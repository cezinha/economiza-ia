import { useState, useRef, useEffect, useCallback } from "react";
import { MessageCircle, X, Send, Sparkles } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { cn } from "@/lib/utils";
import ReactMarkdown from "react-markdown";

interface Message {
  id: string;
  role: "user" | "assistant";
  content: string;
}

const GREETING = `👋 **Hello! How can I help?**

I'm your OLP Launch Orchestrator assistant. I can help explain any part of the dashboard in your preferred language.

_كيف يمكنني مساعدتك؟ / 我能帮你什么？/ How can I help? / Comment puis-je vous aider ? / Как я могу помочь? / ¿Cómo puedo ayudar?_

Try asking about:
- **Schedule** — task timelines & phases
- **Status colors** — what Green/Yellow/Red mean
- **Navigation** — how to find pages`;

const mockResponses: Record<string, string> = {
  schedule: `📅 **OLP Schedule**\n\nThe Schedule page shows all tasks organized by phase:\n\n- **Concept** → **Define** → **Plan** → **Develop/Qual** → **Pilot/Ramp/Launch**\n\nEach task has an owner, due date, and status indicator. Click any task row to see its full details, dependencies, and documents.`,
  status: `🚦 **Status Indicators**\n\n- 🟢 **Green — On Track**: Everything proceeding as planned\n- 🟡 **Yellow — At Risk w/ Mitigation**: Issue identified, but a mitigation plan exists\n- 🔴 **Red — At Risk w/ No Plan**: Critical issue with no resolution plan yet\n- ⚪ **Gray — Not Started**: Task hasn't begun`,
  phase: `🏁 **Phase Gate Exit**\n\nPhase Gate Exit reviews ensure all criteria are met before moving to the next phase. Each criterion shows:\n- ✅ Complete / ❌ Incomplete status\n- Owner responsible\n- Supporting documents\n\nAll criteria must be complete to exit a phase.`,
  nudd: `⚠️ **NUDDs & Design Issues**\n\nNUDDs (New, Unique, Difficult, Dangerous) track technical risks:\n- Plotted on **Impact vs Probability** scatter charts\n- Color-coded by severity\n- Filterable by platform and category\n\nDesign Issues track engineering problems requiring resolution before production.`,
  home: `🏠 **Home Page**\n\nThe Home page shows a high-level overview of all programs:\n- **Program table** with phase, status, and key dates\n- **Timeline visualization** showing program milestones\n- Click any program to drill into its Platform Summary`,
  navigate: `🧭 **Navigation Guide**\n\n- **Sidebar** (left) — Main navigation to all pages\n- **Search** (⌘K) — Quick-find programs, pages, or tasks\n- **Breadcrumb** (top) — Shows your current location\n- **Profile menu** (top-right) — Switch roles & preferences`,
  config: `⚙️ **Golden Configs**\n\nGolden Configs tracks the approved hardware/software configurations for each platform. It features:\n- **Target Config** table — the approved baseline\n- **Current Config** table — what's actually in use\n- Differences are highlighted for quick identification`,
  build: `🔨 **Build Execution**\n\nBuild Execution tracks manufacturing progress from initial builds through production:\n- Timeline from **Build Start** → **Ready to Ship (RTS)**\n- Unit counts and pass/fail rates\n- Factory constraint tracking`,
};

type DetectedLang = "en" | "es" | "fr" | "de" | "pt" | "zh" | "ja" | "ko" | "ar" | "hi" | "other";

const langPreambles: Record<DetectedLang, string> = {
  en: "",
  es: "🌐 _Respondiendo en español:_\n\n",
  fr: "🌐 _Réponse en français :_\n\n",
  de: "🌐 _Antwort auf Deutsch:_\n\n",
  pt: "🌐 _Respondendo em português:_\n\n",
  zh: "🌐 _用中文回复：_\n\n",
  ja: "🌐 _日本語で回答：_\n\n",
  ko: "🌐 _한국어로 응답：_\n\n",
  ar: "🌐 _الرد بالعربية:_\n\n",
  hi: "🌐 _हिंदी में उत्तर:_\n\n",
  other: "🌐 _I detected a non-English language. Here's my response:_\n\n",
};

const langKeywords: Record<string, DetectedLang> = {
  // Spanish
  "qué": "es", "cómo": "es", "dónde": "es", "ayuda": "es", "hola": "es", "por favor": "es", "gracias": "es", "programa": "es", "calendario": "es",
  // French
  "bonjour": "fr", "comment": "fr", "merci": "fr", "quel": "fr", "aide": "fr", "où": "fr", "s'il vous plaît": "fr", "programme": "fr",
  // German
  "hallo": "de", "wie": "de", "danke": "de", "hilfe": "de", "bitte": "de", "zeitplan": "de", "wo": "de",
  // Portuguese
  "olá": "pt", "obrigado": "pt", "ajuda": "pt", "onde": "pt", "cronograma": "pt",
};

function detectLanguage(text: string): DetectedLang {
  // CJK character ranges
  if (/[\u4e00-\u9fff]/.test(text)) return "zh";
  if (/[\u3040-\u30ff]/.test(text)) return "ja";
  if (/[\uac00-\ud7af]/.test(text)) return "ko";
  if (/[\u0600-\u06ff]/.test(text)) return "ar";
  if (/[\u0900-\u097f]/.test(text)) return "hi";
  if (/[\u0400-\u04ff]/.test(text)) return "other"; // Cyrillic

  const lower = text.toLowerCase();
  for (const [keyword, lang] of Object.entries(langKeywords)) {
    if (lower.includes(keyword)) return lang;
  }
  return "en";
}

function getResponse(input: string): string {
  const lang = detectLanguage(input);
  const preamble = langPreambles[lang];
  const lower = input.toLowerCase();

  let baseResponse: string;

  for (const [key, response] of Object.entries(mockResponses)) {
    if (lower.includes(key)) {
      baseResponse = response;
      return preamble + baseResponse;
    }
  }
  if (lower.includes("color") || lower.includes("green") || lower.includes("red") || lower.includes("yellow") || lower.includes("verde") || lower.includes("rojo") || lower.includes("amarillo")) {
    return preamble + mockResponses.status;
  }
  if (lower.includes("help") || lower.includes("what") || lower.includes("ayuda") || lower.includes("aide") || lower.includes("hilfe") || lower.includes("帮") || lower.includes("助けて")) {
    return preamble + `I can help with:\n\n- **Schedule** — task timelines\n- **Status** — color meanings\n- **Phase Gate** — exit criteria\n- **NUDDs** — risk tracking\n- **Navigation** — finding pages\n- **Golden Configs** — configurations\n- **Build Execution** — manufacturing\n\nJust ask about any topic!`;
  }
  return preamble + `I understand you're asking about "${input}". Here are some topics I can help with:\n\n- Schedule & timelines\n- Status indicators (RYG)\n- Phase Gate Exit criteria\n- NUDDs & Design Issues\n- Navigation & search\n\nTry asking about one of these topics for a detailed explanation!`;
}

const AIChatbot = () => {
  const [open, setOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    { id: "greeting", role: "assistant", content: GREETING },
  ]);
  const [input, setInput] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, isTyping]);

  useEffect(() => {
    if (open) setTimeout(() => inputRef.current?.focus(), 200);
  }, [open]);

  // Listen for header help button
  useEffect(() => {
    const handler = () => setOpen(true);
    window.addEventListener("open-ai-chatbot", handler);
    return () => window.removeEventListener("open-ai-chatbot", handler);
  }, []);

  const handleSend = useCallback(() => {
    const text = input.trim();
    if (!text) return;

    const userMsg: Message = { id: Date.now().toString(), role: "user", content: text };
    setMessages((prev) => [...prev, userMsg]);
    setInput("");
    setIsTyping(true);

    setTimeout(() => {
      const response = getResponse(text);
      const assistantMsg: Message = { id: (Date.now() + 1).toString(), role: "assistant", content: response };
      setMessages((prev) => [...prev, assistantMsg]);
      setIsTyping(false);
    }, 600 + Math.random() * 800);
  }, [input]);

  return (
    <>

      {/* Chat Panel */}
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, y: 20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.95 }}
            transition={{ duration: 0.2, ease: [0.25, 0.1, 0.25, 1] }}
            className="fixed bottom-6 right-6 z-50 w-[400px] h-[520px] bg-card border border-border rounded-2xl shadow-2xl flex flex-col overflow-hidden"
          >
            {/* Header */}
            <div className="flex items-center justify-between px-5 py-3.5 border-b border-border bg-primary/[0.03]">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center">
                  <Sparkles className="w-4 h-4 text-primary" />
                </div>
                <div>
                  <h3 className="text-[13px] font-bold text-foreground">OLP Assistant</h3>
                  <p className="text-[10px] text-muted-foreground">Ask anything about the dashboard</p>
                </div>
              </div>
              <button
                onClick={() => setOpen(false)}
                className="p-1.5 rounded-lg hover:bg-muted transition-colors"
                aria-label="Close chat"
              >
                <X className="w-4 h-4 text-muted-foreground" />
              </button>
            </div>

            {/* Messages */}
            <div className="flex-1 overflow-y-auto px-4 py-4 space-y-4">
              {messages.map((msg) => (
                <div
                  key={msg.id}
                  className={cn(
                    "flex",
                    msg.role === "user" ? "justify-end" : "justify-start"
                  )}
                >
                  <div
                    className={cn(
                      "max-w-[85%] rounded-2xl px-4 py-2.5 text-[12px] leading-relaxed",
                      msg.role === "user"
                        ? "bg-primary text-primary-foreground rounded-br-md"
                        : "bg-muted/50 text-foreground rounded-bl-md border border-border/30"
                    )}
                  >
                    {msg.role === "assistant" ? (
                      <div className="prose prose-sm max-w-none [&_p]:m-0 [&_p]:mb-1.5 [&_ul]:m-0 [&_ul]:pl-4 [&_li]:m-0 [&_strong]:text-foreground [&_em]:text-muted-foreground text-[12px]">
                        <ReactMarkdown>{msg.content}</ReactMarkdown>
                      </div>
                    ) : (
                      msg.content
                    )}
                  </div>
                </div>
              ))}
              {isTyping && (
                <div className="flex justify-start">
                  <div className="bg-muted/50 rounded-2xl rounded-bl-md px-4 py-3 border border-border/30">
                    <div className="flex gap-1">
                      <span className="w-1.5 h-1.5 rounded-full bg-muted-foreground/40 animate-bounce [animation-delay:0ms]" />
                      <span className="w-1.5 h-1.5 rounded-full bg-muted-foreground/40 animate-bounce [animation-delay:150ms]" />
                      <span className="w-1.5 h-1.5 rounded-full bg-muted-foreground/40 animate-bounce [animation-delay:300ms]" />
                    </div>
                  </div>
                </div>
              )}
              <div ref={messagesEndRef} />
            </div>

            {/* Input */}
            <div className="px-4 py-3 border-t border-border bg-background/50">
              <div className="flex items-center gap-2 bg-muted/30 rounded-xl border border-border/30 px-3 py-1.5">
                <input
                  ref={inputRef}
                  type="text"
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && handleSend()}
                  placeholder="Ask a question..."
                  className="flex-1 bg-transparent text-[12px] text-foreground placeholder:text-muted-foreground/40 outline-none"
                />
                <button
                  onClick={handleSend}
                  disabled={!input.trim()}
                  className={cn(
                    "p-1.5 rounded-lg transition-all",
                    input.trim()
                      ? "bg-primary text-primary-foreground hover:bg-primary/90"
                      : "text-muted-foreground/30"
                  )}
                  aria-label="Send message"
                >
                  <Send className="w-3.5 h-3.5" />
                </button>
              </div>
              <p className="text-[9px] text-muted-foreground/30 text-center mt-1.5">
                Powered by OLP Assistant · Contextual help for your dashboard
              </p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
};

export default AIChatbot;
