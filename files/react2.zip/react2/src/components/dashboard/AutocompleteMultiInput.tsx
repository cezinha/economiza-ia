import { useEffect, useMemo, useRef, useState } from "react";
import { Search, X } from "lucide-react";
import { cn } from "@/lib/utils";

interface AutocompleteMultiInputProps {
  /** Full list of selectable suggestions. */
  options: string[];
  /** Currently selected values. */
  selected: string[];
  /** Called whenever the selection changes. */
  onChange: (next: string[]) => void;
  placeholder: string;
  ariaLabel: string;
  /** Tailwind width class for the input shell. */
  widthClass?: string;
  /** Max suggestions to render. */
  maxSuggestions?: number;
}

/**
 * Compact autocomplete + multi-select used in the Schedule page filter bar
 * for Owner and Task filtering. As the user types, matching options surface
 * in a dropdown; selecting one adds it as a chip. Free text can also be
 * committed with Enter (so partial task substrings still work).
 */
const AutocompleteMultiInput = ({
  options,
  selected,
  onChange,
  placeholder,
  ariaLabel,
  widthClass = "w-[160px]",
  maxSuggestions = 8,
}: AutocompleteMultiInputProps) => {
  const [query, setQuery] = useState("");
  const [open, setOpen] = useState(false);
  const [activeIdx, setActiveIdx] = useState(0);
  const containerRef = useRef<HTMLDivElement>(null);

  const suggestions = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return [] as string[];
    return options
      .filter((o) => o.toLowerCase().includes(q) && !selected.includes(o))
      .slice(0, maxSuggestions);
  }, [query, options, selected, maxSuggestions]);

  useEffect(() => {
    if (!open) return;
    const handler = (e: MouseEvent) => {
      if (!containerRef.current?.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, [open]);

  const commit = (value: string) => {
    const v = value.trim();
    if (!v || selected.includes(v)) {
      setQuery("");
      return;
    }
    onChange([...selected, v]);
    setQuery("");
    setActiveIdx(0);
  };

  const remove = (value: string) => {
    onChange(selected.filter((s) => s !== value));
  };

  return (
    <div ref={containerRef} className={cn("relative shrink-0", widthClass)}>
      <div
        className={cn(
          "flex items-center flex-wrap gap-1 min-h-7 px-1.5 py-0.5 text-[11px] rounded-md border border-input bg-background focus-within:ring-1 focus-within:ring-ring",
        )}
        onClick={() => {
          // Focus the inner input on shell click for a natural UX.
          const input = containerRef.current?.querySelector("input");
          input?.focus();
        }}
      >
        <Search className="w-3 h-3 text-muted-foreground shrink-0" />
        {selected.map((s) => (
          <span
            key={s}
            className="inline-flex items-center gap-0.5 max-w-[110px] pl-1.5 pr-0.5 py-px rounded bg-[hsl(var(--mds-blue))]/10 text-[hsl(var(--mds-blue))] font-medium"
            title={s}
          >
            <span className="truncate">{s}</span>
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                remove(s);
              }}
              className="rounded hover:bg-[hsl(var(--mds-blue))]/20 p-0.5 shrink-0"
              aria-label={`Remove ${s}`}
            >
              <X className="w-2.5 h-2.5" />
            </button>
          </span>
        ))}
        <input
          type="text"
          value={query}
          onChange={(e) => {
            setQuery(e.target.value);
            setOpen(true);
            setActiveIdx(0);
          }}
          onFocus={() => setOpen(true)}
          onKeyDown={(e) => {
            if (e.key === "ArrowDown") {
              e.preventDefault();
              setActiveIdx((i) => Math.min(i + 1, suggestions.length - 1));
            } else if (e.key === "ArrowUp") {
              e.preventDefault();
              setActiveIdx((i) => Math.max(i - 1, 0));
            } else if (e.key === "Enter") {
              e.preventDefault();
              if (suggestions[activeIdx]) commit(suggestions[activeIdx]);
              else if (query.trim()) commit(query);
            } else if (e.key === "Backspace" && !query && selected.length > 0) {
              remove(selected[selected.length - 1]);
            } else if (e.key === "Escape") {
              setOpen(false);
            }
          }}
          placeholder={selected.length === 0 ? placeholder : ""}
          aria-label={ariaLabel}
          className="flex-1 min-w-[40px] bg-transparent outline-none text-[11px] text-foreground placeholder:text-muted-foreground"
        />
      </div>

      {open && suggestions.length > 0 && (
        <div className="absolute z-50 left-0 right-0 mt-1 max-h-48 overflow-auto rounded-md border border-border bg-popover shadow-md">
          {suggestions.map((s, i) => (
            <button
              key={s}
              type="button"
              onMouseDown={(e) => {
                e.preventDefault();
                commit(s);
              }}
              onMouseEnter={() => setActiveIdx(i)}
              className={cn(
                "w-full text-left px-2 py-1 text-[11px] truncate",
                i === activeIdx
                  ? "bg-accent text-accent-foreground"
                  : "text-foreground hover:bg-accent/60",
              )}
              title={s}
            >
              {s}
            </button>
          ))}
        </div>
      )}
    </div>
  );
};

export default AutocompleteMultiInput;
