import { ReactNode } from "react";

interface ComingSoonBannerProps {
  message?: string;
  children?: ReactNode;
}

const ComingSoonBanner = ({
  message = "Coming soon — to be implemented in version 2.0",
  children,
}: ComingSoonBannerProps) => {
  // If no children, render the legacy centered card
  if (!children) {
    return (
      <div className="flex-1 flex items-center justify-center p-8">
        <div className="w-full max-w-4xl rounded-2xl bg-muted border border-border px-12 py-24 text-center shadow-sm">
          <h2 className="text-2xl md:text-3xl font-semibold text-muted-foreground">
            {message}
          </h2>
        </div>
      </div>
    );
  }

  // With children: render the underlying content blurred and overlay the gray box
  return (
    <div className="relative flex-1 min-h-[600px]">
      <div
        className="pointer-events-none select-none blur-sm opacity-60"
        aria-hidden="true"
      >
        {children}
      </div>
      <div className="absolute inset-0 flex items-center justify-center p-8 z-10">
        <div className="w-full max-w-4xl rounded-2xl bg-muted/95 backdrop-blur-sm border border-border px-12 py-24 text-center shadow-lg">
          <h2 className="text-2xl md:text-3xl font-semibold text-muted-foreground">
            {message}
          </h2>
        </div>
      </div>
    </div>
  );
};

export default ComingSoonBanner;
