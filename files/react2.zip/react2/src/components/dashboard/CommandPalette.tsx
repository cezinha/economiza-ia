import { useState, useEffect, useCallback, useRef } from "react";
import { useNavigate } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import { Search, Command, FileText, Calendar, LayoutDashboard, FolderOpen, AlertTriangle, FlaskConical, Hammer, CheckSquare, ClipboardCheck, Archive, ChevronRight, CornerDownLeft } from "lucide-react";
import { cn } from "@/lib/utils";

interface SearchItem {
  id: string;
  label: string;
  description: string;
  icon: typeof FileText;
  category: "program" | "page" | "task";
  path: string;
  state?: Record<string, string>;
}

const searchItems: SearchItem[] = [
  { id: "p1", label: "Laptop 1", description: "Desktop · Plan Phase · At Risk", icon: LayoutDashboard, category: "program", path: "/platform-summary", state: { selectedProgram: "Laptop 1" } },
  { id: "p2", label: "Laptop 2", description: "Desktop · Develop / Qual · At Risk", icon: LayoutDashboard, category: "program", path: "/platform-summary", state: { selectedProgram: "Laptop 2" } },
  { id: "p3", label: "Laptop 3", description: "Notebook · Ramp · On Track", icon: LayoutDashboard, category: "program", path: "/platform-summary", state: { selectedProgram: "Laptop 3" } },
  { id: "p4", label: "Laptop 4", description: "Notebook · Define · On Track", icon: LayoutDashboard, category: "program", path: "/platform-summary", state: { selectedProgram: "Laptop 4" } },
  { id: "p5", label: "Laptop 5", description: "Notebook · Incubate · On Track", icon: LayoutDashboard, category: "program", path: "/platform-summary", state: { selectedProgram: "Laptop 5" } },
  { id: "p6", label: "Laptop 6", description: "Server · Concept · On Track", icon: LayoutDashboard, category: "program", path: "/platform-summary", state: { selectedProgram: "Laptop 6" } },
  { id: "p7", label: "Laptop 7", description: "Server · Plan · Delayed", icon: LayoutDashboard, category: "program", path: "/platform-summary", state: { selectedProgram: "Laptop 7" } },
  { id: "pg1", label: "Home Page", description: "Dashboard overview", icon: LayoutDashboard, category: "page", path: "/" },
  { id: "pg2", label: "Platform Summary", description: "Executive program dashboard", icon: LayoutDashboard, category: "page", path: "/platform-summary" },
  { id: "pg3", label: "Doc & Data Curator", description: "Program documentation hub", icon: FolderOpen, category: "page", path: "/doc-curator" },
  { id: "pg4", label: "Program Details", description: "1-pager program summary", icon: FileText, category: "page", path: "/program-details" },
  { id: "pg5", label: "OLP Schedule", description: "Task schedule & timeline", icon: Calendar, category: "page", path: "/schedule" },
  { id: "pg6", label: "NUDDs & Design Issues", description: "Risk analysis & tracking", icon: AlertTriangle, category: "page", path: "/nudds" },
  
  { id: "pg8", label: "Build Execution", description: "Manufacturing tracking", icon: Hammer, category: "page", path: "/build-execution" },
  { id: "pg9", label: "Phase Gate Exit", description: "Phase exit criteria", icon: CheckSquare, category: "page", path: "/phase-gate" },
  { id: "pg10", label: "Current Task", description: "Task execution dashboard", icon: ClipboardCheck, category: "page", path: "/current-task" },
  { id: "pg11", label: "Archive", description: "Archived programs", icon: Archive, category: "page", path: "/archive" },
  { id: "t1", label: "Lock RTS/RTO schedule", description: "Laptop 1 · Plan · Overdue", icon: ClipboardCheck, category: "task", path: "/current-task" },
  { id: "t2", label: "Finalize BOM configurations", description: "Laptop 2 · Develop / Qual", icon: ClipboardCheck, category: "task", path: "/current-task" },
  { id: "t3", label: "Submit NUDD mitigations", description: "Laptop 7 · 3 high-severity", icon: AlertTriangle, category: "task", path: "/nudds" },
  { id: "t4", label: "Review pilot build results", description: "Laptop 4 · Build Execution", icon: Hammer, category: "task", path: "/build-execution" },
];

const categoryLabels: Record<string, string> = {
  program: "Programs",
  page: "Pages",
  task: "Tasks",
};

const CommandPalette = () => {
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState("");
  const [selectedIndex, setSelectedIndex] = useState(0);
  const navigate = useNavigate();
  const inputRef = useRef<HTMLInputElement>(null);
  const listRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === "k") {
        e.preventDefault();
        setOpen((prev) => !prev);
      }
      if (e.key === "Escape") setOpen(false);
    };
    document.addEventListener("keydown", handler);
    return () => document.removeEventListener("keydown", handler);
  }, []);

  useEffect(() => {
    if (open) {
      setQuery("");
      setSelectedIndex(0);
      setTimeout(() => inputRef.current?.focus(), 50);
    }
  }, [open]);

  const filtered = query.trim()
    ? searchItems.filter((item) => {
        const q = query.toLowerCase();
        return item.label.toLowerCase().includes(q) || item.description.toLowerCase().includes(q);
      })
    : searchItems;

  const grouped = filtered.reduce<Record<string, SearchItem[]>>((acc, item) => {
    if (!acc[item.category]) acc[item.category] = [];
    acc[item.category].push(item);
    return acc;
  }, {});

  const flatList = Object.values(grouped).flat();

  useEffect(() => {
    setSelectedIndex(0);
  }, [query]);

  const handleSelect = useCallback((item: SearchItem) => {
    setOpen(false);
    navigate(item.path, { state: item.state });
  }, [navigate]);

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "ArrowDown") {
      e.preventDefault();
      setSelectedIndex((prev) => Math.min(prev + 1, flatList.length - 1));
    } else if (e.key === "ArrowUp") {
      e.preventDefault();
      setSelectedIndex((prev) => Math.max(prev - 1, 0));
    } else if (e.key === "Enter" && flatList[selectedIndex]) {
      handleSelect(flatList[selectedIndex]);
    }
  };

  useEffect(() => {
    if (listRef.current) {
      const selected = listRef.current.querySelector("[data-selected='true']");
      selected?.scrollIntoView({ block: "nearest" });
    }
  }, [selectedIndex]);

  let flatIdx = -1;

  return (
    <>
      <button
        onClick={() => setOpen(true)}
        className="hidden md:flex items-center gap-2.5 px-4 py-[7px] rounded-xl bg-muted/30 border border-border/30 text-muted-foreground w-[320px] cursor-pointer hover:bg-muted/50 hover:border-border/50 transition-all duration-200 group"
        aria-label="Search"
      >
        <Search className="w-3.5 h-3.5 text-muted-foreground/40 group-hover:text-muted-foreground/60 transition-colors" />
        <span className="text-[11px] font-medium text-muted-foreground/40 group-hover:text-muted-foreground/60 transition-colors">Search programs, tasks...</span>
        <div className="ml-auto flex items-center gap-0.5 text-[10px] font-mono text-muted-foreground/25 bg-background/50 px-1.5 py-0.5 rounded border border-border/25">
          <Command className="w-2.5 h-2.5" />K
        </div>
      </button>

      <AnimatePresence>
        {open && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.12 }}
              className="fixed inset-0 bg-black/30 backdrop-blur-sm z-[100]"
              onClick={() => setOpen(false)}
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.96, y: -8 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.96, y: -8 }}
              transition={{ duration: 0.15, ease: [0.25, 0.1, 0.25, 1] }}
              className="fixed top-[15%] left-1/2 -translate-x-1/2 w-[540px] max-h-[70vh] bg-card border border-border/50 rounded-2xl shadow-2xl z-[101] overflow-hidden flex flex-col"
            >
              <div className="flex items-center gap-3 px-5 py-3.5 border-b border-border/25">
                <Search className="w-4 h-4 text-muted-foreground/40 shrink-0" />
                <input
                  ref={inputRef}
                  type="text"
                  placeholder="Search programs, pages, tasks..."
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  onKeyDown={handleKeyDown}
                  className="flex-1 bg-transparent text-[13px] font-medium text-foreground placeholder:text-muted-foreground/35 outline-none"
                />
                <kbd className="text-[9px] font-mono text-muted-foreground/25 bg-muted/25 px-1.5 py-0.5 rounded border border-border/25">ESC</kbd>
              </div>

              <div ref={listRef} className="flex-1 overflow-y-auto py-2 max-h-[50vh]">
                {flatList.length === 0 ? (
                  <div className="py-12 text-center">
                    <p className="text-[13px] text-muted-foreground/40 font-medium">No results found</p>
                    <p className="text-[11px] text-muted-foreground/25 mt-1">Try a different search term</p>
                  </div>
                ) : (
                  Object.entries(grouped).map(([category, items]) => (
                    <div key={category}>
                      <div className="px-5 py-1.5">
                        <span className="text-[10px] font-bold text-muted-foreground/35 uppercase tracking-[0.15em]">{categoryLabels[category]}</span>
                      </div>
                      {items.map((item) => {
                        flatIdx++;
                        const isSelected = flatIdx === selectedIndex;
                        const Icon = item.icon;
                        const currentIdx = flatIdx;
                        return (
                          <button
                            key={item.id}
                            data-selected={isSelected}
                            onClick={() => handleSelect(item)}
                            onMouseEnter={() => setSelectedIndex(currentIdx)}
                            className={cn(
                              "w-full flex items-center gap-3 px-5 py-2.5 text-left transition-colors",
                              isSelected ? "bg-primary/[0.05]" : "hover:bg-muted/15"
                            )}
                          >
                            <div className={cn(
                              "w-8 h-8 rounded-lg flex items-center justify-center shrink-0",
                              isSelected ? "bg-primary/10" : "bg-muted/20"
                            )}>
                              <Icon className={cn("w-3.5 h-3.5", isSelected ? "text-primary" : "text-muted-foreground/40")} />
                            </div>
                            <div className="flex-1 min-w-0">
                              <span className={cn("text-[12px] font-semibold block", isSelected ? "text-foreground" : "text-foreground/70")}>{item.label}</span>
                              <span className="text-[10px] text-muted-foreground/40 block truncate">{item.description}</span>
                            </div>
                            {isSelected && (
                              <div className="flex items-center gap-1 text-[10px] text-primary/40 shrink-0">
                                <CornerDownLeft className="w-3 h-3" />
                                <span className="font-medium">Open</span>
                              </div>
                            )}
                            <ChevronRight className={cn("w-3 h-3 shrink-0 transition-opacity", isSelected ? "text-primary/30 opacity-100" : "opacity-0")} />
                          </button>
                        );
                      })}
                    </div>
                  ))
                )}
              </div>

              <div className="px-5 py-2 border-t border-border/15 bg-muted/[0.02] flex items-center justify-between">
                <div className="flex items-center gap-3.5">
                  <span className="flex items-center gap-1 text-[9px] text-muted-foreground/25">
                    <kbd className="px-1 py-0.5 rounded bg-muted/25 border border-border/25 font-mono text-[8px]">↑↓</kbd>
                    Navigate
                  </span>
                  <span className="flex items-center gap-1 text-[9px] text-muted-foreground/25">
                    <kbd className="px-1 py-0.5 rounded bg-muted/25 border border-border/25 font-mono text-[8px]">↵</kbd>
                    Open
                  </span>
                  <span className="flex items-center gap-1 text-[9px] text-muted-foreground/25">
                    <kbd className="px-1 py-0.5 rounded bg-muted/25 border border-border/25 font-mono text-[8px]">esc</kbd>
                    Close
                  </span>
                </div>
                <span className="text-[9px] text-muted-foreground/20 font-medium">{flatList.length} results</span>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </>
  );
};

export default CommandPalette;
