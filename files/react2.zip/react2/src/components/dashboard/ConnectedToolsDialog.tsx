import { Link2, CheckCircle2 } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { cn } from "@/lib/utils";
import { motion } from "framer-motion";

interface ConnectedToolsDialogProps {
  open: boolean;
  onClose: () => void;
}

const tools = [
  { name: "Regrello", description: "Task Management & Workflow" },
  { name: "Jira", description: "Issue Tracking & Sprints" },
  { name: "JQIM", description: "Quality Issue Management" },
  { name: "DFx Tool", description: "Design for Excellence" },
  { name: "Supply Config Engine", description: "Supply Chain Config" },
  { name: "BOM Tool", description: "Bill of Materials" },
  { name: "GAFP Tool", description: "Platform Promotions" },
  { name: "DCOS", description: "RTS Readiness Tracking" },
  { name: "Planview", description: "Program Scheduling" },
  { name: "System Sample Tracker", description: "Sample Tracking" },
];

const ConnectedToolsDialog = ({ open, onClose }: ConnectedToolsDialogProps) => {
  return (
    <Dialog open={open} onOpenChange={(v) => !v && onClose()}>
      <DialogContent className="sm:max-w-[520px] rounded-xl">
        <DialogHeader>
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center">
              <Link2 className="w-4 h-4 text-primary" />
            </div>
            <div>
              <DialogTitle className="text-[14px] font-bold">Connected Tools</DialogTitle>
              <p className="text-[11px] text-muted-foreground mt-0.5">
                {tools.length} of {tools.length} tools connected
              </p>
            </div>
          </div>
          {/* Progress bar */}
          <div className="flex items-center gap-2.5 mt-3">
            <div className="flex-1 h-1.5 rounded-full bg-muted/30 overflow-hidden">
              <motion.div
                className="h-full rounded-full bg-success"
                initial={{ width: 0 }}
                animate={{ width: "100%" }}
                transition={{ duration: 0.6, delay: 0.2 }}
              />
            </div>
            <span className="text-[10px] font-bold text-success tabular-nums">
              {tools.length}/{tools.length}
            </span>
          </div>
        </DialogHeader>

        <div className="grid grid-cols-2 gap-2 mt-2">
          {tools.map((tool, idx) => (
            <motion.div
              key={tool.name}
              initial={{ opacity: 0, y: 3 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: idx * 0.03 }}
              className="relative flex flex-col rounded-xl border border-border/30 overflow-hidden"
            >
              <div className="h-[2px] w-full bg-success" />
              <div className="flex items-center gap-2.5 p-3">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-1.5 mb-0.5">
                    <span className="text-[11px] font-bold text-foreground truncate">{tool.name}</span>
                    <CheckCircle2 className="w-3 h-3 text-success shrink-0" />
                  </div>
                  <span className="text-[9px] text-muted-foreground/60 block truncate">{tool.description}</span>
                </div>
                <span className="text-[8px] px-2 py-0.5 rounded-full border font-bold shrink-0 bg-success/10 text-success border-success/20">
                  Connected
                </span>
              </div>
            </motion.div>
          ))}
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default ConnectedToolsDialog;
