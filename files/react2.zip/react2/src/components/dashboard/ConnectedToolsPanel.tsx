import { Link2, CheckCircle2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { motion } from "framer-motion";

interface ToolConnection {
  name: string;
  description: string;
  status: "connected" | "pending" | "not-connected";
  reqId?: string;
}

const tools: ToolConnection[] = [
  { name: "Regrello", description: "Task Management & Workflow", status: "connected", reqId: "#48" },
  { name: "Jira", description: "Issue Tracking & Sprints", status: "pending", reqId: "#26" },
  { name: "JQIM", description: "Quality Issue Management", status: "not-connected", reqId: "#51" },
  { name: "DFx Tool", description: "Design for Excellence", status: "not-connected", reqId: "#52" },
  { name: "Supply Config Engine", description: "Supply Chain Config", status: "not-connected", reqId: "#53" },
  { name: "BOM Tool", description: "Bill of Materials", status: "not-connected", reqId: "#56" },
  { name: "GAFP Tool", description: "Platform Promotions", status: "not-connected", reqId: "#57" },
  { name: "DCOS", description: "RTS Readiness Tracking", status: "not-connected", reqId: "#62" },
  { name: "Planview", description: "Program Scheduling", status: "not-connected", reqId: "#26" },
  { name: "System Sample Tracker", description: "Sample Tracking", status: "not-connected", reqId: "#55" },
];

const statusConfig: Record<string, { label: string; topBorder: string; dotClass: string; badgeClass: string }> = {
  connected: {
    label: "Connected",
    topBorder: "bg-success",
    dotClass: "bg-success",
    badgeClass: "bg-success/10 text-success border-success/20",
  },
  pending: {
    label: "Pending",
    topBorder: "bg-warning",
    dotClass: "bg-warning animate-pulse",
    badgeClass: "bg-warning/10 text-warning border-warning/20",
  },
  "not-connected": {
    label: "Not Connected",
    topBorder: "bg-muted-foreground/15",
    dotClass: "bg-muted-foreground/20",
    badgeClass: "bg-muted/40 text-muted-foreground border-border/40",
  },
};

const ConnectedToolsPanel = () => {
  const connectedCount = tools.filter((t) => t.status === "connected").length;
  const pendingCount = tools.filter((t) => t.status === "pending").length;
  const pct = Math.round((connectedCount / tools.length) * 100);

  return (
    <div className="card-elevated rounded-2xl overflow-hidden h-full flex flex-col">
      <div className="px-5 py-4 border-b border-border/30">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center">
              <Link2 className="w-4 h-4 text-primary" />
            </div>
            <div>
              <h3 className="text-[13px] font-bold text-foreground">Connected Tools</h3>
              <p className="text-[10px] text-muted-foreground">{connectedCount} active · {pendingCount} pending</p>
            </div>
          </div>
          <div className="flex items-center gap-2.5">
            <div className="w-24 h-1 rounded-full bg-muted/30 overflow-hidden">
              <motion.div
                className="h-full rounded-full bg-primary"
                initial={{ width: 0 }}
                animate={{ width: `${pct}%` }}
                transition={{ duration: 0.6, delay: 0.2 }}
              />
            </div>
            <span className="text-[10px] font-bold text-muted-foreground tabular-nums">{connectedCount}/{tools.length}</span>
          </div>
        </div>
      </div>

      <div className="p-3 flex-1">
        <div className="grid grid-cols-2 gap-2">
          {tools.map((tool, idx) => {
            const cfg = statusConfig[tool.status];
            return (
              <motion.div
                key={tool.name}
                initial={{ opacity: 0, y: 3 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: idx * 0.02 }}
                className="relative flex flex-col rounded-xl border border-border/30 hover:border-border/50 hover:bg-muted/15 transition-all duration-200 overflow-hidden group"
              >
                <div className={cn("h-[2px] w-full", cfg.topBorder)} />

                <div className="flex items-center gap-2.5 p-3">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-1.5 mb-0.5">
                      <span className="text-[11px] font-bold text-foreground truncate">{tool.name}</span>
                      {tool.status === "connected" && <CheckCircle2 className="w-3 h-3 text-success shrink-0" />}
                    </div>
                    <span className="text-[9px] text-muted-foreground/60 block truncate">{tool.description}</span>
                  </div>
                  {tool.status === "not-connected" ? (
                    <Button
                      variant="outline"
                      size="sm"
                      className="h-6 text-[9px] px-2.5 shrink-0 font-bold hover:bg-primary hover:text-primary-foreground hover:border-primary transition-all press-scale rounded-lg"
                    >
                      Connect
                    </Button>
                  ) : (
                    <span className={cn("text-[8px] px-2 py-0.5 rounded-full border font-bold shrink-0", cfg.badgeClass)}>
                      {cfg.label}
                    </span>
                  )}
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>
    </div>
  );
};

export default ConnectedToolsPanel;
