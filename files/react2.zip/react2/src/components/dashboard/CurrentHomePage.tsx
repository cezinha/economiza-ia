import React, { useState, useMemo, useEffect } from "react";
import { motion } from "framer-motion";
import { 
  BarChart3, Calendar, Activity, TrendingUp, TrendingDown, Minus,
  Star, ChevronRight, AlertTriangle, CheckCircle2, XCircle, Clock,
  Zap, ArrowUpRight, Info, FileText, ShieldCheck, Factory, FileArchive, GitBranch, Truck,
  Hammer, FolderOpen, FlaskConical, ClipboardList, LayoutGrid
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useNavigate, useLocation } from "react-router-dom";
import { usePlatform } from "@/contexts/PlatformContext";
import { useWatchlist } from "@/contexts/WatchlistContext";
import { useUniversalFilters, defaultFilters, PLATFORM_LOB, LOBS } from "@/contexts/UniversalFilterContext";
import { useRole } from "@/contexts/RoleContext";
import { programs, getProgramStatus as _legacyGetProgramStatus, type ProgramStatus, type Program } from "./ProgramOverviewTimeline";
import { programSchedules, computeRollupStatus } from "@/data/scheduleData";

// Derive program status from its full task list (same source as Portfolio Schedule)
const getProgramStatus = (p: Program): ProgramStatus => {
  const phases = programSchedules[p.name] || [];
  const allTasks = phases.flatMap((ph) => ph.milestones.flatMap((m) => m.tasks));
  const rollup = computeRollupStatus(allTasks);
  if (rollup === "delayed") return "delayed";
  if (rollup === "at-risk") return "at-risk";
  return "on-track";
};
import HomeFilterBar from "./HomeFilterBar";
import { useHomeFilters } from "@/contexts/HomeFilterContext";

// Every platform is CSG for now; expand here when ISG products are added.
const PLATFORM_ORG: Record<string, "CSG" | "ISG"> = {
  "Laptop 1": "CSG", "Laptop 2": "CSG", "Laptop 3": "CSG", "Laptop 4": "CSG",
  "Laptop 5": "CSG", "Laptop 6": "CSG", "Laptop 7": "CSG",
};

// Map a phase string from program data → canonical 5-phase name used in the filter.
const STATUS_LABEL_TO_KEY: Record<string, ProgramStatus> = {
  "On Track": "on-track",
  "At Risk w/ Mitigation": "at-risk",
  "At Risk w/ No Plan": "delayed",
};

const getCurrentCanonicalPhase = (programName: string): string => {
  const phases = programSchedules[programName] || [];
  const active =
    phases.find((ph) => ph.milestones.flatMap((m) => m.tasks).some((t) => t.status !== "completed")) ||
    phases[phases.length - 1];
  if (!active) return "Concept";
  const n = active.name;
  if (n === "Concept") return "Concept";
  if (n === "Define") return "Define";
  if (n === "Plan") return "Plan";
  if (n === "Qual" || n.includes("Develop")) return "Qual";
  if (n === "Ramp" || n.includes("Launch")) return "Ramp";
  if (n === "Pilot" || n.includes("Pilot")) return "Pilot";
  return "Concept";
};


import PortfolioScheduleGantt from "./PortfolioScheduleGantt";
import StatusUpdateModal from "./StatusUpdateModal";
import LobReportSection from "./LobReportSection";
import PortfolioPhaseDistribution from "./PortfolioPhaseDistribution";
import { useTimezone } from "@/hooks/use-timezone";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";

const getUserFirstName = () => {
  const name = localStorage.getItem("userName") || "John Doe";
  return name.split(" ")[0];
};

// ── Animation presets ──
const stagger = {
  hidden: {},
  show: { transition: { staggerChildren: 0.05 } },
};
const fadeUp = {
  hidden: { opacity: 0, y: 16 },
  show: { opacity: 1, y: 0, transition: { duration: 0.45, ease: [0.25, 0.1, 0.25, 1] as const } },
};

const getGreeting = () => {
  const h = new Date().getHours();
  if (h < 12) return "Good morning";
  if (h < 17) return "Good afternoon";
  return "Good evening";
};

// ── Program summary data ──
const programSummary: Record<string, { phase: string; onSchedule: number; risks: number; productCost: string; costDelta: string; costDeltaDir: "up" | "down" | "flat" }> = {
  "Laptop 1": { phase: "Plan", onSchedule: 82, risks: 3, productCost: "$1,245", costDelta: "+5.4%", costDeltaDir: "up" },
  "Laptop 2": { phase: "Qual", onSchedule: 74, risks: 2, productCost: "$1,180", costDelta: "+2.1%", costDeltaDir: "up" },
  "Laptop 3": { phase: "Ramp", onSchedule: 96, risks: 1, productCost: "$1,350", costDelta: "-1.2%", costDeltaDir: "down" },
  "Laptop 4": { phase: "Define", onSchedule: 91, risks: 4, productCost: "$1,420", costDelta: "+3.8%", costDeltaDir: "up" },
  "Laptop 5": { phase: "Incubate", onSchedule: 100, risks: 0, productCost: "$1,100", costDelta: "0%", costDeltaDir: "flat" },
  "Laptop 6": { phase: "Concept", onSchedule: 93, risks: 2, productCost: "$1,290", costDelta: "-0.5%", costDeltaDir: "down" },
  "Laptop 7": { phase: "Plan", onSchedule: 58, risks: 5, productCost: "$1,500", costDelta: "+7.2%", costDeltaDir: "up" },
};

// ── Per-platform tracker metrics (integrated into Portfolio Overview table) ──
type TrackerCellTone = "success" | "warning" | "destructive" | "muted" | "primary";
interface TrackerCell {
  value: string;
  tone: TrackerCellTone;
  hint: string;
}
interface PlatformTrackers {
  docs: TrackerCell;          // Document Repository
  factory: TrackerCell;       // Factory Constraints
  compliance: TrackerCell;    // Compliance
  dependencies: TrackerCell;  // Dependencies
  supplyChain: TrackerCell;   // Supply Chain
  buildExecution: TrackerCell;// Build Execution
  docCurator: TrackerCell;    // Doc Curator
  goldenConfigs: TrackerCell; // Golden Configs
  currentTask: TrackerCell;   // Current Task
}
const platformTrackers: Record<string, PlatformTrackers> = {
  "Laptop 1": {
    docs:           { value: "11/14",  tone: "success",     hint: "11 of 14 approved" },
    factory:        { value: "2",      tone: "warning",     hint: "2 open constraints" },
    compliance:     { value: "92%",    tone: "success",     hint: "Pass rate" },
    dependencies:   { value: "3",      tone: "primary",     hint: "Active dependencies" },
    supplyChain:    { value: "62/100", tone: "warning",     hint: "Risk score" },
    buildExecution: { value: "2/3",    tone: "primary",     hint: "Builds completed" },
    docCurator:     { value: "18/22",  tone: "success",     hint: "Documents complete" },
    goldenConfigs:  { value: "4",      tone: "success",     hint: "Locked configs" },
    currentTask:    { value: "5",      tone: "primary",     hint: "In progress" },
  },
  "Laptop 2": {
    docs:           { value: "8/12",   tone: "warning",     hint: "8 of 12 approved" },
    factory:        { value: "3",      tone: "destructive", hint: "3 critical constraints" },
    compliance:     { value: "78%",    tone: "warning",     hint: "Pass rate" },
    dependencies:   { value: "2",      tone: "warning",     hint: "At risk" },
    supplyChain:    { value: "71/100", tone: "destructive", hint: "Risk score" },
    buildExecution: { value: "1/4",    tone: "warning",     hint: "Builds completed" },
    docCurator:     { value: "14/20",  tone: "warning",     hint: "Documents complete" },
    goldenConfigs:  { value: "3",      tone: "warning",     hint: "Draft configs" },
    currentTask:    { value: "7",      tone: "warning",     hint: "Open tasks" },
  },
  "Laptop 3": {
    docs:           { value: "16/16",  tone: "success",     hint: "All approved" },
    factory:        { value: "0",      tone: "success",     hint: "No constraints" },
    compliance:     { value: "98%",    tone: "success",     hint: "Pass rate" },
    dependencies:   { value: "1",      tone: "primary",     hint: "Active" },
    supplyChain:    { value: "32/100", tone: "success",     hint: "Risk score" },
    buildExecution: { value: "5/5",    tone: "success",     hint: "Builds completed" },
    docCurator:     { value: "24/24",  tone: "success",     hint: "Documents complete" },
    goldenConfigs:  { value: "6",      tone: "success",     hint: "Locked configs" },
    currentTask:    { value: "2",      tone: "muted",       hint: "Open tasks" },
  },
  "Laptop 4": {
    docs:           { value: "6/15",   tone: "warning",     hint: "6 of 15 approved" },
    factory:        { value: "4",      tone: "destructive", hint: "4 critical constraints" },
    compliance:     { value: "85%",    tone: "primary",     hint: "Pass rate" },
    dependencies:   { value: "4",      tone: "warning",     hint: "At risk" },
    supplyChain:    { value: "58/100", tone: "warning",     hint: "Risk score" },
    buildExecution: { value: "0/2",    tone: "muted",       hint: "Not started" },
    docCurator:     { value: "9/18",   tone: "warning",     hint: "Documents complete" },
    goldenConfigs:  { value: "2",      tone: "warning",     hint: "Draft configs" },
    currentTask:    { value: "8",      tone: "destructive", hint: "Overdue" },
  },
  "Laptop 5": {
    docs:           { value: "2/8",    tone: "muted",       hint: "Early stage" },
    factory:        { value: "0",      tone: "success",     hint: "No constraints" },
    compliance:     { value: "—",      tone: "muted",       hint: "Not yet started" },
    dependencies:   { value: "0",      tone: "muted",       hint: "None" },
    supplyChain:    { value: "—",      tone: "muted",       hint: "Pre-BOM" },
    buildExecution: { value: "0/1",    tone: "muted",       hint: "Not started" },
    docCurator:     { value: "3/10",   tone: "muted",       hint: "In progress" },
    goldenConfigs:  { value: "1",      tone: "muted",       hint: "Pending" },
    currentTask:    { value: "1",      tone: "muted",       hint: "Open" },
  },
  "Laptop 6": {
    docs:           { value: "5/9",    tone: "primary",     hint: "5 of 9 approved" },
    factory:        { value: "1",      tone: "warning",     hint: "1 warning" },
    compliance:     { value: "88%",    tone: "primary",     hint: "Pass rate" },
    dependencies:   { value: "2",      tone: "primary",     hint: "Active" },
    supplyChain:    { value: "45/100", tone: "primary",     hint: "Risk score" },
    buildExecution: { value: "1/2",    tone: "primary",     hint: "In progress" },
    docCurator:     { value: "11/15",  tone: "primary",     hint: "Documents complete" },
    goldenConfigs:  { value: "2",      tone: "primary",     hint: "Locked" },
    currentTask:    { value: "3",      tone: "primary",     hint: "Open" },
  },
  "Laptop 7": {
    docs:           { value: "4/14",   tone: "destructive", hint: "Behind schedule" },
    factory:        { value: "5",      tone: "destructive", hint: "5 critical" },
    compliance:     { value: "62%",    tone: "destructive", hint: "Pass rate" },
    dependencies:   { value: "5",      tone: "destructive", hint: "Impacted" },
    supplyChain:    { value: "82/100", tone: "destructive", hint: "Risk score" },
    buildExecution: { value: "0/3",    tone: "destructive", hint: "Delayed" },
    docCurator:     { value: "5/17",   tone: "destructive", hint: "Behind" },
    goldenConfigs:  { value: "1",      tone: "destructive", hint: "Pending" },
    currentTask:    { value: "9",      tone: "destructive", hint: "Overdue" },
  },
};

const TONE_TEXT: Record<TrackerCellTone, string> = {
  success: "text-success",
  warning: "text-warning",
  destructive: "text-destructive",
  muted: "text-muted-foreground",
  primary: "text-primary",
};
const TONE_BG: Record<TrackerCellTone, string> = {
  success: "bg-success/10",
  warning: "bg-warning/10",
  destructive: "bg-destructive/10",
  muted: "bg-muted/30",
  primary: "bg-primary/10",
};

const TRACKER_COLUMNS: { key: keyof PlatformTrackers; label: string; route: string }[] = [
  { key: "docs",           label: "Docs",     route: "/document-repository" },
  { key: "docCurator",     label: "Curator",  route: "/doc-curator" },
  { key: "buildExecution", label: "Builds",   route: "/build-execution" },
  { key: "compliance",     label: "Comply",   route: "/compliance" },
  { key: "factory",        label: "Factory",  route: "/factory-constraints" },
  { key: "dependencies",   label: "Deps",     route: "/dependencies" },
  { key: "supplyChain",    label: "Supply",   route: "/supply-chain" },
  { key: "currentTask",    label: "Tasks",    route: "/current-task" },
];

// ── Status config ──
const statusConfig: { key: ProgramStatus; label: string; icon: typeof CheckCircle2; color: string; bg: string; ring: string; bar: string; dot: string }[] = [
  { key: "on-track", label: "On Track", icon: CheckCircle2, color: "text-success", bg: "bg-success/8", ring: "ring-success/30", bar: "bg-success", dot: "bg-success" },
  { key: "at-risk", label: "At Risk w/ Mitigation", icon: AlertTriangle, color: "text-warning", bg: "bg-warning/8", ring: "ring-warning/30", bar: "bg-warning", dot: "bg-warning" },
  { key: "delayed", label: "At Risk w/ No Plan", icon: XCircle, color: "text-destructive", bg: "bg-destructive/8", ring: "ring-destructive/30", bar: "bg-destructive", dot: "bg-destructive" },
];

const DeltaIcon = ({ dir }: { dir: "up" | "down" | "flat" }) => {
  if (dir === "up") return <TrendingUp className="w-3 h-3" />;
  if (dir === "down") return <TrendingDown className="w-3 h-3" />;
  return <Minus className="w-2.5 h-2.5" />;
};

// ── Reusable status-summary grid ──
interface StatusSummaryGridProps {
  programsList: Program[];
  statusFilter: ProgramStatus | null;
  onStatusClick: (k: ProgramStatus) => void;
  compact?: boolean;
}

const StatusSummaryGrid = ({ programsList, statusFilter, onStatusClick, compact = false }: StatusSummaryGridProps) => {
  const total = programsList.length;
  const local = {
    counts: { "on-track": 0, "at-risk": 0, delayed: 0 } as Record<ProgramStatus, number>,
    byStatus: { "on-track": [], "at-risk": [], delayed: [] } as Record<ProgramStatus, string[]>,
  };
  programsList.forEach((p) => {
    const s = getProgramStatus(p);
    local.counts[s]++;
    local.byStatus[s].push(p.name);
  });

  return (
    <div className="grid grid-cols-3 gap-4">
      {statusConfig.map((cfg, idx) => {
        const count = local.counts[cfg.key];
        const pct = total > 0 ? Math.round((count / total) * 100) : 0;
        const isActive = statusFilter === cfg.key;
        const Icon = cfg.icon;
        return (
          <motion.button
            key={cfg.key}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3, delay: idx * 0.05 }}
            onClick={() => onStatusClick(cfg.key)}
            className={cn(
              "relative rounded-2xl border overflow-hidden text-left transition-all duration-200 group",
              "bg-card shadow-[var(--card-shadow)]",
              isActive
                ? `ring-2 ring-offset-2 ring-offset-background ${cfg.ring} border-transparent`
                : "border-border/40 hover:border-border/60 hover:shadow-md"
            )}
          >
            <div className={cn("h-1 w-full", cfg.bar)} />
            <div className={compact ? "p-4" : "p-5"}>
              <div className={cn("flex items-start justify-between", compact ? "mb-2" : "mb-3")}>
                <div className="flex items-center gap-2.5">
                  <div className={cn("rounded-xl flex items-center justify-center", compact ? "w-8 h-8" : "w-9 h-9", cfg.bg)}>
                    <Icon className={cn(compact ? "h-4 w-4" : "h-[18px] w-[18px]", cfg.color)} />
                  </div>
                  <div>
                    <h3 className={cn("font-bold text-foreground", compact ? "text-[12px]" : "text-[13px]")}>{cfg.label}</h3>
                    {!compact && (
                      <p className="text-[10px] text-muted-foreground">
                        {cfg.key === "on-track" ? "Progressing as planned" : cfg.key === "at-risk" ? "Mitigation plan in place to meet POR" : "No mitigation plan in place"}
                      </p>
                    )}
                  </div>
                </div>
                <span className={cn("font-black tabular-nums leading-none tracking-tighter", compact ? "text-[32px]" : "text-[40px]", cfg.color)}>{count}</span>
              </div>
              <div className={cn("flex items-center gap-3", compact ? "mb-2" : "mb-3")}>
                <div className="h-1 flex-1 rounded-full bg-muted/30 overflow-hidden">
                  <motion.div
                    className={cn("h-full rounded-full", cfg.bar)}
                    initial={{ width: 0 }}
                    animate={{ width: `${pct}%` }}
                    transition={{ duration: 0.6, delay: 0.15 + idx * 0.08 }}
                  />
                </div>
                <span className="text-[10px] font-semibold text-muted-foreground tabular-nums whitespace-nowrap">{pct}%</span>
              </div>
              <div className="flex flex-wrap gap-1.5">
                {local.byStatus[cfg.key].map((name) => (
                  <span key={name} className="inline-flex items-center gap-1.5 text-[10px] text-foreground/60 bg-muted/20 px-2.5 py-1 rounded-full font-medium border border-border/20">
                    <span className={cn("w-1.5 h-1.5 rounded-full", cfg.dot)} />
                    {name}
                  </span>
                ))}
                {local.byStatus[cfg.key].length === 0 && (
                  <span className="text-[10px] text-muted-foreground/40 italic">None</span>
                )}
              </div>
            </div>
          </motion.button>
        );
      })}
    </div>
  );
};

const CurrentHomePage = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { toggleWatchlist, isInWatchlist } = useWatchlist();
  const { matchesPlatform, setFilters, updateFilter } = useUniversalFilters();
  const { isScoped, assignedPlatforms } = useRole();
  const [statusFilter, setStatusFilter] = useState<ProgramStatus | null>(null);
  const { filters: homeFilters } = useHomeFilters();
  const [myProgramsOnly, setMyProgramsOnly] = useState(false);
  const [collapsedLobs, setCollapsedLobs] = useState<Set<string>>(() => new Set(LOBS));
  const [statusUpdateProgram, setStatusUpdateProgram] = useState<Program | null>(null);
  const { formatTime, resolvedTimezone } = useTimezone();
  const [currentTime, setCurrentTime] = useState(formatTime());

  const { setSelectedPlatform } = usePlatform();

  // Reset filters when returning to home — but for scoped roles (Admin/User),
  // default to their assigned platform(s) instead of clearing filters.
  useEffect(() => {
    if (isScoped && assignedPlatforms.length > 0) {
      const primary = assignedPlatforms[0];
      const lob = PLATFORM_LOB[primary];
      const allSameLob = assignedPlatforms.every((p) => PLATFORM_LOB[p] === lob);
      if (allSameLob && lob) updateFilter("lob", lob);
      else updateFilter("lob", "all");

      // Single-platform → lock the platform filter to it. Multi-platform Admin →
      // leave the platform filter on "all" so the table shows every assigned row.
      if (assignedPlatforms.length === 1) {
        updateFilter("platform", primary);
        setSelectedPlatform(primary);
      } else {
        updateFilter("platform", "all");
        setSelectedPlatform(null);
      }
    } else {
      setFilters(defaultFilters);
      setSelectedPlatform(null);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isScoped, assignedPlatforms]);

  // Handle scroll-to from sidebar navigation
  useEffect(() => {
    const state = location.state as { scrollTo?: string } | null;
    if (state?.scrollTo) {
      setTimeout(() => {
        document.getElementById(state.scrollTo!)?.scrollIntoView({ behavior: "smooth", block: "start" });
      }, 150);
      window.history.replaceState({}, "");
    }
  }, [location.state]);

  useEffect(() => {
    setCurrentTime(formatTime());
    const interval = setInterval(() => setCurrentTime(formatTime()), 30_000);
    return () => clearInterval(interval);
  }, [formatTime]);

  const today = new Date().toLocaleDateString("en-US", { weekday: "long", month: "long", day: "numeric", year: "numeric", timeZone: resolvedTimezone });

  // Restrict the universe of programs to the user's assignments when scoped.
  const assignedSet = useMemo(() => new Set(assignedPlatforms), [assignedPlatforms]);
  const activePrograms = useMemo(
    () =>
      programs.filter((p) => {
        if (p.archived) return false;
        if (!matchesPlatform(p.name)) return false;
        if (isScoped && !assignedSet.has(p.name)) return false;
        // Org filter
        if (homeFilters.orgs.length > 0 && !homeFilters.orgs.includes(PLATFORM_ORG[p.name] ?? "CSG")) return false;
        // LOB filter
        if (homeFilters.lobs.length > 0 && !homeFilters.lobs.includes(PLATFORM_LOB[p.name])) return false;
        // Platform filter
        if (homeFilters.platforms.length > 0 && !homeFilters.platforms.includes(p.name)) return false;
        // Phase filter
        if (homeFilters.phases.length > 0 && !homeFilters.phases.includes(getCurrentCanonicalPhase(p.name))) return false;
        // Status filter
        if (homeFilters.statuses.length > 0) {
          const statusKey = getProgramStatus(p);
          const allowed = homeFilters.statuses.map((s) => STATUS_LABEL_TO_KEY[s]);
          if (!allowed.includes(statusKey)) return false;
        }
        return true;
      }),
    [matchesPlatform, isScoped, assignedSet, homeFilters]
  );
  
  const counts = useMemo(() => {
    const c: Record<ProgramStatus, number> = { "on-track": 0, "at-risk": 0, delayed: 0 };
    const byStatus: Record<ProgramStatus, string[]> = { "on-track": [], "at-risk": [], delayed: [] };
    activePrograms.forEach(p => {
      const s = getProgramStatus(p);
      c[s]++;
      byStatus[s].push(p.name);
    });
    return { counts: c, byStatus };
  }, [activePrograms]);

  const totalRisks = useMemo(() => activePrograms.reduce((sum, p) => sum + (programSummary[p.name]?.risks ?? 0), 0), [activePrograms]);
  const avgSchedule = useMemo(() => {
    if (activePrograms.length === 0) return 0;
    return Math.round(activePrograms.reduce((sum, p) => sum + (programSummary[p.name]?.onSchedule ?? 0), 0) / activePrograms.length);
  }, [activePrograms]);

  // ── Filtered subtab summary metrics ──
  const subtabMetrics = useMemo(() => {
    const platformCount = activePrograms.length;
    // Scale metrics proportionally to filtered platforms
    const ratio = platformCount / 7; // 7 total platforms

    const docTotal = Math.round(18 * ratio);
    const docApproved = Math.round(11 * ratio);
    const docPending = Math.round(4 * ratio);
    const docDraft = Math.max(0, docTotal - docApproved - docPending);

    const fcTotal = Math.round(10 * ratio);
    const fcCritical = Math.round(4 * ratio);
    const fcWarning = Math.round(4 * ratio);
    const fcOpen = Math.round(5 * ratio);

    const compTotal = Math.round(12 * ratio);
    const compPassed = Math.round(5 * ratio);
    const compOutstanding = Math.round(6 * ratio);
    const compFailed = Math.max(0, compTotal - compPassed - compOutstanding);
    const compPassRate = compTotal > 0 ? Math.round((compPassed / compTotal) * 100) : 0;

    return {
      docs: { total: docTotal, approved: docApproved, pending: docPending, draft: docDraft },
      factory: { total: fcTotal, critical: fcCritical, warning: fcWarning, open: fcOpen },
      compliance: { total: compTotal, passRate: compPassRate, outstanding: compOutstanding, failed: compFailed },
      dependencies: {
        total: Math.round(12 * ratio),
        active: Math.round(6 * ratio),
        atRisk: Math.round(3 * ratio),
        impacted: Math.round(2 * ratio),
        notifications: Math.round(5 * ratio),
      },
      supplyChain: {
        riskScore: Math.round(56 * ratio / (ratio || 1)),
        avgLeadTime: 10,
        criticalParts: Math.round(2 * ratio),
        bomComplete: Math.round(80 * ratio / (ratio || 1)),
      },
      buildExecution: {
        totalBuilds: Math.round(8 * ratio),
        completed: Math.round(3 * ratio),
        inProgress: Math.round(2 * ratio),
        upcoming: Math.round(3 * ratio),
      },
      docCurator: {
        totalDocs: Math.round(24 * ratio),
        complete: Math.round(14 * ratio),
        inReview: Math.round(6 * ratio),
        missing: Math.round(4 * ratio),
      },
      goldenConfigs: {
        totalConfigs: Math.round(12 * ratio),
        locked: Math.round(5 * ratio),
        draft: Math.round(4 * ratio),
        pending: Math.round(3 * ratio),
      },
      currentTask: {
        totalTasks: Math.round(15 * ratio),
        completed: Math.round(6 * ratio),
        inProgress: Math.round(4 * ratio),
        overdue: Math.round(5 * ratio),
      },
    };
  }, [activePrograms]);

  const filteredPrograms = useMemo(() => {
    let result = activePrograms;
    if (statusFilter) result = result.filter(p => getProgramStatus(p) === statusFilter);
    if (myProgramsOnly) result = result.filter(p => isInWatchlist(p.name));
    return result;
  }, [activePrograms, statusFilter, myProgramsOnly, isInWatchlist]);

  const toggleLob = (lob: string) => {
    setCollapsedLobs(prev => {
      const next = new Set(prev);
      if (next.has(lob)) next.delete(lob); else next.add(lob);
      return next;
    });
  };

  const groupedPrograms = useMemo(() => {
    const groups: { lob: string; programs: typeof filteredPrograms }[] = [];
    for (const lob of LOBS) {
      const progs = filteredPrograms.filter(p => PLATFORM_LOB[p.name] === lob);
      groups.push({ lob, programs: progs });
    }
    const unassigned = filteredPrograms.filter(p => !LOBS.includes(PLATFORM_LOB[p.name] as any));
    if (unassigned.length > 0) groups.push({ lob: "Other", programs: unassigned });
    return groups;
  }, [filteredPrograms]);

  const quickStats = [
    {
      label: "Active Platforms",
      value: String(activePrograms.length),
      icon: BarChart3,
      accent: "text-primary",
      tooltip: "Platforms currently in an active phase (Concept → Pilot/Ramp/Launch). Excludes archived or not-started programs.",
    },
    {
      label: "Avg On-Schedule",
      value: `${avgSchedule}%`,
      icon: Activity,
      accent: avgSchedule >= 85 ? "text-success" : avgSchedule >= 70 ? "text-warning" : "text-destructive",
      tooltip: "Portfolio-wide average of tasks completed on or ahead of their planned date, across all active platforms.",
    },
    {
      label: "Open Risks",
      value: String(totalRisks),
      icon: AlertTriangle,
      accent: totalRisks > 10 ? "text-destructive" : "text-warning",
      tooltip: "Total unresolved risks (NUDDs + Design Issues) currently flagged across the portfolio that require mitigation.",
    },
  ];

  return (
    <div id="home-scroll-container" className="flex-1 flex flex-col overflow-auto">
      <motion.div
        variants={stagger}
        initial="hidden"
        animate="show"
        className="px-8 pt-7 pb-10 space-y-6 max-w-[1600px] mx-auto w-full"
      >
        {/* ─── Hero Banner ─── */}
        <motion.div variants={fadeUp} className="relative overflow-hidden rounded-2xl">
          {/* Background gradient */}
          <div className="absolute inset-0 bg-gradient-to-br from-[hsl(var(--dell-navy))] via-[hsl(207,48%,18%)] to-[hsl(207,55%,24%)]" />
          {/* Dot pattern overlay */}
          <div className="absolute inset-0 opacity-[0.03]" style={{ backgroundImage: "radial-gradient(circle, white 1px, transparent 1px)", backgroundSize: "24px 24px" }} />
          {/* Glow effects */}
          <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-[hsl(207,100%,55%)]/[0.07] rounded-full blur-[100px] -translate-y-1/2 translate-x-1/4" />
          <div className="absolute bottom-0 left-0 w-[300px] h-[300px] bg-[hsl(207,100%,50%)]/[0.05] rounded-full blur-[80px] translate-y-1/2 -translate-x-1/4" />

          <div className="relative z-10 p-8 pb-7">
            <div className="flex items-end justify-between gap-8">
              {/* Left: greeting & subtitle */}
              <div className="space-y-2">
                <div className="flex items-center gap-2 mb-1">
                  <p className="text-white/50 text-[10px] font-bold uppercase tracking-[0.2em]">{today}</p>
                  <span className="text-white/20">·</span>
                  <div className="flex items-center gap-1.5 text-white/40">
                    <Clock className="w-3 h-3" />
                    <span className="text-[10px] font-bold uppercase tracking-[0.15em] tabular-nums">{currentTime}</span>
                  </div>
                </div>
                <h1 className="text-[32px] font-black tracking-tight text-white leading-none">{getGreeting()}, {getUserFirstName()}</h1>
                <p className="text-white/50 text-[13px] font-medium">OLP Launch Orchestrator — Portfolio at a glance</p>
              </div>

              {/* Right: stats + live indicator */}
              <div className="flex items-center gap-8">
                <TooltipProvider delayDuration={150}>
                  {quickStats.map((stat, i) => (
                    <motion.div
                      key={stat.label}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: 0.3 + i * 0.08 }}
                      className="text-center min-w-[80px]"
                    >
                      <div className="flex items-center justify-center gap-2 mb-1">
                        <stat.icon className="w-3.5 h-3.5 text-white/40" />
                        <span className="text-[30px] font-black text-white tabular-nums leading-none">{stat.value}</span>
                      </div>
                      <div className="flex items-center justify-center gap-1">
                        <span className="text-[9px] text-white/50 font-bold uppercase tracking-wider">{stat.label}</span>
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <button
                              type="button"
                              aria-label={`About ${stat.label}`}
                              className="text-white/40 hover:text-white/80 transition-colors focus:outline-none focus-visible:text-white"
                            >
                              <Info className="w-3 h-3" />
                            </button>
                          </TooltipTrigger>
                          <TooltipContent side="bottom" className="max-w-[240px] text-[11px] leading-snug">
                            {stat.tooltip}
                          </TooltipContent>
                        </Tooltip>
                      </div>
                    </motion.div>
                  ))}
                </TooltipProvider>
              </div>
            </div>
          </div>
        </motion.div>

        {/* ─── Filters (sticky) — matches Schedule & NUDDs pages ─── */}
        <motion.div
          variants={fadeUp}
          className="sticky top-0 z-30 py-3 flex items-center gap-3 bg-background/85 backdrop-blur-md border-b border-border/60 shadow-sm"
        >
          <HomeFilterBar />
        </motion.div>



        {/* ─── Portfolio Table ─── */}
        <motion.div id="portfolio-overview" variants={fadeUp} className="scroll-mt-24 bg-card rounded-2xl border border-border/40 shadow-[var(--card-shadow)] overflow-hidden">
          <div className="px-6 py-4 border-b border-border/30 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <LayoutGrid className="w-5 h-5 text-primary" />
              <h3 className="text-[22px] font-extrabold text-foreground tracking-tight">Portfolio Overview</h3>
            </div>
            <div className="flex items-center gap-4">
              {/* Status legend */}
              <div className="flex items-center gap-4">
                {[
                  { color: "bg-success", label: "On Track" },
                  { color: "bg-warning", label: "At Risk w/ Mitigation" },
                  { color: "bg-destructive", label: "At Risk w/ No Plan" },
                ].map((s) => (
                  <div key={s.label} className="flex items-center gap-1.5">
                    <span className={cn("w-2.5 h-2.5 rounded-full", s.color)} />
                    <span className="text-[10px] text-muted-foreground font-medium">{s.label}</span>
                  </div>
                ))}
              </div>
              {/* Info popover */}
              <div className="relative group">
                <button className="p-1 rounded-full hover:bg-muted transition-colors" aria-label="Status indicator definitions">
                  <Info className="w-3.5 h-3.5 text-muted-foreground/50" />
                </button>
                <div className="absolute right-0 top-full mt-2 w-[340px] bg-card border border-border rounded-xl shadow-xl p-5 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-200 z-50">
                  <h4 className="text-[12px] font-extrabold text-foreground mb-3">Status Indicator Definitions</h4>
                  <div className="space-y-3">
                    {[
                      { color: "bg-success", title: "On Track", desc: "Program is progressing as planned with no schedule risks identified." },
                      { color: "bg-warning", title: "At Risk w/ Mitigation", desc: "Program has identified risks, but a mitigation plan is in place to meet the original Plan of Record (POR)." },
                      { color: "bg-destructive", title: "At Risk w/ No Plan", desc: "Program is at risk with no mitigation plan in place. Immediate action required to define recovery path." },
                    ].map((item) => (
                      <div key={item.title} className="flex items-start gap-2.5">
                        <span className={cn("w-3 h-3 rounded-full mt-0.5 shrink-0", item.color)} />
                        <div>
                          <span className="text-[11px] font-bold text-foreground block">{item.title}</span>
                          <span className="text-[10px] text-muted-foreground leading-relaxed">{item.desc}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
              {statusFilter && (
                <button
                  onClick={() => setStatusFilter(null)}
                  className="text-[10px] text-primary font-bold hover:underline transition-colors"
                >
                  Clear filter
                </button>
              )}
            </div>
          </div>

          {/* ─── Portfolio-wide Status Summary (integrated, dual-track) ─── */}
          <div className="px-6 py-5 border-b border-border/30 bg-muted/[0.02] space-y-5">
            <div className="flex items-center justify-between px-1">
              <span className="text-[10px] text-muted-foreground/70 font-medium">
                Two parallel tracks: GOE / NPI runs the 6-phase Concept→Ramp model; SChM follows Concept→Develop→Launch.
              </span>
              <span className="text-[10px] text-muted-foreground/60 font-medium tabular-nums">
                {activePrograms.length} platform{activePrograms.length === 1 ? "" : "s"}
              </span>
            </div>
            <PortfolioPhaseDistribution
              track="GOE_NPI"
              programsList={activePrograms}
              onPlatformSelect={(name) => {
                setSelectedPlatform(name);
                navigate("/schedule", { state: { selectedProgram: name } });
              }}
            />
            <div className="border-t border-border/30" />
            <PortfolioPhaseDistribution
              track="SCHM"
              programsList={activePrograms}
              onPlatformSelect={(name) => {
                setSelectedPlatform(name);
                navigate("/schedule", { state: { selectedProgram: name } });
              }}
            />
          </div>

        </motion.div>

        {/* LOB Phase Gate Reports section hidden per product decision */}

        {/* ─── OLP Schedule ─── */}
        <motion.div id="olp-schedule" variants={fadeUp} className="scroll-mt-24">
          <PortfolioScheduleGantt />
        </motion.div>

      </motion.div>

      {/* Status update modal */}
      {statusUpdateProgram && (
        <StatusUpdateModal
          open={!!statusUpdateProgram}
          program={statusUpdateProgram}
          onClose={() => setStatusUpdateProgram(null)}
        />
      )}
    </div>
  );
};

export default CurrentHomePage;
