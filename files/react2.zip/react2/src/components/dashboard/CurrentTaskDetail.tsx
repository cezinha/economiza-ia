import { useState } from "react";
import { cn } from "@/lib/utils";
import { CheckCircle2, AlertTriangle, MessageSquare, Plus, X } from "lucide-react";
import DocumentInput from "@/components/dashboard/DocumentInput";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader,
  AlertDialogTitle, AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import type { ScheduleTask } from "@/data/scheduleData";
import { getCompletionSource, completionSourceLabel, getTaskDueOffsetDays, getTaskDueLabel } from "@/data/scheduleData";
import { getTaskParticipants } from "@/data/taskParticipants";
import { useRole } from "@/contexts/RoleContext";
import { Zap } from "lucide-react";

type RiskFlag = {
  id: number;
  type: "risk" | "comment";
  category: string;
  message: string;
};

const CATEGORY_OPTIONS = [
  "Schedule Delay", "Resource Constraint", "Technical Blocker",
  "Dependency Gap", "Cost Impact", "Quality Concern", "Other",
];

interface CurrentTaskDetailProps {
  task: ScheduleTask;
  phaseName: string;
  milestoneName: string;
}

const CurrentTaskDetail = ({ task, phaseName, milestoneName }: CurrentTaskDetailProps) => {
  const { role } = useRole();
  const isReadOnly = role === "Executive";
  const isCompleted = task.status === "completed";
  const completionSource = getCompletionSource(task.name);
  const [currentTaskNote, setCurrentTaskNote] = useState("");
  const [currentTaskFile, setCurrentTaskFile] = useState<File | null>(null);
  const [showConfirm, setShowConfirm] = useState(false);
  const [riskFlags, setRiskFlags] = useState<RiskFlag[]>([]);
  const [showRiskForm, setShowRiskForm] = useState(false);
  const [newRiskType, setNewRiskType] = useState<"risk" | "comment">("comment");
  const [newRiskCategory, setNewRiskCategory] = useState("");
  const [newRiskMessage, setNewRiskMessage] = useState("");

  const addRiskFlag = () => {
    if (!newRiskMessage.trim() || !newRiskCategory) return;
    setRiskFlags((prev) => [
      ...prev,
      { id: Date.now(), type: newRiskType, category: newRiskCategory, message: newRiskMessage.trim() },
    ]);
    setNewRiskMessage("");
    setNewRiskCategory("");
    setNewRiskType("comment");
    setShowRiskForm(false);
  };

  const removeRiskFlag = (id: number) => {
    setRiskFlags((prev) => prev.filter((r) => r.id !== id));
  };

  // Derive due date from RTS (today + 14d, matches RelevantInfoPanel) minus the
  // task's deterministic T-minus offset (7 or 14 days). Keeps date and label in sync.
  const rtsDate = new Date();
  rtsDate.setDate(rtsDate.getDate() + 14);
  const dueOffset = getTaskDueOffsetDays(task.id);
  const dueDate = new Date(rtsDate);
  dueDate.setDate(dueDate.getDate() - dueOffset);
  const dueDateStr = dueDate.toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" });
  const dueLabel = getTaskDueLabel(task.id);

  return (
    <div className="flex flex-col h-full border border-border/60 rounded-lg bg-card overflow-hidden shadow-sm">
      <div className="px-4 py-3 border-b border-border/60 bg-gradient-to-r from-[hsl(var(--mds-blue))]/5 to-transparent">
        <h2 className="text-[10px] font-bold text-foreground uppercase tracking-[0.12em]">Current Task</h2>
      </div>
      <ScrollArea className="flex-1">
        <div className="p-5 space-y-5">
          {/* Header — task title + due card */}
          <div className="flex items-start justify-between gap-3">
            <div className="min-w-0 flex-1">
              <div className="inline-flex items-center gap-1.5 mb-2 px-2 py-0.5 rounded-full bg-[hsl(var(--mds-blue))]/10">
                <CheckCircle2 className="w-3 h-3 text-[hsl(var(--mds-blue))]" />
                <span className="text-[9px] uppercase tracking-[0.1em] text-[hsl(var(--mds-blue))] font-bold">
                  In Progress
                </span>
              </div>
              <h3 className="text-base font-bold text-foreground leading-snug">{task.name}</h3>
            </div>
            <div className="shrink-0 border border-border/60 rounded-lg bg-gradient-to-b from-card to-muted/40 px-3 py-2 text-center shadow-sm min-w-[88px]">
              <span className="text-[9px] uppercase tracking-wider text-muted-foreground font-bold">Due</span>
              <p className="text-[13px] font-bold text-foreground mt-0.5 leading-tight">{dueDateStr}</p>
              <span
                className={cn(
                  "inline-block mt-1.5 text-[9px] font-bold px-2 py-0.5 rounded-full tabular-nums",
                  dueLabel === "T-7"
                    ? "bg-warning/15 text-warning"
                    : "bg-[hsl(var(--mds-blue))]/15 text-[hsl(var(--mds-blue))]"
                )}
                title={`Due ${dueOffset} days before RTS / milestone target`}
              >
                {dueLabel}
              </span>
            </div>
          </div>

          {/* Auto-completion source */}
          {(() => {
            const source = getCompletionSource(task.name);
            if (!source) return null;
            const label = completionSourceLabel[source];
            const isAutoDone = task.status === "completed";
            return (
              <div className={cn(
                "flex items-center gap-2 text-[11px] px-3 py-2 rounded-lg",
                isAutoDone
                  ? "bg-[hsl(var(--mds-blue))]/10 text-[hsl(var(--mds-blue))] border border-[hsl(var(--mds-blue))]/20"
                  : "border border-dashed border-muted-foreground/30 text-muted-foreground bg-muted/20"
              )}>
                <Zap className="w-3.5 h-3.5 shrink-0" />
                <span className="font-medium">
                  {isAutoDone ? `Auto-completed via ${label}` : `Eligible for auto-completion via ${label}`}
                </span>
              </div>
            );
          })()}

          <div className="h-px bg-gradient-to-r from-transparent via-border to-transparent" />

          {/* Comments & Risk Flags */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-1.5">
                <MessageSquare className="w-3.5 h-3.5 text-muted-foreground" />
                <span className="text-[11px] font-bold text-foreground uppercase tracking-wider">Comments & Risk Flags</span>
              </div>
              {!showRiskForm && !isReadOnly && (
                <Button variant="outline" size="sm" className="h-7 text-[11px] gap-1 rounded-full" onClick={() => setShowRiskForm(true)}>
                  <Plus className="w-3 h-3" /> Add
                </Button>
              )}
            </div>

            {showRiskForm && !isReadOnly && (
              <div className="border border-border/60 rounded-lg bg-gradient-to-b from-muted/30 to-muted/10 p-3 space-y-2.5 shadow-sm">
                <div className="flex gap-2">
                  <div className="space-y-1 flex-1">
                    <label className="text-[10px] font-semibold text-muted-foreground uppercase tracking-wider">Type</label>
                    <Select value={newRiskType} onValueChange={(v) => setNewRiskType(v as "risk" | "comment")}>
                      <SelectTrigger className="h-8 text-xs"><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="comment">Comment</SelectItem>
                        <SelectItem value="risk">Risk Flag</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-1 flex-[2]">
                    <label className="text-[10px] font-semibold text-muted-foreground uppercase tracking-wider">Category</label>
                    <Select value={newRiskCategory} onValueChange={setNewRiskCategory}>
                      <SelectTrigger className="h-8 text-xs"><SelectValue placeholder="Select..." /></SelectTrigger>
                      <SelectContent>
                        {CATEGORY_OPTIONS.map((c) => (
                          <SelectItem key={c} value={c}>{c}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <Textarea
                  placeholder="Describe the risk or add a comment..."
                  value={newRiskMessage}
                  onChange={(e) => setNewRiskMessage(e.target.value)}
                  className="min-h-[64px] text-xs resize-none"
                />
                <div className="flex gap-2 justify-end">
                  <Button variant="ghost" size="sm" className="h-7 text-xs" onClick={() => { setShowRiskForm(false); setNewRiskMessage(""); setNewRiskCategory(""); }}>
                    Cancel
                  </Button>
                  <Button size="sm" className="h-7 text-xs" onClick={addRiskFlag} disabled={!newRiskMessage.trim() || !newRiskCategory}>
                    Add {newRiskType === "risk" ? "Risk Flag" : "Comment"}
                  </Button>
                </div>
              </div>
            )}

            {riskFlags.length === 0 && !showRiskForm && (
              <div className="text-center py-4 px-3 rounded-lg border border-dashed border-border/60 bg-muted/10">
                <MessageSquare className="w-4 h-4 text-muted-foreground/50 mx-auto mb-1" />
                <p className="text-[11px] text-muted-foreground">No comments or risk flags added yet.</p>
              </div>
            )}

            {riskFlags.map((flag) => (
              <div
                key={flag.id}
                className={cn(
                  "flex items-start gap-2 border rounded-lg p-2.5 shadow-sm",
                  flag.type === "risk"
                    ? "border-[hsl(var(--mds-danger))]/30 bg-[hsl(var(--mds-danger))]/5"
                    : "border-border/60 bg-muted/20"
                )}
              >
                {flag.type === "risk" ? (
                  <AlertTriangle className="w-3.5 h-3.5 mt-0.5 text-[hsl(var(--mds-danger))] shrink-0" />
                ) : (
                  <MessageSquare className="w-3.5 h-3.5 mt-0.5 text-muted-foreground shrink-0" />
                )}
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-1.5 mb-0.5">
                    <Badge variant={flag.type === "risk" ? "destructive" : "secondary"} className="text-[9px] px-1.5 py-0">
                      {flag.type === "risk" ? "Risk" : "Comment"}
                    </Badge>
                    <span className="text-[10px] text-muted-foreground">{flag.category}</span>
                  </div>
                  <p className="text-[11px] text-foreground leading-relaxed">{flag.message}</p>
                </div>
                {!isReadOnly && (
                  <Button variant="ghost" size="sm" className="h-5 w-5 p-0 shrink-0" onClick={() => removeRiskFlag(flag.id)}>
                    <X className="w-3 h-3" />
                  </Button>
                )}
              </div>
            ))}
          </div>

          {isCompleted && (
            <>
              <div className="h-px bg-gradient-to-r from-transparent via-border to-transparent" />
              <div className="flex items-center gap-2 px-3 py-2.5 rounded-lg bg-gradient-to-r from-[hsl(var(--mds-success))]/10 to-[hsl(var(--mds-success))]/5 border border-[hsl(var(--mds-success))]/30 shadow-sm">
                <CheckCircle2 className="w-4 h-4 text-[hsl(var(--mds-success))] shrink-0" />
                <span className="text-xs font-semibold text-foreground">
                  Task Completed
                  {completionSource && ` · Auto via ${completionSourceLabel[completionSource]}`}
                </span>
              </div>
            </>
          )}

          {!isReadOnly && !isCompleted && (
            <>
              <div className="h-px bg-gradient-to-r from-transparent via-border to-transparent" />

              {/* Notes */}
              <div className="space-y-1.5">
                <label className="text-[11px] font-bold text-foreground uppercase tracking-wider">Submission Notes</label>
                <Textarea
                  placeholder="Add notes about the completed work..."
                  value={currentTaskNote}
                  onChange={(e) => setCurrentTaskNote(e.target.value)}
                  className="min-h-[80px] text-xs resize-none"
                />
              </div>

              {/* Attachment — Dual Input */}
              <div className="space-y-1.5">
                <DocumentInput label="Attachment" />
              </div>

              {/* Complete */}
              <AlertDialog open={showConfirm} onOpenChange={setShowConfirm}>
                <AlertDialogTrigger asChild>
                  <Button className="w-full text-xs h-10 gap-2 shadow-sm bg-[hsl(var(--mds-blue))] hover:bg-[hsl(var(--mds-blue-hover))]" size="sm">
                    <CheckCircle2 className="w-4 h-4" /> Complete Task
                  </Button>
                </AlertDialogTrigger>
                <AlertDialogContent>
                  <AlertDialogHeader>
                    <AlertDialogTitle>Submit Task for Completion</AlertDialogTitle>
                    <AlertDialogDescription>
                      Are you sure you want to submit this task? This action cannot be undone.
                    </AlertDialogDescription>
                  </AlertDialogHeader>
                  <AlertDialogFooter>
                    <AlertDialogCancel>Cancel</AlertDialogCancel>
                    <AlertDialogAction onClick={() => {
                      setCurrentTaskNote("");
                      setCurrentTaskFile(null);
                      setShowConfirm(false);
                    }}>
                      Submit
                    </AlertDialogAction>
                  </AlertDialogFooter>
                </AlertDialogContent>
              </AlertDialog>
            </>
          )}
        </div>
      </ScrollArea>
    </div>
  );
};

export default CurrentTaskDetail;
