import { useState } from "react";
import { User, Settings, ChevronDown, HelpCircle, LogOut, Link2 } from "lucide-react";
import { useLocation, useNavigate } from "react-router-dom";
import dellLogo from "@/assets/dell-logo.png";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tooltip, TooltipContent, TooltipTrigger, TooltipProvider } from "@/components/ui/tooltip";
import NotificationCenter from "@/components/dashboard/NotificationCenter";
import DisplayPreferences from "@/components/dashboard/DisplayPreferences";
import CommandPalette from "@/components/dashboard/CommandPalette";
import ConnectedToolsDialog from "@/components/dashboard/ConnectedToolsDialog";
import { cn } from "@/lib/utils";
import { usePlatform } from "@/contexts/PlatformContext";
import { useRole, SCOPED_ROLES, supportsMultiplePlatforms, type AppRole } from "@/contexts/RoleContext";
import { useUniversalFilters, PLATFORM_LOB, PLATFORM_ORG } from "@/contexts/UniversalFilterContext";

const profileOptions: AppRole[] = [
  "Executive",
  "Super Admin",
  "Admin",
  "User",
];

const useUserInfo = () => {
  const name = localStorage.getItem("userName") || "John Doe";
  const email = localStorage.getItem("userEmail") || "john.doe@dell.com";
  return { name, email };
};

const DashboardHeader = () => {
  const userInfo = useUserInfo();
  const { role, assignedPlatforms, setRoleAndPlatforms } = useRole();
  const { setSelectedPlatform, programs } = usePlatform();
  const { updateFilter } = useUniversalFilters();

  const [pendingRole, setPendingRole] = useState<AppRole | null>(null);
  const [pendingPlatforms, setPendingPlatforms] = useState<string[]>([]);
  const [confirmOpen, setConfirmOpen] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [toolsOpen, setToolsOpen] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();

  const isScopedPending = pendingRole !== null && SCOPED_ROLES.includes(pendingRole);
  const allowsMultiPending = supportsMultiplePlatforms(pendingRole);

  const handleRoleClick = (nextRole: AppRole) => {
    if (nextRole === role) return;
    setPendingRole(nextRole);
    const seed = assignedPlatforms.length > 0 ? assignedPlatforms : [programs[0]];
    setPendingPlatforms(supportsMultiplePlatforms(nextRole) ? seed : [seed[0]]);
    setConfirmOpen(true);
  };

  const togglePendingPlatform = (platform: string, checked: boolean) => {
    setPendingPlatforms((prev) => {
      if (checked) return Array.from(new Set([...prev, platform]));
      return prev.filter((p) => p !== platform);
    });
  };

  const applyRole = (persist: boolean) => {
    if (!pendingRole) return;
    const platforms = SCOPED_ROLES.includes(pendingRole) ? pendingPlatforms : [];
    setRoleAndPlatforms(pendingRole, platforms, persist);

    const primary = platforms[0];
    if (primary) {
      setSelectedPlatform(platforms.length === 1 ? primary : null);
      const org = PLATFORM_ORG[primary];
      const lob = PLATFORM_LOB[primary];
      if (org) updateFilter("organization", org);
      if (lob) updateFilter("lob", lob);
      updateFilter("platform", platforms.length === 1 ? primary : "all");
    }
    setPendingRole(null);
    setConfirmOpen(false);
  };

  const handleSaveRole = () => applyRole(true);
  const handleDiscardRole = () => applyRole(false);

  const canSubmit = pendingRole !== null && (!isScopedPending || pendingPlatforms.length > 0);

  return (
    <>
      <header className="h-[60px] bg-card flex items-center justify-between pr-6 sticky top-0 z-50 border-b border-border/50 shadow-[0_1px_3px_rgba(0,0,0,0.04)]">
        <div className="flex items-center min-w-0">
          <div className="w-[220px] flex items-center justify-center shrink-0">
            <img src={dellLogo} alt="Dell Technologies" className="h-[22px]" />
          </div>
          <div className="w-px h-5 bg-border/40 shrink-0" />
          <span className="text-foreground font-bold text-[13px] tracking-tight shrink-0 ml-4">
            OLP Launch Orchestrator
          </span>
        </div>

        {/* Center: Search */}
        <CommandPalette />

        {/* Right: Actions */}
        <div className="flex items-center gap-1.5">
          {/* Connected Tools */}
          <TooltipProvider delayDuration={200}>
            <Tooltip>
              <TooltipTrigger asChild>
                <button
                  className="flex items-center text-muted-foreground hover:text-foreground transition-colors p-2 rounded-lg hover:bg-muted/50 press-scale"
                  aria-label="Connected Tools"
                  onClick={() => setToolsOpen(true)}
                >
                  <Link2 className="w-4 h-4" />
                </button>
              </TooltipTrigger>
              <TooltipContent side="bottom" className="text-[11px]">Connected Tools</TooltipContent>
            </Tooltip>
          </TooltipProvider>

          {/* Help */}
          <TooltipProvider delayDuration={200}>
            <Tooltip>
              <TooltipTrigger asChild>
                <button
                  className="flex items-center text-muted-foreground hover:text-foreground transition-colors p-2 rounded-lg hover:bg-muted/50 press-scale"
                  aria-label="Help & Support"
                  onClick={() => {
                    window.dispatchEvent(new CustomEvent("open-ai-chatbot"));
                  }}
                >
                  <HelpCircle className="w-4 h-4" />
                </button>
              </TooltipTrigger>
              <TooltipContent side="bottom" className="text-[11px]">Help & Support</TooltipContent>
            </Tooltip>
          </TooltipProvider>

          <NotificationCenter />

          <div className="w-px h-4 bg-border/30 mx-1" />

          {/* Profile dropdown */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <button className="flex items-center gap-2 text-muted-foreground hover:text-foreground transition-all text-[11px] font-semibold px-2.5 py-1.5 rounded-lg hover:bg-muted/50 press-scale" aria-label="Profile menu">
                <div className="w-7 h-7 rounded-full bg-gradient-to-br from-primary/20 to-primary/5 flex items-center justify-center ring-1 ring-primary/15">
                  <User className="w-3.5 h-3.5 text-primary" />
                </div>
                <span className="hidden sm:inline">{role ?? "Profile"}</span>
                {role && role !== "User" && role !== "Admin" && assignedPlatforms.length > 0 && (
                  <span className="hidden sm:inline text-[9px] font-bold text-primary bg-primary/10 px-1.5 py-0.5 rounded-md">
                    {assignedPlatforms.length > 1
                      ? `${assignedPlatforms.length} platforms`
                      : assignedPlatforms[0]}
                  </span>
                )}
                <ChevronDown className="w-3 h-3 text-muted-foreground/40" />
              </button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-56 rounded-xl">
              {/* User info section */}
              <div className="px-3 py-2.5">
                <p className="text-[12px] font-bold text-foreground">{userInfo.name}</p>
                <p className="text-[11px] text-muted-foreground mt-0.5">{userInfo.email}</p>
                {role && (
                  <span className="inline-flex items-center mt-1.5 text-[9px] font-bold text-primary bg-primary/10 px-2 py-0.5 rounded-md">
                    {role}
                  </span>
                )}
                {assignedPlatforms.length > 0 && (
                  <div className="mt-2 space-y-1">
                    <p className="text-[9px] font-bold uppercase tracking-wider text-muted-foreground/60">In-Scope</p>
                    <div className="space-y-1 rounded-md bg-muted/30 px-2 py-1.5">
                      <div className="flex items-center justify-between gap-2">
                        <span className="text-[9px] uppercase tracking-wide text-muted-foreground/70">Org</span>
                        <span className="text-[10px] font-bold text-foreground">{PLATFORM_ORG[assignedPlatforms[0]] ?? "—"}</span>
                      </div>
                      <div className="flex items-center justify-between gap-2">
                        <span className="text-[9px] uppercase tracking-wide text-muted-foreground/70">LOB</span>
                        <span className="text-[10px] font-bold text-foreground">{PLATFORM_LOB[assignedPlatforms[0]] ?? "—"}</span>
                      </div>
                      <div className="flex items-start justify-between gap-2">
                        <span className="text-[9px] uppercase tracking-wide text-muted-foreground/70 mt-0.5">Platforms</span>
                        <div className="flex flex-wrap gap-1 justify-end">
                          {assignedPlatforms.map((p) => (
                            <span
                              key={p}
                              className="inline-flex items-center text-[9px] font-bold text-primary bg-primary/10 px-1.5 py-0.5 rounded"
                            >
                              {p}
                            </span>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </div>
              <DropdownMenuSeparator />
              <div className="px-3 py-2">
                <p className="text-[10px] font-bold text-muted-foreground/50 uppercase tracking-wider">Switch Role</p>
              </div>
              <DropdownMenuSeparator />
              {profileOptions.map((option) => (
                <DropdownMenuItem
                  key={option}
                  className={cn(
                    "text-[11px] cursor-pointer font-semibold rounded-lg mx-1 px-3",
                    role === option && "bg-primary/10 text-primary"
                  )}
                  onClick={() => handleRoleClick(option)}
                >
                  {option}
                </DropdownMenuItem>
              ))}
              <DropdownMenuSeparator />
              <DropdownMenuItem
                className="text-[11px] cursor-pointer font-medium rounded-lg mx-1 px-3 gap-2 text-destructive"
                onClick={() => navigate("/login")}
              >
                <LogOut className="w-3.5 h-3.5" />
                Log Out
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>

          <button
            onClick={() => setSettingsOpen(true)}
            className="flex items-center gap-1.5 text-muted-foreground hover:text-foreground transition-all text-[11px] font-semibold px-2.5 py-1.5 rounded-lg hover:bg-muted/50 press-scale"
            aria-label="Settings"
          >
            <Settings className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Settings</span>
          </button>
        </div>
      </header>

      <DisplayPreferences open={settingsOpen} onClose={() => setSettingsOpen(false)} />
      <ConnectedToolsDialog open={toolsOpen} onClose={() => setToolsOpen(false)} />

      {/* Save role confirmation dialog */}
      <Dialog open={confirmOpen} onOpenChange={setConfirmOpen}>
        <DialogContent className="sm:max-w-[400px]">
          <DialogHeader>
            <DialogTitle className="text-[14px]">
              {isScopedPending ? "Assign platforms" : "Save changes?"}
            </DialogTitle>
            <DialogDescription className="text-[12px]">
              {isScopedPending ? (
                <>
                  Switch role to <span className="font-semibold text-foreground">{pendingRole}</span>.{" "}
                  {allowsMultiPending
                    ? "Pick one or more platforms this account is assigned to."
                    : "Pick which platform this account is assigned to."}
                </>
              ) : (
                <>
                  Switch role to <span className="font-semibold text-foreground">{pendingRole}</span>.
                  Save to remember this role for next login?
                </>
              )}
            </DialogDescription>
          </DialogHeader>

          {isScopedPending && (
            <div className="space-y-2 py-2">
              <Label className="text-[11px] font-bold uppercase tracking-wide text-muted-foreground">
                {allowsMultiPending ? "Assigned Platforms" : "Assigned Platform"}
              </Label>

              {allowsMultiPending ? (
                <div className="rounded-lg border border-border/50 divide-y divide-border/40 max-h-[260px] overflow-auto">
                  {programs.map((p) => {
                    const checked = pendingPlatforms.includes(p);
                    return (
                      <label
                        key={p}
                        className="flex items-center gap-2.5 px-3 py-2 cursor-pointer hover:bg-muted/40 transition-colors"
                      >
                        <Checkbox
                          checked={checked}
                          onCheckedChange={(v) => togglePendingPlatform(p, v === true)}
                        />
                        <span className="text-[12px] font-medium text-foreground">{p}</span>
                      </label>
                    );
                  })}
                </div>
              ) : (
                <Select
                  value={pendingPlatforms[0] ?? ""}
                  onValueChange={(v) => setPendingPlatforms([v])}
                >
                  <SelectTrigger className="h-10 rounded-lg">
                    <SelectValue placeholder="Select platform" />
                  </SelectTrigger>
                  <SelectContent>
                    {programs.map((p) => (
                      <SelectItem key={p} value={p}>{p}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              )}

              <p className="text-[10px] text-muted-foreground/70 leading-relaxed">
                {allowsMultiPending
                  ? `The dashboard will scope to your ${pendingPlatforms.length || "selected"} platform${pendingPlatforms.length === 1 ? "" : "s"}. You can still switch the platform filter manually.`
                  : "The dashboard will default to this platform across all views. You can still switch the platform filter manually."}
              </p>
            </div>
          )}

          <DialogFooter className="gap-2 sm:gap-0">
            <Button variant="outline" size="sm" onClick={handleDiscardRole} disabled={!canSubmit}>
              Don't Save
            </Button>
            <Button size="sm" onClick={handleSaveRole} disabled={!canSubmit}>
              Save
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
};

export default DashboardHeader;
