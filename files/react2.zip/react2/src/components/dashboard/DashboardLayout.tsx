import { Outlet } from "react-router-dom";
import DashboardHeader from "@/components/dashboard/DashboardHeader";
import DashboardSidebar from "@/components/dashboard/DashboardSidebar";
import AIChatbot from "@/components/dashboard/AIChatbot";
import { ReportReturnBanner } from "@/hooks/use-report-return";

const DashboardLayout = () => {
  return (
    <div className="h-screen flex flex-col bg-background overflow-hidden">
      <DashboardHeader />
      <div className="flex flex-1 overflow-hidden">
        <DashboardSidebar />
        <main className="flex-1 flex flex-col overflow-auto">
          <ReportReturnBanner />
          <Outlet />
        </main>
      </div>
      <AIChatbot />
    </div>
  );
};

export default DashboardLayout;
