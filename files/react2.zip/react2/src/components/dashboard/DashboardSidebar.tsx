import { Home, AlertTriangle, FlaskConical, Hammer, ChevronDown, LayoutDashboard, FolderOpen, ClipboardCheck, Archive, GitBranch, Factory, ShieldCheck, Truck, ClipboardList, FileArchive, LayoutGrid, GanttChart, PanelLeftClose, PanelLeft, FileBarChart, Bug, Calendar, CheckSquare } from "lucide-react";
import { NavLink, useLocation, useNavigate } from "react-router-dom";
import { useState, useEffect } from "react";
import { cn } from "@/lib/utils";
import { motion, AnimatePresence } from "framer-motion";
import { usePlatform } from "@/contexts/PlatformContext";
import { useRole } from "@/contexts/RoleContext";

const currentNavItems: { icon: typeof Home; label: string; path: string }[] = [
  { icon: Home, label: "Home", path: "/" },
];

const DashboardSidebar = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { selectedPlatform, setSelectedPlatform, programs } = usePlatform();
  const { role } = useRole();
  const canSeePhaseGateReports = false; // hidden from home page and sidebar per product decision
  const [filterOpen, setFilterOpen] = useState(false);
  const [isHovered, setIsHovered] = useState(false);
  const [isPinned, setIsPinned] = useState(true);
  const [isExpanded, setIsExpanded] = useState(false);
  const [homeSubOpen, setHomeSubOpen] = useState(true);
  const [workstreamOpen, setWorkstreamOpen] = useState(false);
  const [forceCollapse, setForceCollapse] = useState(false);

  const subNavItems = currentNavItems;
  const isSubNavActive = subNavItems.some(item => location.pathname === item.path);

  useEffect(() => {
    const handler = (e: Event) => {
      const collapse = (e as CustomEvent).detail;
      setForceCollapse(collapse);
    };
    window.addEventListener("sidebar-collapse", handler);
    return () => window.removeEventListener("sidebar-collapse", handler);
  }, []);

  useEffect(() => {
    const state = location.state as { selectedProgram?: string } | null;
    if (state?.selectedProgram && (programs as readonly string[]).includes(state.selectedProgram)) {
      setSelectedPlatform(state.selectedProgram);
      window.history.replaceState({}, "");
    }
  }, [location.state, programs, setSelectedPlatform]);

  const showExpanded = !forceCollapse && (isPinned || isHovered || isExpanded || isSubNavActive);

  const filterLabel = selectedPlatform ?? "Portfolio";
  const filterOptions = ["Portfolio", ...programs];

  return (
    <aside
      className={cn(
        "bg-card border-r border-border/40 flex flex-col shrink-0 transition-all duration-300 ease-[cubic-bezier(0.25,0.1,0.25,1)] relative",
        showExpanded ? "w-[220px]" : "w-[52px]"
      )}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      {/* Pin / Collapse toggle */}
      {showExpanded && (
        <div className="px-2 pb-1 flex justify-end">
          <button
            onClick={() => setIsPinned(!isPinned)}
            className={cn(
              "p-1.5 rounded-lg transition-all duration-200",
              isPinned
                ? "bg-primary/10 text-primary"
                : "text-muted-foreground hover:bg-muted/50 hover:text-foreground"
            )}
            title={isPinned ? "Unpin sidebar" : "Pin sidebar open"}
            aria-label={isPinned ? "Unpin sidebar" : "Pin sidebar open"}
          >
            {isPinned ? <PanelLeftClose className="w-3.5 h-3.5" /> : <PanelLeft className="w-3.5 h-3.5" />}
          </button>
        </div>
      )}
      {!showExpanded && (
        <div className="flex justify-center py-1">
          <button
            onClick={() => setIsPinned(true)}
            className="p-1.5 rounded-lg text-muted-foreground hover:bg-muted/50 hover:text-foreground transition-all duration-200"
            title="Expand sidebar"
            aria-label="Expand sidebar"
          >
            <PanelLeft className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      <nav className="flex-1 px-2 pt-1 space-y-0.5 overflow-y-auto overflow-x-hidden">
        {/* Home with collapsible sub-tabs */}
        <div>
          <div className="flex items-center">
            <NavLink
              to="/"
              end
              className={({ isActive }) =>
                cn(
                  "flex-1 flex items-center gap-2.5 px-2.5 py-2 rounded-xl text-[12px] font-semibold transition-all duration-200 relative press-scale",
                  isActive
                    ? "bg-primary text-primary-foreground shadow-sm shadow-primary/20"
                    : "text-foreground/60 hover:bg-muted/60 hover:text-foreground"
                )
              }
              title="Home"
            >
              <Home className="w-4 h-4 shrink-0" />
              {showExpanded && <span className="whitespace-nowrap">Home</span>}
            </NavLink>
            {showExpanded && (
              <button
                onClick={() => setHomeSubOpen(!homeSubOpen)}
                className="p-1 rounded-md hover:bg-muted/50 transition-colors text-muted-foreground"
                aria-label="Toggle sub-tabs"
              >
                <ChevronDown className={cn("w-3.5 h-3.5 transition-transform duration-200", homeSubOpen && "rotate-180")} />
              </button>
            )}
          </div>

          {/* Sub-tabs */}
          <AnimatePresence>
            {(showExpanded ? homeSubOpen : true) && (
              <motion.div
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: "auto", opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  transition={{ duration: 0.2 }}
                  className="overflow-hidden"
                >
                  {showExpanded ? (
                    <div className="mt-0.5 ml-3 space-y-0.5">
                      <button
                        onClick={() => {
                          if (location.pathname !== "/") {
                            navigate("/", { state: { scrollTo: "portfolio-overview" } });
                          } else {
                            document.getElementById("portfolio-overview")?.scrollIntoView({ behavior: "smooth", block: "start" });
                          }
                        }}
                        className="w-full flex items-center gap-2.5 px-2.5 py-[7px] rounded-lg text-[11px] font-medium transition-all duration-200 text-muted-foreground hover:bg-muted/40 hover:text-foreground press-scale"
                        title="Overview"
                      >
                        <LayoutGrid className="w-3.5 h-3.5 shrink-0" />
                        <span className="truncate">Overview</span>
                      </button>
                      <button
                        onClick={() => {
                          if (location.pathname !== "/") {
                            navigate("/", { state: { scrollTo: "olp-schedule" } });
                          } else {
                            document.getElementById("olp-schedule")?.scrollIntoView({ behavior: "smooth", block: "start" });
                          }
                        }}
                        className="w-full flex items-center gap-2.5 px-2.5 py-[7px] rounded-lg text-[11px] font-medium transition-all duration-200 text-muted-foreground hover:bg-muted/40 hover:text-foreground press-scale"
                        title="Portfolio Schedule"
                      >
                        <Calendar className="w-3.5 h-3.5 shrink-0" />
                        <span className="truncate">Portfolio Schedule</span>
                      </button>
                      {canSeePhaseGateReports && (
                        <NavLink
                          to="/phase-gate"
                          className={({ isActive }) =>
                            cn(
                              "w-full flex items-center gap-2.5 px-2.5 py-[7px] rounded-lg text-[11px] font-medium transition-all duration-200 press-scale",
                              isActive
                                ? "bg-primary/10 text-primary"
                                : "text-muted-foreground hover:bg-muted/40 hover:text-foreground"
                            )
                          }
                          title="Phase Gate Reports"
                        >
                          <FileBarChart className="w-3.5 h-3.5 shrink-0" />
                          <span className="truncate">Phase Gate Reports</span>
                        </NavLink>
                      )}
                    </div>
                  ) : (
                    <div className="mt-0.5 flex flex-col items-center">
                      <button
                        onClick={() => {
                          if (location.pathname !== "/") {
                            navigate("/", { state: { scrollTo: "portfolio-overview" } });
                          } else {
                            document.getElementById("portfolio-overview")?.scrollIntoView({ behavior: "smooth", block: "start" });
                          }
                        }}
                        className="flex items-center justify-center w-9 h-9 rounded-xl transition-all duration-200 text-muted-foreground hover:bg-muted/40 hover:text-foreground"
                        title="Overview"
                      >
                        <LayoutGrid className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => {
                          if (location.pathname !== "/") {
                            navigate("/", { state: { scrollTo: "olp-schedule" } });
                          } else {
                            document.getElementById("olp-schedule")?.scrollIntoView({ behavior: "smooth", block: "start" });
                          }
                        }}
                        className="flex items-center justify-center w-9 h-9 rounded-xl transition-all duration-200 text-muted-foreground hover:bg-muted/40 hover:text-foreground"
                        title="Portfolio Schedule"
                      >
                        <Calendar className="w-3.5 h-3.5" />
                      </button>
                      {canSeePhaseGateReports && (
                        <NavLink
                          to="/phase-gate"
                          className={({ isActive }) =>
                            cn(
                              "flex items-center justify-center w-9 h-9 rounded-xl transition-all duration-200",
                              isActive
                                ? "bg-primary/10 text-primary"
                                : "text-muted-foreground hover:bg-muted/40 hover:text-foreground"
                            )
                          }
                          title="Phase Gate Reports"
                        >
                          <FileBarChart className="w-3.5 h-3.5" />
                        </NavLink>
                      )}
                    </div>
                  )}
                </motion.div>
              )}
            </AnimatePresence>
        </div>

        {/* Tasks tab — same view as platform-level portfolio schedule */}
        <NavLink
          to="/schedule"
          className={({ isActive }) =>
            cn(
              "w-full flex items-center gap-2.5 px-2.5 py-2 rounded-xl text-[12px] font-semibold transition-all duration-200 mt-2 press-scale",
              isActive
                ? "bg-primary text-primary-foreground shadow-sm shadow-primary/20"
                : "text-foreground/60 hover:bg-muted/60 hover:text-foreground"
            )
          }
          title="My Tasks"
        >
          <CheckSquare className="w-4 h-4 shrink-0" />
          {showExpanded && <span className="whitespace-nowrap">My Tasks</span>}
        </NavLink>

        {/* Workstream tabs */}
        {[
          { path: "/doc-curator", label: "Doc & Data Curator", icon: FolderOpen, dimmed: false },
          { path: "/nudds", label: "NUDDs", icon: AlertTriangle, dimmed: false },
          { path: "/design-issues", label: "Design Issues", icon: Bug, dimmed: true },
          { path: "/golden-configs", label: "Golden Configs", icon: ClipboardList, dimmed: true },
          { path: "/build-execution", label: "Build Execution", icon: Hammer, dimmed: true },
          { path: "/archive", label: "Archive", icon: Archive, dimmed: true },
        ].map((item) => {
          const ItemIcon = item.icon;
          return (
            <NavLink
              key={item.path}
              to={item.path}
              className={({ isActive }) =>
                cn(
                  "w-full flex items-center gap-2.5 px-2.5 py-2 rounded-xl text-[12px] font-semibold transition-all duration-200 mt-1 press-scale",
                  isActive
                    ? "bg-primary text-primary-foreground shadow-sm shadow-primary/20"
                    : item.dimmed
                      ? "text-foreground/30 hover:bg-muted/40 hover:text-foreground/50"
                      : "text-foreground/60 hover:bg-muted/60 hover:text-foreground"
                )
              }
              title={item.label}
            >
              <ItemIcon className="w-4 h-4 shrink-0" />
              {showExpanded && <span className="whitespace-nowrap truncate">{item.label}</span>}
            </NavLink>
          );
        })}

        {/* My Tasks tab — hidden, may be re-enabled later */}

        {showExpanded && (
          <div className="mt-4 px-3">
            <p className="text-[10px] text-muted-foreground/60 leading-relaxed">
              New pages will appear here as they are built.
            </p>
          </div>
        )}
      </nav>

    </aside>
  );
};

export default DashboardSidebar;
