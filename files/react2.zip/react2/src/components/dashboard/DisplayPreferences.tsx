import { useState } from "react";
import { Sun, Moon, Monitor, X, LayoutDashboard, Globe } from "lucide-react";
import { useTheme } from "@/hooks/use-theme";
import { useTimezone, TIMEZONE_LIST, getGMTOffset } from "@/hooks/use-timezone";
import { cn } from "@/lib/utils";
import { motion, AnimatePresence } from "framer-motion";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";

interface DisplayPreferencesProps {
  open: boolean;
  onClose: () => void;
}

const themes = [
  { value: "light" as const, label: "Light", icon: Sun, description: "Clean, bright interface" },
  { value: "dark" as const, label: "Dark", icon: Moon, description: "Easier on the eyes" },
  { value: "system" as const, label: "System", icon: Monitor, description: "Match your device" },
];

const landingPages = [
  { value: "/", label: "Home" },
  { value: "/platform-summary", label: "Platform Summary" },
  { value: "/schedule", label: "OLP Schedule" },
  { value: "/current-task", label: "Current Task" },
];

const DisplayPreferences = ({ open, onClose }: DisplayPreferencesProps) => {
  const { theme, setTheme } = useTheme();
  const { timezone, setTimezone } = useTimezone();
  const [defaultPage, setDefaultPage] = useState("/");
  const [pendingTz, setPendingTz] = useState<string | null>(null);
  const [tzConfirmOpen, setTzConfirmOpen] = useState(false);

  if (!open) return null;

  const handleTzChange = (newTz: string) => {
    if (newTz === timezone) return;
    if (newTz === "system") {
      // Switching back to system — no confirmation needed
      setTimezone("system");
      return;
    }
    setPendingTz(newTz);
    setTzConfirmOpen(true);
  };

  const handleTzSave = () => {
    if (pendingTz) setTimezone(pendingTz);
    setPendingTz(null);
    setTzConfirmOpen(false);
  };

  const handleTzDiscard = () => {
    setPendingTz(null);
    setTzConfirmOpen(false);
  };

  const pendingLabel = pendingTz
    ? TIMEZONE_LIST.find((t) => t.value === pendingTz)?.label || pendingTz
    : "";
  const pendingOffset = pendingTz ? getGMTOffset(pendingTz) : "";

  return (
    <>
      <AnimatePresence>
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-foreground/20 backdrop-blur-sm z-50 flex items-center justify-center"
          onClick={onClose}
        >
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 8 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 8 }}
            transition={{ duration: 0.2, ease: [0.25, 0.1, 0.25, 1] }}
            className="bg-card border border-border rounded-xl shadow-xl w-full max-w-md mx-4 overflow-hidden max-h-[90vh] flex flex-col"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between px-6 py-4 border-b border-border">
              <h2 className="text-sm font-semibold text-foreground">Settings</h2>
              <button
                onClick={onClose}
                className="p-1.5 rounded-lg hover:bg-muted transition-colors"
                aria-label="Close"
              >
                <X className="w-4 h-4 text-muted-foreground" />
              </button>
            </div>

            <div className="p-6 space-y-6 overflow-y-auto">
              {/* Theme */}
              <div>
                <p className="text-[11px] font-bold text-muted-foreground/50 uppercase tracking-wider mb-3">Appearance</p>
                <div className="grid grid-cols-3 gap-3">
                  {themes.map(({ value, label, icon: Icon, description }) => (
                    <button
                      key={value}
                      onClick={() => setTheme(value)}
                      className={cn(
                        "flex flex-col items-center gap-2 p-3 rounded-lg border-2 transition-all duration-200",
                        theme === value
                          ? "border-primary bg-primary/5 shadow-sm"
                          : "border-border hover:border-muted-foreground/30 hover:bg-muted/30"
                      )}
                    >
                      <div className={cn(
                        "w-9 h-9 rounded-full flex items-center justify-center transition-colors",
                        theme === value ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground"
                      )}>
                        <Icon className="w-4 h-4" />
                      </div>
                      <div className="text-center">
                        <span className="text-[11px] font-semibold text-foreground block">{label}</span>
                        <span className="text-[9px] text-muted-foreground mt-0.5 block">{description}</span>
                      </div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Time Zone */}
              <div>
                <p className="text-[11px] font-bold text-muted-foreground/50 uppercase tracking-wider mb-3 flex items-center gap-1.5">
                  <Globe className="w-3.5 h-3.5" />
                  Time Zone
                </p>
                <select
                  value={timezone}
                  onChange={(e) => handleTzChange(e.target.value)}
                  className="w-full rounded-lg border border-border bg-background px-3 py-2 text-[12px] font-medium text-foreground focus:outline-none focus:ring-2 focus:ring-primary/30 transition-colors"
                >
                  <option value="system">System (default)</option>
                  <option disabled>──────────────────</option>
                  {TIMEZONE_LIST.map((tz) => (
                    <option key={tz.value} value={tz.value}>{tz.label}</option>
                  ))}
                </select>
              </div>

              {/* Default Landing Page */}
              <div>
                <p className="text-[11px] font-bold text-muted-foreground/50 uppercase tracking-wider mb-3 flex items-center gap-1.5">
                  <LayoutDashboard className="w-3.5 h-3.5" />
                  Default Landing Page
                </p>
                <select
                  value={defaultPage}
                  onChange={(e) => setDefaultPage(e.target.value)}
                  className="w-full rounded-lg border border-border bg-background px-3 py-2 text-[12px] font-medium text-foreground focus:outline-none focus:ring-2 focus:ring-primary/30 transition-colors"
                >
                  {landingPages.map((page) => (
                    <option key={page.value} value={page.value}>{page.label}</option>
                  ))}
                </select>
              </div>
            </div>
          </motion.div>
        </motion.div>
      </AnimatePresence>

      {/* Timezone save confirmation */}
      <Dialog open={tzConfirmOpen} onOpenChange={setTzConfirmOpen}>
        <DialogContent className="sm:max-w-[380px]">
          <DialogHeader>
            <DialogTitle className="text-[14px]">Save changes?</DialogTitle>
            <DialogDescription className="text-[12px]">
              Your new time zone will be <span className="font-semibold text-foreground">{pendingLabel}</span>
              {pendingOffset && <> (<span className="font-semibold text-foreground">{pendingOffset}</span>)</>}.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="gap-2 sm:gap-0">
            <Button variant="outline" size="sm" onClick={handleTzDiscard}>
              Cancel
            </Button>
            <Button size="sm" onClick={handleTzSave}>
              Save
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
};

export default DisplayPreferences;
