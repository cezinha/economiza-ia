import { useState } from "react";
import { Link2, Upload, FileText, X } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

type InputMode = "link" | "upload";

interface DocumentInputProps {
  label?: string;
  className?: string;
}

const DocumentInput = ({ label = "Attachment", className }: DocumentInputProps) => {
  const [mode, setMode] = useState<InputMode>("link");
  const [linkValue, setLinkValue] = useState("");
  const [file, setFile] = useState<File | null>(null);

  const hasValue = mode === "link" ? linkValue.trim().length > 0 : file !== null;

  return (
    <div className={cn("space-y-1.5", className)}>
      <label className="text-xs font-medium text-foreground">{label}</label>

      {/* Toggle tabs */}
      <div className="flex items-center rounded-md border border-border bg-muted/30 p-0.5 w-fit">
        <button
          onClick={() => setMode("link")}
          className={cn(
            "flex items-center gap-1 px-2.5 py-1 text-[10px] font-medium rounded transition-colors",
            mode === "link"
              ? "bg-primary text-primary-foreground shadow-sm"
              : "text-muted-foreground hover:text-foreground"
          )}
        >
          <Link2 className="w-3 h-3" />
          Link from repository
        </button>
        <button
          onClick={() => setMode("upload")}
          className={cn(
            "flex items-center gap-1 px-2.5 py-1 text-[10px] font-medium rounded transition-colors",
            mode === "upload"
              ? "bg-primary text-primary-foreground shadow-sm"
              : "text-muted-foreground hover:text-foreground"
          )}
        >
          <Upload className="w-3 h-3" />
          Upload file
        </button>
      </div>

      {/* Input area */}
      {mode === "link" ? (
        <div className="flex items-center gap-2">
          <Input
            type="url"
            placeholder="Paste document URL..."
            value={linkValue}
            onChange={(e) => setLinkValue(e.target.value)}
            className="h-8 text-xs flex-1"
          />
          {linkValue && (
            <Button variant="ghost" size="sm" className="h-7 text-xs px-2" onClick={() => setLinkValue("")}>
              <X className="w-3 h-3" />
            </Button>
          )}
        </div>
      ) : (
        <div className="flex items-center gap-2">
          <label className="flex items-center gap-1.5 px-3 py-1.5 border border-input rounded-md bg-background text-xs cursor-pointer hover:bg-accent transition-colors">
            <Upload className="w-3.5 h-3.5" />
            <span>{file ? file.name : "Choose file..."}</span>
            <input type="file" className="hidden" onChange={(e) => setFile(e.target.files?.[0] || null)} />
          </label>
          {file && (
            <Button variant="ghost" size="sm" className="h-7 text-xs" onClick={() => setFile(null)}>
              Remove
            </Button>
          )}
        </div>
      )}

      {/* Show saved value indicator */}
      {hasValue && (
        <div className="flex items-center gap-1.5 text-[10px] text-[hsl(var(--mds-success))]">
          {mode === "link" ? <Link2 className="w-3 h-3" /> : <FileText className="w-3 h-3" />}
          <span>{mode === "link" ? "Repository link attached" : "File attached"}</span>
        </div>
      )}
    </div>
  );
};

export default DocumentInput;
