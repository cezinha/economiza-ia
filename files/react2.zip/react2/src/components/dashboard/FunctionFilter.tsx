import { cn } from "@/lib/utils";
import type { ScheduleTask } from "@/data/scheduleData";
import { isAutoCompletedTask } from "@/data/taskParticipants";
import { getTaskTrack } from "@/data/phaseTracks";

// Dual-track ownership: GOE & NPI share the 6-phase timeline, SChM follows
// the 5-phase Concept→Define→Plan→Develop→Launch model.
const FUNCTIONS = ["All", "GOE", "NPI", "SChM", "Auto"] as const;
export type FunctionFilterValue = (typeof FUNCTIONS)[number];

interface FunctionFilterProps {
  /** Multi-select; empty array OR ["All"] means no filter. */
  value: FunctionFilterValue[];
  onChange: (v: FunctionFilterValue[]) => void;
  className?: string;
}

const FunctionFilter = ({ value, onChange, className }: FunctionFilterProps) => {
  const isAllActive = value.length === 0 || value.includes("All");

  const toggle = (fn: FunctionFilterValue) => {
    if (fn === "All") {
      onChange(["All"]);
      return;
    }
    const without = value.filter((v) => v !== "All");
    if (without.includes(fn)) {
      const next = without.filter((v) => v !== fn);
      onChange(next.length === 0 ? ["All"] : next);
    } else {
      onChange([...without, fn]);
    }
  };

  return (
    <div className={cn("flex items-center rounded-md border border-border bg-muted/30 p-0.5", className)}>
      {FUNCTIONS.map((fn) => {
        const active = fn === "All" ? isAllActive : value.includes(fn);
        return (
          <button
            key={fn}
            onClick={() => toggle(fn)}
            className={cn(
              "px-2.5 py-1 text-[10px] font-medium rounded transition-colors",
              active
                ? "bg-primary text-primary-foreground shadow-sm"
                : "text-muted-foreground hover:text-foreground"
            )}
            aria-pressed={active}
          >
            {fn}
          </button>
        );
      })}
    </div>
  );
};

/**
 * Returns true if a task passes the active Function multi-filter.
 * - "All" or empty → always true
 * - "Auto" → task is auto-completable
 * - Other tags → matches the task's owner string (function tag)
 */
export const taskMatchesFunction = (
  task: Pick<ScheduleTask, "owner" | "name">,
  active: FunctionFilterValue[]
): boolean => {
  if (active.length === 0 || active.includes("All")) return true;
  return active.some((fn) => {
    if (fn === "Auto") return isAutoCompletedTask(task);
    if (fn === "SChM") return getTaskTrack(task as ScheduleTask) === "SCHM";
    // GOE / NPI both live on the GOE/NPI track. Owner string is "GOE" for
    // every seeded task; differentiate GOE vs NPI by task-name keywords so
    // both filters return non-empty buckets.
    const isGoeNpiTrack = getTaskTrack(task as ScheduleTask) === "GOE_NPI";
    if (!isGoeNpiTrack) return false;
    const n = task.name.toLowerCase();
    const isNpi = /(pilot|ramp|build|qual|launch|ready to ship|ready to order|production|pvt|dvt|evt)/.test(
      n,
    );
    if (fn === "NPI") return isNpi;
    if (fn === "GOE") return !isNpi;
    return task.owner.includes(fn);
  });
};

export default FunctionFilter;
export { FUNCTIONS };
