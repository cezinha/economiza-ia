import { motion } from "framer-motion";
import { useMemo } from "react";

interface GanttTask {
  name: string;
  icon: "stage" | "milestone";
  color: string;
  startWeek: number;
  endWeek: number;
}

const tasks: GanttTask[] = [
  { name: "Define Exit", icon: "stage", color: "bg-success", startWeek: 2, endWeek: 4 },
  { name: "Plan Start", icon: "stage", color: "bg-success", startWeek: 4, endWeek: 7 },
  { name: "Plan Exit -14", icon: "milestone", color: "bg-destructive", startWeek: 5, endWeek: 9 },
  { name: "Plan Exit -7", icon: "milestone", color: "bg-success", startWeek: 8, endWeek: 11 },
  { name: "Feature Matrix", icon: "stage", color: "bg-warning", startWeek: 9, endWeek: 11 },
  { name: "NUDD Action Plan", icon: "stage", color: "bg-warning", startWeek: 9, endWeek: 10 },
];

const months = ["Mar", "Apr", "May"];
const totalWeeks = 12;

const GanttTimeline = () => {
  const weekColumns = useMemo(() => Array.from({ length: totalWeeks }, (_, i) => i), []);

  return (
    <div className="card-elevated flex flex-col">
      <div className="px-5 py-4 border-b border-border-subtle flex justify-between items-center">
        <h3 className="font-semibold text-sm text-foreground">Timeline</h3>
        <div className="flex items-center gap-3">
          <span className="text-[10px] uppercase tracking-wider text-primary font-semibold">
            Plan Phase Exit ▼
          </span>
        </div>
      </div>

      <div className="p-5 overflow-x-auto">
        {/* Month headers */}
        <div className="flex mb-1" style={{ paddingLeft: 140 }}>
          {months.map((month, i) => (
            <div key={month} className="flex-1 text-center">
              <span className={`text-xs font-semibold ${i === 2 ? "text-primary" : "text-muted-foreground"}`}>
                {month}
              </span>
            </div>
          ))}
        </div>

        {/* Grid lines + bars */}
        <div className="relative">
          {tasks.map((task, i) => (
            <div key={task.name} className="flex items-center h-8 group">
              {/* Label */}
              <div className="w-[140px] shrink-0 pr-3 flex items-center gap-2">
                {task.icon === "milestone" ? (
                  <span className="w-3 h-3 rotate-45 bg-primary shrink-0" />
                ) : (
                  <span className="w-4 h-0.5 bg-muted-foreground shrink-0" />
                )}
                <span className="text-xs text-foreground truncate">{task.name}</span>
              </div>
              {/* Bar area */}
              <div className="flex-1 relative h-full flex items-center">
                {/* Grid columns */}
                <div className="absolute inset-0 flex">
                  {weekColumns.map((w) => (
                    <div key={w} className="flex-1 border-r border-border-subtle/50" />
                  ))}
                </div>
                {/* Bar */}
                <motion.div
                  className={`absolute h-5 rounded-sm ${task.color} opacity-90`}
                  style={{
                    left: `${(task.startWeek / totalWeeks) * 100}%`,
                    width: `${((task.endWeek - task.startWeek) / totalWeeks) * 100}%`,
                  }}
                  initial={{ scaleX: 0, originX: 0 }}
                  animate={{ scaleX: 1 }}
                  transition={{ duration: 0.5, delay: i * 0.08, ease: [0.25, 0.1, 0.25, 1] }}
                />
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default GanttTimeline;
