import { useEffect, useMemo } from "react";
import { Filter, RotateCcw, Search } from "lucide-react";
import MultiSelectPopover from "@/components/dashboard/MultiSelectPopover";
import AutocompleteMultiInput from "@/components/dashboard/AutocompleteMultiInput";
import { usePlatform } from "@/contexts/PlatformContext";
import { useUniversalFilters, PLATFORM_LOB, PLATFORM_ORG, LOBS, PHASES } from "@/contexts/UniversalFilterContext";
import { useRole } from "@/contexts/RoleContext";
import { FUNCTIONS, type FunctionFilterValue } from "@/components/dashboard/FunctionFilter";
import { getAllOwnerNames } from "@/data/taskParticipants";
import { getAllTaskNames } from "@/data/scheduleData";
import {
  useHomeFilters,
  defaultHomeFilters,
  ORGS,
  STATUSES,
  type HomeFilterState,
} from "@/contexts/HomeFilterContext";

// Re-export for backward compatibility
export { defaultHomeFilters, ORGS, STATUSES, type HomeFilterState };

/**
 * Multi-select filter bar persisted via HomeFilterContext.
 * Org / LOB / Platform / Phase / Status are multi-select.
 * Function / Owner / Task are enabled via `enableTaskControls` (used on /schedule).
 */
export interface HomeFilterBarProps {
  /** Field keys to render as disabled (greyed out). */
  disabledFields?: Array<"orgs" | "lobs" | "platforms" | "phases" | "statuses">;
  /** When true, Function (multi), Owner (search), Task (search) become active. */
  enableTaskControls?: boolean;
}

const HomeFilterBar = ({ disabledFields = [], enableTaskControls = false }: HomeFilterBarProps) => {
  const { filters: value, setFilters: onChange, reset, hasActive } = useHomeFilters();
  const { programs, setSelectedPlatform } = usePlatform();
  const { updateFilter, setFilters: setUniversalFilters, filters: universalFilters } = useUniversalFilters();
  const { role, assignedPlatform } = useRole();

  const userLocked = role === "User" && !!assignedPlatform;

  // Sync the universal filter context (org/lob/platform) from the home filter bar.
  // Use setFilters directly to avoid updateFilter's cascading resets.
  useEffect(() => {
    const platform = value.platforms.length === 1 ? value.platforms[0] : "all";
    const lob = value.lobs.length === 1 ? value.lobs[0] : "all";
    const organization = value.orgs.length === 1 ? value.orgs[0] : "all";
    setSelectedPlatform(platform === "all" ? null : platform);
    setUniversalFilters({
      ...universalFilters,
      organization,
      lob,
      platform,
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [value.platforms, value.lobs, value.orgs]);

  const availablePlatforms = useMemo(() => {
    if (value.lobs.length === 0) return [...programs];
    return programs.filter((p) => value.lobs.includes(PLATFORM_LOB[p]));
  }, [value.lobs, programs]);

  return (
    <div className="flex items-center gap-1.5 flex-nowrap">
      <Filter className="w-3.5 h-3.5 text-muted-foreground shrink-0" />

      <MultiSelectPopover
        label="Organization"
        options={[...ORGS]}
        selected={value.orgs}
        onChange={(orgs) => onChange({ ...value, orgs })}
        width="w-[100px]"
        emptyLabel="All Orgs"
        disabled={disabledFields.includes("orgs")}
      />

      <MultiSelectPopover
        label="LOB"
        options={[...LOBS]}
        selected={value.lobs}
        onChange={(lobs) => {
          const validPlatforms =
            lobs.length === 0
              ? value.platforms
              : value.platforms.filter((p) => lobs.includes(PLATFORM_LOB[p]));
          onChange({ ...value, lobs, platforms: validPlatforms });
        }}
        width="w-[100px]"
        emptyLabel="All LOBs"
        disabled={userLocked || disabledFields.includes("lobs")}
      />

      <MultiSelectPopover
        label="Platform"
        options={availablePlatforms}
        selected={value.platforms}
        onChange={(platforms) => {
          // Cascade upward: selecting a platform auto-selects its LOB and Org.
          // Union with currently selected LOBs/Orgs so the user's broader picks are preserved.
          const derivedLobs = Array.from(
            new Set([...value.lobs, ...platforms.map((p) => PLATFORM_LOB[p]).filter(Boolean)]),
          );
          const derivedOrgs = Array.from(
            new Set([...value.orgs, ...platforms.map((p) => PLATFORM_ORG[p]).filter(Boolean)]),
          );
          onChange({ ...value, platforms, lobs: derivedLobs, orgs: derivedOrgs });
        }}
        width="w-[110px]"
        emptyLabel="All Platforms"
        disabled={userLocked || disabledFields.includes("platforms")}
      />

      <MultiSelectPopover
        label="Phase"
        options={[...PHASES]}
        selected={value.phases}
        onChange={(phases) => onChange({ ...value, phases })}
        width="w-[100px]"
        emptyLabel="All Phases"
        disabled={disabledFields.includes("phases")}
      />

      <MultiSelectPopover
        label="Status"
        options={[...STATUSES]}
        selected={value.statuses}
        onChange={(statuses) => onChange({ ...value, statuses })}
        width="w-[110px]"
        emptyLabel="All Statuses"
        disabled={disabledFields.includes("statuses")}
      />

      {enableTaskControls ? (
        <>
          <MultiSelectPopover
            label="Function"
            options={FUNCTIONS.filter((f) => f !== "All") as unknown as string[]}
            selected={value.functions.filter((f) => f !== "All")}
            onChange={(fns) =>
              onChange({ ...value, functions: fns as FunctionFilterValue[] })
            }
            width="w-[110px]"
            emptyLabel="All Functions"
          />

          <AutocompleteMultiInput
            options={getAllOwnerNames()}
            selected={value.ownerSearch}
            onChange={(ownerSearch) => onChange({ ...value, ownerSearch })}
            placeholder="Owner"
            ariaLabel="Filter by primary owner"
            widthClass="w-[170px]"
          />

          <AutocompleteMultiInput
            options={getAllTaskNames()}
            selected={value.taskSearch}
            onChange={(taskSearch) => onChange({ ...value, taskSearch })}
            placeholder="Task"
            ariaLabel="Filter by task name"
            widthClass="w-[170px]"
          />
        </>
      ) : (
        <>
          <MultiSelectPopover
            label="Function"
            options={[]}
            selected={[]}
            onChange={() => {}}
            width="w-[110px]"
            emptyLabel="All Functions"
            disabled
          />
          <div className="relative shrink-0">
            <Search className="absolute left-2 top-1/2 -translate-y-1/2 w-3 h-3 text-muted-foreground pointer-events-none" />
            <input
              type="text"
              value=""
              disabled
              placeholder="Owner"
              className="h-7 w-[120px] pl-7 pr-2 text-[11px] rounded-md border border-input bg-background text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-ring opacity-40 cursor-not-allowed"
              aria-label="Search by primary owner (disabled)"
              readOnly
            />
          </div>
          <div className="relative shrink-0">
            <Search className="absolute left-2 top-1/2 -translate-y-1/2 w-3 h-3 text-muted-foreground pointer-events-none" />
            <input
              type="text"
              value=""
              disabled
              placeholder="Task"
              className="h-7 w-[120px] pl-7 pr-2 text-[11px] rounded-md border border-input bg-background text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-ring opacity-40 cursor-not-allowed"
              aria-label="Search by task name (disabled)"
              readOnly
            />
          </div>
        </>
      )}

      <button
        type="button"
        onClick={reset}
        disabled={!hasActive}
        className="ml-1 h-7 px-2 text-[11px] rounded-md text-muted-foreground hover:text-foreground hover:bg-muted flex items-center gap-1 shrink-0 disabled:opacity-40 disabled:cursor-not-allowed disabled:hover:bg-transparent disabled:hover:text-muted-foreground"
        title="Reset all filters"
      >
        <RotateCcw className="w-3 h-3" />
        Reset
      </button>
    </div>
  );
};

export default HomeFilterBar;

/**
 * Sticky page-level filter header. Drop at the top of any page that needs
 * the persistent home filter bar.
 */
export const StickyHomeFilterBar = ({ disabledFields, enableTaskControls }: HomeFilterBarProps = {}) => (
  <div className="sticky top-0 z-30 py-3 px-6 flex items-center gap-3 bg-background/85 backdrop-blur-md border-b border-border/60 shadow-sm">
    <HomeFilterBar disabledFields={disabledFields} enableTaskControls={enableTaskControls} />
  </div>
);
