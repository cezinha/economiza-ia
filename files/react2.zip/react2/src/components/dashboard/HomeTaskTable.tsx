import { CheckCircle2, AlertTriangle, Clock } from "lucide-react";
import { programSchedules, type Phase, type TaskStatus } from "@/data/scheduleData";
import { isAutoCompletedTask, AUTO_COMPLETED_OWNER } from "@/data/taskParticipants";

type RowStatus = "complete" | "on-track" | "at-risk";

export interface StageRow {
  phase: string;
  stage: string;
  stageIcon: "stage" | "milestone";
  owner: string;
  description: string;
  ecd: string;
  status: RowStatus;
  progress?: number;
}

const taskStatusToRowStatus = (status: TaskStatus): RowStatus => {
  switch (status) {
    case "completed": return "complete";
    case "on-track": return "on-track";
    case "pending": return "on-track";
    case "late": return "at-risk";
  }
};

const computeProgress = (status: TaskStatus): number => {
  switch (status) {
    case "completed": return 100;
    case "on-track": return 66;
    case "pending": return 20;
    case "late": return 50;
  }
};

// Generate a mock ECD based on phase
const phaseECDs: Record<string, string[]> = {
  "Concept": ["3/10/26", "3/15/26", "3/20/26"],
  "Define": ["3/25/26", "4/1/26", "4/8/26"],
  "Plan": ["4/10/26", "4/17/26", "4/24/26"],
  "Qual": ["5/1/26", "5/15/26", "5/29/26"],
  "Pilot": ["6/5/26", "6/19/26", "7/3/26"],
};

const getECD = (phaseName: string, idx: number): string => {
  const ecds = phaseECDs[phaseName] || ["4/24/26"];
  return ecds[idx % ecds.length];
};

const deriveRowsFromSchedule = (phases: Phase[]): StageRow[] => {
  const rows: StageRow[] = [];
  
  for (const phase of phases) {
    let isFirstPhaseRow = true;
    
    for (const milestone of phase.milestones) {
      // Add milestone row
      const milestoneStatus = milestone.tasks.every(t => t.status === "completed")
        ? "complete" as RowStatus
        : milestone.tasks.some(t => t.status === "late")
          ? "at-risk" as RowStatus
          : "on-track" as RowStatus;
      
      const milestoneProg = Math.round(
        milestone.tasks.reduce((sum, t) => sum + computeProgress(t.status), 0) / milestone.tasks.length
      );

      rows.push({
        phase: isFirstPhaseRow ? phase.name : "",
        stage: milestone.name,
        stageIcon: "milestone",
        owner: "GOE",
        description: `${milestone.tasks.length} tasks`,
        ecd: getECD(phase.name, rows.length),
        status: milestoneStatus,
        progress: milestoneProg,
      });
      isFirstPhaseRow = false;

      // Add first few task rows under each milestone (limit to keep table manageable)
      const tasksToShow = milestone.tasks.slice(0, 3);
      for (const task of tasksToShow) {
        rows.push({
          phase: "",
          stage: "",
          stageIcon: "stage",
          owner: isAutoCompletedTask(task) ? AUTO_COMPLETED_OWNER : task.owner,
          description: task.name,
          ecd: getECD(phase.name, rows.length),
          status: taskStatusToRowStatus(task.status),
          progress: task.status === "completed" ? undefined : computeProgress(task.status),
        });
      }
    }
  }

  return rows;
};

// Build programTasks from scheduleData
export const programTasks: Record<string, StageRow[]> = Object.fromEntries(
  Object.entries(programSchedules).map(([program, phases]) => {
    // Show summarized view: first 2 phases, limited rows
    const limitedPhases = phases.slice(0, 3);
    const rows = deriveRowsFromSchedule(limitedPhases).slice(0, 8);
    return [program, rows];
  })
);

const statusConfig: Record<RowStatus, { className: string; icon: typeof CheckCircle2 }> = {
  complete: { className: "text-success", icon: CheckCircle2 },
  "on-track": { className: "text-success", icon: Clock },
  "at-risk": { className: "text-destructive", icon: AlertTriangle },
};

interface HomeTaskTableProps {
  selectedProgram?: string | null;
}

const HomeTaskTable = ({ selectedProgram }: HomeTaskTableProps) => {
  const rows = selectedProgram && programTasks[selectedProgram]
    ? programTasks[selectedProgram]
    : Object.values(programTasks)[0] || [];

  return (
    <div className="card-elevated flex flex-col">
      <div className="px-4 py-2.5 border-b border-border-subtle flex items-center gap-2">
        <h3 className="font-semibold text-sm text-foreground">
          {selectedProgram ? selectedProgram : "All Programs"}
        </h3>
        {selectedProgram && (
          <span className="text-[10px] text-muted-foreground">— Task Detail</span>
        )}
      </div>
      <div className="overflow-auto">
        <table className="w-full text-left text-sm">
          <thead>
            <tr className="bg-primary text-primary-foreground uppercase text-[10px] tracking-wider font-semibold">
              <th className="px-4 py-2.5 w-16">Phase</th>
              <th className="px-4 py-2.5 w-32">Stage</th>
              <th className="px-4 py-2.5 w-20">Owner</th>
              <th className="px-4 py-2.5">Description</th>
              <th className="px-4 py-2.5 w-20">ECD</th>
              <th className="px-4 py-2.5 w-20 text-center">Status</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-border-subtle">
            {rows.map((row, i) => {
              const config = statusConfig[row.status];
              const Icon = config.icon;
              return (
                <tr key={i} className="hover:bg-accent/30 transition-colors">
                  <td className="px-4 py-2.5">
                    {row.phase && (
                      <span className="text-xs font-semibold text-primary">{row.phase}</span>
                    )}
                  </td>
                  <td className="px-4 py-2.5">
                    <div className="flex items-center gap-2">
                      {row.stage && (
                        <>
                          {row.stageIcon === "milestone" ? (
                            <span className="w-2.5 h-2.5 rotate-45 bg-primary shrink-0" />
                          ) : (
                            <span className="w-3 h-0.5 bg-muted-foreground shrink-0" />
                          )}
                          <span className="text-xs font-medium text-foreground truncate max-w-[200px]">{row.stage}</span>
                        </>
                      )}
                    </div>
                  </td>
                  <td className="px-4 py-2.5 text-xs text-muted-foreground">{row.owner}</td>
                  <td className="px-4 py-2.5 text-xs text-foreground">{row.description}</td>
                  <td className="px-4 py-2.5 text-xs tabular-nums text-muted-foreground">{row.ecd}</td>
                  <td className="px-4 py-2.5">
                    <div className="flex items-center justify-center gap-1.5">
                      {row.progress !== undefined ? (
                        <>
                          <div className="w-10 h-1.5 bg-secondary rounded-full overflow-hidden">
                            <div
                              className={`h-full rounded-full ${row.status === "at-risk" ? "bg-destructive" : "bg-primary"}`}
                              style={{ width: `${row.progress}%` }}
                            />
                          </div>
                          <span className="text-[10px] tabular-nums text-muted-foreground">{row.progress}%</span>
                        </>
                      ) : (
                        <Icon className={`w-4 h-4 ${config.className}`} />
                      )}
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default HomeTaskTable;
