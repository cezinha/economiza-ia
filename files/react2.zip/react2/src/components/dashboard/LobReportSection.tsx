import { useEffect, useState } from "react";
import { useSearchParams } from "react-router-dom";
import { motion } from "framer-motion";
import { FileText, CheckCircle2, Clock, Send, Eye } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { useRole } from "@/contexts/RoleContext";
import { usePhaseGateReports, REPORT_LOBS, type LobKey } from "@/contexts/PhaseGateReportContext";
import PhaseGateReportDialog from "./PhaseGateReportDialog";

const LobReportSection = () => {
  const { role } = useRole();
  const { reports } = usePhaseGateReports();
  const [searchParams, setSearchParams] = useSearchParams();
  const [active, setActive] = useState<{ lob: LobKey; mode: "view" | "generate" } | null>(null);

  const isExec = role === "Executive";
  const isSuper = role === "Super Admin";

  // Reopen from drill-through return
  useEffect(() => {
    const reopen = searchParams.get("reopenReport") as LobKey | null;
    const mode = (searchParams.get("mode") as "view" | "generate" | null) ?? "view";
    if (reopen && REPORT_LOBS.includes(reopen)) {
      setActive({ lob: reopen, mode });
      const next = new URLSearchParams(searchParams);
      next.delete("reopenReport");
      next.delete("mode");
      setSearchParams(next, { replace: true });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  if (!isExec && !isSuper) return null;

  const fmtDate = (iso?: string) => iso ? new Date(iso).toLocaleDateString(undefined, { month: "short", day: "numeric", year: "numeric" }) : "";

  return (
    <>
      <motion.div
        id="lob-phase-gate-reports"
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
        className="bg-card rounded-2xl border border-border/40 shadow-[var(--card-shadow)] overflow-hidden"
      >
        <div className="px-6 py-4 border-b border-border/30 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <FileText className="w-5 h-5 text-primary" />
            <h3 className="text-[18px] font-extrabold text-foreground tracking-tight">LOB Phase Gate Reports</h3>
          </div>
          <span className="text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">
            {isSuper ? "Super Admin · Generate &amp; submit" : "Executive · Read-only"}
          </span>
        </div>

        <div className="divide-y divide-border/30">
          {REPORT_LOBS.map((lob) => {
            const rec = reports[lob];
            return (
              <div key={lob} className="px-6 py-4 flex items-center justify-between gap-4">
                <div className="flex items-center gap-4">
                  <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center">
                    <FileText className="w-5 h-5 text-primary" />
                  </div>
                  <div>
                    <h4 className="text-[14px] font-extrabold text-foreground">{lob}</h4>
                    <div className="flex items-center gap-2 text-[11px] text-muted-foreground mt-0.5">
                      {rec.submitted ? (
                        <span className="inline-flex items-center gap-1 text-success">
                          <CheckCircle2 className="w-3 h-3" />
                          Submitted {fmtDate(rec.submittedAt)}
                          {rec.submittedBy && <span className="text-muted-foreground"> · by {rec.submittedBy}</span>}
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1">
                          <Clock className="w-3 h-3" />
                          {isExec ? "Awaiting submission from Super Admin" : "Not yet submitted"}
                        </span>
                      )}
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  {isSuper && (
                    <Button size="sm" onClick={() => setActive({ lob, mode: "generate" })}>
                      <Send className="w-3.5 h-3.5" />
                      {rec.submitted ? "Update Report" : "Generate Report"}
                    </Button>
                  )}
                  {isExec && (
                    <Button
                      size="sm"
                      variant={rec.submitted ? "default" : "outline"}
                      disabled={!rec.submitted}
                      onClick={() => rec.submitted && setActive({ lob, mode: "view" })}
                      className={cn(!rec.submitted && "cursor-not-allowed")}
                    >
                      <Eye className="w-3.5 h-3.5" />
                      {rec.submitted ? "View Report" : "Awaiting submission from Super Admin"}
                    </Button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </motion.div>

      {active && (
        <PhaseGateReportDialog
          lob={active.lob}
          mode={active.mode}
          open={!!active}
          onOpenChange={(o) => { if (!o) setActive(null); }}
        />
      )}
    </>
  );
};

export default LobReportSection;
