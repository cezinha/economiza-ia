import { useState, useMemo } from "react";
import { ChevronDown, Check, Search, X } from "lucide-react";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Input } from "@/components/ui/input";
import { cn } from "@/lib/utils";

export interface MultiSelectPopoverProps {
  label: string;            // placeholder shown when nothing selected
  options: string[];        // available options
  selected: string[];       // currently selected options
  onChange: (next: string[]) => void;
  searchable?: boolean;
  width?: string;           // tailwind width class for trigger (e.g. "w-[160px]")
  disabled?: boolean;
  /** Optional extra label suffix (e.g. for the count). */
  emptyLabel?: string;      // text when none selected (defaults to `All ${label}`)
}

const MultiSelectPopover = ({
  label,
  options,
  selected,
  onChange,
  searchable = false,
  width = "w-[160px]",
  disabled,
  emptyLabel,
}: MultiSelectPopoverProps) => {
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState("");

  const filtered = useMemo(() => {
    if (!searchable || !query.trim()) return options;
    const q = query.toLowerCase();
    return options.filter((o) => o.toLowerCase().includes(q));
  }, [options, query, searchable]);

  const toggle = (value: string) => {
    if (selected.includes(value)) {
      onChange(selected.filter((v) => v !== value));
    } else {
      onChange([...selected, value]);
    }
  };

  const clearAll = (e: React.MouseEvent) => {
    e.stopPropagation();
    onChange([]);
  };

  const triggerLabel =
    selected.length === 0
      ? emptyLabel ?? `All ${label}s`
      : selected.length === 1
        ? selected[0]
        : `${selected.length} selected`;

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild disabled={disabled}>
        <button
          type="button"
          className={cn(
            "h-7 px-2.5 text-[11px] rounded-md border border-input bg-background flex items-center justify-between gap-1.5",
            disabled && "opacity-40 cursor-not-allowed",
            width
          )}
          title={selected.length > 1 ? selected.join(", ") : undefined}
        >
          <span className="truncate text-foreground">{triggerLabel}</span>
          <span className="flex items-center gap-1 shrink-0">
            {selected.length > 0 && !disabled && (
              <X
                className="w-3 h-3 text-muted-foreground hover:text-foreground"
                onClick={clearAll}
                aria-label={`Clear ${label}`}
              />
            )}
            <ChevronDown className="w-3 h-3 text-muted-foreground" />
          </span>
        </button>
      </PopoverTrigger>
      <PopoverContent className="p-0 w-64" align="start">
        {searchable && (
          <div className="p-2 border-b border-border">
            <div className="relative">
              <Search className="w-3 h-3 text-muted-foreground absolute left-2 top-1/2 -translate-y-1/2" />
              <Input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder={`Search ${label.toLowerCase()}…`}
                className="h-7 pl-7 text-[11px]"
              />
            </div>
          </div>
        )}
        <ScrollArea className="max-h-64">
          <div className="p-1">
            {filtered.length === 0 ? (
              <div className="px-2 py-3 text-[11px] text-muted-foreground text-center">No matches</div>
            ) : (
              filtered.map((opt) => {
                const checked = selected.includes(opt);
                return (
                  <button
                    key={opt}
                    type="button"
                    onClick={() => toggle(opt)}
                    className={cn(
                      "w-full flex items-center gap-2 px-2 py-1.5 rounded text-[11px] text-left hover:bg-muted",
                      checked && "bg-primary/5"
                    )}
                  >
                    <span
                      className={cn(
                        "w-3.5 h-3.5 rounded-sm border flex items-center justify-center shrink-0",
                        checked
                          ? "bg-primary border-primary text-primary-foreground"
                          : "border-input bg-background"
                      )}
                    >
                      {checked && <Check className="w-3 h-3" />}
                    </span>
                    <span className="truncate text-foreground">{opt}</span>
                  </button>
                );
              })
            )}
          </div>
        </ScrollArea>
      </PopoverContent>
    </Popover>
  );
};

export default MultiSelectPopover;
