import { useMemo, useState } from "react";
import { cn } from "@/lib/utils";
import { ChevronDown, ChevronRight, CheckCircle2, Circle, Clock, AlertTriangle } from "lucide-react";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import type { Phase, ScheduleTask, TaskStatus } from "@/data/scheduleData";
import TaskChipStrip from "@/components/dashboard/TaskChipStrip";

interface MyTasksListProps {
  phases: Phase[];
  selectedTaskId: string | null;
  onSelectTask: (task: ScheduleTask, phaseName: string, milestoneName: string) => void;
}

const statusIcon: Record<TaskStatus, React.ReactNode> = {
  completed: <CheckCircle2 className="w-3.5 h-3.5 text-[hsl(var(--mds-success))]" />,
  "on-track": <Clock className="w-3.5 h-3.5 text-[hsl(var(--mds-blue))]" />,
  "at-risk": <AlertTriangle className="w-3.5 h-3.5 text-[hsl(var(--mds-warning))]" />,
  pending: <Circle className="w-3.5 h-3.5 text-muted-foreground" />,
  late: <AlertTriangle className="w-3.5 h-3.5 text-[hsl(var(--mds-danger))]" />,
};

const phaseColorMap: Record<string, string> = {
  "Concept": "bg-blue-500",
  "Define": "bg-emerald-500",
  "Plan": "bg-amber-500",
  "Qual": "bg-orange-500",
  "Pilot": "bg-teal-500",
  "Ramp": "bg-rose-500",
};

const MyTasksList = ({ phases, selectedTaskId, onSelectTask }: MyTasksListProps) => {
  const [expandedPhases, setExpandedPhases] = useState<Record<string, boolean>>(() => {
    const initial: Record<string, boolean> = {};
    phases.forEach((p, i) => {
      const isCurrentPhase = p.status === "at-risk" || p.status === "on-track";
      initial[p.name] = isCurrentPhase || i === 0;
    });
    return initial;
  });

  // Single source of truth for dependency lookups across all task rows.
  const taskMap = useMemo<Record<string, ScheduleTask>>(() => {
    const map: Record<string, ScheduleTask> = {};
    phases.forEach((ph) =>
      ph.milestones.forEach((m) => m.tasks.forEach((t) => (map[t.id] = t)))
    );
    return map;
  }, [phases]);

  const togglePhase = (name: string) => {
    setExpandedPhases((prev) => ({ ...prev, [name]: !prev[name] }));
  };

  const currentPhaseIndex = phases.findIndex((p) =>
    p.milestones.some((m) => m.tasks.some((t) => t.status !== "completed"))
  );

  return (
    <div className="flex flex-col h-full border border-border rounded-lg bg-card overflow-hidden">
      <div className="px-4 py-3 border-b border-border bg-muted/30 space-y-2">
        <h2 className="text-xs font-semibold text-foreground uppercase tracking-wider">My Tasks</h2>
      </div>
      <ScrollArea className="flex-1">
        <div className="p-2 space-y-1">
          {phases.map((phase, phaseIdx) => {
            const isExpanded = expandedPhases[phase.name] ?? false;
            const isCurrent = phaseIdx === currentPhaseIndex;
            const allTasks = phase.milestones.flatMap((m) => m.tasks);
            const completedCount = allTasks.filter((t) => t.status === "completed").length;
            const totalCount = allTasks.length;

            return (
              <div key={phase.name}>
                <button
                  onClick={() => togglePhase(phase.name)}
                  className={cn(
                    "w-full flex items-center gap-2 px-2.5 py-2 rounded-md text-left transition-colors",
                    "hover:bg-muted/50",
                    isCurrent && "bg-primary/5"
                  )}
                >
                  {isExpanded ? (
                    <ChevronDown className="w-3.5 h-3.5 text-muted-foreground shrink-0" />
                  ) : (
                    <ChevronRight className="w-3.5 h-3.5 text-muted-foreground shrink-0" />
                  )}
                  <div className={cn("w-2 h-2 rounded-full shrink-0", phaseColorMap[phase.name] || "bg-gray-400")} />
                  <span className="text-xs font-semibold text-foreground flex-1 truncate">{phase.name}</span>
                  <span className="text-[10px] text-muted-foreground shrink-0">
                    {completedCount}/{totalCount}
                  </span>
                  {isCurrent && (
                    <Badge variant="secondary" className="text-[9px] px-1.5 py-0 shrink-0">
                      Current
                    </Badge>
                  )}
                </button>
                {isExpanded && (
                  <div className="ml-4 pl-3 border-l border-border/50 space-y-0.5 py-1">
                    {phase.milestones.map((milestone) =>
                      milestone.tasks.map((task) => {
                        const isSelected = selectedTaskId === task.id;
                        return (
                          <button
                            key={task.id}
                            onClick={() => onSelectTask(task, phase.name, milestone.name)}
                            className={cn(
                              "w-full flex items-center gap-2 px-2 py-1.5 rounded text-left transition-colors",
                              "hover:bg-muted/60",
                              isSelected && "bg-primary/10 ring-1 ring-primary/20"
                            )}
                          >
                            {statusIcon[task.status]}
                            <span
                              className={cn(
                                "text-[11px] flex-1 min-w-0 truncate",
                                task.status === "completed"
                                  ? "text-muted-foreground line-through"
                                  : "text-foreground"
                              )}
                            >
                              {task.name}
                            </span>
                            <TaskChipStrip task={task} taskMap={taskMap} />
                          </button>
                        );
                      })
                    )}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </ScrollArea>
    </div>
  );
};

export default MyTasksList;
