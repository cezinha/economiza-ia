import { useState } from "react";
import { Bell, X, AlertTriangle, CheckCircle2, Clock, MailOpen, Mail, Flag } from "lucide-react";
import { cn } from "@/lib/utils";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Tooltip, TooltipContent, TooltipTrigger, TooltipProvider } from "@/components/ui/tooltip";
import { motion, AnimatePresence } from "framer-motion";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { useStatusFlags } from "@/contexts/StatusFlagContext";

interface Notification {
  id: string;
  type: "warning" | "info" | "success" | "overdue";
  title: string;
  message: string;
  timestamp: string;
  read: boolean;
  taskCompleted?: boolean; // for overdue notifications — whether the linked task is done
}

const mockNotifications: Notification[] = [
  { id: "1", type: "overdue", title: "Task Overdue", message: "\"Lock RTS/RTO schedule\" for Laptop 1 is 3 days past due", timestamp: "2h ago", read: false, taskCompleted: false },
  { id: "2", type: "warning", title: "At Risk", message: "Laptop 2 Define phase has 2 late tasks", timestamp: "4h ago", read: false },
  { id: "3", type: "info", title: "Watchlist Update", message: "Laptop 3 moved from Plan to Develop / Qual", timestamp: "1d ago", read: true },
  { id: "4", type: "success", title: "Phase Complete", message: "Laptop 1 Concept phase — all tasks completed", timestamp: "2d ago", read: true },
  { id: "5", type: "warning", title: "Duration Warning", message: "Pilot build task for Laptop 4 scheduled for only 5 days (minimum recommended: 14 days)", timestamp: "3d ago", read: true },
  { id: "6", type: "overdue", title: "NUDD Action Required", message: "3 high-severity NUDDs for Laptop 7 require mitigation updates", timestamp: "3d ago", read: true, taskCompleted: true },
];

const typeIcon: Record<string, React.ReactNode> = {
  warning: <AlertTriangle className="w-3.5 h-3.5 text-warning" />,
  info: <Clock className="w-3.5 h-3.5 text-primary" />,
  success: <CheckCircle2 className="w-3.5 h-3.5 text-success" />,
  overdue: <AlertTriangle className="w-3.5 h-3.5 text-destructive" />,
};

const typeBorder: Record<string, string> = {
  warning: "border-l-warning",
  info: "border-l-primary",
  success: "border-l-success",
  overdue: "border-l-destructive",
};

type FilterTab = "all" | "urgent" | "info";

const isOverdueLocked = (n: Notification) => n.type === "overdue" && !n.taskCompleted;

const NotificationCenter = () => {
  const [open, setOpen] = useState(false);
  const [fullViewOpen, setFullViewOpen] = useState(false);
  const [notifications, setNotifications] = useState(mockNotifications);
  const [filter, setFilter] = useState<FilterTab>("all");
  const { flags, confirmFlag, overrideFlag } = useStatusFlags();
  const unreadCount = notifications.filter((n) => !n.read).length + flags.length;

  const markAllRead = () => {
    setNotifications((prev) => prev.map((n) => isOverdueLocked(n) ? n : { ...n, read: true }));
  };

  const toggleRead = (id: string) => {
    setNotifications((prev) =>
      prev.map((n) => {
        if (n.id !== id) return n;
        // If overdue + task not completed, cannot mark as read
        if (isOverdueLocked(n)) return n;
        return { ...n, read: !n.read };
      })
    );
  };

  const filtered = notifications.filter((n) => {
    if (filter === "urgent") return n.type === "overdue" || n.type === "warning";
    if (filter === "info") return n.type === "info" || n.type === "success";
    return true;
  });

  return (
    <div className="relative">
      <TooltipProvider delayDuration={200}>
        <Tooltip>
          <TooltipTrigger asChild>
            <button
              onClick={() => setOpen(!open)}
              className="relative flex items-center text-muted-foreground hover:text-foreground transition-colors p-2 rounded-lg hover:bg-muted/50 press-scale"
              aria-label="Notifications"
            >
              <Bell className="w-4 h-4" />
              {unreadCount > 0 && (
                <span className="absolute -top-0 -right-0 min-w-[16px] h-4 rounded-full bg-destructive text-destructive-foreground text-[9px] font-black flex items-center justify-center px-1 animate-pulse-ring">
                  {unreadCount}
                </span>
              )}
            </button>
          </TooltipTrigger>
          <TooltipContent side="bottom" className="text-[11px]">
            Notifications
          </TooltipContent>
        </Tooltip>
      </TooltipProvider>

      <AnimatePresence>
        {open && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 z-40"
              onClick={() => setOpen(false)}
            />
            <motion.div
              initial={{ opacity: 0, y: -4, scale: 0.98 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: -4, scale: 0.98 }}
              transition={{ duration: 0.15, ease: [0.25, 0.1, 0.25, 1] }}
              className="absolute right-0 top-10 w-[380px] bg-card border border-border/50 rounded-2xl shadow-2xl z-50 overflow-hidden"
            >
              <div className="flex items-center justify-between px-5 py-3.5 border-b border-border/30">
                <span className="text-[13px] font-bold text-foreground">Notifications</span>
                <div className="flex items-center gap-2">
                  {unreadCount > 0 && (
                    <button onClick={markAllRead} className="text-[10px] text-primary hover:underline font-bold press-scale">
                      Mark all read
                    </button>
                  )}
                  <button onClick={() => setOpen(false)} className="p-1 rounded-lg hover:bg-muted/40 transition-colors press-scale" aria-label="Close notifications">
                    <X className="w-3.5 h-3.5 text-muted-foreground" />
                  </button>
                </div>
              </div>

              {/* Filter tabs */}
              <div className="flex items-center gap-1 px-4 py-2 border-b border-border/20">
                {(["all", "urgent", "info"] as FilterTab[]).map((tab) => (
                  <button
                    key={tab}
                    onClick={() => setFilter(tab)}
                    className={cn(
                      "px-3 py-1 text-[10px] font-bold rounded-full transition-all press-scale uppercase tracking-wide",
                      filter === tab ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:bg-muted/40"
                    )}
                  >
                    {tab === "all" ? "All" : tab === "urgent" ? "Urgent" : "Info"}
                  </button>
                ))}
              </div>

              <ScrollArea className="max-h-[360px]">
                <div className="p-2">
                  {flags.length > 0 && filter !== "info" && (
                    <div className="mb-2">
                      <p className="px-2 pb-1 text-[9px] font-bold uppercase tracking-wider text-muted-foreground">
                        Status Flags · {flags.length}
                      </p>
                      {flags.slice(0, 6).map((f) => (
                        <div
                          key={f.taskId}
                          className={cn(
                            "flex items-start gap-3 p-3 rounded-xl mb-1 border-l-[3px]",
                            f.severity === "red" ? "border-l-destructive bg-destructive/[0.04]" : "border-l-warning bg-warning/[0.04]"
                          )}
                        >
                          <Flag className={cn("w-3.5 h-3.5 mt-0.5 shrink-0", f.severity === "red" ? "text-destructive" : "text-warning")} />
                          <div className="flex-1 min-w-0">
                            <p className="text-[11px] font-bold text-foreground truncate">{f.taskName}</p>
                            <p className="text-[10px] text-muted-foreground mt-0.5">
                              Suggested: <span className="font-semibold capitalize">{f.suggested}</span> — {f.reason}
                            </p>
                            <div className="mt-1.5 flex gap-1.5">
                              <button
                                onClick={() => confirmFlag(f.taskId)}
                                className="text-[10px] font-semibold px-2 py-0.5 rounded bg-primary text-primary-foreground hover:bg-primary/90 press-scale"
                              >
                                Confirm
                              </button>
                              <button
                                onClick={() => overrideFlag(f.taskId)}
                                className="text-[10px] font-semibold px-2 py-0.5 rounded border border-border hover:bg-muted/50 press-scale"
                              >
                                Override
                              </button>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                  {filtered.map((n) => {
                    const locked = isOverdueLocked(n);
                    return (
                      <div
                        key={n.id}
                        className={cn(
                          "flex items-start gap-3 p-3 rounded-xl transition-all border-l-[3px] mb-1 group",
                          typeBorder[n.type],
                          !n.read ? "bg-primary/[0.03]" : "hover:bg-muted/15"
                        )}
                      >
                        <div className="mt-0.5 shrink-0">{typeIcon[n.type]}</div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2">
                            <span className="text-[11px] font-bold text-foreground">{n.title}</span>
                            {!n.read && <span className="w-1.5 h-1.5 rounded-full bg-primary shrink-0" />}
                            {locked && (
                              <span className="text-[8px] text-destructive/70 font-semibold uppercase tracking-wide">Task pending</span>
                            )}
                          </div>
                          <p className="text-[10px] text-muted-foreground mt-0.5 leading-relaxed">{n.message}</p>
                          <span className="text-[9px] text-muted-foreground/40 mt-1.5 block font-medium">{n.timestamp}</span>
                        </div>
                        <TooltipProvider delayDuration={150}>
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <button
                                onClick={(e) => { e.stopPropagation(); toggleRead(n.id); }}
                                disabled={locked}
                                className={cn(
                                  "shrink-0 mt-0.5 p-1 rounded-md transition-all",
                                  locked
                                    ? "opacity-30 cursor-not-allowed"
                                    : "opacity-0 group-hover:opacity-100 hover:bg-muted/40 press-scale"
                                )}
                                aria-label={n.read ? "Mark as unread" : "Mark as read"}
                              >
                                {n.read ? (
                                  <Mail className="w-3.5 h-3.5 text-muted-foreground" />
                                ) : (
                                  <MailOpen className="w-3.5 h-3.5 text-primary" />
                                )}
                              </button>
                            </TooltipTrigger>
                            <TooltipContent side="left" className="text-[10px]">
                              {locked ? "Complete task first" : n.read ? "Mark as unread" : "Mark as read"}
                            </TooltipContent>
                          </Tooltip>
                        </TooltipProvider>
                      </div>
                    );
                  })}
                </div>
              </ScrollArea>

              <div className="px-5 py-2.5 border-t border-border/20">
                <button
                  onClick={() => { setOpen(false); setFullViewOpen(true); }}
                  className="text-[10px] text-primary font-bold hover:underline press-scale w-full text-center"
                >
                  View All Notifications
                </button>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* Full notifications dialog */}
      <Dialog open={fullViewOpen} onOpenChange={setFullViewOpen}>
        <DialogContent className="sm:max-w-[600px] max-h-[80vh] flex flex-col p-0">
          <DialogHeader className="px-6 pt-6 pb-4 border-b border-border/30">
            <DialogTitle className="text-[15px] font-extrabold">All Notifications</DialogTitle>
            <div className="flex items-center gap-2 mt-2">
              {(["all", "urgent", "info"] as FilterTab[]).map((tab) => (
                <button
                  key={tab}
                  onClick={() => setFilter(tab)}
                  className={cn(
                    "px-3 py-1 text-[10px] font-bold rounded-full transition-all uppercase tracking-wide",
                    filter === tab ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:bg-muted/40"
                  )}
                >
                  {tab === "all" ? "All" : tab === "urgent" ? "Urgent" : "Info"}
                </button>
              ))}
              {unreadCount > 0 && (
                <button onClick={markAllRead} className="ml-auto text-[10px] text-primary hover:underline font-bold">
                  Mark all read
                </button>
              )}
            </div>
          </DialogHeader>
          <ScrollArea className="flex-1 px-4 py-3">
            <div className="space-y-1">
              {filtered.map((n) => {
                const locked = isOverdueLocked(n);
                return (
                  <div
                    key={n.id}
                    className={cn(
                      "flex items-start gap-3 p-4 rounded-xl transition-all border-l-[3px] group",
                      typeBorder[n.type],
                      !n.read ? "bg-primary/[0.04]" : "hover:bg-muted/15"
                    )}
                  >
                    <div className="mt-0.5 shrink-0">{typeIcon[n.type]}</div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="text-[12px] font-bold text-foreground">{n.title}</span>
                        {!n.read && <span className="w-1.5 h-1.5 rounded-full bg-primary shrink-0" />}
                        {locked && (
                          <span className="text-[9px] text-destructive/70 font-semibold uppercase tracking-wide">Task pending</span>
                        )}
                      </div>
                      <p className="text-[11px] text-muted-foreground mt-1 leading-relaxed">{n.message}</p>
                      <span className="text-[10px] text-muted-foreground/40 mt-2 block font-medium">{n.timestamp}</span>
                    </div>
                    <button
                      onClick={() => toggleRead(n.id)}
                      disabled={locked}
                      className={cn(
                        "shrink-0 mt-0.5 p-1.5 rounded-md transition-all",
                        locked
                          ? "opacity-30 cursor-not-allowed"
                          : "opacity-40 hover:opacity-100 hover:bg-muted/40"
                      )}
                      aria-label={n.read ? "Mark as unread" : "Mark as read"}
                    >
                      {n.read ? (
                        <Mail className="w-4 h-4 text-muted-foreground" />
                      ) : (
                        <MailOpen className="w-4 h-4 text-primary" />
                      )}
                    </button>
                  </div>
                );
              })}
              {filtered.length === 0 && (
                <p className="text-center text-[12px] text-muted-foreground/50 py-8">No notifications</p>
              )}
            </div>
          </ScrollArea>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default NotificationCenter;
