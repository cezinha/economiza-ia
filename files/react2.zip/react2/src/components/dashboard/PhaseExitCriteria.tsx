import { useMemo } from "react";
import {
  programSchedules,
  computePlatformRollupStatus,
  getEffectiveTaskStatus,
  type PhaseStatus,
  type TaskStatus,
  type ScheduleTask,
} from "@/data/scheduleData";
import { getCurrentPhaseByDate } from "@/components/dashboard/PortfolioScheduleGantt";

type CriterionStatus =
  | "on-track"
  | "in-progress"
  | "at-risk-mitigation"
  | "at-risk-no-plan"
  | "not-started";

interface MilestoneRow {
  label: string;
  tasks: ScheduleTask[];
  effectiveStatuses: TaskStatus[];
  pct: number;
}

interface PhaseExitCriteriaProps {
  programName?: string;
}

const getProgramPhases = (programName: string) =>
  programSchedules[programName] || programSchedules["Laptop 1"] || [];

const pickCurrentPhase = (programName: string) => {
  const phases = getProgramPhases(programName);
  if (phases.length === 0) return undefined;
  const currentName = getCurrentPhaseByDate(programName);
  return phases.find((p) => p.name === currentName) ?? phases[0];
};

const phaseStatusBadge: Record<PhaseStatus, { label: string; className: string }> = {
  "on-track": { label: "On Track", className: "bg-success/15 text-success" },
  "at-risk": { label: "At Risk", className: "bg-warning/15 text-warning" },
  delayed: { label: "Delayed", className: "bg-destructive/15 text-destructive" },
  "not-started": { label: "Not Started", className: "bg-muted text-muted-foreground" },
};

const criterionStatusConfig: Record<CriterionStatus, { label: string; className: string }> = {
  "on-track": { label: "On Track", className: "bg-success/15 text-success" },
  "in-progress": { label: "In Progress", className: "bg-muted text-muted-foreground" },
  "at-risk-mitigation": { label: "At Risk w/ Mitigation", className: "bg-warning/15 text-warning" },
  "at-risk-no-plan": { label: "At Risk w/ No Plan", className: "bg-destructive/15 text-destructive" },
  "not-started": { label: "Not Started", className: "bg-muted text-muted-foreground" },
};

const getMilestoneStatus = (statuses: TaskStatus[]): CriterionStatus => {
  if (statuses.length === 0) return "not-started";
  if (statuses.some((s) => s === "late")) return "at-risk-no-plan";
  if (statuses.some((s) => s === "at-risk")) return "at-risk-mitigation";
  if (statuses.every((s) => s === "completed")) return "on-track";
  const anyStarted = statuses.some((s) => s === "completed" || s === "on-track");
  if (!anyStarted) return "not-started";
  return "in-progress";
};

const PhaseExitCriteria = ({ programName = "Laptop 1" }: PhaseExitCriteriaProps) => {
  const { milestones, currentPhaseStatus, phasePct, currentPhaseName } = useMemo(() => {
    const current = pickCurrentPhase(programName);
    if (!current) {
      return {
        milestones: [] as MilestoneRow[],
        currentPhaseStatus: "not-started" as PhaseStatus,
        phasePct: 0,
        currentPhaseName: "",
      };
    }

    const rows: MilestoneRow[] = current.milestones.map((m) => {
      const effective = m.tasks.map((t) => getEffectiveTaskStatus(t));
      const total = effective.length;
      const completed = effective.filter((s) => s === "completed").length;
      const pct = total === 0 ? 0 : Math.round((completed / total) * 100);
      return { label: m.name, tasks: m.tasks, effectiveStatuses: effective, pct };
    });

    const allTasks = current.milestones.flatMap((m) => m.tasks);
    const allEffective = allTasks.map((t) => getEffectiveTaskStatus(t));
    const totalTasks = allEffective.length;
    const completedTasks = allEffective.filter((s) => s === "completed").length;
    const overallPct = totalTasks === 0 ? 0 : Math.round((completedTasks / totalTasks) * 100);

    // Use effective statuses for the rollup
    const tasksWithEffective = allTasks.map((t, i) => ({ ...t, status: allEffective[i] }));
    const status = computePlatformRollupStatus(tasksWithEffective, { hasStartedPhase: true });

    return {
      milestones: rows,
      currentPhaseStatus: status,
      phasePct: overallPct,
      currentPhaseName: current.name,
    };
  }, [programName]);

  const completeCount = milestones.filter((m) => m.pct === 100).length;
  const phaseBadge = phaseStatusBadge[currentPhaseStatus];

  return (
    <div className="card-elevated flex flex-col h-full">
      <div className="px-5 py-4 border-b border-border-subtle flex justify-between items-center gap-2">
        <div className="flex items-center gap-2 min-w-0">
          <h3 className="font-semibold text-sm text-foreground truncate">
            Outcome-Based Subprocesses
          </h3>
          <span className="text-xs text-muted-foreground tabular-nums shrink-0">
            {currentPhaseName} · {phasePct}%
          </span>
          <span
            className={`text-[10px] font-semibold px-2 py-0.5 rounded-full shrink-0 ${phaseBadge.className}`}
          >
            {phaseBadge.label}
          </span>
        </div>
        <span className="text-xs font-semibold text-primary tabular-nums shrink-0">
          {completeCount}/{milestones.length} Complete
        </span>
      </div>
      <div className="p-3 flex-1 overflow-auto space-y-0.5">
        {milestones.length === 0 && (
          <div className="text-xs text-muted-foreground px-2 py-4 text-center">
            No exit criteria available for this phase.
          </div>
        )}
        {milestones.map((m) => {
          const status = getMilestoneStatus(m.effectiveStatuses);
          const config = criterionStatusConfig[status];
          return (
            <div
              key={m.label}
              className="flex items-center gap-2.5 py-2 px-2 rounded-md hover:bg-accent/50 transition-colors"
            >
              <span className="text-sm text-foreground leading-snug flex-1 text-left">
                {m.label}
              </span>
              <span className="text-[11px] text-muted-foreground tabular-nums shrink-0 w-10 text-right">
                {m.pct}%
              </span>
              <span
                className={`text-[10px] font-semibold px-2 py-0.5 rounded-full shrink-0 w-40 text-center ${config.className}`}
              >
                {config.label}
              </span>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default PhaseExitCriteria;
