import { useMemo } from "react";
import { Target } from "lucide-react";
import { cn } from "@/lib/utils";
import {
  getCurrentPhaseByDate,
  getPhaseBarColor,
  computeProgramStatus,
  computeMilestoneDate,
  MILESTONES,
  type MilestoneDef,
} from "@/components/dashboard/PortfolioScheduleGantt";
import { computeRollupStatus, type Phase, type PhaseStatus } from "@/data/scheduleData";

const statusDotColors: Record<PhaseStatus, string> = {
  "on-track": "bg-green-500",
  "at-risk": "bg-yellow-500",
  "delayed": "bg-red-500",
  "not-started": "bg-gray-400",
};

const statusTextColors: Record<PhaseStatus, string> = {
  "on-track": "text-green-700",
  "at-risk": "text-yellow-700",
  "delayed": "text-red-700",
  "not-started": "text-muted-foreground",
};

const formatDate = (d: Date) =>
  d.toLocaleDateString(undefined, { month: "short", day: "2-digit", year: "numeric" });

interface Props {
  programName: string;
  phases: Phase[];
  phaseTimelineDates: Record<string, { start: Date; end: Date }>;
}

const MONTH_ABBR = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

const PhaseExitTrackerWidget = ({ programName, phases, phaseTimelineDates }: Props) => {
  const currentPhaseName = useMemo(() => getCurrentPhaseByDate(programName), [programName]);
  const phaseSpan = phaseTimelineDates[currentPhaseName];
  const today = useMemo(() => new Date(), []);

  const { donePct, barColor, todayPctLocal, todayInPhase, monthTicks, milestonesInPhase } = useMemo(() => {
    if (!phaseSpan) {
      return {
        donePct: 0,
        barColor: "bg-muted-foreground/40",
        todayPctLocal: 0,
        todayInPhase: false,
        monthTicks: [] as { label: string; pct: number }[],
        milestonesInPhase: [] as { def: MilestoneDef; date: Date; pct: number }[],
      };
    }
    const startMs = phaseSpan.start.getTime();
    const endMs = phaseSpan.end.getTime();
    const spanMs = Math.max(1, endMs - startMs);

    // Same time-based formula used in PortfolioScheduleGantt platform row.
    const t = today.getTime();
    let pct = 0;
    let hasProgress = false;
    if (t >= endMs) {
      pct = 100;
      hasProgress = true;
    } else if (t > startMs) {
      pct = Math.round(((t - startMs) / spanMs) * 100);
      hasProgress = true;
    }

    const platformStatus = computeProgramStatus(phases, programName);
    const color = getPhaseBarColor(pct, hasProgress, platformStatus);

    const inPhase = t >= startMs && t <= endMs;
    const tPct = inPhase ? ((t - startMs) / spanMs) * 100 : 0;

    // Month ticks across the phase span.
    const ticks: { label: string; pct: number }[] = [];
    const cursor = new Date(phaseSpan.start.getFullYear(), phaseSpan.start.getMonth(), 1);
    while (cursor <= phaseSpan.end) {
      const cMs = cursor.getTime();
      if (cMs >= startMs && cMs <= endMs) {
        ticks.push({
          label: `${MONTH_ABBR[cursor.getMonth()]} '${String(cursor.getFullYear()).slice(2)}`,
          pct: ((cMs - startMs) / spanMs) * 100,
        });
      }
      cursor.setMonth(cursor.getMonth() + 1);
    }

    // Milestones whose computed date sits inside this phase span.
    const ms: { def: MilestoneDef; date: Date; pct: number }[] = [];
    for (const def of MILESTONES) {
      const d = computeMilestoneDate(def, phaseTimelineDates);
      if (!d) continue;
      const dMs = d.getTime();
      if (dMs < startMs || dMs > endMs) continue;
      ms.push({ def, date: d, pct: ((dMs - startMs) / spanMs) * 100 });
    }

    return {
      donePct: pct,
      barColor: color,
      todayPctLocal: tPct,
      todayInPhase: inPhase,
      monthTicks: ticks,
      milestonesInPhase: ms,
    };
  }, [phaseSpan, phases, programName, today, phaseTimelineDates]);

  if (!phaseSpan) return null;

  const todayLabel = today.toLocaleDateString(undefined, { month: "short", day: "numeric" });

  return (
    <div className="border border-border rounded-lg bg-card">
      {/* Header: title only — phase name + % live inside the bar (mirrors portfolio Gantt row) */}
      <div className="flex items-center gap-2 px-4 py-3 border-b border-border">
        <Target className="w-4 h-4 text-primary" />
        <h4 className="text-sm font-semibold text-foreground">Phase Exit Tracker</h4>
        <span className="text-[10px] text-muted-foreground ml-1">— zoomed view of current phase</span>
      </div>

      {/* Gantt strip */}
      <div className="px-4 pt-3 pb-5">
        {/* Month labels */}
        <div className="relative h-4 mb-1">
          {monthTicks.map((m) => (
            <div
              key={m.label}
              className="absolute -translate-x-1/2 text-[10px] text-muted-foreground font-medium"
              style={{ left: `${m.pct}%` }}
            >
              {m.label}
            </div>
          ))}
        </div>

        {/* Bar track — height matches portfolio Gantt row strip */}
        <div className="relative h-12 bg-muted/40 rounded">
          {/* Month tick marks */}
          {monthTicks.map((m) => (
            <div
              key={`tick-${m.label}`}
              className="absolute top-0 bottom-0 w-px bg-border"
              style={{ left: `${m.pct}%` }}
            />
          ))}

          {/* Phase bar — mirrors PortfolioScheduleGantt platform row bar (h-5 with in-bar label) */}
          <div
            className={cn(
              "absolute h-5 rounded-sm overflow-hidden flex items-center justify-center left-0 right-0",
              barColor,
            )}
            style={{ top: "12px" }}
            title={`${currentPhaseName}: ${donePct}% complete`}
          >
            <span className="text-[10px] font-bold text-white drop-shadow-sm truncate px-2">
              {currentPhaseName} {donePct}%
            </span>
          </div>

          {/* Milestones — same diamond as portfolio Gantt (w-1.5 h-1.5 rotate-45 bg-purple-500) */}
          {milestonesInPhase.map((ms) => (
            <div
              key={ms.def.short}
              className="absolute z-[5] group/ms"
              style={{ left: `${ms.pct}%`, top: "36px", transform: "translateX(-50%)" }}
              title={`${ms.def.label}: ${ms.date.toLocaleDateString()}`}
            >
              <div className="w-1.5 h-1.5 rotate-45 bg-purple-500" />
              <span className="absolute top-3 left-1/2 -translate-x-1/2 mt-1 px-1.5 py-0.5 rounded bg-popover text-popover-foreground text-[9px] font-medium shadow-md border border-border/40 whitespace-nowrap opacity-0 group-hover/ms:opacity-100 transition-opacity pointer-events-none z-30">
                {ms.def.label}
              </span>
            </div>
          ))}

          {/* Today line — same w-px bg-primary as portfolio Gantt */}
          {todayInPhase && (
            <div
              className="absolute -top-2 bottom-0 w-px bg-primary z-20 pointer-events-none"
              style={{ left: `${todayPctLocal}%` }}
              aria-label="Today's date marker"
            />
          )}
        </div>

        {todayInPhase && (
          <div className="relative mt-1 h-3">
            <div
              className="absolute -translate-x-1/2 text-[10px] font-semibold text-primary tabular-nums"
              style={{ left: `${todayPctLocal}%` }}
            >
              Today · {todayLabel}
            </div>
          </div>
        )}
      </div>
      {/* Sub-widget: Milestone Dates */}
      {(() => {
        const phaseNames = phases.map((p) => p.name);
        const idx = phaseNames.indexOf(currentPhaseName);
        const prevName = idx > 0 ? phaseNames[idx - 1] : currentPhaseName;
        const nextName = idx >= 0 && idx < phaseNames.length - 1 ? phaseNames[idx + 1] : currentPhaseName;
        const prevSpan = phaseTimelineDates[prevName];
        const nextSpan = phaseTimelineDates[nextName];
        const rangeStart = (prevSpan ?? phaseSpan).start.getTime();
        const rangeEnd = (nextSpan ?? phaseSpan).end.getTime();
        const rows: { def: MilestoneDef; date: Date }[] = [];
        for (const def of MILESTONES) {
          const d = computeMilestoneDate(def, phaseTimelineDates);
          if (!d) continue;
          const t = d.getTime();
          if (t >= rangeStart && t <= rangeEnd) rows.push({ def, date: d });
        }
        rows.sort((a, b) => a.date.getTime() - b.date.getTime());

        return (
          <div className="border-t border-border px-4 py-3">
            <h5 className="text-xs font-semibold text-foreground mb-2">Milestone Dates</h5>
            {rows.length === 0 ? (
              <div className="text-[11px] text-muted-foreground italic">N/A — no milestones in this phase</div>
            ) : (
              <div className="divide-y divide-border/60">
                {rows.map((r) => (
                  <div key={r.def.short} className="flex items-center gap-2 py-1.5">
                    <div className="w-1.5 h-1.5 rotate-45 bg-purple-500 shrink-0" />
                    <span className="text-[11px] text-foreground flex-1 truncate">
                      <span className="font-semibold">{r.def.short}</span>
                      <span className="text-muted-foreground"> — {r.def.label}</span>
                    </span>
                    <span className="text-[11px] text-foreground tabular-nums">{formatDate(r.date)}</span>
                  </div>
                ))}
              </div>
            )}
          </div>
        );
      })()}

      {/* Sub-widget: Outcome-based Subprocesses */}
      {(() => {
        const currentPhaseObj = phases.find((p) => p.name === currentPhaseName);
        const milestones = currentPhaseObj?.milestones ?? [];

        return (
          <div className="border-t border-border px-4 py-3">
            <h5 className="text-xs font-semibold text-foreground mb-2">Outcome-based Subprocesses</h5>
            {milestones.length === 0 ? (
              <div className="text-[11px] text-muted-foreground italic">No subprocesses defined for this phase.</div>
            ) : (
              <div className="divide-y divide-border/60">
                {milestones.map((m) => {
                  const status = computeRollupStatus(m.tasks);
                  const done = m.tasks.filter((t) => t.status === "completed").length;
                  const total = m.tasks.length;
                  return (
                    <div key={m.name} className="flex items-center gap-2 py-1.5">
                      <div className={cn("w-2 h-2 rotate-45 shrink-0", statusDotColors[status])} />
                      <span className={cn("text-[11px] font-medium flex-1 truncate", statusTextColors[status])}>
                        {m.name}
                      </span>
                      <span className="text-[10px] text-muted-foreground tabular-nums">
                        {done} of {total} tasks
                      </span>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        );
      })()}
    </div>
  );
};

export default PhaseExitTrackerWidget;
