import { motion } from "framer-motion";
import { cn } from "@/lib/utils";

export interface PhaseBucket {
  phase: string;
  onTrack: number;
  atRisk: number;
  delayed: number;
}

interface Props {
  data: PhaseBucket[];
  onPhaseClick?: (phase: string) => void;
}

const PhaseGateBarChart = ({ data, onPhaseClick }: Props) => {
  const max = Math.max(1, ...data.map(d => d.onTrack + d.atRisk + d.delayed));

  return (
    <div className="space-y-3">
      <div className="flex items-end justify-between gap-3 h-48 px-2">
        {data.map((d) => {
          const total = d.onTrack + d.atRisk + d.delayed;
          const heightPct = (total / max) * 100;
          return (
            <button
              key={d.phase}
              onClick={() => onPhaseClick?.(d.phase)}
              className="flex-1 flex flex-col items-center gap-1.5 group"
            >
              <span className="text-[10px] font-bold text-foreground tabular-nums">{total || ""}</span>
              <div className="w-full max-w-[44px] flex flex-col-reverse rounded-md overflow-hidden border border-border/40 bg-muted/20" style={{ height: `${Math.max(heightPct, 4)}%`, minHeight: 8 }}>
                {d.onTrack > 0 && (
                  <motion.div initial={{ height: 0 }} animate={{ height: `${(d.onTrack/total)*100}%` }} transition={{ duration: 0.5 }} className="bg-success w-full" />
                )}
                {d.atRisk > 0 && (
                  <motion.div initial={{ height: 0 }} animate={{ height: `${(d.atRisk/total)*100}%` }} transition={{ duration: 0.5, delay: 0.1 }} className="bg-warning w-full" />
                )}
                {d.delayed > 0 && (
                  <motion.div initial={{ height: 0 }} animate={{ height: `${(d.delayed/total)*100}%` }} transition={{ duration: 0.5, delay: 0.2 }} className="bg-destructive w-full" />
                )}
              </div>
              <span className={cn("text-[9px] font-semibold uppercase tracking-wide text-muted-foreground group-hover:text-foreground transition-colors text-center leading-tight")}>{d.phase}</span>
            </button>
          );
        })}
      </div>
      <div className="flex items-center justify-center gap-4 pt-2 border-t border-border/30">
        {[
          { c: "bg-success", l: "On Track" },
          { c: "bg-warning", l: "At Risk w/ Mitigation" },
          { c: "bg-destructive", l: "At Risk w/ No Plan" },
        ].map(s => (
          <div key={s.l} className="flex items-center gap-1.5">
            <span className={cn("w-2 h-2 rounded-full", s.c)} />
            <span className="text-[9px] text-muted-foreground font-medium">{s.l}</span>
          </div>
        ))}
      </div>
    </div>
  );
};

export default PhaseGateBarChart;
