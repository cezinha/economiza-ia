import { useMemo, useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { z } from "zod";
import { Dialog, DialogContent, DialogTitle } from "@/components/ui/dialog";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";
import { motion } from "framer-motion";
import { FileText, ExternalLink, Plus, Trash2, Save } from "lucide-react";
import { programs, getProgramStatus, type Program, type ProgramStatus } from "./ProgramOverviewTimeline";
import { PLATFORM_LOB } from "@/contexts/UniversalFilterContext";
import { usePhaseGateReports, type LobKey, type RiskRow, type ReportEdits } from "@/contexts/PhaseGateReportContext";
import PhaseGateBarChart, { type PhaseBucket } from "./PhaseGateBarChart";
import { setReportReturn } from "@/hooks/use-report-return";

const REPORT_PHASES = ["Concept", "Define", "Plan", "Qual", "Pilot", "Ramp"] as const;

const PHASE_ALIAS: Record<string, typeof REPORT_PHASES[number]> = {
  Concept: "Concept",
  Define: "Define",
  Plan: "Plan",
  Develop: "Qual",
  Qual: "Qual",
  Pilot: "Pilot",
  Ramp: "Ramp",
  Launch: "Ramp",
  Incubate: "Concept",
};

const STATUS_LABEL: Record<ProgramStatus, string> = {
  "on-track": "Green",
  "at-risk": "Yellow",
  "delayed": "Red",
};
const STATUS_DOT: Record<ProgramStatus, string> = {
  "on-track": "bg-success",
  "at-risk": "bg-warning",
  "delayed": "bg-destructive",
};

// ── Validation ──
const riskSchema = z.object({
  id: z.string(),
  phase: z.string().trim().min(1, "Phase required").max(60),
  status: z.enum(["on-track", "at-risk", "delayed"]),
  platform: z.string().trim().min(1, "Platform required").max(80),
  issue: z.string().trim().max(300, "Issue must be ≤ 300 chars"),
  impact: z.string().trim().max(300, "Impact must be ≤ 300 chars"),
  mitigation: z.string().trim().max(500, "Mitigation must be ≤ 500 chars"),
  owner: z.string().trim().max(80, "Owner must be ≤ 80 chars"),
  target: z.string().trim().max(80, "Target must be ≤ 80 chars"),
});
const editsSchema = z.object({
  summaryBullets: z.array(z.string().trim().min(1, "Bullet cannot be empty").max(400)).max(10),
  risks: z.array(riskSchema).max(50),
});

interface Props {
  lob: LobKey;
  mode: "view" | "generate";
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

const PhaseGateReportDialog = ({ lob, mode, open, onOpenChange }: Props) => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const { submitReport, saveDraft, getReport } = usePhaseGateReports();
  const [confirmOpen, setConfirmOpen] = useState(false);
  const record = getReport(lob);
  const isEditable = mode === "generate";

  const lobPrograms: Program[] = useMemo(
    () => programs.filter(p => !p.archived && PLATFORM_LOB[p.name] === lob),
    [lob]
  );

  const programCurrentPhase = (p: Program): typeof REPORT_PHASES[number] | null => {
    const active = p.phases.find(ph => ph.status !== "complete");
    const target = active ?? p.phases[p.phases.length - 1];
    return PHASE_ALIAS[target.name] ?? null;
  };

  const buckets: PhaseBucket[] = useMemo(() => {
    const map: Record<string, PhaseBucket> = {};
    REPORT_PHASES.forEach(ph => { map[ph] = { phase: ph, onTrack: 0, atRisk: 0, delayed: 0 }; });
    lobPrograms.forEach(p => {
      const ph = programCurrentPhase(p);
      if (!ph) return;
      const s = getProgramStatus(p);
      if (s === "on-track") map[ph].onTrack++;
      else if (s === "at-risk") map[ph].atRisk++;
      else map[ph].delayed++;
    });
    return REPORT_PHASES.map(ph => map[ph]);
  }, [lobPrograms]);

  const totals = useMemo(() => {
    let g = 0, y = 0, r = 0;
    lobPrograms.forEach(p => {
      const s = getProgramStatus(p);
      if (s === "on-track") g++; else if (s === "at-risk") y++; else r++;
    });
    return { g, y, r, total: lobPrograms.length };
  }, [lobPrograms]);

  // Auto-generated defaults
  const defaultBullets = useMemo<string[]>(() => {
    const bullets: string[] = [];
    bullets.push(`${totals.g} of ${totals.total} ${lob} platforms are on track to meet phase gate exit criteria.`);
    bullets.push(`${totals.y} platform${totals.y === 1 ? "" : "s"} flagged at risk with active mitigation plans.`);
    bullets.push(`${totals.r} platform${totals.r === 1 ? "" : "s"} at risk without a recovery plan — escalation required.`);
    return bullets;
  }, [totals, lob]);

  const defaultRisks = useMemo<RiskRow[]>(() => {
    return lobPrograms
      .filter(p => getProgramStatus(p) !== "on-track")
      .map(p => {
        const s = getProgramStatus(p);
        const ph = programCurrentPhase(p) ?? "—";
        return {
          id: p.name,
          phase: ph,
          status: s,
          platform: p.name,
          issue: s === "delayed" ? "Schedule slip with no recovery path" : "Schedule risk with mitigation in flight",
          impact: s === "delayed" ? "RTS at risk; revenue exposure" : "POR achievable with action",
          mitigation: s === "delayed" ? "Recovery plan pending — escalation required" : "Mitigation plan tracked weekly",
          owner: "Program Mgr",
          target: "Next phase gate",
        };
      });
  }, [lobPrograms]);

  // ── Editable state, hydrated from saved edits or defaults ──
  const [bullets, setBullets] = useState<string[]>(record.edits?.summaryBullets ?? defaultBullets);
  const [risks, setRisks] = useState<RiskRow[]>(record.edits?.risks ?? defaultRisks);
  const [errors, setErrors] = useState<Record<string, string>>({});

  // Reset local state when reopened or lob changes
  useEffect(() => {
    if (open) {
      setBullets(record.edits?.summaryBullets ?? defaultBullets);
      setRisks(record.edits?.risks ?? defaultRisks);
      setErrors({});
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, lob]);

  // Drill-throughs
  const drillTo = (path: string) => {
    setReportReturn({ lob, mode });
    onOpenChange(false);
    navigate(path);
  };

  // Edit helpers
  const updateBullet = (i: number, v: string) => setBullets(b => b.map((x, idx) => idx === i ? v : x));
  const removeBullet = (i: number) => setBullets(b => b.filter((_, idx) => idx !== i));
  const addBullet = () => setBullets(b => [...b, "New summary point"]);

  const updateRisk = (id: string, patch: Partial<RiskRow>) =>
    setRisks(rs => rs.map(r => r.id === id ? { ...r, ...patch } : r));
  const removeRisk = (id: string) => setRisks(rs => rs.filter(r => r.id !== id));
  const addRisk = () => setRisks(rs => [...rs, {
    id: `custom-${Date.now()}`,
    phase: "Plan",
    status: "at-risk",
    platform: "",
    issue: "",
    impact: "",
    mitigation: "",
    owner: "",
    target: "",
  }]);

  const validate = (): ReportEdits | null => {
    const candidate = { summaryBullets: bullets, risks };
    const result = editsSchema.safeParse(candidate);
    if (!result.success) {
      const fieldErrors: Record<string, string> = {};
      result.error.issues.forEach(issue => {
        fieldErrors[issue.path.join(".")] = issue.message;
      });
      setErrors(fieldErrors);
      toast({
        title: "Please fix validation errors",
        description: result.error.issues[0]?.message ?? "Invalid input",
        variant: "destructive",
      });
      return null;
    }
    setErrors({});
    return result.data;
  };

  const handleSaveDraft = () => {
    const edits = validate();
    if (!edits) return;
    saveDraft(lob, edits);
    toast({ title: "Draft saved", description: `${lob} report edits saved locally.` });
  };

  const handleSubmit = () => {
    const edits = validate();
    if (!edits) return;
    setConfirmOpen(true);
  };
  const confirmSubmit = () => {
    const edits = validate();
    if (!edits) { setConfirmOpen(false); return; }
    submitReport(lob, edits);
    setConfirmOpen(false);
    onOpenChange(false);
    toast({ title: "Report submitted", description: `${lob} report shared with Executives.` });
  };

  const formatDate = (iso?: string) => iso ? new Date(iso).toLocaleString() : "—";

  return (
    <>
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent className="max-w-5xl max-h-[90vh] overflow-y-auto p-0 gap-0">
          {/* Header bar — Dell Blue */}
          <div className="bg-[hsl(var(--primary))] text-primary-foreground px-6 py-4 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <FileText className="w-5 h-5" />
              <DialogTitle className="text-[18px] font-extrabold tracking-tight text-primary-foreground">
                {lob} Phase Gate Status
              </DialogTitle>
            </div>
            <div className="text-[10px] font-semibold uppercase tracking-wider opacity-80">
              {isEditable ? "Editing — Super Admin" : record.submitted ? `Submitted ${formatDate(record.submittedAt)}` : "Preview"}
            </div>
          </div>

          <div className="p-6 space-y-5">
            {/* Top row: chart + summary */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
              <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="rounded-2xl border border-border/40 p-4 bg-card">
                <div className="flex items-center justify-between mb-3">
                  <h4 className="text-[13px] font-extrabold text-foreground">Phase Distribution</h4>
                  <button onClick={() => drillTo("/")} className="text-[10px] font-bold text-primary hover:underline inline-flex items-center gap-1">
                    Open Schedule <ExternalLink className="w-3 h-3" />
                  </button>
                </div>
                <PhaseGateBarChart data={buckets} onPhaseClick={() => drillTo("/")} />
              </motion.div>

              <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.05 }} className="rounded-2xl border border-border/40 p-4 bg-card">
                <div className="flex items-center justify-between mb-3">
                  <h4 className="text-[13px] font-extrabold text-foreground">Executive Summary</h4>
                  {isEditable && (
                    <Button size="sm" variant="outline" onClick={addBullet} className="h-7 px-2 text-[11px]">
                      <Plus className="w-3 h-3" /> Add bullet
                    </Button>
                  )}
                </div>

                {bullets.length === 0 && !isEditable && (
                  <p className="text-[12px] text-muted-foreground italic">No summary points.</p>
                )}

                <ul className="space-y-2 text-[12px] text-foreground/80">
                  {bullets.map((b, i) => (
                    <li key={i} className="flex gap-2 items-start">
                      <span className="w-1.5 h-1.5 rounded-full bg-primary mt-2 shrink-0" />
                      {isEditable ? (
                        <div className="flex-1 flex gap-1.5 items-start">
                          <div className="flex-1">
                            <Textarea
                              value={b}
                              onChange={(e) => updateBullet(i, e.target.value)}
                              maxLength={400}
                              rows={2}
                              className={cn("text-[12px] min-h-[44px] resize-none", errors[`summaryBullets.${i}`] && "border-destructive")}
                            />
                            {errors[`summaryBullets.${i}`] && (
                              <p className="text-[10px] text-destructive mt-1">{errors[`summaryBullets.${i}`]}</p>
                            )}
                          </div>
                          <button
                            onClick={() => removeBullet(i)}
                            className="p-1.5 text-muted-foreground hover:text-destructive rounded-md hover:bg-muted transition-colors"
                            aria-label="Remove bullet"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      ) : (
                        <span>{b}</span>
                      )}
                    </li>
                  ))}
                </ul>

                {!isEditable && (
                  <button
                    onClick={() => drillTo("/platform-summary")}
                    className="mt-4 text-[11px] font-bold text-primary hover:underline inline-flex items-center gap-1"
                  >
                    View Platform Summary <ExternalLink className="w-3 h-3" />
                  </button>
                )}
              </motion.div>
            </div>

            {/* Risk table */}
            <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }} className="rounded-2xl border border-border/40 bg-card overflow-hidden">
              <div className="px-4 py-3 border-b border-border/30 flex items-center justify-between">
                <h4 className="text-[13px] font-extrabold text-foreground">Risks &amp; Mitigations</h4>
                <div className="flex items-center gap-2">
                  <span className="text-[10px] text-muted-foreground tabular-nums">{risks.length} risk{risks.length === 1 ? "" : "s"}</span>
                  {isEditable && (
                    <Button size="sm" variant="outline" onClick={addRisk} className="h-7 px-2 text-[11px]">
                      <Plus className="w-3 h-3" /> Add row
                    </Button>
                  )}
                </div>
              </div>
              {risks.length === 0 ? (
                <div className="p-6 text-center text-[12px] text-muted-foreground italic">No active risks for this LOB.</div>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="text-[10px] uppercase">Phase</TableHead>
                      <TableHead className="text-[10px] uppercase">RYG</TableHead>
                      <TableHead className="text-[10px] uppercase">Platform</TableHead>
                      <TableHead className="text-[10px] uppercase">Issue</TableHead>
                      <TableHead className="text-[10px] uppercase">Impact</TableHead>
                      <TableHead className="text-[10px] uppercase">Mitigation</TableHead>
                      <TableHead className="text-[10px] uppercase">Owner / Target</TableHead>
                      {isEditable && <TableHead className="w-8" />}
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {risks.map((r, idx) => (
                      <TableRow key={r.id} className="text-[12px] align-top">
                        {/* Phase */}
                        <TableCell className="font-medium">
                          {isEditable ? (
                            <Select value={r.phase} onValueChange={(v) => updateRisk(r.id, { phase: v })}>
                              <SelectTrigger className="h-8 text-[11px] w-[130px]"><SelectValue /></SelectTrigger>
                              <SelectContent>
                                {REPORT_PHASES.map(ph => <SelectItem key={ph} value={ph} className="text-[11px]">{ph}</SelectItem>)}
                              </SelectContent>
                            </Select>
                          ) : r.phase}
                        </TableCell>
                        {/* Status */}
                        <TableCell>
                          {isEditable ? (
                            <Select value={r.status} onValueChange={(v) => updateRisk(r.id, { status: v as ProgramStatus })}>
                              <SelectTrigger className="h-8 text-[11px] w-[110px]">
                                <span className="inline-flex items-center gap-1.5">
                                  <span className={cn("w-2 h-2 rounded-full", STATUS_DOT[r.status])} />
                                  {STATUS_LABEL[r.status]}
                                </span>
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="on-track" className="text-[11px]">Green</SelectItem>
                                <SelectItem value="at-risk" className="text-[11px]">Yellow</SelectItem>
                                <SelectItem value="delayed" className="text-[11px]">Red</SelectItem>
                              </SelectContent>
                            </Select>
                          ) : (
                            <span className="inline-flex items-center gap-1.5">
                              <span className={cn("w-2 h-2 rounded-full", STATUS_DOT[r.status])} />
                              <span className="text-[11px] font-semibold">{STATUS_LABEL[r.status]}</span>
                            </span>
                          )}
                        </TableCell>
                        {/* Platform */}
                        <TableCell>
                          {isEditable ? (
                            <Input
                              value={r.platform}
                              onChange={(e) => updateRisk(r.id, { platform: e.target.value })}
                              maxLength={80}
                              className={cn("h-8 text-[11px] w-[110px]", errors[`risks.${idx}.platform`] && "border-destructive")}
                            />
                          ) : (
                            <button
                              onClick={() => drillTo(`/platform-summary?platform=${encodeURIComponent(r.platform)}`)}
                              className="text-primary font-bold hover:underline"
                            >
                              {r.platform}
                            </button>
                          )}
                        </TableCell>
                        {/* Issue */}
                        <TableCell className="text-foreground/80">
                          {isEditable ? (
                            <Textarea value={r.issue} onChange={(e) => updateRisk(r.id, { issue: e.target.value })} maxLength={300} rows={2} className="text-[11px] min-h-[40px] resize-none w-[180px]" />
                          ) : r.issue}
                        </TableCell>
                        {/* Impact */}
                        <TableCell className="text-foreground/80">
                          {isEditable ? (
                            <Textarea value={r.impact} onChange={(e) => updateRisk(r.id, { impact: e.target.value })} maxLength={300} rows={2} className="text-[11px] min-h-[40px] resize-none w-[180px]" />
                          ) : r.impact}
                        </TableCell>
                        {/* Mitigation */}
                        <TableCell>
                          {isEditable ? (
                            <Textarea value={r.mitigation} onChange={(e) => updateRisk(r.id, { mitigation: e.target.value })} maxLength={500} rows={2} className="text-[11px] min-h-[40px] resize-none w-[200px]" />
                          ) : (
                            <button
                              onClick={() => drillTo(`/schedule?platform=${encodeURIComponent(r.platform)}`)}
                              className="text-left text-foreground/80 hover:text-primary hover:underline"
                            >
                              {r.mitigation}
                            </button>
                          )}
                        </TableCell>
                        {/* Owner / Target */}
                        <TableCell className="text-foreground/80">
                          {isEditable ? (
                            <div className="flex flex-col gap-1 w-[140px]">
                              <Input value={r.owner} placeholder="Owner" onChange={(e) => updateRisk(r.id, { owner: e.target.value })} maxLength={80} className="h-7 text-[11px]" />
                              <Input value={r.target} placeholder="Target" onChange={(e) => updateRisk(r.id, { target: e.target.value })} maxLength={80} className="h-7 text-[11px]" />
                            </div>
                          ) : (
                            <span>{r.owner} <span className="text-muted-foreground">· {r.target}</span></span>
                          )}
                        </TableCell>
                        {isEditable && (
                          <TableCell>
                            <button
                              onClick={() => removeRisk(r.id)}
                              className="p-1.5 text-muted-foreground hover:text-destructive rounded-md hover:bg-muted transition-colors"
                              aria-label="Remove row"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </TableCell>
                        )}
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </motion.div>
          </div>

          {/* Footer */}
          <div className="px-6 py-4 border-t border-border/40 bg-muted/20 flex items-center justify-between">
            <div className="text-[10px] text-muted-foreground">
              {isEditable
                ? "Edits are auto-applied to the report shared with Executives."
                : `Auto-generated · ${new Date().toLocaleDateString()}`}
            </div>
            <div className="flex items-center gap-2">
              <Button variant="outline" size="sm" onClick={() => onOpenChange(false)}>
                {isEditable ? "Cancel" : "Close"}
              </Button>
              {isEditable ? (
                <>
                  <Button variant="secondary" size="sm" onClick={handleSaveDraft}>
                    <Save className="w-3.5 h-3.5" /> Save Draft
                  </Button>
                  <Button size="sm" onClick={handleSubmit}>
                    {record.submitted ? "Resubmit to Executives" : "Submit to Executives"}
                  </Button>
                </>
              ) : (
                <Button size="sm" onClick={() => window.print()}>Download PDF</Button>
              )}
            </div>
          </div>
        </DialogContent>
      </Dialog>

      <AlertDialog open={confirmOpen} onOpenChange={setConfirmOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Share {lob} report with Executives?</AlertDialogTitle>
            <AlertDialogDescription>
              Your edits will be published as the official Phase Gate Status report. Executives will be able to view it immediately. You can resubmit later to publish updates.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={confirmSubmit}>Submit</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
};

export default PhaseGateReportDialog;
