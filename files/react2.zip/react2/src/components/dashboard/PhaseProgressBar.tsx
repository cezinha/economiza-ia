import { useMemo } from "react";
import { motion } from "framer-motion";
import { cn } from "@/lib/utils";
import { Check } from "lucide-react";
import { programSchedules, getEffectiveTaskStatus } from "@/data/scheduleData";
import { getCurrentPhaseByDate } from "@/components/dashboard/PortfolioScheduleGantt";

// Canonical phase names (must match programSchedules + platformPhaseTimelines)
const CANONICAL_PHASES = [
  { name: "Concept", short: "Concept" },
  { name: "Define", short: "Define" },
  { name: "Plan", short: "Plan" },
  { name: "Qual", short: "Qual" },
  { name: "Pilot", short: "Pilot" },
  { name: "Ramp", short: "Ramp" },
] as const;

interface PhaseProgressBarProps {
  programName?: string;
}

const PhaseProgressBar = ({ programName = "Laptop 1" }: PhaseProgressBarProps) => {
  const { phases, currentPhaseIndex, currentPhaseName, currentPct } = useMemo(() => {
    const schedule = programSchedules[programName] || programSchedules["Laptop 1"] || [];
    const byName = new Map(schedule.map((p) => [p.name, p]));

    const computed = CANONICAL_PHASES.map(({ name, short }) => {
      const phase = byName.get(name);
      const tasks = phase?.milestones.flatMap((m) => m.tasks) ?? [];
      const total = tasks.length;
      const completed = tasks.filter(
        (t) => getEffectiveTaskStatus(t) === "completed",
      ).length;
      const pct = total === 0 ? 0 : Math.round((completed / total) * 100);
      return { name, short, pct };
    });

    const currentName = getCurrentPhaseByDate(programName);
    const idx = Math.max(
      0,
      CANONICAL_PHASES.findIndex((p) => p.name === currentName),
    );
    return {
      phases: computed,
      currentPhaseIndex: idx,
      currentPhaseName: CANONICAL_PHASES[idx]?.name ?? "Concept",
      currentPct: computed[idx]?.pct ?? 0,
    };
  }, [programName]);

  return (
    <div className="card-elevated rounded-2xl p-6 w-full">
      <div className="flex items-center gap-1">
        {phases.map((phase, i) => {
          const isComplete = phase.pct === 100;
          const isCurrent = i === currentPhaseIndex;

          return (
            <div key={phase.name} className="flex-1 flex flex-col items-center relative">
              <span
                className={cn(
                  "text-[10px] font-bold mb-2.5 uppercase tracking-wider",
                  isCurrent ? "text-primary" : isComplete ? "text-foreground/70" : "text-muted-foreground/30"
                )}
              >
                {phase.short}
              </span>

              <div className="relative w-full h-2.5 rounded-full overflow-hidden bg-muted/20">
                <motion.div
                  className={cn(
                    "absolute inset-y-0 left-0 rounded-full",
                    isCurrent
                      ? "bg-gradient-to-r from-primary/80 to-primary"
                      : isComplete
                      ? "bg-primary/60"
                      : "bg-transparent"
                  )}
                  initial={{ width: 0 }}
                  animate={{ width: `${phase.pct}%` }}
                  transition={{ duration: 0.8, ease: [0.25, 0.1, 0.25, 1], delay: i * 0.08 }}
                />
              </div>

              <span
                className={cn(
                  "text-[10px] mt-2 font-bold tabular-nums",
                  isCurrent ? "text-primary" : isComplete ? "text-foreground/50" : "text-muted-foreground/20"
                )}
              >
                {isComplete ? (
                  <span className="flex items-center gap-1">
                    <Check className="w-3 h-3 text-success" />
                    Done
                  </span>
                ) : (
                  `${phase.pct}%`
                )}
              </span>

              {isCurrent && (
                <motion.div
                  layoutId="phase-marker"
                  className="absolute top-[28px] w-4 h-4 bg-primary rounded-full border-[2.5px] border-card shadow-md z-10 animate-phase-pulse"
                />
              )}
            </div>
          );
        })}
      </div>
      <div className="flex justify-between items-center mt-5 pt-3.5 border-t border-border/20">
        <span className="text-[11px] text-muted-foreground">
          Current: <span className="text-foreground font-bold">{currentPhaseName} Phase</span>
        </span>
        <span className="text-[12px] font-black text-primary tabular-nums">{currentPct}% Complete</span>
      </div>
    </div>
  );
};

export default PhaseProgressBar;
