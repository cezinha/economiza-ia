import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { usePlatform } from "@/contexts/PlatformContext";

const PlatformFilterBar = () => {
  const { selectedPlatform, setSelectedPlatform, programs } = usePlatform();

  return (
    <Select
      value={selectedPlatform ?? "portfolio"}
      onValueChange={(v) => setSelectedPlatform(v === "portfolio" ? null : v)}
    >
      <SelectTrigger className="w-[160px] h-8 text-xs">
        <SelectValue />
      </SelectTrigger>
      <SelectContent>
        <SelectItem value="portfolio">Portfolio</SelectItem>
        {programs.map((p) => (
          <SelectItem key={p} value={p}>{p}</SelectItem>
        ))}
      </SelectContent>
    </Select>
  );
};

export default PlatformFilterBar;
