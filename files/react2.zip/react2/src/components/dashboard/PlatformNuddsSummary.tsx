import { useMemo } from "react";
import { useNavigate } from "react-router-dom";
import { ShieldAlert, ChevronRight, AlertTriangle, AlertCircle, CircleDot, Layers } from "lucide-react";
import { cn } from "@/lib/utils";
import {
  getNuddsForPlatform,
  PHASES_ORDER,
  phaseMap,
  type EnrichedNudd,
} from "@/data/nuddsData";

interface PlatformNuddsSummaryProps {
  platform: string;
}

const riskPillClass = (lvl: "H" | "M" | "L"): string => {
  if (lvl === "H") return "bg-destructive/10 text-destructive border-destructive/30";
  if (lvl === "M") return "bg-warning/15 text-warning border-warning/40";
  return "bg-success/10 text-success border-success/30";
};

const statusPillClass = (status: EnrichedNudd["status"]): string => {
  if (status === "Open") return "bg-indigo-500/10 text-indigo-700 dark:text-indigo-300 border-indigo-500/30";
  if (status === "On Hold") return "bg-muted text-muted-foreground border-border";
  return "bg-success/10 text-success border-success/30";
};

const PlatformNuddsSummary = ({ platform }: PlatformNuddsSummaryProps) => {
  const navigate = useNavigate();

  const nudds = useMemo(
    () => getNuddsForPlatform(platform).filter((n) => n.status !== "Completed"),
    [platform],
  );

  const total = nudds.length;
  const highCount = nudds.filter((n) => n.overallRiskLevel === "H").length;
  const medCount = nudds.filter((n) => n.overallRiskLevel === "M").length;
  const openCount = nudds.filter((n) => n.status === "Open").length;

  const phaseDistribution = useMemo(() => {
    const map: Record<string, { low: number; med: number; high: number; total: number }> = {};
    PHASES_ORDER.forEach((p) => { map[p] = { low: 0, med: 0, high: 0, total: 0 }; });
    nudds.forEach((n) => {
      const p = phaseMap(n.goeOlpPhase) as string;
      if (!map[p]) return;
      if (n.overallRiskLevel === "H") map[p].high++;
      else if (n.overallRiskLevel === "M") map[p].med++;
      else map[p].low++;
      map[p].total++;
    });
    return PHASES_ORDER.map((p) => ({ phase: p, ...map[p] }));
  }, [nudds]);

  const maxPhaseTotal = Math.max(1, ...phaseDistribution.map((d) => d.total));

  const top3 = useMemo(
    () => [...nudds].sort((a, b) => b.riskPriority - a.riskPriority).slice(0, 3),
    [nudds],
  );

  const goToNuddRow = (focusId: string) => {
    navigate("/nudds", { state: { platform, focusId } });
  };

  return (
    <section className="rounded-2xl bg-card border border-border/60 shadow-[var(--card-shadow,0_1px_2px_rgba(0,0,0,0.04))] overflow-hidden">
      {/* Header */}
      <header className="flex items-center gap-2.5 px-5 py-3.5 border-b border-border/50 bg-gradient-to-r from-[hsl(var(--mds-blue))]/[0.04] to-transparent">
        <div className="w-8 h-8 rounded-lg bg-[hsl(var(--mds-blue))]/10 flex items-center justify-center">
          <ShieldAlert className="w-4 h-4 text-[hsl(var(--mds-blue))]" />
        </div>
        <div className="flex-1 min-w-0">
          <h4 className="text-sm font-bold tracking-tight text-foreground leading-tight">
            NUDDs Impacting {platform}
          </h4>
          <p className="text-[11px] text-muted-foreground leading-tight">
            Active (non-completed) Notable Unresolved Design / Delivery / Discovery items linked to this platform
          </p>
        </div>
      </header>

      {total === 0 ? (
        <div className="px-5 py-8 flex flex-col items-center justify-center gap-2 text-center">
          <div className="w-10 h-10 rounded-full bg-success/10 flex items-center justify-center">
            <CircleDot className="w-5 h-5 text-success" />
          </div>
          <p className="text-sm font-medium text-foreground">No active NUDDs impact {platform}</p>
          <p className="text-[11px] text-muted-foreground">All open NUDDs have been resolved or none are linked to this platform.</p>
        </div>
      ) : (
        <div className="p-5 space-y-5">
          {/* KPI strip */}
          <div className="grid grid-cols-4 gap-3">
            <KpiTile icon={Layers} label="Total" value={total} tone="neutral" />
            <KpiTile icon={AlertTriangle} label="High Risk" value={highCount} tone="danger" />
            <KpiTile icon={AlertCircle} label="Medium" value={medCount} tone="warning" />
            <KpiTile icon={CircleDot} label="Open" value={openCount} tone="info" />
          </div>

          {/* Phase distribution — true horizontal bars */}
          <div>
            <div className="flex items-baseline justify-between mb-2">
              <p className="text-[11px] uppercase tracking-wider text-muted-foreground font-bold">
                Distribution by Phase
              </p>
              <div className="flex items-center gap-3">
                <LegendDot className="bg-destructive" label="High" />
                <LegendDot className="bg-warning" label="Med" />
                <LegendDot className="bg-success" label="Low" />
              </div>
            </div>
            <div className="space-y-1.5">
              {phaseDistribution.map((d) => {
                const widthPct = (d.total / maxPhaseTotal) * 100;
                const seg = (n: number) => (d.total === 0 ? 0 : (n / d.total) * 100);
                return (
                  <div key={d.phase} className="flex items-center gap-3">
                    <span className="text-[10.5px] font-semibold uppercase tracking-wide text-muted-foreground w-[120px] shrink-0 truncate">
                      {d.phase}
                    </span>
                    <div className="flex-1 h-5 bg-muted/40 rounded-md overflow-hidden flex">
                      {d.total > 0 && (
                        <div
                          className="h-full flex transition-all"
                          style={{ width: `${Math.max(widthPct, 4)}%` }}
                          title={`${d.phase}: ${d.total} (H ${d.high} · M ${d.med} · L ${d.low})`}
                        >
                          {d.high > 0 && <div className="bg-destructive h-full" style={{ width: `${seg(d.high)}%` }} />}
                          {d.med > 0 && <div className="bg-warning h-full" style={{ width: `${seg(d.med)}%` }} />}
                          {d.low > 0 && <div className="bg-success h-full" style={{ width: `${seg(d.low)}%` }} />}
                        </div>
                      )}
                    </div>
                    <span className="text-[11px] font-bold text-foreground tabular-nums w-6 text-right">
                      {d.total}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Top NUDDs list */}
          <div>
            <p className="text-[11px] uppercase tracking-wider text-muted-foreground font-bold mb-2">
              Top NUDDs by Risk Priority
            </p>
            <div className="rounded-lg border border-border/60 overflow-hidden divide-y divide-border/40">
              {top3.map((n) => (
                <button
                  key={n.id}
                  type="button"
                  onClick={() => goToNuddRow(n.id)}
                  className="w-full flex items-center gap-3 px-3 py-2.5 hover:bg-[hsl(var(--mds-blue))]/[0.04] transition-colors text-left group"
                >
                  <span className={cn(
                    "h-5 w-5 rounded border text-[10px] font-bold inline-flex items-center justify-center shrink-0",
                    riskPillClass(n.overallRiskLevel),
                  )}>
                    {n.overallRiskLevel}
                  </span>
                  <span className="text-[10.5px] font-mono font-semibold text-muted-foreground shrink-0 w-[72px]">
                    {n.id}
                  </span>
                  <span className="flex-1 text-[12.5px] text-foreground truncate group-hover:text-[hsl(var(--mds-blue))] transition-colors">
                    {n.summary}
                  </span>
                  <span className={cn(
                    "h-5 w-16 rounded-full border text-[10px] font-semibold inline-flex items-center justify-center shrink-0",
                    statusPillClass(n.status),
                  )}>
                    {n.status}
                  </span>
                  <ChevronRight className="w-3.5 h-3.5 text-muted-foreground shrink-0 group-hover:text-[hsl(var(--mds-blue))] group-hover:translate-x-0.5 transition-all" />
                </button>
              ))}
            </div>
          </div>
        </div>
      )}
    </section>
  );
};

interface KpiTileProps {
  icon: React.ComponentType<{ className?: string }>;
  label: string;
  value: number;
  tone: "neutral" | "danger" | "warning" | "info";
}

const KpiTile = ({ icon: Icon, label, value, tone }: KpiTileProps) => {
  const styles = {
    neutral: { box: "border-border/60 bg-muted/30", icon: "bg-muted text-muted-foreground", value: "text-foreground" },
    danger:  { box: "border-destructive/25 bg-destructive/[0.04]", icon: "bg-destructive/10 text-destructive", value: "text-destructive" },
    warning: { box: "border-warning/35 bg-warning/[0.06]", icon: "bg-warning/15 text-warning", value: "text-warning" },
    info:    { box: "border-indigo-500/30 bg-indigo-500/[0.06]", icon: "bg-indigo-500/10 text-indigo-600 dark:text-indigo-300", value: "text-indigo-600 dark:text-indigo-300" },
  }[tone];
  return (
    <div className={cn("rounded-xl border px-3 py-2.5 flex items-center gap-3", styles.box)}>
      <div className={cn("w-8 h-8 rounded-lg flex items-center justify-center shrink-0", styles.icon)}>
        <Icon className="w-4 h-4" />
      </div>
      <div className="min-w-0">
        <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-bold leading-tight">
          {label}
        </p>
        <p className={cn("text-xl font-extrabold tabular-nums leading-tight", styles.value)}>{value}</p>
      </div>
    </div>
  );
};

const LegendDot = ({ className, label }: { className: string; label: string }) => (
  <span className="inline-flex items-center gap-1">
    <span className={cn("w-2 h-2 rounded-sm", className)} />
    <span className="text-[10px] text-muted-foreground">{label}</span>
  </span>
);

export default PlatformNuddsSummary;
