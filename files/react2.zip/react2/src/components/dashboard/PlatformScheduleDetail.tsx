import { useState, useCallback, useMemo, useEffect } from "react";
import { ChevronDown, ChevronRight, CalendarIcon, Pencil, AlertTriangle, Link2, ClipboardCheck, Zap } from "lucide-react";
import { programSchedules, phaseExitDates, type PhaseStatus, type TaskStatus, type ScheduleTask, computeRollupStatus, getCompletionSource, completionSourceLabel, getTaskDueLabel } from "@/data/scheduleData";
import { isAutoCompletedTask, getTaskParticipants } from "@/data/taskParticipants";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import TaskDetailModal from "@/components/dashboard/TaskDetailModal";
import { type TaskComment } from "@/components/dashboard/TaskDetailPanel";
import { taskMatchesFunction } from "@/components/dashboard/FunctionFilter";
import { type TaskPageFilterState, defaultTaskPageFilters } from "@/components/dashboard/TaskPageFilters";
import { phaseMatches } from "@/contexts/UniversalFilterContext";
import { cn } from "@/lib/utils";
import { format, addWeeks } from "date-fns";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Calendar as CalendarPicker } from "@/components/ui/calendar";
import { Button } from "@/components/ui/button";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import PhaseProgressBar from "@/components/dashboard/PhaseProgressBar";
import PhaseExitCriteria from "@/components/dashboard/PhaseExitCriteria";
import PlatformNuddsSummary from "@/components/dashboard/PlatformNuddsSummary";
import PhaseExitTrackerWidget from "@/components/dashboard/PhaseExitTrackerWidget";
import TaskChipStrip from "@/components/dashboard/TaskChipStrip";
import { motion } from "framer-motion";

const statusBarColors: Record<PhaseStatus, string> = {
  "on-track": "bg-green-500",
  "at-risk": "bg-yellow-500",
  "delayed": "bg-red-500",
  "not-started": "bg-muted-foreground/40",
};

const statusBorderColors: Record<PhaseStatus, string> = {
  "on-track": "border-green-500",
  "at-risk": "border-yellow-500",
  "delayed": "border-red-500",
  "not-started": "border-muted-foreground/40",
};

const statusDotColors: Record<PhaseStatus, string> = {
  "on-track": "bg-green-500",
  "at-risk": "bg-yellow-500",
  "delayed": "bg-red-500",
  "not-started": "bg-gray-400",
};

const statusTextColors: Record<PhaseStatus, string> = {
  "on-track": "text-green-700",
  "at-risk": "text-yellow-700",
  "delayed": "text-red-700",
  "not-started": "text-gray-500",
};

const statusLabels: Record<PhaseStatus, string> = {
  "on-track": "On Track",
  "at-risk": "At Risk w/ Mitigation",
  "delayed": "At Risk w/ No Plan",
  "not-started": "Not Started",
};

const statusBadgeVariants: Record<PhaseStatus, string> = {
  "on-track": "bg-green-100 text-green-800 border-green-200",
  "at-risk": "bg-yellow-100 text-yellow-800 border-yellow-200",
  "delayed": "bg-red-100 text-red-800 border-red-200",
  "not-started": "bg-gray-100 text-gray-600 border-gray-200",
};

const taskStatusBadge: Record<TaskStatus, string> = {
  completed: "bg-green-100 text-green-800 border-green-200",
  "on-track": "bg-green-100 text-green-800 border-green-200",
  "at-risk": "bg-yellow-100 text-yellow-800 border-yellow-200",
  pending: "bg-gray-100 text-gray-600 border-gray-200",
  late: "bg-red-100 text-red-800 border-red-200",
};

// ─── Task priority (deterministic per task id) ─────────────────────────────
type TaskPriority = "H" | "M" | "L";
const hashTaskId = (id: string): number => {
  let h = 0;
  for (let i = 0; i < id.length; i++) h = (h * 31 + id.charCodeAt(i)) | 0;
  return Math.abs(h);
};
const getTaskPriority = (id: string): TaskPriority => {
  const m = hashTaskId(id) % 10;
  if (m < 3) return "H";   // ~30%
  if (m < 7) return "M";   // ~40%
  return "L";              // ~30%
};
const priorityRank: Record<TaskPriority, number> = { H: 0, M: 1, L: 2 };
// Canonical chip styling — used by all task-row chips for visual consistency.
const BASE_CHIP = "h-5 px-1.5 text-[9px] font-semibold rounded border inline-flex items-center justify-center shrink-0 tabular-nums";
const NEUTRAL_CHIP = "bg-muted text-muted-foreground border-border";
const AUTO_CHIP = "bg-[hsl(var(--mds-blue))]/10 text-[hsl(var(--mds-blue))] border-[hsl(var(--mds-blue))]/30";

const getTaskFunction = (task: ScheduleTask): "GOE" | "NPI" | "SChM" | "Auto" => {
  if (isAutoCompletedTask(task)) return "Auto";
  if (task.owner.includes("GOE")) return "GOE";
  if (task.owner.includes("NPI")) return "NPI";
  if (task.owner.includes("SChM")) return "SChM";
  return "GOE";
};

// Status precedence: Red (late) → Yellow (at-risk) → Green (on-track) → Completed → Pending.
const statusRank: Record<TaskStatus, number> = {
  late: 0,
  "at-risk": 1,
  "on-track": 2,
  completed: 3,
  pending: 4,
};

// Within-phase task ordering (applied per milestone, which lives within one phase):
// 1. At-risk tasks (yellow `at-risk` + red `late`) bubble to the top
// 2. Due date: T-7 (earlier deadline) before T-14
// 3. Priority within same due: High → Medium → Low
// 4. Stable tiebreaker by task name
const dueRank = (id: string): number => (getTaskDueLabel(id) === "T-7" ? 0 : 1);
const atRiskRank = (status: TaskStatus): number =>
  status === "late" || status === "at-risk" ? 0 : 1;

const sortTasksForView = (tasks: ScheduleTask[]): ScheduleTask[] => {
  return [...tasks].sort((a, b) => {
    const rDiff = atRiskRank(a.status) - atRiskRank(b.status);
    if (rDiff !== 0) return rDiff;
    const dDiff = dueRank(a.id) - dueRank(b.id);
    if (dDiff !== 0) return dDiff;
    const pDiff = priorityRank[getTaskPriority(a.id)] - priorityRank[getTaskPriority(b.id)];
    if (pDiff !== 0) return pDiff;
    return a.name.localeCompare(b.name);
  });
};

const taskStatusLabels: Record<TaskStatus, string> = {
  completed: "Completed",
  "on-track": "On Track",
  "at-risk": "At Risk",
  pending: "Pending",
  late: "Late",
};

const taskStatusDot: Record<TaskStatus, string> = {
  completed: "bg-green-500",
  "on-track": "bg-green-500",
  "at-risk": "bg-yellow-500",
  pending: "bg-gray-400",
  late: "bg-red-500",
};

import {
  TIMELINE_START,
  TIMELINE_END,
  dateToPct as portfolioDateToPct,
  generateMonthLabels as generatePortfolioMonthLabels,
  platformPhaseTimelines,
  MILESTONES,
  computeMilestoneDate,
  computeProgramStatus,
  getPhaseBarColor,
  inProgressColorByStatus,
  PHASE_COLOR_COMPLETE,
  PHASE_COLOR_NOT_STARTED,
} from "@/components/dashboard/PortfolioScheduleGantt";

const dateToPct = (date: Date): number => portfolioDateToPct(date);

const RTS_BASELINE_DATE = new Date(2026, 10, 3);

const computePhaseStatus = (phase: { milestones: { tasks: { status: TaskStatus }[] }[] }): PhaseStatus => {
  const allTasks = phase.milestones.flatMap((m) => m.tasks);
  return computeRollupStatus(allTasks);
};

interface PlatformScheduleDetailProps {
  programName: string;
  pageFilters?: TaskPageFilterState;
  /** Phase track to display. SChM remaps Qual+Pilot→Develop, Ramp→Launch and
   *  filters tasks to SChM-tagged ones. Default: GOE_NPI (full 6-phase). */
  track?: "GOE_NPI" | "SCHM";
}

import { getTaskTrack, platformPhaseTimelinesSchm, SCHM_TO_GOE_NPI_SPAN, type SchmPhase } from "@/data/phaseTracks";

const PlatformScheduleDetail = ({
  programName,
  pageFilters = defaultTaskPageFilters,
  track = "GOE_NPI",
}: PlatformScheduleDetailProps) => {
  const sourcePhases = useMemo(
    () => programSchedules[programName] || programSchedules["Laptop 1"],
    [programName],
  );

  // Transform the underlying GOE/NPI phase tree into the active track's view.
  // For SChM: re-bucket phases (Qual+Pilot→Develop, Ramp→Launch) and keep only
  // SChM-track tasks within each milestone.
  const trackedPhases = useMemo(() => {
    if (track === "GOE_NPI") return sourcePhases;
    const buckets: Record<SchmPhase, typeof sourcePhases[number]["milestones"]> = {
      Concept: [],
      Define: [],
      Plan: [],
      Develop: [],
      Launch: [],
    };
    for (const ph of sourcePhases) {
      const target = (Object.keys(SCHM_TO_GOE_NPI_SPAN) as SchmPhase[]).find((sp) =>
        SCHM_TO_GOE_NPI_SPAN[sp].includes(ph.name),
      );
      if (!target) continue;
      const filteredMilestones = ph.milestones
        .map((m) => ({
          ...m,
          tasks: m.tasks.filter((t) => getTaskTrack(t) === "SCHM"),
        }))
        .filter((m) => m.tasks.length > 0);
      buckets[target].push(...filteredMilestones);
    }
    return (Object.keys(buckets) as SchmPhase[]).map((name) => ({
      name,
      milestones: buckets[name],
    })) as typeof sourcePhases;
  }, [sourcePhases, track]);

  const [phases, setPhases] = useState(trackedPhases);
  // Re-sync when track or program changes (different shape).
  useEffect(() => {
    setPhases(trackedPhases);
    setExpandedPhases(new Set());
    setExpandedMilestones(new Set());
  }, [trackedPhases]);

  const [rtsDate, setRtsDate] = useState<Date>(RTS_BASELINE_DATE);
  const [rtsEditConfirmed, setRtsEditConfirmed] = useState(false);
  const [rtsConfirmOpen, setRtsConfirmOpen] = useState(false);
  const [rtsPickerOpen, setRtsPickerOpen] = useState(false);
  const [expandedPhases, setExpandedPhases] = useState<Set<string>>(new Set());
  const [expandedMilestones, setExpandedMilestones] = useState<Set<string>>(new Set());
  const [selectedTask, setSelectedTask] = useState<ScheduleTask | null>(null);
  const [taskComments, setTaskComments] = useState<Record<string, TaskComment[]>>({});

  const { taskMap } = useMemo(() => {
    const tMap: Record<string, ScheduleTask> = {};
    const allTasks = phases.flatMap(p => p.milestones.flatMap(m => m.tasks));
    for (const t of allTasks) tMap[t.id] = t;
    return { taskMap: tMap };
  }, [phases]);

  const { estimatedRts, delayWeeks, hasDelay } = useMemo(() => {
    const allTasks = phases.flatMap((p) => p.milestones.flatMap((m) => m.tasks));
    const lateTasks = allTasks.filter((t) => t.status === "late");
    const delay = lateTasks.length;
    return { estimatedRts: addWeeks(rtsDate, delay), delayWeeks: delay, hasDelay: delay > 0 };
  }, [phases, rtsDate]);

  const rtsLeftPct = useMemo(() => dateToPct(rtsDate), [rtsDate]);

  const toggle = (set: Set<string>, key: string) => {
    const next = new Set(set);
    next.has(key) ? next.delete(key) : next.add(key);
    return next;
  };

  const handleMarkComplete = useCallback((taskId: string) => {
    setPhases((prev) =>
      prev.map((phase) => ({
        ...phase,
        milestones: phase.milestones.map((m) => ({
          ...m,
          tasks: m.tasks.map((t) => (t.id === taskId ? { ...t, status: "completed" as TaskStatus } : t)),
        })),
      }))
    );
    setSelectedTask((prev) => prev && prev.id === taskId ? { ...prev, status: "completed" } : prev);
  }, []);

  const handleAddComment = useCallback((taskId: string, comment: string) => {
    const currentUser = sessionStorage.getItem("userRole") || "User";
    const newComment: TaskComment = { id: crypto.randomUUID(), author: currentUser, text: comment, timestamp: new Date() };
    setTaskComments((prev) => ({ ...prev, [taskId]: [...(prev[taskId] || []), newComment] }));
  }, []);

  const handleDeleteComment = useCallback((taskId: string, commentId: string) => {
    setTaskComments((prev) => ({ ...prev, [taskId]: (prev[taskId] || []).filter((c) => c.id !== commentId) }));
  }, []);

  const filterTasks = useCallback((tasks: ScheduleTask[]) => {
    return tasks.filter((t) => {
      if (!taskMatchesFunction(t, pageFilters.functions)) return false;
      if (pageFilters.tasks.length > 0) {
        const lowerName = t.name.toLowerCase();
        if (!pageFilters.tasks.some((cat) => lowerName.includes(cat.toLowerCase()))) return false;
      }
      if (pageFilters.primaryOwners.length > 0) {
        const ownerName = getTaskParticipants(t).owner;
        if (!pageFilters.primaryOwners.includes(ownerName)) return false;
      }
      return true;
    });
  }, [pageFilters.functions, pageFilters.tasks, pageFilters.primaryOwners]);

  const isFunctionAll = pageFilters.functions.length === 0 || pageFilters.functions.includes("All");
  const hasAnyTaskFilter = !isFunctionAll || pageFilters.tasks.length > 0 || pageFilters.primaryOwners.length > 0;
  const phasePassesFilter = (name: string) =>
    pageFilters.phases.length === 0 || pageFilters.phases.some((p) => phaseMatches(p, name));

  const completionCount = (phaseIdx: number) => {
    const phase = phases[phaseIdx];
    const all = phase.milestones.flatMap((m) => filterTasks(m.tasks));
    return { done: all.filter((t) => t.status === "completed").length, total: all.length };
  };

  const phaseTimelineDates = useMemo(
    () =>
      track === "SCHM"
        ? platformPhaseTimelinesSchm[programName] || platformPhaseTimelinesSchm["Laptop 1"] || {}
        : platformPhaseTimelines[programName] || platformPhaseTimelines["Laptop 1"] || {},
    [programName, track]
  );

  const monthLabels = useMemo(() => generatePortfolioMonthLabels(), []);

  const milestonesForPlatform = useMemo(() => {
    return MILESTONES.map((def) => {
      const date = computeMilestoneDate(def, phaseTimelineDates);
      return date ? { def, date, pct: dateToPct(date) } : null;
    }).filter((m): m is { def: typeof MILESTONES[number]; date: Date; pct: number } => m !== null);
  }, [phaseTimelineDates]);

  // Group milestones by their owning phase. Boundary milestones (between [a,b])
  // are attributed to phase `a` (the phase they exit). Also synthesize an "RTS"
  // milestone diamond on whichever phase contains rtsDate (or the last phase).
  const milestonesByPhase = useMemo(() => {
    type MItem = { def: { label: string; short: string }; date: Date; pct: number };
    const map: Record<string, MItem[]> = {};
    for (const m of milestonesForPlatform) {
      const phaseName = m.def.within?.phase ?? m.def.between?.[0];
      if (!phaseName) continue;
      (map[phaseName] ||= []).push(m);
    }
    // Place RTS diamond
    const rtsItem: MItem = {
      def: { label: "Ready to Ship — RTS", short: "RTS" },
      date: rtsDate,
      pct: dateToPct(rtsDate),
    };
    const containingPhase = Object.entries(phaseTimelineDates).find(
      ([, t]) => rtsDate >= t.start && rtsDate <= t.end
    )?.[0];
    const targetPhase = containingPhase ?? "Pilot";
    (map[targetPhase] ||= []).push(rtsItem);
    return map;
  }, [milestonesForPlatform, rtsDate, phaseTimelineDates]);

  const todayInRange = useMemo(() => {
    const now = new Date();
    return now >= TIMELINE_START && now <= TIMELINE_END;
  }, []);
  const todayPct = useMemo(() => dateToPct(new Date()), []);

  const barStyle = (name: string) => {
    const t = phaseTimelineDates[name];
    if (!t) return { left: "0%", width: "0%" };
    const left = dateToPct(t.start);
    const width = dateToPct(t.end) - left;
    return { left: `${left}%`, width: `${width}%` };
  };

  return (
    <div className="bg-muted/[0.02] border-t border-border/30">
      <div className="flex items-center gap-3 px-4 pt-3 pb-2">
        {(["on-track", "at-risk", "delayed", "not-started"] as const).map((s) => (
          <div key={s} className="flex items-center gap-1">
            <span className={`w-2.5 h-2.5 rounded-full ${statusDotColors[s]}`} />
            <span className="text-[10px] text-muted-foreground">{statusLabels[s]}</span>
          </div>
        ))}
      </div>

      {/* RTS Info Block */}
      <div className="px-4 pb-3">
        <div className="border border-border rounded-lg bg-card p-4 flex items-center gap-6 flex-wrap">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-full bg-destructive/10 flex items-center justify-center">
              <CalendarIcon className="w-4 h-4 text-destructive" />
            </div>
            <div>
              <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-semibold">Target RTS Date</p>
              <div className="flex items-center gap-2">
                <span className="text-sm font-bold text-foreground">{format(rtsDate, "MMM d, yyyy")}</span>
                <Popover open={rtsPickerOpen} onOpenChange={setRtsPickerOpen}>
                  <PopoverTrigger asChild>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-6 w-6"
                      aria-label="Edit Target RTS Date"
                      onClick={(e) => {
                        if (!rtsEditConfirmed) {
                          e.preventDefault();
                          setRtsConfirmOpen(true);
                        }
                      }}
                    >
                      <Pencil className="w-3 h-3 text-muted-foreground" />
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0" align="start">
                    <CalendarPicker
                      mode="single"
                      selected={rtsDate}
                      onSelect={(d) => {
                        if (d) {
                          setRtsDate(d);
                          setRtsPickerOpen(false);
                        }
                      }}
                      initialFocus
                      className={cn("p-3 pointer-events-auto")}
                    />
                  </PopoverContent>
                </Popover>

                <AlertDialog open={rtsConfirmOpen} onOpenChange={setRtsConfirmOpen}>
                  <AlertDialogContent>
                    <AlertDialogHeader>
                      <AlertDialogTitle>Edit Target RTS Date?</AlertDialogTitle>
                      <AlertDialogDescription>
                        This date is auto-synced from <strong>Regrello</strong> and <strong>Doc Curator</strong>. Any change you make here will write back to both connected tools and may impact downstream schedules.
                      </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                      <AlertDialogCancel>Cancel</AlertDialogCancel>
                      <AlertDialogAction
                        onClick={() => {
                          setRtsEditConfirmed(true);
                          setRtsConfirmOpen(false);
                          setRtsPickerOpen(true);
                        }}
                      >
                        Continue & Edit
                      </AlertDialogAction>
                    </AlertDialogFooter>
                  </AlertDialogContent>
                </AlertDialog>
              </div>
            </div>
          </div>

          <div className="h-8 w-px bg-border" />

          <div>
            <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-semibold">Estimated RTS</p>
            <span className={cn("text-sm font-bold", hasDelay ? "text-destructive" : "text-green-600")}>
              {format(estimatedRts, "MMM d, yyyy")}
            </span>
          </div>

          {hasDelay && (
            <>
              <div className="h-8 w-px bg-border" />
              <div className="flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 text-destructive" />
                <div>
                  <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-semibold">Slip</p>
                  <span className="text-sm font-bold text-destructive">+{delayWeeks} week{delayWeeks !== 1 ? "s" : ""}</span>
                </div>
              </div>
            </>
          )}
        </div>
      </div>

      <div className="px-4 pb-4">
        <div className="border border-border rounded-lg bg-card overflow-hidden">
          <div className="grid grid-cols-[480px_1fr] bg-muted/50 border-b border-border">
            <div className="px-3 py-2 text-[10px] font-semibold text-muted-foreground uppercase tracking-wider">
              <div className="grid grid-cols-[20px_14px_6px_120px_100px_72px_1fr] items-center">
                <span></span>
                <span></span>
                <span></span>
                <span>Phase</span>
                <span>Exit Date</span>
                <span>Status</span>
                <span className="text-right pr-1">Progress</span>
              </div>
            </div>
            <div className="relative py-2 pb-7">
              <div className="relative h-3">
                {monthLabels.map((m, i) => (
                  <span
                    key={i}
                    className="absolute top-0 text-[8px] text-muted-foreground font-medium text-center"
                    style={{ left: `${m.pct}%`, width: `${m.width}%` }}
                  >
                    {m.label}
                  </span>
                ))}
              </div>
              <div className="absolute bottom-0.5 flex items-center gap-0.5" style={{ left: `${rtsLeftPct}%`, transform: 'translateX(-50%)' }}>
                <span className="text-[10px] font-bold text-destructive whitespace-nowrap leading-tight">RTS</span>
                <span className="text-[9px] text-destructive whitespace-nowrap leading-tight">{format(rtsDate, "MMM d")}</span>
              </div>
            </div>
          </div>

          {phases.filter((p) => phasePassesFilter(p.name)).map((phase, pi) => {
            const isOpen = expandedPhases.has(phase.name);
            const { done, total } = completionCount(pi);
            const filteredTasks = phase.milestones.flatMap(m => filterTasks(m.tasks));
            const exitDates = phaseExitDates[programName] || phaseExitDates["Laptop 1"] || {};
            const rawExitDate = exitDates[phase.name];
            const exitDate = rawExitDate ? new Date(rawExitDate).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" }) : null;
            const lateTasks = filteredTasks.filter(t => t.status === "late");

            // Time-based progress + status, mirroring PortfolioScheduleGantt header.
            // When task filters are active, fall back to task-rollup semantics so
            // the user's filtered slice is reflected.
            const t = phaseTimelineDates[phase.name];
            const now = new Date();
            let donePct = 0;
            let timeBasedStatus: PhaseStatus = "not-started";
            if (t) {
              if (now >= t.end) donePct = 100;
              else if (now <= t.start) donePct = 0;
              else donePct = Math.round(((now.getTime() - t.start.getTime()) / (t.end.getTime() - t.start.getTime())) * 100);

              if (now < t.start) timeBasedStatus = "not-started";
              else if (now > t.end) timeBasedStatus = "on-track";
              else timeBasedStatus = computeProgramStatus(phases);
            }

            const phaseStatus: PhaseStatus = hasAnyTaskFilter
              ? computeRollupStatus(filteredTasks)
              : timeBasedStatus;
            const displayPct = hasAnyTaskFilter
              ? (total > 0 ? Math.round((done / total) * 100) : 0)
              : donePct;
            const phaseBarColor = hasAnyTaskFilter
              ? statusBarColors[phaseStatus]
              : getPhaseBarColor(donePct, total > 0, computeProgramStatus(phases));

            const phaseStatusReason = lateTasks.length > 0
              ? lateTasks[0].statusReason || `${lateTasks.length} task(s) late`
              : filteredTasks.find(t => t.statusReason)?.statusReason || null;

            if (hasAnyTaskFilter && filteredTasks.length === 0) return null;

            return (
              <div key={phase.name}>
                <button
                  onClick={() => setExpandedPhases(toggle(expandedPhases, phase.name))}
                  className="w-full grid grid-cols-[480px_1fr] items-center hover:bg-muted/30 transition-colors border-b border-border"
                >
                  <div className="flex flex-col gap-0.5 px-3 py-2.5">
                    <div className="grid grid-cols-[20px_14px_6px_120px_100px_72px_1fr] items-center">
                      <span className="flex items-center justify-center">
                        {isOpen ? <ChevronDown className="w-3.5 h-3.5 text-muted-foreground" /> : <ChevronRight className="w-3.5 h-3.5 text-muted-foreground" />}
                      </span>
                      <span className={`w-2.5 h-2.5 rounded-full ${statusDotColors[phaseStatus]}`} />
                      <span></span>
                      <span className="text-xs font-semibold text-foreground truncate text-left">{phase.name}</span>
                      <span className="text-[10px] text-muted-foreground truncate text-left">{exitDate ?? "—"}</span>
                      <span className={`text-[9px] px-1.5 py-0.5 rounded-full border text-center truncate ${statusBadgeVariants[phaseStatus]}`}>{statusLabels[phaseStatus]}</span>
                      <span className="text-[10px] text-muted-foreground text-right tabular-nums pr-1">{done} of {total} tasks</span>
                    </div>
                    {phaseStatus !== "on-track" && phaseStatus !== "not-started" && phaseStatusReason && (
                      <span className="text-[9px] italic text-muted-foreground ml-[42px] truncate max-w-[400px] text-left">{phaseStatusReason}</span>
                    )}
                  </div>
                  <div className="relative h-8">
                    <div className="absolute inset-0">
                      {monthLabels.map((m, i) => (
                        <div
                          key={i}
                          className="absolute top-0 bottom-0 border-l border-border/20"
                          style={{ left: `${m.pct}%` }}
                        />
                      ))}
                    </div>
                    {todayInRange && (
                      <div
                        className="absolute top-0 bottom-0 w-px bg-primary z-[2] pointer-events-none"
                        style={{ left: `${todayPct}%` }}
                      />
                    )}
                    <div className={`absolute top-1.5 h-5 rounded-sm ${phaseBarColor} opacity-85 flex items-center justify-center transition-all z-[1]`} style={barStyle(phase.name)}>
                      <span className="text-[9px] font-bold text-white drop-shadow-sm">{displayPct}%</span>
                    </div>
                    {(milestonesByPhase[phase.name] ?? []).map(({ def, date, pct: mPct }) => (
                      <div
                        key={def.label}
                        className="absolute z-[3] group/ms"
                        style={{ left: `${mPct}%`, bottom: "0px", transform: "translateX(-50%)" }}
                        title={`${def.label}: ${date.toLocaleDateString()}`}
                      >
                        <div className="w-2 h-2 rotate-45 bg-purple-500 border border-purple-700 shadow-sm" />
                        <span className="absolute bottom-3 left-1/2 -translate-x-1/2 mb-1 px-1.5 py-0.5 rounded bg-popover text-popover-foreground text-[9px] font-medium shadow-md border border-border/40 whitespace-nowrap opacity-0 group-hover/ms:opacity-100 transition-opacity pointer-events-none z-30">
                          {def.label} — {def.short}
                        </span>
                      </div>
                    ))}
                  </div>
                </button>

                {isOpen && (
                  <div className={`border-l-2 ${statusBorderColors[phaseStatus]} ml-4`}>
                    {phase.milestones.map((milestone) => {
                      const mKey = `${phase.name}-${milestone.name}`;
                      const isMOpen = expandedMilestones.has(mKey);
                      const mFiltered = filterTasks(milestone.tasks);
                      if (hasAnyTaskFilter && mFiltered.length === 0) return null;
                      const mDone = mFiltered.filter((t) => t.status === "completed").length;
                      const milestoneStatus = !hasAnyTaskFilter ? computePhaseStatus({ milestones: [milestone] }) : computeRollupStatus(mFiltered);
                      const mLate = mFiltered.filter(t => t.status === "late");
                      const milestoneReason = mLate.length > 0 ? mLate[0].statusReason || `${mLate.length} task(s) late` : null;

                      return (
                        <div key={mKey}>
                          <button
                            onClick={() => setExpandedMilestones(toggle(expandedMilestones, mKey))}
                            className="w-full flex flex-col px-3 py-1.5 pl-6 hover:bg-muted/20 transition-colors border-b border-border/40"
                          >
                            <div className="flex items-center gap-2 w-full">
                              {isMOpen ? <ChevronDown className="w-3 h-3 text-muted-foreground shrink-0" /> : <ChevronRight className="w-3 h-3 text-muted-foreground shrink-0" />}
                              <span className={`w-1.5 h-1.5 rotate-45 ${statusDotColors[milestoneStatus]} shrink-0`} />
                              <span className={`text-[11px] font-medium ${statusTextColors[milestoneStatus]}`}>{milestone.name}</span>
                              <span className="text-[10px] text-muted-foreground ml-auto mr-2">{mDone} of {mFiltered.length} tasks</span>
                            </div>
                            {milestoneStatus !== "on-track" && milestoneStatus !== "not-started" && milestoneReason && (
                              <span className="text-[9px] italic text-muted-foreground ml-7 mt-0.5 truncate max-w-[260px] text-left">{milestoneReason}</span>
                            )}
                          </button>

                          {isMOpen && sortTasksForView(filterTasks(milestone.tasks)).map((task) => {
                            const priority = getTaskPriority(task.id);
                            return (
                            <div
                              key={task.id}
                              onClick={() => {
                                setSelectedTask(task);
                                window.dispatchEvent(new CustomEvent("sidebar-collapse", { detail: true }));
                              }}
                              className={cn(
                                "flex items-center gap-1.5 px-3 py-1.5 pl-12 cursor-pointer transition-colors border-b border-border/20",
                                selectedTask?.id === task.id ? "bg-primary/10 border-l-2 border-l-primary" : "hover:bg-muted/10"
                              )}
                            >
                              <span className={`w-2 h-2 rounded-full ${taskStatusDot[task.status]} shrink-0`} />
                              <span className={`text-[11px] flex-1 ${task.status === "completed" ? "text-muted-foreground" : "text-foreground"}`}>{task.name}</span>
                              <TaskChipStrip task={task} taskMap={taskMap} />
                            </div>
                            );
                          })}
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>

      <div className="px-4 pt-4 pb-6">
        {/* Phase Exit Tracker — current-phase Gantt strip */}
        <PhaseExitTrackerWidget
          programName={programName}
          phases={phases}
          phaseTimelineDates={phaseTimelineDates}
        />

        {/* NUDDs impacting this platform */}
        <div className="mt-5">
          <PlatformNuddsSummary platform={programName} />
        </div>
      </div>

      {selectedTask && (() => {
        let phaseName = "";
        let milestoneName = "";
        for (const ph of phases) {
          for (const m of ph.milestones) {
            if (m.tasks.some((t) => t.id === selectedTask.id)) {
              phaseName = ph.name;
              milestoneName = m.name;
              break;
            }
          }
          if (phaseName) break;
        }
        return (
          <TaskDetailModal
            open={!!selectedTask}
            task={selectedTask}
            phaseName={phaseName}
            milestoneName={milestoneName}
            allTasks={Object.values(taskMap)}
            onClose={() => {
              setSelectedTask(null);
              window.dispatchEvent(new CustomEvent("sidebar-collapse", { detail: false }));
            }}
            onMarkComplete={handleMarkComplete}
            onAddComment={handleAddComment}
            onDeleteComment={handleDeleteComment}
            comments={taskComments[selectedTask.id] || []}
          />
        );
      })()}
    </div>
  );
};

export default PlatformScheduleDetail;
