import { useMemo, useState, useRef } from "react";
import { motion } from "framer-motion";
import { cn } from "@/lib/utils";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { programSchedules } from "@/data/scheduleData";
import { getCurrentPhaseByDate, computeProgramStatus } from "./PortfolioScheduleGantt";
import { type Program, type ProgramStatus } from "./ProgramOverviewTimeline";
import { ChevronRight, X } from "lucide-react";
import {
  GOE_NPI_PHASES,
  SCHM_PHASES,
  platformPhaseTimelinesSchm,
  TRACK_LABEL,
  TRACK_TONE,
  type Track,
} from "@/data/phaseTracks";

const getProgramStatus = (name: string): ProgramStatus => {
  const phases = programSchedules[name] || [];
  const rollup = computeProgramStatus(phases, name);
  if (rollup === "delayed") return "delayed";
  if (rollup === "at-risk") return "at-risk";
  return "on-track";
};

/** Date-based current-phase resolver for the SChM track. */
const getCurrentSchmPhase = (name: string): string => {
  const t = platformPhaseTimelinesSchm[name];
  if (!t) return "Concept";
  const now = new Date();
  for (const ph of SCHM_PHASES) {
    const w = t[ph];
    if (!w) continue;
    if (now <= w.end) return ph;
  }
  return SCHM_PHASES[SCHM_PHASES.length - 1];
};

const getCurrentPhase = (name: string, track: Track): string => {
  if (track === "SCHM") return getCurrentSchmPhase(name);
  const p = getCurrentPhaseByDate(name);
  return (GOE_NPI_PHASES as readonly string[]).includes(p) ? p : "Concept";
};

interface Props {
  programsList: Program[];
  onPlatformSelect: (platformName: string) => void;
  /** Which phase track to chart. Defaults to GOE/NPI for backwards compat. */
  track?: Track;
}

interface Bucket {
  onTrack: string[];
  atRisk: string[];
  delayed: string[];
}

const STATUS_LABEL: Record<ProgramStatus, string> = {
  "on-track": "On Track",
  "at-risk": "At Risk w/ Mitigation",
  "delayed": "At Risk w/ No Plan",
};

const STATUS_DOT: Record<ProgramStatus, string> = {
  "on-track": "bg-success",
  "at-risk": "bg-warning",
  "delayed": "bg-destructive",
};

const PortfolioPhaseDistribution = ({ programsList, onPlatformSelect, track = "GOE_NPI" }: Props) => {
  const PHASES = track === "SCHM" ? SCHM_PHASES : GOE_NPI_PHASES;
  const tone = TRACK_TONE[track];
  // Per-phase open state — supports hover (auto) + click (locked)
  const [hoverPhase, setHoverPhase] = useState<string | null>(null);
  const [lockedPhase, setLockedPhase] = useState<string | null>(null);
  const closeTimer = useRef<number | null>(null);

  const buckets = useMemo(() => {
    const init: Record<string, Bucket> = {};
    for (const ph of PHASES) init[ph] = { onTrack: [], atRisk: [], delayed: [] };
    programsList.forEach((p) => {
      const phase = getCurrentPhase(p.name, track);
      const status = getProgramStatus(p.name);
      if (!init[phase]) return;
      if (status === "delayed") init[phase].delayed.push(p.name);
      else if (status === "at-risk") init[phase].atRisk.push(p.name);
      else init[phase].onTrack.push(p.name);
    });
    return init;
  }, [programsList, track, PHASES]);

  const max = Math.max(
    1,
    ...PHASES.map((ph) => buckets[ph].onTrack.length + buckets[ph].atRisk.length + buckets[ph].delayed.length),
  );

  const phasePlatforms = (phase: string) => {
    const b = buckets[phase];
    return [
      ...b.delayed.map((n) => ({ name: n, status: "delayed" as ProgramStatus })),
      ...b.atRisk.map((n) => ({ name: n, status: "at-risk" as ProgramStatus })),
      ...b.onTrack.map((n) => ({ name: n, status: "on-track" as ProgramStatus })),
    ];
  };

  const scheduleClose = (phase: string) => {
    if (closeTimer.current) window.clearTimeout(closeTimer.current);
    closeTimer.current = window.setTimeout(() => {
      setHoverPhase((cur) => (cur === phase ? null : cur));
    }, 120);
  };
  const cancelClose = () => {
    if (closeTimer.current) {
      window.clearTimeout(closeTimer.current);
      closeTimer.current = null;
    }
  };

  return (
    <div className="space-y-2">
      <div className="flex items-center gap-2 px-2">
        <span
          className={cn(
            "inline-flex items-center font-semibold rounded border h-5 px-2 text-[10px] tracking-wide uppercase",
            tone.bg,
            tone.text,
            tone.border,
          )}
        >
          {TRACK_LABEL[track]} Track
        </span>
        <span className="text-[10px] text-muted-foreground">
          {track === "SCHM"
            ? "Concept · Define · Plan · Develop · Launch"
            : "Concept · Define · Plan · Qual · Pilot · Ramp"}
        </span>
      </div>
      <div className="flex items-stretch justify-between gap-3 sm:gap-6 h-60 px-2">
        {PHASES.map((phase) => {
          const b = buckets[phase];
          const total = b.onTrack.length + b.atRisk.length + b.delayed.length;
          const heightPct = (total / max) * 100;
          const segPct = (n: number) => (total === 0 ? 0 : (n / total) * 100);
          const isLocked = lockedPhase === phase;
          const isOpen = isLocked || hoverPhase === phase;
          const platforms = phasePlatforms(phase);

          return (
            <Popover
              key={phase}
              open={total > 0 && isOpen}
              onOpenChange={(o) => {
                if (!o) {
                  setLockedPhase((cur) => (cur === phase ? null : cur));
                  setHoverPhase((cur) => (cur === phase ? null : cur));
                }
              }}
            >
              <PopoverTrigger asChild>
                <button
                  type="button"
                  onMouseEnter={() => {
                    if (total === 0) return;
                    cancelClose();
                    setHoverPhase(phase);
                  }}
                  onMouseLeave={() => {
                    if (lockedPhase === phase) return;
                    scheduleClose(phase);
                  }}
                  onClick={() => {
                    if (total === 0) return;
                    setLockedPhase((cur) => (cur === phase ? null : phase));
                  }}
                  disabled={total === 0}
                  className="flex-1 flex flex-col items-center gap-2 group focus:outline-none h-full"
                >
                  <span className="text-sm font-bold text-foreground tabular-nums h-5">{total || ""}</span>
                  <div className="flex-1 w-full flex items-end justify-center min-h-0">
                    {total > 0 && (
                      <div
                        className={cn(
                          "w-full max-w-[72px] flex flex-col-reverse rounded-md overflow-hidden border bg-muted/20 transition-all group-hover:border-primary/50 group-hover:shadow-md",
                          isLocked ? "border-primary shadow-md ring-2 ring-primary/30" : "border-border/40"
                        )}
                        style={{ height: `${Math.max(heightPct, 4)}%`, minHeight: 12 }}
                      >
                        {b.onTrack.length > 0 && (
                          <motion.div
                            initial={{ height: 0 }}
                            animate={{ height: `${segPct(b.onTrack.length)}%` }}
                            transition={{ duration: 0.5 }}
                            className="bg-success w-full flex items-center justify-center"
                          >
                            {segPct(b.onTrack.length) >= 12 && (
                              <span className="text-[10px] font-bold text-white tabular-nums">{b.onTrack.length}</span>
                            )}
                          </motion.div>
                        )}
                        {b.atRisk.length > 0 && (
                          <motion.div
                            initial={{ height: 0 }}
                            animate={{ height: `${segPct(b.atRisk.length)}%` }}
                            transition={{ duration: 0.5, delay: 0.1 }}
                            className="bg-warning w-full flex items-center justify-center"
                          >
                            {segPct(b.atRisk.length) >= 12 && (
                              <span className="text-[10px] font-bold text-white tabular-nums">{b.atRisk.length}</span>
                            )}
                          </motion.div>
                        )}
                        {b.delayed.length > 0 && (
                          <motion.div
                            initial={{ height: 0 }}
                            animate={{ height: `${segPct(b.delayed.length)}%` }}
                            transition={{ duration: 0.5, delay: 0.2 }}
                            className="bg-destructive w-full flex items-center justify-center"
                          >
                            {segPct(b.delayed.length) >= 12 && (
                              <span className="text-[10px] font-bold text-white tabular-nums">{b.delayed.length}</span>
                            )}
                          </motion.div>
                        )}
                      </div>
                    )}
                  </div>
                  <span className="text-[11px] font-semibold uppercase tracking-wide text-muted-foreground group-hover:text-foreground transition-colors text-center leading-tight">
                    {phase} Phase
                  </span>
                </button>
              </PopoverTrigger>

              <PopoverContent
                side="top"
                align="center"
                sideOffset={8}
                className="w-80 p-0"
                onMouseEnter={cancelClose}
                onMouseLeave={() => {
                  if (lockedPhase !== phase) scheduleClose(phase);
                }}
                onOpenAutoFocus={(e) => e.preventDefault()}
              >
                <div className="flex items-center justify-between px-4 py-3 border-b border-border/40">
                  <h4 className="text-sm font-bold text-foreground">
                    Platforms in {phase} Phase <span className="text-muted-foreground font-normal">· {TRACK_LABEL[track]}</span>
                  </h4>
                  {isLocked && (
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        setLockedPhase(null);
                        setHoverPhase(null);
                      }}
                      className="p-0.5 rounded hover:bg-muted text-muted-foreground hover:text-foreground"
                      aria-label="Close"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
                <div className="space-y-1 max-h-[60vh] overflow-y-auto p-2">
                  {platforms.length === 0 ? (
                    <p className="text-sm text-muted-foreground py-4 text-center">No platforms in this phase.</p>
                  ) : (
                    platforms.map((p) => (
                      <button
                        key={p.name}
                        onClick={(e) => {
                          e.stopPropagation();
                          onPlatformSelect(p.name);
                          setLockedPhase(null);
                          setHoverPhase(null);
                        }}
                        className="w-full flex items-center justify-between gap-3 px-3 py-2 rounded-md hover:bg-muted/50 transition-colors text-left group"
                      >
                        <div className="flex items-center gap-3 min-w-0">
                          <span className={cn("w-2.5 h-2.5 rounded-full shrink-0", STATUS_DOT[p.status])} />
                          <span className="text-sm font-medium text-foreground truncate">{p.name}</span>
                        </div>
                        <div className="flex items-center gap-2 shrink-0">
                          <span className="text-[11px] text-muted-foreground">{STATUS_LABEL[p.status]}</span>
                          <ChevronRight className="w-4 h-4 text-muted-foreground group-hover:text-foreground transition-colors" />
                        </div>
                      </button>
                    ))
                  )}
                </div>
              </PopoverContent>
            </Popover>
          );
        })}
      </div>
    </div>
  );
};

export default PortfolioPhaseDistribution;
