import { useMemo, useState, useEffect, type ReactNode } from "react";
import { Calendar, ChevronRight, ChevronDown, Info } from "lucide-react";
import { programSchedules, computeRollupStatus, computePlatformRollupStatus, type PhaseStatus, type Phase } from "@/data/scheduleData";
import { usePlatform } from "@/contexts/PlatformContext";
import { useUniversalFilters, PLATFORM_LOB, PLATFORM_ORG } from "@/contexts/UniversalFilterContext";
import { useHomeFilters } from "@/contexts/HomeFilterContext";
import { cn } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";
import ReportExporter from "@/components/dashboard/ReportExporter";
import { useNavigate } from "react-router-dom";
import { getTaskParticipants } from "@/data/taskParticipants";
import { taskMatchesFunction } from "@/components/dashboard/FunctionFilter";
import { SCHM_PHASES, platformPhaseTimelinesSchm } from "@/data/phaseTracks";
import { platformPhaseTimelines } from "@/data/platformPhaseTimelines";
export { platformPhaseTimelines };

const STATUS_LABEL_TO_KEY: Record<string, PhaseStatus> = {
  "On Track": "on-track",
  "At Risk w/ Mitigation": "at-risk",
  "At Risk w/ No Plan": "delayed",
};

// Canonical "current phase" for a platform — date-based against `platformPhaseTimelines`.
// This is the SINGLE SOURCE OF TRUTH for "what calendar phase is this platform in right now?"
// Used by: Portfolio Gantt header, Home Program Overview table, Home Phase Distribution chart.
// Note: This is distinct from `getCurrentPhaseIndex` in scheduleData.ts, which is based on
// phase-exit gate closures (used for exit-criteria readiness in PhaseExitCriteria.tsx).
export const getCurrentPhaseByDate = (programName: string, now: Date = new Date()): string => {
  const timeline = platformPhaseTimelines[programName];
  if (!timeline) return "Concept";
  for (const phase of PHASE_NAMES) {
    const t = timeline[phase];
    if (!t) continue;
    if (now <= t.end) return phase;
  }
  return PHASE_NAMES[PHASE_NAMES.length - 1];
};

const getCurrentCanonicalPhase = (programName: string): string => getCurrentPhaseByDate(programName);

const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

// Phase bar color reflects completion state.
// Complete = blue, In-progress = platform R/Y/G status, Not started = gray.
export const PHASE_COLOR_COMPLETE = "bg-primary";
export const PHASE_COLOR_NOT_STARTED = "bg-muted-foreground/40";

export const inProgressColorByStatus: Record<PhaseStatus, string> = {
  "on-track": "bg-success",
  "at-risk": "bg-warning",
  "delayed": "bg-destructive",
  "not-started": "bg-muted-foreground/40",
};

export const getPhaseBarColor = (donePct: number, hasTasks: boolean, platformStatus: PhaseStatus): string => {
  if (!hasTasks || donePct === 0) return PHASE_COLOR_NOT_STARTED;
  if (donePct >= 100) return PHASE_COLOR_COMPLETE;
  return inProgressColorByStatus[platformStatus];
};

const statusDotColors: Record<PhaseStatus, string> = {
  "on-track": "bg-success",
  "at-risk": "bg-warning",
  "delayed": "bg-destructive",
  "not-started": "bg-gray-400",
};

const statusLabels: Record<PhaseStatus, string> = {
  "on-track": "On Track",
  "at-risk": "At Risk w/ Mitigation",
  "delayed": "At Risk w/ No Plan",
  "not-started": "Not Started",
};

const statusBadgeColors: Record<PhaseStatus, string> = {
  "on-track": "bg-green-100 text-green-800 border-green-200",
  "at-risk": "bg-yellow-100 text-yellow-800 border-yellow-200",
  "delayed": "bg-red-100 text-red-800 border-red-200",
  "not-started": "bg-gray-100 text-gray-600 border-gray-200",
};

// platformPhaseTimelines lives in @/data/platformPhaseTimelines and is re-exported above.

export const TIMELINE_START = new Date(2025, 9, 1);
export const TIMELINE_END = new Date(2027, 5, 30);
const TIMELINE_MS = TIMELINE_END.getTime() - TIMELINE_START.getTime();

export const dateToPct = (date: Date): number => {
  const clamped = Math.max(TIMELINE_START.getTime(), Math.min(TIMELINE_END.getTime(), date.getTime()));
  return ((clamped - TIMELINE_START.getTime()) / TIMELINE_MS) * 100;
};

export const generateMonthLabels = (): { label: string; pct: number; width: number }[] => {
  const labels: { label: string; pct: number; width: number }[] = [];
  const d = new Date(TIMELINE_START);
  while (d < TIMELINE_END) {
    const start = dateToPct(new Date(d));
    const nextMonth = new Date(d.getFullYear(), d.getMonth() + 1, 1);
    const end = dateToPct(nextMonth);
    labels.push({
      label: `${months[d.getMonth()]} '${String(d.getFullYear()).slice(2)}`,
      pct: start,
      width: end - start,
    });
    d.setMonth(d.getMonth() + 1);
  }
  return labels;
};

export const computeProgramStatus = (phases: Phase[], programName?: string): PhaseStatus => {
  const allTasks = phases.flatMap(p => p.milestones.flatMap(m => m.tasks));
  const timeline = programName ? platformPhaseTimelines[programName] : null;
  const firstStart = timeline?.["Concept"]?.start;
  const hasStartedPhase = firstStart ? new Date() >= firstStart : true;
  return computePlatformRollupStatus(allTasks, { hasStartedPhase });
};

const PHASE_NAMES = ["Concept", "Define", "Plan", "Qual", "Pilot", "Ramp"];

interface PlatformRow {
  name: string;
  status: PhaseStatus;
  total: number;
  completed: number;
  pct: number;
  timeline: Record<string, { start: Date; end: Date }>;
  rtsDate: Date | null;
  phases: Phase[];
}

// Milestone definitions: relative position within phase (0-1) determines date.
// Some milestones sit at boundaries between phases.
export type MilestoneDef = {
  label: string;
  short: string;
  // Either between two phases (boundary) or within a single phase at a fraction
  between?: [string, string];
  within?: { phase: string; at: number };
};

export const MILESTONES: MilestoneDef[] = [
  { label: "Concept Phase Exit", short: "ConX", between: ["Concept", "Define"] },
  { label: "Define Phase Exit", short: "DefX", between: ["Define", "Plan"] },
  { label: "Plan Phase Exit", short: "PlanX", between: ["Plan", "Qual"] },
  { label: "Engineering Validation Test", short: "EVT", within: { phase: "Qual", at: 0.15 } },
  { label: "Design Validation Test 1", short: "DVT1", within: { phase: "Qual", at: 0.35 } },
  { label: "Design Validation Test 2", short: "DVT2", within: { phase: "Qual", at: 0.55 } },
  { label: "Pre-Production Engineering", short: "PPE", within: { phase: "Qual", at: 0.75 } },
  { label: "Production Validation Test", short: "PVT", within: { phase: "Qual", at: 0.9 } },
  { label: "Qualify Phase Exit", short: "QualX", between: ["Qual", "Pilot"] },
  { label: "Qual Build", short: "QB", within: { phase: "Pilot", at: 0.25 } },
  { label: "Pilot Build", short: "PB", within: { phase: "Pilot", at: 0.7 } },
  { label: "Pilot Phase Exit", short: "PilotX", between: ["Pilot", "Ramp"] },
  { label: "Ready to Order", short: "RTO", within: { phase: "Ramp", at: 0.5 } },
  { label: "Ready to Ship", short: "RTS", between: ["Ramp", "__post"] },
];

export const computeMilestoneDate = (
  def: MilestoneDef,
  timeline: Record<string, { start: Date; end: Date }>
): Date | null => {
  if (def.between) {
    const [a, b] = def.between;
    if (b === "__post") {
      const aEnd = timeline[a]?.end;
      return aEnd ? new Date(aEnd.getTime() + 24 * 60 * 60 * 1000) : null;
    }
    const aEnd = timeline[a]?.end;
    const bStart = timeline[b]?.start;
    if (aEnd && bStart) return new Date((aEnd.getTime() + bStart.getTime()) / 2);
    return aEnd || bStart || null;
  }
  if (def.within) {
    const t = timeline[def.within.phase];
    if (!t) return null;
    return new Date(t.start.getTime() + (t.end.getTime() - t.start.getTime()) * def.within.at);
  }
  return null;
};

interface PortfolioScheduleGanttProps {
  expandable?: boolean;
  renderExpanded?: (platformName: string) => ReactNode;
  initiallyExpanded?: string[];
}

const PortfolioScheduleGantt = ({ expandable = false, renderExpanded, initiallyExpanded = [] }: PortfolioScheduleGanttProps = {}) => {
  const { programs, setSelectedPlatform } = usePlatform();
  const { matchesPlatform, updateFilter, setFilters } = useUniversalFilters();
  const { filters: homeFilters } = useHomeFilters();
  const navigate = useNavigate();
  const [expandedPlatforms, setExpandedPlatforms] = useState<Set<string>>(() => new Set(initiallyExpanded));

  useEffect(() => {
    if (initiallyExpanded.length > 0) {
      setExpandedPlatforms((prev) => {
        const next = new Set(prev);
        initiallyExpanded.forEach((p) => next.add(p));
        return next;
      });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [initiallyExpanded.join(",")]);

  const monthLabels = useMemo(() => generateMonthLabels(), []);
  const today = useMemo(() => new Date(), []);
  const todayInRange = today >= TIMELINE_START && today <= TIMELINE_END;
  const todayPct = dateToPct(today);
  const todayLabel = today.toLocaleDateString(undefined, { month: "short", day: "numeric" });

  const platformData = useMemo(() => {
    return programs
      .filter((name) => {
        // AND-combine: legacy single-select universal lock + multi-select Home filters
        if (!matchesPlatform(name)) return false;
        if (homeFilters.orgs.length      && !homeFilters.orgs.includes(PLATFORM_ORG[name] ?? "CSG")) return false;
        if (homeFilters.lobs.length      && !homeFilters.lobs.includes(PLATFORM_LOB[name]))          return false;
        if (homeFilters.platforms.length && !homeFilters.platforms.includes(name))                   return false;
        if (homeFilters.phases.length    && !homeFilters.phases.includes(getCurrentCanonicalPhase(name))) return false;

        // Owner / Task / Function chips: hide platforms with zero matching tasks.
        const hasOwnerChips    = homeFilters.ownerSearch.length > 0;
        const hasTaskChips     = homeFilters.taskSearch.length  > 0;
        const hasFunctionChips = homeFilters.functions.length   > 0
                                 && !homeFilters.functions.includes("All");
        if (hasOwnerChips || hasTaskChips || hasFunctionChips) {
          const allTasks = (programSchedules[name] ?? [])
            .flatMap((p) => p.milestones.flatMap((m) => m.tasks));
          const compoundMatch = allTasks.some((t) => {
            const okOwner = !hasOwnerChips || homeFilters.ownerSearch.some((q) =>
              getTaskParticipants(t).owner.toLowerCase().includes(q.trim().toLowerCase()));
            const okTask = !hasTaskChips || homeFilters.taskSearch.some((q) =>
              t.name.toLowerCase().includes(q.trim().toLowerCase()));
            const okFn = !hasFunctionChips || taskMatchesFunction(t, homeFilters.functions);
            return okOwner && okTask && okFn;
          });
          if (!compoundMatch) return false;
        }
        return true;
      })
      .map((prog) => {
        const phases = programSchedules[prog] || [];
        const status = computeProgramStatus(phases, prog);
        const allTasks = phases.flatMap((p) => p.milestones.flatMap((m) => m.tasks));
        const total = allTasks.length;
        const completed = allTasks.filter((t) => t.status === "completed").length;
        const pct = total > 0 ? Math.round((completed / total) * 100) : 0;
        const timeline = platformPhaseTimelines[prog] || {};
        const rampEnd = timeline["Ramp"]?.end || timeline["Pilot"]?.end || null;
        const rtsDate = rampEnd ? new Date(rampEnd.getTime() + 24 * 60 * 60 * 1000) : null;

        return { name: prog, status, total, completed, pct, timeline, rtsDate, phases };
      })
      .filter((row) => {
        if (!homeFilters.statuses.length) return true;
        const allowed = homeFilters.statuses.map((s) => STATUS_LABEL_TO_KEY[s]).filter(Boolean);
        return allowed.includes(row.status);
      });
  }, [programs, matchesPlatform, homeFilters]);

  // Sort: Red → Yellow → Green (then anything else); within each, earliest RTS first
  const sortedPlatforms = useMemo(() => {
    const statusRank: Record<PhaseStatus, number> = {
      "delayed": 0,
      "at-risk": 1,
      "on-track": 2,
      "not-started": 3,
    };
    return [...platformData].sort((a, b) => {
      const sr = statusRank[a.status] - statusRank[b.status];
      if (sr !== 0) return sr;
      const aTime = a.rtsDate?.getTime() ?? Number.POSITIVE_INFINITY;
      const bTime = b.rtsDate?.getTime() ?? Number.POSITIVE_INFINITY;
      return aTime - bTime;
    });
  }, [platformData]);

  const applyPlatformFilters = (name: string) => {
    const org = PLATFORM_ORG[name];
    const lob = PLATFORM_LOB[name];
    setFilters({
      organization: org ?? "all",
      lob: lob ?? "all",
      platform: name,
      phase: "all",
      task: "all",
    });
    setSelectedPlatform(name);
  };

  const handlePlatformClick = (name: string) => {
    if (expandable) {
      // In expandable mode (OLP Schedule – Task View), expanding/collapsing a row
      // must NOT apply a platform filter, otherwise the other platforms disappear.
      setExpandedPlatforms((prev) => {
        const next = new Set(prev);
        next.has(name) ? next.delete(name) : next.add(name);
        return next;
      });
      return;
    }
    applyPlatformFilters(name);
    navigate("/schedule", { state: { selectedProgram: name } });
  };

  return (
    <div className="bg-card rounded-2xl border border-border/40 shadow-[var(--card-shadow)] overflow-hidden">
      {/* Header */}
      {!expandable && (
        <div className="px-6 py-4 border-b border-border/30 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Calendar className="w-5 h-5 text-primary" />
            <h3 className="text-[22px] font-extrabold text-foreground tracking-tight">Portfolio Schedule</h3>
          </div>
          <div className="flex items-center gap-4">
            {/* Phase legend */}
            <div className="flex items-center gap-3 flex-wrap">
              {[
                { cls: PHASE_COLOR_COMPLETE, label: "Phase Complete" },
                { cls: "bg-success", label: "In Progress · On Track" },
                { cls: "bg-warning", label: "In Progress · At Risk w/ Mitigation" },
                { cls: "bg-destructive", label: "In Progress · At Risk w/ No Plan" },
                { cls: PHASE_COLOR_NOT_STARTED, label: "Not Started" },
              ].map(item => (
                <div key={item.label} className="flex items-center gap-1.5">
                  <span className={cn("w-2.5 h-2.5 rounded-full", item.cls)} />
                  <span className="text-[10px] text-muted-foreground font-medium">{item.label}</span>
                </div>
              ))}
              <div className="flex items-center gap-1.5">
                <span className="w-2 h-2 rotate-45 bg-purple-500" />
                <span className="text-[10px] text-muted-foreground font-medium">Milestone</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-2 h-2 rotate-45 border border-[hsl(var(--mds-navy))] bg-background" />
                <span className="text-[10px] text-muted-foreground font-medium">SChM Milestone</span>
              </div>
              <span className="text-[10px] text-muted-foreground/70 italic">Applies to both GOE/NPI and SChM tracks</span>
            </div>
            {/* Info popover */}
            <div className="relative group">
              <button className="p-1 rounded-full hover:bg-muted transition-colors" aria-label="Phase indicator definitions">
                <Info className="w-3.5 h-3.5 text-muted-foreground/50" />
              </button>
              <div className="absolute right-0 top-full mt-2 w-[360px] bg-card border border-border rounded-xl shadow-xl p-5 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-200 z-50">
                <h4 className="text-[12px] font-extrabold text-foreground mb-3">Phase Indicator Definitions</h4>
                <div className="space-y-3">
                  {[
                    { color: PHASE_COLOR_COMPLETE, title: "Phase Complete", desc: "All tasks within the phase are completed and the phase exit gate has been cleared." },
                    { color: "bg-success", title: "In Progress · On Track", desc: "Phase is currently active and progressing as planned with no schedule risks identified." },
                    { color: "bg-warning", title: "In Progress · At Risk w/ Mitigation", desc: "Phase is active with identified risks, but a mitigation plan is in place to meet the original Plan of Record (POR)." },
                    { color: "bg-destructive", title: "In Progress · At Risk w/ No Plan", desc: "Phase is active and at risk with no mitigation plan in place. Immediate action required to define a recovery path." },
                    { color: PHASE_COLOR_NOT_STARTED, title: "Not Started", desc: "Phase has not yet begun. No tasks are in progress and the entry criteria have not been triggered." },
                  ].map((item) => (
                    <div key={item.title} className="flex items-start gap-2.5">
                      <span className={cn("w-3 h-3 rounded-full mt-0.5 shrink-0", item.color)} />
                      <div>
                        <span className="text-[11px] font-bold text-foreground block">{item.title}</span>
                        <span className="text-[10px] text-muted-foreground leading-relaxed">{item.desc}</span>
                      </div>
                    </div>
                  ))}
                  <div className="flex items-start gap-2.5">
                    <span className="w-3 h-3 rotate-45 bg-purple-500 mt-0.5 shrink-0" />
                    <div>
                      <span className="text-[11px] font-bold text-foreground block">Milestone</span>
                      <span className="text-[10px] text-muted-foreground leading-relaxed">A key checkpoint within or between phases (e.g., phase exits, EVT/DVT/PVT builds, RTS).</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Export bar */}
      {!expandable && (
        <div className="flex items-center justify-end gap-3 px-6 py-3 border-b border-border/20">
          <ReportExporter context="Portfolio Schedule" />
        </div>
      )}

      {/* Gantt chart */}
      <div>
        <div className="w-full">
          {/* Month header */}
          <div className="grid grid-cols-[200px_1fr_32px] bg-muted/[0.04] border-b border-border/20">
            <div className="px-4 py-2.5 text-[10px] font-bold text-muted-foreground uppercase tracking-wider flex items-center">
              Platform
            </div>
            <div className="relative py-2.5 flex pl-[56px]">
              {monthLabels.map((m, i) => (
                <div
                  key={i}
                  className="text-[8px] text-muted-foreground font-medium text-center border-l border-border/20 first:border-l-0"
                  style={{ width: `${m.width}%`, marginLeft: i === 0 ? `${m.pct}%` : undefined }}
                >
                  {m.label}
                </div>
              ))}
            </div>
            <div />
          </div>

          {/* Empty state */}
          {sortedPlatforms.length === 0 && (
            <div className="px-6 py-10 text-center text-[12px] text-muted-foreground">
              No platforms match the current filters
            </div>
          )}

          {/* Platform rows (flat, sorted by status then RTS) */}
          {sortedPlatforms.map((platform, rowIdx) => {
            const isExpanded = expandable && expandedPlatforms.has(platform.name);
            return (
            <div key={platform.name} data-platform-row={platform.name}>
            <div
              className="grid grid-cols-[200px_1fr_32px] items-center border-b border-border/10 hover:bg-primary/[0.03] transition-colors cursor-pointer group"
              onClick={() => handlePlatformClick(platform.name)}
            >
              {/* Left label */}
              <div className="px-4 py-3.5 flex flex-col gap-1">
                <div className="flex items-center gap-2">
                  {expandable && (
                    isExpanded
                      ? <ChevronDown className="w-3 h-3 text-muted-foreground shrink-0" />
                      : <ChevronRight className="w-3 h-3 text-muted-foreground shrink-0" />
                  )}
                  <span className={cn("w-2 h-2 rounded-full shrink-0", statusDotColors[platform.status])} />
                  <span className="text-[12px] font-bold text-foreground group-hover:text-primary transition-colors">{platform.name}</span>
                </div>
                <div className="flex items-center gap-2 ml-4">
                  <Badge variant="outline" className={cn("text-[8px] border px-1.5 py-0", statusBadgeColors[platform.status])}>
                    {statusLabels[platform.status]}
                  </Badge>
                  <span className="text-[9px] text-muted-foreground tabular-nums">{platform.completed}/{platform.total}</span>
                </div>
              </div>

              {/* Timeline bars (dual-track: GOE/NPI on top, SChM on bottom) */}
              <div className="relative h-[78px]">
                {monthLabels.map((m, i) => (
                  <div
                    key={i}
                    className="absolute top-0 bottom-0 border-l border-border/10"
                    style={{ left: `${m.pct}%` }}
                  />
                ))}

                {/* Track labels — left edge, color-coded. Reserve a 56px gutter so
                    bars don't overlap the labels and phase names stay readable. */}
                <span className="absolute left-0 top-[12px] w-[52px] text-[9px] font-bold text-[hsl(var(--mds-blue))] tracking-wide uppercase pointer-events-none">
                  GOE/NPI
                </span>
                <span className="absolute left-0 top-[44px] w-[52px] text-[9px] font-bold text-[hsl(var(--mds-navy))] tracking-wide uppercase pointer-events-none">
                  SChM
                </span>

                {/* Bars are positioned inside an inset container starting after the
                    track-label gutter so phase names have visible breathing room. */}
                <div className="absolute inset-y-0 left-[56px] right-0">
                {/* GOE/NPI band */}
                {PHASE_NAMES.map(phaseName => {
                  const t = platform.timeline[phaseName];
                  if (!t) return null;
                  const left = dateToPct(t.start);
                  const right = dateToPct(t.end);
                  const width = right - left;

                  let donePct: number;
                  let hasProgress: boolean;
                  if (today >= t.end) {
                    donePct = 100;
                    hasProgress = true;
                  } else if (today <= t.start) {
                    donePct = 0;
                    hasProgress = false;
                  } else {
                    const span = t.end.getTime() - t.start.getTime();
                    donePct = Math.round(((today.getTime() - t.start.getTime()) / span) * 100);
                    hasProgress = true;
                  }

                  return (
                    <div
                      key={`goe-${phaseName}`}
                      className={cn("absolute h-5 rounded-sm overflow-hidden flex items-center justify-center", getPhaseBarColor(donePct, hasProgress, platform.status))}
                      style={{ left: `${left}%`, width: `${width}%`, top: "8px" }}
                      title={`GOE/NPI · ${phaseName}: ${donePct}% complete`}
                    >
                      {width > 2 && (
                        <span className="text-[10px] font-bold text-white drop-shadow-sm truncate px-1 leading-none">
                          {width > 5 ? `${phaseName} ${donePct}%` : `${donePct}%`}
                        </span>
                      )}
                    </div>
                  );
                })}

                {/* SChM band */}
                {SCHM_PHASES.map(phaseName => {
                  const t = platformPhaseTimelinesSchm[platform.name]?.[phaseName];
                  if (!t) return null;
                  const left = dateToPct(t.start);
                  const right = dateToPct(t.end);
                  const width = right - left;

                  let donePct: number;
                  let hasProgress: boolean;
                  if (today >= t.end) {
                    donePct = 100;
                    hasProgress = true;
                  } else if (today <= t.start) {
                    donePct = 0;
                    hasProgress = false;
                  } else {
                    const span = t.end.getTime() - t.start.getTime();
                    donePct = Math.round(((today.getTime() - t.start.getTime()) / span) * 100);
                    hasProgress = true;
                  }

                  return (
                    <div
                      key={`schm-${phaseName}`}
                      className={cn(
                        "absolute h-5 rounded-sm overflow-hidden flex items-center justify-center border-t border-dashed border-[hsl(var(--mds-navy))]/40",
                        getPhaseBarColor(donePct, hasProgress, platform.status),
                      )}
                      style={{ left: `${left}%`, width: `${width}%`, top: "40px" }}
                      title={`SChM · ${phaseName}: ${donePct}% complete`}
                    >
                      {width > 2 && (
                        <span className="text-[10px] font-bold text-white drop-shadow-sm truncate px-1 leading-none">
                          {width > 5 ? `${phaseName} ${donePct}%` : `${donePct}%`}
                        </span>
                      )}
                    </div>
                  );
                })}

                {/* Milestone diamonds — shared strip below both bands */}
                {MILESTONES.map(def => {
                  const date = computeMilestoneDate(def, platform.timeline);
                  if (!date) return null;
                  const pct = dateToPct(date);
                  return (
                    <div
                      key={def.label}
                      className="absolute z-[5] group/ms"
                      style={{ left: `${pct}%`, top: "66px", transform: "translateX(-50%)" }}
                      title={`${def.label}: ${date.toLocaleDateString()}`}
                    >
                      <div className="w-1.5 h-1.5 rotate-45 bg-purple-500" />
                      <span className="absolute top-3 left-1/2 -translate-x-1/2 mt-1 px-1.5 py-0.5 rounded bg-popover text-popover-foreground text-[9px] font-medium shadow-md border border-border/40 whitespace-nowrap opacity-0 group-hover/ms:opacity-100 transition-opacity pointer-events-none z-30">
                        {def.label}
                      </span>
                    </div>
                  );
                })}

                {/* SChM-specific milestones (Develop Exit, Launch readiness) — outlined diamonds */}
                {(() => {
                  const schmT = platformPhaseTimelinesSchm[platform.name];
                  if (!schmT) return null;
                  const items: { label: string; date: Date }[] = [];
                  if (schmT.Develop) items.push({ label: "Develop Phase Exit", date: schmT.Develop.end });
                  if (schmT.Launch) items.push({ label: "Launch Readiness", date: schmT.Launch.start });
                  return items.map(({ label, date }) => {
                    const pct = dateToPct(date);
                    return (
                      <div
                        key={label}
                        className="absolute z-[5] group/ms2"
                        style={{ left: `${pct}%`, top: "66px", transform: "translateX(-50%)" }}
                        title={`${label}: ${date.toLocaleDateString()}`}
                      >
                        <div className="w-1.5 h-1.5 rotate-45 border border-[hsl(var(--mds-navy))] bg-background" />
                        <span className="absolute top-3 left-1/2 -translate-x-1/2 mt-1 px-1.5 py-0.5 rounded bg-popover text-popover-foreground text-[9px] font-medium shadow-md border border-border/40 whitespace-nowrap opacity-0 group-hover/ms2:opacity-100 transition-opacity pointer-events-none z-30">
                          {label} · SChM
                        </span>
                      </div>
                    );
                  });
                })()}

                {platform.rtsDate && (
                  <div
                    className="absolute z-10 group/rts"
                    style={{ left: `${dateToPct(platform.rtsDate)}%`, top: "66px", transform: "translateX(-50%)" }}
                    title={`Ready to Ship: ${platform.rtsDate.toLocaleDateString()}`}
                  >
                    <div className="w-1.5 h-1.5 rotate-45 bg-purple-500" />
                    <span className="absolute top-3 left-1/2 -translate-x-1/2 mt-1 px-1.5 py-0.5 rounded bg-popover text-popover-foreground text-[9px] font-medium shadow-md border border-border/40 whitespace-nowrap opacity-0 group-hover/rts:opacity-100 transition-opacity pointer-events-none z-30">
                      Ready to Ship
                    </span>
                  </div>
                )}

                {todayInRange && (
                  <div
                    className="absolute -top-2 bottom-0 w-px bg-primary z-20 pointer-events-none"
                    style={{ left: `${todayPct}%` }}
                    aria-label="Today's date marker"
                  >
                    {rowIdx === 0 && (
                      <span className="absolute -top-3 left-1/2 -translate-x-1/2 px-1.5 py-0.5 rounded-full bg-primary text-primary-foreground text-[9px] font-bold shadow-sm whitespace-nowrap">
                        Today · {todayLabel}
                      </span>
                    )}
                  </div>
                )}
                </div>
              </div>

              {/* Arrow */}
              <div className="flex items-center justify-center">
                {expandable ? (
                  isExpanded
                    ? <ChevronDown className="w-3.5 h-3.5 text-primary" />
                    : <ChevronRight className="w-3.5 h-3.5 text-muted-foreground/30 group-hover:text-primary transition-colors" />
                ) : (
                  <ChevronRight className="w-3.5 h-3.5 text-muted-foreground/20 group-hover:text-primary transition-colors" />
                )}
              </div>
            </div>
            {isExpanded && renderExpanded && (
              <div className="border-b border-border/30">
                {renderExpanded(platform.name)}
              </div>
            )}
            </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};

export default PortfolioScheduleGantt;
