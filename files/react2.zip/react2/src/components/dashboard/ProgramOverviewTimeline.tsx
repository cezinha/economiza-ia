import React from "react";
import { motion } from "framer-motion";
import { useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { cn } from "@/lib/utils";
import { ChevronRight, Star, Info } from "lucide-react";
import { useWatchlist } from "@/contexts/WatchlistContext";
import { useUniversalFilters } from "@/contexts/UniversalFilterContext";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { getCurrentPhaseByDate } from "./PortfolioScheduleGantt";

export type PhaseStatus = "on-track" | "at-risk" | "delayed" | "complete" | "not-started";
export type ProgramStatus = "on-track" | "at-risk" | "delayed";

interface Phase {
  name: string;
  status: PhaseStatus;
  startWeek: number;
  endWeek: number;
}

export type LifecycleStatus = "active" | "sustaining" | "eol";

export interface Program {
  name: string;
  line: string;
  group?: string;
  category: "live" | "sustaining";
  lifecycleStatus: LifecycleStatus;
  eolDate?: string;
  archived?: boolean;
  startWeek: number;
  endWeek: number;
  phases: Phase[];
}

export function getProgramStatus(program: Program): ProgramStatus {
  const activePhases = program.phases.filter((p) => p.status !== "not-started" && p.status !== "complete");
  if (activePhases.some((p) => p.status === "delayed")) return "delayed";
  if (activePhases.some((p) => p.status === "at-risk")) return "at-risk";
  return "on-track";
}

export { programs };

const statusColors: Record<PhaseStatus, string> = {
  complete: "bg-success",
  "on-track": "bg-success",
  "at-risk": "bg-warning",
  delayed: "bg-destructive",
  "not-started": "bg-muted-foreground/20",
};

const programStatusDot: Record<ProgramStatus, string> = {
  "on-track": "bg-success ring-success/25",
  "at-risk": "bg-warning ring-warning/25",
  "delayed": "bg-destructive ring-destructive/25",
};

const programs: Program[] = [
  {
    name: "Laptop 1", line: "CSG", category: "live", lifecycleStatus: "active", startWeek: 1, endWeek: 10,
    phases: [
      { name: "Concept", status: "complete", startWeek: 1, endWeek: 2 },
      { name: "Define", status: "complete", startWeek: 2, endWeek: 4 },
      { name: "Plan", status: "at-risk", startWeek: 4, endWeek: 6 },
      { name: "Develop", status: "not-started", startWeek: 6, endWeek: 8 },
      { name: "Launch", status: "not-started", startWeek: 8, endWeek: 10 },
    ],
  },
  {
    name: "Laptop 2", line: "CSG", category: "live", lifecycleStatus: "active", startWeek: 3, endWeek: 12,
    phases: [
      { name: "Concept", status: "complete", startWeek: 3, endWeek: 4 },
      { name: "Define", status: "complete", startWeek: 4, endWeek: 6 },
      { name: "Plan", status: "at-risk", startWeek: 6, endWeek: 8 },
      { name: "Develop", status: "not-started", startWeek: 8, endWeek: 10 },
      { name: "Launch", status: "not-started", startWeek: 10, endWeek: 12 },
    ],
  },
  {
    name: "Laptop 3", line: "CSG", category: "live", lifecycleStatus: "active", startWeek: 0, endWeek: 10,
    phases: [
      { name: "Concept", status: "complete", startWeek: 0, endWeek: 1 },
      { name: "Define", status: "complete", startWeek: 1, endWeek: 3 },
      { name: "Plan", status: "complete", startWeek: 3, endWeek: 5 },
      { name: "Develop", status: "not-started", startWeek: 5, endWeek: 8 },
      { name: "Launch", status: "not-started", startWeek: 8, endWeek: 10 },
    ],
  },
  {
    name: "Laptop 4", line: "CSG", category: "live", lifecycleStatus: "active", startWeek: 2, endWeek: 12,
    phases: [
      { name: "Concept", status: "complete", startWeek: 2, endWeek: 3 },
      { name: "Define", status: "complete", startWeek: 3, endWeek: 5 },
      { name: "Plan", status: "not-started", startWeek: 5, endWeek: 7 },
      { name: "Develop", status: "not-started", startWeek: 7, endWeek: 10 },
      { name: "Launch", status: "not-started", startWeek: 10, endWeek: 12 },
    ],
  },
  {
    name: "Laptop 5", line: "CSG", category: "live", lifecycleStatus: "active", startWeek: 4, endWeek: 12,
    phases: [
      { name: "Concept", status: "complete", startWeek: 4, endWeek: 5 },
      { name: "Define", status: "not-started", startWeek: 5, endWeek: 7 },
      { name: "Plan", status: "not-started", startWeek: 7, endWeek: 9 },
      { name: "Develop", status: "not-started", startWeek: 9, endWeek: 11 },
      { name: "Launch", status: "not-started", startWeek: 11, endWeek: 12 },
    ],
  },
  {
    name: "Laptop 6", line: "CSG", category: "live", lifecycleStatus: "active", startWeek: 0, endWeek: 11,
    phases: [
      { name: "Concept", status: "complete", startWeek: 0, endWeek: 1 },
      { name: "Define", status: "complete", startWeek: 1, endWeek: 3 },
      { name: "Plan", status: "complete", startWeek: 3, endWeek: 6 },
      { name: "Develop", status: "not-started", startWeek: 6, endWeek: 9 },
      { name: "Launch", status: "not-started", startWeek: 9, endWeek: 11 },
    ],
  },
  {
    name: "Laptop 7", line: "CSG", category: "live", lifecycleStatus: "active", startWeek: 5, endWeek: 12,
    phases: [
      { name: "Concept", status: "complete", startWeek: 5, endWeek: 6 },
      { name: "Define", status: "complete", startWeek: 6, endWeek: 8 },
      { name: "Plan", status: "delayed", startWeek: 8, endWeek: 10 },
      { name: "Develop", status: "not-started", startWeek: 10, endWeek: 11 },
      { name: "Launch", status: "not-started", startWeek: 11, endWeek: 12 },
    ],
  },
];

const programSummary: Record<string, { phase: string; onSchedule: number; onScheduleColor: string; risks: number; productCost: string; costDelta: string; costDeltaColor: string; costDeltaDir: "up" | "down" | "flat" }> = {
  "Laptop 1": { phase: "Plan", onSchedule: 82, onScheduleColor: "text-warning", risks: 3, productCost: "$1,245", costDelta: "+5.4%", costDeltaColor: "text-destructive", costDeltaDir: "up" },
  "Laptop 2": { phase: "Qual", onSchedule: 74, onScheduleColor: "text-warning", risks: 2, productCost: "$1,180", costDelta: "+2.1%", costDeltaColor: "text-destructive", costDeltaDir: "up" },
  "Laptop 3": { phase: "Ramp", onSchedule: 96, onScheduleColor: "text-success", risks: 1, productCost: "$1,350", costDelta: "-1.2%", costDeltaColor: "text-success", costDeltaDir: "down" },
  "Laptop 4": { phase: "Define", onSchedule: 91, onScheduleColor: "text-success", risks: 4, productCost: "$1,420", costDelta: "+3.8%", costDeltaColor: "text-destructive", costDeltaDir: "up" },
  "Laptop 5": { phase: "Incubate", onSchedule: 100, onScheduleColor: "text-success", risks: 0, productCost: "$1,100", costDelta: "0%", costDeltaColor: "text-muted-foreground", costDeltaDir: "flat" },
  "Laptop 6": { phase: "Concept", onSchedule: 93, onScheduleColor: "text-success", risks: 2, productCost: "$1,290", costDelta: "-0.5%", costDeltaColor: "text-success", costDeltaDir: "down" },
  "Laptop 7": { phase: "Plan", onSchedule: 58, onScheduleColor: "text-destructive", risks: 5, productCost: "$1,500", costDelta: "+7.2%", costDeltaColor: "text-destructive", costDeltaDir: "up" },
};

interface ProgramOverviewTimelineProps {
  statusFilter?: ProgramStatus | null;
}


const ScheduleBar = ({ value, color }: { value: number; color: string }) => {
  const barColor = color === "text-success" ? "bg-success" : color === "text-warning" ? "bg-warning" : "bg-destructive";
  const barBg = color === "text-success" ? "bg-success/12" : color === "text-warning" ? "bg-warning/12" : "bg-destructive/12";
  return (
    <div className="flex items-center gap-2.5">
      <div className={cn("flex-1 h-[6px] rounded-full overflow-hidden", barBg)}>
        <motion.div
          className={cn("h-full rounded-full", barColor)}
          initial={{ width: 0 }}
          animate={{ width: `${value}%` }}
          transition={{ duration: 0.5, ease: [0.25, 0.1, 0.25, 1] }}
        />
      </div>
      <span className={cn("text-[11px] font-bold tabular-nums w-9 text-right", color)}>{value}%</span>
    </div>
  );
};



const ProgramOverviewTimeline = ({ statusFilter }: ProgramOverviewTimelineProps) => {
  const navigate = useNavigate();
  const { toggleWatchlist, isInWatchlist } = useWatchlist();
  const { matchesPlatform } = useUniversalFilters();
  const [myProgramsOnly, setMyProgramsOnly] = useState(false);
  

  const filteredPrograms = useMemo(() => {
    let result = programs.filter((p) => !p.archived && matchesPlatform(p.name));
    if (statusFilter) result = result.filter((p) => getProgramStatus(p) === statusFilter);
    if (myProgramsOnly) result = result.filter((p) => isInWatchlist(p.name));
    return result;
  }, [statusFilter, myProgramsOnly, isInWatchlist, matchesPlatform]);

  return (
    <div className="card-elevated flex flex-col overflow-hidden rounded-2xl">
      {/* Header */}
      <div className="px-6 py-4 border-b border-border/40 flex flex-wrap justify-between items-center gap-3 bg-card">
        <div className="flex items-center gap-4">
          <h3 className="font-extrabold text-[13px] text-foreground tracking-tight">Portfolio Overview</h3>
          <button
            onClick={() => setMyProgramsOnly(!myProgramsOnly)}
            className={cn(
              "px-3.5 py-1 text-[10px] font-bold rounded-full transition-all duration-200 press-scale uppercase tracking-wide border",
              myProgramsOnly
                ? "bg-primary text-primary-foreground shadow-sm border-primary"
                : "text-muted-foreground hover:text-foreground border-border/30 bg-muted/30"
            )}
          >
            My Platforms
          </button>
        </div>
        <Popover>
          <PopoverTrigger asChild>
            <button className="flex items-center gap-5 cursor-pointer hover:opacity-80 transition-opacity">
              {(["on-track", "at-risk", "delayed", "not-started"] as PhaseStatus[]).map((s) => (
                <span key={s} className="flex items-center gap-1.5 text-[10px] text-muted-foreground font-medium">
                  <span className={cn("w-2 h-2 rounded-full shrink-0", statusColors[s])} />
                  {s === "on-track" ? "On Track" : s === "at-risk" ? "At Risk w/ Mitigation" : s === "delayed" ? "At Risk w/ No Plan" : "Not Started"}
                </span>
              ))}
              <Info className="w-3.5 h-3.5 text-muted-foreground/50" />
            </button>
          </PopoverTrigger>
          <PopoverContent className="w-80 p-4" align="end">
            <h4 className="text-xs font-bold text-foreground mb-3">Status Indicator Definitions</h4>
            <div className="space-y-2.5">
              <div className="flex items-start gap-2.5">
                <span className="w-2.5 h-2.5 rounded-full bg-success shrink-0 mt-0.5" />
                <div>
                  <p className="text-[11px] font-semibold text-foreground">On Track</p>
                  <p className="text-[10px] text-muted-foreground leading-relaxed">Program is progressing as planned with no schedule risks identified.</p>
                </div>
              </div>
              <div className="flex items-start gap-2.5">
                <span className="w-2.5 h-2.5 rounded-full bg-warning shrink-0 mt-0.5" />
                <div>
                  <p className="text-[11px] font-semibold text-foreground">At Risk w/ Mitigation</p>
                  <p className="text-[10px] text-muted-foreground leading-relaxed">Program has identified risks, but a mitigation plan is in place to meet the original Plan of Record (POR).</p>
                </div>
              </div>
              <div className="flex items-start gap-2.5">
                <span className="w-2.5 h-2.5 rounded-full bg-destructive shrink-0 mt-0.5" />
                <div>
                  <p className="text-[11px] font-semibold text-foreground">At Risk w/ No Plan</p>
                  <p className="text-[10px] text-muted-foreground leading-relaxed">Program is at risk with no mitigation plan in place. Immediate action required to define recovery path.</p>
                </div>
              </div>
              <div className="flex items-start gap-2.5">
                <span className="w-2.5 h-2.5 rounded-full bg-muted-foreground/20 shrink-0 mt-0.5" />
                <div>
                  <p className="text-[11px] font-semibold text-foreground">Not Started</p>
                  <p className="text-[10px] text-muted-foreground leading-relaxed">Phase or program has not yet begun execution.</p>
                </div>
              </div>
            </div>
          </PopoverContent>
        </Popover>
      </div>

      {/* Table */}
      <div className="overflow-x-auto">
        <table className="w-full text-xs table-fixed">
          <colgroup>
            <col className="w-[4%]" />
            <col className="w-[28%]" />
            <col className="w-[20%]" />
            <col className="w-[36%]" />
            <col className="w-[12%]" />
          </colgroup>
          <thead>
            <tr className="border-b border-border/30 bg-muted/[0.08]">
              <th className="py-3 px-2"></th>
              <th className="text-left py-3 px-5 text-[10px] text-muted-foreground font-bold uppercase tracking-wider">Platform</th>
              <th className="text-left py-3 px-4 text-[10px] text-muted-foreground font-bold uppercase tracking-wider">Phase</th>
              <th className="text-left py-3 px-4 text-[10px] text-muted-foreground font-bold uppercase tracking-wider">On Schedule</th>
              <th className="text-center py-3 px-4 text-[10px] text-muted-foreground font-bold uppercase tracking-wider">Risks</th>
            </tr>
          </thead>
          <tbody>
            {(() => {
              const ALL_SECTIONS = ["CSG", "ISG", "DnCP"] as const;
              const grouped: Record<string, typeof filteredPrograms> = {};
              ALL_SECTIONS.forEach((s) => { grouped[s] = []; });
              filteredPrograms.forEach((p) => {
                if (!grouped[p.line]) grouped[p.line] = [];
                grouped[p.line].push(p);
              });

              const rows: React.ReactNode[] = [];
              let globalIdx = 0;
              ALL_SECTIONS.forEach((section) => {
                const sectionPrograms = grouped[section] ?? [];
                rows.push(
                  <tr key={`header-${section}`}>
                    <td colSpan={5} className="px-5 pt-4 pb-1">
                      <span className="text-[10px] font-black uppercase tracking-[0.15em] text-muted-foreground/70">
                        {section} <span className="font-semibold text-muted-foreground/40">({sectionPrograms.length} platforms)</span>
                      </span>
                    </td>
                  </tr>
                );
                if (sectionPrograms.length === 0) {
                  rows.push(
                    <tr key={`empty-${section}`}>
                      <td colSpan={5} className="px-8 py-3">
                        <span className="text-[10px] text-muted-foreground/40 italic">No platforms in this category</span>
                      </td>
                    </tr>
                  );
                } else {
                  sectionPrograms.forEach((program) => {
                    const summary = programSummary[program.name];
                    const status = getProgramStatus(program);
                    const idx = globalIdx++;
                    rows.push(
                      <motion.tr
                        key={program.name}
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        transition={{ duration: 0.2, delay: idx * 0.02 }}
                        className={cn(
                          "border-b border-border/15 cursor-pointer transition-all duration-200 group",
                          "hover:bg-primary/[0.03]",
                          idx % 2 === 0 ? "bg-transparent" : "bg-muted/[0.04]"
                        )}
                        onClick={() => navigate("/platform-summary", { state: { selectedProgram: program.name } })}
                      >
                        <td className="py-3.5 px-2 text-center">
                          <button
                            onClick={(e) => { e.stopPropagation(); toggleWatchlist(program.name); }}
                            className="p-1 rounded-lg hover:bg-muted/50 transition-colors press-scale"
                            aria-label={`${isInWatchlist(program.name) ? "Remove" : "Add"} ${program.name} ${isInWatchlist(program.name) ? "from" : "to"} watchlist`}
                          >
                            <Star className={cn("w-3.5 h-3.5 transition-colors", isInWatchlist(program.name) ? "text-warning fill-warning" : "text-muted-foreground/30 hover:text-warning/60")} />
                          </button>
                        </td>
                        <td className="py-3.5 px-4 pl-4 font-bold text-foreground">
                          <div className="flex items-center gap-2.5">
                            <span className={cn("w-2.5 h-2.5 rounded-full shrink-0 ring-[1.5px] ring-offset-1 ring-offset-card", programStatusDot[status])} />
                            <span className="group-hover:text-primary transition-colors text-[12px]">{program.name}</span>
                            <ChevronRight className="w-3 h-3 text-muted-foreground/20 opacity-0 group-hover:opacity-100 group-hover:text-primary transition-all group-hover:translate-x-0.5" />
                          </div>
                        </td>
                        <td className="py-3.5 px-4 text-muted-foreground font-semibold text-[11px]">{getCurrentPhaseByDate(program.name)}</td>
                        <td className="py-3.5 px-4">
                          {summary ? <ScheduleBar value={summary.onSchedule} color={summary.onScheduleColor} /> : <span className="text-muted-foreground">—</span>}
                        </td>
                        <td className="py-3.5 px-4 text-center">
                          {summary && summary.risks > 0 ? (
                            <span className={cn(
                              "inline-flex items-center justify-center w-6 h-6 rounded-full text-[10px] font-black",
                              summary.risks >= 4 ? "bg-destructive/10 text-destructive" : summary.risks >= 2 ? "bg-warning/10 text-warning" : "bg-muted/40 text-muted-foreground"
                            )}>
                              {summary.risks}
                            </span>
                          ) : (
                            <span className="text-muted-foreground/25 text-[10px]">—</span>
                          )}
                        </td>
                      </motion.tr>
                    );
                  });
                }
              });
              return rows;
            })()}
          </tbody>
        </table>
      </div>

      {/* Footer */}
      <div className="px-6 py-2.5 border-t border-border/20 bg-muted/[0.03] flex items-center justify-between">
        <span className="text-[10px] text-muted-foreground">
          Showing <span className="font-bold text-foreground">{filteredPrograms.length}</span> of {programs.length} programs
        </span>
        <span className="text-[10px] text-muted-foreground">
          Last updated <span className="font-bold text-foreground">2 min ago</span>
        </span>
      </div>

    </div>
  );
};

export default ProgramOverviewTimeline;
