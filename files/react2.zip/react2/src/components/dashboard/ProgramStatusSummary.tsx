import { useMemo } from "react";
import { motion } from "framer-motion";
import { CheckCircle2, AlertTriangle, XCircle } from "lucide-react";
import { cn } from "@/lib/utils";
import { programs, type ProgramStatus } from "./ProgramOverviewTimeline";
import { useUniversalFilters } from "@/contexts/UniversalFilterContext";
import { programSchedules } from "@/data/scheduleData";
import { computeProgramStatus } from "./PortfolioScheduleGantt";

// Derive program status from its full task list (calendar-aware).
const getScheduleStatus = (programName: string): ProgramStatus => {
  const phases = programSchedules[programName] || [];
  const rollup = computeProgramStatus(phases, programName);
  if (rollup === "delayed") return "delayed";
  if (rollup === "at-risk") return "at-risk";
  return "on-track";
};

interface ProgramStatusSummaryProps {
  activeStatus: ProgramStatus | null;
  onStatusClick: (status: ProgramStatus | null) => void;
}

const statusConfig: {
  key: ProgramStatus;
  label: string;
  subtitle: string;
  icon: typeof CheckCircle2;
  topBar: string;
  iconBg: string;
  iconClass: string;
  textClass: string;
  ringClass: string;
  barClass: string;
}[] = [
  {
    key: "on-track",
    label: "On Track",
    subtitle: "Progressing as planned",
    icon: CheckCircle2,
    topBar: "from-success to-success/60",
    iconBg: "bg-success/10",
    iconClass: "text-success",
    textClass: "text-success",
    ringClass: "ring-success/30 border-success/20",
    barClass: "bg-success",
  },
  {
    key: "at-risk",
    label: "At Risk w/ Mitigation",
    subtitle: "Mitigation plan in place to meet POR",
    icon: AlertTriangle,
    topBar: "from-warning to-warning/60",
    iconBg: "bg-warning/10",
    iconClass: "text-warning",
    textClass: "text-warning",
    ringClass: "ring-warning/30 border-warning/20",
    barClass: "bg-warning",
  },
  {
    key: "delayed",
    label: "At Risk w/ No Plan",
    subtitle: "No mitigation plan in place",
    icon: XCircle,
    topBar: "from-destructive to-destructive/60",
    iconBg: "bg-destructive/10",
    iconClass: "text-destructive",
    textClass: "text-destructive",
    ringClass: "ring-destructive/30 border-destructive/20",
    barClass: "bg-destructive",
  },
];

const ProgramStatusSummary = ({ activeStatus, onStatusClick }: ProgramStatusSummaryProps) => {
  const { matchesPlatform } = useUniversalFilters();
  const filteredProgs = useMemo(() => programs.filter(p => !p.archived && matchesPlatform(p.name)), [matchesPlatform]);

  const counts: Record<ProgramStatus, number> = { "on-track": 0, "at-risk": 0, delayed: 0 };
  const programsByStatus: Record<ProgramStatus, string[]> = { "on-track": [], "at-risk": [], delayed: [] };

  filteredProgs.forEach((p) => {
    const s = getScheduleStatus(p.name);
    counts[s]++;
    programsByStatus[s].push(p.name);
  });

  const total = filteredProgs.length;

  return (
    <div className="grid grid-cols-3 gap-5">
      {statusConfig.map((cfg, idx) => {
        const count = counts[cfg.key];
        const pct = total > 0 ? Math.round((count / total) * 100) : 0;
        const isActive = activeStatus === cfg.key;
        const Icon = cfg.icon;

        return (
          <motion.div
            key={cfg.key}
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.35, delay: idx * 0.06 }}
            onClick={() => onStatusClick(isActive ? null : cfg.key)}
            className={cn(
              "card-elevated cursor-pointer rounded-2xl border overflow-hidden relative group press-scale",
              isActive
                ? `ring-2 ring-offset-2 ring-offset-background ${cfg.ringClass}`
                : "border-border/50 hover:border-border"
            )}
            whileHover={{ y: -2 }}
          >
            {/* Top gradient accent */}
            <div className={cn("h-1 w-full bg-gradient-to-r", cfg.topBar)} />

            <div className="p-5">
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center gap-2.5">
                  <div className={cn("w-9 h-9 rounded-xl flex items-center justify-center", cfg.iconBg)}>
                    <Icon className={cn("h-[18px] w-[18px]", cfg.iconClass)} />
                  </div>
                  <div>
                    <h3 className="text-[13px] font-bold text-foreground">{cfg.label}</h3>
                    <p className="text-[10px] text-muted-foreground">{cfg.subtitle}</p>
                  </div>
                </div>
                <div className="text-right">
                  <span className={cn("text-[42px] font-black tabular-nums leading-none tracking-tighter", cfg.textClass)}>{count}</span>
                  <p className="text-[10px] text-muted-foreground mt-0.5 tabular-nums font-semibold">{pct}% of total</p>
                </div>
              </div>

              {/* Progress bar */}
              <div className="h-1 w-full rounded-full bg-muted/30 mb-3.5 overflow-hidden">
                <motion.div
                  className={cn("h-full rounded-full", cfg.barClass)}
                  initial={{ width: 0 }}
                  animate={{ width: `${pct}%` }}
                  transition={{ duration: 0.7, delay: 0.2 + idx * 0.1, ease: [0.25, 0.1, 0.25, 1] }}
                />
              </div>

              {/* Program pills */}
              <div className="flex flex-wrap gap-1.5">
                {programsByStatus[cfg.key].map((name) => (
                  <span key={name} className="inline-flex items-center gap-1.5 text-[10px] text-foreground/60 bg-muted/25 px-2.5 py-1 rounded-full font-medium border border-border/25">
                    <span className={cn("w-1.5 h-1.5 rounded-full", cfg.barClass)} />
                    {name}
                  </span>
                ))}
                {programsByStatus[cfg.key].length === 0 && (
                  <span className="text-[10px] text-muted-foreground/40 italic">No programs</span>
                )}
              </div>
            </div>
          </motion.div>
        );
      })}
    </div>
  );
};

export default ProgramStatusSummary;
