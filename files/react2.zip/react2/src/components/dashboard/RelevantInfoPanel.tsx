import { FileText, Calendar, Database, ExternalLink, Layers, Sparkles } from "lucide-react";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import type { ScheduleTask } from "@/data/scheduleData";
import { isAutoCompletedTask, AUTO_COMPLETED_OWNER } from "@/data/taskParticipants";

interface RelevantInfoPanelProps {
  task: ScheduleTask;
  phaseName: string;
}

// Map task keywords to relevant documents for the right-hand panel
const getRelevantDocuments = (task: ScheduleTask): { label: string; type: "document" | "data" | "link"; date?: string }[] => {
  const docs: { label: string; type: "document" | "data" | "link"; date?: string }[] = [];
  const name = task.name.toLowerCase();

  // Add date-based info
  const tsDate = new Date();
  tsDate.setDate(tsDate.getDate() + 14);
  docs.push({
    label: `RTS Date: ${tsDate.toLocaleDateString("en-US", { month: "2-digit", day: "2-digit", year: "numeric" })}`,
    type: "data",
  });

  // Derive documents from task data sources
  if (task.dataSources) {
    task.dataSources.forEach((src) => {
      if (src === "PRD") docs.push({ label: "PRD (Product Requirements Document)", type: "document", date: "Latest: Apr 2, 2026" });
      if (src === "Confluence") docs.push({ label: "Confluence Page", type: "link", date: "Updated: Apr 8, 2026" });
      if (src === "Jira") docs.push({ label: "Jira Tracker", type: "link", date: "Active" });
      if (src === "Memory Matrix") docs.push({ label: "Memory Matrix", type: "data", date: "Latest: Mar 28, 2026" });
      if (src === "SAP") docs.push({ label: "SAP Data", type: "data", date: "Synced: Apr 10, 2026" });
    });
  }

  // Add contextual documents based on task name keywords
  if (name.includes("ard") || name.includes("architecture")) {
    docs.push({ label: "ARD (Architecture Requirements Document)", type: "document", date: "Latest: Mar 15, 2026" });
  }
  if (name.includes("edd") || name.includes("engineering definition")) {
    docs.push({ label: "EDD (Engineering Definition Document)", type: "document", date: "Latest: Mar 20, 2026" });
  }
  if (name.includes("charter")) {
    docs.push({ label: "Program Charter Template", type: "document", date: "Latest: Feb 10, 2026" });
  }
  if (name.includes("bom") || name.includes("bill of materials")) {
    docs.push({ label: "BOM Structure File", type: "document", date: "Latest: Apr 1, 2026" });
  }
  if (name.includes("nudd") || name.includes("dfx") || name.includes("dfm")) {
    docs.push({ label: "NUDD Register", type: "data", date: "Active" });
    docs.push({ label: "DFx Assessment Report", type: "document", date: "Latest: Mar 25, 2026" });
  }
  if (name.includes("rfq")) {
    docs.push({ label: "RFQ Package", type: "document", date: "Latest: Mar 30, 2026" });
  }
  if (name.includes("schedule") || name.includes("frc") || name.includes("rts")) {
    docs.push({ label: "Operations Schedule", type: "document", date: "Latest: Apr 5, 2026" });
  }
  if (name.includes("fulfillment") || name.includes("logistics")) {
    docs.push({ label: "Fulfillment Model", type: "document", date: "Latest: Apr 3, 2026" });
  }
  if (name.includes("audit") || name.includes("sma") || name.includes("supplier")) {
    docs.push({ label: "Supplier Audit Report", type: "document", date: "Latest: Mar 22, 2026" });
  }
  if (name.includes("cost") || name.includes("cost bridge")) {
    docs.push({ label: "Cost Bridge Workbook", type: "document", date: "Latest: Apr 7, 2026" });
  }
  if (name.includes("kpi") || name.includes("yield") || name.includes("quality")) {
    docs.push({ label: "KPI Dashboard Export", type: "data", date: "Latest: Apr 9, 2026" });
  }
  if (name.includes("build") || name.includes("dvt") || name.includes("pvt")) {
    docs.push({ label: "Build Execution Plan", type: "document", date: "Latest: Apr 6, 2026" });
  }

  // Deduplicate by label
  const seen = new Set<string>();
  return docs.filter((d) => {
    if (seen.has(d.label)) return false;
    seen.add(d.label);
    return true;
  });
};

const iconMap = {
  document: <FileText className="w-3.5 h-3.5 text-primary shrink-0" />,
  data: <Database className="w-3.5 h-3.5 text-[hsl(var(--mds-success))] shrink-0" />,
  link: <ExternalLink className="w-3.5 h-3.5 text-[hsl(var(--mds-blue))] shrink-0" />,
};

const RelevantInfoPanel = ({ task, phaseName }: RelevantInfoPanelProps) => {
  const relevantDocs = getRelevantDocuments(task);

  return (
    <div className="flex flex-col h-full border border-border/60 rounded-lg bg-card overflow-hidden shadow-sm">
      <div className="px-4 py-3 border-b border-border/60 bg-gradient-to-r from-[hsl(var(--mds-blue))]/5 to-transparent">
        <h2 className="text-[10px] font-bold text-foreground uppercase tracking-[0.12em]">
          Relevant Information
        </h2>
      </div>
      <ScrollArea className="flex-1">
        <div className="p-4 space-y-4">
          {/* Task context */}
          <div className="rounded-lg border border-border/60 bg-gradient-to-b from-muted/20 to-transparent p-3">
            <div className="flex items-center gap-1.5 mb-1.5">
              <Sparkles className="w-3 h-3 text-[hsl(var(--mds-blue))]" />
              <span className="text-[10px] uppercase tracking-wider text-muted-foreground font-bold">
                Selected Task
              </span>
            </div>
            <p className="text-[12px] font-semibold text-foreground leading-relaxed">{task.name}</p>
            <div className="flex items-center gap-1.5 mt-2 flex-wrap">
              <Badge variant="outline" className="text-[9px] font-medium">{phaseName}</Badge>
              <Badge variant="secondary" className="text-[9px] font-medium">{isAutoCompletedTask(task) ? AUTO_COMPLETED_OWNER : task.owner}</Badge>
            </div>
          </div>

          {/* Documents & Data Sources */}
          <div className="space-y-2">
            <div className="flex items-center gap-1.5">
              <Layers className="w-3 h-3 text-muted-foreground" />
              <span className="text-[10px] uppercase tracking-wider text-muted-foreground font-bold">
                Documents & Data Sources
              </span>
            </div>
            <div className="space-y-1.5">
              {relevantDocs.map((doc, idx) => (
                <div
                  key={idx}
                  className="group flex items-start gap-2 p-2.5 rounded-lg border border-border/50 bg-card hover:bg-muted/30 hover:border-border hover:shadow-sm transition-all cursor-pointer"
                >
                  <div className="mt-0.5">{iconMap[doc.type]}</div>
                  <div className="flex-1 min-w-0">
                    <p className="text-[11px] font-semibold text-foreground leading-tight group-hover:text-[hsl(var(--mds-blue))] transition-colors">{doc.label}</p>
                    {doc.date && (
                      <p className="text-[9px] text-muted-foreground mt-0.5">{doc.date}</p>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Requirement Doc */}
          {task.requirementDoc && (
            <div className="space-y-2">
              <div className="flex items-center gap-1.5">
                <FileText className="w-3 h-3 text-muted-foreground" />
                <span className="text-[10px] uppercase tracking-wider text-muted-foreground font-bold">
                  Requirement Document
                </span>
              </div>
              <div className="flex items-center gap-2 p-2.5 rounded-lg border border-primary/20 bg-primary/5 hover:bg-primary/10 transition-colors cursor-pointer">
                <FileText className="w-3.5 h-3.5 text-primary shrink-0" />
                <span className="text-[11px] text-primary font-medium underline truncate">{task.requirementDoc}</span>
              </div>
            </div>
          )}

          {/* Source indicator */}
          <div className="p-3 rounded-lg bg-gradient-to-br from-primary/5 to-[hsl(var(--mds-blue))]/5 border border-primary/15">
            <div className="flex items-center gap-1.5 mb-1">
              <Calendar className="w-3 h-3 text-primary" />
              <span className="text-[10px] font-bold text-primary uppercase tracking-wider">From Doc Curator</span>
            </div>
            <p className="text-[10px] text-muted-foreground leading-relaxed">
              Documents and data sources are dynamically pulled from the Doc Curator based on task relevance and recency.
            </p>
          </div>
        </div>
      </ScrollArea>
    </div>
  );
};

export default RelevantInfoPanel;
