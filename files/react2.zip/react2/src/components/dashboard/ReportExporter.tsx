import { Download, FileText, Table } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { useToast } from "@/hooks/use-toast";

interface ReportExporterProps {
  context: string; // e.g. "Schedule", "Phase Gate", "Platform Summary"
}

const ReportExporter = ({ context }: ReportExporterProps) => {
  const { toast } = useToast();

  const handleExport = (format: "excel" | "pdf") => {
    toast({
      title: `${format.toUpperCase()} Export Started`,
      description: `Generating ${context} report as ${format.toUpperCase()}...`,
    });
    // Simulated export delay
    setTimeout(() => {
      toast({
        title: "Export Complete",
        description: `${context} report downloaded as ${format.toUpperCase()}.`,
      });
    }, 1500);
  };

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="outline" size="sm" className="h-7 text-xs gap-1.5">
          <Download className="w-3 h-3" />
          Export
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-40">
        <DropdownMenuItem onClick={() => handleExport("excel")} className="text-xs gap-2 cursor-pointer">
          <Table className="w-3.5 h-3.5" />
          Export as Excel
        </DropdownMenuItem>
        <DropdownMenuItem onClick={() => handleExport("pdf")} className="text-xs gap-2 cursor-pointer">
          <FileText className="w-3.5 h-3.5" />
          Export as PDF
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
};

export default ReportExporter;
