import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import type { TaskStatus } from "@/data/scheduleData";

interface StatusChangeDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  taskName: string;
  newStatus: TaskStatus;
  onConfirm: (reason: string) => void;
}

const statusLabels: Record<TaskStatus, string> = {
  completed: "Completed",
  "on-track": "On Track",
  "at-risk": "At Risk",
  pending: "Pending",
  late: "Late",
};

const StatusChangeDialog = ({ open, onOpenChange, taskName, newStatus, onConfirm }: StatusChangeDialogProps) => {
  const [reason, setReason] = useState("");

  const handleConfirm = () => {
    if (!reason.trim()) return;
    onConfirm(reason.trim());
    setReason("");
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="text-sm">Status Change Required</DialogTitle>
          <DialogDescription className="text-xs">
            Please provide a reason for changing the status of <strong>{taskName}</strong> to <strong>{statusLabels[newStatus]}</strong>.
          </DialogDescription>
        </DialogHeader>
        <Textarea
          placeholder="Enter reason for status change..."
          value={reason}
          onChange={(e) => setReason(e.target.value)}
          className="min-h-[80px] text-xs"
        />
        <DialogFooter>
          <Button variant="outline" size="sm" onClick={() => onOpenChange(false)} className="text-xs">
            Cancel
          </Button>
          <Button size="sm" onClick={handleConfirm} disabled={!reason.trim()} className="text-xs">
            Confirm Change
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default StatusChangeDialog;
