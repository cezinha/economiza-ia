import { useState, useMemo } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import { Plus, Trash2, FileText } from "lucide-react";
import { programSchedules, phaseExitDates, computeRollupStatus, type Phase, type PhaseStatus } from "@/data/scheduleData";
import type { Program } from "./ProgramOverviewTimeline";
import { getProgramStatus } from "./ProgramOverviewTimeline";

/* ------------------------------------------------------------------ */
/*  Types                                                              */
/* ------------------------------------------------------------------ */

interface Challenge {
  id: string;
  challenge: string;
  businessImpact: string;
  severity: "High" | "Medium" | "Low";
  rootCause: string;
  actionRequired: string;
  ownerDue: string;
}

interface StatusUpdateModalProps {
  open: boolean;
  onClose: () => void;
  program: Program;
}

/* ------------------------------------------------------------------ */
/*  Helpers                                                            */
/* ------------------------------------------------------------------ */

const PHASE_NAMES = ["Concept / Define", "Plan", "Develop", "RTS"] as const;

const phaseBarColors: Record<string, string> = {
  "on-track": "bg-success",
  "at-risk": "bg-warning",
  delayed: "bg-destructive",
  "not-started": "bg-muted-foreground/30",
  complete: "bg-success",
};

const statusLabel: Record<string, string> = {
  "on-track": "On Track",
  "at-risk": "At Risk w/ Mitigation",
  delayed: "At Risk w/ No Plan",
  "not-started": "Not Started",
  complete: "Achieved / On Track",
};

const statusDot: Record<string, string> = {
  "on-track": "bg-success",
  "at-risk": "bg-warning",
  delayed: "bg-destructive",
  "not-started": "bg-muted-foreground/30",
};

const severityColors: Record<string, string> = {
  High: "bg-destructive/10 text-destructive border-destructive/20",
  Medium: "bg-warning/10 text-warning border-warning/20",
  Low: "bg-success/10 text-success border-success/20",
};

/* ------------------------------------------------------------------ */
/*  Auto-derive data from schedule                                     */
/* ------------------------------------------------------------------ */

function deriveOlpStatus(phases: Phase[]): string[] {
  const bullets: string[] = [];
  const allTasks = phases.flatMap((p) => p.milestones.flatMap((m) => m.tasks));
  const completed = allTasks.filter((t) => t.status === "completed").length;
  const late = allTasks.filter((t) => t.status === "late").length;
  const pending = allTasks.filter((t) => t.status === "pending").length;
  const total = allTasks.length;

  const overallStatus = computeRollupStatus(allTasks);
  const statusText = overallStatus === "on-track" ? "Green" : overallStatus === "at-risk" ? "Yellow" : overallStatus === "delayed" ? "Red" : "Not Started";

  bullets.push(`CT Overall Status: Program is in ${statusText}.`);
  bullets.push(`${completed}/${total} tasks completed (${Math.round((completed / total) * 100)}%).`);

  if (late > 0) {
    bullets.push(`${late} task${late > 1 ? "s" : ""} currently late — requires attention.`);
  }
  if (pending > 0) {
    bullets.push(`${pending} task${pending > 1 ? "s" : ""} not yet started.`);
  }

  // Current phase
  const activePhase = phases.find((p) => {
    const tasks = p.milestones.flatMap((m) => m.tasks);
    return tasks.some((t) => t.status === "on-track" || t.status === "late");
  });
  if (activePhase) {
    bullets.push(`Currently executing ${activePhase.name} phase.`);
  }

  return bullets;
}

function deriveGoeStatus(phases: Phase[]): string[] {
  const bullets: string[] = [];
  const allTasks = phases.flatMap((p) => p.milestones.flatMap((m) => m.tasks));

  // Find tasks by owner category
  const goeLateTasks = allTasks.filter((t) => t.owner.includes("GOE") && t.status === "late");
  const schmLateTasks = allTasks.filter((t) => t.owner.includes("SChM") && t.status === "late");
  const npiLateTasks = allTasks.filter((t) => t.owner.includes("NPI") && t.status === "late");

  if (goeLateTasks.length > 0) {
    bullets.push(`GOE has ${goeLateTasks.length} late task${goeLateTasks.length > 1 ? "s" : ""}: ${goeLateTasks.slice(0, 2).map((t) => t.name).join("; ")}.`);
  } else {
    bullets.push("GOE tasks are on track — no outstanding delays.");
  }

  if (schmLateTasks.length > 0) {
    bullets.push(`Supply Chain has ${schmLateTasks.length} late task${schmLateTasks.length > 1 ? "s" : ""} requiring resolution.`);
  }

  if (npiLateTasks.length > 0) {
    bullets.push(`NPI has ${npiLateTasks.length} late task${npiLateTasks.length > 1 ? "s" : ""} impacting build readiness.`);
  }

  // NUDD / risk summary
  const nuddTasks = allTasks.filter((t) => t.name.toLowerCase().includes("nudd"));
  const completedNudds = nuddTasks.filter((t) => t.status === "completed").length;
  if (nuddTasks.length > 0) {
    bullets.push(`NUDD tracking: ${completedNudds}/${nuddTasks.length} NUDD tasks completed.`);
  }

  return bullets;
}

function deriveChallenges(phases: Phase[], programName: string): Challenge[] {
  const allTasks = phases.flatMap((p) => p.milestones.flatMap((m) => m.tasks));
  const lateTasks = allTasks.filter((t) => t.status === "late");

  return lateTasks.slice(0, 5).map((task, i) => ({
    id: `ch-${i}`,
    challenge: task.name,
    businessImpact: `Delay in ${task.name.includes("BOM") || task.name.includes("cost") ? "cost validation" : task.name.includes("supply") || task.name.includes("ODM") ? "supply chain readiness" : "program milestone"}`,
    severity: task.owner.includes("SChM") || task.name.toLowerCase().includes("cost") ? "High" as const : "Medium" as const,
    rootCause: task.statusReason || "Task dependencies not yet resolved",
    actionRequired: `Escalate to ${task.owner} team for resolution plan`,
    ownerDue: `${task.owner} (${new Date().toLocaleDateString("en-US", { month: "numeric", day: "numeric" })})`,
  }));
}

function derivePhaseTimeline(phases: Phase[], programName: string) {
  const exitDates = phaseExitDates[programName];
  return phases.map((phase) => {
    const tasks = phase.milestones.flatMap((m) => m.tasks);
    const status = computeRollupStatus(tasks);
    const completed = tasks.filter((t) => t.status === "completed").length;
    const total = tasks.length;
    const pct = total > 0 ? Math.round((completed / total) * 100) : 0;
    const exitDate = exitDates?.[phase.name];
    return { name: phase.name, status, pct, exitDate };
  });
}

/* ------------------------------------------------------------------ */
/*  Component                                                          */
/* ------------------------------------------------------------------ */

const StatusUpdateModal = ({ open, onClose, program }: StatusUpdateModalProps) => {
  const phases = programSchedules[program.name] || [];
  const overallStatus = getProgramStatus(program);

  const timeline = useMemo(() => derivePhaseTimeline(phases, program.name), [phases, program.name]);
  const olpBullets = useMemo(() => deriveOlpStatus(phases), [phases]);
  const goeBullets = useMemo(() => deriveGoeStatus(phases), [phases]);
  const autoChallenges = useMemo(() => deriveChallenges(phases, program.name), [phases, program.name]);

  // Editable state
  const [olpNotes, setOlpNotes] = useState("");
  const [goeNotes, setGoeNotes] = useState("");
  const [challenges, setChallenges] = useState<Challenge[]>(autoChallenges);

  const addChallenge = () => {
    setChallenges((prev) => [
      ...prev,
      {
        id: `manual-${Date.now()}`,
        challenge: "",
        businessImpact: "",
        severity: "Medium",
        rootCause: "",
        actionRequired: "",
        ownerDue: "",
      },
    ]);
  };

  const updateChallenge = (id: string, field: keyof Challenge, value: string) => {
    setChallenges((prev) =>
      prev.map((c) => (c.id === id ? { ...c, [field]: value } : c))
    );
  };

  const removeChallenge = (id: string) => {
    setChallenges((prev) => prev.filter((c) => c.id !== id));
  };

  return (
    <Dialog open={open} onOpenChange={(v) => !v && onClose()}>
      <DialogContent className="max-w-[900px] max-h-[90vh] overflow-y-auto p-0">
        <DialogHeader className="px-6 pt-6 pb-3 border-b border-border/40">
          <DialogTitle className="flex items-center gap-3 text-base font-bold">
            <FileText className="w-4 h-4 text-primary" />
            {program.name} — Status Update
            <Badge className={cn("text-[9px] ml-auto", statusDot[overallStatus] ? `${severityColors[overallStatus === "delayed" ? "High" : overallStatus === "at-risk" ? "Medium" : "Low"]}` : "")}>
              {statusLabel[overallStatus] ?? overallStatus}
            </Badge>
          </DialogTitle>
        </DialogHeader>

        <div className="px-6 py-4 space-y-5">
          {/* Phase Timeline Bar */}
          <div className="space-y-2">
            <h3 className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground">Phase Timeline</h3>
            <div className="flex gap-1 h-8 rounded-lg overflow-hidden border border-border/40">
              {timeline.map((phase, i) => (
                <div
                  key={phase.name}
                  className={cn(
                    "flex-1 flex items-center justify-center gap-1.5 text-[9px] font-bold text-white relative",
                    phaseBarColors[phase.status as PhaseStatus] || "bg-muted-foreground/30",
                    i === 0 && "rounded-l-lg",
                    i === timeline.length - 1 && "rounded-r-lg"
                  )}
                >
                  <span className="truncate px-1">{phase.name}</span>
                  <span className="opacity-80">{phase.pct}%</span>
                </div>
              ))}
            </div>
            {/* Milestone dates */}
            <div className="flex gap-1">
              {timeline.map((phase) => (
                <div key={phase.name} className="flex-1 text-center">
                  {phase.exitDate ? (
                    <span className="text-[9px] text-muted-foreground font-medium">
                      Exit: {new Date(phase.exitDate).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "2-digit" })}
                    </span>
                  ) : (
                    <span className="text-[9px] text-muted-foreground/40">—</span>
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* OLP Status + GOE Status side by side */}
          <div className="grid grid-cols-2 gap-4">
            <div className="border border-border/40 rounded-lg p-4 space-y-2">
              <h3 className="text-[10px] font-bold uppercase tracking-wider text-primary">OLP Status</h3>
              <ul className="space-y-1.5">
                {olpBullets.map((bullet, i) => (
                  <li key={i} className="text-[11px] text-foreground leading-snug flex gap-1.5">
                    <span className="text-primary mt-0.5">•</span>
                    <span>{bullet}</span>
                  </li>
                ))}
              </ul>
              <Textarea
                placeholder="Add additional OLP status notes..."
                value={olpNotes}
                onChange={(e) => setOlpNotes(e.target.value)}
                className="text-[11px] h-16 mt-2 resize-none"
              />
            </div>

            <div className="border border-border/40 rounded-lg p-4 space-y-2">
              <h3 className="text-[10px] font-bold uppercase tracking-wider text-primary">GOE Status</h3>
              <ul className="space-y-1.5">
                {goeBullets.map((bullet, i) => (
                  <li key={i} className="text-[11px] text-foreground leading-snug flex gap-1.5">
                    <span className="text-primary mt-0.5">•</span>
                    <span>{bullet}</span>
                  </li>
                ))}
              </ul>
              <Textarea
                placeholder="Add additional GOE status notes..."
                value={goeNotes}
                onChange={(e) => setGoeNotes(e.target.value)}
                className="text-[11px] h-16 mt-2 resize-none"
              />
            </div>
          </div>

          {/* Key Challenges Table */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <h3 className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground">Key Challenges / Escalations</h3>
              <Button variant="outline" size="sm" className="h-7 text-[10px] gap-1.5" onClick={addChallenge}>
                <Plus className="w-3 h-3" />
                Add Row
              </Button>
            </div>

            <div className="border border-border/40 rounded-lg overflow-hidden">
              <table className="w-full text-[10px]">
                <thead>
                  <tr className="bg-primary text-primary-foreground">
                    <th className="text-left py-2 px-2.5 font-bold w-[16%]">Key Challenges</th>
                    <th className="text-left py-2 px-2.5 font-bold w-[16%]">Business Impacts</th>
                    <th className="text-center py-2 px-2.5 font-bold w-[8%]">Severity</th>
                    <th className="text-left py-2 px-2.5 font-bold w-[18%]">Root Causes</th>
                    <th className="text-left py-2 px-2.5 font-bold w-[22%]">Action Required</th>
                    <th className="text-left py-2 px-2.5 font-bold w-[14%]">Owner / Due</th>
                    <th className="py-2 px-1.5 w-[6%]"></th>
                  </tr>
                </thead>
                <tbody>
                  {challenges.length === 0 && (
                    <tr>
                      <td colSpan={7} className="text-center py-6 text-muted-foreground italic text-[11px]">
                        No key challenges identified — click "Add Row" to add manually
                      </td>
                    </tr>
                  )}
                  {challenges.map((ch) => (
                    <tr key={ch.id} className="border-t border-border/30 hover:bg-muted/30">
                      <td className="py-1.5 px-2">
                        <Input
                          value={ch.challenge}
                          onChange={(e) => updateChallenge(ch.id, "challenge", e.target.value)}
                          className="h-7 text-[10px] border-0 bg-transparent px-1 focus-visible:ring-1"
                          placeholder="Enter challenge..."
                        />
                      </td>
                      <td className="py-1.5 px-2">
                        <Input
                          value={ch.businessImpact}
                          onChange={(e) => updateChallenge(ch.id, "businessImpact", e.target.value)}
                          className="h-7 text-[10px] border-0 bg-transparent px-1 focus-visible:ring-1"
                          placeholder="Business impact..."
                        />
                      </td>
                      <td className="py-1.5 px-2">
                        <Select value={ch.severity} onValueChange={(v) => updateChallenge(ch.id, "severity", v)}>
                          <SelectTrigger className="h-7 text-[10px] border-0 bg-transparent">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {(["High", "Medium", "Low"] as const).map((s) => (
                              <SelectItem key={s} value={s}>
                                <Badge className={cn("text-[9px]", severityColors[s])}>{s}</Badge>
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </td>
                      <td className="py-1.5 px-2">
                        <Input
                          value={ch.rootCause}
                          onChange={(e) => updateChallenge(ch.id, "rootCause", e.target.value)}
                          className="h-7 text-[10px] border-0 bg-transparent px-1 focus-visible:ring-1"
                          placeholder="Root cause..."
                        />
                      </td>
                      <td className="py-1.5 px-2">
                        <Input
                          value={ch.actionRequired}
                          onChange={(e) => updateChallenge(ch.id, "actionRequired", e.target.value)}
                          className="h-7 text-[10px] border-0 bg-transparent px-1 focus-visible:ring-1"
                          placeholder="Action required..."
                        />
                      </td>
                      <td className="py-1.5 px-2">
                        <Input
                          value={ch.ownerDue}
                          onChange={(e) => updateChallenge(ch.id, "ownerDue", e.target.value)}
                          className="h-7 text-[10px] border-0 bg-transparent px-1 focus-visible:ring-1"
                          placeholder="Owner (date)"
                        />
                      </td>
                      <td className="py-1.5 px-1">
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-6 w-6"
                          onClick={() => removeChallenge(ch.id)}
                        >
                          <Trash2 className="w-3 h-3 text-muted-foreground hover:text-destructive" />
                        </Button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Legend */}
          <div className="flex items-center gap-5 pt-1 border-t border-border/30">
            {Object.entries(statusDot).map(([key, color]) => (
              <div key={key} className="flex items-center gap-1.5">
                <span className={cn("w-3 h-2.5 rounded-sm", color)} />
                <span className="text-[9px] text-muted-foreground font-medium">{statusLabel[key]}</span>
              </div>
            ))}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default StatusUpdateModal;
