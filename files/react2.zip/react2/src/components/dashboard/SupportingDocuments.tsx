import { FileText, FileSpreadsheet, FileArchive, Download, ExternalLink } from "lucide-react";

interface DocSection {
  heading: string;
  docs: { name: string; type: "pdf" | "xlsx" | "link"; updated?: string }[];
}

const sections: DocSection[] = [
  {
    heading: "Planning & Requirements",
    docs: [
      { name: "PRD", type: "pdf", updated: "2h ago" },
      { name: "ARD", type: "pdf", updated: "1d ago" },
      { name: "Build Plan", type: "xlsx", updated: "3h ago" },
      { name: "Program Schedule", type: "xlsx", updated: "5h ago" },
      { name: "Functional Plan", type: "pdf", updated: "12h ago" },
    ],
  },
  {
    heading: "Configuration & Design",
    docs: [
      { name: "Golden Configuration", type: "xlsx", updated: "4h ago" },
      { name: "GCD", type: "pdf", updated: "1d ago" },
      { name: "Ecosystem Matrix", type: "xlsx", updated: "6h ago" },
      { name: "Memory Matrix", type: "xlsx", updated: "2d ago" },
      { name: "Storage Matrix", type: "xlsx", updated: "1d ago" },
      { name: "Slot Priority Matrix", type: "xlsx", updated: "8h ago" },
      { name: "FM - Feature Matrix", type: "xlsx", updated: "3h ago" },
      { name: "ID Book", type: "pdf", updated: "2d ago" },
    ],
  },
  {
    heading: "Engineering & Quality",
    docs: [
      { name: "Engineering Restrictions", type: "pdf", updated: "5h ago" },
      { name: "CSTL", type: "link" },
      { name: "NUDDs", type: "xlsx", updated: "1d ago" },
      { name: "Jira Quality Issues", type: "link" },
      { name: "Agile PH (BOM)", type: "xlsx", updated: "4h ago" },
    ],
  },
];

const iconMap = {
  pdf: FileText,
  xlsx: FileSpreadsheet,
  link: ExternalLink,
};

const SupportingDocuments = () => {
  return (
    <div className="card-elevated flex flex-col h-full">
      <div className="px-5 py-4 border-b border-border-subtle">
        <h3 className="font-semibold text-sm text-foreground">Supporting Documents</h3>
      </div>
      <div className="p-4 space-y-4 flex-1 overflow-auto">
        {sections.map((section) => (
          <div key={section.heading}>
            <h4 className="text-[10px] uppercase tracking-wider text-muted-foreground font-semibold mb-2">
              {section.heading}
            </h4>
            <div className="space-y-1">
              {section.docs.map((doc) => {
                const Icon = iconMap[doc.type];
                return (
                  <div
                    key={doc.name}
                    className="flex items-center gap-2.5 px-2.5 py-2 rounded-md hover:bg-accent/50 transition-all group cursor-pointer"
                  >
                    <div className="w-6 h-6 rounded bg-accent flex items-center justify-center shrink-0 group-hover:bg-primary/10">
                      <Icon className="w-3.5 h-3.5 text-muted-foreground group-hover:text-primary" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-xs font-medium text-primary truncate leading-tight hover:underline">
                        {doc.name}
                      </p>
                      {doc.updated && (
                        <p className="text-[10px] text-muted-foreground">Updated {doc.updated}</p>
                      )}
                    </div>
                    {doc.type !== "link" && (
                      <Download className="w-3.5 h-3.5 text-muted-foreground/0 group-hover:text-muted-foreground transition-colors" />
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default SupportingDocuments;
