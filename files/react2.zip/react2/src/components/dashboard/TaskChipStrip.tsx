import { CheckCircle2, Link2, Zap } from "lucide-react";
import { cn } from "@/lib/utils";
import type { ScheduleTask, TaskStatus } from "@/data/scheduleData";
import { getTaskDueLabel, getTaskDependencyState } from "@/data/scheduleData";
import { getTaskParticipants, isAutoCompletedTask } from "@/data/taskParticipants";
import { getTaskTrack } from "@/data/phaseTracks";
import TrackBadge from "@/components/dashboard/TrackBadge";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";

// Canonical chip styling — fixed widths so columns line up across every row.
const BASE_CHIP =
  "h-5 px-1.5 text-[9px] font-semibold rounded border inline-flex items-center justify-center gap-0.5 shrink-0 tabular-nums";
const NEUTRAL_CHIP = "bg-muted text-muted-foreground border-border";
const AUTO_CHIP =
  "bg-[hsl(var(--mds-blue))]/10 text-[hsl(var(--mds-blue))] border-[hsl(var(--mds-blue))]/30";
const SUCCESS_CHIP =
  "bg-[hsl(var(--mds-success))]/10 text-[hsl(var(--mds-success))] border-[hsl(var(--mds-success))]/30";

const taskStatusLabels: Record<TaskStatus, string> = {
  completed: "Completed",
  "on-track": "On Track",
  "at-risk": "At Risk",
  pending: "Pending",
  late: "Late",
};

const taskStatusBadge: Record<TaskStatus, string> = {
  completed: SUCCESS_CHIP,
  "on-track": "bg-[hsl(var(--mds-success))]/10 text-[hsl(var(--mds-success))] border-[hsl(var(--mds-success))]/30",
  "at-risk": "bg-warning/10 text-warning border-warning/30",
  pending: NEUTRAL_CHIP,
  late: "bg-destructive/10 text-destructive border-destructive/30",
};

const getTaskFunction = (task: ScheduleTask): "GOE" | "NPI" | "SChM" | "Auto" => {
  if (isAutoCompletedTask(task)) return "Auto";
  if (getTaskTrack(task) === "SCHM") return "SChM";
  // GOE/NPI track: derive sub-function from name keywords so both labels appear.
  const n = task.name.toLowerCase();
  if (/(pilot|ramp|build|qual|launch|ready to ship|ready to order|production|pvt|dvt|evt)/.test(n)) {
    return "NPI";
  }
  return "GOE";
};

const getTaskSeverity = (id: string): "H" | "M" | "L" => {
  let h = 0;
  for (let i = 0; i < id.length; i++) h = (h * 31 + id.charCodeAt(i)) | 0;
  const m = Math.abs(h) % 10;
  return m < 3 ? "H" : m < 7 ? "M" : "L";
};

interface TaskChipStripProps {
  task: ScheduleTask;
  taskMap: Record<string, ScheduleTask>;
  className?: string;
}

const TaskChipStrip = ({ task, taskMap, className }: TaskChipStripProps) => {
  const depState = getTaskDependencyState(task, taskMap);
  const depTasks = (task.dependencies ?? []).map((id) => taskMap[id]).filter(Boolean);
  const fn = getTaskFunction(task);
  const isAuto = fn === "Auto";
  const dueLabel = getTaskDueLabel(task.id);
  const severity = getTaskSeverity(task.id);
  const severityLabel = severity === "H" ? "High" : severity === "M" ? "Medium" : "Low";
  const ownerName = isAuto ? "Auto" : getTaskParticipants(task).owner;
  const isCompleted = task.status === "completed";

  return (
    <div className={cn("flex items-center gap-1.5", className)}>
      {/* 1. Dependencies (always present, w-[68px]) */}
      {depState === "none" ? (
        <span
          className={cn(BASE_CHIP, NEUTRAL_CHIP, "w-[68px] opacity-50")}
          title="No dependencies"
          aria-label="No dependencies"
        >
          —
        </span>
      ) : (
        <TooltipProvider delayDuration={200}>
          <Tooltip>
            <TooltipTrigger asChild>
              <span className={cn(BASE_CHIP, NEUTRAL_CHIP, "w-[68px]")}>
                <Link2 className="w-2.5 h-2.5" />
                {depState === "ready" ? "Ready" : "Blocked"}
              </span>
            </TooltipTrigger>
            <TooltipContent side="top" className="text-xs max-w-[260px]">
              <p className="font-semibold mb-1">Depends on:</p>
              {depTasks.map((dep) => (
                <div key={dep.id} className="flex items-center gap-1.5 py-0.5">
                  <span
                    className={cn(
                      "w-1.5 h-1.5 rounded-full shrink-0",
                      dep.status === "completed" ? "bg-[hsl(var(--mds-success))]" : "bg-destructive"
                    )}
                  />
                  <span className={dep.status === "completed" ? "line-through opacity-60" : ""}>
                    {dep.name}
                  </span>
                </div>
              ))}
            </TooltipContent>
          </Tooltip>
        </TooltipProvider>
      )}

      {/* 2. Primary Owner (w-[110px]) */}
      {isAuto ? (
        <span
          className={cn(BASE_CHIP, NEUTRAL_CHIP, "w-[110px] opacity-50")}
          title="No primary owner (auto-completed)"
          aria-label="No primary owner (auto-completed)"
        >
          —
        </span>
      ) : (
        <span
          className={cn(BASE_CHIP, NEUTRAL_CHIP, "w-[110px]")}
          title={`Primary Owner: ${ownerName}`}
        >
          <span className="truncate">{ownerName}</span>
        </span>
      )}

      {/* 3. Function (w-[44px]) */}
      <span
        className={cn(BASE_CHIP, isAuto ? AUTO_CHIP : NEUTRAL_CHIP, "w-[44px]")}
        title={`Function: ${fn}`}
      >
        {fn}
      </span>

      {/* 3b. Track badge — which phase taxonomy this task lives on */}
      {!isAuto && <TrackBadge track={getTaskTrack(task)} />}

      {/* 4. Due Date (w-[56px]) */}
      <span
        className={cn(BASE_CHIP, NEUTRAL_CHIP, "w-[56px]")}
        title={`Due ${dueLabel === "T-7" ? "7" : "14"} days before milestone target`}
      >
        {dueLabel}
      </span>

      {/* 5. Severity Score (w-5) */}
      <span
        className={cn(BASE_CHIP, NEUTRAL_CHIP, "w-5 px-0")}
        title={`Severity: ${severityLabel}`}
      >
        {severity}
      </span>

      {/* 6. Completed / Status (w-[80px]) */}
      <span
        className={cn(BASE_CHIP, taskStatusBadge[task.status], "w-[80px]")}
        title={`Status: ${taskStatusLabels[task.status]}`}
      >
        {isCompleted && <CheckCircle2 className="w-2.5 h-2.5" />}
        {taskStatusLabels[task.status]}
      </span>
    </div>
  );
};

export default TaskChipStrip;
