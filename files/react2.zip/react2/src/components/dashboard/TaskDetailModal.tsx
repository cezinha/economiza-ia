import { Dialog, DialogContent, DialogTitle } from "@/components/ui/dialog";
import { ChevronRight, X } from "lucide-react";
import CurrentTaskDetail from "@/components/dashboard/CurrentTaskDetail";
import RelevantInfoPanel from "@/components/dashboard/RelevantInfoPanel";
import TaskDetailPanel, { type TaskComment } from "@/components/dashboard/TaskDetailPanel";
import type { ScheduleTask } from "@/data/scheduleData";

interface TaskDetailModalProps {
  open: boolean;
  task: ScheduleTask | null;
  phaseName: string;
  milestoneName: string;
  allTasks: ScheduleTask[];
  comments: TaskComment[];
  onClose: () => void;
  onMarkComplete: (taskId: string) => void;
  onAddComment: (taskId: string, comment: string) => void;
  onDeleteComment: (taskId: string, commentId: string) => void;
}

/**
 * Full-screen pop-up window combining the Current Task execution view,
 * Relevant Information, and Ownership / POR / Dependencies tracking.
 */
const TaskDetailModal = ({
  open,
  task,
  phaseName,
  milestoneName,
  allTasks,
  comments,
  onClose,
  onMarkComplete,
  onAddComment,
  onDeleteComment,
}: TaskDetailModalProps) => {
  if (!task) return null;

  return (
    <Dialog open={open} onOpenChange={(v) => { if (!v) onClose(); }}>
      <DialogContent className="max-w-[1240px] w-[96vw] h-[90vh] p-0 overflow-hidden gap-0 rounded-xl border-border/60 shadow-2xl">
        <DialogTitle className="sr-only">{task.name}</DialogTitle>

        {/* Unified shell */}
        <div className="flex flex-col h-full bg-gradient-to-b from-muted/30 to-background overflow-hidden">

          {/* Top breadcrumb / title strip */}
          <div className="shrink-0 px-6 py-3 border-b border-border/60 bg-card/90 backdrop-blur-sm flex items-center justify-between gap-4">
            <div className="flex items-center gap-2 text-[11px] text-muted-foreground min-w-0">
              <span className="font-semibold uppercase tracking-wider text-[hsl(var(--mds-blue))]">{phaseName}</span>
              <ChevronRight className="w-3 h-3 shrink-0" />
              <span className="font-medium uppercase tracking-wider truncate">{milestoneName}</span>
              <ChevronRight className="w-3 h-3 shrink-0" />
              <span className="font-semibold text-foreground truncate normal-case tracking-normal text-xs">{task.name}</span>
            </div>
            <button
              onClick={onClose}
              className="shrink-0 p-1.5 rounded-md hover:bg-muted transition-colors text-muted-foreground hover:text-foreground"
              aria-label="Close"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Three-column workspace */}
          <div className="grid grid-cols-12 flex-1 min-h-0 overflow-hidden">
            {/* Left: Current Task execution */}
            <div className="col-span-5 min-h-0 overflow-hidden border-r border-border/60 p-3">
              <CurrentTaskDetail
                task={task}
                phaseName={phaseName}
                milestoneName={milestoneName}
              />
            </div>

            {/* Center: Relevant Information */}
            <div className="col-span-3 min-h-0 overflow-hidden border-r border-border/60 p-3">
              <RelevantInfoPanel task={task} phaseName={phaseName} />
            </div>

            {/* Right: Ownership · POR · Dependencies · Comments */}
            <div className="col-span-4 min-h-0 overflow-hidden p-3">
              <div className="h-full flex flex-col border border-border/60 rounded-lg bg-card overflow-hidden shadow-sm">
                <div className="px-4 py-3 border-b border-border/60 bg-gradient-to-r from-[hsl(var(--mds-blue))]/5 to-transparent">
                  <span className="text-[10px] font-bold text-foreground uppercase tracking-[0.12em]">
                    Ownership & Tracking
                  </span>
                </div>
                <div className="flex-1 min-h-0 overflow-hidden">
                  <TaskDetailPanel
                    task={task}
                    allTasks={allTasks}
                    onClose={onClose}
                    onMarkComplete={onMarkComplete}
                    onAddComment={onAddComment}
                    onDeleteComment={onDeleteComment}
                    comments={comments}
                    embedded
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default TaskDetailModal;
