import { useState, useMemo } from "react";
import { X, CheckCircle2, Circle, Trash2, FileText, History, Info, Link2, UserCog, ArrowUpRight, ArrowDownRight, ChevronDown, AlertTriangle } from "lucide-react";
import DocumentInput from "@/components/dashboard/DocumentInput";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";
import type { ScheduleTask, TaskStatus, AssignmentHistoryEntry } from "@/data/scheduleData";
import { ownerDetails } from "@/data/scheduleData";
import { getTaskParticipants, getBackupOwnerName, getOwnerFunctionTag, isAutoCompletedTask, AUTO_COMPLETED_OWNER } from "@/data/taskParticipants";
import { evaluateTaskFlag } from "@/lib/statusFlagging";
import { useStatusFlags } from "@/contexts/StatusFlagContext";
import StatusChangeDialog from "@/components/dashboard/StatusChangeDialog";
import TaskReassignmentDialog, { type ReassignType } from "@/components/dashboard/TaskReassignmentDialog";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { useRole } from "@/contexts/RoleContext";

export interface TaskComment {
  id: string;
  author: string;
  text: string;
  timestamp: Date;
}

interface TaskDetailPanelProps {
  task: ScheduleTask;
  allTasks?: ScheduleTask[];
  onClose: () => void;
  onMarkComplete: (taskId: string) => void;
  onAddComment: (taskId: string, comment: string) => void;
  onDeleteComment: (taskId: string, commentId: string) => void;
  comments: TaskComment[];
  /** When true, render without outer card chrome (border, header, close button). */
  embedded?: boolean;
}

const statusLabel: Record<TaskStatus, string> = {
  completed: "Completed",
  "on-track": "On Track",
  "at-risk": "At Risk",
  pending: "Pending",
  late: "Late",
};

const statusColor: Record<TaskStatus, string> = {
  completed: "text-green-700 bg-green-100 border-green-200",
  "on-track": "text-blue-700 bg-blue-100 border-blue-200",
  "at-risk": "text-yellow-800 bg-yellow-100 border-yellow-200",
  pending: "text-gray-600 bg-gray-100 border-gray-200",
  late: "text-red-700 bg-red-100 border-red-200",
};

const formatTime = (date: Date) => {
  const now = new Date();
  const diff = now.getTime() - date.getTime();
  if (diff < 60000) return "Just now";
  if (diff < 3600000) return `${Math.floor(diff / 60000)}m ago`;
  if (diff < 86400000) return `${Math.floor(diff / 3600000)}h ago`;
  return date.toLocaleDateString();
};

const TaskDetailPanel = ({ task, allTasks = [], onClose, onMarkComplete, onAddComment, onDeleteComment, comments, embedded = false }: TaskDetailPanelProps) => {
  const [commentText, setCommentText] = useState("");
  const [showStatusDialog, setShowStatusDialog] = useState(false);
  const [showReassignDialog, setShowReassignDialog] = useState(false);
  const [historyOpen, setHistoryOpen] = useState(false);

  // Local assignment-history overlay (data is read-only; we keep an in-memory log).
  // Owners are now person names (dummy data) derived deterministically from the task.
  const participants = useMemo(() => getTaskParticipants(task), [task]);
  const [primaryOwner, setPrimaryOwner] = useState<string>(participants.owner);
  const initialBackup = getBackupOwnerName(task, participants.owner);
  const [backupOwner, setBackupOwner] = useState<string>(initialBackup);
  const [history, setHistory] = useState<AssignmentHistoryEntry[]>(task.assignmentHistory ?? []);

  const { confirmFlag, overrideFlag, clearOverride, dismissedIds, confirmedStatuses } = useStatusFlags();
  const { role } = useRole();
  const isReadOnly = role === "Executive";
  const confirmedStatus = confirmedStatuses.get(task.id);
  const effectiveStatus: TaskStatus = confirmedStatus ?? task.status;
  const flag = useMemo(
    () => (dismissedIds.has(task.id) ? null : evaluateTaskFlag({ ...task, status: effectiveStatus })),
    [task, dismissedIds, effectiveStatus]
  );

  const currentUser = sessionStorage.getItem("userRole") || "User";
  const primaryFnTag = getOwnerFunctionTag(primaryOwner);
  const backupFnTag = getOwnerFunctionTag(backupOwner);
  const ownerInfo = ownerDetails[primaryFnTag] ?? ownerDetails[task.owner];
  const backupInfo = ownerDetails[backupFnTag] ?? ownerDetails[task.owner];

  // Build dependency data
  const { dependsOn, blocks } = useMemo(() => {
    const taskMap: Record<string, ScheduleTask> = {};
    for (const t of allTasks) taskMap[t.id] = t;

    const dependsOn = (task.dependencies || []).map(id => taskMap[id]).filter(Boolean);
    const blocks = allTasks.filter(t => t.dependencies?.includes(task.id));
    return { dependsOn, blocks };
  }, [task, allTasks]);

  const handleSubmitComment = () => {
    if (!commentText.trim()) return;
    onAddComment(task.id, commentText.trim());
    setCommentText("");
  };

  const handleMarkComplete = () => {
    if (task.status !== "completed") {
      setShowStatusDialog(true);
    }
  };

  const handleStatusConfirm = (reason: string) => {
    onAddComment(task.id, `[Status Change → Completed] ${reason}`);
    onMarkComplete(task.id);
    setShowStatusDialog(false);
  };

  // Simulated POR tracking
  const porDate = task.porDate || null;
  const delayCount = task.delayCount || 0;

  return (
    <div className={cn(
      embedded
        ? "flex flex-col h-full bg-card overflow-hidden"
        : "w-[320px] shrink-0 border-l border-border bg-card flex flex-col h-full overflow-hidden"
    )}>
      {!embedded && (
        <div className="flex items-center justify-between px-4 py-3 border-b border-border bg-muted/30">
          <span className="text-xs font-semibold text-foreground">Task Details</span>
          <button onClick={onClose} className="p-1 rounded hover:bg-muted transition-colors">
            <X className="w-3.5 h-3.5 text-muted-foreground" />
          </button>
        </div>
      )}

      <div className="flex-1 overflow-auto px-4 py-4 space-y-4">
        <div>
          <span className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider">Task Name</span>
          <p className="text-sm font-bold text-foreground mt-1 leading-snug">{task.name}</p>
        </div>

        <div>
          <span className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider">Status</span>
          <div className="mt-1.5 flex items-center gap-2 flex-wrap">
            <span className={cn("text-[10px] px-2.5 py-1 rounded-full border font-semibold", statusColor[effectiveStatus])}>
              {statusLabel[effectiveStatus]}
            </span>
            {task.statusReason && (
              <Tooltip>
                <TooltipTrigger>
                  <Info className="w-3 h-3 text-muted-foreground" />
                </TooltipTrigger>
                <TooltipContent className="text-xs max-w-[200px]">
                  {task.statusReason}
                </TooltipContent>
              </Tooltip>
            )}
          </div>
          {confirmedStatus && (
            <div className="mt-1.5 flex items-center gap-2">
              <span className="text-[9px] italic text-muted-foreground">Auto-flagged · confirmed</span>
              <button
                onClick={() => {
                  onAddComment(task.id, `[Auto-flag undone] Reverted status to ${statusLabel[task.status]}`);
                  clearOverride(task.id);
                }}
                className="text-[9px] font-semibold text-primary hover:underline"
              >
                Undo
              </button>
            </div>
          )}
          {flag && (
            <div
              className={cn(
                "mt-2 flex items-start gap-2 rounded-lg border px-2.5 py-2 shadow-sm",
                flag.severity === "red"
                  ? "border-destructive/40 bg-destructive/5"
                  : "border-warning/40 bg-warning/5"
              )}
            >
              <AlertTriangle
                className={cn(
                  "w-3.5 h-3.5 shrink-0 mt-0.5",
                  flag.severity === "red" ? "text-destructive" : "text-warning"
                )}
              />
              <div className="flex-1 min-w-0">
                <p className="text-[10px] font-semibold text-foreground">
                  Suggested status change → {statusLabel[flag.suggested]}
                </p>
                <p className="text-[10px] text-muted-foreground leading-snug">{flag.reason}</p>
                {!isReadOnly && (
                  <div className="mt-1.5 flex gap-1.5">
                    <button
                      onClick={() => {
                        onAddComment(task.id, `[Auto-flag confirmed] Status → ${statusLabel[flag.suggested]}: ${flag.reason}`);
                        confirmFlag(task.id);
                      }}
                      className="text-[10px] font-semibold px-2 py-0.5 rounded bg-primary text-primary-foreground hover:bg-primary/90"
                    >
                      Confirm
                    </button>
                    <button
                      onClick={() => {
                        onAddComment(task.id, `[Auto-flag overridden] Kept status as ${statusLabel[task.status]} despite: ${flag.reason}`);
                        overrideFlag(task.id);
                      }}
                      className="text-[10px] font-semibold px-2 py-0.5 rounded border border-border hover:bg-muted/50"
                    >
                      Override
                    </button>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>

        {/* Owners block — primary + backup as paired cards */}
        <div className="rounded-lg border border-border/60 bg-gradient-to-b from-muted/20 to-transparent p-3 space-y-3">
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider">Primary Owner</span>
              {!isReadOnly && !isAutoCompletedTask(task) && (
                <button onClick={() => setShowReassignDialog(true)} className="flex items-center gap-1 text-[10px] text-primary hover:underline font-semibold">
                  <UserCog className="w-3 h-3" /> Reassign
                </button>
              )}
            </div>
            <div className="flex items-start gap-2.5">
              <div className="w-8 h-8 rounded-full bg-gradient-to-br from-[hsl(var(--mds-blue))] to-[hsl(var(--mds-blue-hover))] flex items-center justify-center shrink-0 shadow-sm">
                <span className="text-[11px] font-bold text-white">
                  {(isAutoCompletedTask(task) ? AUTO_COMPLETED_OWNER : primaryOwner).charAt(0)}
                </span>
              </div>
              <div className="min-w-0 flex-1">
                <p className="text-[12px] font-semibold text-foreground leading-tight">{isAutoCompletedTask(task) ? AUTO_COMPLETED_OWNER : primaryOwner}</p>
                {!isAutoCompletedTask(task) && ownerInfo && (
                  <div className="mt-0.5 text-[10px] text-muted-foreground space-y-0.5">
                    <p>{ownerInfo.name}</p>
                    <p className="truncate">{ownerInfo.email}</p>
                    <p className="text-[9px] italic">{ownerInfo.function}</p>
                  </div>
                )}
              </div>
            </div>
          </div>

          <div className="h-px bg-border/60" />

          <div>
            <span className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider">Backup Owner</span>
            <div className="mt-2 flex items-start gap-2.5">
              <div className="w-7 h-7 rounded-full bg-muted flex items-center justify-center shrink-0 border border-border/60">
                <span className="text-[10px] font-bold text-muted-foreground">
                  {(isAutoCompletedTask(task) ? AUTO_COMPLETED_OWNER : backupOwner).charAt(0)}
                </span>
              </div>
              <div className="min-w-0 flex-1">
                <p className="text-[12px] font-medium text-foreground leading-tight">{isAutoCompletedTask(task) ? AUTO_COMPLETED_OWNER : backupOwner}</p>
                {!isAutoCompletedTask(task) && backupInfo && (
                  <p className="text-[10px] text-muted-foreground mt-0.5">{backupInfo.name}</p>
                )}
              </div>
            </div>
          </div>

          <Collapsible open={historyOpen} onOpenChange={setHistoryOpen}>
            <CollapsibleTrigger className="flex items-center gap-1 text-[10px] text-primary hover:underline font-semibold">
              <ChevronDown className={cn("w-3 h-3 transition-transform", historyOpen && "rotate-180")} />
              Assignment History {history.length > 0 && `(${history.length})`}
            </CollapsibleTrigger>
            <CollapsibleContent className="mt-1.5 space-y-1.5">
              {history.length === 0 ? (
                <p className="text-[10px] text-muted-foreground italic">No reassignments yet.</p>
              ) : (
                history.map((h, i) => (
                  <div key={i} className="text-[10px] bg-card rounded-md px-2 py-1.5 border border-border/60">
                    <p className="font-semibold text-foreground">
                      {h.type === "primary" ? "Primary" : "Backup"} owner: {h.from} → {h.to}
                    </p>
                    <p className="text-muted-foreground mt-0.5">{h.reason}</p>
                    <p className="text-muted-foreground/70 mt-0.5 text-[9px]">
                      by {h.changedBy} · {new Date(h.timestamp).toLocaleDateString()}
                    </p>
                  </div>
                ))
              )}
            </CollapsibleContent>
          </Collapsible>
        </div>


        <div>
          <span className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider">Requirement Document</span>
          {task.requirementDoc ? (
            <div className="flex items-center gap-2 mt-1.5 p-2 rounded-md border border-primary/20 bg-primary/5 hover:bg-primary/10 transition-colors cursor-pointer">
              <FileText className="w-3.5 h-3.5 text-primary shrink-0" />
              <span className="text-[11px] text-primary underline truncate font-medium">{task.requirementDoc}</span>
            </div>
          ) : isReadOnly ? (
            <p className="text-xs text-muted-foreground mt-1">—</p>
          ) : (
            <DocumentInput label="" className="mt-1" />
          )}
        </div>

        <div>
          <span className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider">Data Sources</span>
          {task.dataSources && task.dataSources.length > 0 ? (
            <div className="flex flex-wrap gap-1.5 mt-1.5">
              {task.dataSources.map((source) => {
                const isLink = source.startsWith("http://") || source.startsWith("https://");
                return isLink ? (
                  <a
                    key={source}
                    href={source}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-[10px] px-2 py-1 rounded-md border border-primary/30 bg-primary/5 font-semibold text-primary hover:bg-primary/10 transition-colors"
                  >
                    {source}
                  </a>
                ) : (
                  <span key={source} className="text-[10px] px-2 py-1 rounded-md border border-border/60 bg-muted/40 font-semibold text-foreground">
                    {source}
                  </span>
                );
              })}
            </div>
          ) : (
            <p className="text-xs text-muted-foreground mt-1">—</p>
          )}
        </div>

        {/* Dependencies Section */}
        {(dependsOn.length > 0 || blocks.length > 0) && (
          <div className="p-3 rounded-lg border border-border/60 bg-gradient-to-br from-muted/30 to-transparent space-y-3 shadow-sm">
            <div className="flex items-center gap-1.5">
              <Link2 className="w-3.5 h-3.5 text-primary" />
              <span className="text-[10px] font-bold text-foreground uppercase tracking-wider">Dependencies</span>
            </div>

            {dependsOn.length > 0 && (
              <div>
                <div className="flex items-center gap-1 mb-1.5">
                  <ArrowUpRight className="w-3 h-3 text-muted-foreground" />
                  <span className="text-[9px] font-bold text-muted-foreground uppercase tracking-wider">Depends On</span>
                </div>
                <div className="space-y-1">
                  {dependsOn.map(dep => (
                    <div key={dep.id} className="flex items-center gap-2 py-1.5 px-2 rounded-md bg-card border border-border/40">
                      <span className={cn(
                        "w-2 h-2 rounded-full shrink-0",
                        dep.status === "completed" ? "bg-[hsl(var(--mds-success))]" : "bg-destructive"
                      )} />
                      <span className={cn(
                        "text-[11px] flex-1 truncate",
                        dep.status === "completed" ? "text-muted-foreground line-through" : "text-foreground"
                      )}>
                        {dep.name}
                      </span>
                      <span className={cn(
                        "text-[9px] font-bold px-1.5 py-0.5 rounded-full shrink-0",
                        dep.status === "completed"
                          ? "bg-[hsl(var(--mds-success))]/10 text-[hsl(var(--mds-success))]"
                          : "bg-destructive/10 text-destructive"
                      )}>
                        {dep.status === "completed" ? "Done" : "Pending"}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {blocks.length > 0 && (
              <div>
                <div className="flex items-center gap-1 mb-1.5">
                  <ArrowDownRight className="w-3 h-3 text-muted-foreground" />
                  <span className="text-[9px] font-bold text-muted-foreground uppercase tracking-wider">Blocks</span>
                </div>
                <div className="space-y-1">
                  {blocks.map(dep => (
                    <div key={dep.id} className="flex items-center gap-2 py-1.5 px-2 rounded-md bg-card border border-border/40">
                      <span className={cn(
                        "w-2 h-2 rounded-full shrink-0",
                        dep.status === "completed" ? "bg-[hsl(var(--mds-success))]" : "bg-[hsl(var(--mds-warning))]"
                      )} />
                      <span className="text-[11px] flex-1 text-foreground truncate">{dep.name}</span>
                      <span className={cn(
                        "text-[9px] font-bold px-1.5 py-0.5 rounded-full shrink-0",
                        dep.status === "completed"
                          ? "bg-[hsl(var(--mds-success))]/10 text-[hsl(var(--mds-success))]"
                          : "bg-[hsl(var(--mds-warning))]/10 text-[hsl(var(--mds-warning))]"
                      )}>
                        {dep.status === "completed" ? "Done" : "Waiting"}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

        {!isReadOnly && (
          <div>
            <Button
              size="sm"
              variant={task.status === "completed" ? "outline" : "default"}
              className="w-full text-xs h-9 gap-2 shadow-sm"
              onClick={handleMarkComplete}
              disabled={task.status === "completed"}
            >
              {task.status === "completed" ? (
                <><CheckCircle2 className="w-3.5 h-3.5" /> Already Completed</>
              ) : (
                <><Circle className="w-3.5 h-3.5" /> Mark as Complete</>
              )}
            </Button>
          </div>
        )}

        <div className="space-y-2">
          <span className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider">
            Comments {comments.length > 0 && `(${comments.length})`}
          </span>

          {comments.length > 0 && (
            <div className="space-y-2 max-h-48 overflow-auto pr-1">
              {comments.map((c) => (
                <div key={c.id} className="bg-muted/40 rounded-lg p-2.5 border border-border/50 group">
                  <div className="flex items-center justify-between mb-1">
                    <div className="flex items-center gap-1.5">
                      <div className="w-5 h-5 rounded-full bg-gradient-to-br from-primary/30 to-primary/10 flex items-center justify-center">
                        <span className="text-[9px] font-bold text-primary">{c.author.charAt(0).toUpperCase()}</span>
                      </div>
                      <span className="text-[10px] font-semibold text-foreground">{c.author}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <span className="text-[9px] text-muted-foreground">{formatTime(c.timestamp)}</span>
                      {!isReadOnly && (
                        <button
                          onClick={() => onDeleteComment(task.id, c.id)}
                          className="p-0.5 rounded opacity-0 group-hover:opacity-100 hover:bg-destructive/10 transition-all"
                          title="Delete comment"
                        >
                          <Trash2 className="w-3 h-3 text-destructive" />
                        </button>
                      )}
                    </div>
                  </div>
                  <p className={cn("text-[11px] text-foreground leading-relaxed", c.text.startsWith("[Status Change") && "text-primary font-medium")}>{c.text}</p>
                </div>
              ))}
            </div>
          )}

          {!isReadOnly && (
            <>
              <Textarea
                value={commentText}
                onChange={(e) => setCommentText(e.target.value)}
                placeholder="Add a comment or status update..."
                className="text-xs min-h-[72px] resize-none"
              />
              <Button
                size="sm"
                variant="outline"
                className="w-full text-xs"
                onClick={handleSubmitComment}
                disabled={!commentText.trim()}
              >
                Add Comment
              </Button>
            </>
          )}
        </div>

        {/* POR vs Actuals Tracking */}
        <div className="p-3 rounded-lg border border-border/60 bg-gradient-to-br from-primary/5 to-transparent space-y-2.5 shadow-sm">
          <div className="flex items-center gap-1.5">
            <History className="w-3.5 h-3.5 text-primary" />
            <span className="text-[10px] font-bold text-foreground uppercase tracking-wider">POR vs Actuals</span>
          </div>
          <div className="grid grid-cols-2 gap-2">
            <div className="rounded-md bg-card border border-border/60 px-2.5 py-2">
              <span className="text-[9px] text-muted-foreground uppercase tracking-wider font-semibold">POR Date</span>
              <p className="text-[11px] font-bold text-foreground mt-0.5">{porDate || "Not set"}</p>
            </div>
            <div className="rounded-md bg-card border border-border/60 px-2.5 py-2">
              <span className="text-[9px] text-muted-foreground uppercase tracking-wider font-semibold">Actual</span>
              <p className="text-[11px] font-bold text-foreground mt-0.5">{task.actualDate || (task.status === "completed" ? "Today" : "—")}</p>
            </div>
            <div className="rounded-md bg-card border border-border/60 px-2.5 py-2">
              <span className="text-[9px] text-muted-foreground uppercase tracking-wider font-semibold">Times Delayed</span>
              <p className={cn("text-[14px] font-bold mt-0.5 tabular-nums", delayCount > 0 ? "text-destructive" : "text-foreground")}>{delayCount}</p>
            </div>
            <div className="rounded-md bg-card border border-border/60 px-2.5 py-2">
              <span className="text-[9px] text-muted-foreground uppercase tracking-wider font-semibold">Status</span>
              <p className={cn("text-[11px] font-bold mt-0.5", task.status === "late" ? "text-destructive" : "text-[hsl(var(--mds-success))]")}>
                {task.status === "late" ? "At Risk" : task.status === "completed" ? "On Time" : "Tracking"}
              </p>
            </div>
          </div>
        </div>
      </div>

      <StatusChangeDialog
        open={showStatusDialog}
        onOpenChange={setShowStatusDialog}
        taskName={task.name}
        newStatus="completed"
        onConfirm={handleStatusConfirm}
      />

      <TaskReassignmentDialog
        open={showReassignDialog}
        onOpenChange={setShowReassignDialog}
        currentOwner={primaryOwner}
        currentBackup={backupOwner}
        taskName={task.name}
        onConfirm={(newOwner, reason, type: ReassignType) => {
          const from = type === "primary" ? primaryOwner : backupOwner;
          const entry: AssignmentHistoryEntry = {
            from,
            to: newOwner,
            reason,
            changedBy: currentUser,
            timestamp: new Date().toISOString(),
            type,
          };
          setHistory((prev) => [entry, ...prev]);
          if (type === "primary") setPrimaryOwner(newOwner);
          else setBackupOwner(newOwner);
          onAddComment(
            task.id,
            `[Reassignment · ${type === "primary" ? "Primary" : "Backup"}] ${from} → ${newOwner}: ${reason}`
          );
          setShowReassignDialog(false);
          setHistoryOpen(true);
        }}
      />
    </div>
  );
};

export default TaskDetailPanel;
