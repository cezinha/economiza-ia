import { useEffect, useMemo } from "react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { usePlatform } from "@/contexts/PlatformContext";
import { useUniversalFilters, PLATFORM_LOB, LOBS, PHASES, TASK_CATEGORIES } from "@/contexts/UniversalFilterContext";
import { useRole } from "@/contexts/RoleContext";
import { Filter, RotateCcw } from "lucide-react";
import { cn } from "@/lib/utils";
import MultiSelectPopover from "@/components/dashboard/MultiSelectPopover";
import { FUNCTIONS, type FunctionFilterValue } from "@/components/dashboard/FunctionFilter";
import { getAllOwnerNames } from "@/data/taskParticipants";

export interface TaskPageFilterState {
  phases: string[];        // multi
  tasks: string[];         // multi (TASK_CATEGORIES)
  functions: FunctionFilterValue[];
  primaryOwners: string[]; // multi
}

interface TaskPageFiltersProps {
  value: TaskPageFilterState;
  onChange: (next: TaskPageFilterState) => void;
}

/**
 * Filter bar for task-centric pages (Schedule, My Tasks).
 * - LOB + Platform stay single-select and share the global UniversalFilterContext.
 * - Phase, Task, Function, Primary Owner are multi-select and local to the page.
 */
const TaskPageFilters = ({ value, onChange }: TaskPageFiltersProps) => {
  const { programs } = usePlatform();
  const { filters, updateFilter } = useUniversalFilters();
  const { role, assignedPlatform } = useRole();

  const userLocked = role === "User" && !!assignedPlatform;
  const lockedLob = userLocked && assignedPlatform ? PLATFORM_LOB[assignedPlatform] : null;

  useEffect(() => {
    if (!userLocked || !assignedPlatform) return;
    if (lockedLob && filters.lob !== lockedLob) updateFilter("lob", lockedLob);
    if (filters.platform !== assignedPlatform) updateFilter("platform", assignedPlatform);
  }, [userLocked, lockedLob, assignedPlatform, filters.lob, filters.platform, updateFilter]);

  const lobSelected = filters.lob !== "all";

  const availablePlatforms = useMemo(() => {
    if (!lobSelected) return [];
    return programs.filter((p) => PLATFORM_LOB[p] === filters.lob);
  }, [filters.lob, lobSelected, programs]);

  const ownerOptions = useMemo(() => getAllOwnerNames(), []);

  return (
    <div className="flex items-center gap-2 flex-wrap">
      <Filter className="w-3.5 h-3.5 text-muted-foreground shrink-0" />

      <Select value={filters.lob} onValueChange={(v) => updateFilter("lob", v)} disabled={userLocked}>
        <SelectTrigger
          className={cn("w-[120px] h-7 text-[11px]", userLocked && "opacity-60 cursor-not-allowed")}
          title={userLocked ? "Auto-assigned for your profile" : undefined}
        >
          <SelectValue />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value="all">All LOBs</SelectItem>
          {LOBS.map((l) => (
            <SelectItem key={l} value={l}>{l}</SelectItem>
          ))}
        </SelectContent>
      </Select>

      <Select
        value={lobSelected ? filters.platform : "all"}
        onValueChange={(v) => updateFilter("platform", v)}
        disabled={!lobSelected || userLocked}
      >
        <SelectTrigger
          className={cn("w-[140px] h-7 text-[11px]", (!lobSelected || userLocked) && "opacity-60 cursor-not-allowed")}
          title={userLocked ? "Auto-assigned for your profile" : undefined}
        >
          <SelectValue placeholder="Platform" />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value="all">All Platforms</SelectItem>
          {availablePlatforms.map((p) => (
            <SelectItem key={p} value={p}>{p}</SelectItem>
          ))}
        </SelectContent>
      </Select>

      <MultiSelectPopover
        label="Phase"
        options={[...PHASES]}
        selected={value.phases}
        onChange={(phases) => onChange({ ...value, phases })}
        width="w-[160px]"
        emptyLabel="All Phases"
      />

      <MultiSelectPopover
        label="Function"
        options={FUNCTIONS.filter((f) => f !== "All") as unknown as string[]}
        selected={value.functions.filter((f) => f !== "All")}
        onChange={(fns) =>
          onChange({
            ...value,
            functions: fns.length === 0 ? ["All"] : (fns as FunctionFilterValue[]),
          })
        }
        width="w-[150px]"
        emptyLabel="All Functions"
      />

      <MultiSelectPopover
        label="Primary Owner"
        options={ownerOptions}
        selected={value.primaryOwners}
        onChange={(primaryOwners) => onChange({ ...value, primaryOwners })}
        searchable
        width="w-[170px]"
        emptyLabel="All Owners"
      />

      <MultiSelectPopover
        label="Task"
        options={[...TASK_CATEGORIES]}
        selected={value.tasks}
        onChange={(tasks) => onChange({ ...value, tasks })}
        width="w-[160px]"
        emptyLabel="All Tasks"
      />

      <button
        type="button"
        onClick={() => {
          onChange(defaultTaskPageFilters);
          updateFilter("lob", "all");
          updateFilter("platform", "all");
        }}
        disabled={
          filters.lob === "all" &&
          filters.platform === "all" &&
          value.phases.length === 0 &&
          value.tasks.length === 0 &&
          value.primaryOwners.length === 0 &&
          (value.functions.length === 0 || (value.functions.length === 1 && value.functions[0] === "All"))
        }
        className="ml-1 h-7 px-2 text-[11px] rounded-md text-muted-foreground hover:text-foreground hover:bg-muted flex items-center gap-1 shrink-0 disabled:opacity-40 disabled:cursor-not-allowed disabled:hover:bg-transparent disabled:hover:text-muted-foreground"
        title="Reset all filters"
      >
        <RotateCcw className="w-3 h-3" />
        Reset
      </button>
    </div>
  );
};

export const defaultTaskPageFilters: TaskPageFilterState = {
  phases: [],
  tasks: [],
  functions: ["All"],
  primaryOwners: [],
};

export default TaskPageFilters;
