import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { UserCog } from "lucide-react";
import { getAllOwnerNames, getOwnerFunctionTag } from "@/data/taskParticipants";

export type ReassignType = "primary" | "backup";

interface TaskReassignmentDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  currentOwner: string;
  currentBackup?: string;
  taskName: string;
  onConfirm: (newOwner: string, reason: string, type: ReassignType) => void;
}

const availableOwners = getAllOwnerNames();

const TaskReassignmentDialog = ({ open, onOpenChange, currentOwner, currentBackup, taskName, onConfirm }: TaskReassignmentDialogProps) => {
  const [type, setType] = useState<ReassignType>("primary");
  const [newOwner, setNewOwner] = useState("");
  const [reason, setReason] = useState("");

  const currentSlotValue = type === "primary" ? currentOwner : currentBackup ?? "—";

  const handleConfirm = () => {
    if (!newOwner || !reason.trim()) return;
    onConfirm(newOwner, reason.trim(), type);
    setNewOwner("");
    setReason("");
    setType("primary");
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-sm">
        <DialogHeader>
          <DialogTitle className="text-sm flex items-center gap-2">
            <UserCog className="w-4 h-4 text-primary" />
            Reassign Task
          </DialogTitle>
        </DialogHeader>
        <div className="space-y-4 text-xs">
          <div>
            <p className="text-[10px] text-muted-foreground uppercase font-semibold mb-1">Task</p>
            <p className="text-sm font-medium text-foreground">{taskName}</p>
          </div>

          <div className="space-y-1.5">
            <Label className="text-xs">Reassignment Slot</Label>
            <RadioGroup
              value={type}
              onValueChange={(v) => { setType(v as ReassignType); setNewOwner(""); }}
              className="flex gap-4"
            >
              <div className="flex items-center gap-1.5">
                <RadioGroupItem value="primary" id="r-primary" />
                <Label htmlFor="r-primary" className="text-xs cursor-pointer">Primary Owner</Label>
              </div>
              <div className="flex items-center gap-1.5">
                <RadioGroupItem value="backup" id="r-backup" />
                <Label htmlFor="r-backup" className="text-xs cursor-pointer">Backup Owner</Label>
              </div>
            </RadioGroup>
          </div>

          <div>
            <p className="text-[10px] text-muted-foreground uppercase font-semibold mb-1">
              Current {type === "primary" ? "Primary" : "Backup"}
            </p>
            <p className="font-medium">{currentSlotValue}</p>
          </div>

          <div className="space-y-1.5">
            <Label className="text-xs">New {type === "primary" ? "Primary" : "Backup"} Owner</Label>
            <Select value={newOwner} onValueChange={setNewOwner}>
              <SelectTrigger className="h-9 text-xs"><SelectValue placeholder={`Select new ${type} owner`} /></SelectTrigger>
              <SelectContent>
                {availableOwners.filter(o => o !== currentSlotValue).map(o => (
                  <SelectItem key={o} value={o}>
                    <span>{o}</span>
                    <span className="text-muted-foreground ml-2">— {getOwnerFunctionTag(o)}</span>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-1.5">
            <Label className="text-xs">Reason for Reassignment *</Label>
            <Textarea
              value={reason}
              onChange={e => setReason(e.target.value)}
              placeholder="Explain why this task is being reassigned..."
              className="text-xs min-h-[72px] resize-none"
            />
          </div>
        </div>
        <DialogFooter className="gap-2">
          <Button variant="outline" size="sm" className="text-xs" onClick={() => onOpenChange(false)}>Cancel</Button>
          <Button size="sm" className="text-xs" onClick={handleConfirm} disabled={!newOwner || !reason.trim()}>Confirm Reassignment</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default TaskReassignmentDialog;
