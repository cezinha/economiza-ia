import { CheckCircle2, AlertTriangle, Clock, ChevronDown } from "lucide-react";
import { programSchedules, type TaskStatus as ScheduleTaskStatus } from "@/data/scheduleData";

type TaskStatus = "complete" | "on-track" | "at-risk" | "delayed";
type TaskType = "stage" | "task";

interface TaskItem {
  type: TaskType;
  description: string;
  ecd: string;
  status: TaskStatus;
  progress?: number;
}

const mapStatus = (s: ScheduleTaskStatus): TaskStatus => {
  switch (s) {
    case "completed": return "complete";
    case "on-track": return "on-track";
    case "pending": return "on-track";
    case "late": return "delayed";
  }
};

const computeProgress = (s: ScheduleTaskStatus): number => {
  switch (s) {
    case "completed": return 100;
    case "on-track": return 66;
    case "pending": return 20;
    case "late": return 50;
  }
};

// Derive tasks from the first program's schedule for the Phase Gate view
const deriveTasksFromSchedule = (): TaskItem[] => {
  const firstProgram = Object.values(programSchedules)[0];
  if (!firstProgram) return [];

  const items: TaskItem[] = [];
  // Show tasks from the current active phases (first 2-3 phases)
  const activePhases = firstProgram.filter(p => p.status !== "not-started").slice(0, 2);
  
  for (const phase of activePhases) {
    for (const milestone of phase.milestones) {
      // Add milestone as a "stage" entry
      const milestoneProgress = Math.round(
        milestone.tasks.reduce((sum, t) => sum + computeProgress(t.status), 0) / milestone.tasks.length
      );
      const milestoneStatus = milestone.tasks.every(t => t.status === "completed")
        ? "complete" as TaskStatus
        : milestone.tasks.some(t => t.status === "late")
          ? "at-risk" as TaskStatus
          : "on-track" as TaskStatus;

      items.push({
        type: "stage",
        description: milestone.name,
        ecd: "4/24/26",
        status: milestoneStatus,
        progress: milestoneProgress,
      });

      // Add individual tasks under the milestone
      for (const task of milestone.tasks.slice(0, 2)) {
        items.push({
          type: "task",
          description: task.name,
          ecd: "4/24/26",
          status: mapStatus(task.status),
        });
      }
    }
  }

  return items.slice(0, 10); // Limit for display
};

const tasks = deriveTasksFromSchedule();

const statusConfig: Record<TaskStatus, { label: string; className: string; icon: typeof CheckCircle2 }> = {
  complete: { label: "Done", className: "bg-success/10 text-success", icon: CheckCircle2 },
  "on-track": { label: "On Track", className: "bg-success/10 text-success", icon: Clock },
  "at-risk": { label: "At Risk w/ Mitigation", className: "bg-destructive/10 text-destructive", icon: AlertTriangle },
  delayed: { label: "At Risk w/ No Plan", className: "bg-warning/10 text-warning", icon: AlertTriangle },
};

const TaskSchedule = () => {
  return (
    <div className="card-elevated flex flex-col h-full">
      <div className="px-5 py-4 border-b border-border-subtle flex justify-between items-center">
        <h3 className="font-semibold text-sm text-foreground">Schedule</h3>
        <button className="text-xs font-medium text-primary hover:underline flex items-center gap-1">
          View Gantt <ChevronDown className="w-3 h-3" />
        </button>
      </div>
      <div className="overflow-auto flex-1">
        <table className="w-full text-left text-sm">
          <thead>
            <tr className="bg-accent/50 text-muted-foreground uppercase text-[10px] tracking-wider font-semibold">
              <th className="px-5 py-2.5 w-12">Desc.</th>
              <th className="px-5 py-2.5">ECD</th>
              <th className="px-5 py-2.5">Status</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-border-subtle">
            {tasks.map((task, i) => {
              const config = statusConfig[task.status];
              const Icon = config.icon;
              return (
                <tr key={i} className="hover:bg-accent/30 transition-colors">
                  <td className="px-5 py-2.5">
                    <div className="flex items-center gap-2">
                      {task.type === "stage" ? (
                        <span className="w-5 h-4 bg-primary/10 text-primary text-[9px] font-bold flex items-center justify-center rounded">S</span>
                      ) : (
                        <span className="w-5 h-4 bg-muted text-muted-foreground text-[9px] font-bold flex items-center justify-center rounded">T</span>
                      )}
                      <span className="text-sm font-medium text-foreground truncate max-w-[180px]">{task.description}</span>
                    </div>
                  </td>
                  <td className="px-5 py-2.5 tabular-nums text-muted-foreground text-xs">{task.ecd}</td>
                  <td className="px-5 py-2.5">
                    <div className="flex items-center gap-2">
                      {task.progress !== undefined ? (
                        <div className="flex items-center gap-2">
                          <div className="w-12 h-1.5 bg-secondary rounded-full overflow-hidden">
                            <div
                              className={`h-full rounded-full ${task.status === "at-risk" ? "bg-destructive" : "bg-primary"}`}
                              style={{ width: `${task.progress}%` }}
                            />
                          </div>
                          <span className="text-[11px] tabular-nums text-muted-foreground">{task.progress}%</span>
                        </div>
                      ) : (
                        <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-medium ${config.className}`}>
                          <Icon className="w-3 h-3" />
                        </span>
                      )}
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default TaskSchedule;
