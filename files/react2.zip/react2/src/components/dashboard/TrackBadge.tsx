import { cn } from "@/lib/utils";
import { TRACK_LABEL, TRACK_TONE, type Track } from "@/data/phaseTracks";

interface TrackBadgeProps {
  track: Track;
  className?: string;
  /** Compact ~16px height pill for inline rows. */
  size?: "xs" | "sm";
}

/**
 * Small pill identifying which phase track (GOE/NPI or SChM) a row belongs to.
 * Uses MDS Blue for GOE/NPI and MDS Navy for SChM so they remain visually
 * distinct from R/Y/G status chips.
 */
const TrackBadge = ({ track, className, size = "xs" }: TrackBadgeProps) => {
  const tone = TRACK_TONE[track];
  return (
    <span
      className={cn(
        "inline-flex items-center font-semibold rounded border tabular-nums shrink-0",
        size === "xs" ? "h-4 px-1 text-[8px]" : "h-5 px-1.5 text-[9px]",
        tone.bg,
        tone.text,
        tone.border,
        className,
      )}
      title={`${TRACK_LABEL[track]} track`}
    >
      {TRACK_LABEL[track]}
    </span>
  );
};

export default TrackBadge;
