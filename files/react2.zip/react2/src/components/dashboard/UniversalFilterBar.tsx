import { useEffect, useMemo } from "react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { usePlatform } from "@/contexts/PlatformContext";
import { useUniversalFilters, PLATFORM_LOB, PLATFORM_ORG, LOBS, ORGANIZATIONS, PHASES, TASK_CATEGORIES } from "@/contexts/UniversalFilterContext";
import { useRole } from "@/contexts/RoleContext";
import { Filter, Lock } from "lucide-react";
import { cn } from "@/lib/utils";

// Re-export for backward compat
export type { UniversalFilters } from "@/contexts/UniversalFilterContext";
export { defaultFilters } from "@/contexts/UniversalFilterContext";

interface UniversalFilterBarProps {
  /** Hide specific filter dropdowns if they don't apply to the page */
  hidePlatform?: boolean;
  hidePhase?: boolean;
  hideTask?: boolean;
  hideLob?: boolean;
  hideOrg?: boolean;
}

const UniversalFilterBar = ({
  hidePlatform,
  hidePhase,
  hideTask,
  hideLob,
  hideOrg,
}: UniversalFilterBarProps) => {
  const { programs } = usePlatform();
  const { filters, updateFilter } = useUniversalFilters();
  const { role, assignedPlatforms } = useRole();

  // Lock Org/LOB/Platform when role is User or Admin (scoped roles).
  const scopeLocked = (role === "User" || role === "Admin") && assignedPlatforms.length > 0;
  const lockedOrg = scopeLocked ? PLATFORM_ORG[assignedPlatforms[0]] ?? null : null;
  const lockedLob = scopeLocked ? PLATFORM_LOB[assignedPlatforms[0]] ?? null : null;
  // Single platform → lock to it. Multiple → lock to "all" (within their assigned set, shown elsewhere).
  const lockedPlatform = scopeLocked && assignedPlatforms.length === 1 ? assignedPlatforms[0] : null;

  useEffect(() => {
    if (!scopeLocked) return;
    if (lockedOrg && filters.organization !== lockedOrg) updateFilter("organization", lockedOrg);
    if (lockedLob && filters.lob !== lockedLob) updateFilter("lob", lockedLob);
    if (lockedPlatform && filters.platform !== lockedPlatform) updateFilter("platform", lockedPlatform);
  }, [scopeLocked, lockedOrg, lockedLob, lockedPlatform, filters.organization, filters.lob, filters.platform, updateFilter]);

  const orgSelected = filters.organization !== "all";
  const lobSelected = filters.lob !== "all";
  const platformSelected = filters.platform !== "all";
  const phaseSelected = filters.phase !== "all";

  const availablePlatforms = useMemo(() => {
    if (!lobSelected) return [];
    let list = programs.filter((p) => PLATFORM_LOB[p] === filters.lob);
    if (orgSelected) list = list.filter((p) => PLATFORM_ORG[p] === filters.organization);
    if (scopeLocked) list = list.filter((p) => assignedPlatforms.includes(p));
    return list;
  }, [filters.lob, filters.organization, lobSelected, orgSelected, programs, scopeLocked, assignedPlatforms]);

  const lockTitle = "Locked to your assigned scope";

  return (
    <div className="flex items-center gap-2 flex-wrap">
      <Filter className="w-3.5 h-3.5 text-muted-foreground shrink-0" />

      {!hideOrg && (
        <Select value={filters.organization} onValueChange={(v) => updateFilter("organization", v)} disabled={scopeLocked}>
          <SelectTrigger className={cn("w-[120px] h-7 text-[11px]", scopeLocked && "opacity-70 cursor-not-allowed")} title={scopeLocked ? lockTitle : undefined}>
            {scopeLocked && <Lock className="w-2.5 h-2.5 mr-1 text-muted-foreground" />}
            <SelectValue placeholder="Organization" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Orgs</SelectItem>
            {ORGANIZATIONS.map((o) => (
              <SelectItem key={o} value={o}>{o}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      )}

      {!hideLob && (
        <Select value={filters.lob} onValueChange={(v) => updateFilter("lob", v)} disabled={scopeLocked}>
          <SelectTrigger className={cn("w-[120px] h-7 text-[11px]", scopeLocked && "opacity-70 cursor-not-allowed")} title={scopeLocked ? lockTitle : undefined}>
            {scopeLocked && <Lock className="w-2.5 h-2.5 mr-1 text-muted-foreground" />}
            <SelectValue placeholder="LOB" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All LOBs</SelectItem>
            {LOBS.map((l) => (
              <SelectItem key={l} value={l}>{l}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      )}

      {!hidePlatform && (
        <Select
          value={lobSelected ? filters.platform : "all"}
          onValueChange={(v) => updateFilter("platform", v)}
          disabled={!lobSelected || (scopeLocked && assignedPlatforms.length === 1)}
        >
          <SelectTrigger
            className={cn(
              "w-[140px] h-7 text-[11px]",
              (!lobSelected || (scopeLocked && assignedPlatforms.length === 1)) && "opacity-70 cursor-not-allowed",
            )}
            title={scopeLocked ? lockTitle : undefined}
          >
            {scopeLocked && assignedPlatforms.length === 1 && <Lock className="w-2.5 h-2.5 mr-1 text-muted-foreground" />}
            <SelectValue placeholder="Platform" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Platforms</SelectItem>
            {availablePlatforms.map((p) => (
              <SelectItem key={p} value={p}>{p}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      )}

      {!hidePhase && (
        <Select
          value={platformSelected ? filters.phase : "all"}
          onValueChange={(v) => updateFilter("phase", v)}
          disabled={!platformSelected}
        >
          <SelectTrigger className={cn("w-[160px] h-7 text-[11px]", !platformSelected && "opacity-40 cursor-not-allowed")}>
            <SelectValue placeholder="Phase" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Phases</SelectItem>
            {PHASES.map((p) => (
              <SelectItem key={p} value={p}>{p}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      )}

      {!hideTask && (
        <Select
          value={phaseSelected ? filters.task : "all"}
          onValueChange={(v) => updateFilter("task", v)}
          disabled={!phaseSelected}
        >
          <SelectTrigger className={cn("w-[160px] h-7 text-[11px]", !phaseSelected && "opacity-40 cursor-not-allowed")}>
            <SelectValue placeholder="Task" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Tasks</SelectItem>
            {TASK_CATEGORIES.map((t) => (
              <SelectItem key={t} value={t}>{t}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      )}
    </div>
  );
};

export default UniversalFilterBar;
