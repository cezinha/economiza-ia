import { Star, AlertTriangle, ChevronRight, Eye } from "lucide-react";
import { cn } from "@/lib/utils";
import { motion } from "framer-motion";
import { useWatchlist } from "@/contexts/WatchlistContext";

const statusBarColors: Record<string, string> = {
  "on-track": "bg-success",
  "at-risk": "bg-warning",
  "delayed": "bg-destructive",
};

const statusLabels: Record<string, string> = {
  "on-track": "On Track",
  "at-risk": "At Risk w/ Mitigation",
  "delayed": "At Risk w/ No Plan",
};

const statusBadge: Record<string, string> = {
  "on-track": "bg-success/10 text-success border-success/20",
  "at-risk": "bg-warning/10 text-warning border-warning/20",
  "delayed": "bg-destructive/10 text-destructive border-destructive/20",
};

const WatchlistPanel = () => {
  const { watchlistItems, toggleWatchlist } = useWatchlist();

  return (
    <div className="card-elevated rounded-2xl overflow-hidden h-full flex flex-col">
      <div className="px-5 py-4 border-b border-border/30">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-warning/10 flex items-center justify-center">
            <Star className="w-4 h-4 text-warning fill-warning" />
          </div>
          <div>
            <h3 className="text-[13px] font-bold text-foreground">My Platforms</h3>
            <p className="text-[10px] text-muted-foreground">{watchlistItems.length} platforms starred</p>
          </div>
        </div>
      </div>

      <div className="p-3 flex-1">
        {watchlistItems.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-10 text-center">
            <div className="w-12 h-12 rounded-xl bg-muted/20 flex items-center justify-center mb-3">
              <Eye className="w-5 h-5 text-muted-foreground/25" />
            </div>
            <p className="text-[11px] font-semibold text-muted-foreground">No programs starred</p>
            <p className="text-[10px] text-muted-foreground/40 mt-1">Star a program to track it here</p>
          </div>
        ) : (
          <div className="space-y-2">
            {watchlistItems.map((item, idx) => (
              <motion.div
                key={item.program}
                initial={{ opacity: 0, x: -6 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: idx * 0.04 }}
                className="flex items-center gap-0 rounded-xl border border-border/30 bg-card hover:bg-muted/20 transition-all duration-200 group cursor-pointer overflow-hidden"
              >
                <div className={cn("w-[3px] self-stretch shrink-0 rounded-l-xl", statusBarColors[item.status])} />

                <div className="flex items-center gap-3 p-3 flex-1 min-w-0">
                  <span className="text-[11px] font-black text-muted-foreground/25 w-4 text-center tabular-nums">{idx + 1}</span>

                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-0.5">
                      <span className="text-[12px] font-bold text-foreground">{item.program}</span>
                      <span className="text-[10px] text-muted-foreground/40">·</span>
                      <span className="text-[10px] text-muted-foreground">{item.phase}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className={cn("text-[9px] px-2 py-0.5 rounded-full border font-bold", statusBadge[item.status])}>
                        {statusLabels[item.status]}
                      </span>
                      {item.lateTasks > 0 && (
                        <span className="flex items-center gap-0.5 text-[10px] font-bold text-destructive">
                          <AlertTriangle className="w-2.5 h-2.5" />
                          {item.lateTasks} late
                        </span>
                      )}
                    </div>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={(e) => { e.stopPropagation(); toggleWatchlist(item.program); }}
                      className="p-1.5 rounded-lg hover:bg-muted/50 transition-colors press-scale"
                      title="Remove from watchlist"
                      aria-label={`Remove ${item.program} from watchlist`}
                    >
                      <Star className="w-3.5 h-3.5 text-warning fill-warning" />
                    </button>
                    <span className="text-[10px] text-primary font-semibold opacity-0 group-hover:opacity-100 transition-opacity flex items-center gap-0.5 whitespace-nowrap">
                      View <ChevronRight className="w-3 h-3" />
                    </span>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default WatchlistPanel;
