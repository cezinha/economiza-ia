import { createContext, useContext, useState, useEffect, useRef, type ReactNode } from "react";
import type { FunctionFilterValue } from "@/components/dashboard/FunctionFilter";
import { useRole } from "@/contexts/RoleContext";
import { PLATFORM_LOB, PLATFORM_ORG } from "@/contexts/UniversalFilterContext";
import { CURRENT_USER_OWNER_NAME } from "@/data/taskParticipants";

export const ORGS = ["CSG", "ISG"] as const;
export const STATUSES = ["On Track", "At Risk w/ Mitigation", "At Risk w/ No Plan"] as const;

export interface HomeFilterState {
  orgs: string[];
  lobs: string[];
  platforms: string[];
  phases: string[];
  statuses: string[];
  /** Multi-select Function values (GOE / SChM / NPI / Auto). */
  functions: FunctionFilterValue[];
  /** Multi-select Owner names (autocomplete). */
  ownerSearch: string[];
  /** Multi-select Task name substrings (autocomplete). */
  taskSearch: string[];
}

export const defaultHomeFilters: HomeFilterState = {
  orgs: [],
  lobs: [],
  platforms: [],
  phases: [],
  statuses: [],
  functions: [],
  ownerSearch: [],
  taskSearch: [],
};

interface HomeFilterContextType {
  filters: HomeFilterState;
  setFilters: (f: HomeFilterState) => void;
  reset: () => void;
  hasActive: boolean;
}

const HomeFilterContext = createContext<HomeFilterContextType | undefined>(undefined);

export const HomeFilterProvider = ({ children }: { children: ReactNode }) => {
  const [filters, setFilters] = useState<HomeFilterState>(defaultHomeFilters);
  const { role, assignedPlatforms } = useRole();
  const seededRef = useRef(false);

  // Seed filter chips for User and Admin roles from their assigned platforms.
  // The Owner chip is only seeded for User (Admin manages platforms, not tasks).
  // Runs once per scoped session; resets when role transitions to a non-scoped role.
  useEffect(() => {
    if (role !== "User" && role !== "Admin") {
      seededRef.current = false;
      return;
    }
    if (seededRef.current) return;
    if (assignedPlatforms.length === 0) return;

    const orgs = Array.from(
      new Set(assignedPlatforms.map((p) => PLATFORM_ORG[p]).filter(Boolean)),
    );
    const lobs = Array.from(
      new Set(assignedPlatforms.map((p) => PLATFORM_LOB[p]).filter(Boolean)),
    );

    setFilters({
      ...defaultHomeFilters,
      orgs,
      lobs,
      platforms: [...assignedPlatforms],
      ownerSearch: role === "User" ? [CURRENT_USER_OWNER_NAME] : [],
    });
    seededRef.current = true;
  }, [role, assignedPlatforms]);

  const hasActive =
    filters.orgs.length > 0 ||
    filters.lobs.length > 0 ||
    filters.platforms.length > 0 ||
    filters.phases.length > 0 ||
    filters.statuses.length > 0 ||
    filters.functions.length > 0 ||
    filters.ownerSearch.length > 0 ||
    filters.taskSearch.length > 0;

  return (
    <HomeFilterContext.Provider
      value={{ filters, setFilters, reset: () => setFilters(defaultHomeFilters), hasActive }}
    >
      {children}
    </HomeFilterContext.Provider>
  );
};

export const useHomeFilters = () => {
  const ctx = useContext(HomeFilterContext);
  if (!ctx) throw new Error("useHomeFilters must be used within HomeFilterProvider");
  return ctx;
};
