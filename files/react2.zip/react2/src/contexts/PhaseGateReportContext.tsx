import { createContext, useContext, useState, useCallback, useMemo, useEffect, type ReactNode } from "react";

export type LobKey = "CSG" | "ISG" | "DnCP";
export const REPORT_LOBS: LobKey[] = ["CSG", "ISG", "DnCP"];

export interface RiskRow {
  id: string;
  phase: string;
  status: "on-track" | "at-risk" | "delayed";
  platform: string;
  issue: string;
  impact: string;
  mitigation: string;
  owner: string;
  target: string;
}

export interface ReportEdits {
  /** Override executive summary bullets — when undefined, defaults are auto-generated. */
  summaryBullets?: string[];
  /** Override risk rows — when undefined, defaults are auto-generated. */
  risks?: RiskRow[];
}

export interface ReportRecord {
  submitted: boolean;
  submittedAt?: string;
  submittedBy?: string;
  edits?: ReportEdits;
}

type ReportMap = Record<LobKey, ReportRecord>;

const STORAGE_KEY = "phaseGateReports";

const empty = (): ReportMap => ({
  CSG: { submitted: false },
  ISG: { submitted: false },
  DnCP: { submitted: false },
});

interface CtxType {
  reports: ReportMap;
  submitReport: (lob: LobKey, edits?: ReportEdits) => void;
  saveDraft: (lob: LobKey, edits: ReportEdits) => void;
  resetReport: (lob: LobKey) => void;
  getReport: (lob: LobKey) => ReportRecord;
  isSubmitted: (lob: LobKey) => boolean;
}

const PhaseGateReportContext = createContext<CtxType | undefined>(undefined);

export const PhaseGateReportProvider = ({ children }: { children: ReactNode }) => {
  const [reports, setReports] = useState<ReportMap>(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) return { ...empty(), ...JSON.parse(raw) };
    } catch {}
    return empty();
  });

  useEffect(() => {
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify(reports)); } catch {}
  }, [reports]);

  const submitReport = useCallback((lob: LobKey, edits?: ReportEdits) => {
    const submittedBy = localStorage.getItem("userName") || "Super Admin";
    setReports((prev) => ({
      ...prev,
      [lob]: {
        submitted: true,
        submittedAt: new Date().toISOString(),
        submittedBy,
        edits: edits ?? prev[lob]?.edits,
      },
    }));
  }, []);

  const saveDraft = useCallback((lob: LobKey, edits: ReportEdits) => {
    setReports((prev) => ({ ...prev, [lob]: { ...prev[lob], edits } }));
  }, []);

  const resetReport = useCallback((lob: LobKey) => {
    setReports((prev) => ({ ...prev, [lob]: { submitted: false } }));
  }, []);

  const getReport = useCallback((lob: LobKey) => reports[lob], [reports]);
  const isSubmitted = useCallback((lob: LobKey) => reports[lob]?.submitted ?? false, [reports]);

  const value = useMemo(() => ({ reports, submitReport, saveDraft, resetReport, getReport, isSubmitted }),
    [reports, submitReport, saveDraft, resetReport, getReport, isSubmitted]);

  return <PhaseGateReportContext.Provider value={value}>{children}</PhaseGateReportContext.Provider>;
};

export const usePhaseGateReports = () => {
  const ctx = useContext(PhaseGateReportContext);
  if (!ctx) throw new Error("usePhaseGateReports must be used within PhaseGateReportProvider");
  return ctx;
};
