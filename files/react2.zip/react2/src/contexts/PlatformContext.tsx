import { createContext, useContext, useState, useCallback, type ReactNode } from "react";

const PROGRAMS = ["Laptop 1", "Laptop 2", "Laptop 3", "Laptop 4", "Laptop 5", "Laptop 6", "Laptop 7"] as const;

interface PlatformContextType {
  selectedPlatform: string | null; // null = All Platforms
  setSelectedPlatform: (platform: string | null) => void;
  programs: readonly string[];
  isPortfolioView: boolean;
}

const PlatformContext = createContext<PlatformContextType | undefined>(undefined);

export const PlatformProvider = ({ children }: { children: ReactNode }) => {
  const [selectedPlatform, setSelectedPlatformState] = useState<string | null>(() => {
    const stored = sessionStorage.getItem("selectedProgram");
    return stored && PROGRAMS.includes(stored as any) ? stored : null;
  });

  const setSelectedPlatform = useCallback((platform: string | null) => {
    setSelectedPlatformState(platform);
    if (platform) {
      sessionStorage.setItem("selectedProgram", platform);
    } else {
      sessionStorage.removeItem("selectedProgram");
    }
  }, []);

  return (
    <PlatformContext.Provider value={{
      selectedPlatform,
      setSelectedPlatform,
      programs: PROGRAMS,
      isPortfolioView: selectedPlatform === null,
    }}>
      {children}
    </PlatformContext.Provider>
  );
};

export const usePlatform = () => {
  const ctx = useContext(PlatformContext);
  if (!ctx) throw new Error("usePlatform must be used within PlatformProvider");
  return ctx;
};
