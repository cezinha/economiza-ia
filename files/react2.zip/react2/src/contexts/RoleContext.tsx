import { createContext, useContext, useState, useCallback, useMemo, type ReactNode } from "react";

export type AppRole = "Executive" | "Super Admin" | "Admin" | "User";

/** Roles that are scoped to one or more assigned platforms */
export const SCOPED_ROLES: AppRole[] = ["Admin", "User"];

/** Roles that may be assigned to multiple platforms */
export const MULTI_PLATFORM_ROLES: AppRole[] = ["Admin", "User"];

export const supportsMultiplePlatforms = (role: AppRole | null) =>
  role !== null && MULTI_PLATFORM_ROLES.includes(role);

interface RoleContextType {
  role: AppRole | null;
  /** All platforms this account is assigned to (empty when role is unscoped). */
  assignedPlatforms: string[];
  /** Convenience accessor — first assigned platform, or null. */
  assignedPlatform: string | null;
  /** True when current role is Admin or User (platform-scoped). */
  isScoped: boolean;
  setRoleAndPlatforms: (role: AppRole, assignedPlatforms: string[], persist: boolean) => void;
  clearRole: () => void;
}

const RoleContext = createContext<RoleContextType | undefined>(undefined);

const readStoredPlatforms = (): string[] => {
  const multi = localStorage.getItem("assignedPlatforms");
  if (multi) {
    try {
      const parsed = JSON.parse(multi);
      if (Array.isArray(parsed)) return parsed.filter((p): p is string => typeof p === "string");
    } catch {
      // fall through
    }
  }
  // Back-compat: previously stored a single assignedPlatform string
  const legacy = localStorage.getItem("assignedPlatform");
  return legacy ? [legacy] : [];
};

export const RoleProvider = ({ children }: { children: ReactNode }) => {
  const [role, setRole] = useState<AppRole | null>(() => {
    return (localStorage.getItem("savedRole") as AppRole | null) ?? null;
  });
  const [assignedPlatforms, setAssignedPlatforms] = useState<string[]>(readStoredPlatforms);

  const setRoleAndPlatforms = useCallback(
    (nextRole: AppRole, platforms: string[], persist: boolean) => {
      const cleaned = Array.from(new Set(platforms)).filter(Boolean);
      setRole(nextRole);
      setAssignedPlatforms(cleaned);
      if (persist) {
        localStorage.setItem("savedRole", nextRole);
        if (cleaned.length > 0) {
          localStorage.setItem("assignedPlatforms", JSON.stringify(cleaned));
          // Keep legacy key roughly in sync for any other readers
          localStorage.setItem("assignedPlatform", cleaned[0]);
        } else {
          localStorage.removeItem("assignedPlatforms");
          localStorage.removeItem("assignedPlatform");
        }
      }
    },
    []
  );

  const clearRole = useCallback(() => {
    setRole(null);
    setAssignedPlatforms([]);
    localStorage.removeItem("savedRole");
    localStorage.removeItem("assignedPlatforms");
    localStorage.removeItem("assignedPlatform");
  }, []);

  const value = useMemo<RoleContextType>(
    () => ({
      role,
      assignedPlatforms,
      assignedPlatform: assignedPlatforms[0] ?? null,
      isScoped: role !== null && SCOPED_ROLES.includes(role),
      setRoleAndPlatforms,
      clearRole,
    }),
    [role, assignedPlatforms, setRoleAndPlatforms, clearRole]
  );

  return <RoleContext.Provider value={value}>{children}</RoleContext.Provider>;
};

export const useRole = () => {
  const ctx = useContext(RoleContext);
  if (!ctx) throw new Error("useRole must be used within RoleProvider");
  return ctx;
};
