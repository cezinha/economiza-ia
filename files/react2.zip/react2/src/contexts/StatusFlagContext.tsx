import { createContext, useCallback, useContext, useEffect, useMemo, useState, ReactNode } from "react";
import type { TaskFlag } from "@/lib/statusFlagging";
import { evaluateTaskFlag } from "@/lib/statusFlagging";
import type { ScheduleTask, TaskStatus } from "@/data/scheduleData";
import { programSchedules, setTaskStatusOverrides } from "@/data/scheduleData";

interface StatusFlagContextValue {
  flags: TaskFlag[];
  dismissedIds: Set<string>;
  confirmedStatuses: Map<string, TaskStatus>;
  confirmFlag: (taskId: string) => void;
  overrideFlag: (taskId: string) => void;
  clearOverride: (taskId: string) => void;
  getEffectiveStatus: (task: ScheduleTask) => TaskStatus;
}

const StatusFlagContext = createContext<StatusFlagContextValue | null>(null);

const computeAllFlags = (
  dismissed: Set<string>,
  confirmed: Map<string, TaskStatus>,
): TaskFlag[] => {
  const out: TaskFlag[] = [];
  Object.values(programSchedules).forEach((phases) => {
    phases.forEach((phase) => {
      phase.milestones.forEach((m) => {
        m.tasks.forEach((task: ScheduleTask) => {
          if (dismissed.has(task.id)) return;
          // Skip if effective status already matches/exceeds the suggestion
          const effective = confirmed.get(task.id) ?? task.status;
          const f = evaluateTaskFlag({ ...task, status: effective });
          if (!f) return;
          out.push({
            taskId: task.id,
            taskName: task.name,
            currentStatus: effective,
            ...f,
          });
        });
      });
    });
  });
  return out.sort((a, b) => {
    if (a.severity !== b.severity) return a.severity === "red" ? -1 : 1;
    return a.daysUntilDue - b.daysUntilDue;
  });
};

export const StatusFlagProvider = ({ children }: { children: ReactNode }) => {
  const [dismissedIds, setDismissedIds] = useState<Set<string>>(new Set());
  const [confirmedStatuses, setConfirmedStatuses] = useState<Map<string, TaskStatus>>(new Map());

  // Sync overrides into the shared scheduleData module so computeRollupStatus
  // (called by Gantt / Status / Home / Schedule) escalates automatically.
  useEffect(() => {
    setTaskStatusOverrides(confirmedStatuses.entries());
  }, [confirmedStatuses]);

  const flags = useMemo(
    () => computeAllFlags(dismissedIds, confirmedStatuses),
    [dismissedIds, confirmedStatuses],
  );

  const confirmFlag = useCallback((taskId: string) => {
    // Look up the suggested status from the current flag for this task.
    let suggested: TaskStatus | null = null;
    Object.values(programSchedules).some((phases) =>
      phases.some((phase) =>
        phase.milestones.some((m) =>
          m.tasks.some((t) => {
            if (t.id !== taskId) return false;
            const f = evaluateTaskFlag(t);
            if (f) suggested = f.suggested;
            return true;
          }),
        ),
      ),
    );
    if (suggested) {
      setConfirmedStatuses((prev) => {
        const next = new Map(prev);
        next.set(taskId, suggested!);
        return next;
      });
    }
    setDismissedIds((prev) => {
      const next = new Set(prev);
      next.add(taskId);
      return next;
    });
  }, []);

  const overrideFlag = useCallback((taskId: string) => {
    setDismissedIds((prev) => {
      const next = new Set(prev);
      next.add(taskId);
      return next;
    });
  }, []);

  const clearOverride = useCallback((taskId: string) => {
    setConfirmedStatuses((prev) => {
      if (!prev.has(taskId)) return prev;
      const next = new Map(prev);
      next.delete(taskId);
      return next;
    });
    setDismissedIds((prev) => {
      if (!prev.has(taskId)) return prev;
      const next = new Set(prev);
      next.delete(taskId);
      return next;
    });
  }, []);

  const getEffectiveStatus = useCallback(
    (task: ScheduleTask): TaskStatus => confirmedStatuses.get(task.id) ?? task.status,
    [confirmedStatuses],
  );

  return (
    <StatusFlagContext.Provider
      value={{
        flags,
        dismissedIds,
        confirmedStatuses,
        confirmFlag,
        overrideFlag,
        clearOverride,
        getEffectiveStatus,
      }}
    >
      {children}
    </StatusFlagContext.Provider>
  );
};

export const useStatusFlags = () => {
  const ctx = useContext(StatusFlagContext);
  if (!ctx) throw new Error("useStatusFlags must be used within StatusFlagProvider");
  return ctx;
};
