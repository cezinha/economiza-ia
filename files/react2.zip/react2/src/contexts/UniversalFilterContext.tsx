import { createContext, useContext, useState, useMemo, useCallback, type ReactNode } from "react";
import { usePlatform } from "@/contexts/PlatformContext";

/** Organization assignment for each platform (one level above LOB). */
export const PLATFORM_ORG: Record<string, string> = {
  "Laptop 1": "CSG",
  "Laptop 2": "CSG",
  "Laptop 3": "CSG",
  "Laptop 4": "CSG",
  "Laptop 5": "CSG",
  "Laptop 6": "CSG",
  "Laptop 7": "CSG",
};

/** LOB assignment for each platform. LOBs: Notebook, Desktop, DnCP. */
export const PLATFORM_LOB: Record<string, string> = {
  "Laptop 1": "Notebook",
  "Laptop 2": "Notebook",
  "Laptop 3": "Notebook",
  "Laptop 4": "Notebook",
  "Laptop 5": "Notebook",
  "Laptop 6": "Notebook",
  "Laptop 7": "Notebook",
};

export const ORGANIZATIONS = ["CSG", "ISG"] as const;
export const LOBS = ["Notebook", "Desktop", "DnCP"] as const;
export const PHASES = ["Concept", "Define", "Plan", "Qual", "Pilot", "Ramp"] as const;
export const TASK_CATEGORIES = [
  "Document Upload",
  "Team Formation",
  "Supply Chain",
  "DFx Assessment",
  "BOM / Cost",
  "Build Readiness",
  "Quality / Compliance",
  "Communication",
] as const;

export interface UniversalFilters {
  organization: string;
  lob: string;
  platform: string;
  phase: string;
  task: string;
}

export const defaultFilters: UniversalFilters = {
  organization: "all",
  lob: "all",
  platform: "all",
  phase: "all",
  task: "all",
};

/** Phase-name normalisation for matching filter values to data fields */
const PHASE_MAP: Record<string, string[]> = {
  Concept: ["Concept"],
  Define: ["Define"],
  Plan: ["Plan"],
  "Qual": ["Qual", "Develop", "DVT", "EVT", "PVT", "Develop/Qual"],
  "Pilot": ["Pilot", "Mockup/EVT"],
  "Ramp": ["Ramp", "Launch", "RTS", "RTO"],
};

export function phaseMatches(filterPhase: string, dataPhase: string): boolean {
  if (filterPhase === "all") return true;
  const aliases = PHASE_MAP[filterPhase];
  if (!aliases) return dataPhase === filterPhase;
  return aliases.some((a) => dataPhase.includes(a));
}

interface UniversalFilterContextType {
  filters: UniversalFilters;
  setFilters: (filters: UniversalFilters) => void;
  updateFilter: (key: keyof UniversalFilters, value: string) => void;
  /** Check if a platform name passes the current Org + LOB + Platform filters */
  matchesPlatform: (platformName: string) => boolean;
  /** Check if a phase string passes the current Phase filter */
  matchesPhase: (phase: string) => boolean;
}

const UniversalFilterContext = createContext<UniversalFilterContextType | undefined>(undefined);

export const UniversalFilterProvider = ({ children }: { children: ReactNode }) => {
  const { setSelectedPlatform } = usePlatform();
  const [filters, setFilters] = useState<UniversalFilters>(defaultFilters);

  const updateFilter = useCallback((key: keyof UniversalFilters, value: string) => {
    setFilters((prev) => {
      const next = { ...prev, [key]: value };
      if (key === "organization") {
        next.lob = "all";
        next.platform = "all";
        next.phase = "all";
        next.task = "all";
      } else if (key === "lob") {
        next.platform = "all";
        next.phase = "all";
        next.task = "all";
      } else if (key === "platform") {
        next.phase = "all";
        next.task = "all";
      } else if (key === "phase") {
        next.task = "all";
      }
      return next;
    });
    if (key === "organization" || key === "lob") {
      setSelectedPlatform(null);
    } else if (key === "platform") {
      setSelectedPlatform(value === "all" ? null : value);
    }
  }, [setSelectedPlatform]);

  const matchesPlatform = useCallback((platformName: string): boolean => {
    if (filters.organization !== "all") {
      const org = PLATFORM_ORG[platformName];
      if (org !== filters.organization) return false;
    }
    if (filters.lob !== "all") {
      const lob = PLATFORM_LOB[platformName];
      if (lob !== filters.lob) return false;
    }
    if (filters.platform !== "all") {
      if (platformName !== filters.platform) return false;
    }
    return true;
  }, [filters.organization, filters.lob, filters.platform]);

  const matchesPhase = useCallback((phase: string): boolean => {
    return phaseMatches(filters.phase, phase);
  }, [filters.phase]);

  const value = useMemo(() => ({
    filters,
    setFilters,
    updateFilter,
    matchesPlatform,
    matchesPhase,
  }), [filters, updateFilter, matchesPlatform, matchesPhase]);

  return (
    <UniversalFilterContext.Provider value={value}>
      {children}
    </UniversalFilterContext.Provider>
  );
};

export const useUniversalFilters = () => {
  const ctx = useContext(UniversalFilterContext);
  if (!ctx) throw new Error("useUniversalFilters must be used within UniversalFilterProvider");
  return ctx;
};
