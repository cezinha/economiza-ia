import React, { createContext, useContext, useState, useCallback, useMemo } from "react";
import { programs, getProgramStatus } from "@/components/dashboard/ProgramOverviewTimeline";

export interface WatchlistItem {
  program: string;
  status: "on-track" | "at-risk" | "delayed";
  phase: string;
  lateTasks: number;
}

interface WatchlistContextValue {
  watchlist: Set<string>;
  watchlistItems: WatchlistItem[];
  toggleWatchlist: (program: string) => void;
  isInWatchlist: (program: string) => boolean;
}

const WatchlistContext = createContext<WatchlistContextValue | undefined>(undefined);

const phaseForProgram: Record<string, string> = {
  "Laptop 1": "Plan",
  "Laptop 2": "Qual",
  "Laptop 3": "Ramp",
  "Laptop 4": "Define",
  "Laptop 5": "Incubate",
  "Laptop 6": "Concept",
  "Laptop 7": "Plan",
};

const lateTasksForProgram: Record<string, number> = {
  "Laptop 1": 2,
  "Laptop 2": 1,
  "Laptop 3": 0,
  "Laptop 4": 3,
  "Laptop 5": 0,
  "Laptop 6": 1,
  "Laptop 7": 5,
};

export const WatchlistProvider = ({ children }: { children: React.ReactNode }) => {
  const [watchlist, setWatchlist] = useState<Set<string>>(
    new Set(["Laptop 1", "Laptop 2", "Laptop 3", "Laptop 4", "Laptop 5", "Laptop 6", "Laptop 7"])
  );

  const toggleWatchlist = useCallback((program: string) => {
    setWatchlist((prev) => {
      const next = new Set(prev);
      if (next.has(program)) {
        // Prevent removing last starred program
        if (next.size <= 1) return prev;
        next.delete(program);
      } else {
        next.add(program);
      }
      return next;
    });
  }, []);

  const isInWatchlist = useCallback((program: string) => watchlist.has(program), [watchlist]);

  const watchlistItems: WatchlistItem[] = useMemo(() => {
    return Array.from(watchlist).map((name) => {
      const prog = programs.find((p) => p.name === name);
      const status = prog ? getProgramStatus(prog) : "on-track";
      return {
        program: name,
        status,
        phase: phaseForProgram[name] ?? "—",
        lateTasks: lateTasksForProgram[name] ?? 0,
      };
    });
  }, [watchlist]);

  return (
    <WatchlistContext.Provider value={{ watchlist, watchlistItems, toggleWatchlist, isInWatchlist }}>
      {children}
    </WatchlistContext.Provider>
  );
};

export const useWatchlist = () => {
  const ctx = useContext(WatchlistContext);
  if (!ctx) throw new Error("useWatchlist must be used within WatchlistProvider");
  return ctx;
};
