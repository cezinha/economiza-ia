// Shared NUDDs dataset + helpers. Single source of truth for the NUDDs page
// and any other surface (e.g. the platform schedule summary) that needs to
// reason about NUDDs that impact a specific platform.

export type NuddStatus = "Open" | "On Hold" | "Completed";

export interface NuddRecord {
  id: string;
  summary: string;
  affectedPlatforms: string;
  affectedLOBs: string;
  detailedDescription: string;
  goeOlpPhase: string;
  riskEvents: string;
  riskDrivers: string;
  mitigationPlan: string;
  status: NuddStatus;
  currentScore: number;
  dateCreated: string;
  dateUpdated: string;
}

export interface NuddScoring {
  id: string;
  riskImpact: number;
  riskProbability: number;
  riskPriority: number;
  overallRiskLevel: "H" | "M" | "L";
  overallStatus: string;
}

export const nuddsData: NuddRecord[] = [
  { id: "GRIT-2818", summary: "Brightness drop (<100 nits) and Transmittance % reduction", affectedPlatforms: "Laptop 1, Laptop 2", affectedLOBs: "Notebook", detailedDescription: "Brightness drop (<100 nits) and Transmittance % reduction caused by iridescent layer blocking light.", goeOlpPhase: "Define", riskEvents: "Brightness drop caused by iridescent layer blocking light.", riskDrivers: "Coating Attenuation: Iridescent IML coating acts as an optical barrier.", mitigationPlan: "Optimize PWM tuning to boost LED output and punch through the coating layer.", status: "Open", currentScore: 8, dateCreated: "2026-01-22", dateUpdated: "2026-04-10T14:32" },
  { id: "GRIT-2817", summary: "Yield Loss due to Front Panel Assembly", affectedPlatforms: "Laptop 3, Laptop 5", affectedLOBs: "Notebook", detailedDescription: "Yield loss observed during front panel assembly due to adhesive curing inconsistency.", goeOlpPhase: "Plan", riskEvents: "Adhesive curing failure causing panel separation.", riskDrivers: "Temperature variance in curing oven across production line.", mitigationPlan: "Calibrate oven zones and add inline temperature monitoring.", status: "Open", currentScore: 6, dateCreated: "2026-02-04", dateUpdated: "2026-04-15T09:18" },
  { id: "GRIT-2814", summary: "ENG0018500 A05 Introduction", affectedPlatforms: "Laptop 2", affectedLOBs: "Notebook", detailedDescription: "New A05 revision introduction requiring validation across thermal and EMI parameters.", goeOlpPhase: "Develop", riskEvents: "EMI regression with new PCB layout.", riskDrivers: "Component placement changes in A05 revision.", mitigationPlan: "Run full EMI pre-scan before DVT build.", status: "Completed", currentScore: 3, dateCreated: "2026-01-08", dateUpdated: "2026-03-21T16:05" },
  { id: "GRIT-2813", summary: "Slate TP Modularity and PSCS", affectedPlatforms: "Laptop 4, Laptop 6, Laptop 7", affectedLOBs: "Notebook", detailedDescription: "Touchpad modularity design conflicts with PSCS connector placement.", goeOlpPhase: "Define", riskEvents: "Connector interference during assembly.", riskDrivers: "Mechanical clearance insufficient for modular TP design.", mitigationPlan: "Redesign bracket to provide 0.5mm additional clearance.", status: "Open", currentScore: 9, dateCreated: "2026-01-30", dateUpdated: "2026-04-18T11:47" },
  { id: "GRIT-2812", summary: "CABB Assembly process", affectedPlatforms: "Laptop 5", affectedLOBs: "Notebook", detailedDescription: "CABB assembly process showing inconsistent torque values on fasteners.", goeOlpPhase: "Plan", riskEvents: "Fastener loosening under vibration testing.", riskDrivers: "Torque driver calibration drift on production line.", mitigationPlan: "Implement torque monitoring with SPC alerts.", status: "On Hold", currentScore: 5, dateCreated: "2026-02-12", dateUpdated: "2026-04-02T08:55" },
  { id: "GRIT-2810", summary: "Hinge torque degradation over lifecycle", affectedPlatforms: "Laptop 4, Laptop 7", affectedLOBs: "Notebook", detailedDescription: "Hinge torque drops below spec after 15K cycles causing lid droop.", goeOlpPhase: "Develop", riskEvents: "Lid fails to hold position at angles >120°.", riskDrivers: "Lubricant degradation and bushing wear.", mitigationPlan: "Switch to PTFE-coated bushings and revalidate at 20K cycles.", status: "Open", currentScore: 7, dateCreated: "2026-02-19", dateUpdated: "2026-04-19T13:22" },
  { id: "GRIT-2808", summary: "Speaker rattling at high frequencies", affectedPlatforms: "Laptop 6", affectedLOBs: "Notebook", detailedDescription: "Speaker module exhibits audible rattling above 12kHz at max volume.", goeOlpPhase: "Define", riskEvents: "Audio quality degradation reported in user testing.", riskDrivers: "Insufficient gasket compression on speaker cavity.", mitigationPlan: "Add foam damper and increase gasket compression by 0.3mm.", status: "Completed", currentScore: 4, dateCreated: "2026-01-15", dateUpdated: "2026-03-29T10:11" },
  { id: "GRIT-2805", summary: "Battery swelling under thermal stress", affectedPlatforms: "Laptop 1, Laptop 3, Laptop 5", affectedLOBs: "Notebook", detailedDescription: "Battery cells show swelling after 500 charge cycles at 45°C ambient.", goeOlpPhase: "Plan", riskEvents: "Battery expansion causing keyboard deck lift.", riskDrivers: "Electrolyte decomposition at elevated temperatures.", mitigationPlan: "Qualify alternate cell chemistry with higher thermal tolerance.", status: "Open", currentScore: 9, dateCreated: "2026-02-26", dateUpdated: "2026-04-20T15:40" },
  { id: "GRIT-2803", summary: "USB-C port intermittent connection", affectedPlatforms: "Laptop 4", affectedLOBs: "Notebook", detailedDescription: "USB-C port loses connection under lateral force on connector.", goeOlpPhase: "Develop", riskEvents: "Data transfer interruption during docking.", riskDrivers: "Solder joint fatigue on port receptacle.", mitigationPlan: "Add through-hole anchor pins and reflow solder profile adjustment.", status: "On Hold", currentScore: 6, dateCreated: "2026-03-04", dateUpdated: "2026-04-08T12:03" },
  { id: "GRIT-2801", summary: "Fan noise exceeds spec at idle", affectedPlatforms: "Laptop 2, Laptop 6", affectedLOBs: "Notebook", detailedDescription: "Fan noise measured at 32dBA at idle, exceeding 28dBA spec limit.", goeOlpPhase: "Define", riskEvents: "Acoustic compliance failure at certification.", riskDrivers: "Bearing tolerance stack-up causing vibration resonance.", mitigationPlan: "Source tighter tolerance bearings and add rubber isolation mounts.", status: "Open", currentScore: 5, dateCreated: "2026-03-11", dateUpdated: "2026-04-17T17:28" },
  { id: "GRIT-2799", summary: "Thermal throttling during sustained workload", affectedPlatforms: "Laptop 3, Laptop 7", affectedLOBs: "Notebook", detailedDescription: "CPU thermal throttles after 10 min of sustained multi-threaded load.", goeOlpPhase: "Develop", riskEvents: "Performance benchmark regression vs prior generation.", riskDrivers: "Vapor chamber contact pressure insufficient on die.", mitigationPlan: "Increase spring force on heatsink mount and add graphite TIM.", status: "Open", currentScore: 8, dateCreated: "2026-03-18", dateUpdated: "2026-04-21T09:44" },
];

export const nuddsScoringData: NuddScoring[] = [
  { id: "GRIT-2818", riskImpact: 2, riskProbability: 2, riskPriority: 4, overallRiskLevel: "M", overallStatus: "NONE" },
  { id: "GRIT-2817", riskImpact: 3, riskProbability: 3, riskPriority: 9, overallRiskLevel: "H", overallStatus: "OPEN" },
  { id: "GRIT-2814", riskImpact: 1, riskProbability: 1, riskPriority: 1, overallRiskLevel: "L", overallStatus: "NONE" },
  { id: "GRIT-2813", riskImpact: 3, riskProbability: 3, riskPriority: 9, overallRiskLevel: "H", overallStatus: "OPEN" },
  { id: "GRIT-2812", riskImpact: 2, riskProbability: 1, riskPriority: 2, overallRiskLevel: "L", overallStatus: "NONE" },
  { id: "GRIT-2810", riskImpact: 2, riskProbability: 3, riskPriority: 6, overallRiskLevel: "M", overallStatus: "OPEN" },
  { id: "GRIT-2808", riskImpact: 1, riskProbability: 2, riskPriority: 2, overallRiskLevel: "L", overallStatus: "NONE" },
  { id: "GRIT-2805", riskImpact: 3, riskProbability: 3, riskPriority: 9, overallRiskLevel: "H", overallStatus: "OPEN" },
  { id: "GRIT-2803", riskImpact: 2, riskProbability: 2, riskPriority: 4, overallRiskLevel: "M", overallStatus: "NONE" },
  { id: "GRIT-2801", riskImpact: 2, riskProbability: 2, riskPriority: 4, overallRiskLevel: "M", overallStatus: "NONE" },
  { id: "GRIT-2799", riskImpact: 3, riskProbability: 3, riskPriority: 9, overallRiskLevel: "H", overallStatus: "OPEN" },
];

export const PHASES_ORDER = ["Concept", "Define", "Plan", "Qual", "Pilot", "Ramp"] as const;
export type CanonicalPhase = typeof PHASES_ORDER[number];

/** Migrate legacy phase names to the new canonical 6-phase model. */
export const migratePhaseName = (phase: string): string => {
  if (phase === "Develop / Qual") return "Qual";
  if (phase === "Pilot / Ramp / Launch") return "Pilot";
  return phase;
};

export const phaseMap = (phase: string): CanonicalPhase | string => {
  const p = phase.toLowerCase();
  if (p.includes("ramp") || p.includes("launch") || p.includes("rts") || p.includes("rto")) return "Ramp";
  if (p.includes("pilot")) return "Pilot";
  if (p.includes("develop") || p.includes("qual") || p.includes("evt") || p.includes("dvt") || p.includes("pvt")) return "Qual";
  if (p.includes("plan")) return "Plan";
  if (p.includes("define")) return "Define";
  if (p.includes("concept") || p.includes("mockup")) return "Concept";
  return phase;
};

export type EnrichedNudd = NuddRecord & NuddScoring;

const platformsOf = (csv: string): string[] =>
  csv.split(",").map((s) => s.trim()).filter(Boolean);

export function getNuddsForPlatform(platform: string): EnrichedNudd[] {
  const scoringById = new Map(nuddsScoringData.map((s) => [s.id, s]));
  return nuddsData
    .filter((n) => platformsOf(n.affectedPlatforms).includes(platform))
    .map((n) => {
      const s = scoringById.get(n.id);
      return s ? { ...n, ...s } : null;
    })
    .filter((x): x is EnrichedNudd => x !== null);
}
