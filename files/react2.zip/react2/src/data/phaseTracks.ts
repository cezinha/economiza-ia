/**
 * Dual-track phase taxonomy.
 *
 * The portfolio is run on two parallel timelines that share the same calendar
 * dates but use different phase nomenclature:
 *
 *   GOE / NPI track:  Concept → Define → Plan → Qual    → Pilot   → Ramp
 *   SChM track:       Concept → Define → Plan → Develop          → Launch
 *
 * SChM-only phases (Develop, Launch) are derived from existing platform
 * timelines so we keep a single source of truth for dates while presenting the
 * correct phase chips/bars per audience.
 */

import { platformPhaseTimelines } from "@/data/platformPhaseTimelines";
import type { ScheduleTask } from "@/data/scheduleData";

export type Track = "GOE_NPI" | "SCHM";

export const GOE_NPI_PHASES = ["Concept", "Define", "Plan", "Qual", "Pilot", "Ramp"] as const;
export const SCHM_PHASES = ["Concept", "Define", "Plan", "Develop", "Launch"] as const;

export type GoeNpiPhase = (typeof GOE_NPI_PHASES)[number];
export type SchmPhase = (typeof SCHM_PHASES)[number];

export const TRACK_LABEL: Record<Track, string> = {
  GOE_NPI: "GOE / NPI",
  SCHM: "SChM",
};

/** MDS-aligned hue for each track (used in chips, swatches, milestone glyphs). */
export const TRACK_TONE: Record<Track, { bg: string; text: string; border: string; bar: string }> = {
  GOE_NPI: {
    bg: "bg-[hsl(var(--mds-blue))]/10",
    text: "text-[hsl(var(--mds-blue))]",
    border: "border-[hsl(var(--mds-blue))]/30",
    bar: "bg-[hsl(var(--mds-blue))]",
  },
  SCHM: {
    bg: "bg-[hsl(var(--mds-navy))]/10",
    text: "text-[hsl(var(--mds-navy))]",
    border: "border-[hsl(var(--mds-navy))]/30",
    bar: "bg-[hsl(var(--mds-navy))]",
  },
};

/** Map a function/owner string to its track. */
export const getTrackForFunction = (fn: string): Track => {
  if (/schm/i.test(fn)) return "SCHM";
  return "GOE_NPI";
};

/**
 * Deterministic track assignment for a task. We don't have an authored field,
 * so derive from owner + name keywords:
 *   - explicit "SChM" owner → SCHM
 *   - supply-chain / logistics / fulfillment / sourcing / commodity / RFQ /
 *     ODM / capex keywords → SCHM
 *   - everything else → GOE_NPI
 */
export const getTaskTrack = (task: Pick<ScheduleTask, "id" | "name" | "owner">): Track => {
  if (/schm/i.test(task.owner)) return "SCHM";
  const n = task.name.toLowerCase();
  if (
    /supply\s*chain|logistics|fulfillment|sourcing|commodity|rfq|odm|supplier|capex|warehouse|customs|freight|inventory|sku|allocation|forecast|cost|bom/.test(
      n,
    )
  ) {
    return "SCHM";
  }
  return "GOE_NPI";
};

/** Phase list for a track. */
export const phasesForTrack = (track: Track): readonly string[] =>
  track === "GOE_NPI" ? GOE_NPI_PHASES : SCHM_PHASES;

/**
 * Per-platform SChM timeline derived from the canonical 6-phase timeline:
 *   Concept / Define / Plan stay as-is.
 *   Develop = Qual.start → Pilot.end
 *   Launch  = Ramp (start → end)
 */
export const platformPhaseTimelinesSchm: Record<string, Record<string, { start: Date; end: Date }>> =
  Object.fromEntries(
    Object.entries(platformPhaseTimelines).map(([platform, t]) => {
      const concept = t.Concept;
      const define = t.Define;
      const plan = t.Plan;
      const qual = t.Qual;
      const pilot = t.Pilot;
      const ramp = t.Ramp;
      return [
        platform,
        {
          Concept: concept,
          Define: define,
          Plan: plan,
          Develop: qual && pilot ? { start: qual.start, end: pilot.end } : qual ?? pilot,
          Launch: ramp,
        },
      ];
    }),
  );

/** Map a SChM phase name back to the GOE/NPI phase it spans (for milestones). */
export const SCHM_TO_GOE_NPI_SPAN: Record<SchmPhase, string[]> = {
  Concept: ["Concept"],
  Define: ["Define"],
  Plan: ["Plan"],
  Develop: ["Qual", "Pilot"],
  Launch: ["Ramp"],
};
