/**
 * Pure-data module: per-platform GOE/NPI phase timelines.
 *
 * Extracted from PortfolioScheduleGantt to break a circular dependency between
 * the Gantt component and `phaseTracks.ts` (which derives the SChM timelines
 * from this constant at module top-level).
 */

// Helper to split a legacy Pilot/Ramp/Launch window into a Pilot (~55%) + Ramp (~45%) pair.
const _split = (start: Date, end: Date): { pilotEnd: Date; rampEnd: Date } => {
  const span = end.getTime() - start.getTime();
  return {
    pilotEnd: new Date(start.getTime() + span * 0.55),
    rampEnd: end,
  };
};

const _laptop1 = _split(new Date(2026, 8, 15), new Date(2026, 10, 2));
const _laptop2 = _split(new Date(2026, 9, 11), new Date(2026, 11, 15));
const _laptop3 = _split(new Date(2026, 9, 1), new Date(2026, 11, 1));
const _laptop4 = _split(new Date(2026, 10, 16), new Date(2027, 1, 28));
const _laptop5 = _split(new Date(2027, 1, 1), new Date(2027, 3, 15));
const _laptop6 = _split(new Date(2026, 10, 2), new Date(2027, 0, 15));
const _laptop7 = _split(new Date(2027, 1, 16), new Date(2027, 4, 1));

export const platformPhaseTimelines: Record<string, Record<string, { start: Date; end: Date }>> = {
  "Laptop 1": {
    Concept: { start: new Date(2025, 9, 1), end: new Date(2025, 11, 14) },
    Define: { start: new Date(2025, 11, 15), end: new Date(2026, 2, 14) },
    Plan: { start: new Date(2026, 2, 15), end: new Date(2026, 5, 29) },
    "Qual": { start: new Date(2026, 5, 30), end: new Date(2026, 8, 14) },
    "Pilot": { start: new Date(2026, 8, 15), end: _laptop1.pilotEnd },
    "Ramp": { start: _laptop1.pilotEnd, end: _laptop1.rampEnd },
  },
  "Laptop 2": {
    Concept: { start: new Date(2025, 10, 1), end: new Date(2026, 0, 15) },
    Define: { start: new Date(2026, 0, 16), end: new Date(2026, 3, 10) },
    Plan: { start: new Date(2026, 3, 11), end: new Date(2026, 6, 15) },
    "Qual": { start: new Date(2026, 6, 16), end: new Date(2026, 9, 10) },
    "Pilot": { start: new Date(2026, 9, 11), end: _laptop2.pilotEnd },
    "Ramp": { start: _laptop2.pilotEnd, end: _laptop2.rampEnd },
  },
  "Laptop 3": {
    Concept: { start: new Date(2025, 8, 15), end: new Date(2025, 10, 30) },
    Define: { start: new Date(2025, 11, 1), end: new Date(2026, 1, 28) },
    Plan: { start: new Date(2026, 2, 1), end: new Date(2026, 5, 15) },
    "Qual": { start: new Date(2026, 5, 16), end: new Date(2026, 8, 30) },
    "Pilot": { start: new Date(2026, 9, 1), end: _laptop3.pilotEnd },
    "Ramp": { start: _laptop3.pilotEnd, end: _laptop3.rampEnd },
  },
  "Laptop 4": {
    Concept: { start: new Date(2026, 0, 1), end: new Date(2026, 2, 1) },
    Define: { start: new Date(2026, 2, 2), end: new Date(2026, 4, 15) },
    Plan: { start: new Date(2026, 4, 16), end: new Date(2026, 7, 31) },
    "Qual": { start: new Date(2026, 8, 1), end: new Date(2026, 10, 15) },
    "Pilot": { start: new Date(2026, 10, 16), end: _laptop4.pilotEnd },
    "Ramp": { start: _laptop4.pilotEnd, end: _laptop4.rampEnd },
  },
  "Laptop 5": {
    Concept: { start: new Date(2026, 1, 1), end: new Date(2026, 3, 15) },
    Define: { start: new Date(2026, 3, 16), end: new Date(2026, 6, 1) },
    Plan: { start: new Date(2026, 6, 2), end: new Date(2026, 9, 15) },
    "Qual": { start: new Date(2026, 9, 16), end: new Date(2027, 0, 31) },
    "Pilot": { start: new Date(2027, 1, 1), end: _laptop5.pilotEnd },
    "Ramp": { start: _laptop5.pilotEnd, end: _laptop5.rampEnd },
  },
  "Laptop 6": {
    Concept: { start: new Date(2025, 11, 1), end: new Date(2026, 1, 15) },
    Define: { start: new Date(2026, 1, 16), end: new Date(2026, 4, 1) },
    Plan: { start: new Date(2026, 4, 2), end: new Date(2026, 7, 15) },
    "Qual": { start: new Date(2026, 7, 16), end: new Date(2026, 10, 1) },
    "Pilot": { start: new Date(2026, 10, 2), end: _laptop6.pilotEnd },
    "Ramp": { start: _laptop6.pilotEnd, end: _laptop6.rampEnd },
  },
  "Laptop 7": {
    Concept: { start: new Date(2026, 2, 1), end: new Date(2026, 4, 15) },
    Define: { start: new Date(2026, 4, 16), end: new Date(2026, 7, 1) },
    Plan: { start: new Date(2026, 7, 2), end: new Date(2026, 10, 1) },
    "Qual": { start: new Date(2026, 10, 2), end: new Date(2027, 1, 15) },
    "Pilot": { start: new Date(2027, 1, 16), end: _laptop7.pilotEnd },
    "Ramp": { start: _laptop7.pilotEnd, end: _laptop7.rampEnd },
  },
};
