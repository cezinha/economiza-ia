// NOTE: All seeded tasks belong to GOE. Other owner functions
// (NPI, SChM, DnCP) will be reintroduced when their task sets are authored.
export type PhaseStatus = "on-track" | "at-risk" | "delayed" | "not-started";
export type TaskStatus = "completed" | "on-track" | "at-risk" | "pending" | "late";
export type CompletionSource = "manual" | "doc-curator" | "regrello" | "bom-tool" | "dfx-tool" | "jqim";

export interface AssignmentHistoryEntry {
  from: string;
  to: string;
  reason: string;
  changedBy: string;
  timestamp: string;
  type: "primary" | "backup";
}

export interface ScheduleTask {
  id: string;
  name: string;
  status: TaskStatus;
  owner: string;
  ownerName?: string;
  ownerEmail?: string;
  assigner?: string;
  assignee?: string;
  requirementDoc?: string;
  dataSources?: string[];
  porDate?: string;        // Plan of Record date (original target)
  actualDate?: string;     // Actual completion date
  delayCount?: number;     // Number of times task was delayed
  category?: string;       // Task category for reminder frequency
  minDuration?: number;    // Minimum recommended duration in days
  isActive?: boolean;      // Whether task is active (for LOB deactivation)
  statusReason?: string;   // Reason for current RYG status
  dependencies?: string[]; // IDs of dependent tasks
  completionSource?: CompletionSource; // How the task was/can be completed
  backupOwner?: string;    // Backup owner alias key into ownerDetails
  assignmentHistory?: AssignmentHistoryEntry[];
}

/**
 * Deterministic backup owner derived from ownerDetails so every task always
 * has a fallback assignee distinct from the primary owner.
 */
export const getBackupOwner = (taskId: string, primaryOwner: string): string => {
  const candidates = Object.keys(__ownerDetailsCache).filter((o) => o !== primaryOwner);
  if (candidates.length === 0) return primaryOwner;
  let hash = 0;
  for (let i = 0; i < taskId.length; i++) hash = (hash * 31 + taskId.charCodeAt(i)) | 0;
  return candidates[Math.abs(hash) % candidates.length];
};

// Forward-declared cache populated below once ownerDetails is defined.
const __ownerDetailsCache: Record<string, { name: string; email: string; function: string }> = {};

// Determine completion source based on task name pattern matching
export const getCompletionSource = (taskName: string): CompletionSource | null => {
  const lower = taskName.toLowerCase();

  // Doc & Data Curator patterns
  if (lower.includes("upload") || lower.includes("confirm") && (lower.includes("ingested") || lower.includes("has been")) || lower.includes("deck")) {
    return "doc-curator";
  }

  // Regrello patterns
  if (lower.includes("send") && lower.includes("communication") || lower.includes("initiate") && lower.includes("formation") || lower.includes("kick-off") || lower.includes("kickoff")) {
    return "regrello";
  }

  // BOM Tool patterns
  if (lower.includes("costed bom") || lower.includes("validate costed") || lower.includes("cs workbook") || lower.includes("review") && lower.includes("cost")) {
    return "bom-tool";
  }

  // DFx Tool patterns
  if (lower.includes("dfx") || lower.includes("df") && lower.includes("assessment")) {
    return "dfx-tool";
  }

  // JQIM patterns
  if (lower.includes("qbr") || lower.includes("quality") && lower.includes("score") || lower.includes("jqim")) {
    return "jqim";
  }

  return null;
};

// Human-readable label for each completion source
export const completionSourceLabel: Record<CompletionSource, string> = {
  "manual": "Manual",
  "doc-curator": "Doc & Data Curator",
  "regrello": "Regrello",
  "bom-tool": "BOM Tool",
  "dfx-tool": "DFx Tool",
  "jqim": "JQIM",
};

// Placeholder due-date label for each task. Returns "T-7" or "T-14"
// (i.e. due 7 or 14 days before the milestone target / RTS date).
// Deterministic per task ID so labels and computed dates always agree.
export type TaskDueLabel = "T-7" | "T-14";
export const getTaskDueOffsetDays = (taskId: string): 7 | 14 => {
  let hash = 0;
  for (let i = 0; i < taskId.length; i++) {
    hash = (hash * 31 + taskId.charCodeAt(i)) | 0;
  }
  return Math.abs(hash) % 2 === 0 ? 7 : 14;
};
export const getTaskDueLabel = (taskId: string): TaskDueLabel => {
  return `T-${getTaskDueOffsetDays(taskId)}` as TaskDueLabel;
};

/**
 * Returns the dependency readiness state for a task:
 * - "none": no predecessors declared
 * - "ready": all predecessors completed
 * - "blocked": at least one predecessor not yet completed
 */
export type TaskDependencyState = "none" | "ready" | "blocked";
export const getTaskDependencyState = (
  task: Pick<ScheduleTask, "dependencies">,
  taskMap: Record<string, Pick<ScheduleTask, "status">>
): TaskDependencyState => {
  const deps = task.dependencies ?? [];
  if (deps.length === 0) return "none";
  const blocked = deps.some((id) => {
    const dep = taskMap[id];
    return !dep || dep.status !== "completed";
  });
  return blocked ? "blocked" : "ready";
};
/** Compute concrete due date = RTS/milestone target − T-minus offset. */
export const getTaskDueDate = (taskId: string, rtsDate: Date): Date => {
  const d = new Date(rtsDate);
  d.setDate(d.getDate() - getTaskDueOffsetDays(taskId));
  return d;
};
export const ownerDetails: Record<string, { name: string; email: string; function: string }> = {
  "GOE": { name: "Global Operations Engineering", email: "goe-team@company.com", function: "Operations Engineering" },
};
// Populate the cache used by getBackupOwner (defined above).
Object.assign(__ownerDetailsCache, ownerDetails);

// Phase exit dates for validation (simulated per-program).
// Pilot/Ramp split: Pilot ends ~55% into the legacy Pilot window; Ramp ends
// at the legacy Pilot exit date.
export const phaseExitDates: Record<string, Record<string, string>> = {
  "Laptop 1": {
    "Concept": "2025-12-15",
    "Define": "2026-03-15",
    "Plan": "2026-06-30",
    "Qual": "2026-09-15",
    "Pilot": "2026-10-08",
    "Ramp": "2026-11-03",
  },
  "Laptop 2": {
    "Concept": "2025-11-01",
    "Define": "2026-02-15",
    "Plan": "2026-05-30",
    "Qual": "2026-08-15",
    "Pilot": "2026-09-23",
    "Ramp": "2026-10-15",
  },
  "Laptop 3": {
    "Concept": "2025-10-15",
    "Define": "2026-01-30",
    "Plan": "2026-05-01",
    "Qual": "2026-08-01",
    "Pilot": "2026-09-08",
    "Ramp": "2026-10-01",
  },
  "Laptop 4": {
    "Concept": "2026-01-15",
    "Define": "2026-04-15",
    "Plan": "2026-07-30",
    "Qual": "2026-10-15",
    "Pilot": "2026-11-21",
    "Ramp": "2026-12-15",
  },
  "Laptop 5": {
    "Concept": "2026-02-01",
    "Define": "2026-05-01",
    "Plan": "2026-08-15",
    "Qual": "2026-11-01",
    "Pilot": "2026-12-15",
    "Ramp": "2027-01-15",
  },
  "Laptop 6": {
    "Concept": "2025-09-15",
    "Define": "2026-01-01",
    "Plan": "2026-04-15",
    "Qual": "2026-07-15",
    "Pilot": "2026-09-01",
    "Ramp": "2026-09-30",
  },
  "Laptop 7": {
    "Concept": "2026-03-01",
    "Define": "2026-06-01",
    "Plan": "2026-09-15",
    "Qual": "2026-12-01",
    "Pilot": "2027-01-20",
    "Ramp": "2027-02-15",
  },
};

// Module-level overrides map — populated by StatusFlagContext when a user
// confirms an auto-flag. Allows `computeRollupStatus` to escalate phase /
// platform colors without every caller threading overrides explicitly.
const __taskStatusOverrides: Map<string, TaskStatus> = new Map();
export const setTaskStatusOverrides = (entries: Iterable<[string, TaskStatus]>) => {
  __taskStatusOverrides.clear();
  for (const [k, v] of entries) __taskStatusOverrides.set(k, v);
};
export const getEffectiveTaskStatus = (task: { id?: string; status: TaskStatus }): TaskStatus => {
  if (task.id && __taskStatusOverrides.has(task.id)) return __taskStatusOverrides.get(task.id)!;
  return task.status;
};

// RYG rollup: compute milestone/phase/program status from tasks.
// Severity wins: any `late` → delayed (Red); else any `at-risk` → at-risk (Yellow).
export const computeRollupStatus = (tasks: { id?: string; status: TaskStatus }[]): PhaseStatus => {
  if (tasks.length === 0) return "not-started";
  const effective = tasks.map((t) => getEffectiveTaskStatus(t));
  if (effective.some((s) => s === "late")) return "delayed";
  if (effective.some((s) => s === "at-risk")) return "at-risk";
  if (effective.every((s) => s === "completed")) return "on-track";
  // Any mix of pending + completed (without late/at-risk) stays gray —
  // green requires 100% completion.
  return "not-started";
};

// Platform/program-level rollup: respects calendar progress.
// Severity wins (late→Red, at-risk→Yellow). Otherwise:
//   - all completed → On Track (Green)
//   - any work started OR calendar phase in progress → On Track (Green)
//   - nothing started AND no phase active yet → Not Started (Gray)
export const computePlatformRollupStatus = (
  tasks: { id?: string; status: TaskStatus }[],
  opts: { hasStartedPhase: boolean }
): PhaseStatus => {
  if (tasks.length === 0) return "not-started";
  const effective = tasks.map((t) => getEffectiveTaskStatus(t));
  if (effective.some((s) => s === "late")) return "delayed";
  if (effective.some((s) => s === "at-risk")) return "at-risk";
  if (effective.every((s) => s === "completed")) return "on-track";
  const anyStarted = effective.some((s) => s === "completed" || s === "on-track");
  if (anyStarted || opts.hasStartedPhase) return "on-track";
  return "not-started";
};

// Validate task due date does not exceed phase exit
export const validateTaskDueDate = (taskDueDate: string, phaseExitDate: string): boolean => {
  return new Date(taskDueDate) <= new Date(phaseExitDate);
};

// Check minimum duration warning
export const getDurationWarning = (taskName: string, durationDays: number): string | null => {
  const lower = taskName.toLowerCase();
  if (lower.includes("pilot") && durationDays < 14) return "Pilot tasks should be at least 2 weeks";
  if (lower.includes("audit") && durationDays < 7) return "Audit tasks should be at least 1 week";
  if (lower.includes("build") && durationDays < 5) return "Build tasks should be at least 5 days";
  return null;
};

// Compute RTS date from task completion data
// Each late task adds ~1 week of estimated delay to the baseline RTS
export const computeRTSDate = (phases: Phase[], baselineRTS: Date): { projected: Date; deltaWeeks: number; status: "on-track" | "at-risk" | "delayed" } => {
  const allTasks = phases.flatMap(p => p.milestones.flatMap(m => m.tasks));
  const lateTasks = allTasks.filter(t => t.status === "late");
  const deltaWeeks = lateTasks.length;
  const projected = new Date(baselineRTS);
  projected.setDate(projected.getDate() + deltaWeeks * 7);
  const status = deltaWeeks === 0 ? "on-track" : deltaWeeks <= 2 ? "at-risk" : "delayed";
  return { projected, deltaWeeks, status };
};

export interface Milestone {
  name: string;
  tasks: ScheduleTask[];
}

export interface Phase {
  name: string;
  color: string;
  status: PhaseStatus;
  milestones: Milestone[];
}

// Per-program schedule data derived from the NPI Task Sheet.
// NOTE: any task whose name maps to a CompletionSource (see getCompletionSource)
// is auto-completed by definition — its status is forced to "completed" by the
// normalizer below regardless of what's authored in the literal.
const _rawProgramSchedules: Record<string, Phase[]> = {
  "Laptop 1": [
    {
      name: "Concept", color: "bg-blue-500", status: "on-track",
      milestones: [
        { name: "Concept Phase documents uploaded (added)", tasks: [
          { id: "l1-0", name: "Upload Program Charter", status: "completed", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "l1-1", name: "Upload Feature Matrix/List (MVP/Backlog) / Roadmap", status: "completed", owner: "GOE", dataSources: ["Confluence", "PRD"], dependencies: ["l1-0"] },
          { id: "l1-2", name: "Confirm PRD / Marketing info has been ingested", status: "completed", owner: "GOE", dataSources: ["Confluence", "PRD"], dependencies: ["l1-0"] },
          { id: "l1-3", name: "Confirm EDD has been ingested", status: "completed", owner: "GOE", dataSources: ["Confluence", "PRD"], dependencies: ["l1-2"] },
          { id: "l1-4", name: "Confirm ARD has been ingested", status: "completed", owner: "GOE", dataSources: ["Confluence", "PRD"], dependencies: ["l1-2"] },
          { id: "l1-5", name: "Upload Innovation Story", status: "completed", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "l1-6", name: "Upload Lessons Learned", status: "completed", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "l1-7", name: "Upload Concept Phase exit Deck", status: "completed", owner: "GOE", dataSources: ["Confluence", "PRD"], dependencies: ["l1-5", "l1-6"] },
          { id: "l1-8", name: "Approve Concept Phase Exit deck", status: "completed", owner: "GOE", dataSources: ["Confluence", "PRD"], dependencies: ["l1-7"] },
        ]},
        { name: "Initial extended team formed", tasks: [
          { id: "l1-9", name: "Intiate Extended Team formation", status: "completed", owner: "GOE" },
        ]},
        { name: "Early end 2 end supply chain NUDD identified", tasks: [
          { id: "l1-10", name: "Conduct ODM supplier assessment prior to BA", status: "completed", owner: "GOE", dataSources: ["Memory Matrix", "Jira"], dependencies: ["l1-9"] },
          { id: "l1-11", name: "Gather CAPEX requirements for WW NPI", status: "completed", owner: "GOE", dataSources: ["Memory Matrix", "Jira"], dependencies: ["l1-9"] },
        ]},
        { name: "Early DFx NUDD identified", tasks: [
          { id: "l1-12", name: "Future technology Risk Assessment", status: "completed", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
          { id: "l1-13", name: "Conduct DFx assessment & Eng engagement", status: "completed", owner: "GOE", dataSources: ["Memory Matrix", "Jira"], dependencies: ["l1-12"] },
          { id: "l1-14", name: "Populate all NUDDS in NUDD tool", status: "completed", owner: "GOE", dataSources: ["Memory Matrix", "Jira"], dependencies: ["l1-12", "l1-13"] },
        ]},
        { name: "ODM improvement plan formulated (new ODM only)", tasks: [
          { id: "l1-15", name: "Formulate ODM Improvement plan (New ODMs)", status: "completed", owner: "GOE", dataSources: ["Jira", "Confluence"] },
        ]},
      ],
    },
    {
      name: "Define", color: "bg-emerald-500", status: "on-track",
      milestones: [
        { name: "Upload Define Phase documents", tasks: [
          { id: "l1-16", name: "Upload PG Documentation and approval of CPE", status: "completed", owner: "GOE", dataSources: ["Confluence", "PRD"] },
        ]},
        { name: "Extended team expanded & finalized", tasks: [
          { id: "l1-17", name: "Finalize GO Extended team", status: "completed", owner: "GOE" },
          { id: "l1-18", name: "Update extended team with full information", status: "completed", owner: "GOE" },
        ]},
        { name: "OE requirement locked", tasks: [
          { id: "l1-19", name: "Provide Prelim. schedule, fulfillment model, Supply Chain Resiliency Requirement and related documents.", status: "completed", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "l1-20", name: "Prepare Operations Engineering (OE) RFQ Package", status: "completed", owner: "GOE" },
          { id: "l1-21", name: "Finalize \"Define Phase Cost Bridge\" & commodity cost estimate", status: "completed", owner: "GOE" },
          { id: "l1-22", name: "Approve front end should have cost bridge", status: "completed", owner: "GOE" },
          { id: "l1-23", name: "Review FIN's cost projection", status: "completed", owner: "GOE" },
          { id: "l1-24", name: "Complete ODM RFQ package and pre-alignment", status: "completed", owner: "GOE", dataSources: ["Jira", "Confluence"] },
        ]},
        { name: "Mitigation plans formulated for early identified NUDDs", tasks: [
          { id: "l1-25", name: "Identify NUDDs and Initial Mitigation Plan", status: "completed", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
          { id: "l1-26", name: "Formulate ODM Improvement plan (New ODMs)", status: "completed", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
          { id: "l1-27", name: "Review and provide feedback on NUDDs", status: "completed", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
        ]},
        { name: "Additional NUDDs identified", tasks: [
          { id: "l1-28", name: "Update DFx Assessment", status: "completed", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
        ]},
        { name: "New test requirements identified", tasks: [
          { id: "l1-29", name: "Confirm draft ITM plan for the new program", status: "completed", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l1-30", name: "Upload Draft - New test Enablement Plan - A", status: "completed", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "l1-31", name: "Upload initial GTS/VM Inputs - A/C", status: "completed", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "l1-32", name: "Upload Location and Quantity - A/TI - P1", status: "completed", owner: "GOE", dataSources: ["Confluence", "PRD"] },
        ]},
        { name: "Relevant dependencies mapped (if applicable to Critical Transitions)", tasks: [
          { id: "l1-33", name: "Review product documentation (ex: EDD, ARD, FM), LLs, and predecessor platform data", status: "completed", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "l1-34", name: "Confirm alignment between FE team and GSM(?) on NUDD supply chain plan (critical for express lane)", status: "completed", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
          { id: "l1-35", name: "Approve front end IC & XLOB SSS list", status: "completed", owner: "GOE" },
        ]},
      ],
    },
    {
      name: "Plan", color: "bg-amber-500", status: "on-track",
      milestones: [
        { name: "Upload Plan Phase documents", tasks: [
          { id: "l1-36", name: "Send program kick-off communication with all attachments to extended teams", status: "completed", owner: "GOE", dataSources: ["Confluence", "PRD"], dependencies: ["l1-17"] },
          { id: "l1-37", name: "Upload Plan Phase Exit Deck and approval minutes", status: "completed", owner: "GOE", dataSources: ["Confluence", "PRD"], dependencies: ["l1-39"] },
          { id: "l1-38", name: "Define Plan Exit GOE Manager approval", status: "completed", owner: "GOE", dataSources: ["Confluence", "PRD"], dependencies: ["l1-37"] },
          { id: "l1-39", name: "Upload Plan Phase Exit Deck", status: "completed", owner: "GOE", dataSources: ["Confluence", "PRD"], dependencies: ["l1-8"] },
        ]},
        { name: "WW FRC & RTO volume ramp plan locked", tasks: [
          { id: "l1-40", name: "Release Contract Book 1.0, update DPE with MYPO, and verify volume estimation", status: "completed", owner: "GOE", dependencies: ["l1-21"] },
          { id: "l1-41", name: "Define TTM target and lock RTS/RTO schedule", status: "completed", owner: "GOE", dataSources: ["Jira", "Confluence"], dependencies: ["l1-40"] },
        ]},
        { name: "Manufacturing plan confirmed", tasks: [
          { id: "l1-42", name: "Validate costed BOM and CS workbook against RTS carcass cost", status: "completed", owner: "GOE", dataSources: ["SAP", "Jira"], dependencies: ["l1-40"] },
          { id: "l1-43", name: "Validate tooling plan and complete tooling risk go decision", status: "completed", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
          { id: "l1-44", name: "Confirm receipt of ME/XLOB PPE cost projections for BA POR", status: "completed", owner: "GOE", dataSources: ["Jira", "Confluence"], dependencies: ["l1-42"] },
          { id: "l1-45", name: "Define PPAP schedule per CT recommendations", status: "completed", owner: "GOE", dataSources: ["Jira", "Confluence"], dependencies: ["l1-43"] },
          { id: "l1-46", name: "Confirm critical part qualification schedule is included in platform backend schedule", status: "completed", owner: "GOE", dataSources: ["Jira", "Confluence"], dependencies: ["l1-45"] },
          { id: "l1-47", name: "Upload ODM RFQ design proposal", status: "completed", owner: "GOE", dataSources: ["Confluence", "PRD"], dependencies: ["l1-24"] },
          { id: "l1-48", name: "Input last quarter QBR score", status: "completed", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l1-49", name: "Develop build and manufacturing plan and lock FRC date", status: "on-track", owner: "GOE", dataSources: ["Jira", "Confluence"], dependencies: ["l1-41", "l1-42"] },
        ]},
        { name: "WW fulfillment plan confirmed", tasks: [
          { id: "l1-50", name: "Consolidate SSS and BCP plan with XLOB GCM and review compliance attributes", status: "on-track", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l1-51", name: "Review supply chain map and include it in PPE deck", status: "on-track", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "l1-52", name: "Lock WW fulfillment/logistics model and provide expedite cost estimates", status: "on-track", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l1-53", name: "Upload Supplier Chain Lead Time file", status: "on-track", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "l1-54", name: "Upload fulfillment model and evaluate gaps", status: "on-track", owner: "GOE", dataSources: ["Confluence", "PRD"] },
        ]},
        { name: "SQE MEDF Phase Gate #2 exited", tasks: [
          { id: "l1-55", name: "Record post-BA changes and link to Finance TCM document", status: "on-track", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "l1-56", name: "Upload Supplier Maturity Assessment for new ODM onboarding", status: "on-track", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "l1-57", name: "Validate ODM and sub-tier supplier audit schedules", status: "on-track", owner: "GOE", dataSources: ["Jira", "Confluence"] },
        ]},
        { name: "KPI aligned (yield, quality, FIR & IFIR goals)", tasks: [
          { id: "l1-58", name: "Validate yield rate, RFQ volume, and complexity matrix with CT and provide tooling plan to Sourcing GCM", status: "on-track", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l1-59", name: "Review attach rate by feature and include in complexity matrix", status: "on-track", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l1-60", name: "Share complexity matrix with CT and ensure compliance with ACL guidance", status: "on-track", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l1-61", name: "Calculate pre-BA score and confirm with CT", status: "on-track", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l1-62", name: "Confirm joint review and feedback on BA recommendation", status: "on-track", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l1-63", name: "Upload and submit GOE Pre-BA scorecard to CT", status: "on-track", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "l1-64", name: "Define KPIs for Yield, Quality, FIR, and IFIR", status: "on-track", owner: "GOE", dataSources: ["Jira", "Confluence"] },
        ]},
        { name: "DFx design plan locked", tasks: [
          { id: "l1-65", name: "Complete PDL assessment and confirm with CT", status: "on-track", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
          { id: "l1-66", name: "Update product documentation for Plan Phase exit", status: "on-track", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "l1-67", name: "Review and validate initial PH and BOM", status: "on-track", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
          { id: "l1-68", name: "Review engineering drawings and mockups and provide feedback", status: "on-track", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
          { id: "l1-69", name: "Continue DFx validation and update validation process", status: "on-track", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
          { id: "l1-70", name: "Review prototype with operations and document feedback", status: "on-track", owner: "GOE", dataSources: ["Confluence", "PRD"] },
        ]},
        { name: "NUDD mitigation plans locked", tasks: [
          { id: "l1-71", name: "Review and validate NUDD/DFMAA plan for risk mitigation", status: "pending", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
          { id: "l1-72", name: "Identify NUDDs, finalize mitigation plans, and define action plan", status: "pending", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
        ]},
        { name: "Development builds, Phase Gates, OLP schedule locked", tasks: [
          { id: "l1-73", name: "Upload overall operations schedule", status: "pending", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "l1-74", name: "Upload locked engineering schedule", status: "pending", owner: "GOE", dataSources: ["Confluence", "PRD"] },
        ]},
        { name: "Substitution matrix & restriction set up, order process assessed, IT tool set up", tasks: [
          { id: "l1-75", name: "Confirm order and platform data is maintained across IT tools", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l1-76", name: "Review restriction rules and factory configuration with GOE", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l1-77", name: "Complete test coverage analysis with ODM and Engineering", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
        ]},
      ],
    },
    {
      name: "Qual", color: "bg-orange-500", status: "not-started",
      milestones: [
        { name: "SQE MEDF Phase Gates #3,4,5,6 exited", tasks: [
          { id: "l1-78", name: "Complete PPAP on schedule for ME parts ramping", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l1-79", name: "Submit RTS approval request to VP of client procurement", status: "pending", owner: "GOE" },
          { id: "l1-80", name: "Complete ODM audit execution and reporting", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l1-81", name: "Complete sub-tier supplier audits for key components", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l1-82", name: "Submit GOE recommendation to exit Qual phase", status: "pending", owner: "GOE" },
          { id: "l1-83", name: "Complete CCC FM & OM ITM1/ITM2 readiness and execution", status: "pending", owner: "GOE" },
        ]},
        { name: "DVT1, DVT2 builds completed, goals met, issues captured, action plan in place", tasks: [
          { id: "l1-84", name: "Lock DVT2 OPS demand to confirmed volumes", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l1-85", name: "Lock Pilot CTO demand to confirmed volumes", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l1-86", name: "Kick off DVT2 ops build material preparation", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l1-87", name: "Confirm Golden config & demand are complete; material ETA on time", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l1-88", name: "Approve ODM DVT1 build entry", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l1-89", name: "Approve ODM DVT1 build exit", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l1-90", name: "Approve ODM DVT1.x build entry", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l1-91", name: "Approve ODM DVT1.x build exit", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l1-92", name: "Approve ODM DVT2 build entry", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l1-93", name: "Approve ODM DVT2 build exit", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l1-94", name: "Approve ODM DVT2.x build entry", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l1-95", name: "Approve ODM DVT2.x build exit", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l1-96", name: "Approve regression build entry readiness", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l1-97", name: "Complete regression build with issue disposition plan", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l1-98", name: "Complete PVB builds with systems and GAFPs validated", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l1-99", name: "Execute and monitor DVT2 OPS builds", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l1-100", name: "Conduct daily build review and track progress", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l1-101", name: "Complete post-build exit review", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l1-102", name: "Confirm build completion and output readiness", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l1-103", name: "Capture issues and ensure actions are in place", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
        ]},
        { name: "VH, H & M NUDDs closed", tasks: [
          { id: "l1-104", name: "Review and mitigate single/sole source risk", status: "pending", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
          { id: "l1-105", name: "Consolidate SSS and BCP plan with XLOB GCM", status: "pending", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
          { id: "l1-106", name: "Trigger event management if required", status: "pending", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
          { id: "l1-107", name: "Continue DFx validation and close findings in Jira", status: "pending", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
          { id: "l1-108", name: "Execute and close NUDD mitigation plans", status: "pending", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
        ]},
        { name: "Ops requirements on required design changes aligned", tasks: [
          { id: "l1-109", name: "Complete platform health check", status: "pending", owner: "GOE" },
          { id: "l1-110", name: "Review and trigger multiple tooling plan to execution", status: "pending", owner: "GOE" },
          { id: "l1-111", name: "Review Original Design Manufacturer tooling plan", status: "pending", owner: "GOE" },
          { id: "l1-112", name: "Complete Mid DD single tooling and SSS review", status: "pending", owner: "GOE" },
          { id: "l1-113", name: "Provide WWP BOM creation guidance", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l1-114", name: "Submit PH/X-rev mod and ensure D2 code readiness", status: "pending", owner: "GOE" },
          { id: "l1-115", name: "Release Panel ER and NPRR on schedule", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l1-116", name: "Review DFM status and confirm client approval", status: "pending", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
          { id: "l1-117", name: "Validate FGA BOM structure accuracy", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l1-118", name: "Generate and review platform matrix with extended team", status: "pending", owner: "GOE" },
          { id: "l1-119", name: "Confirm clean build results and closure of development changes", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l1-120", name: "Provide BOM attributes and packaging details", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
        ]},
        { name: "Manufacturing test coverage validated, design health checks completed", tasks: [
          { id: "l1-121", name: "Confirm L10 material Is complete", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l1-122", name: "Confirm DVT2 ops (SMT and L10) material is complete", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l1-123", name: "Confirm Pilot CTO material ETA is on schedule", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l1-124", name: "Prepare Pilot CTO MRA to readiness state", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l1-125", name: "Review ME pilot build safe launch report to confirm readiness", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l1-126", name: "Review first GDS report", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l1-127", name: "Validate test coverage and complete design health checks", status: "pending", owner: "GOE" },
          { id: "l1-128", name: "Ensure MRA readiness for qualification builds", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l1-129", name: "Complete RTB checklist before build start", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l1-130", name: "Review ODM build activity and exit status", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l1-131", name: "Confirm MRA materials availability before build", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l1-132", name: "Upload test and SW GAFPs before build", status: "pending", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "l1-133", name: "Ensure MRA readiness for pilot build", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
        ]},
        { name: "BOM mapping finalized", tasks: [
          { id: "l1-134", name: "Align CCI BOM structure for audit readiness", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l1-135", name: "Upload and maintain MOD list in NPI tool", status: "pending", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "l1-136", name: "Create and validate DVT2 MOD configurations", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l1-137", name: "Generate and validate qualification order configurations", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l1-138", name: "Generate and validate pilot order configurations", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l1-139", name: "Confirm SKU readiness in systems for PLS orders", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l1-140", name: "Submit ship order configuration into Jet", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
        ]},
        { name: "Substitution matrix & restriction set up, order process assessed, IT tool set up", tasks: [
          { id: "l1-141", name: "Lock RTS and PVT demand to confirmed volumes", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l1-142", name: "Shape RTS demand to align with supply constraints", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l1-143", name: "Trigger demand signal schedule for long L/T parts", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l1-144", name: "Determine supply control limit based on ACP commitment", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l1-145", name: "Confirm FHC MRP readiness", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l1-146", name: "Confirm ARC MRP readiness", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l1-147", name: "Load MRP with PVT demand", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l1-148", name: "Provide long lead time ARC list", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l1-149", name: "Prepare FHC MBP and PVT load to readiness state", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l1-150", name: "Confirm FHC readiness", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l1-151", name: "Confirm FGA readiness", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l1-152", name: "Confirm GCM parts cost is loaded correctly", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l1-153", name: "Prepare BCC MRA for GCM cost loading", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l1-154", name: "Confirm all PO cost is loaded for ST CTO build", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l1-155", name: "Confirm WW fulfillment/logistics mode", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l1-156", name: "Complete MPP review to confirm volume commitment is >= 75% of RFQ volume", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l1-157", name: "Confirm UPP loading attainment is 75% of platform BC", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l1-158", name: "Confirm packaging material is ready with L10 and BE & packaging team", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l1-159", name: "Upload OBE instructions for build execution", status: "pending", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "l1-160", name: "Download DVT2 build orders to factory", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l1-161", name: "Configure and validate GRR restriction rules", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l1-162", name: "Validate operations readiness for pilot execution", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l1-163", name: "Confirm operation plan execution status", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l1-164", name: "Review NPI production and supply chain performance reports", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l1-165", name: "Validate order fulfillment readiness for pilot", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l1-166", name: "Complete HWC setup for production readiness", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l1-167", name: "Review GRR list and restriction rules", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l1-168", name: "Download and acknowledge pilot/PLS orders by factories", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
        ]},
      ],
    },
    {
      name: "Pilot", color: "bg-teal-500", status: "not-started",
      milestones: [
        { name: "Supply & Demand readiness confirmed", tasks: [
          { id: "l1-169", name: "Define DSI goal and FGI position", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l1-170", name: "Confirm MRA materials available before build", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l1-171", name: "Confirm DSI goal and FGI position achieved", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l1-172", name: "Review RTS material supportability at T-1", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
        ]},
        { name: "Operational & Fulfillment readiness confirmed", tasks: [
          { id: "l1-173", name: "Confirm operations readiness for pilot execution", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l1-174", name: "Confirm order fulfillment readiness for pilot", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l1-175", name: "Confirm pilot order software and test readiness", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l1-176", name: "Generate pilot orders", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l1-177", name: "Send pilot orders to ODM/client factory for build", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l1-178", name: "Complete APJ FRC", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l1-179", name: "Complete EMEA FRC", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l1-180", name: "Complete DAO FRC", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l1-181", name: "Complete WW FRC", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l1-182", name: "Define and implement order process improvements", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l1-183", name: "Maintain and update tool rules and configurations", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
        ]},
        { name: "Issue Closure & Quality Stabilization", tasks: [
          { id: "l1-184", name: "Complete DFx activities and close all findings", status: "pending", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
          { id: "l1-185", name: "Close all NUDDs with mitigation completed", status: "pending", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
          { id: "l1-186", name: "Confirm issues and excursions are tracked and resolved", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l1-187", name: "Identify and reduce illegal orders with corrective actions", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l1-188", name: "Review and approve WWP deviation setup in Agile", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l1-189", name: "Monitor FPY and safe launch metrics against targets", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
        ]},
        { name: "Governance, Approval & Phase Closure", tasks: [
          { id: "l1-190", name: "Upload Develop Phase Exit documentation and approval", status: "pending", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "l1-191", name: "Upload Launch Phase Exit documentation and approval", status: "pending", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "l1-192", name: "Close development stage and document lessons learned", status: "pending", owner: "GOE", dataSources: ["Confluence", "PRD"] },
        ]},
        { name: "Build Execution & Completion", tasks: [
          { id: "l1-193", name: "Execute and monitor pilot build to completion", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l1-194", name: "Confirm PVT build is completed", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l1-195", name: "Confirm pilot completion from ODM and client factory", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l1-196", name: "Complete first block execution", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
        ]},
      ],
    },
  ],

  "Laptop 2": [
    {
      name: "Concept", color: "bg-blue-500", status: "on-track",
      milestones: [
        { name: "Concept Phase documents uploaded (added)", tasks: [
          { id: "l2-0", name: "Upload Program Charter", status: "completed", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "l2-1", name: "Upload Feature Matrix/List (MVP/Backlog) / Roadmap", status: "completed", owner: "GOE", dataSources: ["Confluence", "PRD"],
      dependencies: ["l2-0"],
    },
          { id: "l2-2", name: "Confirm PRD / Marketing info has been ingested", status: "completed", owner: "GOE", dataSources: ["Confluence", "PRD"],
      dependencies: ["l2-0"],
    },
          { id: "l2-3", name: "Confirm EDD has been ingested", status: "completed", owner: "GOE", dataSources: ["Confluence", "PRD"],
      dependencies: ["l2-2"],
    },
          { id: "l2-4", name: "Confirm ARD has been ingested", status: "completed", owner: "GOE", dataSources: ["Confluence", "PRD"],
      dependencies: ["l2-2"],
    },
          { id: "l2-5", name: "Upload Innovation Story", status: "completed", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "l2-6", name: "Upload Lessons Learned", status: "completed", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "l2-7", name: "Upload Concept Phase exit Deck", status: "completed", owner: "GOE", dataSources: ["Confluence", "PRD"],
      dependencies: ["l2-5", "l2-6"],
    },
          { id: "l2-8", name: "Approve Concept Phase Exit deck", status: "completed", owner: "GOE", dataSources: ["Confluence", "PRD"],
      dependencies: ["l2-7"],
    },
        ]},
        { name: "Initial extended team formed", tasks: [
          { id: "l2-9", name: "Intiate Extended Team formation", status: "completed", owner: "GOE" },
        ]},
        { name: "Early end 2 end supply chain NUDD identified", tasks: [
          { id: "l2-10", name: "Conduct ODM supplier assessment prior to BA", status: "completed", owner: "GOE", dataSources: ["Memory Matrix", "Jira"],
      dependencies: ["l2-9"],
    },
          { id: "l2-11", name: "Gather CAPEX requirements for WW NPI", status: "completed", owner: "GOE", dataSources: ["Memory Matrix", "Jira"],
      dependencies: ["l2-9"],
    },
        ]},
        { name: "Early DFx NUDD identified", tasks: [
          { id: "l2-12", name: "Future technology Risk Assessment", status: "completed", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
          { id: "l2-13", name: "Conduct DFx assessment & Eng engagement", status: "completed", owner: "GOE", dataSources: ["Memory Matrix", "Jira"],
      dependencies: ["l2-12"],
    },
          { id: "l2-14", name: "Populate all NUDDS in NUDD tool", status: "completed", owner: "GOE", dataSources: ["Memory Matrix", "Jira"],
      dependencies: ["l2-12", "l2-13"],
    },
        ]},
        { name: "ODM improvement plan formulated (new ODM only)", tasks: [
          { id: "l2-15", name: "Formulate ODM Improvement plan (New ODMs)", status: "completed", owner: "GOE", dataSources: ["Jira", "Confluence"] },
        ]},
      ],
    },
    {
      name: "Define", color: "bg-emerald-500", status: "on-track",
      milestones: [
        { name: "Upload Define Phase documents", tasks: [
          { id: "l2-16", name: "Upload PG Documentation and approval of CPE", status: "completed", owner: "GOE", dataSources: ["Confluence", "PRD"] },
        ]},
        { name: "Extended team expanded & finalized", tasks: [
          { id: "l2-17", name: "Finalize GO Extended team", status: "completed", owner: "GOE" },
          { id: "l2-18", name: "Update extended team with full information", status: "completed", owner: "GOE" },
        ]},
        { name: "OE requirement locked", tasks: [
          { id: "l2-19", name: "Provide Prelim. schedule, fulfillment model, Supply Chain Resiliency Requirement and related documents.", status: "completed", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "l2-20", name: "Prepare Operations Engineering (OE) RFQ Package", status: "completed", owner: "GOE" },
          { id: "l2-21", name: "Finalize \"Define Phase Cost Bridge\" & commodity cost estimate", status: "completed", owner: "GOE" },
          { id: "l2-22", name: "Approve front end should have cost bridge", status: "completed", owner: "GOE" },
          { id: "l2-23", name: "Review FIN's cost projection", status: "completed", owner: "GOE" },
          { id: "l2-24", name: "Complete ODM RFQ package and pre-alignment", status: "completed", owner: "GOE", dataSources: ["Jira", "Confluence"] },
        ]},
        { name: "Mitigation plans formulated for early identified NUDDs", tasks: [
          { id: "l2-25", name: "Identify NUDDs and Initial Mitigation Plan", status: "completed", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
          { id: "l2-26", name: "Formulate ODM Improvement plan (New ODMs)", status: "completed", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
          { id: "l2-27", name: "Review and provide feedback on NUDDs", status: "completed", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
        ]},
        { name: "Additional NUDDs identified", tasks: [
          { id: "l2-28", name: "Update DFx Assessment", status: "completed", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
        ]},
        { name: "New test requirements identified", tasks: [
          { id: "l2-29", name: "Confirm draft ITM plan for the new program", status: "completed", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l2-30", name: "Upload Draft - New test Enablement Plan - A", status: "completed", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "l2-31", name: "Upload initial GTS/VM Inputs - A/C", status: "completed", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "l2-32", name: "Upload Location and Quantity - A/TI - P1", status: "completed", owner: "GOE", dataSources: ["Confluence", "PRD"] },
        ]},
        { name: "Relevant dependencies mapped (if applicable to Critical Transitions)", tasks: [
          { id: "l2-33", name: "Review product documentation (ex: EDD, ARD, FM), LLs, and predecessor platform data", status: "completed", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "l2-34", name: "Confirm alignment between FE team and GSM(?) on NUDD supply chain plan (critical for express lane)", status: "completed", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
          { id: "l2-35", name: "Approve front end IC & XLOB SSS list", status: "completed", owner: "GOE" },
        ]},
      ],
    },
    {
      name: "Plan", color: "bg-amber-500", status: "on-track",
      milestones: [
        { name: "Upload Plan Phase documents", tasks: [
          { id: "l2-36", name: "Send program kick-off communication with all attachments to extended teams", status: "completed", owner: "GOE", dataSources: ["Confluence", "PRD"],
      dependencies: ["l2-17"],
    },
          { id: "l2-37", name: "Upload Plan Phase Exit Deck and approval minutes", status: "completed", owner: "GOE", dataSources: ["Confluence", "PRD"],
      dependencies: ["l2-39"],
    },
          { id: "l2-38", name: "Define Plan Exit GOE Manager approval", status: "completed", owner: "GOE", dataSources: ["Confluence", "PRD"],
      dependencies: ["l2-37"],
    },
          { id: "l2-39", name: "Upload Plan Phase Exit Deck", status: "completed", owner: "GOE", dataSources: ["Confluence", "PRD"],
      dependencies: ["l2-8"],
    },
        ]},
        { name: "WW FRC & RTO volume ramp plan locked", tasks: [
          { id: "l2-40", name: "Release Contract Book 1.0, update DPE with MYPO, and verify volume estimation", status: "completed", owner: "GOE",
      dependencies: ["l2-21"],
    },
          { id: "l2-41", name: "Define TTM target and lock RTS/RTO schedule", status: "completed", owner: "GOE", dataSources: ["Jira", "Confluence"],
      dependencies: ["l2-40"],
    },
        ]},
        { name: "Manufacturing plan confirmed", tasks: [
          { id: "l2-42", name: "Validate costed BOM and CS workbook against RTS carcass cost", status: "completed", owner: "GOE", dataSources: ["SAP", "Jira"],
      dependencies: ["l2-40"],
    },
          { id: "l2-43", name: "Validate tooling plan and complete tooling risk go decision", status: "completed", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
          { id: "l2-44", name: "Confirm receipt of ME/XLOB PPE cost projections for BA POR", status: "completed", owner: "GOE", dataSources: ["Jira", "Confluence"],
      dependencies: ["l2-42"],
    },
          { id: "l2-45", name: "Define PPAP schedule per CT recommendations", status: "completed", owner: "GOE", dataSources: ["Jira", "Confluence"],
      dependencies: ["l2-43"],
    },
          { id: "l2-46", name: "Confirm critical part qualification schedule is included in platform backend schedule", status: "completed", owner: "GOE", dataSources: ["Jira", "Confluence"],
      dependencies: ["l2-45"],
    },
          { id: "l2-47", name: "Upload ODM RFQ design proposal", status: "completed", owner: "GOE", dataSources: ["Confluence", "PRD"],
      dependencies: ["l2-24"],
    },
          { id: "l2-48", name: "Input last quarter QBR score", status: "completed", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l2-49", name: "Develop build and manufacturing plan and lock FRC date", status: "on-track", owner: "GOE", dataSources: ["Jira", "Confluence"],
      dependencies: ["l2-41", "l2-42"],
    },
        ]},
        { name: "WW fulfillment plan confirmed", tasks: [
          { id: "l2-50", name: "Consolidate SSS and BCP plan with XLOB GCM and review compliance attributes", status: "on-track", owner: "GOE", dataSources: ["Jira", "Confluence"],
      dependencies: ["l2-49"],
    },
          { id: "l2-51", name: "Review supply chain map and include it in PPE deck", status: "on-track", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "l2-52", name: "Lock WW fulfillment/logistics model and provide expedite cost estimates", status: "on-track", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l2-53", name: "Upload Supplier Chain Lead Time file", status: "on-track", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "l2-54", name: "Upload fulfillment model and evaluate gaps", status: "on-track", owner: "GOE", dataSources: ["Confluence", "PRD"] },
        ]},
        { name: "SQE MEDF Phase Gate #2 exited", tasks: [
          { id: "l2-55", name: "Record post-BA changes and link to Finance TCM document", status: "on-track", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "l2-56", name: "Upload Supplier Maturity Assessment for new ODM onboarding", status: "on-track", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "l2-57", name: "Validate ODM and sub-tier supplier audit schedules", status: "on-track", owner: "GOE", dataSources: ["Jira", "Confluence"] },
        ]},
        { name: "KPI aligned (yield, quality, FIR & IFIR goals)", tasks: [
          { id: "l2-58", name: "Validate yield rate, RFQ volume, and complexity matrix with CT and provide tooling plan to Sourcing GCM", status: "on-track", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l2-59", name: "Review attach rate by feature and include in complexity matrix", status: "on-track", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l2-60", name: "Share complexity matrix with CT and ensure compliance with ACL guidance", status: "on-track", owner: "GOE", dataSources: ["Jira", "Confluence"],
      dependencies: ["l2-49", "l2-47"],
    },
          { id: "l2-61", name: "Calculate pre-BA score and confirm with CT", status: "on-track", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l2-62", name: "Confirm joint review and feedback on BA recommendation", status: "on-track", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l2-63", name: "Upload and submit GOE Pre-BA scorecard to CT", status: "on-track", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "l2-64", name: "Define KPIs for Yield, Quality, FIR, and IFIR", status: "on-track", owner: "GOE", dataSources: ["Jira", "Confluence"] },
        ]},
        { name: "DFx design plan locked", tasks: [
          { id: "l2-65", name: "Complete PDL assessment and confirm with CT", status: "on-track", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
          { id: "l2-66", name: "Update product documentation for Plan Phase exit", status: "on-track", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "l2-67", name: "Review and validate initial PH and BOM", status: "on-track", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
          { id: "l2-68", name: "Review engineering drawings and mockups and provide feedback", status: "on-track", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
          { id: "l2-69", name: "Continue DFx validation and update validation process", status: "on-track", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
          { id: "l2-70", name: "Review prototype with operations and document feedback", status: "on-track", owner: "GOE", dataSources: ["Confluence", "PRD"] },
        ]},
        { name: "NUDD mitigation plans locked", tasks: [
          { id: "l2-71", name: "Review and validate NUDD/DFMAA plan for risk mitigation", status: "pending", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
          { id: "l2-72", name: "Identify NUDDs, finalize mitigation plans, and define action plan", status: "pending", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
        ]},
        { name: "Development builds, Phase Gates, OLP schedule locked", tasks: [
          { id: "l2-73", name: "Upload overall operations schedule", status: "pending", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "l2-74", name: "Upload locked engineering schedule", status: "pending", owner: "GOE", dataSources: ["Confluence", "PRD"] },
        ]},
        { name: "Substitution matrix & restriction set up, order process assessed, IT tool set up", tasks: [
          { id: "l2-75", name: "Confirm order and platform data is maintained across IT tools", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l2-76", name: "Review restriction rules and factory configuration with GOE", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l2-77", name: "Complete test coverage analysis with ODM and Engineering", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
        ]},
      ],
    },
    {
      name: "Qual", color: "bg-orange-500", status: "not-started",
      milestones: [
        { name: "SQE MEDF Phase Gates #3,4,5,6 exited", tasks: [
          { id: "l2-78", name: "Complete PPAP on schedule for ME parts ramping", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l2-79", name: "Submit RTS approval request to VP of client procurement", status: "pending", owner: "GOE" },
          { id: "l2-80", name: "Complete ODM audit execution and reporting", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"],
      dependencies: ["l2-60"],
    },
          { id: "l2-81", name: "Complete sub-tier supplier audits for key components", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l2-82", name: "Submit GOE recommendation to exit Qual phase", status: "pending", owner: "GOE" },
          { id: "l2-83", name: "Complete CCC FM & OM ITM1/ITM2 readiness and execution", status: "pending", owner: "GOE" },
        ]},
        { name: "DVT1, DVT2 builds completed, goals met, issues captured, action plan in place", tasks: [
          { id: "l2-84", name: "Lock DVT2 OPS demand to confirmed volumes", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l2-85", name: "Lock Pilot CTO demand to confirmed volumes", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l2-86", name: "Kick off DVT2 ops build material preparation", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l2-87", name: "Confirm Golden config & demand are complete; material ETA on time", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l2-88", name: "Approve ODM DVT1 build entry", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l2-89", name: "Approve ODM DVT1 build exit", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l2-90", name: "Approve ODM DVT1.x build entry", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l2-91", name: "Approve ODM DVT1.x build exit", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l2-92", name: "Approve ODM DVT2 build entry", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l2-93", name: "Approve ODM DVT2 build exit", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l2-94", name: "Approve ODM DVT2.x build entry", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l2-95", name: "Approve ODM DVT2.x build exit", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l2-96", name: "Approve regression build entry readiness", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l2-97", name: "Complete regression build with issue disposition plan", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l2-98", name: "Complete PVB builds with systems and GAFPs validated", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l2-99", name: "Execute and monitor DVT2 OPS builds", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l2-100", name: "Conduct daily build review and track progress", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l2-101", name: "Complete post-build exit review", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l2-102", name: "Confirm build completion and output readiness", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l2-103", name: "Capture issues and ensure actions are in place", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
        ]},
        { name: "VH, H & M NUDDs closed", tasks: [
          { id: "l2-104", name: "Review and mitigate single/sole source risk", status: "pending", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
          { id: "l2-105", name: "Consolidate SSS and BCP plan with XLOB GCM", status: "pending", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
          { id: "l2-106", name: "Trigger event management if required", status: "pending", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
          { id: "l2-107", name: "Continue DFx validation and close findings in Jira", status: "pending", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
          { id: "l2-108", name: "Execute and close NUDD mitigation plans", status: "pending", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
        ]},
        { name: "Ops requirements on required design changes aligned", tasks: [
          { id: "l2-109", name: "Complete platform health check", status: "pending", owner: "GOE" },
          { id: "l2-110", name: "Review and trigger multiple tooling plan to execution", status: "pending", owner: "GOE" },
          { id: "l2-111", name: "Review Original Design Manufacturer tooling plan", status: "pending", owner: "GOE" },
          { id: "l2-112", name: "Complete Mid DD single tooling and SSS review", status: "pending", owner: "GOE" },
          { id: "l2-113", name: "Provide WWP BOM creation guidance", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l2-114", name: "Submit PH/X-rev mod and ensure D2 code readiness", status: "pending", owner: "GOE" },
          { id: "l2-115", name: "Release Panel ER and NPRR on schedule", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l2-116", name: "Review DFM status and confirm client approval", status: "pending", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
          { id: "l2-117", name: "Validate FGA BOM structure accuracy", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l2-118", name: "Generate and review platform matrix with extended team", status: "pending", owner: "GOE" },
          { id: "l2-119", name: "Confirm clean build results and closure of development changes", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l2-120", name: "Provide BOM attributes and packaging details", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
        ]},
        { name: "Manufacturing test coverage validated, design health checks completed", tasks: [
          { id: "l2-121", name: "Confirm L10 material Is complete", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l2-122", name: "Confirm DVT2 ops (SMT and L10) material is complete", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l2-123", name: "Confirm Pilot CTO material ETA is on schedule", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l2-124", name: "Prepare Pilot CTO MRA to readiness state", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l2-125", name: "Review ME pilot build safe launch report to confirm readiness", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l2-126", name: "Review first GDS report", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l2-127", name: "Validate test coverage and complete design health checks", status: "pending", owner: "GOE" },
          { id: "l2-128", name: "Ensure MRA readiness for qualification builds", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l2-129", name: "Complete RTB checklist before build start", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l2-130", name: "Review ODM build activity and exit status", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l2-131", name: "Confirm MRA materials availability before build", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l2-132", name: "Upload test and SW GAFPs before build", status: "pending", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "l2-133", name: "Ensure MRA readiness for pilot build", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
        ]},
        { name: "BOM mapping finalized", tasks: [
          { id: "l2-134", name: "Align CCI BOM structure for audit readiness", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l2-135", name: "Upload and maintain MOD list in NPI tool", status: "pending", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "l2-136", name: "Create and validate DVT2 MOD configurations", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l2-137", name: "Generate and validate qualification order configurations", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l2-138", name: "Generate and validate pilot order configurations", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l2-139", name: "Confirm SKU readiness in systems for PLS orders", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l2-140", name: "Submit ship order configuration into Jet", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
        ]},
        { name: "Substitution matrix & restriction set up, order process assessed, IT tool set up", tasks: [
          { id: "l2-141", name: "Lock RTS and PVT demand to confirmed volumes", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l2-142", name: "Shape RTS demand to align with supply constraints", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l2-143", name: "Trigger demand signal schedule for long L/T parts", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l2-144", name: "Determine supply control limit based on ACP commitment", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l2-145", name: "Confirm FHC MRP readiness", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l2-146", name: "Confirm ARC MRP readiness", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l2-147", name: "Load MRP with PVT demand", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l2-148", name: "Provide long lead time ARC list", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l2-149", name: "Prepare FHC MBP and PVT load to readiness state", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l2-150", name: "Confirm FHC readiness", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l2-151", name: "Confirm FGA readiness", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l2-152", name: "Confirm GCM parts cost is loaded correctly", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l2-153", name: "Prepare BCC MRA for GCM cost loading", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l2-154", name: "Confirm all PO cost is loaded for ST CTO build", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l2-155", name: "Confirm WW fulfillment/logistics mode", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l2-156", name: "Complete MPP review to confirm volume commitment is >= 75% of RFQ volume", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l2-157", name: "Confirm UPP loading attainment is 75% of platform BC", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l2-158", name: "Confirm packaging material is ready with L10 and BE & packaging team", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l2-159", name: "Upload OBE instructions for build execution", status: "pending", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "l2-160", name: "Download DVT2 build orders to factory", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l2-161", name: "Configure and validate GRR restriction rules", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l2-162", name: "Validate operations readiness for pilot execution", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l2-163", name: "Confirm operation plan execution status", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l2-164", name: "Review NPI production and supply chain performance reports", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l2-165", name: "Validate order fulfillment readiness for pilot", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l2-166", name: "Complete HWC setup for production readiness", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l2-167", name: "Review GRR list and restriction rules", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l2-168", name: "Download and acknowledge pilot/PLS orders by factories", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
        ]},
      ],
    },
    {
      name: "Pilot", color: "bg-teal-500", status: "not-started",
      milestones: [
        { name: "Supply & Demand readiness confirmed", tasks: [
          { id: "l2-169", name: "Define DSI goal and FGI position", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l2-170", name: "Confirm MRA materials available before build", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l2-171", name: "Confirm DSI goal and FGI position achieved", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l2-172", name: "Review RTS material supportability at T-1", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
        ]},
        { name: "Operational & Fulfillment readiness confirmed", tasks: [
          { id: "l2-173", name: "Confirm operations readiness for pilot execution", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l2-174", name: "Confirm order fulfillment readiness for pilot", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l2-175", name: "Confirm pilot order software and test readiness", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l2-176", name: "Generate pilot orders", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l2-177", name: "Send pilot orders to ODM/client factory for build", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l2-178", name: "Complete APJ FRC", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l2-179", name: "Complete EMEA FRC", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l2-180", name: "Complete DAO FRC", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l2-181", name: "Complete WW FRC", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l2-182", name: "Define and implement order process improvements", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l2-183", name: "Maintain and update tool rules and configurations", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
        ]},
        { name: "Issue Closure & Quality Stabilization", tasks: [
          { id: "l2-184", name: "Complete DFx activities and close all findings", status: "pending", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
          { id: "l2-185", name: "Close all NUDDs with mitigation completed", status: "pending", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
          { id: "l2-186", name: "Confirm issues and excursions are tracked and resolved", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l2-187", name: "Identify and reduce illegal orders with corrective actions", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l2-188", name: "Review and approve WWP deviation setup in Agile", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l2-189", name: "Monitor FPY and safe launch metrics against targets", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
        ]},
        { name: "Governance, Approval & Phase Closure", tasks: [
          { id: "l2-190", name: "Upload Develop Phase Exit documentation and approval", status: "pending", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "l2-191", name: "Upload Launch Phase Exit documentation and approval", status: "pending", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "l2-192", name: "Close development stage and document lessons learned", status: "pending", owner: "GOE", dataSources: ["Confluence", "PRD"] },
        ]},
        { name: "Build Execution & Completion", tasks: [
          { id: "l2-193", name: "Execute and monitor pilot build to completion", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l2-194", name: "Confirm PVT build is completed", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l2-195", name: "Confirm pilot completion from ODM and client factory", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l2-196", name: "Complete first block execution", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
        ]},
      ],
    },
  ],

  "Laptop 3": [
    {
      name: "Concept", color: "bg-blue-500", status: "on-track",
      milestones: [
        { name: "Concept Phase documents uploaded (added)", tasks: [
          { id: "l3-0", name: "Upload Program Charter", status: "completed", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "l3-1", name: "Upload Feature Matrix/List (MVP/Backlog) / Roadmap", status: "completed", owner: "GOE", dataSources: ["Confluence", "PRD"],
      dependencies: ["l3-0"],
    },
          { id: "l3-2", name: "Confirm PRD / Marketing info has been ingested", status: "completed", owner: "GOE", dataSources: ["Confluence", "PRD"],
      dependencies: ["l3-0"],
    },
          { id: "l3-3", name: "Confirm EDD has been ingested", status: "completed", owner: "GOE", dataSources: ["Confluence", "PRD"],
      dependencies: ["l3-2"],
    },
          { id: "l3-4", name: "Confirm ARD has been ingested", status: "completed", owner: "GOE", dataSources: ["Confluence", "PRD"],
      dependencies: ["l3-2"],
    },
          { id: "l3-5", name: "Upload Innovation Story", status: "completed", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "l3-6", name: "Upload Lessons Learned", status: "completed", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "l3-7", name: "Upload Concept Phase exit Deck", status: "completed", owner: "GOE", dataSources: ["Confluence", "PRD"],
      dependencies: ["l3-5", "l3-6"],
    },
          { id: "l3-8", name: "Approve Concept Phase Exit deck", status: "completed", owner: "GOE", dataSources: ["Confluence", "PRD"],
      dependencies: ["l3-7"],
    },
        ]},
        { name: "Initial extended team formed", tasks: [
          { id: "l3-9", name: "Intiate Extended Team formation", status: "completed", owner: "GOE" },
        ]},
        { name: "Early end 2 end supply chain NUDD identified", tasks: [
          { id: "l3-10", name: "Conduct ODM supplier assessment prior to BA", status: "completed", owner: "GOE", dataSources: ["Memory Matrix", "Jira"],
      dependencies: ["l3-9"],
    },
          { id: "l3-11", name: "Gather CAPEX requirements for WW NPI", status: "completed", owner: "GOE", dataSources: ["Memory Matrix", "Jira"],
      dependencies: ["l3-9"],
    },
        ]},
        { name: "Early DFx NUDD identified", tasks: [
          { id: "l3-12", name: "Future technology Risk Assessment", status: "completed", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
          { id: "l3-13", name: "Conduct DFx assessment & Eng engagement", status: "completed", owner: "GOE", dataSources: ["Memory Matrix", "Jira"],
      dependencies: ["l3-12"],
    },
          { id: "l3-14", name: "Populate all NUDDS in NUDD tool", status: "completed", owner: "GOE", dataSources: ["Memory Matrix", "Jira"],
      dependencies: ["l3-12", "l3-13"],
    },
        ]},
        { name: "ODM improvement plan formulated (new ODM only)", tasks: [
          { id: "l3-15", name: "Formulate ODM Improvement plan (New ODMs)", status: "completed", owner: "GOE", dataSources: ["Jira", "Confluence"] },
        ]},
      ],
    },
    {
      name: "Define", color: "bg-emerald-500", status: "on-track",
      milestones: [
        { name: "Upload Define Phase documents", tasks: [
          { id: "l3-16", name: "Upload PG Documentation and approval of CPE", status: "completed", owner: "GOE", dataSources: ["Confluence", "PRD"] },
        ]},
        { name: "Extended team expanded & finalized", tasks: [
          { id: "l3-17", name: "Finalize GO Extended team", status: "completed", owner: "GOE" },
          { id: "l3-18", name: "Update extended team with full information", status: "completed", owner: "GOE" },
        ]},
        { name: "OE requirement locked", tasks: [
          { id: "l3-19", name: "Provide Prelim. schedule, fulfillment model, Supply Chain Resiliency Requirement and related documents.", status: "completed", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "l3-20", name: "Prepare Operations Engineering (OE) RFQ Package", status: "completed", owner: "GOE" },
          { id: "l3-21", name: "Finalize \"Define Phase Cost Bridge\" & commodity cost estimate", status: "completed", owner: "GOE" },
          { id: "l3-22", name: "Approve front end should have cost bridge", status: "completed", owner: "GOE" },
          { id: "l3-23", name: "Review FIN's cost projection", status: "completed", owner: "GOE" },
          { id: "l3-24", name: "Complete ODM RFQ package and pre-alignment", status: "completed", owner: "GOE", dataSources: ["Jira", "Confluence"] },
        ]},
        { name: "Mitigation plans formulated for early identified NUDDs", tasks: [
          { id: "l3-25", name: "Identify NUDDs and Initial Mitigation Plan", status: "completed", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
          { id: "l3-26", name: "Formulate ODM Improvement plan (New ODMs)", status: "completed", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
          { id: "l3-27", name: "Review and provide feedback on NUDDs", status: "completed", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
        ]},
        { name: "Additional NUDDs identified", tasks: [
          { id: "l3-28", name: "Update DFx Assessment", status: "completed", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
        ]},
        { name: "New test requirements identified", tasks: [
          { id: "l3-29", name: "Confirm draft ITM plan for the new program", status: "completed", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l3-30", name: "Upload Draft - New test Enablement Plan - A", status: "completed", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "l3-31", name: "Upload initial GTS/VM Inputs - A/C", status: "completed", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "l3-32", name: "Upload Location and Quantity - A/TI - P1", status: "completed", owner: "GOE", dataSources: ["Confluence", "PRD"] },
        ]},
        { name: "Relevant dependencies mapped (if applicable to Critical Transitions)", tasks: [
          { id: "l3-33", name: "Review product documentation (ex: EDD, ARD, FM), LLs, and predecessor platform data", status: "completed", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "l3-34", name: "Confirm alignment between FE team and GSM(?) on NUDD supply chain plan (critical for express lane)", status: "completed", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
          { id: "l3-35", name: "Approve front end IC & XLOB SSS list", status: "completed", owner: "GOE" },
        ]},
      ],
    },
    {
      name: "Plan", color: "bg-amber-500", status: "at-risk",
      milestones: [
        { name: "Upload Plan Phase documents", tasks: [
          { id: "l3-36", name: "Send program kick-off communication with all attachments to extended teams", status: "completed", owner: "GOE", dataSources: ["Confluence", "PRD"],
      dependencies: ["l3-17"],
    },
          { id: "l3-37", name: "Upload Plan Phase Exit Deck and approval minutes", status: "completed", owner: "GOE", dataSources: ["Confluence", "PRD"],
      dependencies: ["l3-39"],
    },
          { id: "l3-38", name: "Define Plan Exit GOE Manager approval", status: "completed", owner: "GOE", dataSources: ["Confluence", "PRD"],
      dependencies: ["l3-37"],
    },
          { id: "l3-39", name: "Upload Plan Phase Exit Deck", status: "completed", owner: "GOE", dataSources: ["Confluence", "PRD"],
      dependencies: ["l3-8"],
    },
        ]},
        { name: "WW FRC & RTO volume ramp plan locked", tasks: [
          { id: "l3-40", name: "Release Contract Book 1.0, update DPE with MYPO, and verify volume estimation", status: "completed", owner: "GOE",
      dependencies: ["l3-21"],
    },
          { id: "l3-41", name: "Define TTM target and lock RTS/RTO schedule", status: "completed", owner: "GOE", dataSources: ["Jira", "Confluence"],
      dependencies: ["l3-40"],
    },
        ]},
        { name: "Manufacturing plan confirmed", tasks: [
          { id: "l3-42", name: "Validate costed BOM and CS workbook against RTS carcass cost", status: "completed", owner: "GOE", dataSources: ["SAP", "Jira"],
      dependencies: ["l3-40"],
    },
          { id: "l3-43", name: "Validate tooling plan and complete tooling risk go decision", status: "completed", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
          { id: "l3-44", name: "Confirm receipt of ME/XLOB PPE cost projections for BA POR", status: "completed", owner: "GOE", dataSources: ["Jira", "Confluence"],
      dependencies: ["l3-42"],
    },
          { id: "l3-45", name: "Define PPAP schedule per CT recommendations", status: "completed", owner: "GOE", dataSources: ["Jira", "Confluence"],
      dependencies: ["l3-43"],
    },
          { id: "l3-46", name: "Confirm critical part qualification schedule is included in platform backend schedule", status: "completed", owner: "GOE", dataSources: ["Jira", "Confluence"],
      dependencies: ["l3-45"],
    },
          { id: "l3-47", name: "Upload ODM RFQ design proposal", status: "completed", owner: "GOE", dataSources: ["Confluence", "PRD"],
      dependencies: ["l3-24"],
    },
          { id: "l3-48", name: "Input last quarter QBR score", status: "completed", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l3-49", name: "Develop build and manufacturing plan and lock FRC date", status: "on-track", owner: "GOE", dataSources: ["Jira", "Confluence"],
      dependencies: ["l3-41", "l3-42"],
    },
        ]},
        { name: "WW fulfillment plan confirmed", tasks: [
          { id: "l3-50", name: "Consolidate SSS and BCP plan with XLOB GCM and review compliance attributes", status: "on-track", owner: "GOE", dataSources: ["Jira", "Confluence"],
      dependencies: ["l3-49"],
    },
          { id: "l3-51", name: "Review supply chain map and include it in PPE deck", status: "on-track", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "l3-52", name: "Lock WW fulfillment/logistics model and provide expedite cost estimates", status: "on-track", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l3-53", name: "Upload Supplier Chain Lead Time file", status: "on-track", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "l3-54", name: "Upload fulfillment model and evaluate gaps", status: "on-track", owner: "GOE", dataSources: ["Confluence", "PRD"] },
        ]},
        { name: "SQE MEDF Phase Gate #2 exited", tasks: [
          { id: "l3-55", name: "Record post-BA changes and link to Finance TCM document", status: "on-track", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "l3-56", name: "Upload Supplier Maturity Assessment for new ODM onboarding", status: "on-track", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "l3-57", name: "Validate ODM and sub-tier supplier audit schedules", status: "on-track", owner: "GOE", dataSources: ["Jira", "Confluence"] },
        ]},
        { name: "KPI aligned (yield, quality, FIR & IFIR goals)", tasks: [
          { id: "l3-58", name: "Validate yield rate, RFQ volume, and complexity matrix with CT and provide tooling plan to Sourcing GCM", status: "on-track", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l3-59", name: "Review attach rate by feature and include in complexity matrix", status: "on-track", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l3-60", name: "Share complexity matrix with CT and ensure compliance with ACL guidance", status: "on-track", owner: "GOE", dataSources: ["Jira", "Confluence"],
      dependencies: ["l3-49", "l3-47"],
    },
          { id: "l3-61", name: "Calculate pre-BA score and confirm with CT", status: "on-track", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l3-62", name: "Confirm joint review and feedback on BA recommendation", status: "on-track", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l3-63", name: "Upload and submit GOE Pre-BA scorecard to CT", status: "at-risk", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "l3-64", name: "Define KPIs for Yield, Quality, FIR, and IFIR", status: "at-risk", owner: "GOE", dataSources: ["Jira", "Confluence"] },
        ]},
        { name: "DFx design plan locked", tasks: [
          { id: "l3-65", name: "Complete PDL assessment and confirm with CT", status: "at-risk", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
          { id: "l3-66", name: "Update product documentation for Plan Phase exit", status: "at-risk", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "l3-67", name: "Review and validate initial PH and BOM", status: "at-risk", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
          { id: "l3-68", name: "Review engineering drawings and mockups and provide feedback", status: "at-risk", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
          { id: "l3-69", name: "Continue DFx validation and update validation process", status: "at-risk", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
          { id: "l3-70", name: "Review prototype with operations and document feedback", status: "at-risk", owner: "GOE", dataSources: ["Confluence", "PRD"] },
        ]},
        { name: "NUDD mitigation plans locked", tasks: [
          { id: "l3-71", name: "Review and validate NUDD/DFMAA plan for risk mitigation", status: "on-track", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
          { id: "l3-72", name: "Identify NUDDs, finalize mitigation plans, and define action plan", status: "on-track", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
        ]},
        { name: "Development builds, Phase Gates, OLP schedule locked", tasks: [
          { id: "l3-73", name: "Upload overall operations schedule", status: "on-track", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "l3-74", name: "Upload locked engineering schedule", status: "on-track", owner: "GOE", dataSources: ["Confluence", "PRD"] },
        ]},
        { name: "Substitution matrix & restriction set up, order process assessed, IT tool set up", tasks: [
          { id: "l3-75", name: "Confirm order and platform data is maintained across IT tools", status: "on-track", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l3-76", name: "Review restriction rules and factory configuration with GOE", status: "on-track", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l3-77", name: "Complete test coverage analysis with ODM and Engineering", status: "on-track", owner: "GOE", dataSources: ["Jira", "Confluence"] },
        ]},
      ],
    },
    {
      name: "Qual", color: "bg-orange-500", status: "not-started",
      milestones: [
        { name: "SQE MEDF Phase Gates #3,4,5,6 exited", tasks: [
          { id: "l3-78", name: "Complete PPAP on schedule for ME parts ramping", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l3-79", name: "Submit RTS approval request to VP of client procurement", status: "pending", owner: "GOE" },
          { id: "l3-80", name: "Complete ODM audit execution and reporting", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"],
      dependencies: ["l3-60"],
    },
          { id: "l3-81", name: "Complete sub-tier supplier audits for key components", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l3-82", name: "Submit GOE recommendation to exit Qual phase", status: "pending", owner: "GOE" },
          { id: "l3-83", name: "Complete CCC FM & OM ITM1/ITM2 readiness and execution", status: "pending", owner: "GOE" },
        ]},
        { name: "DVT1, DVT2 builds completed, goals met, issues captured, action plan in place", tasks: [
          { id: "l3-84", name: "Lock DVT2 OPS demand to confirmed volumes", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l3-85", name: "Lock Pilot CTO demand to confirmed volumes", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l3-86", name: "Kick off DVT2 ops build material preparation", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l3-87", name: "Confirm Golden config & demand are complete; material ETA on time", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l3-88", name: "Approve ODM DVT1 build entry", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l3-89", name: "Approve ODM DVT1 build exit", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l3-90", name: "Approve ODM DVT1.x build entry", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l3-91", name: "Approve ODM DVT1.x build exit", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l3-92", name: "Approve ODM DVT2 build entry", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l3-93", name: "Approve ODM DVT2 build exit", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l3-94", name: "Approve ODM DVT2.x build entry", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l3-95", name: "Approve ODM DVT2.x build exit", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l3-96", name: "Approve regression build entry readiness", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l3-97", name: "Complete regression build with issue disposition plan", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l3-98", name: "Complete PVB builds with systems and GAFPs validated", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l3-99", name: "Execute and monitor DVT2 OPS builds", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l3-100", name: "Conduct daily build review and track progress", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l3-101", name: "Complete post-build exit review", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l3-102", name: "Confirm build completion and output readiness", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l3-103", name: "Capture issues and ensure actions are in place", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
        ]},
        { name: "VH, H & M NUDDs closed", tasks: [
          { id: "l3-104", name: "Review and mitigate single/sole source risk", status: "pending", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
          { id: "l3-105", name: "Consolidate SSS and BCP plan with XLOB GCM", status: "pending", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
          { id: "l3-106", name: "Trigger event management if required", status: "pending", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
          { id: "l3-107", name: "Continue DFx validation and close findings in Jira", status: "pending", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
          { id: "l3-108", name: "Execute and close NUDD mitigation plans", status: "pending", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
        ]},
        { name: "Ops requirements on required design changes aligned", tasks: [
          { id: "l3-109", name: "Complete platform health check", status: "pending", owner: "GOE" },
          { id: "l3-110", name: "Review and trigger multiple tooling plan to execution", status: "pending", owner: "GOE" },
          { id: "l3-111", name: "Review Original Design Manufacturer tooling plan", status: "pending", owner: "GOE" },
          { id: "l3-112", name: "Complete Mid DD single tooling and SSS review", status: "pending", owner: "GOE" },
          { id: "l3-113", name: "Provide WWP BOM creation guidance", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l3-114", name: "Submit PH/X-rev mod and ensure D2 code readiness", status: "pending", owner: "GOE" },
          { id: "l3-115", name: "Release Panel ER and NPRR on schedule", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l3-116", name: "Review DFM status and confirm client approval", status: "pending", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
          { id: "l3-117", name: "Validate FGA BOM structure accuracy", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l3-118", name: "Generate and review platform matrix with extended team", status: "pending", owner: "GOE" },
          { id: "l3-119", name: "Confirm clean build results and closure of development changes", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l3-120", name: "Provide BOM attributes and packaging details", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
        ]},
        { name: "Manufacturing test coverage validated, design health checks completed", tasks: [
          { id: "l3-121", name: "Confirm L10 material Is complete", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l3-122", name: "Confirm DVT2 ops (SMT and L10) material is complete", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l3-123", name: "Confirm Pilot CTO material ETA is on schedule", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l3-124", name: "Prepare Pilot CTO MRA to readiness state", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l3-125", name: "Review ME pilot build safe launch report to confirm readiness", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l3-126", name: "Review first GDS report", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l3-127", name: "Validate test coverage and complete design health checks", status: "pending", owner: "GOE" },
          { id: "l3-128", name: "Ensure MRA readiness for qualification builds", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l3-129", name: "Complete RTB checklist before build start", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l3-130", name: "Review ODM build activity and exit status", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l3-131", name: "Confirm MRA materials availability before build", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l3-132", name: "Upload test and SW GAFPs before build", status: "pending", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "l3-133", name: "Ensure MRA readiness for pilot build", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
        ]},
        { name: "BOM mapping finalized", tasks: [
          { id: "l3-134", name: "Align CCI BOM structure for audit readiness", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l3-135", name: "Upload and maintain MOD list in NPI tool", status: "pending", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "l3-136", name: "Create and validate DVT2 MOD configurations", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l3-137", name: "Generate and validate qualification order configurations", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l3-138", name: "Generate and validate pilot order configurations", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l3-139", name: "Confirm SKU readiness in systems for PLS orders", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l3-140", name: "Submit ship order configuration into Jet", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
        ]},
        { name: "Substitution matrix & restriction set up, order process assessed, IT tool set up", tasks: [
          { id: "l3-141", name: "Lock RTS and PVT demand to confirmed volumes", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l3-142", name: "Shape RTS demand to align with supply constraints", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l3-143", name: "Trigger demand signal schedule for long L/T parts", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l3-144", name: "Determine supply control limit based on ACP commitment", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l3-145", name: "Confirm FHC MRP readiness", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l3-146", name: "Confirm ARC MRP readiness", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l3-147", name: "Load MRP with PVT demand", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l3-148", name: "Provide long lead time ARC list", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l3-149", name: "Prepare FHC MBP and PVT load to readiness state", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l3-150", name: "Confirm FHC readiness", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l3-151", name: "Confirm FGA readiness", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l3-152", name: "Confirm GCM parts cost is loaded correctly", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l3-153", name: "Prepare BCC MRA for GCM cost loading", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l3-154", name: "Confirm all PO cost is loaded for ST CTO build", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l3-155", name: "Confirm WW fulfillment/logistics mode", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l3-156", name: "Complete MPP review to confirm volume commitment is >= 75% of RFQ volume", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l3-157", name: "Confirm UPP loading attainment is 75% of platform BC", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l3-158", name: "Confirm packaging material is ready with L10 and BE & packaging team", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l3-159", name: "Upload OBE instructions for build execution", status: "pending", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "l3-160", name: "Download DVT2 build orders to factory", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l3-161", name: "Configure and validate GRR restriction rules", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l3-162", name: "Validate operations readiness for pilot execution", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l3-163", name: "Confirm operation plan execution status", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l3-164", name: "Review NPI production and supply chain performance reports", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l3-165", name: "Validate order fulfillment readiness for pilot", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l3-166", name: "Complete HWC setup for production readiness", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l3-167", name: "Review GRR list and restriction rules", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l3-168", name: "Download and acknowledge pilot/PLS orders by factories", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
        ]},
      ],
    },
    {
      name: "Pilot", color: "bg-teal-500", status: "not-started",
      milestones: [
        { name: "Supply & Demand readiness confirmed", tasks: [
          { id: "l3-169", name: "Define DSI goal and FGI position", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l3-170", name: "Confirm MRA materials available before build", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l3-171", name: "Confirm DSI goal and FGI position achieved", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l3-172", name: "Review RTS material supportability at T-1", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
        ]},
        { name: "Operational & Fulfillment readiness confirmed", tasks: [
          { id: "l3-173", name: "Confirm operations readiness for pilot execution", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l3-174", name: "Confirm order fulfillment readiness for pilot", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l3-175", name: "Confirm pilot order software and test readiness", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l3-176", name: "Generate pilot orders", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l3-177", name: "Send pilot orders to ODM/client factory for build", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l3-178", name: "Complete APJ FRC", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l3-179", name: "Complete EMEA FRC", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l3-180", name: "Complete DAO FRC", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l3-181", name: "Complete WW FRC", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l3-182", name: "Define and implement order process improvements", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l3-183", name: "Maintain and update tool rules and configurations", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
        ]},
        { name: "Issue Closure & Quality Stabilization", tasks: [
          { id: "l3-184", name: "Complete DFx activities and close all findings", status: "pending", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
          { id: "l3-185", name: "Close all NUDDs with mitigation completed", status: "pending", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
          { id: "l3-186", name: "Confirm issues and excursions are tracked and resolved", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l3-187", name: "Identify and reduce illegal orders with corrective actions", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l3-188", name: "Review and approve WWP deviation setup in Agile", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l3-189", name: "Monitor FPY and safe launch metrics against targets", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
        ]},
        { name: "Governance, Approval & Phase Closure", tasks: [
          { id: "l3-190", name: "Upload Develop Phase Exit documentation and approval", status: "pending", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "l3-191", name: "Upload Launch Phase Exit documentation and approval", status: "pending", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "l3-192", name: "Close development stage and document lessons learned", status: "pending", owner: "GOE", dataSources: ["Confluence", "PRD"] },
        ]},
        { name: "Build Execution & Completion", tasks: [
          { id: "l3-193", name: "Execute and monitor pilot build to completion", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l3-194", name: "Confirm PVT build is completed", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l3-195", name: "Confirm pilot completion from ODM and client factory", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l3-196", name: "Complete first block execution", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
        ]},
      ],
    },
  ],

  "Laptop 4": [
    {
      name: "Concept", color: "bg-blue-500", status: "on-track",
      milestones: [
        { name: "Concept Phase documents uploaded (added)", tasks: [
          { id: "l4-0", name: "Upload Program Charter", status: "completed", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "l4-1", name: "Upload Feature Matrix/List (MVP/Backlog) / Roadmap", status: "completed", owner: "GOE", dataSources: ["Confluence", "PRD"],
      dependencies: ["l4-0"],
    },
          { id: "l4-2", name: "Confirm PRD / Marketing info has been ingested", status: "completed", owner: "GOE", dataSources: ["Confluence", "PRD"],
      dependencies: ["l4-0"],
    },
          { id: "l4-3", name: "Confirm EDD has been ingested", status: "completed", owner: "GOE", dataSources: ["Confluence", "PRD"],
      dependencies: ["l4-2"],
    },
          { id: "l4-4", name: "Confirm ARD has been ingested", status: "completed", owner: "GOE", dataSources: ["Confluence", "PRD"],
      dependencies: ["l4-2"],
    },
          { id: "l4-5", name: "Upload Innovation Story", status: "completed", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "l4-6", name: "Upload Lessons Learned", status: "completed", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "l4-7", name: "Upload Concept Phase exit Deck", status: "completed", owner: "GOE", dataSources: ["Confluence", "PRD"],
      dependencies: ["l4-5", "l4-6"],
    },
          { id: "l4-8", name: "Approve Concept Phase Exit deck", status: "completed", owner: "GOE", dataSources: ["Confluence", "PRD"],
      dependencies: ["l4-7"],
    },
        ]},
        { name: "Initial extended team formed", tasks: [
          { id: "l4-9", name: "Intiate Extended Team formation", status: "completed", owner: "GOE" },
        ]},
        { name: "Early end 2 end supply chain NUDD identified", tasks: [
          { id: "l4-10", name: "Conduct ODM supplier assessment prior to BA", status: "completed", owner: "GOE", dataSources: ["Memory Matrix", "Jira"],
      dependencies: ["l4-9"],
    },
          { id: "l4-11", name: "Gather CAPEX requirements for WW NPI", status: "completed", owner: "GOE", dataSources: ["Memory Matrix", "Jira"],
      dependencies: ["l4-9"],
    },
        ]},
        { name: "Early DFx NUDD identified", tasks: [
          { id: "l4-12", name: "Future technology Risk Assessment", status: "completed", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
          { id: "l4-13", name: "Conduct DFx assessment & Eng engagement", status: "completed", owner: "GOE", dataSources: ["Memory Matrix", "Jira"],
      dependencies: ["l4-12"],
    },
          { id: "l4-14", name: "Populate all NUDDS in NUDD tool", status: "completed", owner: "GOE", dataSources: ["Memory Matrix", "Jira"],
      dependencies: ["l4-12", "l4-13"],
    },
        ]},
        { name: "ODM improvement plan formulated (new ODM only)", tasks: [
          { id: "l4-15", name: "Formulate ODM Improvement plan (New ODMs)", status: "completed", owner: "GOE", dataSources: ["Jira", "Confluence"] },
        ]},
      ],
    },
    {
      name: "Define", color: "bg-emerald-500", status: "on-track",
      milestones: [
        { name: "Upload Define Phase documents", tasks: [
          { id: "l4-16", name: "Upload PG Documentation and approval of CPE", status: "completed", owner: "GOE", dataSources: ["Confluence", "PRD"] },
        ]},
        { name: "Extended team expanded & finalized", tasks: [
          { id: "l4-17", name: "Finalize GO Extended team", status: "completed", owner: "GOE" },
          { id: "l4-18", name: "Update extended team with full information", status: "completed", owner: "GOE" },
        ]},
        { name: "OE requirement locked", tasks: [
          { id: "l4-19", name: "Provide Prelim. schedule, fulfillment model, Supply Chain Resiliency Requirement and related documents.", status: "completed", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "l4-20", name: "Prepare Operations Engineering (OE) RFQ Package", status: "completed", owner: "GOE" },
          { id: "l4-21", name: "Finalize \"Define Phase Cost Bridge\" & commodity cost estimate", status: "completed", owner: "GOE" },
          { id: "l4-22", name: "Approve front end should have cost bridge", status: "completed", owner: "GOE" },
          { id: "l4-23", name: "Review FIN's cost projection", status: "completed", owner: "GOE" },
          { id: "l4-24", name: "Complete ODM RFQ package and pre-alignment", status: "completed", owner: "GOE", dataSources: ["Jira", "Confluence"] },
        ]},
        { name: "Mitigation plans formulated for early identified NUDDs", tasks: [
          { id: "l4-25", name: "Identify NUDDs and Initial Mitigation Plan", status: "completed", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
          { id: "l4-26", name: "Formulate ODM Improvement plan (New ODMs)", status: "completed", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
          { id: "l4-27", name: "Review and provide feedback on NUDDs", status: "completed", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
        ]},
        { name: "Additional NUDDs identified", tasks: [
          { id: "l4-28", name: "Update DFx Assessment", status: "completed", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
        ]},
        { name: "New test requirements identified", tasks: [
          { id: "l4-29", name: "Confirm draft ITM plan for the new program", status: "completed", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l4-30", name: "Upload Draft - New test Enablement Plan - A", status: "completed", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "l4-31", name: "Upload initial GTS/VM Inputs - A/C", status: "completed", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "l4-32", name: "Upload Location and Quantity - A/TI - P1", status: "completed", owner: "GOE", dataSources: ["Confluence", "PRD"] },
        ]},
        { name: "Relevant dependencies mapped (if applicable to Critical Transitions)", tasks: [
          { id: "l4-33", name: "Review product documentation (ex: EDD, ARD, FM), LLs, and predecessor platform data", status: "completed", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "l4-34", name: "Confirm alignment between FE team and GSM(?) on NUDD supply chain plan (critical for express lane)", status: "completed", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
          { id: "l4-35", name: "Approve front end IC & XLOB SSS list", status: "completed", owner: "GOE" },
        ]},
      ],
    },
    {
      name: "Plan", color: "bg-amber-500", status: "delayed",
      milestones: [
        { name: "Upload Plan Phase documents", tasks: [
          { id: "l4-36", name: "Send program kick-off communication with all attachments to extended teams", status: "completed", owner: "GOE", dataSources: ["Confluence", "PRD"],
      dependencies: ["l4-17"],
    },
          { id: "l4-37", name: "Upload Plan Phase Exit Deck and approval minutes", status: "completed", owner: "GOE", dataSources: ["Confluence", "PRD"],
      dependencies: ["l4-39"],
    },
          { id: "l4-38", name: "Define Plan Exit GOE Manager approval", status: "completed", owner: "GOE", dataSources: ["Confluence", "PRD"],
      dependencies: ["l4-37"],
    },
          { id: "l4-39", name: "Upload Plan Phase Exit Deck", status: "completed", owner: "GOE", dataSources: ["Confluence", "PRD"],
      dependencies: ["l4-8"],
    },
        ]},
        { name: "WW FRC & RTO volume ramp plan locked", tasks: [
          { id: "l4-40", name: "Release Contract Book 1.0, update DPE with MYPO, and verify volume estimation", status: "completed", owner: "GOE",
      dependencies: ["l4-21"],
    },
          { id: "l4-41", name: "Define TTM target and lock RTS/RTO schedule", status: "completed", owner: "GOE", dataSources: ["Jira", "Confluence"],
      dependencies: ["l4-40"],
    },
        ]},
        { name: "Manufacturing plan confirmed", tasks: [
          { id: "l4-42", name: "Validate costed BOM and CS workbook against RTS carcass cost", status: "completed", owner: "GOE", dataSources: ["SAP", "Jira"],
      dependencies: ["l4-40"],
    },
          { id: "l4-43", name: "Validate tooling plan and complete tooling risk go decision", status: "completed", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
          { id: "l4-44", name: "Confirm receipt of ME/XLOB PPE cost projections for BA POR", status: "completed", owner: "GOE", dataSources: ["Jira", "Confluence"],
      dependencies: ["l4-42"],
    },
          { id: "l4-45", name: "Define PPAP schedule per CT recommendations", status: "completed", owner: "GOE", dataSources: ["Jira", "Confluence"],
      dependencies: ["l4-43"],
    },
          { id: "l4-46", name: "Confirm critical part qualification schedule is included in platform backend schedule", status: "completed", owner: "GOE", dataSources: ["Jira", "Confluence"],
      dependencies: ["l4-45"],
    },
          { id: "l4-47", name: "Upload ODM RFQ design proposal", status: "completed", owner: "GOE", dataSources: ["Confluence", "PRD"],
      dependencies: ["l4-24"],
    },
          { id: "l4-48", name: "Input last quarter QBR score", status: "completed", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l4-49", name: "Develop build and manufacturing plan and lock FRC date", status: "completed", owner: "GOE", dataSources: ["Jira", "Confluence"],
      dependencies: ["l4-41", "l4-42"],
    },
        ]},
        { name: "WW fulfillment plan confirmed", tasks: [
          { id: "l4-50", name: "Consolidate SSS and BCP plan with XLOB GCM and review compliance attributes", status: "completed", owner: "GOE", dataSources: ["Jira", "Confluence"],
      dependencies: ["l4-49"],
    },
          { id: "l4-51", name: "Review supply chain map and include it in PPE deck", status: "completed", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "l4-52", name: "Lock WW fulfillment/logistics model and provide expedite cost estimates", status: "completed", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l4-53", name: "Upload Supplier Chain Lead Time file", status: "completed", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "l4-54", name: "Upload fulfillment model and evaluate gaps", status: "completed", owner: "GOE", dataSources: ["Confluence", "PRD"] },
        ]},
        { name: "SQE MEDF Phase Gate #2 exited", tasks: [
          { id: "l4-55", name: "Record post-BA changes and link to Finance TCM document", status: "completed", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "l4-56", name: "Upload Supplier Maturity Assessment for new ODM onboarding", status: "completed", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "l4-57", name: "Validate ODM and sub-tier supplier audit schedules", status: "completed", owner: "GOE", dataSources: ["Jira", "Confluence"] },
        ]},
        { name: "KPI aligned (yield, quality, FIR & IFIR goals)", tasks: [
          { id: "l4-58", name: "Validate yield rate, RFQ volume, and complexity matrix with CT and provide tooling plan to Sourcing GCM", status: "completed", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l4-59", name: "Review attach rate by feature and include in complexity matrix", status: "completed", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l4-60", name: "Share complexity matrix with CT and ensure compliance with ACL guidance", status: "completed", owner: "GOE", dataSources: ["Jira", "Confluence"],
      dependencies: ["l4-49", "l4-47"],
    },
          { id: "l4-61", name: "Calculate pre-BA score and confirm with CT", status: "completed", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l4-62", name: "Confirm joint review and feedback on BA recommendation", status: "completed", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l4-63", name: "Upload and submit GOE Pre-BA scorecard to CT", status: "completed", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "l4-64", name: "Define KPIs for Yield, Quality, FIR, and IFIR", status: "completed", owner: "GOE", dataSources: ["Jira", "Confluence"] },
        ]},
        { name: "DFx design plan locked", tasks: [
          { id: "l4-65", name: "Complete PDL assessment and confirm with CT", status: "completed", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
          { id: "l4-66", name: "Update product documentation for Plan Phase exit", status: "completed", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "l4-67", name: "Review and validate initial PH and BOM", status: "completed", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
          { id: "l4-68", name: "Review engineering drawings and mockups and provide feedback", status: "completed", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
          { id: "l4-69", name: "Continue DFx validation and update validation process", status: "completed", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
          { id: "l4-70", name: "Review prototype with operations and document feedback", status: "completed", owner: "GOE", dataSources: ["Confluence", "PRD"] },
        ]},
        { name: "NUDD mitigation plans locked", tasks: [
          { id: "l4-71", name: "Review and validate NUDD/DFMAA plan for risk mitigation", status: "completed", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
          { id: "l4-72", name: "Identify NUDDs, finalize mitigation plans, and define action plan", status: "completed", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
        ]},
        { name: "Development builds, Phase Gates, OLP schedule locked", tasks: [
          { id: "l4-73", name: "Upload overall operations schedule", status: "completed", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "l4-74", name: "Upload locked engineering schedule", status: "completed", owner: "GOE", dataSources: ["Confluence", "PRD"] },
        ]},
        { name: "Substitution matrix & restriction set up, order process assessed, IT tool set up", tasks: [
          { id: "l4-75", name: "Confirm order and platform data is maintained across IT tools", status: "completed", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l4-76", name: "Review restriction rules and factory configuration with GOE", status: "completed", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l4-77", name: "Complete test coverage analysis with ODM and Engineering", status: "completed", owner: "GOE", dataSources: ["Jira", "Confluence"] },
        ]},
      ],
    },
    {
      name: "Qual", color: "bg-orange-500", status: "not-started",
      milestones: [
        { name: "SQE MEDF Phase Gates #3,4,5,6 exited", tasks: [
          { id: "l4-78", name: "Complete PPAP on schedule for ME parts ramping", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l4-79", name: "Submit RTS approval request to VP of client procurement", status: "pending", owner: "GOE" },
          { id: "l4-80", name: "Complete ODM audit execution and reporting", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"],
      dependencies: ["l4-60"],
    },
          { id: "l4-81", name: "Complete sub-tier supplier audits for key components", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l4-82", name: "Submit GOE recommendation to exit Qual phase", status: "pending", owner: "GOE" },
          { id: "l4-83", name: "Complete CCC FM & OM ITM1/ITM2 readiness and execution", status: "pending", owner: "GOE" },
        ]},
        { name: "DVT2 build executed", tasks: [
          { id: "l4-84", name: "Lock DVT2 OPS demand to confirmed volumes", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l4-85", name: "Lock Pilot CTO demand to confirmed volumes", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l4-86", name: "Kick off DVT2 ops build material preparation", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l4-87", name: "Confirm Golden config & demand are complete; material ETA on time", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l4-88", name: "Approve ODM DVT1 build entry", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l4-89", name: "Approve ODM DVT1 build exit", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l4-90", name: "Approve ODM DVT1.x build entry", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l4-91", name: "Approve ODM DVT1.x build exit", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l4-92", name: "Approve ODM DVT2 build entry", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l4-93", name: "Approve ODM DVT2 build exit", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l4-94", name: "Approve ODM DVT2.x build entry", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l4-95", name: "Approve ODM DVT2.x build exit", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l4-96", name: "Approve regression build entry readiness", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l4-97", name: "Complete regression build with issue disposition plan", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l4-98", name: "Complete PVB builds with systems and GAFPs validated", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l4-99", name: "Execute and monitor DVT2 OPS builds", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l4-100", name: "Conduct daily build review and track progress", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l4-101", name: "Complete post-build exit review", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l4-102", name: "Confirm build completion and output readiness", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l4-103", name: "Capture issues and ensure actions are in place", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
        ]},
        { name: "VH, H & M NUDDs closed", tasks: [
          { id: "l4-104", name: "Review and mitigate single/sole source risk", status: "pending", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
          { id: "l4-105", name: "Consolidate SSS and BCP plan with XLOB GCM", status: "pending", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
          { id: "l4-106", name: "Trigger event management if required", status: "pending", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
          { id: "l4-107", name: "Continue DFx validation and close findings in Jira", status: "pending", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
          { id: "l4-108", name: "Execute and close NUDD mitigation plans", status: "pending", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
        ]},
        { name: "Ops requirements on required design changes aligned", tasks: [
          { id: "l4-109", name: "Complete platform health check", status: "pending", owner: "GOE" },
          { id: "l4-110", name: "Review and trigger multiple tooling plan to execution", status: "pending", owner: "GOE" },
          { id: "l4-111", name: "Review Original Design Manufacturer tooling plan", status: "pending", owner: "GOE" },
          { id: "l4-112", name: "Complete Mid DD single tooling and SSS review", status: "pending", owner: "GOE" },
          { id: "l4-113", name: "Provide WWP BOM creation guidance", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l4-114", name: "Submit PH/X-rev mod and ensure D2 code readiness", status: "pending", owner: "GOE" },
          { id: "l4-115", name: "Release Panel ER and NPRR on schedule", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l4-116", name: "Review DFM status and confirm client approval", status: "pending", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
          { id: "l4-117", name: "Validate FGA BOM structure accuracy", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l4-118", name: "Generate and review platform matrix with extended team", status: "pending", owner: "GOE" },
          { id: "l4-119", name: "Confirm clean build results and closure of development changes", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l4-120", name: "Provide BOM attributes and packaging details", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
        ]},
        { name: "Manufacturing test coverage validated, design health checks completed", tasks: [
          { id: "l4-121", name: "Confirm L10 material Is complete", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l4-122", name: "Confirm DVT2 ops (SMT and L10) material is complete", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l4-123", name: "Confirm Pilot CTO material ETA is on schedule", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l4-124", name: "Prepare Pilot CTO MRA to readiness state", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l4-125", name: "Review ME pilot build safe launch report to confirm readiness", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l4-126", name: "Review first GDS report", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l4-127", name: "Validate test coverage and complete design health checks", status: "pending", owner: "GOE" },
          { id: "l4-128", name: "Ensure MRA readiness for qualification builds", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l4-129", name: "Complete RTB checklist before build start", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l4-130", name: "Review ODM build activity and exit status", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l4-131", name: "Confirm MRA materials availability before build", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l4-132", name: "Upload test and SW GAFPs before build", status: "pending", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "l4-133", name: "Ensure MRA readiness for pilot build", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
        ]},
        { name: "BOM mapping finalized", tasks: [
          { id: "l4-134", name: "Align CCI BOM structure for audit readiness", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l4-135", name: "Upload and maintain MOD list in NPI tool", status: "pending", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "l4-136", name: "Create and validate DVT2 MOD configurations", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l4-137", name: "Generate and validate qualification order configurations", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l4-138", name: "Generate and validate pilot order configurations", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l4-139", name: "Confirm SKU readiness in systems for PLS orders", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l4-140", name: "Submit ship order configuration into Jet", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
        ]},
        { name: "Substitution matrix & restriction set up, order process assessed, IT tool set up", tasks: [
          { id: "l4-141", name: "Lock RTS and PVT demand to confirmed volumes", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l4-142", name: "Shape RTS demand to align with supply constraints", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l4-143", name: "Trigger demand signal schedule for long L/T parts", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l4-144", name: "Determine supply control limit based on ACP commitment", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l4-145", name: "Confirm FHC MRP readiness", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l4-146", name: "Confirm ARC MRP readiness", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l4-147", name: "Load MRP with PVT demand", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l4-148", name: "Provide long lead time ARC list", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l4-149", name: "Prepare FHC MBP and PVT load to readiness state", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l4-150", name: "Confirm FHC readiness", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l4-151", name: "Confirm FGA readiness", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l4-152", name: "Confirm GCM parts cost is loaded correctly", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l4-153", name: "Prepare BCC MRA for GCM cost loading", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l4-154", name: "Confirm all PO cost is loaded for ST CTO build", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l4-155", name: "Confirm WW fulfillment/logistics mode", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l4-156", name: "Complete MPP review to confirm volume commitment is >= 75% of RFQ volume", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l4-157", name: "Confirm UPP loading attainment is 75% of platform BC", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l4-158", name: "Confirm packaging material is ready with L10 and BE & packaging team", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l4-159", name: "Upload OBE instructions for build execution", status: "pending", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "l4-160", name: "Download DVT2 build orders to factory", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l4-161", name: "Configure and validate GRR restriction rules", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l4-162", name: "Validate operations readiness for pilot execution", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l4-163", name: "Confirm operation plan execution status", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l4-164", name: "Review NPI production and supply chain performance reports", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l4-165", name: "Validate order fulfillment readiness for pilot", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l4-166", name: "Complete HWC setup for production readiness", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l4-167", name: "Review GRR list and restriction rules", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l4-168", name: "Download and acknowledge pilot/PLS orders by factories", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
        ]},
      ],
    },
    {
      name: "Pilot", color: "bg-teal-500", status: "not-started",
      milestones: [
        { name: "Supply & Demand readiness confirmed", tasks: [
          { id: "l4-169", name: "Define DSI goal and FGI position", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l4-170", name: "Confirm MRA materials available before build", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l4-171", name: "Confirm DSI goal and FGI position achieved", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l4-172", name: "Review RTS material supportability at T-1", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
        ]},
        { name: "Operational & Fulfillment readiness confirmed", tasks: [
          { id: "l4-173", name: "Confirm operations readiness for pilot execution", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l4-174", name: "Confirm order fulfillment readiness for pilot", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l4-175", name: "Confirm pilot order software and test readiness", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l4-176", name: "Generate pilot orders", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l4-177", name: "Send pilot orders to ODM/client factory for build", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l4-178", name: "Complete APJ FRC", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l4-179", name: "Complete EMEA FRC", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l4-180", name: "Complete DAO FRC", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l4-181", name: "Complete WW FRC", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l4-182", name: "Define and implement order process improvements", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l4-183", name: "Maintain and update tool rules and configurations", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
        ]},
        { name: "Issue Closure & Quality Stabilization", tasks: [
          { id: "l4-184", name: "Complete DFx activities and close all findings", status: "pending", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
          { id: "l4-185", name: "Close all NUDDs with mitigation completed", status: "pending", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
          { id: "l4-186", name: "Confirm issues and excursions are tracked and resolved", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l4-187", name: "Identify and reduce illegal orders with corrective actions", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "l4-188", name: "Review and approve WWP deviation setup in Agile", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l4-189", name: "Monitor FPY and safe launch metrics against targets", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
        ]},
        { name: "Governance, Approval & Phase Closure", tasks: [
          { id: "l4-190", name: "Upload Develop Phase Exit documentation and approval", status: "pending", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "l4-191", name: "Upload Launch Phase Exit documentation and approval", status: "pending", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "l4-192", name: "Close development stage and document lessons learned", status: "pending", owner: "GOE", dataSources: ["Confluence", "PRD"] },
        ]},
        { name: "Build Execution & Completion", tasks: [
          { id: "l4-193", name: "Execute and monitor pilot build to completion", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l4-194", name: "Confirm PVT build is completed", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l4-195", name: "Confirm pilot completion from ODM and client factory", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "l4-196", name: "Complete first block execution", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
        ]},
      ],
    },
  ],

  "Server 1": [
    {
      name: "Concept", color: "bg-blue-500", status: "on-track",
      milestones: [
        { name: "Concept Phase documents uploaded (added)", tasks: [
          { id: "s1-0", name: "Upload Program Charter", status: "completed", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "s1-1", name: "Upload Feature Matrix/List (MVP/Backlog) / Roadmap", status: "completed", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "s1-2", name: "Confirm PRD / Marketing info has been ingested", status: "completed", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "s1-3", name: "Confirm EDD has been ingested", status: "completed", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "s1-4", name: "Confirm ARD has been ingested", status: "completed", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "s1-5", name: "Upload Innovation Story", status: "completed", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "s1-6", name: "Upload Lessons Learned", status: "completed", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "s1-7", name: "Upload Concept Phase exit Deck", status: "completed", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "s1-8", name: "Approve Concept Phase Exit deck", status: "completed", owner: "GOE", dataSources: ["Confluence", "PRD"] },
        ]},
        { name: "Initial extended team formed", tasks: [
          { id: "s1-9", name: "Intiate Extended Team formation", status: "completed", owner: "GOE" },
        ]},
        { name: "Early end 2 end supply chain NUDD identified", tasks: [
          { id: "s1-10", name: "Conduct ODM supplier assessment prior to BA", status: "completed", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
          { id: "s1-11", name: "Gather CAPEX requirements for WW NPI", status: "completed", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
        ]},
        { name: "Early DFx NUDD identified", tasks: [
          { id: "s1-12", name: "Future technology Risk Assessment", status: "completed", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
          { id: "s1-13", name: "Conduct DFx assessment & Eng engagement", status: "completed", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
          { id: "s1-14", name: "Populate all NUDDS in NUDD tool", status: "completed", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
        ]},
        { name: "ODM improvement plan formulated (new ODM only)", tasks: [
          { id: "s1-15", name: "Formulate ODM Improvement plan (New ODMs)", status: "completed", owner: "GOE", dataSources: ["Jira", "Confluence"] },
        ]},
      ],
    },
    {
      name: "Define", color: "bg-emerald-500", status: "on-track",
      milestones: [
        { name: "Upload Define Phase documents", tasks: [
          { id: "s1-16", name: "Upload PG Documentation and approval of CPE", status: "completed", owner: "GOE", dataSources: ["Confluence", "PRD"] },
        ]},
        { name: "Extended team expanded & finalized", tasks: [
          { id: "s1-17", name: "Finalize GO Extended team", status: "completed", owner: "GOE" },
          { id: "s1-18", name: "Update extended team with full information", status: "completed", owner: "GOE" },
        ]},
        { name: "OE requirement locked", tasks: [
          { id: "s1-19", name: "Provide Prelim. schedule, fulfillment model, Supply Chain Resiliency Requirement and related documents.", status: "completed", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "s1-20", name: "Prepare Operations Engineering (OE) RFQ Package", status: "completed", owner: "GOE" },
          { id: "s1-21", name: "Finalize \"Define Phase Cost Bridge\" & commodity cost estimate", status: "completed", owner: "GOE" },
          { id: "s1-22", name: "Approve front end should have cost bridge", status: "completed", owner: "GOE" },
          { id: "s1-23", name: "Review FIN's cost projection", status: "completed", owner: "GOE" },
          { id: "s1-24", name: "Complete ODM RFQ package and pre-alignment", status: "completed", owner: "GOE", dataSources: ["Jira", "Confluence"] },
        ]},
        { name: "Mitigation plans formulated for early identified NUDDs", tasks: [
          { id: "s1-25", name: "Identify NUDDs and Initial Mitigation Plan", status: "completed", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
          { id: "s1-26", name: "Formulate ODM Improvement plan (New ODMs)", status: "completed", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
          { id: "s1-27", name: "Review and provide feedback on NUDDs", status: "completed", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
        ]},
        { name: "Additional NUDDs identified", tasks: [
          { id: "s1-28", name: "Update DFx Assessment", status: "completed", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
        ]},
        { name: "New test requirements identified", tasks: [
          { id: "s1-29", name: "Confirm draft ITM plan for the new program", status: "completed", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s1-30", name: "Upload Draft - New test Enablement Plan - A", status: "completed", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "s1-31", name: "Upload initial GTS/VM Inputs - A/C", status: "completed", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "s1-32", name: "Upload Location and Quantity - A/TI - P1", status: "completed", owner: "GOE", dataSources: ["Confluence", "PRD"] },
        ]},
        { name: "Relevant dependencies mapped (if applicable to Critical Transitions)", tasks: [
          { id: "s1-33", name: "Review product documentation (ex: EDD, ARD, FM), LLs, and predecessor platform data", status: "completed", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "s1-34", name: "Confirm alignment between FE team and GSM(?) on NUDD supply chain plan (critical for express lane)", status: "completed", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
          { id: "s1-35", name: "Approve front end IC & XLOB SSS list", status: "completed", owner: "GOE" },
        ]},
      ],
    },
    {
      name: "Plan", color: "bg-amber-500", status: "delayed",
      milestones: [
        { name: "Upload Plan Phase documents", tasks: [
          { id: "s1-36", name: "Send program kick-off communication with all attachments to extended teams", status: "completed", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "s1-37", name: "Upload Plan Phase Exit Deck and approval minutes", status: "completed", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "s1-38", name: "Define Plan Exit GOE Manager approval", status: "completed", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "s1-39", name: "Upload Plan Phase Exit Deck", status: "completed", owner: "GOE", dataSources: ["Confluence", "PRD"] },
        ]},
        { name: "WW FRC & RTO volume ramp plan locked", tasks: [
          { id: "s1-40", name: "Release Contract Book 1.0, update DPE with MYPO, and verify volume estimation", status: "completed", owner: "GOE" },
          { id: "s1-41", name: "Define TTM target and lock RTS/RTO schedule", status: "completed", owner: "GOE", dataSources: ["Jira", "Confluence"] },
        ]},
        { name: "Manufacturing plan confirmed", tasks: [
          { id: "s1-42", name: "Validate costed BOM and CS workbook against RTS carcass cost", status: "completed", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "s1-43", name: "Validate tooling plan and complete tooling risk go decision", status: "completed", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
          { id: "s1-44", name: "Confirm receipt of ME/XLOB PPE cost projections for BA POR", status: "completed", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s1-45", name: "Define PPAP schedule per CT recommendations", status: "on-track", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s1-46", name: "Confirm critical part qualification schedule is included in platform backend schedule", status: "on-track", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s1-47", name: "Upload ODM RFQ design proposal", status: "on-track", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "s1-48", name: "Input last quarter QBR score", status: "on-track", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s1-49", name: "Develop build and manufacturing plan and lock FRC date", status: "on-track", owner: "GOE", dataSources: ["Jira", "Confluence"] },
        ]},
        { name: "WW fulfillment plan confirmed", tasks: [
          { id: "s1-50", name: "Consolidate SSS and BCP plan with XLOB GCM and review compliance attributes", status: "on-track", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s1-51", name: "Review supply chain map and include it in PPE deck", status: "on-track", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "s1-52", name: "Lock WW fulfillment/logistics model and provide expedite cost estimates", status: "on-track", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s1-53", name: "Upload Supplier Chain Lead Time file", status: "on-track", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "s1-54", name: "Upload fulfillment model and evaluate gaps", status: "on-track", owner: "GOE", dataSources: ["Confluence", "PRD"] },
        ]},
        { name: "SQE MEDF Phase Gate #2 exited", tasks: [
          { id: "s1-55", name: "Record post-BA changes and link to Finance TCM document", status: "on-track", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "s1-56", name: "Upload Supplier Maturity Assessment for new ODM onboarding", status: "on-track", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "s1-57", name: "Validate ODM and sub-tier supplier audit schedules", status: "on-track", owner: "GOE", dataSources: ["Jira", "Confluence"] },
        ]},
        { name: "KPI aligned (yield, quality, FIR & IFIR goals)", tasks: [
          { id: "s1-58", name: "Validate yield rate, RFQ volume, and complexity matrix with CT and provide tooling plan to Sourcing GCM", status: "on-track", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s1-59", name: "Review attach rate by feature and include in complexity matrix", status: "on-track", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s1-60", name: "Share complexity matrix with CT and ensure compliance with ACL guidance", status: "on-track", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s1-61", name: "Calculate pre-BA score and confirm with CT", status: "on-track", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s1-62", name: "Confirm joint review and feedback on BA recommendation", status: "on-track", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s1-63", name: "Upload and submit GOE Pre-BA scorecard to CT", status: "on-track", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "s1-64", name: "Define KPIs for Yield, Quality, FIR, and IFIR", status: "on-track", owner: "GOE", dataSources: ["Jira", "Confluence"] },
        ]},
        { name: "DFx design plan locked", tasks: [
          { id: "s1-65", name: "Complete PDL assessment and confirm with CT", status: "on-track", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
          { id: "s1-66", name: "Update product documentation for Plan Phase exit", status: "on-track", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "s1-67", name: "Review and validate initial PH and BOM", status: "on-track", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
          { id: "s1-68", name: "Review engineering drawings and mockups and provide feedback", status: "on-track", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
          { id: "s1-69", name: "Continue DFx validation and update validation process", status: "on-track", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
          { id: "s1-70", name: "Review prototype with operations and document feedback", status: "on-track", owner: "GOE", dataSources: ["Confluence", "PRD"] },
        ]},
        { name: "NUDD mitigation plans locked", tasks: [
          { id: "s1-71", name: "Review and validate NUDD/DFMAA plan for risk mitigation", status: "on-track", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
          { id: "s1-72", name: "Identify NUDDs, finalize mitigation plans, and define action plan", status: "on-track", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
        ]},
        { name: "Development builds, Phase Gates, OLP schedule locked", tasks: [
          { id: "s1-73", name: "Upload overall operations schedule", status: "on-track", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "s1-74", name: "Upload locked engineering schedule", status: "on-track", owner: "GOE", dataSources: ["Confluence", "PRD"] },
        ]},
        { name: "Substitution matrix & restriction set up, order process assessed, IT tool set up", tasks: [
          { id: "s1-75", name: "Confirm order and platform data is maintained across IT tools", status: "on-track", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "s1-76", name: "Review restriction rules and factory configuration with GOE", status: "on-track", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "s1-77", name: "Complete test coverage analysis with ODM and Engineering", status: "on-track", owner: "GOE", dataSources: ["Jira", "Confluence"] },
        ]},
      ],
    },
    {
      name: "Qual", color: "bg-orange-500", status: "not-started",
      milestones: [
        { name: "SQE MEDF Phase Gates #3,4,5,6 exited", tasks: [
          { id: "s1-78", name: "Complete PPAP on schedule for ME parts ramping", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s1-79", name: "Submit RTS approval request to VP of client procurement", status: "pending", owner: "GOE" },
          { id: "s1-80", name: "Complete ODM audit execution and reporting", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s1-81", name: "Complete sub-tier supplier audits for key components", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s1-82", name: "Submit GOE recommendation to exit Qual phase", status: "pending", owner: "GOE" },
          { id: "s1-83", name: "Complete CCC FM & OM ITM1/ITM2 readiness and execution", status: "pending", owner: "GOE" },
        ]},
        { name: "DVT1, DVT2 builds completed, goals met, issues captured, action plan in place", tasks: [
          { id: "s1-84", name: "Lock DVT2 OPS demand to confirmed volumes", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s1-85", name: "Lock Pilot CTO demand to confirmed volumes", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s1-86", name: "Kick off DVT2 ops build material preparation", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s1-87", name: "Confirm Golden config & demand are complete; material ETA on time", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "s1-88", name: "Approve ODM DVT1 build entry", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s1-89", name: "Approve ODM DVT1 build exit", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s1-90", name: "Approve ODM DVT1.x build entry", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s1-91", name: "Approve ODM DVT1.x build exit", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s1-92", name: "Approve ODM DVT2 build entry", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s1-93", name: "Approve ODM DVT2 build exit", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s1-94", name: "Approve ODM DVT2.x build entry", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s1-95", name: "Approve ODM DVT2.x build exit", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s1-96", name: "Approve regression build entry readiness", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s1-97", name: "Complete regression build with issue disposition plan", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s1-98", name: "Complete PVB builds with systems and GAFPs validated", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s1-99", name: "Execute and monitor DVT2 OPS builds", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s1-100", name: "Conduct daily build review and track progress", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s1-101", name: "Complete post-build exit review", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s1-102", name: "Confirm build completion and output readiness", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s1-103", name: "Capture issues and ensure actions are in place", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
        ]},
        { name: "VH, H & M NUDDs closed", tasks: [
          { id: "s1-104", name: "Review and mitigate single/sole source risk", status: "pending", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
          { id: "s1-105", name: "Consolidate SSS and BCP plan with XLOB GCM", status: "pending", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
          { id: "s1-106", name: "Trigger event management if required", status: "pending", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
          { id: "s1-107", name: "Continue DFx validation and close findings in Jira", status: "pending", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
          { id: "s1-108", name: "Execute and close NUDD mitigation plans", status: "pending", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
        ]},
        { name: "Ops requirements on required design changes aligned", tasks: [
          { id: "s1-109", name: "Complete platform health check", status: "pending", owner: "GOE" },
          { id: "s1-110", name: "Review and trigger multiple tooling plan to execution", status: "pending", owner: "GOE" },
          { id: "s1-111", name: "Review Original Design Manufacturer tooling plan", status: "pending", owner: "GOE" },
          { id: "s1-112", name: "Complete Mid DD single tooling and SSS review", status: "pending", owner: "GOE" },
          { id: "s1-113", name: "Provide WWP BOM creation guidance", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "s1-114", name: "Submit PH/X-rev mod and ensure D2 code readiness", status: "pending", owner: "GOE" },
          { id: "s1-115", name: "Release Panel ER and NPRR on schedule", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s1-116", name: "Review DFM status and confirm client approval", status: "pending", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
          { id: "s1-117", name: "Validate FGA BOM structure accuracy", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "s1-118", name: "Generate and review platform matrix with extended team", status: "pending", owner: "GOE" },
          { id: "s1-119", name: "Confirm clean build results and closure of development changes", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s1-120", name: "Provide BOM attributes and packaging details", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
        ]},
        { name: "Manufacturing test coverage validated, design health checks completed", tasks: [
          { id: "s1-121", name: "Confirm L10 material Is complete", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s1-122", name: "Confirm DVT2 ops (SMT and L10) material is complete", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s1-123", name: "Confirm Pilot CTO material ETA is on schedule", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s1-124", name: "Prepare Pilot CTO MRA to readiness state", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s1-125", name: "Review ME pilot build safe launch report to confirm readiness", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s1-126", name: "Review first GDS report", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s1-127", name: "Validate test coverage and complete design health checks", status: "pending", owner: "GOE" },
          { id: "s1-128", name: "Ensure MRA readiness for qualification builds", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s1-129", name: "Complete RTB checklist before build start", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s1-130", name: "Review ODM build activity and exit status", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s1-131", name: "Confirm MRA materials availability before build", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s1-132", name: "Upload test and SW GAFPs before build", status: "pending", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "s1-133", name: "Ensure MRA readiness for pilot build", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
        ]},
        { name: "BOM mapping finalized", tasks: [
          { id: "s1-134", name: "Align CCI BOM structure for audit readiness", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "s1-135", name: "Upload and maintain MOD list in NPI tool", status: "pending", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "s1-136", name: "Create and validate DVT2 MOD configurations", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "s1-137", name: "Generate and validate qualification order configurations", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "s1-138", name: "Generate and validate pilot order configurations", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "s1-139", name: "Confirm SKU readiness in systems for PLS orders", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "s1-140", name: "Submit ship order configuration into Jet", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
        ]},
        { name: "Substitution matrix & restriction set up, order process assessed, IT tool set up", tasks: [
          { id: "s1-141", name: "Lock RTS and PVT demand to confirmed volumes", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "s1-142", name: "Shape RTS demand to align with supply constraints", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "s1-143", name: "Trigger demand signal schedule for long L/T parts", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "s1-144", name: "Determine supply control limit based on ACP commitment", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "s1-145", name: "Confirm FHC MRP readiness", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "s1-146", name: "Confirm ARC MRP readiness", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "s1-147", name: "Load MRP with PVT demand", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "s1-148", name: "Provide long lead time ARC list", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "s1-149", name: "Prepare FHC MBP and PVT load to readiness state", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "s1-150", name: "Confirm FHC readiness", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "s1-151", name: "Confirm FGA readiness", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "s1-152", name: "Confirm GCM parts cost is loaded correctly", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "s1-153", name: "Prepare BCC MRA for GCM cost loading", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "s1-154", name: "Confirm all PO cost is loaded for ST CTO build", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "s1-155", name: "Confirm WW fulfillment/logistics mode", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "s1-156", name: "Complete MPP review to confirm volume commitment is >= 75% of RFQ volume", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "s1-157", name: "Confirm UPP loading attainment is 75% of platform BC", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "s1-158", name: "Confirm packaging material is ready with L10 and BE & packaging team", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "s1-159", name: "Upload OBE instructions for build execution", status: "pending", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "s1-160", name: "Download DVT2 build orders to factory", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "s1-161", name: "Configure and validate GRR restriction rules", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "s1-162", name: "Validate operations readiness for pilot execution", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "s1-163", name: "Confirm operation plan execution status", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "s1-164", name: "Review NPI production and supply chain performance reports", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s1-165", name: "Validate order fulfillment readiness for pilot", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "s1-166", name: "Complete HWC setup for production readiness", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "s1-167", name: "Review GRR list and restriction rules", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "s1-168", name: "Download and acknowledge pilot/PLS orders by factories", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
        ]},
      ],
    },
    {
      name: "Pilot", color: "bg-teal-500", status: "not-started",
      milestones: [
        { name: "Supply & Demand readiness confirmed", tasks: [
          { id: "s1-169", name: "Define DSI goal and FGI position", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s1-170", name: "Confirm MRA materials available before build", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s1-171", name: "Confirm DSI goal and FGI position achieved", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s1-172", name: "Review RTS material supportability at T-1", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
        ]},
        { name: "Operational & Fulfillment readiness confirmed", tasks: [
          { id: "s1-173", name: "Confirm operations readiness for pilot execution", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s1-174", name: "Confirm order fulfillment readiness for pilot", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "s1-175", name: "Confirm pilot order software and test readiness", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "s1-176", name: "Generate pilot orders", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "s1-177", name: "Send pilot orders to ODM/client factory for build", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s1-178", name: "Complete APJ FRC", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s1-179", name: "Complete EMEA FRC", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s1-180", name: "Complete DAO FRC", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s1-181", name: "Complete WW FRC", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s1-182", name: "Define and implement order process improvements", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "s1-183", name: "Maintain and update tool rules and configurations", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
        ]},
        { name: "Issue Closure & Quality Stabilization", tasks: [
          { id: "s1-184", name: "Complete DFx activities and close all findings", status: "pending", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
          { id: "s1-185", name: "Close all NUDDs with mitigation completed", status: "pending", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
          { id: "s1-186", name: "Confirm issues and excursions are tracked and resolved", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s1-187", name: "Identify and reduce illegal orders with corrective actions", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "s1-188", name: "Review and approve WWP deviation setup in Agile", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s1-189", name: "Monitor FPY and safe launch metrics against targets", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
        ]},
        { name: "Governance, Approval & Phase Closure", tasks: [
          { id: "s1-190", name: "Upload Develop Phase Exit documentation and approval", status: "pending", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "s1-191", name: "Upload Launch Phase Exit documentation and approval", status: "pending", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "s1-192", name: "Close development stage and document lessons learned", status: "pending", owner: "GOE", dataSources: ["Confluence", "PRD"] },
        ]},
        { name: "Build Execution & Completion", tasks: [
          { id: "s1-193", name: "Execute and monitor pilot build to completion", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s1-194", name: "Confirm PVT build is completed", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s1-195", name: "Confirm pilot completion from ODM and client factory", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s1-196", name: "Complete first block execution", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
        ]},
      ],
    },
  ],

  "Server 2": [
    {
      name: "Concept", color: "bg-blue-500", status: "on-track",
      milestones: [
        { name: "Concept Phase documents uploaded (added)", tasks: [
          { id: "s2-0", name: "Upload Program Charter", status: "completed", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "s2-1", name: "Upload Feature Matrix/List (MVP/Backlog) / Roadmap", status: "completed", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "s2-2", name: "Confirm PRD / Marketing info has been ingested", status: "completed", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "s2-3", name: "Confirm EDD has been ingested", status: "completed", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "s2-4", name: "Confirm ARD has been ingested", status: "completed", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "s2-5", name: "Upload Innovation Story", status: "completed", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "s2-6", name: "Upload Lessons Learned", status: "completed", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "s2-7", name: "Upload Concept Phase exit Deck", status: "completed", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "s2-8", name: "Approve Concept Phase Exit deck", status: "completed", owner: "GOE", dataSources: ["Confluence", "PRD"] },
        ]},
        { name: "Initial extended team formed", tasks: [
          { id: "s2-9", name: "Intiate Extended Team formation", status: "completed", owner: "GOE" },
        ]},
        { name: "Early end 2 end supply chain NUDD identified", tasks: [
          { id: "s2-10", name: "Conduct ODM supplier assessment prior to BA", status: "completed", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
          { id: "s2-11", name: "Gather CAPEX requirements for WW NPI", status: "completed", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
        ]},
        { name: "Early DFx NUDD identified", tasks: [
          { id: "s2-12", name: "Future technology Risk Assessment", status: "completed", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
          { id: "s2-13", name: "Conduct DFx assessment & Eng engagement", status: "completed", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
          { id: "s2-14", name: "Populate all NUDDS in NUDD tool", status: "completed", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
        ]},
        { name: "ODM improvement plan formulated (new ODM only)", tasks: [
          { id: "s2-15", name: "Formulate ODM Improvement plan (New ODMs)", status: "completed", owner: "GOE", dataSources: ["Jira", "Confluence"] },
        ]},
      ],
    },
    {
      name: "Define", color: "bg-emerald-500", status: "on-track",
      milestones: [
        { name: "Upload Define Phase documents", tasks: [
          { id: "s2-16", name: "Upload PG Documentation and approval of CPE", status: "completed", owner: "GOE", dataSources: ["Confluence", "PRD"] },
        ]},
        { name: "Extended team expanded & finalized", tasks: [
          { id: "s2-17", name: "Finalize GO Extended team", status: "completed", owner: "GOE" },
          { id: "s2-18", name: "Update extended team with full information", status: "completed", owner: "GOE" },
        ]},
        { name: "OE requirement locked", tasks: [
          { id: "s2-19", name: "Provide Prelim. schedule, fulfillment model, Supply Chain Resiliency Requirement and related documents.", status: "completed", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "s2-20", name: "Prepare Operations Engineering (OE) RFQ Package", status: "completed", owner: "GOE" },
          { id: "s2-21", name: "Finalize \"Define Phase Cost Bridge\" & commodity cost estimate", status: "completed", owner: "GOE" },
          { id: "s2-22", name: "Approve front end should have cost bridge", status: "completed", owner: "GOE" },
          { id: "s2-23", name: "Review FIN's cost projection", status: "completed", owner: "GOE" },
          { id: "s2-24", name: "Complete ODM RFQ package and pre-alignment", status: "completed", owner: "GOE", dataSources: ["Jira", "Confluence"] },
        ]},
        { name: "Mitigation plans formulated for early identified NUDDs", tasks: [
          { id: "s2-25", name: "Identify NUDDs and Initial Mitigation Plan", status: "completed", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
          { id: "s2-26", name: "Formulate ODM Improvement plan (New ODMs)", status: "completed", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
          { id: "s2-27", name: "Review and provide feedback on NUDDs", status: "completed", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
        ]},
        { name: "Additional NUDDs identified", tasks: [
          { id: "s2-28", name: "Update DFx Assessment", status: "completed", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
        ]},
        { name: "New test requirements identified", tasks: [
          { id: "s2-29", name: "Confirm draft ITM plan for the new program", status: "completed", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s2-30", name: "Upload Draft - New test Enablement Plan - A", status: "completed", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "s2-31", name: "Upload initial GTS/VM Inputs - A/C", status: "completed", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "s2-32", name: "Upload Location and Quantity - A/TI - P1", status: "completed", owner: "GOE", dataSources: ["Confluence", "PRD"] },
        ]},
        { name: "Relevant dependencies mapped (if applicable to Critical Transitions)", tasks: [
          { id: "s2-33", name: "Review product documentation (ex: EDD, ARD, FM), LLs, and predecessor platform data", status: "completed", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "s2-34", name: "Confirm alignment between FE team and GSM(?) on NUDD supply chain plan (critical for express lane)", status: "completed", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
          { id: "s2-35", name: "Approve front end IC & XLOB SSS list", status: "completed", owner: "GOE" },
        ]},
      ],
    },
    {
      name: "Plan", color: "bg-amber-500", status: "delayed",
      milestones: [
        { name: "Upload Plan Phase documents", tasks: [
          { id: "s2-36", name: "Send program kick-off communication with all attachments to extended teams", status: "on-track", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "s2-37", name: "Upload Plan Phase Exit Deck and approval minutes", status: "on-track", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "s2-38", name: "Define Plan Exit GOE Manager approval", status: "on-track", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "s2-39", name: "Upload Plan Phase Exit Deck", status: "on-track", owner: "GOE", dataSources: ["Confluence", "PRD"] },
        ]},
        { name: "WW FRC & RTO volume ramp plan locked", tasks: [
          { id: "s2-40", name: "Release Contract Book 1.0, update DPE with MYPO, and verify volume estimation", status: "on-track", owner: "GOE" },
          { id: "s2-41", name: "Define TTM target and lock RTS/RTO schedule", status: "on-track", owner: "GOE", dataSources: ["Jira", "Confluence"] },
        ]},
        { name: "Manufacturing plan confirmed", tasks: [
          { id: "s2-42", name: "Validate costed BOM and CS workbook against RTS carcass cost", status: "on-track", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "s2-43", name: "Validate tooling plan and complete tooling risk go decision", status: "on-track", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
          { id: "s2-44", name: "Confirm receipt of ME/XLOB PPE cost projections for BA POR", status: "at-risk", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s2-45", name: "Define PPAP schedule per CT recommendations", status: "at-risk", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s2-46", name: "Confirm critical part qualification schedule is included in platform backend schedule", status: "at-risk", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s2-47", name: "Upload ODM RFQ design proposal", status: "at-risk", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "s2-48", name: "Input last quarter QBR score", status: "at-risk", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s2-49", name: "Develop build and manufacturing plan and lock FRC date", status: "at-risk", owner: "GOE", dataSources: ["Jira", "Confluence"] },
        ]},
        { name: "WW fulfillment plan confirmed", tasks: [
          { id: "s2-50", name: "Consolidate SSS and BCP plan with XLOB GCM and review compliance attributes", status: "at-risk", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s2-51", name: "Review supply chain map and include it in PPE deck", status: "at-risk", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "s2-52", name: "Lock WW fulfillment/logistics model and provide expedite cost estimates", status: "at-risk", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s2-53", name: "Upload Supplier Chain Lead Time file", status: "at-risk", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "s2-54", name: "Upload fulfillment model and evaluate gaps", status: "at-risk", owner: "GOE", dataSources: ["Confluence", "PRD"] },
        ]},
        { name: "SQE MEDF Phase Gate #2 exited", tasks: [
          { id: "s2-55", name: "Record post-BA changes and link to Finance TCM document", status: "at-risk", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "s2-56", name: "Upload Supplier Maturity Assessment for new ODM onboarding", status: "at-risk", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "s2-57", name: "Validate ODM and sub-tier supplier audit schedules", status: "at-risk", owner: "GOE", dataSources: ["Jira", "Confluence"] },
        ]},
        { name: "KPI aligned (yield, quality, FIR & IFIR goals)", tasks: [
          { id: "s2-58", name: "Validate yield rate, RFQ volume, and complexity matrix with CT and provide tooling plan to Sourcing GCM", status: "at-risk", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s2-59", name: "Review attach rate by feature and include in complexity matrix", status: "at-risk", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s2-60", name: "Share complexity matrix with CT and ensure compliance with ACL guidance", status: "at-risk", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s2-61", name: "Calculate pre-BA score and confirm with CT", status: "at-risk", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s2-62", name: "Confirm joint review and feedback on BA recommendation", status: "at-risk", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s2-63", name: "Upload and submit GOE Pre-BA scorecard to CT", status: "at-risk", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "s2-64", name: "Define KPIs for Yield, Quality, FIR, and IFIR", status: "at-risk", owner: "GOE", dataSources: ["Jira", "Confluence"] },
        ]},
        { name: "DFx design plan locked", tasks: [
          { id: "s2-65", name: "Complete PDL assessment and confirm with CT", status: "at-risk", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
          { id: "s2-66", name: "Update product documentation for Plan Phase exit", status: "at-risk", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "s2-67", name: "Review and validate initial PH and BOM", status: "at-risk", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
          { id: "s2-68", name: "Review engineering drawings and mockups and provide feedback", status: "at-risk", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
          { id: "s2-69", name: "Continue DFx validation and update validation process", status: "at-risk", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
          { id: "s2-70", name: "Review prototype with operations and document feedback", status: "at-risk", owner: "GOE", dataSources: ["Confluence", "PRD"] },
        ]},
        { name: "NUDD mitigation plans locked", tasks: [
          { id: "s2-71", name: "Review and validate NUDD/DFMAA plan for risk mitigation", status: "at-risk", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
          { id: "s2-72", name: "Identify NUDDs, finalize mitigation plans, and define action plan", status: "at-risk", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
        ]},
        { name: "Development builds, Phase Gates, OLP schedule locked", tasks: [
          { id: "s2-73", name: "Upload overall operations schedule", status: "at-risk", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "s2-74", name: "Upload locked engineering schedule", status: "at-risk", owner: "GOE", dataSources: ["Confluence", "PRD"] },
        ]},
        { name: "Substitution matrix & restriction set up, order process assessed, IT tool set up", tasks: [
          { id: "s2-75", name: "Confirm order and platform data is maintained across IT tools", status: "at-risk", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "s2-76", name: "Review restriction rules and factory configuration with GOE", status: "at-risk", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "s2-77", name: "Complete test coverage analysis with ODM and Engineering", status: "at-risk", owner: "GOE", dataSources: ["Jira", "Confluence"] },
        ]},
      ],
    },
    {
      name: "Qual", color: "bg-orange-500", status: "not-started",
      milestones: [
        { name: "SQE MEDF Phase Gates #3,4,5,6 exited", tasks: [
          { id: "s2-78", name: "Complete PPAP on schedule for ME parts ramping", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s2-79", name: "Submit RTS approval request to VP of client procurement", status: "pending", owner: "GOE" },
          { id: "s2-80", name: "Complete ODM audit execution and reporting", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s2-81", name: "Complete sub-tier supplier audits for key components", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s2-82", name: "Submit GOE recommendation to exit Qual phase", status: "pending", owner: "GOE" },
          { id: "s2-83", name: "Complete CCC FM & OM ITM1/ITM2 readiness and execution", status: "pending", owner: "GOE" },
        ]},
        { name: "DVT1, DVT2 builds completed, goals met, issues captured, action plan in place", tasks: [
          { id: "s2-84", name: "Lock DVT2 OPS demand to confirmed volumes", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s2-85", name: "Lock Pilot CTO demand to confirmed volumes", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s2-86", name: "Kick off DVT2 ops build material preparation", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s2-87", name: "Confirm Golden config & demand are complete; material ETA on time", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "s2-88", name: "Approve ODM DVT1 build entry", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s2-89", name: "Approve ODM DVT1 build exit", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s2-90", name: "Approve ODM DVT1.x build entry", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s2-91", name: "Approve ODM DVT1.x build exit", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s2-92", name: "Approve ODM DVT2 build entry", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s2-93", name: "Approve ODM DVT2 build exit", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s2-94", name: "Approve ODM DVT2.x build entry", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s2-95", name: "Approve ODM DVT2.x build exit", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s2-96", name: "Approve regression build entry readiness", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s2-97", name: "Complete regression build with issue disposition plan", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s2-98", name: "Complete PVB builds with systems and GAFPs validated", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s2-99", name: "Execute and monitor DVT2 OPS builds", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s2-100", name: "Conduct daily build review and track progress", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s2-101", name: "Complete post-build exit review", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s2-102", name: "Confirm build completion and output readiness", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s2-103", name: "Capture issues and ensure actions are in place", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
        ]},
        { name: "VH, H & M NUDDs closed", tasks: [
          { id: "s2-104", name: "Review and mitigate single/sole source risk", status: "pending", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
          { id: "s2-105", name: "Consolidate SSS and BCP plan with XLOB GCM", status: "pending", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
          { id: "s2-106", name: "Trigger event management if required", status: "pending", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
          { id: "s2-107", name: "Continue DFx validation and close findings in Jira", status: "pending", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
          { id: "s2-108", name: "Execute and close NUDD mitigation plans", status: "pending", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
        ]},
        { name: "Ops requirements on required design changes aligned", tasks: [
          { id: "s2-109", name: "Complete platform health check", status: "pending", owner: "GOE" },
          { id: "s2-110", name: "Review and trigger multiple tooling plan to execution", status: "pending", owner: "GOE" },
          { id: "s2-111", name: "Review Original Design Manufacturer tooling plan", status: "pending", owner: "GOE" },
          { id: "s2-112", name: "Complete Mid DD single tooling and SSS review", status: "pending", owner: "GOE" },
          { id: "s2-113", name: "Provide WWP BOM creation guidance", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "s2-114", name: "Submit PH/X-rev mod and ensure D2 code readiness", status: "pending", owner: "GOE" },
          { id: "s2-115", name: "Release Panel ER and NPRR on schedule", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s2-116", name: "Review DFM status and confirm client approval", status: "pending", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
          { id: "s2-117", name: "Validate FGA BOM structure accuracy", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "s2-118", name: "Generate and review platform matrix with extended team", status: "pending", owner: "GOE" },
          { id: "s2-119", name: "Confirm clean build results and closure of development changes", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s2-120", name: "Provide BOM attributes and packaging details", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
        ]},
        { name: "Manufacturing test coverage validated, design health checks completed", tasks: [
          { id: "s2-121", name: "Confirm L10 material Is complete", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s2-122", name: "Confirm DVT2 ops (SMT and L10) material is complete", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s2-123", name: "Confirm Pilot CTO material ETA is on schedule", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s2-124", name: "Prepare Pilot CTO MRA to readiness state", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s2-125", name: "Review ME pilot build safe launch report to confirm readiness", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s2-126", name: "Review first GDS report", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s2-127", name: "Validate test coverage and complete design health checks", status: "pending", owner: "GOE" },
          { id: "s2-128", name: "Ensure MRA readiness for qualification builds", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s2-129", name: "Complete RTB checklist before build start", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s2-130", name: "Review ODM build activity and exit status", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s2-131", name: "Confirm MRA materials availability before build", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s2-132", name: "Upload test and SW GAFPs before build", status: "pending", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "s2-133", name: "Ensure MRA readiness for pilot build", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
        ]},
        { name: "BOM mapping finalized", tasks: [
          { id: "s2-134", name: "Align CCI BOM structure for audit readiness", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "s2-135", name: "Upload and maintain MOD list in NPI tool", status: "pending", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "s2-136", name: "Create and validate DVT2 MOD configurations", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "s2-137", name: "Generate and validate qualification order configurations", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "s2-138", name: "Generate and validate pilot order configurations", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "s2-139", name: "Confirm SKU readiness in systems for PLS orders", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "s2-140", name: "Submit ship order configuration into Jet", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
        ]},
        { name: "Substitution matrix & restriction set up, order process assessed, IT tool set up", tasks: [
          { id: "s2-141", name: "Lock RTS and PVT demand to confirmed volumes", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "s2-142", name: "Shape RTS demand to align with supply constraints", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "s2-143", name: "Trigger demand signal schedule for long L/T parts", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "s2-144", name: "Determine supply control limit based on ACP commitment", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "s2-145", name: "Confirm FHC MRP readiness", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "s2-146", name: "Confirm ARC MRP readiness", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "s2-147", name: "Load MRP with PVT demand", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "s2-148", name: "Provide long lead time ARC list", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "s2-149", name: "Prepare FHC MBP and PVT load to readiness state", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "s2-150", name: "Confirm FHC readiness", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "s2-151", name: "Confirm FGA readiness", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "s2-152", name: "Confirm GCM parts cost is loaded correctly", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "s2-153", name: "Prepare BCC MRA for GCM cost loading", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "s2-154", name: "Confirm all PO cost is loaded for ST CTO build", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "s2-155", name: "Confirm WW fulfillment/logistics mode", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "s2-156", name: "Complete MPP review to confirm volume commitment is >= 75% of RFQ volume", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "s2-157", name: "Confirm UPP loading attainment is 75% of platform BC", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "s2-158", name: "Confirm packaging material is ready with L10 and BE & packaging team", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "s2-159", name: "Upload OBE instructions for build execution", status: "pending", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "s2-160", name: "Download DVT2 build orders to factory", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "s2-161", name: "Configure and validate GRR restriction rules", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "s2-162", name: "Validate operations readiness for pilot execution", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "s2-163", name: "Confirm operation plan execution status", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "s2-164", name: "Review NPI production and supply chain performance reports", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s2-165", name: "Validate order fulfillment readiness for pilot", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "s2-166", name: "Complete HWC setup for production readiness", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "s2-167", name: "Review GRR list and restriction rules", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "s2-168", name: "Download and acknowledge pilot/PLS orders by factories", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
        ]},
      ],
    },
    {
      name: "Pilot", color: "bg-teal-500", status: "not-started",
      milestones: [
        { name: "Supply & Demand readiness confirmed", tasks: [
          { id: "s2-169", name: "Define DSI goal and FGI position", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s2-170", name: "Confirm MRA materials available before build", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s2-171", name: "Confirm DSI goal and FGI position achieved", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s2-172", name: "Review RTS material supportability at T-1", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
        ]},
        { name: "Operational & Fulfillment readiness confirmed", tasks: [
          { id: "s2-173", name: "Confirm operations readiness for pilot execution", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s2-174", name: "Confirm order fulfillment readiness for pilot", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "s2-175", name: "Confirm pilot order software and test readiness", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "s2-176", name: "Generate pilot orders", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "s2-177", name: "Send pilot orders to ODM/client factory for build", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s2-178", name: "Complete APJ FRC", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s2-179", name: "Complete EMEA FRC", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s2-180", name: "Complete DAO FRC", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s2-181", name: "Complete WW FRC", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s2-182", name: "Define and implement order process improvements", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "s2-183", name: "Maintain and update tool rules and configurations", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
        ]},
        { name: "Issue Closure & Quality Stabilization", tasks: [
          { id: "s2-184", name: "Complete DFx activities and close all findings", status: "pending", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
          { id: "s2-185", name: "Close all NUDDs with mitigation completed", status: "pending", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
          { id: "s2-186", name: "Confirm issues and excursions are tracked and resolved", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s2-187", name: "Identify and reduce illegal orders with corrective actions", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "s2-188", name: "Review and approve WWP deviation setup in Agile", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s2-189", name: "Monitor FPY and safe launch metrics against targets", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
        ]},
        { name: "Governance, Approval & Phase Closure", tasks: [
          { id: "s2-190", name: "Upload Develop Phase Exit documentation and approval", status: "pending", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "s2-191", name: "Upload Launch Phase Exit documentation and approval", status: "pending", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "s2-192", name: "Close development stage and document lessons learned", status: "pending", owner: "GOE", dataSources: ["Confluence", "PRD"] },
        ]},
        { name: "Build Execution & Completion", tasks: [
          { id: "s2-193", name: "Execute and monitor pilot build to completion", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s2-194", name: "Confirm PVT build is completed", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s2-195", name: "Confirm pilot completion from ODM and client factory", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s2-196", name: "Complete first block execution", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
        ]},
      ],
    },
  ],

  "Server 3": [
    {
      name: "Concept", color: "bg-blue-500", status: "on-track",
      milestones: [
        { name: "Concept Phase documents uploaded (added)", tasks: [
          { id: "s3-0", name: "Upload Program Charter", status: "completed", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "s3-1", name: "Upload Feature Matrix/List (MVP/Backlog) / Roadmap", status: "completed", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "s3-2", name: "Confirm PRD / Marketing info has been ingested", status: "completed", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "s3-3", name: "Confirm EDD has been ingested", status: "completed", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "s3-4", name: "Confirm ARD has been ingested", status: "completed", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "s3-5", name: "Upload Innovation Story", status: "completed", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "s3-6", name: "Upload Lessons Learned", status: "completed", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "s3-7", name: "Upload Concept Phase exit Deck", status: "completed", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "s3-8", name: "Approve Concept Phase Exit deck", status: "completed", owner: "GOE", dataSources: ["Confluence", "PRD"] },
        ]},
        { name: "Initial extended team formed", tasks: [
          { id: "s3-9", name: "Intiate Extended Team formation", status: "completed", owner: "GOE" },
        ]},
        { name: "Early end 2 end supply chain NUDD identified", tasks: [
          { id: "s3-10", name: "Conduct ODM supplier assessment prior to BA", status: "completed", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
          { id: "s3-11", name: "Gather CAPEX requirements for WW NPI", status: "completed", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
        ]},
        { name: "Early DFx NUDD identified", tasks: [
          { id: "s3-12", name: "Future technology Risk Assessment", status: "completed", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
          { id: "s3-13", name: "Conduct DFx assessment & Eng engagement", status: "completed", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
          { id: "s3-14", name: "Populate all NUDDS in NUDD tool", status: "completed", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
        ]},
        { name: "ODM improvement plan formulated (new ODM only)", tasks: [
          { id: "s3-15", name: "Formulate ODM Improvement plan (New ODMs)", status: "completed", owner: "GOE", dataSources: ["Jira", "Confluence"] },
        ]},
      ],
    },
    {
      name: "Define", color: "bg-emerald-500", status: "on-track",
      milestones: [
        { name: "Upload Define Phase documents", tasks: [
          { id: "s3-16", name: "Upload PG Documentation and approval of CPE", status: "completed", owner: "GOE", dataSources: ["Confluence", "PRD"] },
        ]},
        { name: "Extended team expanded & finalized", tasks: [
          { id: "s3-17", name: "Finalize GO Extended team", status: "completed", owner: "GOE" },
          { id: "s3-18", name: "Update extended team with full information", status: "completed", owner: "GOE" },
        ]},
        { name: "OE requirement locked", tasks: [
          { id: "s3-19", name: "Provide Prelim. schedule, fulfillment model, Supply Chain Resiliency Requirement and related documents.", status: "completed", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "s3-20", name: "Prepare Operations Engineering (OE) RFQ Package", status: "completed", owner: "GOE" },
          { id: "s3-21", name: "Finalize \"Define Phase Cost Bridge\" & commodity cost estimate", status: "completed", owner: "GOE" },
          { id: "s3-22", name: "Approve front end should have cost bridge", status: "completed", owner: "GOE" },
          { id: "s3-23", name: "Review FIN's cost projection", status: "completed", owner: "GOE" },
          { id: "s3-24", name: "Complete ODM RFQ package and pre-alignment", status: "completed", owner: "GOE", dataSources: ["Jira", "Confluence"] },
        ]},
        { name: "Mitigation plans formulated for early identified NUDDs", tasks: [
          { id: "s3-25", name: "Identify NUDDs and Initial Mitigation Plan", status: "completed", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
          { id: "s3-26", name: "Formulate ODM Improvement plan (New ODMs)", status: "completed", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
          { id: "s3-27", name: "Review and provide feedback on NUDDs", status: "completed", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
        ]},
        { name: "Additional NUDDs identified", tasks: [
          { id: "s3-28", name: "Update DFx Assessment", status: "completed", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
        ]},
        { name: "New test requirements identified", tasks: [
          { id: "s3-29", name: "Confirm draft ITM plan for the new program", status: "completed", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s3-30", name: "Upload Draft - New test Enablement Plan - A", status: "completed", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "s3-31", name: "Upload initial GTS/VM Inputs - A/C", status: "completed", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "s3-32", name: "Upload Location and Quantity - A/TI - P1", status: "completed", owner: "GOE", dataSources: ["Confluence", "PRD"] },
        ]},
        { name: "Relevant dependencies mapped (if applicable to Critical Transitions)", tasks: [
          { id: "s3-33", name: "Review product documentation (ex: EDD, ARD, FM), LLs, and predecessor platform data", status: "completed", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "s3-34", name: "Confirm alignment between FE team and GSM(?) on NUDD supply chain plan (critical for express lane)", status: "completed", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
          { id: "s3-35", name: "Approve front end IC & XLOB SSS list", status: "completed", owner: "GOE" },
        ]},
      ],
    },
    {
      name: "Plan", color: "bg-amber-500", status: "delayed",
      milestones: [
        { name: "Upload Plan Phase documents", tasks: [
          { id: "s3-36", name: "Send program kick-off communication with all attachments to extended teams", status: "late", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "s3-37", name: "Upload Plan Phase Exit Deck and approval minutes", status: "late", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "s3-38", name: "Define Plan Exit GOE Manager approval", status: "late", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "s3-39", name: "Upload Plan Phase Exit Deck", status: "late", owner: "GOE", dataSources: ["Confluence", "PRD"] },
        ]},
        { name: "WW FRC & RTO volume ramp plan locked", tasks: [
          { id: "s3-40", name: "Release Contract Book 1.0, update DPE with MYPO, and verify volume estimation", status: "late", owner: "GOE" },
          { id: "s3-41", name: "Define TTM target and lock RTS/RTO schedule", status: "late", owner: "GOE", dataSources: ["Jira", "Confluence"] },
        ]},
        { name: "Manufacturing plan confirmed", tasks: [
          { id: "s3-42", name: "Validate costed BOM and CS workbook against RTS carcass cost", status: "late", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "s3-43", name: "Validate tooling plan and complete tooling risk go decision", status: "late", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
          { id: "s3-44", name: "Confirm receipt of ME/XLOB PPE cost projections for BA POR", status: "late", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s3-45", name: "Define PPAP schedule per CT recommendations", status: "late", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s3-46", name: "Confirm critical part qualification schedule is included in platform backend schedule", status: "late", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s3-47", name: "Upload ODM RFQ design proposal", status: "late", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "s3-48", name: "Input last quarter QBR score", status: "late", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s3-49", name: "Develop build and manufacturing plan and lock FRC date", status: "late", owner: "GOE", dataSources: ["Jira", "Confluence"] },
        ]},
        { name: "WW fulfillment plan confirmed", tasks: [
          { id: "s3-50", name: "Consolidate SSS and BCP plan with XLOB GCM and review compliance attributes", status: "late", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s3-51", name: "Review supply chain map and include it in PPE deck", status: "late", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "s3-52", name: "Lock WW fulfillment/logistics model and provide expedite cost estimates", status: "late", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s3-53", name: "Upload Supplier Chain Lead Time file", status: "late", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "s3-54", name: "Upload fulfillment model and evaluate gaps", status: "late", owner: "GOE", dataSources: ["Confluence", "PRD"] },
        ]},
        { name: "SQE MEDF Phase Gate #2 exited", tasks: [
          { id: "s3-55", name: "Record post-BA changes and link to Finance TCM document", status: "late", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "s3-56", name: "Upload Supplier Maturity Assessment for new ODM onboarding", status: "late", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "s3-57", name: "Validate ODM and sub-tier supplier audit schedules", status: "late", owner: "GOE", dataSources: ["Jira", "Confluence"] },
        ]},
        { name: "KPI aligned (yield, quality, FIR & IFIR goals)", tasks: [
          { id: "s3-58", name: "Validate yield rate, RFQ volume, and complexity matrix with CT and provide tooling plan to Sourcing GCM", status: "late", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s3-59", name: "Review attach rate by feature and include in complexity matrix", status: "late", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s3-60", name: "Share complexity matrix with CT and ensure compliance with ACL guidance", status: "late", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s3-61", name: "Calculate pre-BA score and confirm with CT", status: "late", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s3-62", name: "Confirm joint review and feedback on BA recommendation", status: "late", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s3-63", name: "Upload and submit GOE Pre-BA scorecard to CT", status: "late", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "s3-64", name: "Define KPIs for Yield, Quality, FIR, and IFIR", status: "late", owner: "GOE", dataSources: ["Jira", "Confluence"] },
        ]},
        { name: "DFx design plan locked", tasks: [
          { id: "s3-65", name: "Complete PDL assessment and confirm with CT", status: "late", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
          { id: "s3-66", name: "Update product documentation for Plan Phase exit", status: "late", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "s3-67", name: "Review and validate initial PH and BOM", status: "late", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
          { id: "s3-68", name: "Review engineering drawings and mockups and provide feedback", status: "late", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
          { id: "s3-69", name: "Continue DFx validation and update validation process", status: "late", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
          { id: "s3-70", name: "Review prototype with operations and document feedback", status: "late", owner: "GOE", dataSources: ["Confluence", "PRD"] },
        ]},
        { name: "NUDD mitigation plans locked", tasks: [
          { id: "s3-71", name: "Review and validate NUDD/DFMAA plan for risk mitigation", status: "late", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
          { id: "s3-72", name: "Identify NUDDs, finalize mitigation plans, and define action plan", status: "late", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
        ]},
        { name: "Development builds, Phase Gates, OLP schedule locked", tasks: [
          { id: "s3-73", name: "Upload overall operations schedule", status: "late", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "s3-74", name: "Upload locked engineering schedule", status: "late", owner: "GOE", dataSources: ["Confluence", "PRD"] },
        ]},
        { name: "Substitution matrix & restriction set up, order process assessed, IT tool set up", tasks: [
          { id: "s3-75", name: "Confirm order and platform data is maintained across IT tools", status: "late", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "s3-76", name: "Review restriction rules and factory configuration with GOE", status: "late", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "s3-77", name: "Complete test coverage analysis with ODM and Engineering", status: "late", owner: "GOE", dataSources: ["Jira", "Confluence"] },
        ]},
      ],
    },
    {
      name: "Qual", color: "bg-orange-500", status: "not-started",
      milestones: [
        { name: "SQE MEDF Phase Gates #3,4,5,6 exited", tasks: [
          { id: "s3-78", name: "Complete PPAP on schedule for ME parts ramping", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s3-79", name: "Submit RTS approval request to VP of client procurement", status: "pending", owner: "GOE" },
          { id: "s3-80", name: "Complete ODM audit execution and reporting", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s3-81", name: "Complete sub-tier supplier audits for key components", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s3-82", name: "Submit GOE recommendation to exit Qual phase", status: "pending", owner: "GOE" },
          { id: "s3-83", name: "Complete CCC FM & OM ITM1/ITM2 readiness and execution", status: "pending", owner: "GOE" },
        ]},
        { name: "DVT1, DVT2 builds completed, goals met, issues captured, action plan in place", tasks: [
          { id: "s3-84", name: "Lock DVT2 OPS demand to confirmed volumes", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s3-85", name: "Lock Pilot CTO demand to confirmed volumes", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s3-86", name: "Kick off DVT2 ops build material preparation", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s3-87", name: "Confirm Golden config & demand are complete; material ETA on time", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "s3-88", name: "Approve ODM DVT1 build entry", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s3-89", name: "Approve ODM DVT1 build exit", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s3-90", name: "Approve ODM DVT1.x build entry", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s3-91", name: "Approve ODM DVT1.x build exit", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s3-92", name: "Approve ODM DVT2 build entry", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s3-93", name: "Approve ODM DVT2 build exit", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s3-94", name: "Approve ODM DVT2.x build entry", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s3-95", name: "Approve ODM DVT2.x build exit", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s3-96", name: "Approve regression build entry readiness", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s3-97", name: "Complete regression build with issue disposition plan", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s3-98", name: "Complete PVB builds with systems and GAFPs validated", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s3-99", name: "Execute and monitor DVT2 OPS builds", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s3-100", name: "Conduct daily build review and track progress", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s3-101", name: "Complete post-build exit review", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s3-102", name: "Confirm build completion and output readiness", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s3-103", name: "Capture issues and ensure actions are in place", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
        ]},
        { name: "VH, H & M NUDDs closed", tasks: [
          { id: "s3-104", name: "Review and mitigate single/sole source risk", status: "pending", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
          { id: "s3-105", name: "Consolidate SSS and BCP plan with XLOB GCM", status: "pending", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
          { id: "s3-106", name: "Trigger event management if required", status: "pending", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
          { id: "s3-107", name: "Continue DFx validation and close findings in Jira", status: "pending", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
          { id: "s3-108", name: "Execute and close NUDD mitigation plans", status: "pending", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
        ]},
        { name: "Ops requirements on required design changes aligned", tasks: [
          { id: "s3-109", name: "Complete platform health check", status: "pending", owner: "GOE" },
          { id: "s3-110", name: "Review and trigger multiple tooling plan to execution", status: "pending", owner: "GOE" },
          { id: "s3-111", name: "Review Original Design Manufacturer tooling plan", status: "pending", owner: "GOE" },
          { id: "s3-112", name: "Complete Mid DD single tooling and SSS review", status: "pending", owner: "GOE" },
          { id: "s3-113", name: "Provide WWP BOM creation guidance", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "s3-114", name: "Submit PH/X-rev mod and ensure D2 code readiness", status: "pending", owner: "GOE" },
          { id: "s3-115", name: "Release Panel ER and NPRR on schedule", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s3-116", name: "Review DFM status and confirm client approval", status: "pending", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
          { id: "s3-117", name: "Validate FGA BOM structure accuracy", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "s3-118", name: "Generate and review platform matrix with extended team", status: "pending", owner: "GOE" },
          { id: "s3-119", name: "Confirm clean build results and closure of development changes", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s3-120", name: "Provide BOM attributes and packaging details", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
        ]},
        { name: "Manufacturing test coverage validated, design health checks completed", tasks: [
          { id: "s3-121", name: "Confirm L10 material Is complete", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s3-122", name: "Confirm DVT2 ops (SMT and L10) material is complete", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s3-123", name: "Confirm Pilot CTO material ETA is on schedule", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s3-124", name: "Prepare Pilot CTO MRA to readiness state", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s3-125", name: "Review ME pilot build safe launch report to confirm readiness", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s3-126", name: "Review first GDS report", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s3-127", name: "Validate test coverage and complete design health checks", status: "pending", owner: "GOE" },
          { id: "s3-128", name: "Ensure MRA readiness for qualification builds", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s3-129", name: "Complete RTB checklist before build start", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s3-130", name: "Review ODM build activity and exit status", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s3-131", name: "Confirm MRA materials availability before build", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s3-132", name: "Upload test and SW GAFPs before build", status: "pending", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "s3-133", name: "Ensure MRA readiness for pilot build", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
        ]},
        { name: "BOM mapping finalized", tasks: [
          { id: "s3-134", name: "Align CCI BOM structure for audit readiness", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "s3-135", name: "Upload and maintain MOD list in NPI tool", status: "pending", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "s3-136", name: "Create and validate DVT2 MOD configurations", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "s3-137", name: "Generate and validate qualification order configurations", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "s3-138", name: "Generate and validate pilot order configurations", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "s3-139", name: "Confirm SKU readiness in systems for PLS orders", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "s3-140", name: "Submit ship order configuration into Jet", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
        ]},
        { name: "Substitution matrix & restriction set up, order process assessed, IT tool set up", tasks: [
          { id: "s3-141", name: "Lock RTS and PVT demand to confirmed volumes", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "s3-142", name: "Shape RTS demand to align with supply constraints", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "s3-143", name: "Trigger demand signal schedule for long L/T parts", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "s3-144", name: "Determine supply control limit based on ACP commitment", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "s3-145", name: "Confirm FHC MRP readiness", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "s3-146", name: "Confirm ARC MRP readiness", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "s3-147", name: "Load MRP with PVT demand", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "s3-148", name: "Provide long lead time ARC list", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "s3-149", name: "Prepare FHC MBP and PVT load to readiness state", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "s3-150", name: "Confirm FHC readiness", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "s3-151", name: "Confirm FGA readiness", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "s3-152", name: "Confirm GCM parts cost is loaded correctly", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "s3-153", name: "Prepare BCC MRA for GCM cost loading", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "s3-154", name: "Confirm all PO cost is loaded for ST CTO build", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "s3-155", name: "Confirm WW fulfillment/logistics mode", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "s3-156", name: "Complete MPP review to confirm volume commitment is >= 75% of RFQ volume", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "s3-157", name: "Confirm UPP loading attainment is 75% of platform BC", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "s3-158", name: "Confirm packaging material is ready with L10 and BE & packaging team", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "s3-159", name: "Upload OBE instructions for build execution", status: "pending", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "s3-160", name: "Download DVT2 build orders to factory", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "s3-161", name: "Configure and validate GRR restriction rules", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "s3-162", name: "Validate operations readiness for pilot execution", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "s3-163", name: "Confirm operation plan execution status", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "s3-164", name: "Review NPI production and supply chain performance reports", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s3-165", name: "Validate order fulfillment readiness for pilot", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "s3-166", name: "Complete HWC setup for production readiness", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "s3-167", name: "Review GRR list and restriction rules", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "s3-168", name: "Download and acknowledge pilot/PLS orders by factories", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
        ]},
      ],
    },
    {
      name: "Pilot", color: "bg-teal-500", status: "not-started",
      milestones: [
        { name: "Supply & Demand readiness confirmed", tasks: [
          { id: "s3-169", name: "Define DSI goal and FGI position", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s3-170", name: "Confirm MRA materials available before build", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s3-171", name: "Confirm DSI goal and FGI position achieved", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s3-172", name: "Review RTS material supportability at T-1", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
        ]},
        { name: "Operational & Fulfillment readiness confirmed", tasks: [
          { id: "s3-173", name: "Confirm operations readiness for pilot execution", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s3-174", name: "Confirm order fulfillment readiness for pilot", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "s3-175", name: "Confirm pilot order software and test readiness", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "s3-176", name: "Generate pilot orders", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "s3-177", name: "Send pilot orders to ODM/client factory for build", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s3-178", name: "Complete APJ FRC", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s3-179", name: "Complete EMEA FRC", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s3-180", name: "Complete DAO FRC", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s3-181", name: "Complete WW FRC", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s3-182", name: "Define and implement order process improvements", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "s3-183", name: "Maintain and update tool rules and configurations", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
        ]},
        { name: "Issue Closure & Quality Stabilization", tasks: [
          { id: "s3-184", name: "Complete DFx activities and close all findings", status: "pending", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
          { id: "s3-185", name: "Close all NUDDs with mitigation completed", status: "pending", owner: "GOE", dataSources: ["Memory Matrix", "Jira"] },
          { id: "s3-186", name: "Confirm issues and excursions are tracked and resolved", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s3-187", name: "Identify and reduce illegal orders with corrective actions", status: "pending", owner: "GOE", dataSources: ["SAP", "Jira"] },
          { id: "s3-188", name: "Review and approve WWP deviation setup in Agile", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s3-189", name: "Monitor FPY and safe launch metrics against targets", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
        ]},
        { name: "Governance, Approval & Phase Closure", tasks: [
          { id: "s3-190", name: "Upload Develop Phase Exit documentation and approval", status: "pending", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "s3-191", name: "Upload Launch Phase Exit documentation and approval", status: "pending", owner: "GOE", dataSources: ["Confluence", "PRD"] },
          { id: "s3-192", name: "Close development stage and document lessons learned", status: "pending", owner: "GOE", dataSources: ["Confluence", "PRD"] },
        ]},
        { name: "Build Execution & Completion", tasks: [
          { id: "s3-193", name: "Execute and monitor pilot build to completion", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s3-194", name: "Confirm PVT build is completed", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s3-195", name: "Confirm pilot completion from ODM and client factory", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
          { id: "s3-196", name: "Complete first block execution", status: "pending", owner: "GOE", dataSources: ["Jira", "Confluence"] },
        ]},
      ],
    },
  ],

  "Laptop 5": [
    {
      name: "Concept", color: "bg-blue-500", status: "on-track",
      milestones: [
        { name: "Concept Phase documents uploaded", tasks: [
          { id: "l5-0", name: "Upload Program Charter", status: "completed", owner: "GOE" },
          { id: "l5-1", name: "Upload Feature Matrix/List", status: "completed", owner: "GOE",
      dependencies: ["l5-0"],
    },
          { id: "l5-2", name: "Confirm PRD ingested", status: "completed", owner: "GOE",
      dependencies: ["l5-0"],
    },
          { id: "l5-3", name: "Upload Innovation Story", status: "completed", owner: "GOE",
      dependencies: ["l5-2"],
    },
          { id: "l5-4", name: "Upload Concept Phase exit Deck", status: "completed", owner: "GOE",
      dependencies: ["l5-2"],
    },
        ]},
        { name: "Initial extended team formed", tasks: [
          { id: "l5-5", name: "Initiate Extended Team formation", status: "completed", owner: "GOE" },
        ]},
        { name: "Early supply chain NUDD identified", tasks: [
          { id: "l5-6", name: "Conduct ODM supplier assessment", status: "completed", owner: "GOE" },
          { id: "l5-7", name: "Gather CAPEX requirements", status: "completed", owner: "GOE",
      dependencies: ["l5-5", "l5-6"],
    },
        ]},
      ],
    },
    {
      name: "Define", color: "bg-emerald-500", status: "on-track",
      milestones: [
        { name: "Upload Define Phase documents", tasks: [
          { id: "l5-8", name: "Upload PG Documentation", status: "completed", owner: "GOE",
      dependencies: ["l5-7"],
    },
        ]},
        { name: "Extended team expanded", tasks: [
          { id: "l5-9", name: "Finalize GO Extended team", status: "completed", owner: "GOE" },
          { id: "l5-10", name: "Update extended team info", status: "on-track", owner: "GOE",
      dependencies: ["l5-9"],
    },
        ]},
        { name: "OE requirement locked", tasks: [
          { id: "l5-11", name: "Provide Prelim schedule", status: "on-track", owner: "GOE",
      dependencies: ["l5-9"],
    },
          { id: "l5-12", name: "Prepare OE RFQ Package", status: "on-track", owner: "GOE" },
          { id: "l5-13", name: "Finalize Define Phase Cost Bridge", status: "pending", owner: "GOE",
      dependencies: ["l5-12"],
    },
        ]},
      ],
    },
    {
      name: "Plan", color: "bg-amber-500", status: "not-started",
      milestones: [
        { name: "Upload Plan Phase documents", tasks: [
          { id: "l5-14", name: "Send program kick-off communication", status: "pending", owner: "GOE",
      dependencies: ["l5-12", "l5-13"],
    },
          { id: "l5-15", name: "Upload Plan Phase Exit Deck", status: "pending", owner: "GOE" },
        ]},
        { name: "Manufacturing plan confirmed", tasks: [
          { id: "l5-16", name: "Validate costed BOM", status: "pending", owner: "GOE" },
          { id: "l5-17", name: "Validate tooling plan", status: "pending", owner: "GOE" },
          { id: "l5-18", name: "Develop build and manufacturing plan", status: "pending", owner: "GOE" },
        ]},
        { name: "KPI aligned", tasks: [
          { id: "l5-19", name: "Define KPIs for Yield and Quality", status: "pending", owner: "GOE" },
          { id: "l5-20", name: "Calculate pre-BA score", status: "pending", owner: "GOE" },
        ]},
      ],
    },
    {
      name: "Qual", color: "bg-purple-500", status: "not-started",
      milestones: [
        { name: "Build readiness confirmed", tasks: [
          { id: "l5-21", name: "Validate test coverage", status: "pending", owner: "GOE" },
          { id: "l5-22", name: "Complete RTB checklist", status: "pending", owner: "GOE" },
          { id: "l5-23", name: "Ensure MRA readiness", status: "pending", owner: "GOE" },
        ]},
      ],
    },
    {
      name: "Pilot", color: "bg-teal-500", status: "not-started",
      milestones: [
        { name: "Supply & Demand readiness", tasks: [
          { id: "l5-24", name: "Define DSI goal", status: "pending", owner: "GOE" },
          { id: "l5-25", name: "Confirm MRA materials", status: "pending", owner: "GOE" },
        ]},
        { name: "Build Execution", tasks: [
          { id: "l5-26", name: "Execute pilot build", status: "pending", owner: "GOE" },
          { id: "l5-27", name: "Confirm PVT build completed", status: "pending", owner: "GOE" },
        ]},
      ],
    },
  ],

  "Laptop 6": [
    {
      name: "Concept", color: "bg-blue-500", status: "on-track",
      milestones: [
        { name: "Concept Phase documents uploaded", tasks: [
          { id: "l6-0", name: "Upload Program Charter", status: "completed", owner: "GOE" },
          { id: "l6-1", name: "Upload Feature Matrix", status: "completed", owner: "GOE",
      dependencies: ["l6-0"],
    },
          { id: "l6-2", name: "Confirm PRD ingested", status: "completed", owner: "GOE",
      dependencies: ["l6-0"],
    },
          { id: "l6-3", name: "Upload Concept Phase exit Deck", status: "completed", owner: "GOE",
      dependencies: ["l6-2"],
    },
        ]},
        { name: "Early DFx NUDD identified", tasks: [
          { id: "l6-4", name: "Future technology Risk Assessment", status: "completed", owner: "GOE",
      dependencies: ["l6-2"],
    },
          { id: "l6-5", name: "Conduct DFx assessment", status: "completed", owner: "GOE" },
          { id: "l6-6", name: "Populate NUDDs", status: "completed", owner: "GOE" },
        ]},
      ],
    },
    {
      name: "Define", color: "bg-emerald-500", status: "on-track",
      milestones: [
        { name: "Upload Define Phase documents", tasks: [
          { id: "l6-7", name: "Upload PG Documentation", status: "completed", owner: "GOE",
      dependencies: ["l6-5", "l6-6"],
    },
        ]},
        { name: "Extended team finalized", tasks: [
          { id: "l6-8", name: "Finalize GO Extended team", status: "completed", owner: "GOE",
      dependencies: ["l6-7"],
    },
          { id: "l6-9", name: "Update extended team info", status: "completed", owner: "GOE" },
        ]},
        { name: "OE requirement locked", tasks: [
          { id: "l6-10", name: "Provide Prelim schedule", status: "completed", owner: "GOE",
      dependencies: ["l6-9"],
    },
          { id: "l6-11", name: "Prepare OE RFQ Package", status: "completed", owner: "GOE",
      dependencies: ["l6-9"],
    },
          { id: "l6-12", name: "Finalize Define Phase Cost Bridge", status: "completed", owner: "GOE" },
          { id: "l6-13", name: "Review FIN cost projection", status: "completed", owner: "GOE",
      dependencies: ["l6-12"],
    },
        ]},
        { name: "Mitigation plans formulated", tasks: [
          { id: "l6-14", name: "Identify NUDDs and Initial Mitigation", status: "completed", owner: "GOE",
      dependencies: ["l6-12", "l6-13"],
    },
          { id: "l6-15", name: "Review and provide feedback on NUDDs", status: "completed", owner: "GOE" },
        ]},
      ],
    },
    {
      name: "Plan", color: "bg-amber-500", status: "on-track",
      milestones: [
        { name: "Upload Plan Phase documents", tasks: [
          { id: "l6-16", name: "Send program kick-off communication", status: "completed", owner: "GOE" },
          { id: "l6-17", name: "Upload Plan Phase Exit Deck", status: "completed", owner: "GOE" },
        ]},
        { name: "Manufacturing plan confirmed", tasks: [
          { id: "l6-18", name: "Validate costed BOM", status: "completed", owner: "GOE" },
          { id: "l6-19", name: "Develop build plan", status: "completed", owner: "GOE" },
          { id: "l6-20", name: "Lock FRC date", status: "completed", owner: "GOE" },
        ]},
      ],
    },
    {
      name: "Qual", color: "bg-purple-500", status: "at-risk",
      milestones: [
        { name: "Build readiness confirmed", tasks: [
          { id: "l6-21", name: "Validate test coverage", status: "completed", owner: "GOE" },
          { id: "l6-22", name: "Complete RTB checklist", status: "completed", owner: "GOE" },
          { id: "l6-23", name: "Ensure MRA readiness", status: "on-track", owner: "GOE" },
          { id: "l6-24", name: "Review ODM build activity", status: "on-track", owner: "GOE" },
        ]},
        { name: "BOM mapping finalized", tasks: [
          { id: "l6-25", name: "Align CCI BOM structure", status: "at-risk", owner: "GOE" },
          { id: "l6-26", name: "Create DVT2 MOD configs", status: "on-track", owner: "GOE" },
        ]},
      ],
    },
    {
      name: "Pilot", color: "bg-teal-500", status: "not-started",
      milestones: [
        { name: "Operational readiness", tasks: [
          { id: "l6-27", name: "Confirm operations readiness", status: "pending", owner: "GOE" },
          { id: "l6-28", name: "Generate pilot orders", status: "pending", owner: "GOE" },
          { id: "l6-29", name: "Complete WW FRC", status: "pending", owner: "GOE" },
        ]},
        { name: "Issue Closure", tasks: [
          { id: "l6-30", name: "Close all NUDDs", status: "pending", owner: "GOE" },
          { id: "l6-31", name: "Monitor FPY metrics", status: "pending", owner: "GOE" },
        ]},
      ],
    },
  ],

  "Laptop 7": [
    {
      name: "Concept", color: "bg-blue-500", status: "on-track",
      milestones: [
        { name: "Concept Phase documents uploaded", tasks: [
          { id: "l7-0", name: "Upload Program Charter", status: "completed", owner: "GOE" },
          { id: "l7-1", name: "Upload Feature Matrix", status: "completed", owner: "GOE",
      dependencies: ["l7-0"],
    },
          { id: "l7-2", name: "Confirm PRD ingested", status: "completed", owner: "GOE",
      dependencies: ["l7-0"],
    },
          { id: "l7-3", name: "Confirm EDD ingested", status: "completed", owner: "GOE",
      dependencies: ["l7-2"],
    },
          { id: "l7-4", name: "Upload Innovation Story", status: "completed", owner: "GOE",
      dependencies: ["l7-2"],
    },
          { id: "l7-5", name: "Upload Concept Phase exit Deck", status: "completed", owner: "GOE" },
        ]},
        { name: "Initial extended team formed", tasks: [
          { id: "l7-6", name: "Initiate Extended Team formation", status: "completed", owner: "GOE" },
        ]},
        { name: "Early supply chain NUDD identified", tasks: [
          { id: "l7-7", name: "Conduct ODM supplier assessment", status: "completed", owner: "GOE",
      dependencies: ["l7-5", "l7-6"],
    },
          { id: "l7-8", name: "Gather CAPEX requirements", status: "completed", owner: "GOE",
      dependencies: ["l7-7"],
    },
        ]},
        { name: "Early DFx NUDD identified", tasks: [
          { id: "l7-9", name: "Future technology Risk Assessment", status: "completed", owner: "GOE" },
          { id: "l7-10", name: "Conduct DFx assessment", status: "completed", owner: "GOE",
      dependencies: ["l7-9"],
    },
        ]},
      ],
    },
    {
      name: "Define", color: "bg-emerald-500", status: "on-track",
      milestones: [
        { name: "Upload Define Phase documents", tasks: [
          { id: "l7-11", name: "Upload PG Documentation", status: "completed", owner: "GOE",
      dependencies: ["l7-9"],
    },
        ]},
        { name: "Extended team expanded", tasks: [
          { id: "l7-12", name: "Finalize GO Extended team", status: "on-track", owner: "GOE" },
        ]},
        { name: "OE requirement locked", tasks: [
          { id: "l7-13", name: "Provide Prelim schedule", status: "on-track", owner: "GOE",
      dependencies: ["l7-12"],
    },
          { id: "l7-14", name: "Prepare OE RFQ Package", status: "pending", owner: "GOE",
      dependencies: ["l7-12", "l7-13"],
    },
        ]},
      ],
    },
    {
      name: "Plan", color: "bg-amber-500", status: "not-started",
      milestones: [
        { name: "Upload Plan Phase documents", tasks: [
          { id: "l7-15", name: "Send program kick-off communication", status: "pending", owner: "GOE" },
          { id: "l7-16", name: "Upload Plan Phase Exit Deck", status: "pending", owner: "GOE" },
        ]},
        { name: "Manufacturing plan confirmed", tasks: [
          { id: "l7-17", name: "Validate costed BOM", status: "pending", owner: "GOE" },
          { id: "l7-18", name: "Develop build plan", status: "pending", owner: "GOE" },
        ]},
      ],
    },
    {
      name: "Qual", color: "bg-purple-500", status: "not-started",
      milestones: [
        { name: "Build readiness confirmed", tasks: [
          { id: "l7-19", name: "Validate test coverage", status: "pending", owner: "GOE" },
          { id: "l7-20", name: "Complete RTB checklist", status: "pending", owner: "GOE" },
        ]},
      ],
    },
    {
      name: "Pilot", color: "bg-teal-500", status: "not-started",
      milestones: [
        { name: "Supply & Demand readiness", tasks: [
          { id: "l7-21", name: "Define DSI goal", status: "pending", owner: "GOE" },
        ]},
        { name: "Build Execution", tasks: [
          { id: "l7-22", name: "Execute pilot build", status: "pending", owner: "GOE" },
        ]},
      ],
    },
  ],
};

// Deterministic per-platform status target — guarantees a varied portfolio:
//   Laptop 4 → Red (delayed),  Laptop 2 & 6 → Yellow (at-risk),  others on-track.
// Auto-completable tasks (those with a CompletionSource) are always forced to "completed"
// per business rule, regardless of randomization.
const PLATFORM_STATUS_TARGET: Record<string, "delayed" | "at-risk" | "on-track"> = {
  "Laptop 1": "on-track",
  "Laptop 2": "at-risk",
  "Laptop 3": "at-risk",
  "Laptop 4": "delayed",
  "Laptop 5": "on-track",
  "Laptop 6": "at-risk",
  "Laptop 7": "on-track",
};

// Cheap deterministic hash so the "randomization" is stable across reloads.
const _hashStr = (s: string): number => {
  let h = 0;
  for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) | 0;
  return Math.abs(h);
};

const _normalizeAutoCompleted = (raw: Record<string, Phase[]>): Record<string, Phase[]> => {
  const out: Record<string, Phase[]> = {};
  for (const [program, phases] of Object.entries(raw)) {
    const target = PLATFORM_STATUS_TARGET[program] ?? "on-track";
    let lateInjected = false;
    let atRiskInjected = false;

    out[program] = phases.map((phase) => ({
      ...phase,
      milestones: phase.milestones.map((m) => ({
        ...m,
        tasks: m.tasks.map((t) => {
          // Rule 1: auto-completable → always completed.
          if (getCompletionSource(t.name)) {
            return { ...t, status: "completed" as TaskStatus };
          }
          // Rule 2: inject status for non-auto, not-yet-completed tasks to hit the platform target.
          if (t.status === "completed") return t;

          if (target === "delayed" && !lateInjected) {
            lateInjected = true;
            return { ...t, status: "late" as TaskStatus };
          }
          if (target === "at-risk" && !atRiskInjected) {
            atRiskInjected = true;
            return { ...t, status: "at-risk" as TaskStatus };
          }

          // Light randomization on remaining tasks for a believable mix (deterministic).
          const r = _hashStr(`${program}:${t.id}`) % 100;
          if (target === "delayed" && r < 8) return { ...t, status: "at-risk" as TaskStatus };
          if (target === "at-risk" && r < 4) return { ...t, status: "at-risk" as TaskStatus };
          if (target === "on-track" && r < 6) return { ...t, status: "on-track" as TaskStatus };
          return t;
        }),
      })),
    }));
  }
  return out;
};

export const programSchedules: Record<string, Phase[]> = _normalizeAutoCompleted(_rawProgramSchedules);

// ============================================================================
// Chronological status normalization
// ----------------------------------------------------------------------------
// Enforces the canonical business rule across all platforms:
//  • Past phases    → every task `completed`         (phase rolls up to on-track)
//  • Current phase  → distributed mix per PLATFORM_HEALTH (only Y/R allowed here)
//  • Future phases  → every task `pending`, except auto-eligible → `completed`
// Phase / platform colors emerge from `computeRollupStatus` (severity-wins).
// ============================================================================

const SIM_TODAY = new Date("2026-04-23");

const PLATFORM_HEALTH: Record<string, "green" | "yellow" | "red"> = {
  "Laptop 1": "green",
  "Laptop 2": "green",
  "Laptop 3": "yellow",
  "Laptop 4": "red",
  "Laptop 5": "green",
  "Laptop 6": "yellow",
  "Laptop 7": "green",
};

const _applyCurrentPhaseDistribution = (
  tasks: ScheduleTask[],
  profile: "green" | "yellow" | "red" = "green",
) => {
  if (tasks.length === 0) return;

  // Auto-completable tasks are always `completed` and excluded from the slot pool.
  const manualTasks: ScheduleTask[] = [];
  tasks.forEach((t) => {
    if (getCompletionSource(t.name)) {
      t.status = "completed";
    } else {
      manualTasks.push(t);
    }
  });

  const n = manualTasks.length;
  if (n === 0) return;
  const completedEnd = Math.max(1, Math.floor(n * 0.30));
  const pendingStart = Math.max(completedEnd + 1, Math.floor(n * (profile === "red" ? 0.90 : 0.85)));

  // Fixed injection slots for Y/R platforms (by manual-task index ratio).
  const atRiskSlots: number[] = [];
  const lateSlots: number[] = [];
  if (profile === "yellow") {
    atRiskSlots.push(Math.floor(n * 0.60), Math.floor(n * 0.75));
  } else if (profile === "red") {
    atRiskSlots.push(Math.floor(n * 0.55), Math.floor(n * 0.70));
    lateSlots.push(Math.floor(n * 0.80));
  }

  manualTasks.forEach((t, i) => {
    let next: TaskStatus;
    if (i < completedEnd) next = "completed";
    else if (i >= pendingStart) next = "pending";
    else if (lateSlots.includes(i)) next = "late";
    else if (atRiskSlots.includes(i)) next = "at-risk";
    else next = "on-track";
    t.status = next;
  });
};

const GRACE_DAYS = 30;
const GRACE_MS = GRACE_DAYS * 86_400_000;

/**
 * Gate-closure-based current phase index. A phase remains "current" until its
 * exit date + GRACE_DAYS has passed, reflecting realistic gate-closure latency.
 *
 * NOTE: For *calendar* phase use `getCurrentPhaseByDate` from
 * `PortfolioScheduleGantt`. This helper is reserved for the data normalizer
 * that distributes task statuses around the gate-closure window — UI widgets
 * (Gantt header, Phase Progress Bar, Phase Exit Criteria) should use the
 * date-based helper so their "Current Phase" labels stay consistent.
 */
export const getCurrentPhaseIndex = (platform: string): number => {
  const exits = phaseExitDates[platform];
  const phases = programSchedules[platform];
  if (!exits || !phases || phases.length === 0) return 0;
  const idx = phases.findIndex((p) => {
    const exit = exits[p.name];
    if (!exit) return false;
    return new Date(exit).getTime() + GRACE_MS >= SIM_TODAY.getTime();
  });
  return idx === -1 ? phases.length - 1 : idx;
};

/**
 * Date-based current phase index — mirrors `getCurrentPhaseByDate` in
 * PortfolioScheduleGantt by selecting the first phase whose exit date is on
 * or after SIM_TODAY (no grace window). This is the SINGLE SOURCE OF TRUTH
 * the normalizer uses, so every UI widget that asks "what phase is current?"
 * sees the same distribution (Y/R injections, manual at-risk/late slots).
 */
export const getCurrentPhaseIndexByDate = (platform: string): number => {
  const exits = phaseExitDates[platform];
  const phases = programSchedules[platform];
  if (!exits || !phases || phases.length === 0) return 0;
  const idx = phases.findIndex((p) => {
    const exit = exits[p.name];
    if (!exit) return false;
    return new Date(exit).getTime() >= SIM_TODAY.getTime();
  });
  return idx === -1 ? phases.length - 1 : idx;
};

const _normalizePlatformStatuses = () => {
  for (const [platform, phases] of Object.entries(programSchedules)) {
    const exits = phaseExitDates[platform];
    if (!exits) continue;

    const currentIdx = getCurrentPhaseIndexByDate(platform);
    const profile = PLATFORM_HEALTH[platform] ?? "green";

    phases.forEach((phase, pIdx) => {
      const allTasks = phase.milestones.flatMap((m) => m.tasks);

      if (pIdx < currentIdx) {
        // Past phase → everything completed.
        allTasks.forEach((t) => { t.status = "completed"; });
      } else if (pIdx > currentIdx) {
        // Future phase → pending, except auto-eligible tasks which are completed.
        allTasks.forEach((t) => {
          t.status = getCompletionSource(t.name) ? "completed" : "pending";
        });
        // Guarantee the phase rolls up to not-started: keep at least one pending.
        if (allTasks.length > 0 && allTasks.every((t) => t.status === "completed")) {
          allTasks[allTasks.length - 1].status = "pending";
        }
      } else {
        // Current phase → distribute per profile, PER MILESTONE so that every
        // milestone in a Y/R phase surfaces visible at-risk/late tasks (when it
        // has ≥3 manual tasks). This eliminates the case where the phase pill
        // says Red/Yellow but every expanded milestone shows only completed.
        phase.milestones.forEach((m, mIdx) => {
          // Alternate `late` injection across milestones for red profile so we
          // get at least one `late` somewhere in the phase without flooding
          // every milestone with one.
          const milestoneProfile: "green" | "yellow" | "red" =
            profile === "red" && mIdx % 2 === 1 ? "yellow" : profile;
          _applyCurrentPhaseDistribution(m.tasks, milestoneProfile);
        });
        // For red profile: guarantee at least one `late` task somewhere in the
        // phase (the alternation above can degrade to all-yellow if there's
        // only one qualifying milestone).
        if (profile === "red") {
          const hasLate = allTasks.some((t) => t.status === "late");
          if (!hasLate) {
            const candidate = allTasks.find(
              (t) => t.status === "at-risk" || t.status === "on-track",
            );
            if (candidate) candidate.status = "late";
          }
        }
      }

      phase.status = computeRollupStatus(allTasks);
    });
  }
};

_normalizePlatformStatuses();

// ─────────────────────────────────────────────────────────────────────────────
// 6-Phase model: split each `Pilot` phase into `Pilot` + `Ramp` based on
// milestone semantics. Ramp captures launch / phase-closure / final-build
// milestones; Pilot keeps qualification & build readiness milestones.
// ─────────────────────────────────────────────────────────────────────────────
const RAMP_MILESTONE_KEYWORDS = [
  "launch",
  "phase closure",
  "lessons learned",
  "first block",
  "ww frc",
  "wwp",
  "rts",
  "ready to ship",
  "ready to order",
  "ramp",
];

const _splitPilotIntoPilotAndRamp = () => {
  for (const [platform, phases] of Object.entries(programSchedules)) {
    const pilotIdx = phases.findIndex((p) => p.name === "Pilot");
    if (pilotIdx === -1) continue;
    const pilot = phases[pilotIdx];
    if (phases.some((p) => p.name === "Ramp")) continue;

    const rampMilestones: typeof pilot.milestones = [];
    const remainingMilestones: typeof pilot.milestones = [];
    for (const m of pilot.milestones) {
      const lower = m.name.toLowerCase();
      const isRamp = RAMP_MILESTONE_KEYWORDS.some((kw) => lower.includes(kw));
      if (isRamp) rampMilestones.push(m); else remainingMilestones.push(m);
    }

    pilot.milestones = remainingMilestones;
    pilot.status = computeRollupStatus(remainingMilestones.flatMap((m) => m.tasks));

    const rampPhase = {
      name: "Ramp",
      color: "bg-rose-500",
      status: computeRollupStatus(rampMilestones.flatMap((m) => m.tasks)),
      milestones: rampMilestones,
    };
    phases.splice(pilotIdx + 1, 0, rampPhase);
  }
};

_splitPilotIntoPilotAndRamp();

/**
 * Returns every unique task name across all platforms, alphabetized.
 * Used by autocomplete inputs in the schedule page filter bar.
 */
export const getAllTaskNames = (): string[] => {
  const set = new Set<string>();
  Object.values(programSchedules).forEach((phases) =>
    phases.forEach((phase) =>
      phase.milestones.forEach((m) =>
        m.tasks.forEach((t) => set.add(t.name)),
      ),
    ),
  );
  return Array.from(set).sort((a, b) => a.localeCompare(b));
};

