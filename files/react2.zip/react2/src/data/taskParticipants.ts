// Deterministic placeholder Task Owner / Task Assigner names per task.
// Names are seeded by the task id so the same task always shows the same people.

import type { ScheduleTask } from "./scheduleData";
import { getCompletionSource } from "./scheduleData";

export const AUTO_COMPLETED_OWNER = "Automatically completed";

// A task is "automatically completed" (no human owner) when it has a
// non-manual completion source (e.g. Doc Curator, Regrello, BOM Tool, DFx, JQIM).
export const isAutoCompletedTask = (task: Pick<ScheduleTask, "name">): boolean => {
  const src = getCompletionSource(task.name);
  return src !== null && src !== "manual";
};

export interface TaskParticipants {
  owner: string;       // person responsible for executing the task
  ownerEmail: string;
  assigner: string;    // person who assigned/owns the task at a program level
  assignerEmail: string;
}

// All seeded tasks are GOE-owned. Person names below remain as dummy data
// so the UI continues to show varied first/last names. Other function pools
// (SChM, NPI, SQE) will be reintroduced when their task sets are authored.
const OWNER_POOLS: Record<string, string[]> = {
  GOE: [
    "Priya Raman", "Marcus Chen", "Hannah Weiss", "Diego Alvarez", "Yuki Tanaka",
    "Olivia Park", "Rahul Mehta", "Sara Nguyen", "Liam O'Connor", "Ana Costa",
    "Ethan Brooks", "Mei Lin", "Jordan Patel", "Sofia Rossi", "Kenji Watanabe",
    "Aria Khan", "Tomás Vidal", "Naomi Cole", "Ben Achterberg",
  ],
  DEFAULT: ["Alex Morgan", "Jamie Rivera", "Sam Whitley", "Taylor Quinn", "Morgan Reed"],
};

// Program-level Task Assigner pool (program managers / leads).
const ASSIGNER_POOL = [
  "Vikram Shah",
  "Rebecca Lin",
  "Daniel Ortega",
  "Lucia Fernández",
  "Henry Walsh",
  "Aisha Bello",
  "Theo Bergmann",
];

const hash = (s: string): number => {
  let h = 0;
  for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) | 0;
  return Math.abs(h);
};

const emailFor = (fullName: string): string =>
  `${fullName.toLowerCase().replace(/[^a-z]+/g, ".")}@dell.com`;

// Every task is GOE; always draw from the GOE pool.
const pickPool = (_ownerTag: string): string[] => OWNER_POOLS.GOE;

export const getTaskParticipants = (task: Pick<ScheduleTask, "id" | "owner" | "name">): TaskParticipants => {
  const idHash = hash(task.id);
  const assigner = ASSIGNER_POOL[(idHash >> 3) % ASSIGNER_POOL.length];

  if (isAutoCompletedTask(task)) {
    return {
      owner: AUTO_COMPLETED_OWNER,
      ownerEmail: "",
      assigner: AUTO_COMPLETED_OWNER,
      assignerEmail: "",
    };
  }

  const pool = pickPool(task.owner ?? "");
  const owner = pool[idHash % pool.length];
  return {
    owner,
    ownerEmail: emailFor(owner),
    assigner,
    assignerEmail: emailFor(assigner),
  };
};

/**
 * Deterministic backup owner (a person's name) distinct from the primary owner.
 * Drawn from the same function-aligned pool when possible, falling back to the
 * default roster so every task always has a named backup.
 */
export const getBackupOwnerName = (
  task: Pick<ScheduleTask, "id" | "owner" | "name">,
  primaryName: string
): string => {
  if (isAutoCompletedTask(task)) return AUTO_COMPLETED_OWNER;
  const fnPool = pickPool(task.owner ?? "").filter((n) => n !== primaryName);
  const fallbackPool = OWNER_POOLS.DEFAULT.filter((n) => n !== primaryName);
  const pool = fnPool.length > 0 ? fnPool : fallbackPool;
  const idHash = hash(task.id + ":backup");
  return pool[idHash % pool.length];
};

/**
 * Full roster of named individuals (primary + backup candidates) for use in
 * reassignment selectors. Deduplicated and sorted alphabetically.
 */
export const getAllOwnerNames = (): string[] => {
  const set = new Set<string>();
  Object.values(OWNER_POOLS).forEach((pool) => pool.forEach((n) => set.add(n)));
  return Array.from(set).sort();
};

/**
 * Best-effort lookup: which function pool a named person belongs to.
 * Currently every seeded contributor is GOE.
 */
export const getOwnerFunctionTag = (name: string): string => {
  for (const [tag, pool] of Object.entries(OWNER_POOLS)) {
    if (tag === "DEFAULT") continue;
    if (pool.includes(name)) return tag;
  }
  return "Cross-functional";
};

/**
 * Identity used to scope the "My Tasks" view for the User role.
 * In a real app this would come from auth; here it's a stable placeholder
 * matched against the deterministic owner names above.
 */
export const CURRENT_USER_OWNER_NAME = "Priya Raman";
