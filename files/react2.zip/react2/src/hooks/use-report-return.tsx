import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { ArrowLeft, X } from "lucide-react";
import type { LobKey } from "@/contexts/PhaseGateReportContext";

const KEY = "reportReturn";

export interface ReportReturnState {
  lob: LobKey;
  mode: "view" | "generate";
}

export const setReportReturn = (state: ReportReturnState) => {
  try { sessionStorage.setItem(KEY, JSON.stringify(state)); } catch {}
};
export const clearReportReturn = () => {
  try { sessionStorage.removeItem(KEY); } catch {}
};
export const readReportReturn = (): ReportReturnState | null => {
  try {
    const raw = sessionStorage.getItem(KEY);
    return raw ? JSON.parse(raw) : null;
  } catch { return null; }
};

/** Sticky banner that lets users hop back to the open report. */
export const ReportReturnBanner = () => {
  const navigate = useNavigate();
  const [state, setState] = useState<ReportReturnState | null>(null);

  useEffect(() => {
    const sync = () => setState(readReportReturn());
    sync();
    const id = setInterval(sync, 500);
    return () => clearInterval(id);
  }, []);

  if (!state) return null;

  const goBack = () => {
    navigate(`/?reopenReport=${state.lob}&mode=${state.mode}`);
    clearReportReturn();
    setState(null);
  };
  const dismiss = () => {
    clearReportReturn();
    setState(null);
  };

  return (
    <div className="sticky top-0 z-40 bg-primary text-primary-foreground border-b border-primary/40">
      <div className="max-w-[1600px] mx-auto px-6 py-2 flex items-center justify-between gap-3">
        <button onClick={goBack} className="flex items-center gap-2 text-[12px] font-bold hover:underline">
          <ArrowLeft className="w-3.5 h-3.5" />
          Back to {state.lob} Phase Gate Report
        </button>
        <button onClick={dismiss} aria-label="Dismiss" className="p-1 rounded hover:bg-primary-foreground/10">
          <X className="w-3.5 h-3.5" />
        </button>
      </div>
    </div>
  );
};
