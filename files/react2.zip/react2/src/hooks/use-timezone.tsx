import { createContext, useContext, useState, useCallback } from "react";

interface TimezoneContextType {
  timezone: string;
  resolvedTimezone: string;
  setTimezone: (tz: string) => void;
  formatTime: (fmt?: Intl.DateTimeFormatOptions) => string;
}

const TimezoneContext = createContext<TimezoneContextType>({
  timezone: "system",
  resolvedTimezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
  setTimezone: () => {},
  formatTime: () => "",
});

export function TimezoneProvider({ children }: { children: React.ReactNode }) {
  const [timezone, setTimezoneState] = useState<string>(() => {
    return localStorage.getItem("olp-timezone") || "system";
  });

  const systemTz = Intl.DateTimeFormat().resolvedOptions().timeZone;
  const resolvedTimezone = timezone === "system" ? systemTz : timezone;

  const setTimezone = useCallback((tz: string) => {
    setTimezoneState(tz);
    localStorage.setItem("olp-timezone", tz);
  }, []);

  const formatTime = useCallback((fmt?: Intl.DateTimeFormatOptions) => {
    const defaults: Intl.DateTimeFormatOptions = {
      hour: "numeric",
      minute: "2-digit",
      hour12: true,
      timeZone: resolvedTimezone,
      ...fmt,
    };
    return new Date().toLocaleString("en-US", defaults);
  }, [resolvedTimezone]);

  return (
    <TimezoneContext.Provider value={{ timezone, resolvedTimezone, setTimezone, formatTime }}>
      {children}
    </TimezoneContext.Provider>
  );
}

export const useTimezone = () => useContext(TimezoneContext);

// Curated list of common timezones
export const TIMEZONE_LIST: { value: string; label: string }[] = [
  { value: "Pacific/Midway", label: "Midway Island (GMT-11:00)" },
  { value: "Pacific/Honolulu", label: "Hawaii (GMT-10:00)" },
  { value: "America/Anchorage", label: "Alaska (GMT-09:00)" },
  { value: "America/Los_Angeles", label: "Pacific Time (GMT-08:00)" },
  { value: "America/Denver", label: "Mountain Time (GMT-07:00)" },
  { value: "America/Chicago", label: "Central Time (GMT-06:00)" },
  { value: "America/New_York", label: "Eastern Time (GMT-05:00)" },
  { value: "America/Caracas", label: "Caracas (GMT-04:30)" },
  { value: "America/Halifax", label: "Atlantic Time (GMT-04:00)" },
  { value: "America/St_Johns", label: "Newfoundland (GMT-03:30)" },
  { value: "America/Sao_Paulo", label: "São Paulo (GMT-03:00)" },
  { value: "America/Argentina/Buenos_Aires", label: "Buenos Aires (GMT-03:00)" },
  { value: "Atlantic/South_Georgia", label: "Mid-Atlantic (GMT-02:00)" },
  { value: "Atlantic/Azores", label: "Azores (GMT-01:00)" },
  { value: "Europe/London", label: "London (GMT+00:00)" },
  { value: "Europe/Paris", label: "Paris (GMT+01:00)" },
  { value: "Europe/Berlin", label: "Berlin (GMT+01:00)" },
  { value: "Europe/Istanbul", label: "Istanbul (GMT+03:00)" },
  { value: "Europe/Moscow", label: "Moscow (GMT+03:00)" },
  { value: "Africa/Cairo", label: "Cairo (GMT+02:00)" },
  { value: "Africa/Johannesburg", label: "Johannesburg (GMT+02:00)" },
  { value: "Asia/Dubai", label: "Dubai (GMT+04:00)" },
  { value: "Asia/Karachi", label: "Karachi (GMT+05:00)" },
  { value: "Asia/Kolkata", label: "Kolkata (GMT+05:30)" },
  { value: "Asia/Dhaka", label: "Dhaka (GMT+06:00)" },
  { value: "Asia/Bangkok", label: "Bangkok (GMT+07:00)" },
  { value: "Asia/Shanghai", label: "Shanghai (GMT+08:00)" },
  { value: "Asia/Singapore", label: "Singapore (GMT+08:00)" },
  { value: "Asia/Tokyo", label: "Tokyo (GMT+09:00)" },
  { value: "Asia/Seoul", label: "Seoul (GMT+09:00)" },
  { value: "Australia/Sydney", label: "Sydney (GMT+10:00)" },
  { value: "Pacific/Auckland", label: "Auckland (GMT+12:00)" },
];

export function getGMTOffset(tz: string): string {
  try {
    const now = new Date();
    const fmt = new Intl.DateTimeFormat("en-US", { timeZone: tz, timeZoneName: "shortOffset" });
    const parts = fmt.formatToParts(now);
    const offset = parts.find((p) => p.type === "timeZoneName")?.value || "";
    return offset;
  } catch {
    return "";
  }
}
