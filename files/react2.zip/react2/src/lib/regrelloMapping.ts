import type { TaskStatus } from "@/data/scheduleData";

/**
 * Regrello task status colors as exposed by the Regrello API/export.
 * Source of truth for inbound task data.
 */
export type RegrelloStatus = "blue" | "green" | "yellow" | "red";

/**
 * Human-readable Regrello status labels (for legends, tooltips, audit logs).
 */
export const REGRELLO_STATUS_LABEL: Record<RegrelloStatus, string> = {
  blue: "Complete",
  green: "On Track",
  yellow: "Overdue",
  red: "Problem",
};

/**
 * Dashboard label corresponding to each mapped TaskStatus.
 * Mirrors the labels used across the Status Indicators system.
 */
export const DASHBOARD_STATUS_LABEL: Record<TaskStatus, string> = {
  completed: "Done",
  "on-track": "On Track",
  "at-risk": "At Risk w/ Mitigation",
  pending: "Not Started",
  late: "At Risk w/ No Plan",
};

/**
 * Map a Regrello status to the dashboard's internal TaskStatus.
 *
 * Mapping rules:
 *   blue   → completed   (terminal; excluded from risk rollups)
 *   green  → on-track    (default healthy)
 *   yellow → late        (Overdue ≡ missed commitment, escalates Red)
 *   red    → late        (Problem with no mitigation path)
 *
 * Note: Regrello has no native "mitigated risk" concept, so dashboard Yellow
 * ("At Risk w/ Mitigation") is never produced by this adapter. Yellow is
 * applied downstream via owner-set overrides in StatusFlagContext when a
 * mitigation plan is confirmed for a Regrello Red/Yellow task.
 */
export const mapRegrelloStatus = (status: RegrelloStatus): TaskStatus => {
  switch (status) {
    case "blue":
      return "completed";
    case "green":
      return "on-track";
    case "yellow":
    case "red":
      return "late";
  }
};

/**
 * Tooltip copy explaining the Regrello → Dashboard translation for a given
 * inbound Regrello status. Suitable for status-badge hover content.
 */
export const explainRegrelloMapping = (status: RegrelloStatus): string => {
  const mapped = mapRegrelloStatus(status);
  return `Regrello: ${REGRELLO_STATUS_LABEL[status]} → Dashboard: ${DASHBOARD_STATUS_LABEL[mapped]}`;
};
