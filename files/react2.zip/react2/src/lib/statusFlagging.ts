import type { ScheduleTask, TaskStatus } from "@/data/scheduleData";
import { getTaskDueOffsetDays } from "@/data/scheduleData";

export type FlagSeverity = "yellow" | "red";

export interface TaskFlag {
  taskId: string;
  taskName: string;
  currentStatus: TaskStatus;
  suggested: TaskStatus;
  severity: FlagSeverity;
  reason: string;
  daysUntilDue: number;
}

const parsePorDate = (raw?: string): Date | null => {
  if (!raw) return null;
  const d = new Date(raw);
  if (!isNaN(d.getTime())) return d;
  return null;
};

/**
 * Evaluate whether a task should be flagged for an automated status change
 * based on its proximity to the due date. Returns null if no flag is needed.
 */
export const evaluateTaskFlag = (
  task: ScheduleTask,
  now: Date = new Date()
): Omit<TaskFlag, "taskId" | "taskName" | "currentStatus"> | null => {
  if (task.status === "completed") return null;

  const por = parsePorDate(task.porDate);
  if (!por) return null;

  // Effective due date = POR − T-minus offset
  const due = new Date(por);
  due.setDate(due.getDate() - getTaskDueOffsetDays(task.id));

  const msPerDay = 86_400_000;
  const daysUntilDue = Math.ceil((due.getTime() - now.getTime()) / msPerDay);

  // Already late or overdue → red
  if (daysUntilDue < 0) {
    return {
      suggested: "late",
      severity: "red",
      reason: `Overdue by ${Math.abs(daysUntilDue)} day${Math.abs(daysUntilDue) === 1 ? "" : "s"}`,
      daysUntilDue,
    };
  }
  // Due today / 1 day → red
  if (daysUntilDue <= 1 && task.status !== "late") {
    return {
      suggested: "late",
      severity: "red",
      reason: daysUntilDue === 0 ? "Due today" : "Due tomorrow",
      daysUntilDue,
    };
  }
  // Due within 3 days → yellow flag (suggest pending → on-track watch)
  if (daysUntilDue <= 3 && task.status === "pending") {
    return {
      suggested: "on-track",
      severity: "yellow",
      reason: `Due in ${daysUntilDue} days — start tracking`,
      daysUntilDue,
    };
  }
  return null;
};
