import { useState } from "react";
import ComingSoonBanner from "@/components/dashboard/ComingSoonBanner";
import { Archive as ArchiveIcon, Calendar, FileText, BookOpen, AlertCircle, Mail, ChevronDown, ChevronUp } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { cn } from "@/lib/utils";
import { ScrollArea } from "@/components/ui/scroll-area";
import { motion, AnimatePresence } from "framer-motion";

interface ArchivedProgram {
  name: string;
  line: string;
  archiveDate: string;
  launchDate: string;
  phases: { name: string; completedDate: string }[];
  lessonsLearned: string;
  keyDocuments: string[];
}

const archivedPrograms: ArchivedProgram[] = [
  {
    name: "Laptop Alpha",
    line: "Desktop",
    archiveDate: "2024-11-15",
    launchDate: "2024-09-20",
    phases: [
      { name: "Concept", completedDate: "2023-06-01" },
      { name: "Define", completedDate: "2023-09-15" },
      { name: "Plan", completedDate: "2024-01-10" },
      { name: "Qual", completedDate: "2024-06-30" },
      { name: "Pilot", completedDate: "2024-08-15" },
      { name: "Ramp", completedDate: "2024-09-20" },
    ],
    lessonsLearned: "Thermal module sourcing delays pushed Develop phase by 3 weeks. Recommend dual-sourcing for critical thermal components on future programs.",
    keyDocuments: ["Phase Gate Report", "Final BOM", "Launch Readiness Review", "Post-Launch Summary"],
  },
  {
    name: "Laptop Beta",
    line: "Notebook",
    archiveDate: "2025-01-10",
    launchDate: "2024-12-01",
    phases: [
      { name: "Concept", completedDate: "2024-01-15" },
      { name: "Define", completedDate: "2024-04-20" },
      { name: "Plan", completedDate: "2024-07-01" },
      { name: "Qual", completedDate: "2024-10-15" },
      { name: "Pilot", completedDate: "2024-11-10" },
      { name: "Ramp", completedDate: "2024-12-01" },
    ],
    lessonsLearned: "Early factory engagement reduced build issues by 40%. GOE process improvements from this launch should be templated for future NPI programs.",
    keyDocuments: ["Phase Gate Report", "Golden Config Baseline", "Build Execution Log"],
  },
];

const ArchiveContent = () => {
  const [expandedProgram, setExpandedProgram] = useState<string | null>(null);
  const [editingLessons, setEditingLessons] = useState<string | null>(null);
  const [lessonsText, setLessonsText] = useState<Record<string, string>>(() => {
    const initial: Record<string, string> = {};
    archivedPrograms.forEach((p) => { initial[p.name] = p.lessonsLearned; });
    return initial;
  });

  const handleContact = () => {
    window.location.href = "mailto:adnan.sachche@dell.com,ashly_lomme@dell.com?subject=OLP%20Data%20Retention%20Policy%20Inquiry&body=Hi%20Adnan%20and%20Ashly%2C%0A%0AI%20have%20a%20question%20regarding%20the%20data%20retention%20policy%20for%20archived%20programs%20in%20OLP%20Launch%20Orchestrator.%0A%0AThank%20you.";
  };

  return (
    <div className="flex-1 flex flex-col overflow-auto">
      <div className="px-6 pt-6 pb-3 flex items-center gap-3">
        <div className="w-9 h-9 rounded-lg bg-primary/10 flex items-center justify-center">
          <ArchiveIcon className="w-4.5 h-4.5 text-primary" />
        </div>
        <div>
          <h1 className="text-[22px] font-extrabold text-foreground tracking-tight">Archived Programs</h1>
          <p className="text-[11px] text-muted-foreground">{archivedPrograms.length} completed programs</p>
        </div>
      </div>

      {/* Data Retention Notice */}
      <div className="mx-6 mb-5 flex items-start gap-3 rounded-xl border border-warning/25 bg-warning/5 p-4">
        <div className="w-8 h-8 rounded-lg bg-warning/15 flex items-center justify-center shrink-0 mt-0.5">
          <AlertCircle className="w-4 h-4 text-warning" />
        </div>
        <div className="flex-1">
          <p className="text-xs font-semibold text-foreground">Data Retention Policy</p>
          <p className="text-[11px] text-muted-foreground mt-1 leading-relaxed">
            Retention policy TBD — contact <span className="font-medium text-foreground">Adnan Sachche</span> and <span className="font-medium text-foreground">Ashly Lomme</span> for requirements on how long past launch data must be kept (may include ISO requirements).
          </p>
        </div>
        <Button
          variant="outline"
          size="sm"
          className="shrink-0 h-8 text-xs gap-1.5 font-semibold hover:bg-primary hover:text-primary-foreground hover:border-primary transition-all"
          onClick={handleContact}
        >
          <Mail className="w-3.5 h-3.5" />
          Contact
        </Button>
      </div>

      <ScrollArea className="flex-1 px-6 pb-6">
        <div className="space-y-3">
          {archivedPrograms.map((program, idx) => {
            const isExpanded = expandedProgram === program.name;
            const isEditingLessons = editingLessons === program.name;

            return (
              <motion.div
                key={program.name}
                initial={{ opacity: 0, y: 6 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3, delay: idx * 0.08 }}
                className="border border-border rounded-xl bg-card overflow-hidden shadow-sm"
              >
                {/* Header */}
                <button
                  onClick={() => setExpandedProgram(isExpanded ? null : program.name)}
                  className="w-full flex items-center gap-3 px-5 py-4 hover:bg-accent/30 transition-all text-left group"
                >
                  <div className="w-10 h-10 rounded-lg bg-muted/80 flex items-center justify-center shrink-0">
                    <ArchiveIcon className="w-4.5 h-4.5 text-muted-foreground" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-semibold text-foreground">{program.name}</span>
                      <Badge variant="outline" className="text-[9px] font-semibold">{program.line}</Badge>
                    </div>
                    <p className="text-[11px] text-muted-foreground mt-0.5">
                      Launched {new Date(program.launchDate).toLocaleDateString("en-US", { month: "long", day: "numeric", year: "numeric" })} · Archived {new Date(program.archiveDate).toLocaleDateString("en-US", { month: "long", day: "numeric", year: "numeric" })}
                    </p>
                  </div>
                  <Badge className="bg-muted text-muted-foreground border-border text-[9px] font-semibold">Archived</Badge>
                  {isExpanded ? (
                    <ChevronUp className="w-4 h-4 text-muted-foreground" />
                  ) : (
                    <ChevronDown className="w-4 h-4 text-muted-foreground" />
                  )}
                </button>

                {/* Expanded Detail */}
                <AnimatePresence>
                  {isExpanded && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: "auto", opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      transition={{ duration: 0.25 }}
                      className="overflow-hidden"
                    >
                      <div className="border-t border-border px-5 py-5 space-y-5">
                        {/* Phase Completion Timeline */}
                        <div>
                          <span className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider">Phase Completion</span>
                          <div className="mt-3 flex gap-2">
                            {program.phases.map((phase) => (
                              <div key={phase.name} className="flex-1 text-center">
                                <div className="w-full h-2 rounded-full bg-success/20 mb-2">
                                  <div className="w-full h-full rounded-full bg-success" />
                                </div>
                                <p className="text-[9px] font-semibold text-foreground truncate">{phase.name}</p>
                                <p className="text-[8px] text-muted-foreground mt-0.5">
                                  {new Date(phase.completedDate).toLocaleDateString("en-US", { month: "short", year: "2-digit" })}
                                </p>
                              </div>
                            ))}
                          </div>
                        </div>

                        {/* Key Documents */}
                        <div>
                          <span className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider">Key Documents</span>
                          <div className="mt-2 flex flex-wrap gap-2">
                            {program.keyDocuments.map((doc) => (
                              <span key={doc} className="inline-flex items-center gap-1.5 text-[10px] px-2.5 py-1.5 rounded-lg border border-border bg-muted/30 text-foreground cursor-pointer hover:bg-accent hover:border-primary/30 transition-all font-medium">
                                <FileText className="w-3 h-3 text-primary" />
                                {doc}
                              </span>
                            ))}
                          </div>
                        </div>

                        {/* Lessons Learned */}
                        <div>
                          <div className="flex items-center justify-between mb-2">
                            <span className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider flex items-center gap-1.5">
                              <BookOpen className="w-3 h-3" /> Lessons Learned
                            </span>
                            <Button
                              variant="ghost"
                              size="sm"
                              className="h-7 text-[10px] font-semibold"
                              onClick={() => {
                                if (isEditingLessons) {
                                  setEditingLessons(null);
                                } else {
                                  setEditingLessons(program.name);
                                }
                              }}
                            >
                              {isEditingLessons ? "Save" : "Edit"}
                            </Button>
                          </div>
                          {isEditingLessons ? (
                            <Textarea
                              value={lessonsText[program.name]}
                              onChange={(e) => setLessonsText((prev) => ({ ...prev, [program.name]: e.target.value }))}
                              className="text-xs min-h-[80px]"
                            />
                          ) : (
                            <p className="text-[11px] text-foreground leading-relaxed bg-muted/20 rounded-lg p-3.5 border border-border/50">
                              {lessonsText[program.name]}
                            </p>
                          )}
                        </div>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </motion.div>
            );
          })}

          {archivedPrograms.length === 0 && (
            <div className="text-center py-16">
              <div className="w-14 h-14 rounded-2xl bg-muted/50 flex items-center justify-center mx-auto mb-3">
                <ArchiveIcon className="w-6 h-6 text-muted-foreground" />
              </div>
              <p className="text-sm font-medium text-muted-foreground">No archived programs yet</p>
              <p className="text-xs text-muted-foreground mt-1">Programs that complete all Phase Gates will appear here.</p>
            </div>
          )}
        </div>
      </ScrollArea>
    </div>
  );
};

const Archive = () => (
  <ComingSoonBanner message="To be completed in version 2.0">
    <ArchiveContent />
  </ComingSoonBanner>
);

export default Archive;
