import { useState, useMemo } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { ClipboardList, Filter, Download } from "lucide-react";
import { cn } from "@/lib/utils";
import { toast } from "@/hooks/use-toast";
import UniversalFilterBar from "@/components/dashboard/UniversalFilterBar";
import { useUniversalFilters } from "@/contexts/UniversalFilterContext";

interface AuditEntry {
  id: string;
  timestamp: string;
  user: string;
  role: string;
  actionType: "status_change" | "reassignment" | "comment" | "document_upload" | "phase_gate" | "task_create";
  target: string;
  program: string;
  oldValue: string;
  newValue: string;
  reason: string;
}

const mockEntries: AuditEntry[] = [
  { id: "A001", timestamp: "2026-04-15 09:23", user: "Sarah Chen", role: "GOE Manager", actionType: "status_change", target: "Lock DVT2 OPS demand", program: "Laptop 1", oldValue: "Pending", newValue: "On Track", reason: "Demand volumes confirmed with ODM" },
  { id: "A002", timestamp: "2026-04-15 09:15", user: "Mike Johnson", role: "SChM Lead", actionType: "reassignment", target: "Validate costed BOM", program: "Laptop 1", oldValue: "Owner: GOE", newValue: "Owner: SChM", reason: "BOM validation is supply chain responsibility" },
  { id: "A003", timestamp: "2026-04-14 16:45", user: "Lisa Wang", role: "NPI Engineer", actionType: "comment", target: "Complete PPAP on schedule", program: "Laptop 2", oldValue: "", newValue: "Added comment", reason: "PPAP samples shipped to test lab" },
  { id: "A004", timestamp: "2026-04-14 14:30", user: "Sarah Chen", role: "GOE Manager", actionType: "document_upload", target: "Plan Phase Exit Deck", program: "Laptop 1", oldValue: "", newValue: "PlanExit_v2.pptx", reason: "Updated deck with latest metrics" },
  { id: "A005", timestamp: "2026-04-14 11:00", user: "Tom Roberts", role: "Program Director", actionType: "phase_gate", target: "Define Phase", program: "Laptop 1", oldValue: "In Review", newValue: "Approved", reason: "All exit criteria met" },
  { id: "A006", timestamp: "2026-04-13 17:20", user: "Mike Johnson", role: "SChM Lead", actionType: "status_change", target: "Lock WW fulfillment model", program: "Laptop 3", oldValue: "On Track", newValue: "Late", reason: "Logistics model pending region approval" },
  { id: "A007", timestamp: "2026-04-13 15:10", user: "Lisa Wang", role: "NPI Engineer", actionType: "task_create", target: "New test enablement plan", program: "Laptop 4", oldValue: "", newValue: "Created", reason: "Required for DVT1 readiness" },
  { id: "A008", timestamp: "2026-04-13 10:45", user: "Sarah Chen", role: "GOE Manager", actionType: "reassignment", target: "Complete ODM audit", program: "Laptop 2", oldValue: "Owner: NPI", newValue: "Owner: GOE & SQE", reason: "Joint audit required per new policy" },
  { id: "A009", timestamp: "2026-04-12 16:30", user: "Tom Roberts", role: "Program Director", actionType: "comment", target: "Program Schedule", program: "Laptop 7", oldValue: "", newValue: "Added comment", reason: "Flagged thermal design as top risk" },
  { id: "A010", timestamp: "2026-04-12 14:00", user: "Mike Johnson", role: "SChM Lead", actionType: "status_change", target: "Define PPAP schedule", program: "Laptop 5", oldValue: "Pending", newValue: "On Track", reason: "Schedule aligned with CT recommendations" },
  { id: "A011", timestamp: "2026-04-12 09:30", user: "Lisa Wang", role: "NPI Engineer", actionType: "document_upload", target: "GTS/VM Inputs", program: "Laptop 1", oldValue: "", newValue: "GTS_Inputs_v3.xlsx", reason: "Updated with Q2 projections" },
  { id: "A012", timestamp: "2026-04-11 15:45", user: "Sarah Chen", role: "GOE Manager", actionType: "status_change", target: "Future technology Risk Assessment", program: "Laptop 3", oldValue: "On Track", newValue: "Completed", reason: "All technology risks assessed and mitigated" },
];

const actionColors: Record<string, string> = {
  status_change: "bg-blue-100 text-blue-800 border-blue-200",
  reassignment: "bg-purple-100 text-purple-800 border-purple-200",
  comment: "bg-gray-100 text-gray-700 border-gray-200",
  document_upload: "bg-green-100 text-green-800 border-green-200",
  phase_gate: "bg-yellow-100 text-yellow-800 border-yellow-200",
  task_create: "bg-emerald-100 text-emerald-800 border-emerald-200",
};

const actionLabels: Record<string, string> = {
  status_change: "Status Change",
  reassignment: "Reassignment",
  comment: "Comment",
  document_upload: "Doc Upload",
  phase_gate: "Phase Gate",
  task_create: "Task Created",
};

const programs = ["Laptop 1", "Laptop 2", "Laptop 3", "Laptop 4", "Laptop 5", "Laptop 6", "Laptop 7"];

const AuditLog = () => {
  const { matchesPlatform } = useUniversalFilters();
  const [filterAction, setFilterAction] = useState("all");
  const [filterProgram, setFilterProgram] = useState("all");
  const [filterUser, setFilterUser] = useState("all");

  const users = [...new Set(mockEntries.map(e => e.user))];

  const platformFiltered = useMemo(() => mockEntries.filter(e => matchesPlatform(e.program)), [matchesPlatform]);

  const filtered = useMemo(() => platformFiltered.filter(e => {
    if (filterAction !== "all" && e.actionType !== filterAction) return false;
    if (filterProgram !== "all" && e.program !== filterProgram) return false;
    if (filterUser !== "all" && e.user !== filterUser) return false;
    return true;
  }), [filterAction, filterProgram, filterUser]);

  return (
    <div className="flex-1 flex flex-col overflow-auto p-4 space-y-4">
      <div className="flex items-center gap-2.5">
        <ClipboardList className="w-6 h-6 text-primary" />
        <h1 className="text-[22px] font-extrabold text-foreground tracking-tight flex-1">Audit Log</h1>
        <UniversalFilterBar />
        <Button variant="outline" size="sm" className="text-xs gap-1.5 h-8" onClick={() => toast({ title: "Export started", description: "Audit log export will be downloaded shortly." })}>
          <Download className="w-3.5 h-3.5" /> Export
        </Button>
      </div>

      <div className="flex items-center gap-3">
        <Filter className="w-3.5 h-3.5 text-muted-foreground" />
        <Select value={filterAction} onValueChange={setFilterAction}>
          <SelectTrigger className="w-[150px] h-8 text-xs"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Actions</SelectItem>
            {Object.entries(actionLabels).map(([k, v]) => <SelectItem key={k} value={k}>{v}</SelectItem>)}
          </SelectContent>
        </Select>
        <Select value={filterProgram} onValueChange={setFilterProgram}>
          <SelectTrigger className="w-[140px] h-8 text-xs"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Programs</SelectItem>
            {programs.map(p => <SelectItem key={p} value={p}>{p}</SelectItem>)}
          </SelectContent>
        </Select>
        <Select value={filterUser} onValueChange={setFilterUser}>
          <SelectTrigger className="w-[150px] h-8 text-xs"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Users</SelectItem>
            {users.map(u => <SelectItem key={u} value={u}>{u}</SelectItem>)}
          </SelectContent>
        </Select>
      </div>

      <Card className="border-border">
        <CardContent className="p-0">
          <table className="w-full text-xs">
            <thead>
              <tr className="border-b border-border bg-muted/30">
                {["Timestamp", "User", "Role", "Action", "Target", "Program", "Old Value", "New Value", "Reason"].map(h => (
                  <th key={h} className="text-left px-3 py-2 font-semibold text-muted-foreground">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filtered.map(e => (
                <tr key={e.id} className="border-b border-border/40 hover:bg-muted/20 transition-colors">
                  <td className="px-3 py-2 text-muted-foreground whitespace-nowrap">{e.timestamp}</td>
                  <td className="px-3 py-2 font-medium">{e.user}</td>
                  <td className="px-3 py-2 text-muted-foreground">{e.role}</td>
                  <td className="px-3 py-2"><Badge variant="outline" className={cn("text-[9px]", actionColors[e.actionType])}>{actionLabels[e.actionType]}</Badge></td>
                  <td className="px-3 py-2 max-w-[160px] truncate">{e.target}</td>
                  <td className="px-3 py-2">{e.program}</td>
                  <td className="px-3 py-2 text-muted-foreground">{e.oldValue || "—"}</td>
                  <td className="px-3 py-2">{e.newValue || "—"}</td>
                  <td className="px-3 py-2 text-muted-foreground max-w-[200px] truncate">{e.reason}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </CardContent>
      </Card>
    </div>
  );
};

export default AuditLog;
