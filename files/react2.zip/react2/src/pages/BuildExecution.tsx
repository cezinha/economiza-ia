import { useMemo, useState } from "react";
import ComingSoonBanner from "@/components/dashboard/ComingSoonBanner";
import { Monitor, FlaskConical, Download, AppWindow, CheckCircle2, Circle, Loader2, Truck, ClipboardCheck } from "lucide-react";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import UniversalFilterBar from "@/components/dashboard/UniversalFilterBar";
import { useUniversalFilters, PLATFORM_LOB, phaseMatches } from "@/contexts/UniversalFilterContext";

const orderStatusItems = [
  { icon: Monitor, label: "Build", count: 50, total: 100, percent: 50, color: "hsl(var(--success))" },
  { icon: FlaskConical, label: "Automated Function Testing", count: 20, total: 100, percent: 20, color: "hsl(var(--chart-2))" },
  { icon: Download, label: "Software Download", count: 5, total: 100, percent: 5, color: "hsl(var(--warning))" },
  { icon: AppWindow, label: "Window Based Testing", count: 10, total: 100, percent: 10, color: "hsl(var(--primary))" },
];

interface OrderProgress {
  built: "complete" | "in-progress" | "pending";
  functionalTest: "complete" | "in-progress" | "pending";
  softwareDownload: "complete" | "in-progress" | "pending";
  windowsDownload: "complete" | "in-progress" | "pending";
  readyToShip: "complete" | "in-progress" | "pending";
}

const recentOrders: { order: string; factory: string; progress: OrderProgress }[] = [
  {
    order: "Order #9",
    factory: "Factory #9",
    progress: { built: "complete", functionalTest: "complete", softwareDownload: "in-progress", windowsDownload: "pending", readyToShip: "pending" },
  },
  {
    order: "Order #10",
    factory: "Factory #4",
    progress: { built: "complete", functionalTest: "in-progress", softwareDownload: "pending", windowsDownload: "pending", readyToShip: "pending" },
  },
  {
    order: "Order #11",
    factory: "Factory #3",
    progress: { built: "in-progress", functionalTest: "pending", softwareDownload: "pending", windowsDownload: "pending", readyToShip: "pending" },
  },
];

const stepLabels: { key: keyof OrderProgress; label: string; icon: typeof Monitor }[] = [
  { key: "built", label: "Built", icon: Monitor },
  { key: "functionalTest", label: "Functionally Tested", icon: FlaskConical },
  { key: "softwareDownload", label: "Software Downloaded", icon: Download },
  { key: "windowsDownload", label: "Windows Downloaded", icon: AppWindow },
  { key: "readyToShip", label: "Ready to Ship", icon: Truck },
];

const statusStyles = {
  complete: { icon: CheckCircle2, className: "text-success", barClass: "bg-success" },
  "in-progress": { icon: Loader2, className: "text-warning", barClass: "bg-warning" },
  pending: { icon: Circle, className: "text-muted-foreground", barClass: "bg-muted" },
};

const buildIssuesData = [
  {
    id: "BLD-4001",
    buildType: "qual" as const,
    labels: "Assembly",
    severity: "SEV 1",
    dfmaaStatus: "Open",
    affectedPlatforms: "Laptop 3",
    affectedLOBs: "CSG",
    affectedSubLOBs: "Notebook",
    formFactor: "Clamshell",
    enterPhase: "PVT",
    impactedSite: "CSG ODM Factory",
    impactedItems: "Motherboard",
    issueDetails: "Solder bridge on U12 causing boot failure on 3% of units",
    issueStatus: "In Progress",
  },
  {
    id: "BLD-4002",
    buildType: "qual" as const,
    labels: "Thermal",
    severity: "SEV 2",
    dfmaaStatus: "Analyze",
    affectedPlatforms: "Laptop 2",
    affectedLOBs: "ISG",
    affectedSubLOBs: "Workstation",
    formFactor: "Clamshell",
    enterPhase: "DVT",
    impactedSite: "ISG ODM Factory",
    impactedItems: "Heatsink",
    issueDetails: "Thermal paste application inconsistency causing hotspots",
    issueStatus: "Analyze",
  },
  {
    id: "BLD-4003",
    buildType: "pilot" as const,
    labels: "Mechanical",
    severity: "SEV 2",
    dfmaaStatus: "Verify",
    affectedPlatforms: "OptiPlex 7420",
    affectedLOBs: "DnCP",
    affectedSubLOBs: "Desktop",
    formFactor: "AIO",
    enterPhase: "PVT",
    impactedSite: "DnCP Supplier Factory",
    impactedItems: "Chassis",
    issueDetails: "Side panel misalignment causing 2mm gap on left edge",
    issueStatus: "In Progress",
  },
  {
    id: "BLD-4004",
    buildType: "qual" as const,
    labels: "None",
    severity: "SEV 3",
    dfmaaStatus: "Open",
    affectedPlatforms: "Latitude 5550",
    affectedLOBs: "CSG",
    affectedSubLOBs: "Notebook",
    formFactor: "Clamshell",
    enterPhase: "DVT",
    impactedSite: "CSG ODM Factory",
    impactedItems: "Keyboard",
    issueDetails: "Spacebar keycap wobble exceeding 0.5mm tolerance",
    issueStatus: "Analyze",
  },
  {
    id: "BLD-4005",
    buildType: "pilot" as const,
    labels: "Cosmetic",
    severity: "SEV 3",
    dfmaaStatus: "Analyze",
    affectedPlatforms: "Laptop 4",
    affectedLOBs: "CSG",
    affectedSubLOBs: "Notebook",
    formFactor: "Clamshell",
    enterPhase: "PVT",
    impactedSite: "CSG ODM Factory",
    impactedItems: "Palm Rest",
    issueDetails: "Anodization color mismatch between lid and palm rest on 5% of units",
    issueStatus: "Closed",
  },
];

const buildIssuesScoringData = [
  { id: "BLD-4001", decorativeFinishes: "N/A", mfgDiagnostics: "3 - High", supplyChain: "N/A", dfx: "3 - High", packaging: "N/A", orderProcessing: "N/A", riskImpact: 3, riskProbability: 3, riskPriority: 9, overallRiskLevel: "H", overallStatus: "OPEN" },
  { id: "BLD-4002", decorativeFinishes: "N/A", mfgDiagnostics: "2 - Moderate", supplyChain: "N/A", dfx: "2 - Moderate", packaging: "N/A", orderProcessing: "N/A", riskImpact: 2, riskProbability: 2, riskPriority: 4, overallRiskLevel: "M", overallStatus: "NONE" },
  { id: "BLD-4003", decorativeFinishes: "N/A", mfgDiagnostics: "N/A", supplyChain: "2 - Moderate", dfx: "N/A", packaging: "1 - Low", orderProcessing: "N/A", riskImpact: 2, riskProbability: 1, riskPriority: 2, overallRiskLevel: "L", overallStatus: "NONE" },
  { id: "BLD-4004", decorativeFinishes: "N/A", mfgDiagnostics: "1 - Low", supplyChain: "N/A", dfx: "N/A", packaging: "N/A", orderProcessing: "1 - Low", riskImpact: 1, riskProbability: 1, riskPriority: 1, overallRiskLevel: "L", overallStatus: "NONE" },
  { id: "BLD-4005", decorativeFinishes: "2 - Moderate", mfgDiagnostics: "N/A", supplyChain: "N/A", dfx: "N/A", packaging: "N/A", orderProcessing: "N/A", riskImpact: 1, riskProbability: 2, riskPriority: 2, overallRiskLevel: "L", overallStatus: "NONE" },
];

const mraChecklist = {
  qual: [
    { label: "BOM finalized for Qual build", done: true },
    { label: "MRA readiness confirmed for qualification builds", done: true },
    { label: "Critical components sourced and allocated", done: false },
    { label: "Supplier PPAP approvals received", done: false },
    { label: "Test fixtures and tooling ready", done: true },
  ],
  pilot: [
    { label: "Pilot CTO MRA prepared to readiness state", done: false },
    { label: "Full BOM cost validation complete", done: false },
    { label: "Factory line qualification passed", done: false },
    { label: "Packaging and logistics plan confirmed", done: false },
    { label: "SW image and golden configs locked", done: true },
  ],
};

const BuildExecutionContent = () => {

  const [selectedOrder, setSelectedOrder] = useState<string | null>(null);
  const [buildType, setBuildType] = useState("all");
  const [selectedIssue, setSelectedIssue] = useState<(typeof buildIssuesData[0] & typeof buildIssuesScoringData[0]) | null>(null);
  const selected = recentOrders.find((o) => o.order === selectedOrder);
  const { filters } = useUniversalFilters();

  const qualMraDone = mraChecklist.qual.filter(i => i.done).length;
  const pilotMraDone = mraChecklist.pilot.filter(i => i.done).length;

  const filteredIssues = useMemo(() => {
    return buildIssuesData.filter((row) => {
      // Build type tab
      if (buildType !== "all" && row.buildType !== buildType) return false;
      // LOB filter — match against affectedSubLOBs (Notebook/Desktop/Workstation) or affectedLOBs (CSG/ISG/DnCP)
      if (filters.lob !== "all") {
        const lobMatch =
          row.affectedSubLOBs === filters.lob ||
          row.affectedLOBs === filters.lob ||
          (filters.lob === "Desktop" && row.affectedSubLOBs === "Workstation");
        if (!lobMatch) return false;
      }
      // Platform filter
      if (filters.platform !== "all" && row.affectedPlatforms !== filters.platform) return false;
      // Phase filter (matches enterPhase aliases like DVT/PVT)
      if (filters.phase !== "all" && !phaseMatches(filters.phase, row.enterPhase)) return false;
      // Task category filter — match against labels
      if (filters.task !== "all" && !row.labels.toLowerCase().includes(filters.task.toLowerCase())) return false;
      return true;
    });
  }, [buildType, filters]);


  return (
    <div className="flex-1 flex flex-col overflow-auto p-5">
      <div className="flex items-center justify-between mb-4">
        <h1 className="text-[22px] font-extrabold text-foreground tracking-tight">Build Execution</h1>
        <UniversalFilterBar />
        <Tabs value={buildType} onValueChange={setBuildType}>
          <TabsList className="h-8">
            <TabsTrigger value="all" className="text-xs px-3 py-1">All Builds</TabsTrigger>
            <TabsTrigger value="qual" className="text-xs px-3 py-1">Qual Build</TabsTrigger>
            <TabsTrigger value="pilot" className="text-xs px-3 py-1">Pilot Build</TabsTrigger>
          </TabsList>
        </Tabs>
      </div>

      {/* MRA Status Card */}
      <div className="grid grid-cols-2 gap-4 mb-4">
        <div className="border border-border rounded-lg bg-card p-4">
          <div className="flex items-center gap-2 mb-3">
            <ClipboardCheck className="w-4 h-4 text-primary" />
            <h3 className="text-xs font-semibold text-foreground">Qual Build MRA Status</h3>
            <span className="ml-auto text-[10px] font-bold text-muted-foreground">{qualMraDone}/{mraChecklist.qual.length}</span>
          </div>
          <div className="w-full h-1.5 bg-muted rounded-full overflow-hidden mb-2">
            <div className="h-full bg-primary rounded-full transition-all" style={{ width: `${(qualMraDone / mraChecklist.qual.length) * 100}%` }} />
          </div>
          <div className="space-y-1.5">
            {mraChecklist.qual.map((item, i) => (
              <div key={i} className="flex items-center gap-2">
                {item.done ? (
                  <CheckCircle2 className="w-3.5 h-3.5 text-success shrink-0" />
                ) : (
                  <Circle className="w-3.5 h-3.5 text-muted-foreground shrink-0" />
                )}
                <span className={`text-[10px] ${item.done ? "text-muted-foreground line-through" : "text-foreground"}`}>{item.label}</span>
              </div>
            ))}
          </div>
        </div>
        <div className="border border-border rounded-lg bg-card p-4">
          <div className="flex items-center gap-2 mb-3">
            <ClipboardCheck className="w-4 h-4 text-warning" />
            <h3 className="text-xs font-semibold text-foreground">Pilot Build MRA Status</h3>
            <span className="ml-auto text-[10px] font-bold text-muted-foreground">{pilotMraDone}/{mraChecklist.pilot.length}</span>
          </div>
          <div className="w-full h-1.5 bg-muted rounded-full overflow-hidden mb-2">
            <div className="h-full bg-warning rounded-full transition-all" style={{ width: `${(pilotMraDone / mraChecklist.pilot.length) * 100}%` }} />
          </div>
          <div className="space-y-1.5">
            {mraChecklist.pilot.map((item, i) => (
              <div key={i} className="flex items-center gap-2">
                {item.done ? (
                  <CheckCircle2 className="w-3.5 h-3.5 text-success shrink-0" />
                ) : (
                  <Circle className="w-3.5 h-3.5 text-muted-foreground shrink-0" />
                )}
                <span className={`text-[10px] ${item.done ? "text-muted-foreground line-through" : "text-foreground"}`}>{item.label}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="grid grid-cols-12 gap-4 min-h-0">
        {/* Factory Order Status */}
        <div className="col-span-5 border border-border rounded-lg bg-card overflow-hidden flex flex-col">
          <div className="bg-primary px-4 py-2">
            <h2 className="text-sm font-bold text-primary-foreground text-center">
              Factory Order Status {buildType !== "all" ? `— ${buildType === "qual" ? "Qual Build" : "Pilot Build"}` : ""}
            </h2>
          </div>
          <div className="p-4 space-y-4 flex-1">
            {orderStatusItems.map((item) => (
              <div key={item.label} className="flex items-center gap-3">
                <item.icon className="w-5 h-5 shrink-0 text-muted-foreground" />
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-xs font-semibold text-foreground">{item.percent}% ({item.count} of {item.total})</span>
                  </div>
                  <div className="w-full h-2 bg-muted rounded-full overflow-hidden">
                    <div
                      className="h-full rounded-full transition-all"
                      style={{ width: `${item.percent}%`, backgroundColor: item.color }}
                    />
                  </div>
                  <span className="text-[10px] text-muted-foreground mt-0.5 block">{item.label}</span>
                </div>
              </div>
            ))}

            <div className="border-t border-border pt-3 mt-3">
              <h3 className="text-xs font-semibold text-foreground mb-2">Recent Orders</h3>
              <div className="space-y-1">
                {recentOrders.map((o) => (
                  <button
                    key={o.order}
                    onClick={() => setSelectedOrder(o.order === selectedOrder ? null : o.order)}
                    className={`w-full flex justify-between text-xs px-2 py-1.5 rounded-md transition-colors ${
                      selectedOrder === o.order
                        ? "bg-primary/10 text-primary font-semibold"
                        : "hover:bg-accent/50 text-foreground"
                    }`}
                  >
                    <span>{o.order}</span>
                    <span className="text-muted-foreground">{o.factory}</span>
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Order Progress Tracker */}
        <div className="col-span-7 border border-border rounded-lg bg-card overflow-hidden flex flex-col">
          {selected ? (
            <>
              <div className="bg-primary px-4 py-2">
                <h2 className="text-sm font-bold text-primary-foreground text-center">
                  {selected.order} — {selected.factory}
                </h2>
              </div>
              <div className="p-6 flex-1 flex items-center justify-center">
                <div className="w-full max-w-md">
                  {stepLabels.map((step, i) => {
                    const status = selected.progress[step.key];
                    const config = statusStyles[status];
                    const StatusIcon = config.icon;
                    const isLast = i === stepLabels.length - 1;

                    return (
                      <div key={step.key} className="flex gap-4">
                        <div className="flex flex-col items-center">
                          <div className={`w-8 h-8 rounded-full flex items-center justify-center border-2 ${
                            status === "complete"
                              ? "border-success bg-success/10"
                              : status === "in-progress"
                              ? "border-warning bg-warning/10"
                              : "border-muted bg-muted/30"
                          }`}>
                            <StatusIcon className={`w-4 h-4 ${config.className} ${status === "in-progress" ? "animate-spin" : ""}`} />
                          </div>
                          {!isLast && (
                            <div className={`w-0.5 h-10 ${
                              status === "complete" ? config.barClass : "bg-muted"
                            }`} />
                          )}
                        </div>
                        <div className="pt-1.5">
                          <p className={`text-sm font-medium ${
                            status === "pending" ? "text-muted-foreground" : "text-foreground"
                          }`}>
                            {step.label}
                          </p>
                          <p className="text-[10px] text-muted-foreground capitalize">{status === "in-progress" ? "In Progress" : status}</p>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </>
          ) : (
            <div className="flex-1 flex items-center justify-center text-sm text-muted-foreground">
              Select a recent order to view its progress.
            </div>
          )}
        </div>
      </div>

      {/* Build Issue Tracking */}
      <div className="mt-4">
        <div className="flex items-center justify-between mb-2">
          <h2 className="text-xs font-semibold text-foreground">Build Issue Tracking</h2>
          <span className="text-[10px] text-muted-foreground">
            Showing {filteredIssues.length} of {buildIssuesData.length} issues
          </span>
        </div>
        <div className="border border-border rounded-lg bg-card overflow-auto">
          <Table>
            <TableHeader>
              <TableRow className="bg-muted/50">
                <TableHead className="text-[10px] h-7 px-2">ID</TableHead>
                <TableHead className="text-[10px] h-7 px-2">Build Type</TableHead>
                <TableHead className="text-[10px] h-7 px-2">Labels</TableHead>
                <TableHead className="text-[10px] h-7 px-2">Severity</TableHead>
                <TableHead className="text-[10px] h-7 px-2">DFMAA Status</TableHead>
                <TableHead className="text-[10px] h-7 px-2">Affected Platform(s)</TableHead>
                <TableHead className="text-[10px] h-7 px-2 text-center">Risk Impact Level</TableHead>
                <TableHead className="text-[10px] h-7 px-2 text-center">Risk Probability</TableHead>
                <TableHead className="text-[10px] h-7 px-2 text-center">Risk Priority</TableHead>
                <TableHead className="text-[10px] h-7 px-2 text-center">Overall Risk Level</TableHead>
                <TableHead className="text-[10px] h-7 px-2">Impacted Site</TableHead>
                <TableHead className="text-[10px] h-7 px-2">Affected LOB(s)</TableHead>
                <TableHead className="text-[10px] h-7 px-2">Sub-LOB(s)</TableHead>
                <TableHead className="text-[10px] h-7 px-2">Form Factor</TableHead>
                <TableHead className="text-[10px] h-7 px-2">Enter Phase</TableHead>
                <TableHead className="text-[10px] h-7 px-2">Issue Status</TableHead>
                <TableHead className="text-[10px] h-7 px-2">Decorative Finishes</TableHead>
                <TableHead className="text-[10px] h-7 px-2">Mfg Diagnostics</TableHead>
                <TableHead className="text-[10px] h-7 px-2">Supply Chain</TableHead>
                <TableHead className="text-[10px] h-7 px-2">DFx</TableHead>
                <TableHead className="text-[10px] h-7 px-2">Packaging</TableHead>
                <TableHead className="text-[10px] h-7 px-2">Order Processing</TableHead>
                <TableHead className="text-[10px] h-7 px-2">Overall Status</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredIssues.length === 0 && (
                <TableRow>
                  <TableCell colSpan={23} className="text-[11px] text-muted-foreground text-center py-6">
                    No build issues match the current filters.
                  </TableCell>
                </TableRow>
              )}
              {filteredIssues.map((info, idx) => {
                const scoring = buildIssuesScoringData.find((s) => s.id === info.id);
                const row = { ...info, ...scoring! };
                return (
                  <TableRow
                    key={row.id}
                    className={`hover:bg-accent/60 transition-colors cursor-pointer ${idx % 2 === 0 ? "bg-card" : "bg-muted/10"}`}
                    onClick={() => setSelectedIssue(row)}
                  >
                    <TableCell className="text-[10px] py-1 px-2 font-medium text-primary whitespace-nowrap">{row.id}</TableCell>
                    <TableCell className="text-[10px] py-1 px-2">
                      <Badge variant={row.buildType === "qual" ? "outline" : "secondary"} className="text-[9px] px-1 py-0 capitalize">
                        {row.buildType === "qual" ? "Qual Build" : "Pilot Build"}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-[10px] py-1 px-2">{row.labels}</TableCell>
                    <TableCell className="text-[10px] py-1 px-2">
                      <Badge variant={row.severity === "SEV 1" ? "destructive" : "outline"} className="text-[9px] px-1 py-0">{row.severity}</Badge>
                    </TableCell>
                    <TableCell className="text-[10px] py-1 px-2">{row.dfmaaStatus}</TableCell>
                    <TableCell className="text-[10px] py-1 px-2 max-w-[120px] truncate">{row.affectedPlatforms}</TableCell>
                    <TableCell className="text-[10px] py-1 px-2 text-center font-mono">{row.riskImpact}</TableCell>
                    <TableCell className="text-[10px] py-1 px-2 text-center font-mono">{row.riskProbability}</TableCell>
                    <TableCell className="text-[10px] py-1 px-2 text-center font-mono font-bold">{row.riskPriority}</TableCell>
                    <TableCell className="text-[10px] py-1 px-2 text-center">
                      <Badge variant={row.overallRiskLevel === "H" ? "destructive" : row.overallRiskLevel === "M" ? "outline" : "secondary"} className="text-[9px] px-1 py-0">{row.overallRiskLevel}</Badge>
                    </TableCell>
                    <TableCell className="text-[10px] py-1 px-2 max-w-[120px] truncate">{row.impactedSite}</TableCell>
                    <TableCell className="text-[10px] py-1 px-2">{row.affectedLOBs}</TableCell>
                    <TableCell className="text-[10px] py-1 px-2">{row.affectedSubLOBs}</TableCell>
                    <TableCell className="text-[10px] py-1 px-2">{row.formFactor}</TableCell>
                    <TableCell className="text-[10px] py-1 px-2">{row.enterPhase}</TableCell>
                    <TableCell className="text-[10px] py-1 px-2">
                      <Badge variant={row.issueStatus === "Closed" ? "secondary" : "outline"} className="text-[9px] px-1 py-0">{row.issueStatus}</Badge>
                    </TableCell>
                    <TableCell className="text-[10px] py-1 px-2">{row.decorativeFinishes}</TableCell>
                    <TableCell className="text-[10px] py-1 px-2">{row.mfgDiagnostics}</TableCell>
                    <TableCell className="text-[10px] py-1 px-2">{row.supplyChain}</TableCell>
                    <TableCell className="text-[10px] py-1 px-2">{row.dfx}</TableCell>
                    <TableCell className="text-[10px] py-1 px-2">{row.packaging}</TableCell>
                    <TableCell className="text-[10px] py-1 px-2">{row.orderProcessing}</TableCell>
                    <TableCell className="text-[10px] py-1 px-2">{row.overallStatus}</TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </div>
      </div>

      {/* Build Issue Detail Dialog */}
      <Dialog open={!!selectedIssue} onOpenChange={(v) => { if (!v) setSelectedIssue(null); }}>
        <DialogContent className="max-w-2xl max-h-[80vh] overflow-auto">
          <DialogHeader>
            <DialogTitle className="text-base">{selectedIssue ? `${selectedIssue.id} — ${selectedIssue.issueDetails?.slice(0, 60)}…` : ""}</DialogTitle>
          </DialogHeader>
          {selectedIssue && (
            <div className="grid grid-cols-2 gap-x-6 gap-y-3 mt-2">
              {([
                { label: "ID", value: selectedIssue.id },
                { label: "Build Type", value: selectedIssue.buildType === "qual" ? "Qual Build" : "Pilot Build" },
                { label: "Labels", value: selectedIssue.labels },
                { label: "Severity", value: selectedIssue.severity },
                { label: "DFMAA Status", value: selectedIssue.dfmaaStatus },
                { label: "Affected Platform(s)", value: selectedIssue.affectedPlatforms },
                { label: "Affected LOB(s)", value: selectedIssue.affectedLOBs },
                { label: "Affected Sub-LOB(s)", value: selectedIssue.affectedSubLOBs },
                { label: "Form Factor", value: selectedIssue.formFactor },
                { label: "Enter Phase", value: selectedIssue.enterPhase },
                { label: "Impacted Site", value: selectedIssue.impactedSite },
                { label: "Impacted Items", value: selectedIssue.impactedItems },
                { label: "Issue Status", value: selectedIssue.issueStatus },
                { label: "Issue Details", value: selectedIssue.issueDetails, wide: true },
                { label: "Risk Impact Level", value: selectedIssue.riskImpact },
                { label: "Risk Probability", value: selectedIssue.riskProbability },
                { label: "Risk Priority", value: selectedIssue.riskPriority },
                { label: "Overall Risk Level", value: selectedIssue.overallRiskLevel },
                { label: "Decorative Finishes", value: selectedIssue.decorativeFinishes },
                { label: "Mfg Diagnostics", value: selectedIssue.mfgDiagnostics },
                { label: "Supply Chain", value: selectedIssue.supplyChain },
                { label: "DFx", value: selectedIssue.dfx },
                { label: "Packaging", value: selectedIssue.packaging },
                { label: "Order Processing", value: selectedIssue.orderProcessing },
                { label: "Overall Status", value: selectedIssue.overallStatus },
              ] as { label: string; value: string | number | undefined; wide?: boolean }[]).map((r, i) => (
                <div key={i} className={r.wide ? "col-span-2" : ""}>
                  <p className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider">{r.label}</p>
                  <p className="text-[13px] text-foreground mt-0.5 leading-relaxed">{r.value ?? "—"}</p>
                </div>
              ))}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
};

const BuildExecution = () => (
  <ComingSoonBanner message="To be completed in version 2.0">
    <BuildExecutionContent />
  </ComingSoonBanner>
);

export default BuildExecution;