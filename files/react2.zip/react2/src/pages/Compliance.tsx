import ComingSoonBanner from "@/components/dashboard/ComingSoonBanner";

const Compliance = () => <ComingSoonBanner />;

export default Compliance;
