import { useState } from "react";
import { programSchedules } from "@/data/scheduleData";
import type { ScheduleTask } from "@/data/scheduleData";
import MyTasksList from "@/components/dashboard/MyTasksList";
import CurrentTaskDetail from "@/components/dashboard/CurrentTaskDetail";
import RelevantInfoPanel from "@/components/dashboard/RelevantInfoPanel";
import { usePlatform } from "@/contexts/PlatformContext";
import UniversalFilterBar from "@/components/dashboard/UniversalFilterBar";

const CurrentTask = () => {

  const { selectedPlatform } = usePlatform();
  const program = selectedPlatform ?? "Laptop 1";
  const phases = programSchedules[program] ?? programSchedules["Laptop 1"];

  const [selectedTask, setSelectedTask] = useState<{
    task: ScheduleTask;
    phaseName: string;
    milestoneName: string;
  } | null>(null);

  const handleSelectTask = (task: ScheduleTask, phaseName: string, milestoneName: string) => {
    setSelectedTask({ task, phaseName, milestoneName });
  };

  return (
    <div className="p-4 h-[calc(100vh-56px)]">
      <div className="flex items-center justify-between mb-3">
        <h1 className="text-sm font-bold text-foreground">{selectedPlatform ? `${program} — Current Task` : "All Platforms — Current Task"}</h1>
        <UniversalFilterBar />
      </div>
      <div className="flex gap-3 h-[calc(100%-36px)]">
        {/* Left: My Tasks — always visible */}
        <div className={selectedTask ? "w-[280px] shrink-0" : "w-full max-w-md"}>
          <MyTasksList
            phases={phases}
            selectedTaskId={selectedTask?.task.id ?? null}
            onSelectTask={handleSelectTask}
          />
        </div>

        {/* Center + Right: only when a task is selected */}
        {selectedTask && (
          <>
            <div className="flex-1 min-w-0">
              <CurrentTaskDetail
                task={selectedTask.task}
                phaseName={selectedTask.phaseName}
                milestoneName={selectedTask.milestoneName}
              />
            </div>
            <div className="w-[280px] shrink-0">
              <RelevantInfoPanel
                task={selectedTask.task}
                phaseName={selectedTask.phaseName}
              />
            </div>
          </>
        )}
      </div>
    </div>
  );
};

export default CurrentTask;
