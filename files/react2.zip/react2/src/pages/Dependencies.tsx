import { useState, useMemo } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { GitBranch, ArrowRight, Filter, AlertTriangle, Link2, Bell } from "lucide-react";
import { cn } from "@/lib/utils";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import UniversalFilterBar from "@/components/dashboard/UniversalFilterBar";
import { useUniversalFilters } from "@/contexts/UniversalFilterContext";

type ProgramType = "HW" | "SW";

interface Program {
  name: string;
  type: ProgramType;
  phase: string;
  status: "On Track" | "At Risk w/ No Plan" | "At Risk w/ Mitigation";
}

const allPrograms: Program[] = [
  { name: "Laptop 1", type: "HW", phase: "Plan", status: "On Track" },
  { name: "Laptop 2", type: "HW", phase: "Qual", status: "At Risk w/ No Plan" },
  { name: "Laptop 3", type: "HW", phase: "Plan", status: "At Risk w/ Mitigation" },
  { name: "Laptop 4", type: "HW", phase: "Define", status: "On Track" },
  { name: "Laptop 5", type: "HW", phase: "Define", status: "On Track" },
  { name: "Laptop 6", type: "SW", phase: "Plan", status: "On Track" },
  { name: "Laptop 7", type: "SW", phase: "Define", status: "At Risk w/ Mitigation" },
  { name: "BIOS Platform", type: "SW", phase: "Plan", status: "On Track" },
  { name: "Thermal FW", type: "SW", phase: "Qual", status: "At Risk w/ No Plan" },
  { name: "Display Driver", type: "SW", phase: "Plan", status: "On Track" },
  { name: "Power Manager FW", type: "SW", phase: "Define", status: "At Risk w/ Mitigation" },
  { name: "EC Firmware", type: "SW", phase: "Plan", status: "On Track" },
];

interface Dependency {
  id: string;
  hwProgram: string;
  swProgram: string;
  dependency: string;
  direction: "SW→HW" | "HW→SW" | "Bidirectional";
  status: "active" | "at-risk" | "impacted" | "resolved";
  impact: string;
  notification: string | null;
}

const mockDependencies: Dependency[] = [
  { id: "d1", hwProgram: "Laptop 1", swProgram: "BIOS Platform", dependency: "BIOS requires final thermal table from HW DVT2", direction: "SW→HW", status: "active", impact: "BIOS release blocked until thermal characterization complete", notification: null },
  { id: "d2", hwProgram: "Laptop 2", swProgram: "Thermal FW", dependency: "Thermal FW tuning depends on HW PVT thermal data", direction: "SW→HW", status: "impacted", impact: "Laptop 2 DVT2 delayed — Thermal FW cannot validate fan curves", notification: "Laptop 2 schedule slip detected. Thermal FW team notified." },
  { id: "d3", hwProgram: "Laptop 1", swProgram: "Display Driver", dependency: "Display driver needs panel timing specs from HW", direction: "SW→HW", status: "active", impact: "Driver development on hold pending panel selection", notification: null },
  { id: "d4", hwProgram: "Laptop 3", swProgram: "EC Firmware", dependency: "EC FW keyboard matrix depends on HW keyboard design", direction: "SW→HW", status: "at-risk", impact: "Laptop 3 keyboard design change may require EC FW rework", notification: "Laptop 3 keyboard design revision flagged. EC Firmware impact under review." },
  { id: "d5", hwProgram: "Laptop 4", swProgram: "Power Manager FW", dependency: "Power states require HW voltage rail design", direction: "SW→HW", status: "at-risk", impact: "Power Manager FW cannot finalize sleep states", notification: "Power Manager FW blocked — Laptop 4 voltage rail design pending." },
  { id: "d6", hwProgram: "Laptop 1", swProgram: "EC Firmware", dependency: "HW needs EC FW for DVT2 board bring-up", direction: "HW→SW", status: "active", impact: "Laptop 1 DVT2 build requires stable EC firmware drop", notification: null },
  { id: "d7", hwProgram: "Laptop 5", swProgram: "BIOS Platform", dependency: "BIOS must support new memory topology", direction: "SW→HW", status: "active", impact: "Memory training code needs HW schematic finalization", notification: null },
  { id: "d8", hwProgram: "Laptop 2", swProgram: "Display Driver", dependency: "HW display integration test needs driver", direction: "HW→SW", status: "impacted", impact: "Laptop 2 display validation blocked by driver delay", notification: "Display Driver team alerted: Laptop 2 needs driver drop by W26." },
  { id: "d9", hwProgram: "Laptop 3", swProgram: "BIOS Platform", dependency: "BIOS needs HW ACPI table definitions", direction: "Bidirectional", status: "active", impact: "Both teams must align on ACPI spec by Plan exit", notification: null },
  { id: "d10", hwProgram: "Laptop 1", swProgram: "Thermal FW", dependency: "Thermal FW provides fan control for HW thermal validation", direction: "Bidirectional", status: "resolved", impact: "Resolved — FW drop delivered, HW validation complete", notification: null },
  { id: "d11", hwProgram: "Laptop 4", swProgram: "EC Firmware", dependency: "EC FW battery management depends on HW battery design", direction: "SW→HW", status: "active", impact: "Battery charging profiles pending HW cell selection", notification: null },
  { id: "d12", hwProgram: "Laptop 5", swProgram: "Thermal FW", dependency: "HW thermal solution change impacts FW fan curves", direction: "HW→SW", status: "at-risk", impact: "Laptop 5 thermal redesign requires Thermal FW re-tuning", notification: "Laptop 5 thermal solution changed. Thermal FW re-tuning required." },
];

const statusColors: Record<string, string> = {
  active: "bg-blue-100 text-blue-800 border-blue-200",
  resolved: "bg-green-100 text-green-800 border-green-200",
  "at-risk": "bg-yellow-100 text-yellow-800 border-yellow-200",
  impacted: "bg-red-100 text-red-800 border-red-200",
};

const directionColors: Record<string, string> = {
  "SW→HW": "bg-purple-100 text-purple-800 border-purple-200",
  "HW→SW": "bg-indigo-100 text-indigo-800 border-indigo-200",
  Bidirectional: "bg-gray-100 text-gray-700 border-gray-200",
};

const programStatusColors: Record<string, string> = {
  "On Track": "bg-green-500",
  "At Risk w/ No Plan": "bg-red-500",
  "At Risk w/ Mitigation": "bg-yellow-500",
};

const Dependencies = () => {
  const { matchesPlatform } = useUniversalFilters();
  const [filterProgram, setFilterProgram] = useState<string>("all");
  const [filterDirection, setFilterDirection] = useState<string>("all");
  const [filterStatus, setFilterStatus] = useState<string>("all");
  const [selected, setSelected] = useState<Dependency | null>(null);
  const [highlightedPrograms, setHighlightedPrograms] = useState<string[]>([]);

  const platformFiltered = useMemo(() => mockDependencies.filter(d => matchesPlatform(d.hwProgram) || matchesPlatform(d.swProgram)), [matchesPlatform]);

  const filtered = useMemo(() => {
    return platformFiltered.filter((d) => {
      if (filterProgram !== "all" && d.hwProgram !== filterProgram && d.swProgram !== filterProgram) return false;
      if (filterDirection !== "all" && d.direction !== filterDirection) return false;
      if (filterStatus !== "all" && d.status !== filterStatus) return false;
      return true;
    });
  }, [filterProgram, filterDirection, filterStatus, platformFiltered]);

  const stats = useMemo(() => ({
    total: platformFiltered.length,
    active: platformFiltered.filter(d => d.status === "active").length,
    atRisk: platformFiltered.filter(d => d.status === "at-risk").length,
    impacted: platformFiltered.filter(d => d.status === "impacted").length,
    notifications: platformFiltered.filter(d => d.notification).length,
  }), [platformFiltered]);

  const hwPrograms = allPrograms.filter(p => p.type === "HW");
  const swPrograms = allPrograms.filter(p => p.type === "SW");

  const handleProgramClick = (programName: string) => {
    const linked = mockDependencies
      .filter(d => d.hwProgram === programName || d.swProgram === programName)
      .flatMap(d => [d.hwProgram, d.swProgram])
      .filter(p => p !== programName);
    setHighlightedPrograms(prev =>
      prev.includes(programName) ? [] : [programName, ...new Set(linked)]
    );
    setFilterProgram(prev => prev === programName ? "all" : programName);
  };

  // SVG graph positions
  const hwX = 80;
  const swX = 520;
  const nodeStartY = 30;
  const nodeSpacing = 52;

  const hwPositions: Record<string, number> = {};
  hwPrograms.forEach((p, i) => { hwPositions[p.name] = nodeStartY + i * nodeSpacing; });
  const swPositions: Record<string, number> = {};
  swPrograms.forEach((p, i) => { swPositions[p.name] = nodeStartY + i * nodeSpacing; });

  const svgHeight = Math.max(hwPrograms.length, swPrograms.length) * nodeSpacing + 40;

  return (
    <div className="flex-1 flex flex-col overflow-auto p-4 space-y-4">
      <div className="flex items-center gap-2">
        <GitBranch className="w-4 h-4 text-primary" />
        <h1 className="text-sm font-bold text-foreground flex-1">SW ↔ HW Dependencies</h1>
        <UniversalFilterBar />
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-5 gap-3">
        {[
          { label: "Total Dependencies", value: stats.total, color: "text-foreground" },
          { label: "Active", value: stats.active, color: "text-blue-600" },
          { label: "At Risk", value: stats.atRisk, color: "text-yellow-600" },
          { label: "Impacted", value: stats.impacted, color: "text-destructive" },
          { label: "Notifications Sent", value: stats.notifications, color: "text-primary" },
        ].map(s => (
          <Card key={s.label} className="border-border">
            <CardContent className="p-3">
              <p className="text-[10px] text-muted-foreground uppercase tracking-wider font-semibold">{s.label}</p>
              <p className={cn("text-xl font-bold", s.color)}>{s.value}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Filters */}
      <div className="flex items-center gap-3">
        <Filter className="w-3.5 h-3.5 text-muted-foreground" />
        <Select value={filterProgram} onValueChange={v => { setFilterProgram(v); setHighlightedPrograms([]); }}>
          <SelectTrigger className="w-[170px] h-8 text-xs"><SelectValue placeholder="All Programs" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Programs</SelectItem>
            {allPrograms.map(p => (
              <SelectItem key={p.name} value={p.name}>
                <span className="flex items-center gap-1.5">
                  <Badge variant="outline" className={cn("text-[8px] px-1 py-0", p.type === "HW" ? "bg-indigo-100 text-indigo-700" : "bg-purple-100 text-purple-700")}>{p.type}</Badge>
                  {p.name}
                </span>
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Select value={filterDirection} onValueChange={setFilterDirection}>
          <SelectTrigger className="w-[140px] h-8 text-xs"><SelectValue placeholder="All Directions" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Directions</SelectItem>
            <SelectItem value="SW→HW">SW → HW</SelectItem>
            <SelectItem value="HW→SW">HW → SW</SelectItem>
            <SelectItem value="Bidirectional">Bidirectional</SelectItem>
          </SelectContent>
        </Select>
        <Select value={filterStatus} onValueChange={setFilterStatus}>
          <SelectTrigger className="w-[130px] h-8 text-xs"><SelectValue placeholder="All Status" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Status</SelectItem>
            <SelectItem value="active">Active</SelectItem>
            <SelectItem value="at-risk">At Risk</SelectItem>
            <SelectItem value="impacted">Impacted</SelectItem>
            <SelectItem value="resolved">Resolved</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Visual Graph */}
      <Card className="border-border overflow-auto">
        <CardHeader className="pb-2 pt-3 px-4">
          <CardTitle className="text-xs flex items-center gap-2">
            <Link2 className="w-3.5 h-3.5" />
            Dependency Map — Click a program to highlight its links
          </CardTitle>
        </CardHeader>
        <CardContent className="p-4 overflow-x-auto">
          <svg width={620} height={svgHeight} className="min-w-[620px]">
            {/* Column labels */}
            <text x={hwX} y={16} textAnchor="middle" className="fill-muted-foreground text-[10px] font-bold uppercase tracking-wider">Hardware</text>
            <text x={swX} y={16} textAnchor="middle" className="fill-muted-foreground text-[10px] font-bold uppercase tracking-wider">Software</text>

            {/* Arrows */}
            <defs>
              <marker id="dep-arrow" markerWidth="8" markerHeight="6" refX="8" refY="3" orient="auto">
                <polygon points="0 0, 8 3, 0 6" className="fill-muted-foreground/60" />
              </marker>
              <marker id="dep-arrow-risk" markerWidth="8" markerHeight="6" refX="8" refY="3" orient="auto">
                <polygon points="0 0, 8 3, 0 6" fill="#f59e0b" />
              </marker>
              <marker id="dep-arrow-impacted" markerWidth="8" markerHeight="6" refX="8" refY="3" orient="auto">
                <polygon points="0 0, 8 3, 0 6" fill="#ef4444" />
              </marker>
            </defs>

            {filtered.map(d => {
              const hwY = hwPositions[d.hwProgram];
              const swY = swPositions[d.swProgram];
              if (hwY === undefined || swY === undefined) return null;

              const isHighlighted = highlightedPrograms.length === 0 ||
                highlightedPrograms.includes(d.hwProgram) || highlightedPrograms.includes(d.swProgram);

              const color = d.status === "impacted" ? "#ef4444"
                : d.status === "at-risk" ? "#f59e0b"
                : d.status === "resolved" ? "#22c55e"
                : "#94a3b8";
              const marker = d.status === "impacted" ? "url(#dep-arrow-impacted)"
                : d.status === "at-risk" ? "url(#dep-arrow-risk)"
                : "url(#dep-arrow)";

              const x1 = hwX + 70;
              const x2 = swX - 70;

              return (
                <g key={d.id} opacity={isHighlighted ? 1 : 0.15}>
                  {d.direction === "Bidirectional" ? (
                    <>
                      <line x1={x1} y1={hwY - 2} x2={x2} y2={swY - 2} stroke={color} strokeWidth={1.5} markerEnd={marker} />
                      <line x1={x2} y1={swY + 2} x2={x1} y2={hwY + 2} stroke={color} strokeWidth={1.5} markerEnd={marker} />
                    </>
                  ) : d.direction === "HW→SW" ? (
                    <line x1={x1} y1={hwY} x2={x2} y2={swY} stroke={color} strokeWidth={1.5} markerEnd={marker} />
                  ) : (
                    <line x1={x2} y1={swY} x2={x1} y2={hwY} stroke={color} strokeWidth={1.5} markerEnd={marker} />
                  )}
                  {d.notification && (
                    <circle cx={(x1 + x2) / 2} cy={(hwY + swY) / 2 - 6} r={4} fill="#ef4444" />
                  )}
                </g>
              );
            })}

            {/* HW nodes */}
            {hwPrograms.map(p => {
              const y = hwPositions[p.name];
              const isHL = highlightedPrograms.length === 0 || highlightedPrograms.includes(p.name);
              return (
                <g key={p.name} onClick={() => handleProgramClick(p.name)} className="cursor-pointer" opacity={isHL ? 1 : 0.25}>
                  <rect x={hwX - 65} y={y - 14} width={130} height={28} rx={6}
                    className={cn("stroke-border", highlightedPrograms.includes(p.name) ? "fill-primary/10 stroke-primary" : "fill-card")}
                    strokeWidth={highlightedPrograms.includes(p.name) ? 2 : 1} />
                  <circle cx={hwX - 50} cy={y} r={4} className={programStatusColors[p.status]} />
                  <text x={hwX - 40} y={y + 4} className="fill-foreground text-[10px] font-medium">{p.name}</text>
                  <text x={hwX + 55} y={y + 3} textAnchor="end" className="fill-muted-foreground text-[8px]">HW</text>
                </g>
              );
            })}

            {/* SW nodes */}
            {swPrograms.map(p => {
              const y = swPositions[p.name];
              const isHL = highlightedPrograms.length === 0 || highlightedPrograms.includes(p.name);
              return (
                <g key={p.name} onClick={() => handleProgramClick(p.name)} className="cursor-pointer" opacity={isHL ? 1 : 0.25}>
                  <rect x={swX - 65} y={y - 14} width={130} height={28} rx={6}
                    className={cn("stroke-border", highlightedPrograms.includes(p.name) ? "fill-primary/10 stroke-primary" : "fill-card")}
                    strokeWidth={highlightedPrograms.includes(p.name) ? 2 : 1} />
                  <circle cx={swX - 50} cy={y} r={4} className={programStatusColors[p.status]} />
                  <text x={swX - 40} y={y + 4} className="fill-foreground text-[10px] font-medium">{p.name}</text>
                  <text x={swX + 55} y={y + 3} textAnchor="end" className="fill-muted-foreground text-[8px]">SW</text>
                </g>
              );
            })}
          </svg>
        </CardContent>
      </Card>

      {/* Dependencies Table */}
      <Card className="border-border">
        <CardHeader className="pb-2 pt-3 px-4">
          <CardTitle className="text-xs">Dependency List ({filtered.length})</CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-auto">
            <table className="w-full text-xs">
              <thead>
                <tr className="border-b border-border bg-muted/30">
                  {["HW Program", "SW Program", "Direction", "Dependency", "Status", "Impact", ""].map(h => (
                    <th key={h} className="text-left px-3 py-2 font-semibold text-muted-foreground">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {filtered.map(d => (
                  <tr key={d.id}
                    onClick={() => setSelected(d)}
                    className={cn(
                      "border-b border-border/40 hover:bg-muted/20 cursor-pointer transition-colors",
                      d.notification && "bg-red-50/50 dark:bg-red-950/10"
                    )}>
                    <td className="px-3 py-2 font-medium">
                      <span className="flex items-center gap-1.5">
                        <span className={cn("w-2 h-2 rounded-full inline-block", programStatusColors[allPrograms.find(p => p.name === d.hwProgram)?.status || "On Track"])} />
                        {d.hwProgram}
                      </span>
                    </td>
                    <td className="px-3 py-2 font-medium">
                      <span className="flex items-center gap-1.5">
                        <span className={cn("w-2 h-2 rounded-full inline-block", programStatusColors[allPrograms.find(p => p.name === d.swProgram)?.status || "On Track"])} />
                        {d.swProgram}
                      </span>
                    </td>
                    <td className="px-3 py-2">
                      <Badge variant="outline" className={cn("text-[9px]", directionColors[d.direction])}>{d.direction}</Badge>
                    </td>
                    <td className="px-3 py-2 text-muted-foreground max-w-[220px] truncate">{d.dependency}</td>
                    <td className="px-3 py-2">
                      <Badge variant="outline" className={cn("text-[9px]", statusColors[d.status])}>{d.status}</Badge>
                    </td>
                    <td className="px-3 py-2 text-muted-foreground max-w-[200px] truncate">{d.impact}</td>
                    <td className="px-3 py-2">
                      {d.notification && <Bell className="w-3.5 h-3.5 text-destructive" />}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* Detail Dialog */}
      <Dialog open={!!selected} onOpenChange={() => setSelected(null)}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle className="text-sm flex items-center gap-2">
              <Link2 className="w-4 h-4 text-primary" />
              {selected?.hwProgram} ↔ {selected?.swProgram}
            </DialogTitle>
          </DialogHeader>
          {selected && (
            <div className="space-y-4 text-xs">
              <div className="flex gap-2 flex-wrap">
                <Badge variant="outline" className={cn(statusColors[selected.status])}>{selected.status}</Badge>
                <Badge variant="outline" className={cn(directionColors[selected.direction])}>{selected.direction}</Badge>
              </div>
              <div>
                <p className="font-semibold text-muted-foreground uppercase text-[10px] mb-1">Dependency</p>
                <p className="text-foreground">{selected.dependency}</p>
              </div>
              <div>
                <p className="font-semibold text-muted-foreground uppercase text-[10px] mb-1">Impact</p>
                <p className="text-foreground">{selected.impact}</p>
              </div>
              {selected.notification && (
                <div className="p-3 rounded-md bg-destructive/10 border border-destructive/20">
                  <p className="font-semibold text-destructive uppercase text-[10px] mb-1 flex items-center gap-1">
                    <AlertTriangle className="w-3 h-3" /> Notification
                  </p>
                  <p className="text-foreground">{selected.notification}</p>
                </div>
              )}
              <div className="flex gap-6">
                <div>
                  <p className="text-[10px] text-muted-foreground">HW Program</p>
                  <p className="font-medium flex items-center gap-1.5">
                    <span className={cn("w-2 h-2 rounded-full inline-block", programStatusColors[allPrograms.find(p => p.name === selected.hwProgram)?.status || "On Track"])} />
                    {selected.hwProgram}
                  </p>
                </div>
                <div>
                  <p className="text-[10px] text-muted-foreground">SW Program</p>
                  <p className="font-medium flex items-center gap-1.5">
                    <span className={cn("w-2 h-2 rounded-full inline-block", programStatusColors[allPrograms.find(p => p.name === selected.swProgram)?.status || "On Track"])} />
                    {selected.swProgram}
                  </p>
                </div>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default Dependencies;
