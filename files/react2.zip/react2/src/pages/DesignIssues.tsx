import { useState, useEffect, useRef, useCallback, useMemo } from "react";
import ComingSoonBanner from "@/components/dashboard/ComingSoonBanner";
import { useLocation } from "react-router-dom";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Download, ExternalLink } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import * as XLSX from "xlsx";
import UniversalFilterBar from "@/components/dashboard/UniversalFilterBar";
import { useUniversalFilters } from "@/contexts/UniversalFilterContext";
import { useRole } from "@/contexts/RoleContext";

const issuesData = [
  { id: "JQIM-16130", summary: "Cracked components can cause short circuit", labels: "None", severity: "SEV 1", dfmaaStatus: "Verify", impactedSite: "DnCP Supplier Factory", affectedPlatforms: "AW2526HL, AW2726DL, SE2726D", affectedLOBs: "DnCP", affectedSubLOBs: "Display", formFactor: "DnCP Accessory", enterPhase: "Mockup/EVT", impactedItems: "Accessory", issueDetails: "Cracked components can cause short circuit which leads to no power issues", issueStatus: "Analyze" },
  { id: "JQIM-16045", summary: "Thermal pad displacement during assembly", labels: "Thermal", severity: "SEV 2", dfmaaStatus: "Analyze", impactedSite: "CSG ODM Factory", affectedPlatforms: "Laptop 3", affectedLOBs: "CSG", affectedSubLOBs: "Notebook", formFactor: "Clamshell", enterPhase: "DVT", impactedItems: "Thermal Module", issueDetails: "Thermal pad shifts during assembly causing hotspot on CPU", issueStatus: "In Progress" },
  { id: "JQIM-15998", summary: "LCD bezel clip retention failure", labels: "Mechanical", severity: "SEV 2", dfmaaStatus: "Verify", impactedSite: "ISG ODM Factory", affectedPlatforms: "Laptop 2", affectedLOBs: "ISG", affectedSubLOBs: "Workstation", formFactor: "Clamshell", enterPhase: "PVT", impactedItems: "LCD Assembly", issueDetails: "Bezel clips lose retention after 3K open/close cycles", issueStatus: "Closed" },
  { id: "JQIM-15872", summary: "Palm rest paint peeling at edges", labels: "Cosmetic", severity: "SEV 3", dfmaaStatus: "Analyze", impactedSite: "DnCP Supplier Factory", affectedPlatforms: "OptiPlex 7420", affectedLOBs: "DnCP", affectedSubLOBs: "Desktop", formFactor: "AIO", enterPhase: "Mockup/EVT", impactedItems: "Chassis", issueDetails: "Paint peeling observed at palm rest edges after humidity testing", issueStatus: "In Progress" },
  { id: "JQIM-15740", summary: "Trackpad haptic feedback inconsistency", labels: "None", severity: "SEV 2", dfmaaStatus: "Open", impactedSite: "CSG ODM Factory", affectedPlatforms: "Latitude 5550", affectedLOBs: "CSG", affectedSubLOBs: "Notebook", formFactor: "Clamshell", enterPhase: "DVT", impactedItems: "Input Device", issueDetails: "Click force variance of ±15% across trackpad surface area", issueStatus: "Analyze" },
  { id: "JQIM-15685", summary: "Keyboard backlight bleed at edges", labels: "Cosmetic", severity: "SEV 3", dfmaaStatus: "Analyze", impactedSite: "CSG ODM Factory", affectedPlatforms: "Laptop 4", affectedLOBs: "CSG", affectedSubLOBs: "Notebook", formFactor: "Clamshell", enterPhase: "DVT", impactedItems: "Keyboard", issueDetails: "Light bleed visible at keyboard bezel edges in dark environments", issueStatus: "In Progress" },
  { id: "JQIM-15610", summary: "Webcam IR sensor misalignment", labels: "Mechanical", severity: "SEV 2", dfmaaStatus: "Verify", impactedSite: "ISG ODM Factory", affectedPlatforms: "Precision 7680", affectedLOBs: "ISG", affectedSubLOBs: "Workstation", formFactor: "Clamshell", enterPhase: "PVT", impactedItems: "Camera Module", issueDetails: "IR sensor offset causes Windows Hello recognition failures at angles >30°", issueStatus: "Analyze" },
  { id: "JQIM-15542", summary: "NVMe SSD thermal shutdown under load", labels: "Thermal", severity: "SEV 1", dfmaaStatus: "Open", impactedSite: "CSG ODM Factory", affectedPlatforms: "Laptop 3", affectedLOBs: "CSG", affectedSubLOBs: "Notebook", formFactor: "Clamshell", enterPhase: "DVT", impactedItems: "Storage", issueDetails: "NVMe SSD hits 105°C and throttles during sustained sequential writes", issueStatus: "In Progress" },
  { id: "JQIM-15480", summary: "Fingerprint reader false rejection rate", labels: "None", severity: "SEV 2", dfmaaStatus: "Analyze", impactedSite: "DnCP Supplier Factory", affectedPlatforms: "OptiPlex 7420", affectedLOBs: "DnCP", affectedSubLOBs: "Desktop", formFactor: "AIO", enterPhase: "Mockup/EVT", impactedItems: "Biometric Sensor", issueDetails: "False rejection rate of 8% exceeds 3% acceptance criteria", issueStatus: "Analyze" },
  { id: "JQIM-15395", summary: "Display hinge cable pinch risk", labels: "Mechanical", severity: "SEV 1", dfmaaStatus: "Verify", impactedSite: "CSG ODM Factory", affectedPlatforms: "Latitude 5550", affectedLOBs: "CSG", affectedSubLOBs: "Notebook", formFactor: "Clamshell", enterPhase: "DVT", impactedItems: "Display Cable", issueDetails: "LVDS cable routing creates pinch point at hinge barrel during lid close", issueStatus: "In Progress" },
  { id: "JQIM-15310", summary: "Rubber foot adhesion failure", labels: "Cosmetic", severity: "SEV 3", dfmaaStatus: "Open", impactedSite: "DnCP Supplier Factory", affectedPlatforms: "OptiPlex 7420", affectedLOBs: "DnCP", affectedSubLOBs: "Desktop", formFactor: "AIO", enterPhase: "PVT", impactedItems: "Chassis", issueDetails: "Rubber feet detach after 6 months in high-humidity environments", issueStatus: "Closed" },
];

const issuesScoringData = [
  { id: "JQIM-16130", riskImpact: 3, riskProbability: 3, riskPriority: 9, overallRiskLevel: "H", overallStatus: "OPEN" },
  { id: "JQIM-16045", riskImpact: 2, riskProbability: 2, riskPriority: 4, overallRiskLevel: "M", overallStatus: "NONE" },
  { id: "JQIM-15998", riskImpact: 1, riskProbability: 1, riskPriority: 1, overallRiskLevel: "L", overallStatus: "NONE" },
  { id: "JQIM-15872", riskImpact: 1, riskProbability: 2, riskPriority: 2, overallRiskLevel: "L", overallStatus: "NONE" },
  { id: "JQIM-15740", riskImpact: 2, riskProbability: 2, riskPriority: 4, overallRiskLevel: "M", overallStatus: "NONE" },
  { id: "JQIM-15685", riskImpact: 1, riskProbability: 1, riskPriority: 1, overallRiskLevel: "L", overallStatus: "NONE" },
  { id: "JQIM-15610", riskImpact: 3, riskProbability: 2, riskPriority: 6, overallRiskLevel: "M", overallStatus: "OPEN" },
  { id: "JQIM-15542", riskImpact: 3, riskProbability: 3, riskPriority: 9, overallRiskLevel: "H", overallStatus: "OPEN" },
  { id: "JQIM-15480", riskImpact: 2, riskProbability: 2, riskPriority: 4, overallRiskLevel: "M", overallStatus: "NONE" },
  { id: "JQIM-15395", riskImpact: 3, riskProbability: 3, riskPriority: 9, overallRiskLevel: "H", overallStatus: "OPEN" },
  { id: "JQIM-15310", riskImpact: 1, riskProbability: 1, riskPriority: 1, overallRiskLevel: "L", overallStatus: "NONE" },
];

const issuesPoints = issuesScoringData.map((d) => ({
  x: d.riskImpact,
  y: d.riskProbability,
  id: d.id,
  color: d.overallRiskLevel === "H" ? "hsl(var(--destructive))" : d.overallRiskLevel === "M" ? "hsl(var(--chart-mid))" : "hsl(var(--chart-low))",
}));

const PHASES_ORDER = ["Concept", "Define", "Plan", "Develop", "Pilot"];
const phaseMap = (phase: string): string => {
  const p = phase.toLowerCase();
  if (p.includes("develop") || p.includes("qual")) return "Develop";
  if (p.includes("pilot") || p.includes("ramp") || p.includes("launch") || p.includes("pvt")) return "Pilot";
  if (p.includes("plan")) return "Plan";
  if (p.includes("define")) return "Define";
  if (p.includes("concept") || p.includes("evt") || p.includes("mockup")) return "Concept";
  return phase;
};

interface PhaseRiskData { phase: string; low: number; medium: number; high: number; totalScore: number; }
const computePhaseRiskData = (items: { enterPhase: string }[], scoring: { riskPriority: number; overallRiskLevel: string }[]): PhaseRiskData[] => {
  const map: Record<string, { low: number; medium: number; high: number; totalScore: number }> = {};
  PHASES_ORDER.forEach((p) => { map[p] = { low: 0, medium: 0, high: 0, totalScore: 0 }; });
  items.forEach((item, i) => {
    const phase = phaseMap(item.enterPhase || "");
    if (!map[phase]) return;
    const score = scoring[i];
    if (!score) return;
    if (score.overallRiskLevel === "H") map[phase].high++;
    else if (score.overallRiskLevel === "M") map[phase].medium++;
    else map[phase].low++;
    map[phase].totalScore += score.riskPriority;
  });
  return PHASES_ORDER.map((p) => ({ phase: p, ...map[p] }));
};

function filterItems<T extends { affectedLOBs: string; affectedPlatforms: string }>(items: T[], lobFilter: string, platFilter: string): T[] {
  let result = items;
  if (lobFilter !== "all") result = result.filter((i) => i.affectedLOBs.includes(lobFilter));
  if (platFilter !== "all") result = result.filter((i) => i.affectedPlatforms.includes(platFilter));
  return result;
}

const RiskByPhaseChart = ({ data, title }: { data: PhaseRiskData[]; title: string }) => {
  const W = 520, H = 230, PAD_L = 34, PAD_R = 50, PAD_T = 36, PAD_B = 36;
  const plotW = W - PAD_L - PAD_R, plotH = H - PAD_T - PAD_B;
  const maxCount = Math.max(...data.map((d) => d.low + d.medium + d.high), 1);
  const yMaxCount = Math.ceil(maxCount * 1.3);
  const barW = plotW / data.length, barInner = barW * 0.42;
  return (
    <div className="rounded-2xl bg-card p-5 shadow-sm border border-border/50">
      <h4 className="text-sm font-semibold tracking-tight text-foreground/90 mb-4">{title}</h4>
      <svg viewBox={`0 0 ${W} ${H}`} className="w-full h-auto">
        {data.map((d, i) => {
          const x = PAD_L + barW * i + (barW - barInner) / 2;
          const hH = (d.high / yMaxCount) * plotH, hM = (d.medium / yMaxCount) * plotH, hL = (d.low / yMaxCount) * plotH;
          const yBase = PAD_T + plotH;
          return (
            <g key={i}>
              {d.high > 0 && <rect x={x} y={yBase - hH - hM - hL} width={barInner} height={hH} fill="hsl(var(--chart-high))" rx={4} />}
              {d.medium > 0 && <rect x={x} y={yBase - hM - hL} width={barInner} height={hM} fill="hsl(var(--chart-mid))" rx={4} />}
              {d.low > 0 && <rect x={x} y={yBase - hL} width={barInner} height={hL} fill="hsl(var(--chart-low))" rx={4} />}
              <text x={PAD_L + barW * i + barW / 2} y={H - 10} textAnchor="middle" className="text-[11px] font-medium" fill="hsl(var(--foreground))">{d.phase}</text>
            </g>
          );
        })}
      </svg>
    </div>
  );
};

const ScatterChart = ({ points, title, onPointClick, maxScale = 10 }: { points: { x: number; y: number; color: string; id: string }[]; title: string; onPointClick?: (id: string) => void; maxScale?: number }) => {
  const W = 260, H = 230, PAD = 32, plotW = W - PAD * 2, plotH = H - PAD * 2;
  return (
    <div className="rounded-2xl bg-card p-5 shadow-sm border border-border/50 h-full flex flex-col">
      <h4 className="text-sm font-semibold tracking-tight text-foreground/90 mb-4">{title}</h4>
      <svg viewBox={`0 0 ${W} ${H}`} className="w-full flex-1">
        <rect x={PAD + plotW * 0.5} y={PAD} width={plotW * 0.5} height={plotH * 0.5} fill="hsl(var(--destructive) / 0.04)" rx={6} />
        {points.map((p, i) => (
          <circle key={i} cx={PAD + (p.x / maxScale) * plotW} cy={PAD + plotH - (p.y / maxScale) * plotH} r={5.5} fill={p.color} opacity={0.85} className="cursor-pointer hover:opacity-100" stroke="hsl(var(--card))" strokeWidth="2" onClick={() => onPointClick?.(p.id)}>
            <title>{p.id}</title>
          </circle>
        ))}
        <text x={PAD + plotW / 2} y={H - 4} textAnchor="middle" className="text-[10px] font-medium" fill="hsl(var(--muted-foreground))">Risk Impact →</text>
      </svg>
    </div>
  );
};

const SummaryKpis = ({ data, scoring }: { data: { id: string }[]; scoring: { overallRiskLevel: string; riskPriority: number }[] }) => {
  const total = data.length;
  const high = scoring.filter((s) => s.overallRiskLevel === "H").length;
  const medium = scoring.filter((s) => s.overallRiskLevel === "M").length;
  const low = scoring.filter((s) => s.overallRiskLevel === "L").length;
  const avgScore = scoring.length > 0 ? (scoring.reduce((a, s) => a + s.riskPriority, 0) / scoring.length).toFixed(1) : "0";
  const kpis = [
    { label: "Total Items", value: total, accent: "text-foreground" },
    { label: "High Risk", value: high, accent: "text-destructive" },
    { label: "Medium Risk", value: medium, accent: "text-chart-mid" },
    { label: "Low Risk", value: low, accent: "text-chart-low" },
    { label: "Avg Score", value: avgScore, accent: "text-foreground" },
  ];
  return (
    <div className="flex gap-3">
      {kpis.map((k) => (
        <div key={k.label} className="rounded-xl bg-card border border-border/50 px-5 py-3.5 shadow-sm flex-1 min-w-0">
          <p className="text-xs font-medium text-muted-foreground tracking-wide uppercase">{k.label}</p>
          <p className={`text-2xl font-bold mt-0.5 tabular-nums ${k.accent}`}>{k.value}</p>
        </div>
      ))}
    </div>
  );
};

const tableHeadClass = "text-xs h-10 px-4 font-semibold text-muted-foreground uppercase tracking-wide";
const tableCellClass = "text-[13px] py-3.5 px-4";

const DesignIssuesContent = () => {
  const location = useLocation();
  const state = location.state as { selectedProgram?: string } | null;
  const programName = state?.selectedProgram || "AllPrograms";
  const [highlightId, setHighlightId] = useState<string | null>(null);
  const [selectedRow, setSelectedRow] = useState<typeof issuesData[0] & typeof issuesScoringData[0] | null>(null);
  const rowRefs = useRef<Record<string, HTMLTableRowElement | null>>({});
  const { role } = useRole();
  const showRiskVisuals = role === "Executive";
  const { filters: uFilters } = useUniversalFilters();

  const phaseMatches = useCallback((itemPhase: string, filter: string) => {
    if (filter === "all") return true;
    return phaseMap(itemPhase) === phaseMap(filter);
  }, []);

  const filteredIssues = useMemo(() => {
    let result = filterItems(issuesData, uFilters.lob, uFilters.platform);
    if (uFilters.phase !== "all") result = result.filter((d) => phaseMatches(d.enterPhase, uFilters.phase));
    return result;
  }, [uFilters.lob, uFilters.platform, uFilters.phase, phaseMatches]);

  const filteredScoring = useMemo(() => {
    const ids = new Set(filteredIssues.map((d) => d.id));
    return issuesScoringData.filter((s) => ids.has(s.id));
  }, [filteredIssues]);

  const filteredPoints = useMemo(() => {
    const ids = new Set(filteredIssues.map((d) => d.id));
    return issuesPoints.filter((p) => ids.has(p.id));
  }, [filteredIssues]);

  const phaseData = useMemo(() => {
    const scoring = filteredIssues.map((d) => issuesScoringData.find((s) => s.id === d.id)!).filter(Boolean);
    return computePhaseRiskData(filteredIssues, scoring);
  }, [filteredIssues]);

  useEffect(() => {
    if (highlightId && rowRefs.current[highlightId]) {
      rowRefs.current[highlightId]?.scrollIntoView({ behavior: "smooth", block: "center" });
    }
  }, [highlightId]);

  const merged = useMemo(() => filteredIssues.map((info) => ({ ...info, ...issuesScoringData.find((s) => s.id === info.id)! })), [filteredIssues]);

  const exportIssues = useCallback(() => {
    const safeName = programName.replace(/\s+/g, "_");
    const date = new Date().toISOString().slice(0, 10);
    const ws = XLSX.utils.json_to_sheet(merged);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Design Issues");
    XLSX.writeFile(wb, `${safeName}_DesignIssues_${date}.xlsx`);
  }, [merged, programName]);

  return (
    <div className="flex-1 flex flex-col overflow-auto">
      <div className="px-6 pt-6 pb-2 flex items-center justify-between">
        <div>
          <div className="flex items-center gap-3">
            <h1 className="text-[22px] font-extrabold tracking-tight text-foreground">Design Issues</h1>
            <Badge variant="outline" className="text-[10px] gap-1.5 border-warning/40 text-warning bg-warning/5">
              <ExternalLink className="w-2.5 h-2.5" />
              Synced with DFx Tool
            </Badge>
          </div>
          <p className="text-sm text-muted-foreground mt-0.5">DFMAA-tracked manufacturing & design issues from the DFx tool</p>
        </div>
        <UniversalFilterBar hideTask />
      </div>

      <div className="px-6 pb-4 space-y-4">
        <div className="flex items-center justify-end">
          <Button variant="outline" size="sm" className="h-8 text-xs gap-2" onClick={exportIssues}>
            <Download className="w-3.5 h-3.5" /> Export
          </Button>
        </div>

        <SummaryKpis data={filteredIssues} scoring={filteredScoring} />

        {showRiskVisuals && (
          <div className="grid grid-cols-12 gap-4">
            <div className="col-span-4">
              <ScatterChart points={filteredPoints} title="Risk Matrix" onPointClick={(id) => setHighlightId(id)} maxScale={3} />
            </div>
            <div className="col-span-8">
              <RiskByPhaseChart data={phaseData} title="Risk Distribution by Phase" />
            </div>
          </div>
        )}

        <div className="rounded-2xl bg-card border border-border/50 shadow-sm overflow-hidden">
          <Table>
            <TableHeader>
              <TableRow className="bg-muted/20">
                <TableHead className={tableHeadClass}>DFx ID</TableHead>
                <TableHead className={tableHeadClass}>Severity</TableHead>
                <TableHead className={tableHeadClass}>DFMAA</TableHead>
                <TableHead className={tableHeadClass}>Platform(s)</TableHead>
                <TableHead className={`${tableHeadClass} text-center`}>Risk</TableHead>
                <TableHead className={tableHeadClass}>Site</TableHead>
                <TableHead className={tableHeadClass}>Phase</TableHead>
                <TableHead className={tableHeadClass}>Status</TableHead>
                <TableHead className={tableHeadClass}>Link</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {merged.map((row, idx) => (
                <TableRow
                  key={row.id}
                  ref={(el) => { rowRefs.current[row.id] = el; }}
                  className={`cursor-pointer ${idx % 2 === 0 ? "bg-card" : "bg-muted/10"} hover:bg-accent/60 ${highlightId === row.id ? "bg-primary/8 ring-1 ring-primary/20" : ""}`}
                  onClick={() => setSelectedRow(row)}
                >
                  <TableCell className={`${tableCellClass} font-medium text-primary whitespace-nowrap`}>{row.id}</TableCell>
                  <TableCell className={tableCellClass}>
                    <Badge variant={row.severity === "SEV 1" ? "destructive" : "outline"} className="text-xs">{row.severity}</Badge>
                  </TableCell>
                  <TableCell className={tableCellClass}>{row.dfmaaStatus}</TableCell>
                  <TableCell className={`${tableCellClass} max-w-[150px] truncate`}>{row.affectedPlatforms}</TableCell>
                  <TableCell className={`${tableCellClass} text-center`}>
                    <Badge variant={row.overallRiskLevel === "H" ? "destructive" : row.overallRiskLevel === "M" ? "outline" : "secondary"} className="text-xs">{row.overallRiskLevel}</Badge>
                  </TableCell>
                  <TableCell className={`${tableCellClass} max-w-[150px] truncate text-muted-foreground`}>{row.impactedSite}</TableCell>
                  <TableCell className={tableCellClass}>{row.enterPhase}</TableCell>
                  <TableCell className={tableCellClass}>
                    <Badge variant={row.issueStatus === "Closed" ? "secondary" : "outline"} className="text-xs">{row.issueStatus}</Badge>
                  </TableCell>
                  <TableCell className={tableCellClass}>
                    <a
                      href={`https://dfx.example.com/issue/${row.id}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      onClick={(e) => e.stopPropagation()}
                      className="inline-flex items-center gap-1 text-[11px] text-warning hover:underline"
                    >
                      View in DFx <ExternalLink className="w-3 h-3" />
                    </a>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </div>

      <Dialog open={!!selectedRow} onOpenChange={(v) => { if (!v) setSelectedRow(null); }}>
        <DialogContent className="max-w-2xl max-h-[80vh] overflow-auto">
          <DialogHeader>
            <DialogTitle className="text-base">{selectedRow ? `${selectedRow.id} — ${selectedRow.summary}` : ""}</DialogTitle>
          </DialogHeader>
          {selectedRow && (
            <div className="grid grid-cols-2 gap-x-6 gap-y-3 mt-2 text-[13px]">
              <div><p className="text-[10px] font-bold text-muted-foreground uppercase">Severity</p><p>{selectedRow.severity}</p></div>
              <div><p className="text-[10px] font-bold text-muted-foreground uppercase">Issue Status</p><p>{selectedRow.issueStatus}</p></div>
              <div><p className="text-[10px] font-bold text-muted-foreground uppercase">Form Factor</p><p>{selectedRow.formFactor}</p></div>
              <div><p className="text-[10px] font-bold text-muted-foreground uppercase">Sub-LOB</p><p>{selectedRow.affectedSubLOBs}</p></div>
              <div className="col-span-2"><p className="text-[10px] font-bold text-muted-foreground uppercase">Issue Details</p><p>{selectedRow.issueDetails}</p></div>
              <div className="col-span-2">
                <a href={`https://dfx.example.com/issue/${selectedRow.id}`} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1 text-warning hover:underline">
                  Open in DFx Tool <ExternalLink className="w-3 h-3" />
                </a>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
};

const DesignIssuesPage = () => (
  <ComingSoonBanner message="To be completed in version 2.0">
    <DesignIssuesContent />
  </ComingSoonBanner>
);

export default DesignIssuesPage;
