import { useMemo, useState } from "react";
import ComingSoonBanner from "@/components/dashboard/ComingSoonBanner";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { FileText, Files, Activity, Search, Sparkles, Bot } from "lucide-react";

const programs = [
  { name: "Laptop 1", lob: "CSG", group: "Notebook", status: "On Track", docs: 142, usage: 87 },
  { name: "Laptop 2", lob: "ISG", group: "Workstation", status: "At Risk w/ Mitigation", docs: 98, usage: 64 },
  { name: "Laptop 3", lob: "CSG", group: "Notebook", status: "At Risk w/ No Plan", docs: 76, usage: 42 },
  { name: "Laptop 4", lob: "CSG", group: "Notebook", status: "On Track", docs: 134, usage: 81 },
  { name: "Laptop 5", lob: "ISG", group: "Workstation", status: "On Track", docs: 121, usage: 73 },
  { name: "Laptop 6", lob: "CSG", group: "Notebook", status: "At Risk w/ Mitigation", docs: 88, usage: 55 },
  { name: "Laptop 7", lob: "DnCP", group: "Desktop", status: "Not Started", docs: 24, usage: 12 },
];

const statusBadge = (s: string) => {
  if (s === "On Track") return "bg-success/15 text-success border-success/30";
  if (s === "At Risk w/ Mitigation") return "bg-warning/15 text-warning border-warning/30";
  if (s === "At Risk w/ No Plan") return "bg-destructive/15 text-destructive border-destructive/30";
  return "bg-muted text-muted-foreground border-border";
};

const DocCuratorContent = () => {
  const [search, setSearch] = useState("");
  const [lob, setLob] = useState("all");
  const [group, setGroup] = useState("all");
  const [status, setStatus] = useState("all");

  const rows = useMemo(
    () =>
      programs.filter(
        (p) =>
          (lob === "all" || p.lob === lob) &&
          (group === "all" || p.group === group) &&
          (status === "all" || p.status === status) &&
          (!search || p.name.toLowerCase().includes(search.toLowerCase())),
      ),
    [lob, group, status, search],
  );

  const totalDocs = rows.reduce((a, p) => a + p.docs, 0);
  const avgUsage = rows.length ? Math.round(rows.reduce((a, p) => a + p.usage, 0) / rows.length) : 0;

  const kpis = [
    { label: "Total Programs", value: rows.length, icon: FileText, accent: "text-primary" },
    { label: "Ingested Documents", value: totalDocs.toLocaleString(), icon: Files, accent: "text-foreground" },
    { label: "Average Usage", value: `${avgUsage}%`, icon: Activity, accent: "text-success" },
  ];

  return (
    <div className="flex-1 flex flex-col overflow-auto">
      {/* Header */}
      <div className="px-6 pt-6 pb-2 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <FileText className="w-5 h-5 text-primary" />
          <h1 className="text-[22px] font-extrabold tracking-tight text-foreground">Doc & Data Curator</h1>
        </div>
      </div>

      <div className="px-6 pb-6 space-y-4">
        {/* KPIs */}
        <div className="grid grid-cols-3 gap-3">
          {kpis.map((k) => (
            <div key={k.label} className="rounded-2xl bg-card border border-border/50 px-5 py-4 shadow-sm flex items-center gap-4">
              <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center">
                <k.icon className={`w-5 h-5 ${k.accent}`} />
              </div>
              <div>
                <p className="text-[11px] font-semibold text-muted-foreground uppercase tracking-wide">{k.label}</p>
                <p className="text-2xl font-bold tabular-nums text-foreground mt-0.5">{k.value}</p>
              </div>
            </div>
          ))}
        </div>

        {/* Filters */}
        <div className="rounded-2xl bg-card border border-border/50 p-4 shadow-sm flex flex-wrap items-center gap-3">
          <div className="relative flex-1 min-w-[200px]">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
            <Input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search programs…"
              className="h-9 pl-9 text-xs"
            />
          </div>
          <Select value={lob} onValueChange={setLob}>
            <SelectTrigger className="h-9 w-[140px] text-xs"><SelectValue placeholder="LOB" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All LOBs</SelectItem>
              <SelectItem value="CSG">CSG</SelectItem>
              <SelectItem value="ISG">ISG</SelectItem>
              <SelectItem value="DnCP">DnCP</SelectItem>
            </SelectContent>
          </Select>
          <Select value={group} onValueChange={setGroup}>
            <SelectTrigger className="h-9 w-[160px] text-xs"><SelectValue placeholder="Program Group" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Groups</SelectItem>
              <SelectItem value="Notebook">Notebook</SelectItem>
              <SelectItem value="Workstation">Workstation</SelectItem>
              <SelectItem value="Desktop">Desktop</SelectItem>
            </SelectContent>
          </Select>
          <Select value={status} onValueChange={setStatus}>
            <SelectTrigger className="h-9 w-[180px] text-xs"><SelectValue placeholder="Status" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Statuses</SelectItem>
              <SelectItem value="On Track">On Track</SelectItem>
              <SelectItem value="At Risk w/ Mitigation">At Risk w/ Mitigation</SelectItem>
              <SelectItem value="At Risk w/ No Plan">At Risk w/ No Plan</SelectItem>
              <SelectItem value="Not Started">Not Started</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Table */}
        <div className="rounded-2xl bg-card border border-border/50 shadow-sm overflow-hidden">
          <Table>
            <TableHeader>
              <TableRow className="bg-muted/20">
                <TableHead className="text-xs h-10 px-4 font-semibold text-muted-foreground uppercase tracking-wide">Program</TableHead>
                <TableHead className="text-xs h-10 px-4 font-semibold text-muted-foreground uppercase tracking-wide">LOB</TableHead>
                <TableHead className="text-xs h-10 px-4 font-semibold text-muted-foreground uppercase tracking-wide">Group</TableHead>
                <TableHead className="text-xs h-10 px-4 font-semibold text-muted-foreground uppercase tracking-wide">Status</TableHead>
                <TableHead className="text-xs h-10 px-4 font-semibold text-muted-foreground uppercase tracking-wide text-right">Documents</TableHead>
                <TableHead className="text-xs h-10 px-4 font-semibold text-muted-foreground uppercase tracking-wide w-[200px]">Usage</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {rows.map((p, i) => (
                <TableRow key={p.name} className={i % 2 === 0 ? "bg-card" : "bg-muted/10"}>
                  <TableCell className="text-[13px] py-3.5 px-4 font-semibold text-foreground">{p.name}</TableCell>
                  <TableCell className="text-[13px] py-3.5 px-4 text-muted-foreground">{p.lob}</TableCell>
                  <TableCell className="text-[13px] py-3.5 px-4 text-muted-foreground">{p.group}</TableCell>
                  <TableCell className="text-[13px] py-3.5 px-4">
                    <Badge variant="outline" className={`text-[10px] ${statusBadge(p.status)}`}>{p.status}</Badge>
                  </TableCell>
                  <TableCell className="text-[13px] py-3.5 px-4 text-right tabular-nums font-semibold text-foreground">{p.docs}</TableCell>
                  <TableCell className="py-3.5 px-4">
                    <div className="flex items-center gap-2">
                      <div className="flex-1 h-1.5 bg-muted rounded-full overflow-hidden">
                        <div
                          className={`h-full rounded-full ${p.usage >= 70 ? "bg-success" : p.usage >= 40 ? "bg-warning" : "bg-destructive"}`}
                          style={{ width: `${p.usage}%` }}
                        />
                      </div>
                      <span className="text-[11px] tabular-nums text-muted-foreground font-medium w-8 text-right">{p.usage}%</span>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </div>

      {/* GOE Assistant floating widget */}
      <div className="fixed bottom-6 right-6 z-20">
        <Button className="h-12 px-5 rounded-full shadow-lg gap-2">
          <Bot className="w-4 h-4" />
          <span className="text-xs font-semibold">GOE Assistant</span>
          <Sparkles className="w-3.5 h-3.5 opacity-80" />
        </Button>
      </div>
    </div>
  );
};

const DocCurator = () => (
  <ComingSoonBanner message="Doc & Data Curator UI goes here">
    <DocCuratorContent />
  </ComingSoonBanner>
);

export default DocCurator;
