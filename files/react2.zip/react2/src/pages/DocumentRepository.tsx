import { useState, useMemo } from "react";
import { Search, FileText, Upload, Download, Filter } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import UniversalFilterBar from "@/components/dashboard/UniversalFilterBar";
import { useUniversalFilters } from "@/contexts/UniversalFilterContext";
import * as XLSX from "xlsx";

interface Document {
  id: string;
  name: string;
  type: string;
  lob: string;
  platform: string;
  phase: string;
  task: string;
  uploadedBy: string;
  uploadedDate: string;
  size: string;
  status: "Approved" | "Pending Review" | "Draft";
}

const documents: Document[] = [
  { id: "DOC-001", name: "Phase Gate Report — Laptop 1", type: "PDF", lob: "CSG", platform: "Laptop 1", phase: "Plan", task: "Phase Gate Review", uploadedBy: "GOE PM", uploadedDate: "2026-03-12", size: "2.4 MB", status: "Approved" },
  { id: "DOC-002", name: "BOM Baseline v3", type: "XLSX", lob: "CSG", platform: "Laptop 1", phase: "Define", task: "BOM Lock", uploadedBy: "GOE PM", uploadedDate: "2026-02-28", size: "1.8 MB", status: "Approved" },
  { id: "DOC-003", name: "Thermal Validation Report", type: "PDF", lob: "CSG", platform: "Laptop 2", phase: "Qual", task: "Thermal Testing", uploadedBy: "GOE PM", uploadedDate: "2026-04-01", size: "5.1 MB", status: "Pending Review" },
  { id: "DOC-004", name: "Golden Config Spec", type: "PDF", lob: "ISG", platform: "Laptop 2", phase: "Plan", task: "Config Lock", uploadedBy: "GOE PM", uploadedDate: "2026-03-20", size: "890 KB", status: "Approved" },
  { id: "DOC-005", name: "NUDD Tracker", type: "XLSX", lob: "CSG", platform: "Laptop 1", phase: "Define", task: "Risk Assessment", uploadedBy: "GOE PM", uploadedDate: "2026-01-15", size: "1.2 MB", status: "Approved" },
  { id: "DOC-006", name: "Build Execution Log", type: "PDF", lob: "ISG", platform: "Laptop 3", phase: "Pilot", task: "Pilot Build", uploadedBy: "GOE PM", uploadedDate: "2026-04-10", size: "3.7 MB", status: "Draft" },
  { id: "DOC-007", name: "Supply Chain Risk Assessment", type: "PDF", lob: "CSG", platform: "Laptop 3", phase: "Plan", task: "Supplier Qualification", uploadedBy: "GOE PM", uploadedDate: "2026-03-05", size: "2.9 MB", status: "Approved" },
  { id: "DOC-008", name: "Factory Readiness Audit", type: "PDF", lob: "DnCP", platform: "Laptop 4", phase: "Qual", task: "Factory Audit", uploadedBy: "GOE PM", uploadedDate: "2026-03-22", size: "4.3 MB", status: "Pending Review" },
  { id: "DOC-009", name: "DFx Checklist", type: "XLSX", lob: "ISG", platform: "Laptop 2", phase: "Define", task: "DFx Review", uploadedBy: "GOE PM", uploadedDate: "2026-02-10", size: "650 KB", status: "Approved" },
  { id: "DOC-010", name: "Regulatory Certification Pack", type: "PDF", lob: "CSG", platform: "Laptop 4", phase: "Qual", task: "Certification", uploadedBy: "GOE PM", uploadedDate: "2026-04-05", size: "8.2 MB", status: "Pending Review" },
  { id: "DOC-011", name: "Cost Model Q3", type: "XLSX", lob: "CSG", platform: "Laptop 4", phase: "Plan", task: "Cost Analysis", uploadedBy: "GOE PM", uploadedDate: "2026-03-15", size: "1.1 MB", status: "Approved" },
  { id: "DOC-012", name: "Concept Brief", type: "PDF", lob: "CSG", platform: "Laptop 5", phase: "Concept", task: "Concept Review", uploadedBy: "GOE PM", uploadedDate: "2026-01-05", size: "1.5 MB", status: "Approved" },
  { id: "DOC-013", name: "Market Requirements Doc", type: "PDF", lob: "CSG", platform: "Laptop 5", phase: "Concept", task: "Market Analysis", uploadedBy: "GOE PM", uploadedDate: "2026-01-10", size: "2.0 MB", status: "Draft" },
  { id: "DOC-014", name: "ODM Compliance Report", type: "PDF", lob: "DnCP", platform: "Laptop 6", phase: "Qual", task: "Compliance Review", uploadedBy: "GOE PM", uploadedDate: "2026-03-28", size: "3.4 MB", status: "Approved" },
  { id: "DOC-015", name: "Preliminary BOM", type: "XLSX", lob: "CSG", platform: "Laptop 7", phase: "Concept", task: "BOM Draft", uploadedBy: "GOE PM", uploadedDate: "2026-01-20", size: "780 KB", status: "Draft" },
  { id: "DOC-016", name: "Schedule Baseline", type: "PDF", lob: "CSG", platform: "Laptop 7", phase: "Define", task: "Schedule Lock", uploadedBy: "GOE PM", uploadedDate: "2026-02-15", size: "1.3 MB", status: "Approved" },
  { id: "DOC-017", name: "Pilot Build Summary", type: "PDF", lob: "CSG", platform: "Laptop 3", phase: "Pilot", task: "Build Summary", uploadedBy: "GOE PM", uploadedDate: "2026-04-12", size: "2.6 MB", status: "Pending Review" },
  { id: "DOC-018", name: "RTS Schedule", type: "XLSX", lob: "CSG", platform: "Laptop 1", phase: "Plan", task: "RTS Planning", uploadedBy: "GOE PM", uploadedDate: "2026-03-01", size: "950 KB", status: "Approved" },
];

const statusColors: Record<Document["status"], string> = {
  "Approved": "bg-green-100 text-green-800 border-green-200",
  "Pending Review": "bg-yellow-100 text-yellow-800 border-yellow-200",
  "Draft": "bg-gray-100 text-gray-600 border-gray-200",
};

const DocumentRepository = () => {
  const { matchesPlatform, matchesPhase } = useUniversalFilters();
  const [search, setSearch] = useState("");
  const [lobFilter, setLobFilter] = useState("all");
  const [platformFilter, setPlatformFilter] = useState("all");
  const [phaseFilter, setPhaseFilter] = useState("all");
  const [taskFilter, setTaskFilter] = useState("all");

  const uniqueLobs = useMemo(() => [...new Set(documents.map(d => d.lob))].sort(), []);
  const uniquePlatforms = useMemo(() => [...new Set(documents.map(d => d.platform))].sort(), []);
  const uniquePhases = useMemo(() => [...new Set(documents.map(d => d.phase))], []);
  const uniqueTasks = useMemo(() => [...new Set(documents.map(d => d.task))].sort(), []);

  const universalFiltered = useMemo(() => documents.filter(doc => {
    if (!matchesPlatform(doc.platform)) return false;
    if (!matchesPhase(doc.phase)) return false;
    return true;
  }), [matchesPlatform, matchesPhase]);

  const filtered = useMemo(() => {
    return universalFiltered.filter(doc => {
      if (search && !doc.name.toLowerCase().includes(search.toLowerCase()) && !doc.id.toLowerCase().includes(search.toLowerCase())) return false;
      if (lobFilter !== "all" && doc.lob !== lobFilter) return false;
      if (platformFilter !== "all" && doc.platform !== platformFilter) return false;
      if (phaseFilter !== "all" && doc.phase !== phaseFilter) return false;
      if (taskFilter !== "all" && doc.task !== taskFilter) return false;
      return true;
    });
  }, [search, lobFilter, platformFilter, phaseFilter, taskFilter, universalFiltered]);

  const stats = useMemo(() => ({
    total: universalFiltered.length,
    approved: universalFiltered.filter(d => d.status === "Approved").length,
    pending: universalFiltered.filter(d => d.status === "Pending Review").length,
    draft: universalFiltered.filter(d => d.status === "Draft").length,
  }), [universalFiltered]);

  const handleExport = () => {
    const ws = XLSX.utils.json_to_sheet(filtered.map(d => ({
      ID: d.id, Name: d.name, Type: d.type, LOB: d.lob, Platform: d.platform,
      Phase: d.phase, Task: d.task, "Uploaded By": d.uploadedBy,
      "Upload Date": d.uploadedDate, Size: d.size, Status: d.status,
    })));
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Documents");
    XLSX.writeFile(wb, "document_repository.xlsx");
  };

  const clearFilters = () => {
    setSearch("");
    setLobFilter("all");
    setPlatformFilter("all");
    setPhaseFilter("all");
    setTaskFilter("all");
  };

  const hasFilters = search || lobFilter !== "all" || platformFilter !== "all" || phaseFilter !== "all" || taskFilter !== "all";

  return (
    <div className="flex-1 flex flex-col overflow-auto">
      <div className="px-6 pt-6 pb-2">
        <div className="flex items-center justify-between mb-5">
          <div>
            <h1 className="text-[22px] font-extrabold text-foreground tracking-tight">Document Repository</h1>
            <p className="text-xs text-muted-foreground mt-0.5">All ingested and uploaded documents across the portfolio</p>
          </div>
          <div className="flex items-center gap-2">
            <UniversalFilterBar />
            <Button variant="outline" size="sm" onClick={handleExport} className="gap-1.5 text-xs">
              <Download className="w-3.5 h-3.5" />
              Export
            </Button>
          </div>
        </div>

        {/* KPI Row */}
        <div className="grid grid-cols-4 gap-3 mb-5">
          {[
            { label: "Total Documents", value: stats.total, color: "text-primary" },
            { label: "Approved", value: stats.approved, color: "text-green-600" },
            { label: "Pending Review", value: stats.pending, color: "text-yellow-600" },
            { label: "Draft", value: stats.draft, color: "text-muted-foreground" },
          ].map(kpi => (
            <div key={kpi.label} className="bg-card border border-border rounded-lg p-4 flex items-center gap-3">
              <FileText className={cn("w-5 h-5", kpi.color)} />
              <div>
                <p className={cn("text-xl font-bold tabular-nums", kpi.color)}>{kpi.value}</p>
                <p className="text-[10px] text-muted-foreground font-medium">{kpi.label}</p>
              </div>
            </div>
          ))}
        </div>

        {/* Filters */}
        <div className="flex items-center gap-2 flex-wrap mb-2">
          <div className="relative flex-1 max-w-xs">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
            <Input
              placeholder="Search documents..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="pl-9 text-xs h-8"
            />
          </div>
          <Select value={lobFilter} onValueChange={setLobFilter}>
            <SelectTrigger className="w-[100px] text-xs h-8">
              <SelectValue placeholder="LOB" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All LOBs</SelectItem>
              {uniqueLobs.map(l => <SelectItem key={l} value={l}>{l}</SelectItem>)}
            </SelectContent>
          </Select>
          <Select value={platformFilter} onValueChange={setPlatformFilter}>
            <SelectTrigger className="w-[120px] text-xs h-8">
              <SelectValue placeholder="Platform" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Platforms</SelectItem>
              {uniquePlatforms.map(p => <SelectItem key={p} value={p}>{p}</SelectItem>)}
            </SelectContent>
          </Select>
          <Select value={phaseFilter} onValueChange={setPhaseFilter}>
            <SelectTrigger className="w-[150px] text-xs h-8">
              <SelectValue placeholder="Phase" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Phases</SelectItem>
              {uniquePhases.map(p => <SelectItem key={p} value={p}>{p}</SelectItem>)}
            </SelectContent>
          </Select>
          <Select value={taskFilter} onValueChange={setTaskFilter}>
            <SelectTrigger className="w-[150px] text-xs h-8">
              <SelectValue placeholder="Task" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Tasks</SelectItem>
              {uniqueTasks.map(t => <SelectItem key={t} value={t}>{t}</SelectItem>)}
            </SelectContent>
          </Select>
          {hasFilters && (
            <Button variant="ghost" size="sm" onClick={clearFilters} className="text-xs h-8 text-muted-foreground">
              Clear
            </Button>
          )}
        </div>
        <p className="text-[10px] text-muted-foreground text-right mb-1">Showing {filtered.length} of {documents.length}</p>
      </div>

      {/* Table */}
      <div className="px-6 pb-6 flex-1">
        <div className="border border-border rounded-lg bg-card overflow-auto">
          <Table>
            <TableHeader>
              <TableRow className="bg-muted/30 hover:bg-muted/30">
                <TableHead className="text-[10px] font-semibold uppercase tracking-wider text-muted-foreground px-3 py-2.5">ID</TableHead>
                <TableHead className="text-[10px] font-semibold uppercase tracking-wider text-muted-foreground px-3 py-2.5">Document Name</TableHead>
                <TableHead className="text-[10px] font-semibold uppercase tracking-wider text-muted-foreground px-3 py-2.5">Type</TableHead>
                <TableHead className="text-[10px] font-semibold uppercase tracking-wider text-muted-foreground px-3 py-2.5">LOB</TableHead>
                <TableHead className="text-[10px] font-semibold uppercase tracking-wider text-muted-foreground px-3 py-2.5">Platform</TableHead>
                <TableHead className="text-[10px] font-semibold uppercase tracking-wider text-muted-foreground px-3 py-2.5">Phase</TableHead>
                <TableHead className="text-[10px] font-semibold uppercase tracking-wider text-muted-foreground px-3 py-2.5">Task</TableHead>
                <TableHead className="text-[10px] font-semibold uppercase tracking-wider text-muted-foreground px-3 py-2.5">Uploaded By</TableHead>
                <TableHead className="text-[10px] font-semibold uppercase tracking-wider text-muted-foreground px-3 py-2.5">Date</TableHead>
                <TableHead className="text-[10px] font-semibold uppercase tracking-wider text-muted-foreground px-3 py-2.5">Size</TableHead>
                <TableHead className="text-[10px] font-semibold uppercase tracking-wider text-muted-foreground px-3 py-2.5">Status</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filtered.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={11} className="h-24 text-center text-sm text-muted-foreground">
                    No documents match the current filters.
                  </TableCell>
                </TableRow>
              ) : (
                filtered.map((doc, idx) => (
                  <TableRow key={doc.id} className={cn("transition-colors cursor-pointer", idx % 2 === 0 ? "bg-card" : "bg-muted/10", "hover:bg-accent/40")}>
                    <TableCell className="px-3 py-2.5 text-[11px] font-mono text-primary font-semibold">{doc.id}</TableCell>
                    <TableCell className="px-3 py-2.5 text-[11px] font-medium text-foreground max-w-[220px] truncate">{doc.name}</TableCell>
                    <TableCell className="px-3 py-2.5">
                      <Badge variant="outline" className="text-[9px] font-bold px-1.5 py-0">{doc.type}</Badge>
                    </TableCell>
                    <TableCell className="px-3 py-2.5">
                      <Badge variant="outline" className="text-[9px] font-bold bg-primary text-primary-foreground border-none px-1.5 py-0">{doc.lob}</Badge>
                    </TableCell>
                    <TableCell className="px-3 py-2.5 text-[11px] text-foreground">{doc.platform}</TableCell>
                    <TableCell className="px-3 py-2.5 text-[11px] text-muted-foreground">{doc.phase}</TableCell>
                    <TableCell className="px-3 py-2.5 text-[11px] text-muted-foreground">{doc.task}</TableCell>
                    <TableCell className="px-3 py-2.5 text-[11px] text-muted-foreground">{doc.uploadedBy}</TableCell>
                    <TableCell className="px-3 py-2.5 text-[11px] text-muted-foreground tabular-nums">{doc.uploadedDate}</TableCell>
                    <TableCell className="px-3 py-2.5 text-[11px] text-muted-foreground tabular-nums">{doc.size}</TableCell>
                    <TableCell className="px-3 py-2.5">
                      <Badge variant="outline" className={cn("text-[9px] border", statusColors[doc.status])}>{doc.status}</Badge>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>
      </div>
    </div>
  );
};

export default DocumentRepository;
