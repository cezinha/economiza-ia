import { useState, useMemo } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Factory, Filter, AlertTriangle } from "lucide-react";
import { cn } from "@/lib/utils";
import UniversalFilterBar from "@/components/dashboard/UniversalFilterBar";
import { useUniversalFilters } from "@/contexts/UniversalFilterContext";

interface Constraint {
  id: string;
  factory: string;
  type: "capacity" | "tooling" | "material";
  severity: "red" | "yellow" | "green";
  affectedPrograms: string[];
  status: "open" | "mitigating" | "resolved";
  owner: string;
  eta: string;
  description: string;
  mitigationPlan: string;
  linkedBuilds: string[];
}

const mockConstraints: Constraint[] = [
  { id: "FC-001", factory: "Kunshan", type: "capacity", severity: "red", affectedPrograms: ["Laptop 1", "Laptop 2"], status: "open", owner: "GOE", eta: "2026-07-15", description: "SMT line capacity at 95% utilization. Cannot absorb ramp volumes for both programs simultaneously.", mitigationPlan: "Negotiate overflow capacity with secondary ODM facility in Chongqing. Evaluate weekend shift additions.", linkedBuilds: ["DVT2-L1", "PVT-L2"] },
  { id: "FC-002", factory: "Chengdu", type: "tooling", severity: "yellow", affectedPrograms: ["Laptop 3"], status: "mitigating", owner: "SChM", eta: "2026-06-01", description: "New hinge tooling requires 8-week lead time, currently at 4 weeks remaining.", mitigationPlan: "Expedited tooling order placed. Backup supplier identified for soft tooling if needed.", linkedBuilds: ["DVT1-L3"] },
  { id: "FC-003", factory: "Kunshan", type: "material", severity: "red", affectedPrograms: ["Laptop 1", "Laptop 4", "Laptop 5"], status: "open", owner: "SChM", eta: "2026-08-01", description: "LPDDR5X memory allocation constrained globally. Lead times extended to 16 weeks.", mitigationPlan: "Working with procurement to secure allocation. Evaluating alternative qualified suppliers.", linkedBuilds: ["DVT2-L1", "EVT-L4", "EVT-L5"] },
  { id: "FC-004", factory: "Xiamen", type: "capacity", severity: "green", affectedPrograms: ["Laptop 6"], status: "resolved", owner: "GOE", eta: "2026-05-15", description: "Test station bottleneck resolved with additional equipment installation.", mitigationPlan: "Two additional test stations installed and validated. Capacity now at 80% utilization.", linkedBuilds: ["DVT1-L6"] },
  { id: "FC-005", factory: "Chengdu", type: "material", severity: "yellow", affectedPrograms: ["Laptop 2", "Laptop 3"], status: "mitigating", owner: "SChM", eta: "2026-06-30", description: "Display panel supplier quality issues causing 5% rejection rate.", mitigationPlan: "Supplier corrective action in progress. Second-source qualification underway.", linkedBuilds: ["DVT2-L2", "DVT1-L3"] },
  { id: "FC-006", factory: "Kunshan", type: "tooling", severity: "red", affectedPrograms: ["Laptop 7"], status: "open", owner: "GOE", eta: "2026-09-01", description: "Custom thermal module tooling delayed due to design change request.", mitigationPlan: "Engineering review of design simplification options. Parallel tooling path being evaluated.", linkedBuilds: ["EVT-L7"] },
  { id: "FC-007", factory: "Xiamen", type: "capacity", severity: "yellow", affectedPrograms: ["Laptop 4", "Laptop 5"], status: "mitigating", owner: "NPI", eta: "2026-07-01", description: "Final assembly line changeover time between programs too long.", mitigationPlan: "Implementing quick-change fixture system. Target: reduce changeover from 4h to 1h.", linkedBuilds: ["DVT1-L4", "DVT1-L5"] },
  { id: "FC-008", factory: "Chengdu", type: "material", severity: "green", affectedPrograms: ["Laptop 1"], status: "resolved", owner: "SChM", eta: "2026-04-15", description: "Battery cell supply secured with dual-source agreement.", mitigationPlan: "Both suppliers qualified and producing. Safety stock at 4 weeks.", linkedBuilds: ["PVT-L1"] },
  { id: "FC-009", factory: "Kunshan", type: "tooling", severity: "yellow", affectedPrograms: ["Laptop 2", "Laptop 6"], status: "open", owner: "GOE", eta: "2026-06-15", description: "Keyboard tooling modification needed for new key travel specification.", mitigationPlan: "Tooling vendor quote received. Modification timeline: 6 weeks.", linkedBuilds: ["DVT2-L2", "DVT1-L6"] },
  { id: "FC-010", factory: "Xiamen", type: "capacity", severity: "red", affectedPrograms: ["Laptop 3", "Laptop 7"], status: "open", owner: "GOE", eta: "2026-08-15", description: "Burn-in rack capacity insufficient for simultaneous program ramps.", mitigationPlan: "Capital request submitted for additional burn-in racks. Expected delivery: 10 weeks.", linkedBuilds: ["PVT-L3", "DVT1-L7"] },
];

const severityColors: Record<string, string> = {
  red: "bg-red-100 text-red-800 border-red-200",
  yellow: "bg-yellow-100 text-yellow-800 border-yellow-200",
  green: "bg-green-100 text-green-800 border-green-200",
};

const severityLabels: Record<string, string> = {
  red: "High",
  yellow: "Medium",
  green: "Low",
};

const statusColors: Record<string, string> = {
  open: "bg-gray-100 text-gray-700 border-gray-200",
  mitigating: "bg-blue-100 text-blue-800 border-blue-200",
  resolved: "bg-green-100 text-green-800 border-green-200",
};

const statusLabels: Record<string, string> = {
  open: "Open",
  mitigating: "Mitigating",
  resolved: "Resolved",
};

const FactoryConstraints = () => {
  const { matchesPlatform } = useUniversalFilters();
  const [filterFactory, setFilterFactory] = useState("all");
  const [filterSeverity, setFilterSeverity] = useState("all");
  const [filterType, setFilterType] = useState("all");
  const [selected, setSelected] = useState<Constraint | null>(null);

  const factories = [...new Set(mockConstraints.map(c => c.factory))];

  const platformFiltered = useMemo(() => mockConstraints.filter(c => c.affectedPrograms.some(matchesPlatform)), [matchesPlatform]);

  const filtered = platformFiltered.filter(c => {
    if (filterFactory !== "all" && c.factory !== filterFactory) return false;
    if (filterSeverity !== "all" && c.severity !== filterSeverity) return false;
    if (filterType !== "all" && c.type !== filterType) return false;
    return true;
  });

  const stats = {
    total: platformFiltered.length,
    red: platformFiltered.filter(c => c.severity === "red").length,
    yellow: platformFiltered.filter(c => c.severity === "yellow").length,
    open: platformFiltered.filter(c => c.status === "open").length,
  };

  return (
    <div className="flex-1 flex flex-col overflow-auto p-4 space-y-4">
      <div className="flex items-center gap-2.5">
        <Factory className="w-6 h-6 text-primary" />
        <h1 className="text-[22px] font-extrabold text-foreground tracking-tight flex-1">Factory Constraint Tracker</h1>
        <UniversalFilterBar />
      </div>

      <div className="grid grid-cols-4 gap-3">
        {[
          { label: "Total Constraints", value: stats.total, color: "text-foreground" },
          { label: "High Severity", value: stats.red, color: "text-destructive" },
          { label: "Medium Severity", value: stats.yellow, color: "text-yellow-600" },
          { label: "Open Items", value: stats.open, color: "text-foreground" },
        ].map(s => (
          <Card key={s.label} className="border-border">
            <CardContent className="p-3">
              <p className="text-[10px] text-muted-foreground uppercase tracking-wider font-semibold">{s.label}</p>
              <p className={cn("text-xl font-bold", s.color)}>{s.value}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="flex items-center gap-3">
        <Filter className="w-3.5 h-3.5 text-muted-foreground" />
        <Select value={filterFactory} onValueChange={setFilterFactory}>
          <SelectTrigger className="w-[140px] h-8 text-xs"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Factories</SelectItem>
            {factories.map(f => <SelectItem key={f} value={f}>{f}</SelectItem>)}
          </SelectContent>
        </Select>
        <Select value={filterSeverity} onValueChange={setFilterSeverity}>
          <SelectTrigger className="w-[130px] h-8 text-xs"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Severity</SelectItem>
            <SelectItem value="red">High</SelectItem>
            <SelectItem value="yellow">Medium</SelectItem>
            <SelectItem value="green">Low</SelectItem>
          </SelectContent>
        </Select>
        <Select value={filterType} onValueChange={setFilterType}>
          <SelectTrigger className="w-[130px] h-8 text-xs"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Types</SelectItem>
            <SelectItem value="capacity">Capacity</SelectItem>
            <SelectItem value="tooling">Tooling</SelectItem>
            <SelectItem value="material">Material</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <Card className="border-border">
        <CardContent className="p-0">
          <table className="w-full text-xs">
            <thead>
              <tr className="border-b border-border bg-muted/30">
                {["ID", "Factory", "Type", "Severity", "Affected Programs", "Status", "Owner", "ETA"].map(h => (
                  <th key={h} className="text-left px-3 py-2 font-semibold text-muted-foreground">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filtered.map(c => (
                <tr key={c.id} onClick={() => setSelected(c)} className="border-b border-border/40 hover:bg-muted/20 cursor-pointer transition-colors">
                  <td className="px-3 py-2 font-mono font-medium">{c.id}</td>
                  <td className="px-3 py-2">{c.factory}</td>
                  <td className="px-3 py-2 capitalize">{c.type}</td>
                  <td className="px-3 py-2"><Badge variant="outline" className={cn("text-[9px]", severityColors[c.severity])}>{severityLabels[c.severity]}</Badge></td>
                  <td className="px-3 py-2">
                    <div className="flex flex-wrap gap-1">{c.affectedPrograms.map(p => <span key={p} className="text-[9px] px-1.5 py-0.5 bg-muted rounded">{p}</span>)}</div>
                  </td>
                  <td className="px-3 py-2"><Badge variant="outline" className={cn("text-[9px]", statusColors[c.status])}>{statusLabels[c.status]}</Badge></td>
                  <td className="px-3 py-2">{c.owner}</td>
                  <td className="px-3 py-2 text-muted-foreground">{c.eta}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </CardContent>
      </Card>

      <Dialog open={!!selected} onOpenChange={() => setSelected(null)}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle className="text-sm flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-primary" />
              {selected?.id} — {selected?.factory}
            </DialogTitle>
          </DialogHeader>
          {selected && (
            <div className="space-y-4 text-xs">
              <div className="flex gap-2">
                <Badge variant="outline" className={cn(severityColors[selected.severity])}>{severityLabels[selected.severity]}</Badge>
                <Badge variant="outline" className={cn(statusColors[selected.status])}>{statusLabels[selected.status]}</Badge>
                <Badge variant="outline" className="capitalize">{selected.type}</Badge>
              </div>
              <div>
                <p className="font-semibold text-muted-foreground uppercase text-[10px] mb-1">Description</p>
                <p className="text-foreground">{selected.description}</p>
              </div>
              <div>
                <p className="font-semibold text-muted-foreground uppercase text-[10px] mb-1">Mitigation Plan</p>
                <p className="text-foreground">{selected.mitigationPlan}</p>
              </div>
              <div>
                <p className="font-semibold text-muted-foreground uppercase text-[10px] mb-1">Affected Programs</p>
                <div className="flex flex-wrap gap-1">{selected.affectedPrograms.map(p => <Badge key={p} variant="outline">{p}</Badge>)}</div>
              </div>
              <div>
                <p className="font-semibold text-muted-foreground uppercase text-[10px] mb-1">Linked Build Orders</p>
                <div className="flex flex-wrap gap-1">{selected.linkedBuilds.map(b => <Badge key={b} variant="secondary">{b}</Badge>)}</div>
              </div>
              <div className="flex gap-4">
                <div><p className="text-[10px] text-muted-foreground">Owner</p><p className="font-medium">{selected.owner}</p></div>
                <div><p className="text-[10px] text-muted-foreground">ETA</p><p className="font-medium">{selected.eta}</p></div>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default FactoryConstraints;
