import { useState } from "react";
import ComingSoonBanner from "@/components/dashboard/ComingSoonBanner";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Loader2, Download } from "lucide-react";
import UniversalFilterBar from "@/components/dashboard/UniversalFilterBar";

const gcHeaders = ["GC01", "GC01-DLC-Dleta", "GC01-DLC-AVC", "GC01-WG-1224", "GC02"];

const gcRationaleData: Record<string, string[]> = {
  "GC01": ["Baseline reference config"],
  "GC01-DLC-Dleta": ["DLC cooling expertise"],
  "GC01-DLC-AVC": ["AVC thermal solution availability"],
  "GC01-WG-1224": ["Customer-specific requirement"],
  "GC02": ["New platform introduction"],
};

const bmRationaleData: Record<string, string[]> = {
  "GC01": ["High regional demand", "Established supply chain", "Proven quality track record"],
  "GC01-DLC-Dleta": ["New seller qualification", "Cost-competitive sourcing"],
  "GC01-DLC-AVC": ["Top material allocation", "Proximity to component suppliers"],
  "GC01-WG-1224": ["High regional demand", "Priority fulfillment SLA"],
  "GC02": ["Top material availability", "Capacity expansion target"],
};

const buildMatrixRows = [
  { label: "Config/SID#", values: ["RTS 1.0 (Active)", "RTS 1.0 (Active)", "RTS 1.0 (Active)", "RTS 1.0 (Active)", "RTS 1.0 (Active)"], highlight: [] },
  { label: "FSJ", values: [0, 0, 1, 1, 0], highlight: [false, false, true, true, false] },
  { label: "EMFP", values: [1, 0, 1, 0, 1], highlight: [true, false, true, false, true] },
  { label: "CCC2", values: [1, 1, 0, 0, 0], highlight: [true, true, false, false, false] },
  { label: "CCC4", values: [0, 0, 0, 0, 0], highlight: [] },
  { label: "APCC", values: [1, 1, 0, 0, 1], highlight: [true, true, false, false, true] },
  { label: "BRH", values: [0, 0, 0, 0, 0], highlight: [] },
  { label: "ICC", values: [0, 0, 0, 0, 0], highlight: [] },
  { label: "Pilot", values: [0, 0, 0, 0, 0], highlight: [] },
];

const goldenConfigRows = [
  { label: "CHAS", values: ["No backplane", "No backplane", "No backplane", "No backplane", "8x E3.S G6x4"] },
  { label: "PPCM", values: ["C0", "C0", "C0", "C0", "C01-01"] },
  { label: "CBL config#", values: ["0,", "0,", "0,", "0,", "1,"] },
  { label: "CPU/HSK", values: ["256C / 600W", "400W", "400W", "256C / 600W", "128 Core"] },
  { label: "BOSS", values: ["2x 960GB", "2x 960GB", "2x 960GB", "2x 960GB", "With 2x960GB"] },
  { label: "RAIDcfg#", values: ["diskless", "diskless", "diskless", "diskless", "Direct NVMe"] },
  { label: "Riser#", values: ["RC1,RC2,RC3,RC4,", "RC1,RC2,RC3,RC4,", "RC1,RC2,RC3,RC4,", "RC1,RC2,RC3,RC4,", "RC3,RC4,"] },
  { label: "DIMM", values: ["32x64GB", "4x 64G RDIMM", "4x 64G RDIMM", "32x64GB", "32x64GB"] },
  { label: "DRIVE", values: ["—", "—", "—", "—", "4x3.84TB DC"] },
  { label: "NIC/OCP", values: ["NVIDIA CX6-Lx 2P 25Gb", "No OCP", "No OCP", "NVIDIA CX6-Lx 2P 25Gb", "Broadcom 10G"] },
  { label: "Add-in card", values: ["NVIDIA CX6-Dx 2P 100G", "NVIDIA CX6-Dx 2P 100G", "NVIDIA CX6-Dx 2P 100G", "NVIDIA CX6-Dx 2P 100G", "2x 100GbF 2P"] },
];

const GoldenConfigsContent = () => {

  const [loaded, setLoaded] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleLoad = () => {
    setLoading(true);
    setTimeout(() => {
      setLoaded(true);
      setLoading(false);
    }, 800);
  };

  const colCount = gcHeaders.length + 1;

  return (
    <div className="flex-1 flex flex-col overflow-auto">
      <div className="p-5 pb-3 flex items-center justify-between">
        <h1 className="text-base font-bold text-foreground">Golden Config & Build Matrix</h1>
        <div className="flex items-center gap-2">
          <UniversalFilterBar />
        <Button
          size="sm"
          onClick={handleLoad}
          disabled={loading || loaded}
          className="gap-2"
        >
          {loading ? (
            <><Loader2 className="w-3.5 h-3.5 animate-spin" />Loading…</>
          ) : loaded ? (
            <><Download className="w-3.5 h-3.5" />Loaded</>
          ) : (
            <><Download className="w-3.5 h-3.5" />Load Configs</>
          )}
        </Button>
        </div>
      </div>

      <div className="px-5 pb-5 flex-1 min-h-0 space-y-4 overflow-auto">
        {/* Golden Config Table */}
        <div className="border border-border rounded-lg bg-card overflow-hidden">
          <div className="bg-primary px-4 py-2">
            <h2 className="text-sm font-bold text-primary-foreground text-center">Golden Config</h2>
          </div>
          {loaded && (
            <div className="bg-muted/30 border-b border-border px-4 py-3">
              <h3 className="text-[11px] font-semibold text-foreground mb-2">Rationale</h3>
              <Table>
                <TableBody>
                  <TableRow className="border-0 hover:bg-transparent">
                    <TableCell className="w-[120px] p-0" />
                    {gcHeaders.map((gc) => (
                      <TableCell key={gc} className="p-1 align-top">
                        <p className="text-[10px] font-semibold text-primary mb-1">{gc}</p>
                        <ul className="space-y-0.5">
                          {gcRationaleData[gc]?.map((reason, i) => (
                            <li key={i} className="text-[10px] text-muted-foreground flex items-start gap-1">
                              <span className="text-primary mt-0.5">•</span>
                              {reason}
                            </li>
                          ))}
                        </ul>
                      </TableCell>
                    ))}
                  </TableRow>
                </TableBody>
              </Table>
            </div>
          )}
          <div className="overflow-auto">
            <Table>
              <TableHeader>
                <TableRow className="bg-muted/50">
                  <TableHead className="text-xs font-semibold w-[120px]">GC#</TableHead>
                  {gcHeaders.map((h) => (
                    <TableHead key={h} className="text-xs font-semibold text-center bg-primary/10 text-primary">{h}</TableHead>
                  ))}
                </TableRow>
              </TableHeader>
              <TableBody>
                {!loaded ? (
                  <TableRow>
                    <TableCell colSpan={colCount} className="h-24 text-center text-sm text-muted-foreground">
                      {loading ? "Loading…" : "Click \"Load Configs\" to populate."}
                    </TableCell>
                  </TableRow>
                ) : (
                  goldenConfigRows.map((row) => (
                    <TableRow key={row.label} className="hover:bg-muted/30">
                      <TableCell className="text-xs font-semibold text-primary">{row.label}</TableCell>
                      {row.values.map((val, i) => (
                        <TableCell key={i} className="text-xs text-center font-mono text-foreground">
                          {val}
                        </TableCell>
                      ))}
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </div>

        {/* Build Matrix Table */}
        <div className="border border-border rounded-lg bg-card overflow-hidden">
          <div className="bg-primary px-4 py-2">
            <h2 className="text-sm font-bold text-primary-foreground text-center">Build Matrix</h2>
          </div>
          {loaded && (
            <div className="bg-muted/30 border-b border-border px-4 py-3">
              <h3 className="text-[11px] font-semibold text-foreground mb-2">Rationale</h3>
              <Table>
                <TableBody>
                  <TableRow className="border-0 hover:bg-transparent">
                    <TableCell className="w-[120px] p-0" />
                    {gcHeaders.map((gc) => (
                      <TableCell key={gc} className="p-1 align-top">
                        <p className="text-[10px] font-semibold text-primary mb-1">{gc}</p>
                        <ul className="space-y-0.5">
                          {bmRationaleData[gc]?.map((reason, i) => (
                            <li key={i} className="text-[10px] text-muted-foreground flex items-start gap-1">
                              <span className="text-primary mt-0.5">•</span>
                              {reason}
                            </li>
                          ))}
                        </ul>
                      </TableCell>
                    ))}
                  </TableRow>
                </TableBody>
              </Table>
            </div>
          )}
          <div className="overflow-auto">
            <Table>
              <TableHeader>
                <TableRow className="bg-muted/50">
                  <TableHead className="text-xs font-semibold w-[120px]">Config/SID#</TableHead>
                  {gcHeaders.map((h) => (
                    <TableHead key={h} className="text-xs font-semibold text-center">{h}</TableHead>
                  ))}
                </TableRow>
              </TableHeader>
              <TableBody>
                {!loaded ? (
                  <TableRow>
                    <TableCell colSpan={colCount} className="h-24 text-center text-sm text-muted-foreground">
                      {loading ? "Loading…" : "Click \"Load Configs\" to populate."}
                    </TableCell>
                  </TableRow>
                ) : (
                  buildMatrixRows.map((row) => (
                    <TableRow key={row.label} className="hover:bg-muted/30">
                      <TableCell className="text-xs font-semibold text-primary">{row.label}</TableCell>
                      {row.values.map((val, i) => {
                        const isHighlighted = row.highlight?.[i];
                        return (
                          <TableCell
                            key={i}
                            className={`text-xs text-center font-mono ${
                              isHighlighted ? "bg-success/20 font-semibold text-foreground" : "text-muted-foreground"
                            }`}
                          >
                            {val}
                          </TableCell>
                        );
                      })}
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </div>
      </div>
    </div>
  );
};

const GoldenConfigsPage = () => (
  <ComingSoonBanner message="To be completed in version 2.0">
    <GoldenConfigsContent />
  </ComingSoonBanner>
);

export default GoldenConfigsPage;
