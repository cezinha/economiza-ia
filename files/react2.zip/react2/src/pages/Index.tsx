import CurrentHomePage from "@/components/dashboard/CurrentHomePage";

const Index = () => <CurrentHomePage />;

export default Index;
