import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { motion } from "framer-motion";
import dellLogo from "@/assets/dell-logo.png";
import { Rocket, BarChart3, Shield, Zap, Lock } from "lucide-react";
import { useRole, type AppRole, SCOPED_ROLES, supportsMultiplePlatforms } from "@/contexts/RoleContext";
import { usePlatform } from "@/contexts/PlatformContext";
import { useUniversalFilters, PLATFORM_LOB, PLATFORM_ORG } from "@/contexts/UniversalFilterContext";

const features = [
  { icon: Rocket, title: "Launch Faster", desc: "Streamline product launches with unified workflows" },
  { icon: BarChart3, title: "Real-Time Insights", desc: "Live dashboards across all programs and phases" },
  { icon: Shield, title: "Risk Management", desc: "Proactive NUDDs tracking and mitigation" },
  { icon: Zap, title: "Integrated Tools", desc: "Single pane of glass across 10+ enterprise tools" },
];

const ROLES: AppRole[] = ["Executive", "Super Admin", "Admin", "User"];

const Login = () => {
  const [emailPrefix, setEmailPrefix] = useState("");
  const [role, setRole] = useState<AppRole | "">("");
  const [password, setPassword] = useState("");
  const [selectedPlatforms, setSelectedPlatforms] = useState<string[]>([]);
  const navigate = useNavigate();
  const { setRoleAndPlatforms } = useRole();
  const { programs, setSelectedPlatform } = usePlatform();
  const { updateFilter } = useUniversalFilters();

  const fullEmail = emailPrefix ? `${emailPrefix}@dell.com` : "";
  const isScoped = role !== "" && SCOPED_ROLES.includes(role as AppRole);
  const allowsMulti = supportsMultiplePlatforms(role === "" ? null : (role as AppRole));

  const togglePlatform = (p: string, checked: boolean) => {
    setSelectedPlatforms((prev) => {
      if (!allowsMulti) return checked ? [p] : [];
      if (checked) return Array.from(new Set([...prev, p]));
      return prev.filter((x) => x !== p);
    });
  };

  const canSubmit =
    !!emailPrefix && !!role && (!isScoped || selectedPlatforms.length > 0);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!canSubmit) return;

    const parts = emailPrefix.split(".");
    const name = parts.map((p) => p.charAt(0).toUpperCase() + p.slice(1).toLowerCase()).join(" ");
    localStorage.setItem("userName", name);
    localStorage.setItem("userEmail", fullEmail);

    const platforms = isScoped ? selectedPlatforms : [];
    setRoleAndPlatforms(role as AppRole, platforms, true);

    // Auto-apply filters from assigned scope
    if (platforms.length > 0) {
      const primary = platforms[0];
      const org = PLATFORM_ORG[primary];
      const lob = PLATFORM_LOB[primary];
      if (org) updateFilter("organization", org);
      if (lob) updateFilter("lob", lob);
      if (platforms.length === 1) {
        updateFilter("platform", primary);
        setSelectedPlatform(primary);
      } else {
        updateFilter("platform", "all");
        setSelectedPlatform(null);
      }
    }

    navigate("/");
  };

  return (
    <div className="min-h-screen flex bg-background">
      {/* Left hero panel */}
      <motion.div
        initial={{ opacity: 0, x: -20 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ duration: 0.6, ease: [0.25, 0.1, 0.25, 1] }}
        className="hidden lg:flex lg:w-[55%] relative overflow-hidden bg-gradient-to-br from-[hsl(210,52%,14%)] via-[hsl(210,48%,20%)] to-[hsl(207,55%,26%)] flex-col justify-between p-14"
      >
        <div className="absolute top-16 right-16 w-72 h-72 bg-primary/[0.08] rounded-full blur-3xl animate-float" />
        <div className="absolute bottom-24 left-12 w-56 h-56 bg-primary/[0.06] rounded-full blur-2xl" style={{ animationDelay: "2s" }} />
        <div className="absolute top-1/2 right-1/3 w-36 h-36 bg-[hsl(180,50%,42%)]/[0.06] rounded-2xl blur-xl rotate-45 animate-float" style={{ animationDelay: "4s" }} />

        <div className="relative z-10">
          <img src={dellLogo} alt="Dell Technologies" className="h-6 brightness-0 invert opacity-60 mb-10" />
          <h1 className="text-[40px] font-black text-white leading-[1.1] max-w-lg tracking-tight">
            OLP Launch<br />Orchestrator
          </h1>
          <p className="text-white/40 text-[13px] mt-5 max-w-md leading-relaxed font-medium">
            The single pane of glass for managing product launches — from concept to ramp. Replace spreadsheets with real-time visibility.
          </p>
        </div>

        <div className="relative z-10 grid grid-cols-2 gap-3">
          {features.map((f, i) => (
            <motion.div
              key={f.title}
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.4, delay: 0.3 + i * 0.1 }}
              className="flex items-start gap-3 p-4 rounded-xl bg-white/[0.04] border border-white/[0.06]"
            >
              <div className="w-8 h-8 rounded-lg bg-white/[0.06] flex items-center justify-center shrink-0">
                <f.icon className="w-4 h-4 text-white/50" />
              </div>
              <div>
                <span className="text-[11px] font-bold text-white/90 block">{f.title}</span>
                <span className="text-[10px] text-white/30 leading-relaxed">{f.desc}</span>
              </div>
            </motion.div>
          ))}
        </div>
      </motion.div>

      {/* Right login form */}
      <div className="flex-1 flex items-center justify-center p-8 overflow-y-auto">
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.15, ease: [0.25, 0.1, 0.25, 1] }}
          className="w-full max-w-[380px]"
        >
          <div className="lg:hidden flex justify-center mb-8">
            <img src={dellLogo} alt="Dell Logo" className="h-7" />
          </div>

          <div className="text-center mb-6">
            <h2 className="text-2xl font-black text-foreground tracking-tight">Welcome Back</h2>
            <p className="text-[12px] text-muted-foreground mt-2">Sign in to OLP Launch Orchestrator</p>
          </div>

          <Card className="shadow-lg border-border/40 rounded-2xl">
            <CardContent className="p-7">
              <form onSubmit={handleSubmit} className="space-y-5">
                <div className="space-y-2">
                  <Label htmlFor="email" className="text-[11px] font-bold uppercase tracking-wide text-muted-foreground">Email</Label>
                  <div className="flex items-center gap-0">
                    <Input
                      id="email"
                      type="text"
                      placeholder="firstname.lastname"
                      value={emailPrefix}
                      onChange={(e) => setEmailPrefix(e.target.value.replace(/\s/g, ""))}
                      className="h-11 rounded-xl rounded-r-none border-r-0 focus-visible:z-10"
                      autoComplete="username"
                    />
                    <span className="h-11 flex items-center px-3 bg-muted border border-border border-l-0 rounded-xl rounded-l-none text-[12px] font-semibold text-muted-foreground select-none whitespace-nowrap">
                      @dell.com
                    </span>
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="role" className="text-[11px] font-bold uppercase tracking-wide text-muted-foreground">Role</Label>
                  <Select value={role} onValueChange={(v) => { setRole(v as AppRole); setSelectedPlatforms([]); }}>
                    <SelectTrigger id="role" className="h-11 rounded-xl">
                      <SelectValue placeholder="Select a role" />
                    </SelectTrigger>
                    <SelectContent>
                      {ROLES.map((r) => (
                        <SelectItem key={r} value={r}>
                          {r}
                          {SCOPED_ROLES.includes(r) && (
                            <span className="ml-2 text-[10px] text-muted-foreground">(platform-scoped)</span>
                          )}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {isScoped && (
                  <div className="space-y-2">
                    <Label className="text-[11px] font-bold uppercase tracking-wide text-muted-foreground flex items-center gap-1.5">
                      <Lock className="w-3 h-3" />
                      {allowsMulti ? "Assigned Platforms" : "Assigned Platform"}
                    </Label>
                    <p className="text-[10px] text-muted-foreground/70 leading-relaxed">
                      {allowsMulti
                        ? "Select one or more platforms. Org, LOB and Platform filters will be locked to this scope."
                        : "Select your assigned platform. Org, LOB and Platform filters will be locked to this scope."}
                    </p>
                    <div className="rounded-xl border border-border/50 divide-y divide-border/40 max-h-[180px] overflow-auto">
                      {programs.map((p) => {
                        const checked = selectedPlatforms.includes(p);
                        if (allowsMulti) {
                          return (
                            <label key={p} className="flex items-center gap-2.5 px-3 py-2 cursor-pointer hover:bg-muted/40 transition-colors">
                              <Checkbox checked={checked} onCheckedChange={(v) => togglePlatform(p, v === true)} />
                              <span className="text-[12px] font-medium text-foreground">{p}</span>
                              <span className="ml-auto text-[10px] text-muted-foreground">{PLATFORM_ORG[p]} · {PLATFORM_LOB[p]}</span>
                            </label>
                          );
                        }
                        return (
                          <label key={p} className="flex items-center gap-2.5 px-3 py-2 cursor-pointer hover:bg-muted/40 transition-colors">
                            <input
                              type="radio"
                              name="single-platform"
                              checked={checked}
                              onChange={() => togglePlatform(p, true)}
                              className="accent-primary"
                            />
                            <span className="text-[12px] font-medium text-foreground">{p}</span>
                            <span className="ml-auto text-[10px] text-muted-foreground">{PLATFORM_ORG[p]} · {PLATFORM_LOB[p]}</span>
                          </label>
                        );
                      })}
                    </div>
                  </div>
                )}

                <div className="space-y-2">
                  <Label htmlFor="password" className="text-[11px] font-bold uppercase tracking-wide text-muted-foreground">Password</Label>
                  <Input
                    id="password"
                    type="password"
                    placeholder="Enter password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="h-11 rounded-xl"
                  />
                </div>
                <Button type="submit" className="w-full h-11 font-bold press-scale rounded-xl text-[13px]" disabled={!canSubmit}>
                  Sign In
                </Button>
              </form>
            </CardContent>
          </Card>

          <p className="text-center text-[10px] text-muted-foreground/35 mt-6">
            OLP Launch Orchestrator v2.1 · Dell Technologies © 2026
          </p>
        </motion.div>
      </div>
    </div>
  );
};

export default Login;
