import { useState, useMemo } from "react";
import { programSchedules } from "@/data/scheduleData";
import type { ScheduleTask, Phase } from "@/data/scheduleData";
import { getTaskParticipants, CURRENT_USER_OWNER_NAME } from "@/data/taskParticipants";
import MyTasksList from "@/components/dashboard/MyTasksList";
import CurrentTaskDetail from "@/components/dashboard/CurrentTaskDetail";
import RelevantInfoPanel from "@/components/dashboard/RelevantInfoPanel";
import { usePlatform } from "@/contexts/PlatformContext";
import { useUniversalFilters, phaseMatches } from "@/contexts/UniversalFilterContext";
import { useRole } from "@/contexts/RoleContext";
import TaskPageFilters, { defaultTaskPageFilters, type TaskPageFilterState } from "@/components/dashboard/TaskPageFilters";
import { taskMatchesFunction } from "@/components/dashboard/FunctionFilter";
import { ClipboardCheck } from "lucide-react";

const MyTasks = () => {
  const { selectedPlatform, programs } = usePlatform();
  const { filters, matchesPlatform } = useUniversalFilters();
  const { role, assignedPlatforms } = useRole();
  const [pageFilters, setPageFilters] = useState<TaskPageFilterState>(defaultTaskPageFilters);

  // Universe of platforms this view may show, by role:
  // - Admin → only assigned platforms
  // - User / Super Admin / Executive → all platforms (User is further filtered by ownership)
  const rolePlatforms = useMemo<string[]>(() => {
    if (role === "Admin" && assignedPlatforms.length > 0) return assignedPlatforms;
    return [...programs];
  }, [role, assignedPlatforms, programs]);

  const isUserRole = role === "User";

  const phases: Phase[] = useMemo(() => {
    const roleSet = new Set(rolePlatforms);
    const phaseFilter = (name: string) =>
      pageFilters.phases.length === 0 || pageFilters.phases.some((p) => phaseMatches(p, name));

    const taskPasses = (t: ScheduleTask): boolean => {
      if (!taskMatchesFunction(t, pageFilters.functions)) return false;
      if (pageFilters.tasks.length > 0) {
        const lowerName = t.name.toLowerCase();
        if (!pageFilters.tasks.some((cat) => lowerName.includes(cat.toLowerCase()))) return false;
      }
      if (pageFilters.primaryOwners.length > 0) {
        const ownerName = getTaskParticipants(t).owner;
        if (!pageFilters.primaryOwners.includes(ownerName)) return false;
      }
      if (isUserRole && getTaskParticipants(t).owner !== CURRENT_USER_OWNER_NAME) return false;
      return true;
    };

    const buildFiltered = (raw: Phase[], prefix?: string): Phase[] => {
      return raw
        .filter((ph) => phaseFilter(ph.name))
        .map((ph) => {
          const milestones = ph.milestones
            .map((m) => ({
              ...m,
              tasks: m.tasks.filter(taskPasses),
            }))
            .filter((m) => m.tasks.length > 0);
          return {
            ...ph,
            name: prefix ? `${prefix} — ${ph.name}` : ph.name,
            milestones,
          };
        })
        .filter((ph) => ph.milestones.length > 0);
    };

    if (selectedPlatform && matchesPlatform(selectedPlatform) && roleSet.has(selectedPlatform)) {
      return buildFiltered(programSchedules[selectedPlatform] ?? []);
    }

    const merged: Phase[] = [];
    for (const p of programs) {
      if (!roleSet.has(p)) continue;
      if (!matchesPlatform(p)) continue;
      merged.push(...buildFiltered(programSchedules[p] ?? [], p));
    }
    return merged;
  }, [selectedPlatform, programs, pageFilters, matchesPlatform, rolePlatforms, isUserRole]);

  const [selectedTask, setSelectedTask] = useState<{
    task: ScheduleTask;
    phaseName: string;
    milestoneName: string;
  } | null>(null);

  const handleSelectTask = (task: ScheduleTask, phaseName: string, milestoneName: string) => {
    setSelectedTask({ task, phaseName, milestoneName });
  };

  const titleScope = useMemo(() => {
    if (filters.platform !== "all") return filters.platform;
    if (filters.lob !== "all") return `${filters.lob}`;
    if (selectedPlatform) return selectedPlatform;
    return "All Platforms";
  }, [filters.platform, filters.lob, selectedPlatform]);

  return (
    <div className="p-4 h-[calc(100vh-56px)]">
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2.5">
          <ClipboardCheck className="w-6 h-6 text-primary" />
          <h1 className="text-[22px] font-extrabold text-foreground tracking-tight">
            {titleScope} — My Tasks
          </h1>
        </div>
        <TaskPageFilters value={pageFilters} onChange={setPageFilters} />
      </div>
      <div className="flex gap-3 h-[calc(100%-36px)]">
        <div className={selectedTask ? "w-[320px] shrink-0" : "w-full max-w-2xl"}>
          {phases.length === 0 ? (
            <div className="h-full flex items-center justify-center border border-border rounded-lg bg-card text-xs text-muted-foreground">
              No tasks match the current filters.
            </div>
          ) : (
            <MyTasksList
              phases={phases}
              selectedTaskId={selectedTask?.task.id ?? null}
              onSelectTask={handleSelectTask}
            />
          )}
        </div>

        {selectedTask && (
          <>
            <div className="flex-1 min-w-0">
              <CurrentTaskDetail
                task={selectedTask.task}
                phaseName={selectedTask.phaseName}
                milestoneName={selectedTask.milestoneName}
              />
            </div>
            <div className="w-[300px] shrink-0">
              <RelevantInfoPanel
                task={selectedTask.task}
                phaseName={selectedTask.phaseName}
              />
            </div>
          </>
        )}
      </div>
    </div>
  );
};

export default MyTasks;
