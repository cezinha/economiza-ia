import { useState, useEffect, useRef, useCallback, useMemo } from "react";
import { motion } from "framer-motion";
import { useLocation } from "react-router-dom";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Download, ExternalLink, AlertTriangle, Layers, Activity, ChevronRight, ShieldAlert, ShieldCheck, Shield, Info } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Tooltip, TooltipContent, TooltipTrigger, TooltipProvider } from "@/components/ui/tooltip";
import * as XLSX from "xlsx";
import UniversalFilterBar from "@/components/dashboard/UniversalFilterBar";
import { StickyHomeFilterBar } from "@/components/dashboard/HomeFilterBar";
import { useUniversalFilters } from "@/contexts/UniversalFilterContext";
import { useHomeFilters } from "@/contexts/HomeFilterContext";
import { useRole } from "@/contexts/RoleContext";

// NUDDs data lives in a shared module so other surfaces (e.g. the platform
// schedule summary) can reason about the same dataset.
import { nuddsData, nuddsScoringData, PHASES_ORDER, phaseMap, type NuddStatus } from "@/data/nuddsData";
import { SCHM_PHASES, TRACK_LABEL, TRACK_TONE } from "@/data/phaseTracks";

// Map a GOE/NPI canonical phase to its SChM-track equivalent.
// Concept/Define/Plan are shared; Qual+Pilot collapse into Develop; Ramp → Launch.
const goeToSchmPhase = (goePhase: string): string => {
  if (goePhase === "Qual" || goePhase === "Pilot") return "Develop";
  if (goePhase === "Ramp") return "Launch";
  return goePhase; // Concept / Define / Plan pass through
};

// ─── JIRA-style helpers ──────────────────────────────────────────────────────
const MONTHS_SHORT = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
const formatJiraDate = (iso: string, withTime = false): string => {
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return iso;
  const dd = String(d.getDate()).padStart(2, "0");
  const mm = String(d.getMonth() + 1).padStart(2, "0");
  const yy = String(d.getFullYear()).slice(-2);
  const base = `${dd}/${mm}/${yy}`;
  if (!withTime) return base;
  const hh = String(d.getHours()).padStart(2, "0");
  const mi = String(d.getMinutes()).padStart(2, "0");
  return `${base} · ${hh}:${mi}`;
};
const getStatusBadgeClass = (status: NuddStatus): string => {
  switch (status) {
    case "Open":      return "bg-indigo-500/10 text-indigo-700 dark:text-indigo-300 border border-indigo-500/30";
    case "On Hold":   return "bg-slate-500/10 text-slate-700 dark:text-slate-300 border border-slate-500/30";
    case "Completed": return "bg-primary/10 text-primary border border-primary/30";
  }
};
const getRiskPillClass = (lvl: string): string => {
  if (lvl === "H") return "bg-destructive/10 text-destructive border border-destructive/30";
  if (lvl === "M") return "bg-amber-500/10 text-amber-700 dark:text-amber-400 border border-amber-500/30";
  return "bg-emerald-500/10 text-emerald-700 dark:text-emerald-400 border border-emerald-500/30";
};
// Single-axis scores (1=Low, 2=Medium, 3=High) — same RYG palette.
const getAxisScoreClass = (n: number): string => {
  if (n >= 3) return "bg-destructive/10 text-destructive border border-destructive/30";
  if (n === 2) return "bg-amber-500/10 text-amber-700 dark:text-amber-400 border border-amber-500/30";
  return "bg-emerald-500/10 text-emerald-700 dark:text-emerald-400 border border-emerald-500/30";
};

// Deterministic hash for placeholder People/Dates per NUDD
const hashStr = (s: string): number => {
  let h = 0;
  for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) | 0;
  return Math.abs(h);
};
const PEOPLE_POOL = ["Priya Raman", "Marcus Chen", "Hannah Weiss", "Diego Alvarez", "Yuki Tanaka", "Olivia Park", "Rahul Mehta", "Sara Nguyen", "Liam O'Connor", "Ana Costa", "Vikram Shah", "Rebecca Lin", "Daniel Ortega", "Lucia Fernández"];
const pickPerson = (id: string, slot: string): string => {
  const h = hashStr(`${id}:${slot}`);
  return PEOPLE_POOL[h % PEOPLE_POOL.length];
};
const offsetDate = (iso: string, days: number): string => {
  const d = new Date(iso);
  d.setDate(d.getDate() + days);
  return d.toISOString();
};

// Unified RYG color scheme across all NUDD risk visuals.
const RISK_COLOR_HIGH = "hsl(var(--destructive))";
const RISK_COLOR_MED = "hsl(38 92% 50%)";   // amber-500
const RISK_COLOR_LOW = "hsl(142 71% 45%)";  // emerald-500

const nuddsPoints = nuddsScoringData.map((d) => ({
  x: d.riskImpact,
  y: d.riskProbability,
  id: d.id,
  color: d.overallRiskLevel === "H" ? RISK_COLOR_HIGH : d.overallRiskLevel === "M" ? RISK_COLOR_MED : RISK_COLOR_LOW,
}));

type CanonicalPhase = typeof PHASES_ORDER[number];

interface PhaseRiskData { phase: string; low: number; medium: number; high: number; totalScore: number; }

const computePhaseRiskData = (
  items: Record<string, string>[],
  scoring: { riskPriority: number; overallRiskLevel: string }[],
  track: "GOE_NPI" | "SCHM" = "GOE_NPI",
): PhaseRiskData[] => {
  const phases = track === "SCHM" ? (SCHM_PHASES as readonly string[]) : (PHASES_ORDER as readonly string[]);
  const map: Record<string, { low: number; medium: number; high: number; totalScore: number }> = {};
  phases.forEach((p) => { map[p] = { low: 0, medium: 0, high: 0, totalScore: 0 }; });
  items.forEach((item, i) => {
    const goePhase = phaseMap(item.goeOlpPhase || "");
    const phase = track === "SCHM" ? goeToSchmPhase(goePhase) : goePhase;
    if (!map[phase]) return;
    const score = scoring[i];
    if (!score) return;
    if (score.overallRiskLevel === "H") map[phase].high++;
    else if (score.overallRiskLevel === "M") map[phase].medium++;
    else map[phase].low++;
    map[phase].totalScore += score.riskPriority;
  });
  return phases.map((p) => ({ phase: p, ...map[p] }));
};

function filterItems<T extends { affectedLOBs: string; affectedPlatforms: string }>(items: T[], lobFilter: string, platFilter: string): T[] {
  let result = items;
  if (lobFilter !== "all") result = result.filter((i) => i.affectedLOBs.includes(lobFilter));
  if (platFilter !== "all") result = result.filter((i) => i.affectedPlatforms.includes(platFilter));
  return result;
}

// ─── Charts (compact) ────────────────────────────────────────────────────────
type PhaseNudd = {
  id: string;
  summary: string;
  riskPriority: number;
  overallRiskLevel: string;
};

const RiskByPhaseChart = ({
  data,
  title,
  nuddsByPhase,
  onNuddClick,
}: {
  data: PhaseRiskData[];
  title: string;
  nuddsByPhase: Record<string, PhaseNudd[]>;
  onNuddClick: (id: string) => void;
}) => {
  const max = Math.max(1, ...data.map((d) => d.low + d.medium + d.high));
  const [pinnedPhase, setPinnedPhase] = useState<string | null>(null);
  const [hoverPhase, setHoverPhase] = useState<string | null>(null);
  const activePhase = pinnedPhase ?? hoverPhase;

  const cardRef = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (!pinnedPhase) return;
    const onDown = (e: MouseEvent) => {
      if (cardRef.current && !cardRef.current.contains(e.target as Node)) {
        setPinnedPhase(null);
      }
    };
    document.addEventListener("mousedown", onDown);
    return () => document.removeEventListener("mousedown", onDown);
  }, [pinnedPhase]);

  const riskPillBorderClass = (lvl: string) =>
    lvl === "H"
      ? "bg-destructive/10 text-destructive border-destructive/30"
      : lvl === "M"
      ? "bg-amber-500/10 text-amber-700 dark:text-amber-400 border-amber-500/30"
      : "bg-emerald-500/10 text-emerald-700 dark:text-emerald-400 border-emerald-500/30";

  return (
    <div ref={cardRef} className="rounded-2xl bg-card p-5 shadow-sm border border-border/50 h-full flex flex-col relative">
      <h4 className="text-sm font-semibold tracking-tight text-foreground/90 mb-4">{title}</h4>
      <div className="flex items-stretch justify-between gap-3 sm:gap-6 h-72 px-2 relative">
        {data.map((d) => {
          const total = d.low + d.medium + d.high;
          const heightPct = (total / max) * 100;
          const segPct = (n: number) => (total === 0 ? 0 : (n / total) * 100);
          const isActive = activePhase === d.phase;
          const isPinned = pinnedPhase === d.phase;
          const phaseNudds = nuddsByPhase[d.phase] ?? [];

          return (
            <div
              key={d.phase}
              className="flex-1 flex flex-col items-center gap-2 group h-full relative"
              onMouseEnter={() => setHoverPhase(d.phase)}
              onMouseLeave={() => setHoverPhase(null)}
            >
              <span className="text-sm font-bold text-foreground tabular-nums h-5">{total || ""}</span>
              <div className="flex-1 w-full flex items-end justify-center min-h-0">
                {total > 0 ? (
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      setPinnedPhase((cur) => (cur === d.phase ? null : d.phase));
                    }}
                    className={`w-full max-w-[72px] flex flex-col-reverse rounded-md overflow-hidden border bg-muted/20 transition-all cursor-pointer focus:outline-none focus-visible:ring-2 focus-visible:ring-primary/50 ${
                      isActive
                        ? "border-primary shadow-md ring-1 ring-primary/30"
                        : "border-border/40 group-hover:border-primary/50 group-hover:shadow-md"
                    }`}
                    style={{ height: `${Math.max(heightPct, 4)}%`, minHeight: 12 }}
                    aria-label={`${d.phase}: ${total} NUDDs. Click to pin details.`}
                  >
                    {d.low > 0 && (
                      <motion.div
                        initial={{ height: 0 }}
                        animate={{ height: `${segPct(d.low)}%` }}
                        transition={{ duration: 0.5 }}
                        className="bg-success w-full flex items-center justify-center"
                      >
                        {segPct(d.low) >= 12 && (
                          <span className="text-[10px] font-bold text-white tabular-nums">{d.low}</span>
                        )}
                      </motion.div>
                    )}
                    {d.medium > 0 && (
                      <motion.div
                        initial={{ height: 0 }}
                        animate={{ height: `${segPct(d.medium)}%` }}
                        transition={{ duration: 0.5, delay: 0.1 }}
                        className="bg-warning w-full flex items-center justify-center"
                      >
                        {segPct(d.medium) >= 12 && (
                          <span className="text-[10px] font-bold text-white tabular-nums">{d.medium}</span>
                        )}
                      </motion.div>
                    )}
                    {d.high > 0 && (
                      <motion.div
                        initial={{ height: 0 }}
                        animate={{ height: `${segPct(d.high)}%` }}
                        transition={{ duration: 0.5, delay: 0.2 }}
                        className="bg-destructive w-full flex items-center justify-center"
                      >
                        {segPct(d.high) >= 12 && (
                          <span className="text-[10px] font-bold text-white tabular-nums">{d.high}</span>
                        )}
                      </motion.div>
                    )}
                  </button>
                ) : (
                  <div className="w-full max-w-[72px] h-3 rounded-md border border-dashed border-border/40" />
                )}
              </div>
              <span className={`text-[11px] font-semibold uppercase tracking-wide text-center leading-tight ${isActive ? "text-primary" : "text-muted-foreground"}`}>
                {d.phase}
              </span>

              {isActive && total > 0 && (
                <motion.div
                  initial={{ opacity: 0, y: 4 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.15 }}
                  className="absolute z-30 bottom-full mb-2 left-1/2 -translate-x-1/2 w-72 rounded-lg border border-border bg-popover text-popover-foreground shadow-xl p-3"
                  onClick={(e) => e.stopPropagation()}
                  onMouseEnter={() => setHoverPhase(d.phase)}
                >
                  <div className="flex items-center justify-between mb-2 pb-2 border-b border-border/60">
                    <div>
                      <p className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground">{d.phase}</p>
                      <p className="text-sm font-semibold text-foreground">{total} NUDD{total !== 1 ? "s" : ""}</p>
                    </div>
                    <div className="flex items-center gap-1">
                      {d.high > 0 && <span className="inline-flex items-center rounded-full px-1.5 py-0.5 text-[10px] font-semibold bg-destructive/10 text-destructive border border-destructive/30">H {d.high}</span>}
                      {d.medium > 0 && <span className="inline-flex items-center rounded-full px-1.5 py-0.5 text-[10px] font-semibold bg-amber-500/10 text-amber-700 dark:text-amber-400 border border-amber-500/30">M {d.medium}</span>}
                      {d.low > 0 && <span className="inline-flex items-center rounded-full px-1.5 py-0.5 text-[10px] font-semibold bg-emerald-500/10 text-emerald-700 dark:text-emerald-400 border border-emerald-500/30">L {d.low}</span>}
                    </div>
                  </div>
                  <div className="max-h-56 overflow-auto -mx-1 px-1 space-y-0.5">
                    {phaseNudds.map((n) => (
                      <button
                        key={n.id}
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          onNuddClick(n.id);
                          setPinnedPhase(null);
                        }}
                        className="w-full flex items-center gap-2 rounded-md px-2 py-1.5 text-left hover:bg-accent transition-colors"
                      >
                        <span className="font-mono text-[10.5px] font-semibold text-primary shrink-0">{n.id}</span>
                        <span className="text-[12px] text-foreground/90 flex-1 truncate">{n.summary}</span>
                        <span className={`inline-flex items-center rounded-full px-1.5 py-0.5 text-[10px] font-semibold tabular-nums border ${riskPillBorderClass(n.overallRiskLevel)}`}>
                          {n.riskPriority}·{n.overallRiskLevel}
                        </span>
                      </button>
                    ))}
                  </div>
                  {isPinned && (
                    <div className="mt-2 pt-2 border-t border-border/60 flex items-center justify-between text-[10px] text-muted-foreground">
                      <span>Pinned · click outside to close</span>
                      <button
                        type="button"
                        onClick={() => setPinnedPhase(null)}
                        className="text-primary hover:underline font-medium"
                      >
                        Unpin
                      </button>
                    </div>
                  )}
                  <span className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-2 h-2 rotate-45 bg-popover border-r border-b border-border" />
                </motion.div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};

type ScatterPoint = { x: number; y: number; color: string; id: string };
type ScatterRowMeta = {
  id: string;
  summary: string;
  status: NuddStatus;
  riskLevel: string;
  riskPriority: number;
};

const ScatterChart = ({
  points,
  title,
  onPointClick,
  maxScale = 3,
  meta,
}: {
  points: ScatterPoint[];
  title: string;
  onPointClick?: (id: string) => void;
  maxScale?: number;
  meta?: Record<string, ScatterRowMeta>;
}) => {
  // Streamlined risk matrix: Impact (X) × Probability (Y). Dashed red box highlights the high-risk zone.
  const VB = 360;
  const PAD_L = 56, PAD_T = 18, PAD_R = 18, PAD_B = 48;
  const plot = VB - PAD_L - PAD_R;
  const cell = plot / maxScale;

  const cx = (x: number) => PAD_L + (x - 0.5) * cell;
  const cy = (y: number) => PAD_T + (maxScale - y + 0.5) * cell;

  const positioned = points.map((p, i) => {
    const sameSpot = points.filter((q, j) => j < i && q.x === p.x && q.y === p.y).length;
    const angle = sameSpot * 2.4;
    const radius = sameSpot === 0 ? 0 : Math.min(sameSpot * 8, cell * 0.32);
    return {
      ...p,
      px: cx(p.x) + Math.cos(angle) * radius,
      py: cy(p.y) + Math.sin(angle) * radius,
    };
  });

  // High-risk zone: only the single top-right cell (impact = max, probability = max → score = maxScale²)
  const cellPad = 4;
  const zoneLeft = PAD_L + (maxScale - 1) * cell + cellPad;
  const zoneTop = PAD_T + cellPad;
  const zoneSize = cell - cellPad * 2;

  return (
    <div className="rounded-2xl bg-card p-5 shadow-sm border border-border/50 h-full flex flex-col">
      <div className="mb-3 flex items-start justify-between gap-3">
        <div>
          <h4 className="text-sm font-semibold tracking-tight text-foreground/90">{title}</h4>
          <p className="text-[10px] text-muted-foreground mt-0.5">Impact × Probability</p>
        </div>
        <span className="inline-flex items-center gap-1.5 text-[9px] font-medium text-muted-foreground shrink-0">
          <span className="w-2.5 h-2.5 border border-dashed border-destructive" /> High risk
        </span>
      </div>

      <div className="flex-1 min-h-[280px] flex items-center justify-center">
        <svg viewBox={`0 0 ${VB} ${VB}`} className="w-full h-auto max-h-[360px]" role="img" aria-label={title}>
          {/* Plot frame */}
          <line x1={PAD_L} y1={PAD_T} x2={PAD_L} y2={PAD_T + plot} stroke="hsl(var(--border))" strokeWidth={1} />
          <line x1={PAD_L} y1={PAD_T + plot} x2={PAD_L + plot} y2={PAD_T + plot} stroke="hsl(var(--border))" strokeWidth={1} />

          {/* High-risk dashed box (single top-right cell only) */}
          <rect
            x={zoneLeft}
            y={zoneTop}
            width={zoneSize}
            height={zoneSize}
            rx={6}
            fill="transparent"
            stroke="hsl(var(--destructive))"
            strokeWidth={1.5}
            strokeDasharray="6 4"
          />

          <text
            x={PAD_L + plot / 2}
            y={VB - 8}
            textAnchor="middle"
            fontSize="11"
            fontWeight="600"
            fill="hsl(var(--foreground))"
            opacity={0.75}
          >
            Impact →
          </text>
          <text
            x={14}
            y={PAD_T + plot / 2}
            textAnchor="middle"
            fontSize="11"
            fontWeight="600"
            fill="hsl(var(--foreground))"
            opacity={0.75}
            transform={`rotate(-90 14 ${PAD_T + plot / 2})`}
          >
            Probability →
          </text>

          {positioned.map((p) => (
            <g
              key={p.id}
              className="cursor-pointer"
              onClick={() => onPointClick?.(p.id)}
              role="button"
              tabIndex={0}
            >
              <circle cx={p.px} cy={p.py} r={10} fill={p.color} opacity={0.18} />
              <circle
                cx={p.px}
                cy={p.py}
                r={5.5}
                fill={p.color}
                stroke="hsl(var(--card))"
                strokeWidth={2}
              >
                <title>
                  {p.id} — {meta?.[p.id]?.summary ?? ""} (Impact {p.x}, Probability {p.y})
                </title>
              </circle>
            </g>
          ))}
        </svg>
      </div>
    </div>
  );
};

// ─── Track-banded wrapper for the phase distribution chart ──────────────────
// Renders a small track header (GOE/NPI in MDS Blue, SChM in MDS Navy) above
// a RiskByPhaseChart so the two stacked charts stay clearly distinguishable
// even though both use the same R/Y/G stack semantics.
const TrackBandedChart = ({
  track,
  data,
  nuddsByPhase,
  onNuddClick,
}: {
  track: "GOE_NPI" | "SCHM";
  data: PhaseRiskData[];
  nuddsByPhase: Record<string, PhaseNudd[]>;
  onNuddClick: (id: string) => void;
}) => {
  const tone = TRACK_TONE[track];
  const total = data.reduce((s, d) => s + d.low + d.medium + d.high, 0);
  const subtitle =
    track === "GOE_NPI"
      ? "Concept → Define → Plan → Qual → Pilot → Ramp"
      : "Concept → Define → Plan → Develop → Launch";
  return (
    <div className="rounded-2xl bg-card border border-border/50 shadow-sm overflow-hidden">
      <div className={`flex items-center justify-between gap-3 px-4 py-2 border-b border-border/50 ${tone.bg}`}>
        <div className="flex items-center gap-2 min-w-0">
          <span className={`inline-block w-1.5 h-4 rounded-sm ${tone.bar}`} aria-hidden />
          <span className={`text-[11px] font-bold uppercase tracking-wider ${tone.text}`}>
            {TRACK_LABEL[track]} Track
          </span>
          <span className="text-[11px] text-muted-foreground truncate hidden md:inline">
            · {subtitle}
          </span>
        </div>
        <span className="text-[11px] font-semibold text-muted-foreground tabular-nums shrink-0">
          {total} NUDD{total !== 1 ? "s" : ""}
        </span>
      </div>
      <div className="p-1">
        <RiskByPhaseChart
          data={data}
          title="Risk Distribution by Phase"
          nuddsByPhase={nuddsByPhase}
          onNuddClick={onNuddClick}
        />
      </div>
    </div>
  );
};


const SummaryKpis = ({
  data,
  scoring,
}: {
  data: { id: string; status: string }[];
  scoring: { id: string; overallRiskLevel: string; riskPriority: number }[];
}) => {
  const total = data.length;
  const openHold = data.filter((d) => d.status === "Open" || d.status === "On Hold");
  const openHoldIds = new Set(openHold.map((d) => d.id));
  const activeScoring = scoring.filter((s) => openHoldIds.has(s.id));
  const high = activeScoring.filter((s) => s.overallRiskLevel === "H").length;
  const medium = activeScoring.filter((s) => s.overallRiskLevel === "M").length;
  const low = activeScoring.filter((s) => s.overallRiskLevel === "L").length;

  const completed = total - openHold.length;

  // Donut math (completed ring around total)
  const RING_R = 30;
  const RING_C = 2 * Math.PI * RING_R;
  const activeFrac = total > 0 ? openHold.length / total : 0;
  const completedFrac = total > 0 ? completed / total : 0;

  const segments = [
    { key: "high", label: "High Risk", count: high, barClass: "bg-destructive", textClass: "text-destructive" },
    { key: "med", label: "Medium Risk", count: medium, barClass: "bg-amber-500", textClass: "text-amber-600 dark:text-amber-400" },
    { key: "low", label: "Low Risk", count: low, barClass: "bg-emerald-500", textClass: "text-emerald-600 dark:text-emerald-400" },
    { key: "done", label: "Completed", count: completed, barClass: "bg-primary", textClass: "text-primary" },
  ];
  const seg = (n: number) => (total > 0 ? (n / total) * 100 : 0);

  return (
    <div className="rounded-2xl border border-border/60 bg-gradient-to-br from-card via-card to-primary/[0.03] shadow-sm overflow-hidden">
      <div className="flex items-start justify-between gap-4 px-6 pt-4">
        <p className="text-[10px] font-semibold text-muted-foreground tracking-[0.14em] uppercase">Overview</p>
        <TooltipProvider>
          <div className="flex items-center gap-x-4 gap-y-1 flex-wrap text-[11px] justify-end">
            {segments.map((s) => (
              <div key={s.key} className="inline-flex items-center gap-1.5">
                <span className={`w-2 h-2 rounded-full ${s.barClass}`} />
                <span className="text-muted-foreground">{s.label}</span>
              </div>
            ))}
            <Tooltip>
              <TooltipTrigger asChild>
                <button
                  type="button"
                  aria-label="About these definitions"
                  className="text-muted-foreground/60 hover:text-foreground transition-colors focus:outline-none focus-visible:text-foreground"
                >
                  <Info className="w-3 h-3" />
                </button>
              </TooltipTrigger>
              <TooltipContent side="bottom" className="max-w-[240px] text-[11px] leading-snug">
                Definitions from Jira - to be confirmed.
              </TooltipContent>
            </Tooltip>
          </div>
        </TooltipProvider>
      </div>

      <div className="px-6 pb-5 pt-3 flex items-center gap-6 flex-wrap md:flex-nowrap">
        <div className="relative shrink-0">
          <svg width="84" height="84" viewBox="0 0 84 84" className="-rotate-90">
            <circle cx="42" cy="42" r={RING_R} fill="none" stroke="hsl(var(--muted))" strokeWidth="8" />
            <circle
              cx="42"
              cy="42"
              r={RING_R}
              fill="none"
              stroke="hsl(var(--primary))"
              strokeWidth="8"
              strokeLinecap="round"
              strokeDasharray={RING_C}
              strokeDashoffset={RING_C * (1 - completedFrac)}
              className="transition-all duration-700"
            />
          </svg>
          <div className="absolute inset-0 flex flex-col items-center justify-center">
            <span className="text-2xl font-bold tabular-nums text-foreground leading-none">{total}</span>
            <span className="text-[9px] font-semibold text-muted-foreground tracking-wider uppercase mt-0.5">Total</span>
          </div>
        </div>

        <div className="shrink-0 min-w-0">
          <p className="text-[15px] font-semibold text-foreground leading-snug">
            <span className="text-destructive tabular-nums">{openHold.length}</span> unresolved
            <span className="text-muted-foreground font-normal"> of </span>
            <span className="tabular-nums">{total}</span>
          </p>
          <p className="mt-0.5 text-[11px] text-muted-foreground">
            <span className="font-semibold text-foreground tabular-nums">{Math.round(activeFrac * 100)}%</span> require action
            <span className="mx-1.5 text-muted-foreground/40">·</span>
            <span className="font-semibold text-destructive tabular-nums">{high}</span> high risk
          </p>
        </div>

        {/* Segmented bar with inline counts */}
        <div className="flex-1 min-w-[260px] w-full">
          <div className="flex h-9 w-full rounded-lg overflow-hidden border border-border/60 bg-muted/30">
            {segments.map((s) =>
              s.count > 0 ? (
                <div
                  key={s.key}
                  className={`group relative ${s.barClass} flex items-center justify-center transition-all hover:brightness-110`}
                  style={{ width: `${seg(s.count)}%`, minWidth: s.count > 0 ? "28px" : 0 }}
                  title={`${s.label} · ${s.count}`}
                >
                  <span className="text-[11px] font-bold text-white tabular-nums drop-shadow-sm">
                    {s.count}
                  </span>
                  <div className="pointer-events-none absolute bottom-full mb-1.5 left-1/2 -translate-x-1/2 opacity-0 group-hover:opacity-100 transition-opacity z-20">
                    <div className="rounded-md border border-border/70 bg-popover shadow-md px-2 py-1 whitespace-nowrap">
                      <span className="text-[10px] font-semibold text-foreground">
                        {s.label}: <span className="tabular-nums">{s.count}</span>{" "}
                        <span className="text-muted-foreground">({Math.round(seg(s.count))}%)</span>
                      </span>
                    </div>
                  </div>
                </div>
              ) : null,
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

const tableHeadClass = "text-[10px] h-9 px-2 font-semibold text-muted-foreground/80 uppercase tracking-[0.06em]";
const tableCellClass = "text-[12.5px] py-2.5 px-2 align-middle";

// Color stripe (left edge) by overall risk level — quick visual scan.
const getRowAccentClass = (lvl: string): string => {
  if (lvl === "H") return "before:bg-destructive";
  if (lvl === "M") return "before:bg-amber-500";
  return "before:bg-emerald-500";
};
// Status dot color
const getStatusDotClass = (status: NuddStatus): string => {
  switch (status) {
    case "Open":      return "bg-indigo-500";
    case "On Hold":   return "bg-slate-500";
    case "Completed": return "bg-primary";
  }
};

const NuddsPage = () => {
  const location = useLocation();
  const state = location.state as { selectedProgram?: string; platform?: string; focusId?: string } | null;
  const programName = state?.selectedProgram || "AllPrograms";
  const [highlightId, setHighlightId] = useState<string | null>(null);
  const [selectedRow, setSelectedRow] = useState<typeof nuddsData[0] & typeof nuddsScoringData[0] | null>(null);
  const rowRefs = useRef<Record<string, HTMLTableRowElement | null>>({});
  const { role } = useRole();
  const showRiskVisuals = role === "Executive";
  const { filters: uFilters, updateFilter } = useUniversalFilters();
  const { filters: homeFilters } = useHomeFilters();

  // Honor incoming router state from external navigation (e.g. Schedule -> NUDDs deep link)
  useEffect(() => {
    if (state?.platform) {
      updateFilter("platform", state.platform);
    }
    if (state?.focusId) {
      setHighlightId(state.focusId);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);


  const phaseMatches = useCallback((itemPhase: string, filter: string) => {
    if (filter === "all") return true;
    return phaseMap(itemPhase) === phaseMap(filter);
  }, []);

  const filteredNudds = useMemo(() => {
    let result = filterItems(nuddsData, uFilters.lob, uFilters.platform);
    // Universal Org filter — all NUDD platforms are CSG; selecting ISG yields zero rows.
    if (uFilters.organization !== "all" && uFilters.organization !== "CSG") {
      result = [];
    }
    if (uFilters.phase !== "all") result = result.filter((d) => phaseMatches(d.goeOlpPhase, uFilters.phase));

    // Apply Home filter bar (multi-select)
    // Org filter — every Laptop platform is CSG for now, so selecting ISG yields zero rows.
    if (homeFilters.orgs.length > 0) {
      const PLATFORM_ORG_LOCAL: Record<string, "CSG" | "ISG"> = {
        "Laptop 1": "CSG", "Laptop 2": "CSG", "Laptop 3": "CSG", "Laptop 4": "CSG",
        "Laptop 5": "CSG", "Laptop 6": "CSG", "Laptop 7": "CSG",
      };
      result = result.filter((d) =>
        d.affectedPlatforms.split(",").map((p) => p.trim()).some(
          (p) => homeFilters.orgs.includes(PLATFORM_ORG_LOCAL[p] ?? "CSG")
        )
      );
    }
    if (homeFilters.lobs.length > 0) {
      result = result.filter((d) => homeFilters.lobs.some((lob) => d.affectedLOBs.includes(lob)));
    }
    if (homeFilters.platforms.length > 0) {
      result = result.filter((d) =>
        homeFilters.platforms.some((p) => d.affectedPlatforms.includes(p))
      );
    }
    if (homeFilters.phases.length > 0) {
      result = result.filter((d) =>
        homeFilters.phases.some((ph) => phaseMap(d.goeOlpPhase) === phaseMap(ph))
      );
    }
    return result;
  }, [uFilters.organization, uFilters.lob, uFilters.platform, uFilters.phase, homeFilters, phaseMatches]);

  const filteredScoring = useMemo(() => {
    const ids = new Set(filteredNudds.map((d) => d.id));
    return nuddsScoringData.filter((s) => ids.has(s.id));
  }, [filteredNudds]);

  const filteredPoints = useMemo(() => {
    const ids = new Set(filteredNudds.map((d) => d.id));
    return nuddsPoints.filter((p) => ids.has(p.id));
  }, [filteredNudds]);

  const phaseData = useMemo(() => {
    const items = filteredNudds as unknown as Record<string, string>[];
    const scoring = filteredNudds.map((d) => nuddsScoringData.find((s) => s.id === d.id)!).filter(Boolean);
    return computePhaseRiskData(items, scoring, "GOE_NPI");
  }, [filteredNudds]);

  const phaseDataSchm = useMemo(() => {
    const items = filteredNudds as unknown as Record<string, string>[];
    const scoring = filteredNudds.map((d) => nuddsScoringData.find((s) => s.id === d.id)!).filter(Boolean);
    return computePhaseRiskData(items, scoring, "SCHM");
  }, [filteredNudds]);

  useEffect(() => {
    if (highlightId && rowRefs.current[highlightId]) {
      rowRefs.current[highlightId]?.scrollIntoView({ behavior: "smooth", block: "center" });
    }
  }, [highlightId]);

  const merged = useMemo(() => {
    const rows = filteredNudds.map((info) => ({ ...info, ...nuddsScoringData.find((s) => s.id === info.id)! }));
    const levelRank: Record<string, number> = { H: 0, M: 1, L: 2 };
    return rows.sort((a, b) => {
      const lvl = (levelRank[a.overallRiskLevel] ?? 99) - (levelRank[b.overallRiskLevel] ?? 99);
      if (lvl !== 0) return lvl;
      return new Date(b.dateUpdated).getTime() - new Date(a.dateUpdated).getTime();
    });
  }, [filteredNudds]);

  const exportNudds = useCallback(() => {
    const safeName = programName.replace(/\s+/g, "_");
    const date = new Date().toISOString().slice(0, 10);
    const ws = XLSX.utils.json_to_sheet(merged);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "NUDDs");
    XLSX.writeFile(wb, `${safeName}_NUDDs_${date}.xlsx`);
  }, [merged, programName]);

  return (
    <div className="flex-1 flex flex-col overflow-auto">
      <StickyHomeFilterBar disabledFields={["statuses"]} />
      <div className="px-6 pt-6 pb-2 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <AlertTriangle className="w-5 h-5 text-primary" />
          <h1 className="text-[22px] font-extrabold tracking-tight text-foreground">NUDDs</h1>
        </div>
      </div>

      <div className="px-6 pb-4 space-y-4">
        <SummaryKpis data={filteredNudds} scoring={filteredScoring} />

        {showRiskVisuals && (() => {
          const scatterMeta: Record<string, ScatterRowMeta> = {};
          const nuddsByPhase: Record<string, PhaseNudd[]> = {};
          const nuddsByPhaseSchm: Record<string, PhaseNudd[]> = {};
          PHASES_ORDER.forEach((p) => { nuddsByPhase[p] = []; });
          SCHM_PHASES.forEach((p) => { nuddsByPhaseSchm[p] = []; });
          merged.forEach((r) => {
            scatterMeta[r.id] = {
              id: r.id,
              summary: r.summary,
              status: r.status,
              riskLevel: r.overallRiskLevel,
              riskPriority: r.riskPriority,
            };
            const ph = phaseMap(r.goeOlpPhase || "");
            const entry: PhaseNudd = {
              id: r.id,
              summary: r.summary,
              riskPriority: r.riskPriority,
              overallRiskLevel: r.overallRiskLevel,
            };
            if (nuddsByPhase[ph]) nuddsByPhase[ph].push(entry);
            const phSchm = goeToSchmPhase(ph);
            if (nuddsByPhaseSchm[phSchm]) nuddsByPhaseSchm[phSchm].push(entry);
          });
          // Sort each phase by risk priority desc so the most critical NUDDs surface first.
          Object.values(nuddsByPhase).forEach((arr) =>
            arr.sort((a, b) => b.riskPriority - a.riskPriority),
          );
          Object.values(nuddsByPhaseSchm).forEach((arr) =>
            arr.sort((a, b) => b.riskPriority - a.riskPriority),
          );
          const onNuddClick = (id: string) => {
            const row = merged.find((r) => r.id === id);
            if (row) setSelectedRow(row);
          };
          return (
            <div className="grid grid-cols-12 gap-4">
              <div className="col-span-4">
                <ScatterChart
                  points={filteredPoints}
                  title="Risk Matrix"
                  onPointClick={onNuddClick}
                  maxScale={3}
                  meta={scatterMeta}
                />
              </div>
              <div className="col-span-8 space-y-4">
                <TrackBandedChart
                  track="GOE_NPI"
                  data={phaseData}
                  nuddsByPhase={nuddsByPhase}
                  onNuddClick={onNuddClick}
                />
                <TrackBandedChart
                  track="SCHM"
                  data={phaseDataSchm}
                  nuddsByPhase={nuddsByPhaseSchm}
                  onNuddClick={onNuddClick}
                />
              </div>
            </div>
          );
        })()}

        <div className="flex items-center justify-end">
          <Button variant="outline" size="sm" className="h-8 text-xs gap-2" onClick={exportNudds}>
            <Download className="w-3.5 h-3.5" /> Export
          </Button>
        </div>

        <div className="rounded-2xl bg-card border border-border/60 shadow-sm overflow-hidden">
          <Table className="table-fixed w-full">
            <colgroup>
              <col style={{ width: "100px" }} />
              <col style={{ width: "120px" }} />
              <col />
              <col style={{ width: "92px" }} />
              <col style={{ width: "108px" }} />
              <col style={{ width: "92px" }} />
              <col style={{ width: "108px" }} />
              <col style={{ width: "104px" }} />
              <col style={{ width: "124px" }} />
            </colgroup>
            <TableHeader>
              <TableRow className="bg-muted/30 hover:bg-muted/30 border-b border-border/60">
                <TableHead className={`${tableHeadClass} pl-4 text-left`}>ID</TableHead>
                <TableHead className={`${tableHeadClass} text-left`}>Impacted LOB</TableHead>
                <TableHead className={`${tableHeadClass} text-left`}>Impacted Platform</TableHead>
                <TableHead className={`${tableHeadClass} text-left`}>Impact Score</TableHead>
                <TableHead className={`${tableHeadClass} text-left`}>Probability Score</TableHead>
                <TableHead className={`${tableHeadClass} text-left`}>Risk Score</TableHead>
                <TableHead className={`${tableHeadClass} text-left`}>Status</TableHead>
                <TableHead className={`${tableHeadClass} text-left`}>Date Created</TableHead>
                <TableHead className={`${tableHeadClass} text-left`}>Last Updated</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {merged.map((row) => (
                <TableRow
                  key={row.id}
                  ref={(el) => { rowRefs.current[row.id] = el; }}
                  className={`group cursor-pointer relative border-b border-border/40 last:border-b-0 transition-colors hover:bg-accent/40 ${highlightId === row.id ? "bg-primary/[0.06] ring-1 ring-inset ring-primary/30" : ""}`}
                  onClick={() => setSelectedRow(row)}
                >
                  <TableCell className={`${tableCellClass} font-mono text-[11.5px] font-semibold text-primary whitespace-nowrap pl-4 text-left`}>
                    <span className="inline-flex items-center gap-1">
                      {row.id}
                      <a
                        href={`https://jira.example.com/browse/${row.id}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        onClick={(e) => e.stopPropagation()}
                        className="opacity-0 group-hover:opacity-100 transition-opacity text-muted-foreground hover:text-primary"
                        aria-label={`Open ${row.id} in JIRA`}
                      >
                        <ExternalLink className="w-3 h-3" />
                      </a>
                    </span>
                  </TableCell>
                  <TableCell className={`${tableCellClass} text-left`}>
                    <div className="flex flex-wrap gap-1 justify-start">
                      {row.affectedLOBs.split(",").map((l) => l.trim()).filter(Boolean).map((l) => (
                        <span key={l} className="inline-flex items-center rounded px-1.5 py-0.5 text-[10px] font-medium bg-muted text-foreground/80 border border-border/40">{l}</span>
                      ))}
                    </div>
                  </TableCell>
                  <TableCell className={`${tableCellClass} text-left`}>
                    <div className="flex flex-wrap gap-1 justify-start">
                      {row.affectedPlatforms.split(",").map((p) => p.trim()).filter(Boolean).map((p) => (
                        <span key={p} className="inline-flex items-center rounded px-1.5 py-0.5 text-[10px] font-medium bg-muted text-foreground/80 border border-border/40 whitespace-nowrap">{p}</span>
                      ))}
                    </div>
                  </TableCell>
                  <TableCell className={`${tableCellClass} text-left`}>
                    <span className={`inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[10.5px] font-semibold tabular-nums ${getAxisScoreClass(row.riskImpact)}`}>
                      <span className="font-bold">{row.riskImpact}</span>
                      <span className="opacity-60">·</span>
                      <span>{row.riskImpact >= 3 ? "H" : row.riskImpact === 2 ? "M" : "L"}</span>
                    </span>
                  </TableCell>
                  <TableCell className={`${tableCellClass} text-left`}>
                    <span className={`inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[10.5px] font-semibold tabular-nums ${getAxisScoreClass(row.riskProbability)}`}>
                      <span className="font-bold">{row.riskProbability}</span>
                      <span className="opacity-60">·</span>
                      <span>{row.riskProbability >= 3 ? "H" : row.riskProbability === 2 ? "M" : "L"}</span>
                    </span>
                  </TableCell>
                  <TableCell className={`${tableCellClass} text-left`}>
                    <span className={`inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[10.5px] font-semibold tabular-nums ${getRiskPillClass(row.overallRiskLevel)}`}>
                      <span className="font-bold">{row.riskPriority}</span>
                      <span className="opacity-60">·</span>
                      <span>{row.overallRiskLevel}</span>
                    </span>
                  </TableCell>
                  <TableCell className={`${tableCellClass} text-left`}>
                    <span className={`inline-flex items-center gap-1.5 rounded-full px-2 py-0.5 text-[11px] font-semibold whitespace-nowrap ${getStatusBadgeClass(row.status)}`}>
                      <span className={`w-1.5 h-1.5 rounded-full ${getStatusDotClass(row.status)}`} />
                      {row.status}
                    </span>
                  </TableCell>
                  <TableCell className={`${tableCellClass} whitespace-nowrap text-muted-foreground text-[11.5px] tabular-nums`}>{formatJiraDate(row.dateCreated)}</TableCell>
                  <TableCell className={`${tableCellClass} whitespace-nowrap text-muted-foreground text-[11.5px] tabular-nums`}>{formatJiraDate(row.dateUpdated, true)}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </div>

      <Dialog open={!!selectedRow} onOpenChange={(v) => { if (!v) setSelectedRow(null); }}>
        <DialogContent className="max-w-4xl max-h-[88vh] overflow-auto p-0">
          {selectedRow && (() => {
            const r = selectedRow;
            const platforms = r.affectedPlatforms.split(",").map((p) => p.trim()).filter(Boolean);
            const lobs = r.affectedLOBs.split(",").map((l) => l.trim()).filter(Boolean);
            const created = r.dateCreated;
            const conceptEntry = offsetDate(created, 14);
            const conceptExit  = offsetDate(created, 60);
            const defineExit   = offsetDate(created, 110);
            const baDate       = offsetDate(created, 130);
            const ddsDate      = offsetDate(created, 150);
            const planExit     = offsetDate(created, 180);
            const rfdDate      = offsetDate(created, 210);
            const developExit  = offsetDate(created, 260);
            const rtsDate      = offsetDate(created, 290);
            const rtoDate      = offsetDate(created, 320);

            const SectionHeader = ({ children }: { children: React.ReactNode }) => (
              <h3 className="text-[11px] font-bold uppercase tracking-wider text-muted-foreground mb-2 pb-1 border-b border-border/50">{children}</h3>
            );
            const Field = ({ label, children }: { label: string; children: React.ReactNode }) => (
              <div className="grid grid-cols-[120px_1fr] gap-2 py-1 text-[12.5px]">
                <dt className="text-muted-foreground font-medium">{label}</dt>
                <dd className="text-foreground">{children}</dd>
              </div>
            );

            return (
              <>
                <div className="px-6 pt-6 pb-4 border-b border-border/60">
                  <div className="flex items-center gap-2 text-[11px] text-muted-foreground mb-1">
                    <span className="inline-flex items-center justify-center w-4 h-4 rounded bg-primary/10 text-primary text-[10px] font-bold">N</span>
                    <span>PMO-2025 / Project GRIT</span>
                    <span>/</span>
                    <span className="font-mono text-primary">{r.id}</span>
                  </div>
                  <DialogTitle className="text-lg font-semibold leading-tight">{r.summary}</DialogTitle>
                  <div className="flex items-center gap-2 mt-3">
                    <span className={`inline-flex items-center rounded-full px-2.5 py-1 text-[11px] font-semibold ${getStatusBadgeClass(r.status)}`}>{r.status}</span>
                    <Button size="sm" variant="outline" className="h-7 text-[11px]">DRAFT RTS ▾</Button>
                    <div className="flex-1" />
                    <Button size="sm" variant="ghost" className="h-7 text-[11px]">Email</Button>
                    <Button size="sm" variant="ghost" className="h-7 text-[11px]">Share</Button>
                    <Button size="sm" variant="ghost" className="h-7 text-[11px]">Export ▾</Button>
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-6 px-6 py-5">
                  <div className="col-span-2 space-y-6">
                    <section>
                      <SectionHeader>Details</SectionHeader>
                      <dl>
                        <Field label="Type">NUDD / Risk Item</Field>
                        <Field label="Resolution">Unresolved</Field>
                        <Field label="Labels">None</Field>
                        <Field label="Program">Project GRIT</Field>
                        <Field label="Program State">Active</Field>
                        <Field label="Domain">PC-Commercial</Field>
                        <Field label="GOE/OLP Phase">{r.goeOlpPhase}</Field>
                        <Field label="Impacted LOBs">
                          <div className="flex flex-wrap gap-1">
                            {lobs.map((l) => (
                              <span key={l} className="inline-flex items-center rounded px-1.5 py-0.5 text-[10px] font-medium bg-muted text-foreground/80 border border-border/40">{l}</span>
                            ))}
                          </div>
                        </Field>
                        <Field label="Impacted Platforms">
                          <div className="flex flex-wrap gap-1">
                            {platforms.map((p) => (
                              <span key={p} className="inline-flex items-center rounded px-1.5 py-0.5 text-[10px] font-medium bg-muted text-foreground/80 border border-border/40">{p}</span>
                            ))}
                          </div>
                        </Field>
                      </dl>
                    </section>

                    <section>
                      <SectionHeader>Risk</SectionHeader>
                      <dl>
                        <Field label="Impact Score"><span className="font-mono">{r.riskImpact}</span></Field>
                        <Field label="Probability Score"><span className="font-mono">{r.riskProbability}</span></Field>
                        <Field label="Risk Score">
                          <span className={`inline-flex items-center rounded-full px-2 py-0.5 text-[11px] font-semibold ${getRiskPillClass(r.overallRiskLevel)}`}>
                            {r.riskPriority} · {r.overallRiskLevel}
                          </span>
                        </Field>
                      </dl>
                      <div className="mt-3 space-y-3 text-[12.5px]">
                        <div>
                          <p className="text-[10px] font-bold text-muted-foreground uppercase tracking-wide mb-1">Description</p>
                          <p className="text-foreground/90 leading-relaxed">{r.detailedDescription}</p>
                        </div>
                        <div>
                          <p className="text-[10px] font-bold text-muted-foreground uppercase tracking-wide mb-1">Risk Events</p>
                          <p className="text-foreground/90 leading-relaxed">{r.riskEvents}</p>
                        </div>
                        <div>
                          <p className="text-[10px] font-bold text-muted-foreground uppercase tracking-wide mb-1">Risk Drivers</p>
                          <p className="text-foreground/90 leading-relaxed">{r.riskDrivers}</p>
                        </div>
                        <div>
                          <p className="text-[10px] font-bold text-muted-foreground uppercase tracking-wide mb-1">Mitigation Plan</p>
                          <p className="text-foreground/90 leading-relaxed">{r.mitigationPlan}</p>
                        </div>
                      </div>
                    </section>
                  </div>

                  <div className="space-y-6">
                    <section className="rounded-lg border border-border/60 p-3">
                      <SectionHeader>People</SectionHeader>
                      <dl>
                        <Field label="Assignee">{pickPerson(r.id, "assignee")}</Field>
                        <Field label="Reporter">{pickPerson(r.id, "reporter")}</Field>
                        <Field label="Program Mgr">{pickPerson(r.id, "pm")}</Field>
                        <Field label="Engineer">{pickPerson(r.id, "eng")}</Field>
                        <Field label="Quality Eng">{pickPerson(r.id, "qe")}</Field>
                        <Field label="Procurement">{pickPerson(r.id, "proc")}</Field>
                        <Field label="GOE / EDG">{pickPerson(r.id, "goe")}</Field>
                      </dl>
                    </section>

                    <section className="rounded-lg border border-border/60 p-3">
                      <SectionHeader>Dates</SectionHeader>
                      <dl>
                        <Field label="Created">{formatJiraDate(r.dateCreated)}</Field>
                        <Field label="Updated">{formatJiraDate(r.dateUpdated, true)}</Field>
                        <Field label="Concept Entry">{formatJiraDate(conceptEntry)}</Field>
                        <Field label="Concept Exit">{formatJiraDate(conceptExit)}</Field>
                        <Field label="Define Exit">{formatJiraDate(defineExit)}</Field>
                        <Field label="BA">{formatJiraDate(baDate)}</Field>
                        <Field label="DDS">{formatJiraDate(ddsDate)}</Field>
                        <Field label="Plan Exit">{formatJiraDate(planExit)}</Field>
                        <Field label="RFD">{formatJiraDate(rfdDate)}</Field>
                        <Field label="Develop Exit">{formatJiraDate(developExit)}</Field>
                        <Field label="RTS Target">{formatJiraDate(rtsDate)}</Field>
                        <Field label="RTO Target">{formatJiraDate(rtoDate)}</Field>
                      </dl>
                    </section>
                  </div>
                </div>

                <div className="px-6 py-3 border-t border-border/60 flex items-center justify-end">
                  <a
                    href={`https://jira.example.com/browse/${r.id}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1 text-[12.5px] font-medium text-primary hover:underline"
                  >
                    Open in JIRA <ExternalLink className="w-3.5 h-3.5" />
                  </a>
                </div>
              </>
            );
          })()}
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default NuddsPage;
