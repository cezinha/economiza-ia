import PhaseProgressBar from "@/components/dashboard/PhaseProgressBar";
import PhaseExitCriteria from "@/components/dashboard/PhaseExitCriteria";
import TaskSchedule from "@/components/dashboard/TaskSchedule";
import SupportingDocuments from "@/components/dashboard/SupportingDocuments";
import ReportExporter from "@/components/dashboard/ReportExporter";
import { motion } from "framer-motion";
import UniversalFilterBar from "@/components/dashboard/UniversalFilterBar";
import { usePlatform } from "@/contexts/PlatformContext";

const PhaseGatePage = () => {
  const { selectedPlatform } = usePlatform();
  const programName = selectedPlatform ?? "Laptop 1";

  return (
    <>
      <div className="px-6 pt-6 pb-0 flex justify-end gap-2">
        <UniversalFilterBar />
        <ReportExporter context="Phase Gate Exit" />
      </div>
      <motion.div
        initial={{ opacity: 0, y: 6 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3 }}
        className="px-6 pt-3 pb-0"
      >
        <PhaseProgressBar programName={programName} />
      </motion.div>
      <div className="px-6 pt-5 pb-2">
        <h2 className="text-sm font-bold text-foreground">Plan Phase Metrics</h2>
        <p className="text-xs text-muted-foreground mt-0.5">Phase-specific exit criteria and supporting documents — distinct from the Schedule view which tracks task-level progress</p>
      </div>
      <motion.div
        initial={{ opacity: 0, y: 6 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3, delay: 0.1 }}
        className="flex-1 px-6 pb-6 grid grid-cols-12 gap-5 min-h-0"
      >
        <div className="col-span-4">
          <PhaseExitCriteria programName={programName} />
        </div>
        <div className="col-span-4">
          <TaskSchedule />
        </div>
        <div className="col-span-4">
          <SupportingDocuments />
        </div>
      </motion.div>
    </>
  );
};

export default PhaseGatePage;
