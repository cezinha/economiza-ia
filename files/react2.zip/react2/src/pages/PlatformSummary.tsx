import { useMemo } from "react";
import { CalendarClock, AlertTriangle, DollarSign } from "lucide-react";
import {
  PieChart,
  Pie,
  Cell,
  ResponsiveContainer,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ComposedChart,
  Customized,
} from "recharts";
import ReportExporter from "@/components/dashboard/ReportExporter";
import { usePlatform } from "@/contexts/PlatformContext";
import { useUniversalFilters } from "@/contexts/UniversalFilterContext";
import UniversalFilterBar from "@/components/dashboard/UniversalFilterBar";
import { programSchedules, type ScheduleTask } from "@/data/scheduleData";

type FilteredTask = ScheduleTask & {
  platform: string;
  phase: string;
};

type CostSegmentKey = "cpus" | "electricalBom" | "mechanicalBom" | "vam";

type AxisLike = {
  scale: (value: number | string) => number;
  bandSize?: number;
};

const costSegments: { key: CostSegmentKey; label: string; color: string }[] = [
  { key: "cpus", label: "CPUs", color: "hsl(var(--primary))" },
  { key: "electricalBom", label: "Electrical BOM", color: "hsl(var(--chart-2))" },
  { key: "mechanicalBom", label: "Mechanical BOM", color: "hsl(var(--chart-3))" },
  { key: "vam", label: "VAM", color: "hsl(var(--chart-4))" },
];

const inferTaskCategory = (task: ScheduleTask): string => {
  if (task.category) return task.category;

  const value = `${task.name} ${task.dataSources?.join(" ") ?? ""}`.toLowerCase();

  if (/(upload|document|deck|prd|ard|edd|minutes|inputs)/.test(value)) return "Document Upload";
  if (/(team|formation|kick-off|kickoff|extended team|communication)/.test(value)) return "Team Formation";
  if (/(supplier|supply chain|odm|fulfillment|logistics|factory|material|ppap|resiliency)/.test(value)) return "Supply Chain";
  if (/(dfx|assessment|nudd|risk assessment|technology risk)/.test(value)) return "DFx Assessment";
  if (/(bom|cost|commodity|rfq|projection|cost bridge|fin)/.test(value)) return "BOM / Cost";
  if (/(build|readiness|itm|vm|gts|qual|pilot|ramp|launch|test enablement)/.test(value)) return "Build Readiness";
  if (/(quality|compliance|audit|qbr|score)/.test(value)) return "Quality / Compliance";
  return "Communication";
};

const matchesTaskFilter = (task: ScheduleTask, filter: string) => {
  if (filter === "all") return true;
  return inferTaskCategory(task) === filter;
};

const getRiskBucket = (task: FilteredTask) => {
  const taskName = task.name.toLowerCase();
  const highImpact =
    task.status === "late" ||
    task.owner.includes("SChM") ||
    /(cost|supplier|factory|fulfillment|quality|audit)/.test(taskName);
  const highFrequency =
    task.status !== "completed" ||
    task.owner.includes("GOE") ||
    /(upload|review|confirm|update|approve)/.test(taskName);

  if (highImpact && highFrequency) return "High Impact / High Freq";
  if (highImpact) return "High Impact / Low Freq";
  if (highFrequency) return "Low Impact / High Freq";
  return "Low Impact / Low Freq";
};

const getCostSegment = (task: FilteredTask): CostSegmentKey => {
  const taskName = task.name.toLowerCase();

  if (task.owner.includes("SChM") || /(bom|cost|commodity|rfq)/.test(taskName)) return "electricalBom";
  if (task.owner.includes("NPI") || /(build|pilot|qual|factory|test)/.test(taskName)) return "mechanicalBom";
  if (/(vam|value add|packaging|fulfillment|logistics)/.test(taskName)) return "vam";
  return "cpus";
};

const distributeTotal = (total: number, weights: Record<CostSegmentKey, number>) => {
  const entries = Object.entries(weights) as [CostSegmentKey, number][];
  const sum = entries.reduce((acc, [, value]) => acc + value, 0);

  if (sum === 0 || total === 0) {
    return {
      cpus: 0,
      electricalBom: 0,
      mechanicalBom: 0,
      vam: 0,
    } satisfies Record<CostSegmentKey, number>;
  }

  const distributed = {
    cpus: 0,
    electricalBom: 0,
    mechanicalBom: 0,
    vam: 0,
  } satisfies Record<CostSegmentKey, number>;

  let assigned = 0;
  entries.forEach(([key, value], index) => {
    const amount = index === entries.length - 1 ? total - assigned : Math.round((value / sum) * total);
    distributed[key] = amount;
    assigned += amount;
  });

  return distributed;
};

const currency = new Intl.NumberFormat("en-US", {
  style: "currency",
  currency: "USD",
  maximumFractionDigits: 0,
});

const PlatformSummary = () => {
  const { programs } = usePlatform();
  const { filters, matchesPlatform, matchesPhase } = useUniversalFilters();

  const filteredPlatforms = useMemo(
    () => programs.filter((program) => matchesPlatform(program)),
    [programs, matchesPlatform]
  );

  const filteredTasks = useMemo(() => {
    const tasks: FilteredTask[] = [];

    filteredPlatforms.forEach((platform) => {
      const phases = programSchedules[platform] ?? [];

      phases.forEach((phase) => {
        if (!matchesPhase(phase.name)) return;

        phase.milestones.forEach((milestone) => {
          milestone.tasks.forEach((task) => {
            if (!matchesTaskFilter(task, filters.task)) return;
            tasks.push({ ...task, platform, phase: phase.name });
          });
        });
      });
    });

    return tasks;
  }, [filteredPlatforms, matchesPhase, filters.task]);

  const title = filteredPlatforms.length === 1 ? `${filteredPlatforms[0]} Summary` : "Portfolio Summary";

  const currentPhase = useMemo(() => {
    if (filters.phase !== "all") return filters.phase;
    if (filteredTasks.length === 0) return "No matching tasks";

    const phaseCounts = filteredTasks.reduce<Record<string, number>>((acc, task) => {
      acc[task.phase] = (acc[task.phase] ?? 0) + 1;
      return acc;
    }, {});

    return Object.entries(phaseCounts).sort((a, b) => b[1] - a[1])[0]?.[0] ?? "No matching tasks";
  }, [filters.phase, filteredTasks]);

  const taskStatusData = useMemo(() => {
    const completed = filteredTasks.filter((task) => task.status === "completed").length;
    const onTrack = filteredTasks.filter((task) => task.status === "on-track").length;
    const late = filteredTasks.filter((task) => task.status === "late").length;
    const pending = filteredTasks.filter((task) => task.status === "pending").length;

    return [
      { name: "Done", value: completed, color: "hsl(var(--success))" },
      { name: "On Track", value: onTrack, color: "hsl(var(--warning))" },
      { name: "Major Delay", value: late, color: "hsl(var(--destructive))" },
      { name: "Pending", value: pending, color: "hsl(var(--muted-foreground) / 0.75)" },
    ];
  }, [filteredTasks]);

  const totalTasks = taskStatusData.reduce((sum, item) => sum + item.value, 0);
  const lateTasks = taskStatusData.find((item) => item.name === "Major Delay")?.value ?? 0;
  const latePercent = totalTasks > 0 ? Math.round((lateTasks / totalTasks) * 100) : 0;

  const riskData = useMemo(() => {
    const riskCounts = filteredTasks.reduce<Record<string, number>>((acc, task) => {
      const bucket = getRiskBucket(task);
      acc[bucket] = (acc[bucket] ?? 0) + 1;
      return acc;
    }, {});

    return [
      { name: "High Impact / High Freq", value: riskCounts["High Impact / High Freq"] ?? 0, color: "hsl(var(--destructive))" },
      { name: "High Impact / Low Freq", value: riskCounts["High Impact / Low Freq"] ?? 0, color: "hsl(var(--chart-3))" },
      { name: "Low Impact / High Freq", value: riskCounts["Low Impact / High Freq"] ?? 0, color: "hsl(var(--warning))" },
      { name: "Low Impact / Low Freq", value: riskCounts["Low Impact / Low Freq"] ?? 0, color: "hsl(var(--muted-foreground) / 0.75)" },
    ];
  }, [filteredTasks]);

  const totalRisks = riskData.reduce((sum, item) => sum + item.value, 0);
  const highImpactRisks = riskData[0].value + riskData[1].value;
  const riskPercent = totalRisks > 0 ? Math.round((highImpactRisks / totalRisks) * 100) : 0;

  const costChartData = useMemo(() => {
    if (filteredTasks.length === 0) {
      return [
        { name: "Target", cpus: 0, electricalBom: 0, mechanicalBom: 0, vam: 0, total: 0 },
        { name: "Projected", cpus: 0, electricalBom: 0, mechanicalBom: 0, vam: 0, total: 0 },
      ];
    }

    const segmentWeights = filteredTasks.reduce<Record<CostSegmentKey, number>>(
      (acc, task) => {
        acc[getCostSegment(task)] += 1;
        return acc;
      },
      { cpus: 2, electricalBom: 2, mechanicalBom: 2, vam: 1 }
    );

    const targetTotal = Math.round(filteredTasks.length * 7 + filteredPlatforms.length * 36);
    const delta = Math.round(
      filteredTasks.filter((task) => task.status === "late").length * 12 +
        filteredTasks.filter((task) => task.status === "pending").length * 4
    );

    const targetSegments = distributeTotal(targetTotal, segmentWeights);

    const projectedWeights = filteredTasks.reduce<Record<CostSegmentKey, number>>(
      (acc, task) => {
        acc[getCostSegment(task)] += task.status === "late" ? 3 : task.status === "pending" ? 2 : 1;
        return acc;
      },
      { cpus: 1, electricalBom: 1, mechanicalBom: 1, vam: 1 }
    );

    const projectedDeltaBySegment = distributeTotal(delta, projectedWeights);
    const projectedSegments = {
      cpus: targetSegments.cpus + projectedDeltaBySegment.cpus,
      electricalBom: targetSegments.electricalBom + projectedDeltaBySegment.electricalBom,
      mechanicalBom: targetSegments.mechanicalBom + projectedDeltaBySegment.mechanicalBom,
      vam: targetSegments.vam + projectedDeltaBySegment.vam,
    };

    return [
      {
        name: "Target",
        ...targetSegments,
        total: targetTotal,
      },
      {
        name: "Projected",
        ...projectedSegments,
        total: targetTotal + delta,
      },
    ];
  }, [filteredTasks, filteredPlatforms.length]);

  const targetTotal = costChartData[0]?.total ?? 0;
  const projectedTotal = costChartData[1]?.total ?? 0;
  const costDelta = projectedTotal - targetTotal;
  const costDeltaPercent = targetTotal > 0 ? ((costDelta / targetTotal) * 100).toFixed(1) : "0.0";

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-xl font-bold text-foreground">{title}</h1>
        <div className="flex items-center gap-2">
          <UniversalFilterBar />
          <ReportExporter context="Platform Summary" />
        </div>
      </div>

      <div className="flex flex-col lg:flex-row gap-5">
        <div className="lg:flex-1 bg-card border border-border rounded-lg p-5 space-y-4">
          <div className="flex items-center gap-2">
            <CalendarClock className="w-4 h-4 text-primary" />
            <h2 className="text-sm font-semibold text-foreground">Schedule Status</h2>
          </div>
          <p className="text-sm text-muted-foreground">
            Current Phase: <span className="font-semibold text-foreground">{currentPhase}</span>
          </p>
          <div className="flex flex-col items-center gap-3">
            <div className="w-36 h-36 relative">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie data={taskStatusData} cx="50%" cy="50%" innerRadius={38} outerRadius={58} dataKey="value" strokeWidth={2} stroke="hsl(var(--card))">
                    {taskStatusData.map((entry) => (
                      <Cell key={entry.name} fill={entry.color} />
                    ))}
                  </Pie>
                </PieChart>
              </ResponsiveContainer>
              <div className="absolute inset-0 flex flex-col items-center justify-center">
                <span className="text-lg font-bold text-destructive">{latePercent}%</span>
                <span className="text-[10px] text-muted-foreground">Late</span>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-x-4 gap-y-1.5 w-full">
              {taskStatusData.map((item) => (
                <div key={item.name} className="flex items-center gap-2 text-xs">
                  <span className="w-2.5 h-2.5 rounded-full shrink-0" style={{ backgroundColor: item.color }} />
                  <span className="text-muted-foreground">{item.name}</span>
                  <span className="font-semibold text-foreground ml-auto">{item.value}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="lg:flex-1 bg-card border border-border rounded-lg p-5 space-y-4">
          <div className="flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-warning" />
            <h2 className="text-sm font-semibold text-foreground">Open Risks</h2>
          </div>
          <div className="flex flex-col items-center gap-3">
            <div className="w-36 h-36 relative">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie data={riskData} cx="50%" cy="50%" innerRadius={38} outerRadius={58} dataKey="value" strokeWidth={2} stroke="hsl(var(--card))">
                    {riskData.map((entry) => (
                      <Cell key={entry.name} fill={entry.color} />
                    ))}
                  </Pie>
                </PieChart>
              </ResponsiveContainer>
              <div className="absolute inset-0 flex flex-col items-center justify-center">
                <span className="text-lg font-bold text-destructive">+{riskPercent}%</span>
                <span className="text-[10px] text-muted-foreground leading-tight text-center">high impact<br />risk load</span>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-x-4 gap-y-1.5 w-full">
              {riskData.map((item) => (
                <div key={item.name} className="flex items-center gap-2 text-xs">
                  <span className="w-2.5 h-2.5 rounded-full shrink-0" style={{ backgroundColor: item.color }} />
                  <span className="text-muted-foreground">{item.name}</span>
                  <span className="font-semibold text-foreground ml-auto">{item.value}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="lg:flex-1 bg-card border border-border rounded-lg p-5 space-y-4">
          <div className="flex items-center gap-2">
            <DollarSign className="w-4 h-4 text-success" />
            <h2 className="text-sm font-semibold text-foreground">Product Cost</h2>
          </div>
          <div className="flex items-center gap-3">
            <div className="bg-destructive/10 rounded-md px-3 py-2 flex flex-col items-center">
              <span className="text-lg font-bold text-destructive">+{costDeltaPercent}%</span>
              <span className="text-[10px] text-muted-foreground">Cost Delta</span>
            </div>
            <div className="flex-1 space-y-1">
              <div className="flex justify-between text-xs">
                <span className="text-muted-foreground">Target</span>
                <span className="font-medium text-foreground">{currency.format(targetTotal)}</span>
              </div>
              <div className="flex justify-between text-xs">
                <span className="text-muted-foreground">Projected</span>
                <span className="font-medium text-foreground">{currency.format(projectedTotal)}</span>
              </div>
              <div className="flex justify-between text-xs">
                <span className="text-muted-foreground">Variance</span>
                <span className="font-semibold text-destructive">{currency.format(costDelta)}</span>
              </div>
            </div>
          </div>
          <div className="h-48">
            <ResponsiveContainer width="100%" height="100%">
              <ComposedChart data={costChartData}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
                <XAxis dataKey="name" tick={{ fontSize: 11, fill: "hsl(var(--muted-foreground))" }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 11, fill: "hsl(var(--muted-foreground))" }} axisLine={false} tickLine={false} tickFormatter={(value: number) => `${currency.format(value)}`} domain={[0, "auto"]} />
                <Tooltip
                  formatter={(value: number, name: string) => [currency.format(value), name === "total" ? "Total" : costSegments.find((segment) => segment.key === name)?.label ?? name]}
                  contentStyle={{ fontSize: 12, borderRadius: 8, border: "1px solid hsl(var(--border))", background: "hsl(var(--card))" }}
                />
                {costSegments.map((segment, index) => (
                  <Bar
                    key={segment.key}
                    dataKey={segment.key}
                    stackId="cost"
                    fill={segment.color}
                    barSize={40}
                    radius={index === costSegments.length - 1 ? [4, 4, 0, 0] : [0, 0, 0, 0]}
                  />
                ))}
                <Customized
                  component={({ xAxisMap, yAxisMap }: { xAxisMap?: Record<string, AxisLike>; yAxisMap?: Record<string, AxisLike> }) => {
                    const xAxis = xAxisMap ? Object.values(xAxisMap)[0] : undefined;
                    const yAxis = yAxisMap ? Object.values(yAxisMap)[0] : undefined;

                    if (!xAxis || !yAxis || targetTotal === 0) return null;

                    const bandSize = xAxis.bandSize ?? 0;
                    const x1 = xAxis.scale("Target") + bandSize / 2 + 24;
                    const x2 = xAxis.scale("Projected") + bandSize / 2 - 24;
                    const midX = (x1 + x2) / 2;
                    const y1 = yAxis.scale(targetTotal);
                    const y2 = yAxis.scale(projectedTotal);
                    const midY = (y1 + y2) / 2;
                    const stroke = "hsl(var(--foreground))";

                    return (
                      <g>
                        <defs>
                          <marker id="arrowEnd" markerWidth="8" markerHeight="8" refX="6" refY="4" orient="auto">
                            <path d="M0,1 L6,4 L0,7" fill="none" stroke={stroke} strokeWidth="1.5" />
                          </marker>
                          <marker id="arrowStart" markerWidth="8" markerHeight="8" refX="2" refY="4" orient="auto">
                            <path d="M6,1 L0,4 L6,7" fill="none" stroke={stroke} strokeWidth="1.5" />
                          </marker>
                        </defs>
                        <line x1={x1} y1={y1} x2={midX} y2={y1} stroke={stroke} strokeWidth={1.5} strokeDasharray="4 2" />
                        <line x1={midX} y1={y2} x2={x2} y2={y2} stroke={stroke} strokeWidth={1.5} strokeDasharray="4 2" />
                        <line x1={midX} y1={y1 + 4} x2={midX} y2={y2 - 4} stroke={stroke} strokeWidth={1.5} markerEnd="url(#arrowEnd)" markerStart="url(#arrowStart)" />
                        <text x={midX + 8} y={midY} fill={stroke} fontSize={10} fontWeight={600} dominantBaseline="middle">
                          +{currency.format(costDelta)}
                        </text>
                      </g>
                    );
                  }}
                />
              </ComposedChart>
            </ResponsiveContainer>
          </div>
          <div className="flex flex-wrap gap-3 pt-1">
            {costSegments.map((segment) => (
              <div key={segment.key} className="flex items-center gap-1.5 text-xs">
                <span className="w-2.5 h-2.5 rounded-full shrink-0" style={{ backgroundColor: segment.color }} />
                <span className="text-muted-foreground">{segment.label}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default PlatformSummary;
