import { useState, useMemo, useEffect } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { AlertTriangle, Clock, CheckCircle2, User, ChevronRight, TrendingDown, MessageSquare, CalendarClock, DollarSign } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  PieChart, Pie, Cell, ResponsiveContainer, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ComposedChart, Customized,
} from "recharts";
import { programSchedules, type PhaseStatus, type TaskStatus, type ScheduleTask, type Phase } from "@/data/scheduleData";
import { cn } from "@/lib/utils";
import { usePlatform } from "@/contexts/PlatformContext";
import { useUniversalFilters, PLATFORM_LOB } from "@/contexts/UniversalFilterContext";
import UniversalFilterBar from "@/components/dashboard/UniversalFilterBar";

const computePhaseStatus = (phase: Phase): PhaseStatus => {
  const allTasks = phase.milestones.flatMap((m) => m.tasks);
  if (allTasks.length === 0) return "not-started";
  if (allTasks.every((t) => t.status === "completed")) return "on-track";
  if (allTasks.every((t) => t.status === "pending")) return "not-started";
  if (allTasks.some((t) => t.status === "late")) return "delayed";
  if (allTasks.some((t) => t.status === "on-track") && allTasks.some((t) => t.status === "pending")) return "at-risk";
  return "on-track";
};

const phaseTimeline: Record<string, { start: number; end: number }> = {
  Concept: { start: 0, end: 7 },
  Define: { start: 6, end: 14 },
  Plan: { start: 13, end: 22 },
  "Qual": { start: 21, end: 34 },
  "Pilot": { start: 33, end: 44 },
  "Ramp": { start: 43, end: 52 },
};

const TOTAL_WEEKS = 52;

type CostSegmentKey = "cpus" | "electricalBom" | "mechanicalBom" | "vam";
type AxisLike = { scale: (value: number | string) => number; bandSize?: number };

const costSegments: { key: CostSegmentKey; label: string; color: string }[] = [
  { key: "cpus", label: "CPUs", color: "hsl(var(--primary))" },
  { key: "electricalBom", label: "Electrical BOM", color: "hsl(var(--chart-2))" },
  { key: "mechanicalBom", label: "Mechanical BOM", color: "hsl(var(--chart-3))" },
  { key: "vam", label: "VAM", color: "hsl(var(--chart-4))" },
];

const getRiskBucket = (task: ScheduleTask) => {
  const taskName = task.name.toLowerCase();
  const highImpact = task.status === "late" || task.owner.includes("SChM") || /(cost|supplier|factory|fulfillment|quality|audit)/.test(taskName);
  const highFrequency = task.status !== "completed" || task.owner.includes("GOE") || /(upload|review|confirm|update|approve)/.test(taskName);
  if (highImpact && highFrequency) return "High Impact / High Freq";
  if (highImpact) return "High Impact / Low Freq";
  if (highFrequency) return "Low Impact / High Freq";
  return "Low Impact / Low Freq";
};

const getCostSegment = (task: ScheduleTask): CostSegmentKey => {
  const taskName = task.name.toLowerCase();
  if (task.owner.includes("SChM") || /(bom|cost|commodity|rfq)/.test(taskName)) return "electricalBom";
  if (task.owner.includes("NPI") || /(build|pilot|qual|factory|test)/.test(taskName)) return "mechanicalBom";
  if (/(vam|value add|packaging|fulfillment|logistics)/.test(taskName)) return "vam";
  return "cpus";
};

const distributeTotal = (total: number, weights: Record<CostSegmentKey, number>) => {
  const entries = Object.entries(weights) as [CostSegmentKey, number][];
  const sum = entries.reduce((acc, [, v]) => acc + v, 0);
  if (sum === 0 || total === 0) return { cpus: 0, electricalBom: 0, mechanicalBom: 0, vam: 0 };
  const distributed: Record<CostSegmentKey, number> = { cpus: 0, electricalBom: 0, mechanicalBom: 0, vam: 0 };
  let assigned = 0;
  entries.forEach(([key, value], i) => { const amt = i === entries.length - 1 ? total - assigned : Math.round((value / sum) * total); distributed[key] = amt; assigned += amt; });
  return distributed;
};

const currency = new Intl.NumberFormat("en-US", { style: "currency", currency: "USD", maximumFractionDigits: 0 });

const statusColors: Record<PhaseStatus, string> = {
  "on-track": "bg-green-500",
  "at-risk": "bg-yellow-500",
  delayed: "bg-red-500",
  "not-started": "bg-muted-foreground/40",
};

const statusLabels: Record<PhaseStatus, string> = {
  "on-track": "On Track",
  "at-risk": "At Risk w/ Mitigation",
  delayed: "At Risk w/ No Plan",
  "not-started": "Not Started",
};

const statusBadgeColors: Record<PhaseStatus, string> = {
  "on-track": "bg-green-100 text-green-800 border-green-200",
  "at-risk": "bg-yellow-100 text-yellow-800 border-yellow-200",
  delayed: "bg-red-100 text-red-800 border-red-200",
  "not-started": "bg-gray-100 text-gray-600 border-gray-200",
};

const taskStatusBadge: Record<TaskStatus, string> = {
  completed: "bg-green-100 text-green-800",
  "on-track": "bg-blue-100 text-blue-800",
  "at-risk": "bg-yellow-100 text-yellow-800",
  pending: "bg-gray-100 text-gray-600",
  late: "bg-red-100 text-red-800",
};

interface RiskItem {
  taskName: string;
  phaseName: string;
  milestoneName: string;
  owner: string;
  status: TaskStatus;
  riskReason: string;
}

const ProgramDetails = () => {

  const navigate = useNavigate();
  const location = useLocation();
  const { selectedPlatform, setSelectedPlatform, programs, isPortfolioView } = usePlatform();
  const { updateFilter } = useUniversalFilters();
  const state = location.state as { selectedProgram?: string } | null;
  const selectedProgram = selectedPlatform || state?.selectedProgram || "Laptop 1";
  const phases = programSchedules[selectedProgram] || programSchedules["Laptop 1"];

  // Sync filters to the selected program's LOB and platform on mount/change
  useEffect(() => {
    const programName = state?.selectedProgram || selectedPlatform;
    if (programName) {
      const lob = PLATFORM_LOB[programName];
      if (lob) {
        updateFilter("lob", lob);
      }
      updateFilter("platform", programName);
      setSelectedPlatform(programName);
    }
  }, []); // Only on mount

  const analytics = useMemo(() => {
    if (!phases) return null;

    let totalTasks = 0;
    let completedTasks = 0;
    let atRiskTasks = 0;
    let delayedTasks = 0;
    const riskItems: RiskItem[] = [];

    phases.forEach((phase) => {
      phase.milestones.forEach((milestone) => {
        milestone.tasks.forEach((task) => {
          totalTasks++;
          if (task.status === "completed") completedTasks++;
          if (task.status === "late") {
            delayedTasks++;
            riskItems.push({
              taskName: task.name,
              phaseName: phase.name,
              milestoneName: milestone.name,
              owner: task.assignee || task.owner,
              status: task.status,
              riskReason: `Task "${task.name}" is past due. Owner: ${task.assignee || task.owner}. This may impact downstream deliverables in ${phase.name}.`,
            });
          }
          if (task.status === "on-track" && phases.some(p => computePhaseStatus(p) === "at-risk")) {
            // Tasks in at-risk phases that aren't yet completed
          }
          if (task.status === "pending") {
            const phaseStatus = computePhaseStatus(phase);
            if (phaseStatus === "at-risk" || phaseStatus === "delayed") {
              atRiskTasks++;
              riskItems.push({
                taskName: task.name,
                phaseName: phase.name,
                milestoneName: milestone.name,
                owner: task.assignee || task.owner,
                status: task.status,
                riskReason: `Task "${task.name}" is pending in a ${phaseStatus} phase. Owned by ${task.assignee || task.owner}. Requires attention to prevent further delays.`,
              });
            }
          }
        });
      });
    });

    const phaseStatuses = phases.map((p) => ({
      name: p.name,
      status: computePhaseStatus(p),
      totalTasks: p.milestones.flatMap((m) => m.tasks).length,
      completedTasks: p.milestones.flatMap((m) => m.tasks).filter((t) => t.status === "completed").length,
      lateTasks: p.milestones.flatMap((m) => m.tasks).filter((t) => t.status === "late").length,
    }));

    const overallHealth: PhaseStatus = phaseStatuses.some((p) => p.status === "delayed")
      ? "delayed"
      : phaseStatuses.some((p) => p.status === "at-risk")
      ? "at-risk"
      : "on-track";

    return {
      totalTasks,
      completedTasks,
      atRiskTasks,
      delayedTasks,
      riskItems: riskItems.slice(0, 8),
      phaseStatuses,
      overallHealth,
      completionPct: totalTasks > 0 ? Math.round((completedTasks / totalTasks) * 100) : 0,
    };
  }, [phases]);

  // All tasks flat for charts
  const allTasks = useMemo(() => {
    if (!phases) return [];
    return phases.flatMap(phase => phase.milestones.flatMap(m => m.tasks));
  }, [phases]);

  const taskStatusData = useMemo(() => {
    const completed = allTasks.filter(t => t.status === "completed").length;
    const onTrack = allTasks.filter(t => t.status === "on-track").length;
    const late = allTasks.filter(t => t.status === "late").length;
    const pending = allTasks.filter(t => t.status === "pending").length;
    return [
      { name: "Done", value: completed, color: "hsl(var(--success))" },
      { name: "Minor Delay", value: onTrack, color: "hsl(var(--warning))" },
      { name: "Major Delay", value: late, color: "hsl(var(--destructive))" },
      { name: "Not Started", value: pending, color: "hsl(var(--muted-foreground) / 0.75)" },
    ];
  }, [allTasks]);

  const totalTaskCount = taskStatusData.reduce((s, i) => s + i.value, 0);
  const lateCount = taskStatusData.find(i => i.name === "Major Delay")?.value ?? 0;
  const latePct = totalTaskCount > 0 ? Math.round((lateCount / totalTaskCount) * 100) : 0;

  const riskChartData = useMemo(() => {
    const counts = allTasks.reduce<Record<string, number>>((acc, t) => {
      acc[getRiskBucket(t)] = (acc[getRiskBucket(t)] ?? 0) + 1;
      return acc;
    }, {});
    return [
      { name: "High Impact / High Freq", value: counts["High Impact / High Freq"] ?? 0, color: "hsl(var(--destructive))" },
      { name: "High Impact / Low Freq", value: counts["High Impact / Low Freq"] ?? 0, color: "hsl(var(--chart-3))" },
      { name: "Low Impact / High Freq", value: counts["Low Impact / High Freq"] ?? 0, color: "hsl(var(--warning))" },
      { name: "Low Impact / Low Freq", value: counts["Low Impact / Low Freq"] ?? 0, color: "hsl(var(--muted-foreground) / 0.75)" },
    ];
  }, [allTasks]);

  const totalRisks = riskChartData.reduce((s, i) => s + i.value, 0);
  const highImpactRisks = riskChartData[0].value + riskChartData[1].value;
  const riskPct = totalRisks > 0 ? Math.round((highImpactRisks / totalRisks) * 100) : 0;

  const costChartData = useMemo(() => {
    if (allTasks.length === 0) return [
      { name: "Target", cpus: 0, electricalBom: 0, mechanicalBom: 0, vam: 0, total: 0 },
      { name: "Projected", cpus: 0, electricalBom: 0, mechanicalBom: 0, vam: 0, total: 0 },
    ];
    const segW = allTasks.reduce<Record<CostSegmentKey, number>>((acc, t) => { acc[getCostSegment(t)] += 1; return acc; }, { cpus: 2, electricalBom: 2, mechanicalBom: 2, vam: 1 });
    const targetTotal = Math.round(allTasks.length * 7 + 36);
    const delta = Math.round(allTasks.filter(t => t.status === "late").length * 12 + allTasks.filter(t => t.status === "pending").length * 4);
    const targetSeg = distributeTotal(targetTotal, segW);
    const projW = allTasks.reduce<Record<CostSegmentKey, number>>((acc, t) => { acc[getCostSegment(t)] += t.status === "late" ? 3 : t.status === "pending" ? 2 : 1; return acc; }, { cpus: 1, electricalBom: 1, mechanicalBom: 1, vam: 1 });
    const projDelta = distributeTotal(delta, projW);
    return [
      { name: "Target", ...targetSeg, total: targetTotal },
      { name: "Projected", cpus: targetSeg.cpus + projDelta.cpus, electricalBom: targetSeg.electricalBom + projDelta.electricalBom, mechanicalBom: targetSeg.mechanicalBom + projDelta.mechanicalBom, vam: targetSeg.vam + projDelta.vam, total: targetTotal + delta },
    ];
  }, [allTasks]);

  const targetCost = costChartData[0]?.total ?? 0;
  const projectedCost = costChartData[1]?.total ?? 0;
  const costDelta = projectedCost - targetCost;
  const costDeltaPct = targetCost > 0 ? ((costDelta / targetCost) * 100).toFixed(1) : "0.0";

  // Current phase for schedule status label
  const currentPhaseLabel = useMemo(() => {
    if (!analytics) return "";
    const active = analytics.phaseStatuses.find(p => p.status !== "not-started" && p.completedTasks < p.totalTasks);
    return active?.name ?? analytics.phaseStatuses[analytics.phaseStatuses.length - 1]?.name ?? "";
  }, [analytics]);

  if (!phases || !analytics) {
    return (
      <div className="flex-1 flex items-center justify-center p-8">
        <div className="text-center text-muted-foreground">
          <AlertTriangle className="w-10 h-10 mx-auto mb-3 opacity-40" />
          <p className="text-sm font-medium">No program data available</p>
        </div>
      </div>
    );
  }

  // Portfolio mode: show comparison grid of all platforms
  if (isPortfolioView) {
    const platformData = programs.map((prog) => {
      const p = programSchedules[prog] || [];
      let total = 0, completed = 0, delayed = 0;
      p.forEach(phase => phase.milestones.forEach(m => m.tasks.forEach(t => {
        total++;
        if (t.status === "completed") completed++;
        if (t.status === "late") delayed++;
      })));
      const pct = total > 0 ? Math.round((completed / total) * 100) : 0;
      const health: PhaseStatus = delayed > 3 ? "delayed" : delayed > 0 ? "at-risk" : completed === total && total > 0 ? "on-track" : "not-started";
      return { name: prog, total, completed, delayed, pct, health };
    });

    return (
      <div className="flex-1 overflow-auto p-6 space-y-5">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-xl font-bold text-foreground">Portfolio Overview</h1>
            <p className="text-xs text-muted-foreground mt-0.5">Cross-platform program health comparison</p>
          </div>
          <UniversalFilterBar />
        </div>
        <div className="grid grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3">
          {platformData.map(pd => (
            <Card key={pd.name} className="border cursor-pointer hover:shadow-md transition-shadow" onClick={() => { navigate("/program-details"); }}>
              <CardContent className="p-4 space-y-2">
                <div className="flex items-center justify-between">
                  <p className="text-sm font-semibold text-foreground">{pd.name}</p>
                  <Badge variant="outline" className={cn("text-[9px] border", statusBadgeColors[pd.health])}>
                    {statusLabels[pd.health]}
                  </Badge>
                </div>
                <div className="flex items-center gap-3 text-xs text-muted-foreground">
                  <span>{pd.completed}/{pd.total} tasks</span>
                  {pd.delayed > 0 && <span className="text-red-600 font-medium">{pd.delayed} delayed</span>}
                </div>
                <div className="w-full h-1.5 bg-muted rounded-full overflow-hidden">
                  <div className={cn("h-full rounded-full", pd.health === "on-track" ? "bg-green-500" : pd.health === "at-risk" ? "bg-yellow-500" : pd.health === "delayed" ? "bg-red-500" : "bg-muted-foreground/40")} style={{ width: `${pd.pct}%` }} />
                </div>
                <p className="text-[10px] text-muted-foreground">{pd.pct}% complete</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  const handlePhaseClick = (phaseName: string) => {
    navigate("/schedule", { state: { selectedProgram, expandedPhase: phaseName } });
  };

  return (
    <div className="flex-1 overflow-auto p-6 space-y-5">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold text-foreground">{selectedProgram}</h1>
          <p className="text-xs text-muted-foreground mt-0.5">Executive Program Summary</p>
        </div>
        <div className="flex items-center gap-2">
          <UniversalFilterBar />
          <Badge className={cn("text-xs px-3 py-1 border", statusBadgeColors[analytics.overallHealth])}>
            {statusLabels[analytics.overallHealth]}
          </Badge>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-4 gap-3">
        <Card className="border">
          <CardContent className="p-4 flex items-center gap-3">
            <div className="w-9 h-9 rounded-md bg-primary/10 flex items-center justify-center">
              <CheckCircle2 className="w-4.5 h-4.5 text-primary" />
            </div>
            <div>
              <p className="text-[10px] text-muted-foreground uppercase tracking-wider font-medium">Completion</p>
              <p className="text-lg font-bold text-foreground">{analytics.completionPct}%</p>
            </div>
          </CardContent>
        </Card>
        <Card className="border">
          <CardContent className="p-4 flex items-center gap-3">
            <div className="w-9 h-9 rounded-md bg-green-100 flex items-center justify-center">
              <CheckCircle2 className="w-4.5 h-4.5 text-green-600" />
            </div>
            <div>
              <p className="text-[10px] text-muted-foreground uppercase tracking-wider font-medium">Completed</p>
              <p className="text-lg font-bold text-foreground">{analytics.completedTasks}<span className="text-xs text-muted-foreground font-normal">/{analytics.totalTasks}</span></p>
            </div>
          </CardContent>
        </Card>
        <Card className="border">
          <CardContent className="p-4 flex items-center gap-3">
            <div className="w-9 h-9 rounded-md bg-yellow-100 flex items-center justify-center">
              <Clock className="w-4.5 h-4.5 text-yellow-600" />
            </div>
            <div>
              <p className="text-[10px] text-muted-foreground uppercase tracking-wider font-medium">At Risk</p>
              <p className="text-lg font-bold text-foreground">{analytics.atRiskTasks}</p>
            </div>
          </CardContent>
        </Card>
        <Card className="border">
          <CardContent className="p-4 flex items-center gap-3">
            <div className="w-9 h-9 rounded-md bg-red-100 flex items-center justify-center">
              <AlertTriangle className="w-4.5 h-4.5 text-red-600" />
            </div>
            <div>
              <p className="text-[10px] text-muted-foreground uppercase tracking-wider font-medium">Delayed</p>
              <p className="text-lg font-bold text-foreground">{analytics.delayedTasks}</p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Executive Visual Cards */}
      <div className="flex flex-col lg:flex-row gap-5">
        {/* Schedule Status */}
        <div className="lg:flex-1 bg-card border border-border rounded-lg p-5 space-y-4">
          <div className="flex items-center gap-2">
            <CalendarClock className="w-4 h-4 text-primary" />
            <h2 className="text-sm font-semibold text-foreground">Schedule Status</h2>
          </div>
          <p className="text-sm text-muted-foreground">Current Phase: <span className="font-semibold text-foreground">{currentPhaseLabel}</span></p>
          <div className="flex flex-col items-center gap-3">
            <div className="w-36 h-36 relative">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie data={taskStatusData} cx="50%" cy="50%" innerRadius={38} outerRadius={58} dataKey="value" strokeWidth={2} stroke="hsl(var(--card))">
                    {taskStatusData.map(e => <Cell key={e.name} fill={e.color} />)}
                  </Pie>
                </PieChart>
              </ResponsiveContainer>
              <div className="absolute inset-0 flex flex-col items-center justify-center">
                <span className="text-lg font-bold text-destructive">{latePct}%</span>
                <span className="text-[10px] text-muted-foreground">Late</span>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-x-4 gap-y-1.5 w-full">
              {taskStatusData.map(item => (
                <div key={item.name} className="flex items-center gap-2 text-xs">
                  <span className="w-2.5 h-2.5 rounded-full shrink-0" style={{ backgroundColor: item.color }} />
                  <span className="text-muted-foreground">{item.name}</span>
                  <span className="font-semibold text-foreground ml-auto">{item.value}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Open Risks */}
        <div className="lg:flex-1 bg-card border border-border rounded-lg p-5 space-y-4">
          <div className="flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-warning" />
            <h2 className="text-sm font-semibold text-foreground">Open Risks</h2>
          </div>
          <div className="flex flex-col items-center gap-3">
            <div className="w-36 h-36 relative">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie data={riskChartData} cx="50%" cy="50%" innerRadius={38} outerRadius={58} dataKey="value" strokeWidth={2} stroke="hsl(var(--card))">
                    {riskChartData.map(e => <Cell key={e.name} fill={e.color} />)}
                  </Pie>
                </PieChart>
              </ResponsiveContainer>
              <div className="absolute inset-0 flex flex-col items-center justify-center">
                <span className="text-lg font-bold text-destructive">+{riskPct}%</span>
                <span className="text-[10px] text-muted-foreground leading-tight text-center">vs similar<br />programs</span>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-x-4 gap-y-1.5 w-full">
              {riskChartData.map(item => (
                <div key={item.name} className="flex items-center gap-2 text-xs">
                  <span className="w-2.5 h-2.5 rounded-full shrink-0" style={{ backgroundColor: item.color }} />
                  <span className="text-muted-foreground">{item.name}</span>
                  <span className="font-semibold text-foreground ml-auto">{item.value}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Product Cost */}
        <div className="lg:flex-1 bg-card border border-border rounded-lg p-5 space-y-4">
          <div className="flex items-center gap-2">
            <DollarSign className="w-4 h-4 text-success" />
            <h2 className="text-sm font-semibold text-foreground">Product Cost</h2>
          </div>
          <div className="flex items-center gap-3">
            <div className="bg-destructive/10 rounded-md px-3 py-2 flex flex-col items-center">
              <span className="text-lg font-bold text-destructive">+{costDeltaPct}%</span>
              <span className="text-[10px] text-muted-foreground">Cost Delta</span>
            </div>
            <div className="flex-1 space-y-1">
              <div className="flex justify-between text-xs"><span className="text-muted-foreground">Target</span><span className="font-medium text-foreground">{currency.format(targetCost)}</span></div>
              <div className="flex justify-between text-xs"><span className="text-muted-foreground">Projected</span><span className="font-medium text-foreground">{currency.format(projectedCost)}</span></div>
              <div className="flex justify-between text-xs"><span className="text-muted-foreground">Variance</span><span className="font-semibold text-destructive">{currency.format(costDelta)}</span></div>
            </div>
          </div>
          <div className="h-48">
            <ResponsiveContainer width="100%" height="100%">
              <ComposedChart data={costChartData}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
                <XAxis dataKey="name" tick={{ fontSize: 11, fill: "hsl(var(--muted-foreground))" }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 11, fill: "hsl(var(--muted-foreground))" }} axisLine={false} tickLine={false} tickFormatter={(v: number) => currency.format(v)} domain={[0, "auto"]} />
                <Tooltip formatter={(v: number, name: string) => [currency.format(v), costSegments.find(s => s.key === name)?.label ?? name]} contentStyle={{ fontSize: 12, borderRadius: 8, border: "1px solid hsl(var(--border))", background: "hsl(var(--card))" }} />
                {costSegments.map((seg, i) => (
                  <Bar key={seg.key} dataKey={seg.key} stackId="cost" fill={seg.color} barSize={40} radius={i === costSegments.length - 1 ? [4, 4, 0, 0] : [0, 0, 0, 0]} />
                ))}
                <Customized component={({ xAxisMap, yAxisMap }: { xAxisMap?: Record<string, AxisLike>; yAxisMap?: Record<string, AxisLike> }) => {
                  const xAxis = xAxisMap ? Object.values(xAxisMap)[0] : undefined;
                  const yAxis = yAxisMap ? Object.values(yAxisMap)[0] : undefined;
                  if (!xAxis || !yAxis || targetCost === 0) return null;
                  const bandSize = xAxis.bandSize ?? 0;
                  const x1 = xAxis.scale("Target") + bandSize / 2 + 24;
                  const x2 = xAxis.scale("Projected") + bandSize / 2 - 24;
                  const midX = (x1 + x2) / 2;
                  const y1 = yAxis.scale(targetCost);
                  const y2 = yAxis.scale(projectedCost);
                  const midY = (y1 + y2) / 2;
                  const stroke = "hsl(var(--foreground))";
                  return (
                    <g>
                      <defs>
                        <marker id="arrowEndPD" markerWidth="8" markerHeight="8" refX="6" refY="4" orient="auto"><path d="M0,1 L6,4 L0,7" fill="none" stroke={stroke} strokeWidth="1.5" /></marker>
                        <marker id="arrowStartPD" markerWidth="8" markerHeight="8" refX="2" refY="4" orient="auto"><path d="M6,1 L0,4 L6,7" fill="none" stroke={stroke} strokeWidth="1.5" /></marker>
                      </defs>
                      <line x1={x1} y1={y1} x2={midX} y2={y1} stroke={stroke} strokeWidth={1.5} strokeDasharray="4 2" />
                      <line x1={midX} y1={y2} x2={x2} y2={y2} stroke={stroke} strokeWidth={1.5} strokeDasharray="4 2" />
                      <line x1={midX} y1={y1 + 4} x2={midX} y2={y2 - 4} stroke={stroke} strokeWidth={1.5} markerEnd="url(#arrowEndPD)" markerStart="url(#arrowStartPD)" />
                      <text x={midX + 8} y={midY} fill={stroke} fontSize={10} fontWeight={600} dominantBaseline="middle">+{currency.format(costDelta)}</text>
                    </g>
                  );
                }} />
              </ComposedChart>
            </ResponsiveContainer>
          </div>
          <div className="flex flex-wrap gap-3 pt-1">
            {costSegments.map(seg => (
              <div key={seg.key} className="flex items-center gap-1.5 text-xs">
                <span className="w-2.5 h-2.5 rounded-full shrink-0" style={{ backgroundColor: seg.color }} />
                <span className="text-muted-foreground">{seg.label}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      <Card className="border">
        <CardHeader className="pb-2 pt-4 px-5">
          <CardTitle className="text-sm font-semibold">Program Schedule</CardTitle>
          <p className="text-[10px] text-muted-foreground">Click a phase to view detailed schedule</p>
        </CardHeader>
        <CardContent className="px-5 pb-4">
          <div className="space-y-1.5">
            {analytics.phaseStatuses.map((phase) => {
              const timeline = phaseTimeline[phase.name];
              const leftPct = timeline ? (timeline.start / TOTAL_WEEKS) * 100 : 0;
              const widthPct = timeline ? ((timeline.end - timeline.start) / TOTAL_WEEKS) * 100 : 20;
              const progressPct = phase.totalTasks > 0 ? (phase.completedTasks / phase.totalTasks) * 100 : 0;

              return (
                <div
                  key={phase.name}
                  className="flex items-center h-10 cursor-pointer group hover:bg-accent/50 rounded-md px-2 -mx-2 transition-colors"
                  onClick={() => handlePhaseClick(phase.name)}
                >
                  <div className="w-[140px] shrink-0 flex items-center gap-2">
                    <span className={cn("w-2 h-2 rounded-full shrink-0", statusColors[phase.status])} />
                    <span className="text-xs font-medium text-foreground truncate group-hover:text-primary transition-colors">
                      {phase.name}
                    </span>
                  </div>
                  <div className="flex-1 relative h-6 flex items-center min-w-0">
                    <div
                      className={cn(
                        "absolute h-5 rounded-sm overflow-hidden border",
                        phase.status === "delayed" ? "border-red-300 bg-red-50" :
                        phase.status === "at-risk" ? "border-yellow-300 bg-yellow-50" :
                        phase.status === "on-track" ? "border-green-300 bg-green-50" :
                        "border-border bg-muted/30"
                      )}
                      style={{ left: `${leftPct}%`, width: `${widthPct}%` }}
                    >
                      <div
                        className={cn("h-full transition-all", statusColors[phase.status], "opacity-60")}
                        style={{ width: `${progressPct}%` }}
                      />
                      <span className="absolute inset-0 flex items-center justify-center text-[9px] font-semibold text-foreground/70">
                        {phase.completedTasks}/{phase.totalTasks}
                      </span>
                    </div>
                  </div>
                  <ChevronRight className="w-3.5 h-3.5 text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity shrink-0 ml-1" />
                </div>
              );
            })}
          </div>
          {/* Timeline axis */}
          <div className="flex mt-2 px-2 -mx-2">
            <div className="w-[140px] shrink-0" />
            <div className="flex-1 flex min-w-0">
              {["Q1", "Q2", "Q3", "Q4"].map((q) => (
                <div key={q} className="flex-1 text-center">
                  <span className="text-[9px] text-muted-foreground font-medium">{q}</span>
                </div>
              ))}
            </div>
            <div className="w-[18px] shrink-0" />
          </div>
        </CardContent>
      </Card>

      {/* Leading Indicators & Risk Summary */}
      <div className="grid grid-cols-2 gap-4">
        {/* Phase Health Summary */}
        <Card className="border">
          <CardHeader className="pb-2 pt-4 px-5">
            <CardTitle className="text-sm font-semibold flex items-center gap-2">
              <TrendingDown className="w-4 h-4 text-muted-foreground" />
              Leading Indicators
            </CardTitle>
          </CardHeader>
          <CardContent className="px-5 pb-4 space-y-2">
            {analytics.phaseStatuses.map((phase) => (
              <div key={phase.name} className="flex items-center justify-between py-1.5 border-b border-border/50 last:border-0">
                <div className="flex items-center gap-2">
                  <span className={cn("w-1.5 h-6 rounded-full", statusColors[phase.status])} />
                  <div>
                    <p className="text-xs font-medium text-foreground">{phase.name}</p>
                    <p className="text-[10px] text-muted-foreground">
                      {phase.completedTasks}/{phase.totalTasks} tasks complete
                      {phase.lateTasks > 0 && <span className="text-red-600 font-medium"> · {phase.lateTasks} late</span>}
                    </p>
                  </div>
                </div>
                <Badge variant="outline" className={cn("text-[10px] border", statusBadgeColors[phase.status])}>
                  {statusLabels[phase.status]}
                </Badge>
              </div>
            ))}
          </CardContent>
        </Card>

        {/* Timeline Risks */}
        <Card className="border">
          <CardHeader className="pb-2 pt-4 px-5">
            <CardTitle className="text-sm font-semibold flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-red-500" />
              Timeline Risk Summary
            </CardTitle>
            <p className="text-[10px] text-muted-foreground">Tasks requiring immediate attention</p>
          </CardHeader>
          <CardContent className="px-5 pb-4">
            {analytics.riskItems.length === 0 ? (
              <div className="text-center py-6">
                <CheckCircle2 className="w-8 h-8 text-green-500 mx-auto mb-2 opacity-60" />
                <p className="text-xs text-muted-foreground">No critical risks identified</p>
              </div>
            ) : (
              <div className="space-y-2 max-h-[280px] overflow-y-auto">
                {analytics.riskItems.map((item, i) => (
                  <div key={i} className="p-2.5 rounded-md border border-border bg-muted/20 space-y-1">
                    <div className="flex items-start justify-between gap-2">
                      <p className="text-[11px] font-medium text-foreground leading-tight">{item.taskName}</p>
                      <Badge className={cn("text-[9px] shrink-0 border-0", taskStatusBadge[item.status])}>
                        {item.status === "late" ? "Delayed" : "Pending"}
                      </Badge>
                    </div>
                    <div className="flex items-center gap-3 text-[10px] text-muted-foreground">
                      <span className="flex items-center gap-1">
                        <User className="w-3 h-3" />
                        {item.owner}
                      </span>
                      <span>{item.phaseName} › {item.milestoneName}</span>
                    </div>
                    <p className="text-[10px] text-muted-foreground/80 leading-relaxed flex items-start gap-1">
                      <MessageSquare className="w-3 h-3 shrink-0 mt-0.5" />
                      {item.riskReason}
                    </p>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default ProgramDetails;
