import { useEffect, useMemo, useRef, useState } from "react";
import { useLocation } from "react-router-dom";
import { Calendar, ChevronDown, ChevronRight } from "lucide-react";
import { usePlatform } from "@/contexts/PlatformContext";
import { useUniversalFilters, PLATFORM_LOB, PLATFORM_ORG } from "@/contexts/UniversalFilterContext";
import { useHomeFilters } from "@/contexts/HomeFilterContext";
import ReportExporter from "@/components/dashboard/ReportExporter";
import { defaultTaskPageFilters, type TaskPageFilterState } from "@/components/dashboard/TaskPageFilters";
import PortfolioScheduleGantt from "@/components/dashboard/PortfolioScheduleGantt";
import PlatformScheduleDetail from "@/components/dashboard/PlatformScheduleDetail";
import { StickyHomeFilterBar } from "@/components/dashboard/HomeFilterBar";
import { getAllOwnerNames } from "@/data/taskParticipants";
import { TRACK_LABEL, TRACK_TONE } from "@/data/phaseTracks";
import { cn } from "@/lib/utils";

const Schedule = () => {
  const location = useLocation();
  const { setSelectedPlatform } = usePlatform();
  const { updateFilter } = useUniversalFilters();
  const { filters: homeFilters, setFilters: setHomeFilters } = useHomeFilters();
  const state = location.state as { selectedProgram?: string } | null;
  const incomingProgram = state?.selectedProgram;
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (incomingProgram) {
      setSelectedPlatform(incomingProgram);
      const lob = PLATFORM_LOB[incomingProgram];
      const org = PLATFORM_ORG[incomingProgram];
      // Mirror the platform selection into the StickyHomeFilterBar so the
      // result is identical to filtering for this platform directly on /schedule.
      setHomeFilters({
        ...homeFilters,
        orgs: org ? [org] : [],
        lobs: lob ? [lob] : [],
        platforms: [incomingProgram],
      });
      if (lob) {
        updateFilter("lob", lob);
        setTimeout(() => updateFilter("platform", incomingProgram), 0);
      }
      setTimeout(() => {
        const el = containerRef.current?.querySelector(`[data-platform-row="${incomingProgram}"]`);
        el?.scrollIntoView({ behavior: "smooth", block: "start" });
      }, 250);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Derive task-list filters from the unified Home filter bar so Function / Owner / Task
  // entered at the top of the page filter the expanded task rows below.
  const pageFilters = useMemo<TaskPageFilterState>(() => {
    // Owner: each chip is matched as a substring (case-insensitive) against the
    // canonical owner pool. Anything matching is added to primaryOwners (exact match).
    const ownerNames = getAllOwnerNames();
    const matchedOwners = homeFilters.ownerSearch.flatMap((q) => {
      const lq = q.trim().toLowerCase();
      if (!lq) return [];
      return ownerNames.filter((n) => n.toLowerCase().includes(lq));
    });
    const uniqueOwners = Array.from(new Set(matchedOwners));
    const taskQueries = homeFilters.taskSearch.map((t) => t.trim()).filter(Boolean);
    return {
      ...defaultTaskPageFilters,
      phases: homeFilters.phases,
      tasks: taskQueries,
      functions: homeFilters.functions.length > 0 ? homeFilters.functions : ["All"],
      // If owner chips were entered but none matched, return a sentinel so the result is empty.
      primaryOwners:
        homeFilters.ownerSearch.length > 0
          ? (uniqueOwners.length > 0 ? uniqueOwners : ["__no_match__"])
          : [],
    };
  }, [homeFilters.phases, homeFilters.functions, homeFilters.ownerSearch, homeFilters.taskSearch]);

  return (
    <div className="flex-1 flex flex-col overflow-hidden">
      <StickyHomeFilterBar enableTaskControls />
      <div className="flex-1 flex flex-col overflow-auto" ref={containerRef}>
        <div className="px-6 pt-6 pb-2 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Calendar className="w-5 h-5 text-primary" />
            <h1 className="text-[22px] font-extrabold tracking-tight text-foreground">
              My Tasks
            </h1>
          </div>
          <ReportExporter context="Schedule" />
        </div>

        <div className="px-6 pb-6">
          <PortfolioScheduleGantt
            expandable
            initiallyExpanded={incomingProgram ? [incomingProgram] : []}
            renderExpanded={(name) => <DualTrackPlatformDetail programName={name} pageFilters={pageFilters} />}
          />
        </div>
      </div>
    </div>
  );
};

/**
 * Renders both phase tracks for a single platform inside the expanded
 * /schedule row: GOE/NPI defaults open, SChM defaults collapsed. Each section
 * reuses PlatformScheduleDetail so users see a familiar layout per track.
 */
const DualTrackPlatformDetail = ({
  programName,
  pageFilters,
}: {
  programName: string;
  pageFilters: TaskPageFilterState;
}) => {
  const [openTracks, setOpenTracks] = useState<Set<"GOE_NPI" | "SCHM">>(new Set(["GOE_NPI"]));
  const toggle = (t: "GOE_NPI" | "SCHM") => {
    setOpenTracks((prev) => {
      const next = new Set(prev);
      next.has(t) ? next.delete(t) : next.add(t);
      return next;
    });
  };

  return (
    <div className="bg-muted/[0.02]">
      {(["GOE_NPI", "SCHM"] as const).map((track) => {
        const isOpen = openTracks.has(track);
        const tone = TRACK_TONE[track];
        const phaseSummary =
          track === "SCHM"
            ? "Concept · Define · Plan · Develop · Launch"
            : "Concept · Define · Plan · Qual · Pilot · Ramp";
        return (
          <div key={track} className="border-t border-border/40 first:border-t-0">
            <button
              type="button"
              onClick={() => toggle(track)}
              className="w-full flex items-center gap-3 px-4 py-2.5 hover:bg-muted/40 transition-colors"
            >
              {isOpen ? (
                <ChevronDown className="w-3.5 h-3.5 text-muted-foreground shrink-0" />
              ) : (
                <ChevronRight className="w-3.5 h-3.5 text-muted-foreground shrink-0" />
              )}
              <span
                className={cn(
                  "inline-flex items-center font-semibold rounded border h-5 px-2 text-[10px] tracking-wide uppercase",
                  tone.bg,
                  tone.text,
                  tone.border,
                )}
              >
                {TRACK_LABEL[track]} Track
              </span>
              <span className="text-[10px] text-muted-foreground">{phaseSummary}</span>
            </button>
            {isOpen && (
              <PlatformScheduleDetail
                programName={programName}
                pageFilters={pageFilters}
                track={track}
              />
            )}
          </div>
        );
      })}
    </div>
  );
};

export default Schedule;
