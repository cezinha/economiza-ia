import { useState, useMemo } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Truck, Filter, TrendingDown, AlertTriangle, Package, CheckCircle } from "lucide-react";
import { cn } from "@/lib/utils";
import UniversalFilterBar from "@/components/dashboard/UniversalFilterBar";
import { useUniversalFilters } from "@/contexts/UniversalFilterContext";

interface SupplyChainItem {
  id: string;
  part: string;
  supplier: string;
  leadTime: number;
  riskLevel: "high" | "medium" | "low";
  affectedPrograms: string[];
  status: "on-track" | "delayed" | "critical" | "resolved";
  bomComplete: boolean;
  scheduleImpact: number; // days of slippage
}

const mockParts: SupplyChainItem[] = [
  { id: "SC-001", part: "LPDDR5X 16GB Module", supplier: "Samsung", leadTime: 16, riskLevel: "high", affectedPrograms: ["Laptop 1", "Laptop 4"], status: "critical", bomComplete: true, scheduleImpact: 14 },
  { id: "SC-002", part: "14\" OLED Display Panel", supplier: "LG Display", leadTime: 12, riskLevel: "medium", affectedPrograms: ["Laptop 2", "Laptop 3"], status: "delayed", bomComplete: true, scheduleImpact: 7 },
  { id: "SC-003", part: "Thunderbolt 4 Controller", supplier: "Intel", leadTime: 8, riskLevel: "low", affectedPrograms: ["Laptop 1", "Laptop 2", "Laptop 5"], status: "on-track", bomComplete: true, scheduleImpact: 0 },
  { id: "SC-004", part: "72Wh Battery Cell", supplier: "BYD", leadTime: 10, riskLevel: "low", affectedPrograms: ["Laptop 1", "Laptop 6"], status: "resolved", bomComplete: true, scheduleImpact: 0 },
  { id: "SC-005", part: "Custom Thermal Module", supplier: "Cooler Master", leadTime: 14, riskLevel: "high", affectedPrograms: ["Laptop 7"], status: "critical", bomComplete: false, scheduleImpact: 21 },
  { id: "SC-006", part: "WiFi 7 Module", supplier: "Qualcomm", leadTime: 6, riskLevel: "low", affectedPrograms: ["Laptop 1", "Laptop 2", "Laptop 3", "Laptop 4"], status: "on-track", bomComplete: true, scheduleImpact: 0 },
  { id: "SC-007", part: "Hinge Assembly", supplier: "Jarllytec", leadTime: 8, riskLevel: "medium", affectedPrograms: ["Laptop 3"], status: "delayed", bomComplete: true, scheduleImpact: 5 },
  { id: "SC-008", part: "Keyboard Module", supplier: "Darfon", leadTime: 6, riskLevel: "low", affectedPrograms: ["Laptop 2", "Laptop 6"], status: "on-track", bomComplete: true, scheduleImpact: 0 },
  { id: "SC-009", part: "Magnesium Alloy Chassis", supplier: "Foxconn", leadTime: 10, riskLevel: "medium", affectedPrograms: ["Laptop 4", "Laptop 5"], status: "delayed", bomComplete: false, scheduleImpact: 10 },
  { id: "SC-010", part: "Power Adapter 140W GaN", supplier: "Delta Electronics", leadTime: 8, riskLevel: "low", affectedPrograms: ["Laptop 1", "Laptop 7"], status: "on-track", bomComplete: true, scheduleImpact: 0 },
];

const riskLetter: Record<string, string> = { high: "H", medium: "M", low: "L" };
const riskPillClass: Record<string, string> = {
  high: "bg-destructive text-destructive-foreground border-destructive",
  medium: "bg-muted text-foreground border-border",
  low: "bg-muted text-foreground border-border",
};

const statusLabels: Record<string, string> = {
  "on-track": "On Track",
  delayed: "Delayed",
  critical: "Critical",
  resolved: "Resolved",
};

const statusColors: Record<string, string> = {
  "on-track": "bg-green-100 text-green-800 border-green-200",
  delayed: "bg-yellow-100 text-yellow-800 border-yellow-200",
  critical: "bg-red-100 text-red-800 border-red-200",
  resolved: "bg-gray-100 text-gray-600 border-gray-200",
};

const SupplyChain = () => {
  const { matchesPlatform } = useUniversalFilters();
  const [filterRisk, setFilterRisk] = useState("all");
  const [filterSupplier, setFilterSupplier] = useState("all");

  const suppliers = [...new Set(mockParts.map(p => p.supplier))];

  const platformFiltered = useMemo(() => mockParts.filter(p => p.affectedPrograms.some(matchesPlatform)), [matchesPlatform]);

  const filtered = useMemo(() => platformFiltered.filter(p => {
    if (filterRisk !== "all" && p.riskLevel !== filterRisk) return false;
    if (filterSupplier !== "all" && p.supplier !== filterSupplier) return false;
    return true;
  }), [filterRisk, filterSupplier, platformFiltered]);

  const kpis = useMemo(() => ({
    riskScore: Math.round(platformFiltered.reduce((s, p) => s + (p.riskLevel === "high" ? 3 : p.riskLevel === "medium" ? 2 : 1), 0) / Math.max(1, platformFiltered.length) * 33),
    avgLeadTime: Math.round(platformFiltered.reduce((s, p) => s + p.leadTime, 0) / Math.max(1, platformFiltered.length)),
    criticalParts: platformFiltered.filter(p => p.riskLevel === "high").length,
    bomComplete: Math.round(platformFiltered.filter(p => p.bomComplete).length / Math.max(1, platformFiltered.length) * 100),
  }), [platformFiltered]);

  // Bar chart data for schedule impact
  const barData = platformFiltered.filter(p => p.scheduleImpact > 0).sort((a, b) => b.scheduleImpact - a.scheduleImpact);
  const maxImpact = Math.max(1, ...barData.map(d => d.scheduleImpact));

  return (
    <div className="flex-1 flex flex-col overflow-auto p-4 space-y-4">
      <div className="flex items-center gap-2.5">
        <Truck className="w-6 h-6 text-primary" />
        <h1 className="text-[22px] font-extrabold text-foreground tracking-tight flex-1">Supply Chain Correlation</h1>
        <UniversalFilterBar />
      </div>

      <div className="grid grid-cols-4 gap-3">
        {[
          { label: "Supplier Risk Score", value: `${kpis.riskScore}/100`, icon: AlertTriangle, color: kpis.riskScore > 60 ? "text-destructive" : "text-yellow-600" },
          { label: "Avg Lead Time", value: `${kpis.avgLeadTime} wks`, icon: TrendingDown, color: "text-foreground" },
          { label: "Critical Parts", value: kpis.criticalParts, icon: Package, color: "text-destructive" },
          { label: "BOM Completeness", value: `${kpis.bomComplete}%`, icon: CheckCircle, color: kpis.bomComplete >= 90 ? "text-green-600" : "text-yellow-600" },
        ].map(s => (
          <Card key={s.label} className="border-border">
            <CardContent className="p-3 flex items-center gap-3">
              <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
                <s.icon className="w-4 h-4 text-primary" />
              </div>
              <div>
                <p className="text-[10px] text-muted-foreground uppercase tracking-wider font-semibold">{s.label}</p>
                <p className={cn("text-lg font-bold", s.color)}>{s.value}</p>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-[1fr_300px] gap-4">
        {/* Main Table */}
        <Card className="border-border">
          <CardHeader className="pb-2 pt-3 px-4">
            <div className="flex items-center justify-between">
              <CardTitle className="text-xs">Component Supply Status</CardTitle>
              <div className="flex items-center gap-2">
                <Filter className="w-3 h-3 text-muted-foreground" />
                <Select value={filterRisk} onValueChange={setFilterRisk}>
                  <SelectTrigger className="w-[110px] h-7 text-[10px]"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Risk</SelectItem>
                    <SelectItem value="high">High</SelectItem>
                    <SelectItem value="medium">Medium</SelectItem>
                    <SelectItem value="low">Low</SelectItem>
                  </SelectContent>
                </Select>
                <Select value={filterSupplier} onValueChange={setFilterSupplier}>
                  <SelectTrigger className="w-[130px] h-7 text-[10px]"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Suppliers</SelectItem>
                    {suppliers.map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardHeader>
          <CardContent className="p-0">
            <table className="w-full text-xs">
              <thead>
                <tr className="border-b border-border bg-muted/30">
                  {["Part", "Supplier", "Lead Time", "Risk", "Programs", "Status"].map(h => (
                    <th key={h} className="text-left px-3 py-2 font-semibold text-muted-foreground">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {filtered.map(p => (
                  <tr key={p.id} className="border-b border-border/40 hover:bg-muted/20 transition-colors">
                    <td className="px-3 py-2 font-medium">{p.part}</td>
                    <td className="px-3 py-2 text-muted-foreground">{p.supplier}</td>
                    <td className="px-3 py-2">{p.leadTime} wks</td>
                    <td className="px-3 py-2">
                      <span
                        className={cn(
                          "inline-flex items-center justify-center w-5 h-5 rounded-full border text-[10px] font-bold",
                          riskPillClass[p.riskLevel]
                        )}
                        title={p.riskLevel.charAt(0).toUpperCase() + p.riskLevel.slice(1)}
                      >
                        {riskLetter[p.riskLevel]}
                      </span>
                    </td>
                    <td className="px-3 py-2">
                      <div className="flex flex-wrap gap-1">{p.affectedPrograms.map(pr => <span key={pr} className="text-[9px] px-1 py-0.5 bg-muted rounded">{pr}</span>)}</div>
                    </td>
                    <td className="px-3 py-2"><Badge variant="outline" className={cn("text-[9px]", statusColors[p.status])}>{statusLabels[p.status]}</Badge></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </CardContent>
        </Card>

        {/* Schedule Impact Chart */}
        <Card className="border-border">
          <CardHeader className="pb-2 pt-3 px-4">
            <CardTitle className="text-xs">Schedule Impact (days)</CardTitle>
          </CardHeader>
          <CardContent className="px-4 pb-4 space-y-2">
            {barData.length === 0 ? (
              <p className="text-xs text-muted-foreground text-center py-8">No delays detected</p>
            ) : (
              barData.map(d => (
                <div key={d.id} className="space-y-0.5">
                  <div className="flex justify-between text-[10px]">
                    <span className="text-foreground truncate max-w-[180px]">{d.part}</span>
                    <span className="font-bold text-destructive">+{d.scheduleImpact}d</span>
                  </div>
                  <div className="h-3 bg-muted rounded-sm overflow-hidden">
                    <div
                      className={cn("h-full rounded-sm", d.scheduleImpact > 14 ? "bg-destructive" : d.scheduleImpact > 7 ? "bg-yellow-500" : "bg-blue-500")}
                      style={{ width: `${(d.scheduleImpact / maxImpact) * 100}%` }}
                    />
                  </div>
                </div>
              ))
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default SupplyChain;
